/*    */ package org.eclipse.core.internal.filesystem;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FileCacheHolder
/*    */ {
/* 42 */   static final FileCache instance = createFileCache();
/*    */   static CoreException ce;
/*    */   
/*    */   private static FileCache createFileCache() {
/*    */     try {
/* 47 */       return new FileCache();
/* 48 */     } catch (CoreException e) {
/* 49 */       ce = e;
/* 50 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\FileCache$FileCacheHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */