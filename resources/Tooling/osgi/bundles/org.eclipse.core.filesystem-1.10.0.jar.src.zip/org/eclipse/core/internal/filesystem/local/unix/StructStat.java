/*    */ package org.eclipse.core.internal.filesystem.local.unix;
/*    */ 
/*    */ import org.eclipse.core.filesystem.provider.FileInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructStat
/*    */ {
/* 25 */   private static final boolean USE_MILLISECOND_RESOLUTION = Boolean.parseBoolean(System.getProperty("eclipse.filesystem.useNatives.modificationTimestampMillisecondsResolution", "true"));
/*    */   
/*    */   public int st_mode;
/*    */   public long st_size;
/*    */   public long st_mtime;
/*    */   public long st_mtime_msec;
/*    */   public long st_flags;
/*    */   
/*    */   public FileInfo toFileInfo() {
/* 34 */     FileInfo info = new FileInfo();
/* 35 */     info.setExists(true);
/* 36 */     info.setLength(this.st_size);
/* 37 */     long lastModified = this.st_mtime * 1000L;
/* 38 */     if (USE_MILLISECOND_RESOLUTION) {
/* 39 */       lastModified += this.st_mtime_msec;
/*    */     }
/* 41 */     info.setLastModified(lastModified);
/* 42 */     if ((this.st_mode & UnixFileFlags.S_IFMT) == UnixFileFlags.S_IFDIR)
/* 43 */       info.setDirectory(true); 
/* 44 */     if ((this.st_flags & (UnixFileFlags.UF_IMMUTABLE | UnixFileFlags.SF_IMMUTABLE)) != 0L)
/* 45 */       info.setAttribute(2097152, true); 
/* 46 */     if ((this.st_mode & UnixFileFlags.S_IRUSR) == 0)
/* 47 */       info.setAttribute(4194304, false); 
/* 48 */     if ((this.st_mode & UnixFileFlags.S_IWUSR) == 0)
/* 49 */       info.setAttribute(8388608, false); 
/* 50 */     if ((this.st_mode & UnixFileFlags.S_IXUSR) != 0)
/* 51 */       info.setAttribute(16777216, true); 
/* 52 */     if ((this.st_mode & UnixFileFlags.S_IRGRP) != 0)
/* 53 */       info.setAttribute(33554432, true); 
/* 54 */     if ((this.st_mode & UnixFileFlags.S_IWGRP) != 0)
/* 55 */       info.setAttribute(67108864, true); 
/* 56 */     if ((this.st_mode & UnixFileFlags.S_IXGRP) != 0)
/* 57 */       info.setAttribute(134217728, true); 
/* 58 */     if ((this.st_mode & UnixFileFlags.S_IROTH) != 0)
/* 59 */       info.setAttribute(268435456, true); 
/* 60 */     if ((this.st_mode & UnixFileFlags.S_IWOTH) != 0)
/* 61 */       info.setAttribute(536870912, true); 
/* 62 */     if ((this.st_mode & UnixFileFlags.S_IXOTH) != 0)
/* 63 */       info.setAttribute(1073741824, true); 
/* 64 */     return info;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\loca\\unix\StructStat.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */