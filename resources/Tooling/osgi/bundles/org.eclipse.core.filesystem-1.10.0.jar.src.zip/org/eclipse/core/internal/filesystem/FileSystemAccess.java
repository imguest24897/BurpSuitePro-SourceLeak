/*    */ package org.eclipse.core.internal.filesystem;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.osgi.service.datalocation.Location;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.FrameworkUtil;
/*    */ import org.osgi.framework.InvalidSyntaxException;
/*    */ import org.osgi.util.tracker.ServiceTracker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileSystemAccess
/*    */ {
/*    */   public static IPath getCacheLocation() {
/*    */     try {
/* 42 */       Bundle bundle = FrameworkUtil.getBundle(FileSystemAccess.class);
/* 43 */       if (bundle != null) {
/* 44 */         BundleContext context = bundle.getBundleContext();
/* 45 */         if (context != null) {
/* 46 */           ServiceTracker<Location, Location> tracker = new ServiceTracker(context, context.createFilter(Location.INSTANCE_FILTER), null);
/* 47 */           tracker.open();
/*    */           try {
/* 49 */             Location location = (Location)tracker.getService();
/* 50 */             if (location != null) {
/* 51 */               Path path = new Path((new File(location.getURL().getFile())).toString());
/* 52 */               return path.append(".metadata/.plugins").append("org.eclipse.core.filesystem");
/*    */             } 
/*    */           } finally {
/* 55 */             tracker.close();
/*    */           } 
/*    */         } 
/*    */       } 
/* 59 */     } catch (InvalidSyntaxException e) {
/* 60 */       Policy.log(1, null, (Throwable)e);
/*    */     } 
/*    */ 
/*    */     
/* 64 */     return Path.fromOSString(System.getProperty("user.home"));
/*    */   }
/*    */   
/*    */   public static Enumeration<URL> findEntries(String path, String filePattern, boolean recurse) {
/* 68 */     Bundle bundle = FrameworkUtil.getBundle(FileSystemAccess.class);
/* 69 */     if (bundle != null) {
/* 70 */       return bundle.findEntries(path, filePattern, recurse);
/*    */     }
/* 72 */     return Collections.emptyEnumeration();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\FileSystemAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */