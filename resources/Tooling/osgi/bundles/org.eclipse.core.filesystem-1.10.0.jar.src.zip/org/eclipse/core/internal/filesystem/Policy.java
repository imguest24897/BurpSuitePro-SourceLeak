/*    */ package org.eclipse.core.internal.filesystem;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Date;
/*    */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Policy
/*    */ {
/*    */   public static final String PI_FILE_SYSTEM = "org.eclipse.core.filesystem";
/*    */   
/*    */   public static void debug(String message) {
/* 33 */     StringBuilder buffer = new StringBuilder();
/* 34 */     buffer.append(new Date(System.currentTimeMillis()));
/* 35 */     buffer.append(" - [");
/* 36 */     buffer.append(Thread.currentThread().getName());
/* 37 */     buffer.append("] ");
/* 38 */     buffer.append(message);
/* 39 */     System.out.println(buffer.toString());
/*    */   }
/*    */   
/*    */   public static void error(int code, String message) throws CoreException {
/* 43 */     error(code, message, null);
/*    */   }
/*    */   
/*    */   public static void error(int code, String message, Throwable exception) throws CoreException {
/* 47 */     int severity = (code == 0) ? 0 : (1 << code % 100 / 33);
/* 48 */     throw new CoreException(new Status(severity, "org.eclipse.core.filesystem", code, message, exception));
/*    */   }
/*    */   
/*    */   public static void log(int severity, String message, Throwable t) {
/* 52 */     if (message == null)
/* 53 */       message = ""; 
/* 54 */     RuntimeLog.log((IStatus)new Status(severity, "org.eclipse.core.filesystem", 1, message, t));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void safeClose(InputStream in) {
/*    */     try {
/* 62 */       if (in != null)
/* 63 */         in.close(); 
/* 64 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void safeClose(OutputStream out) {
/*    */     try {
/* 74 */       if (out != null)
/* 75 */         out.close(); 
/* 76 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\Policy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */