/*     */ package org.eclipse.core.internal.preferences.legacy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.core.internal.preferences.DefaultPreferences;
/*     */ import org.eclipse.core.internal.preferences.EclipsePreferences;
/*     */ import org.eclipse.core.internal.preferences.PreferencesService;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PreferenceForwarder
/*     */   extends Preferences
/*     */   implements IEclipsePreferences.IPreferenceChangeListener, IEclipsePreferences.INodeChangeListener
/*     */ {
/*  37 */   private static final byte[] BYTE_ARRAY_DEFAULT_DEFAULT = new byte[0];
/*     */   
/*  39 */   private IEclipsePreferences pluginRoot = (IEclipsePreferences)PreferencesService.getDefault().getRootNode().node("instance");
/*  40 */   private DefaultPreferences defaultsRoot = (DefaultPreferences)PreferencesService.getDefault().getRootNode().node("default");
/*     */ 
/*     */   
/*     */   private String pluginID;
/*     */   
/*     */   private Object plugin;
/*     */   
/*     */   private boolean notify = true;
/*     */ 
/*     */   
/*     */   public PreferenceForwarder(String pluginID) {
/*  51 */     this((Object)null, pluginID);
/*     */   }
/*     */ 
/*     */   
/*     */   public PreferenceForwarder(Object plugin, String pluginID) {
/*  56 */     this.plugin = plugin;
/*  57 */     this.pluginID = pluginID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void added(IEclipsePreferences.NodeChangeEvent event) {
/*  65 */     if (this.listeners.size() > 0 && this.pluginID.equals(event.getChild().name())) {
/*     */       try {
/*  67 */         EclipsePreferences prefs = (EclipsePreferences)event.getChild();
/*  68 */         prefs.addPreferenceChangeListener(this);
/*  69 */       } catch (ClassCastException e) {
/*  70 */         throw new RuntimeException("Plug-in preferences must be instances of EclipsePreferences: " + e.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removed(IEclipsePreferences.NodeChangeEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addPropertyChangeListener(Preferences.IPropertyChangeListener listener) {
/*  92 */     if (this.listeners.size() == 0) {
/*  93 */       EclipsePreferences prefs = getPluginPreferences(false);
/*  94 */       if (prefs != null) {
/*  95 */         prefs.addPreferenceChangeListener(this);
/*     */       }
/*  97 */       this.pluginRoot.addNodeChangeListener(this);
/*     */     } 
/*  99 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preferenceChange(IEclipsePreferences.PreferenceChangeEvent event) {
/* 109 */     if (!this.notify)
/*     */       return; 
/* 111 */     Object oldValue = event.getOldValue();
/* 112 */     Object newValue = event.getNewValue();
/* 113 */     String key = event.getKey();
/* 114 */     if (newValue == null) {
/* 115 */       newValue = getDefault(key, oldValue);
/* 116 */     } else if (oldValue == null) {
/* 117 */       oldValue = getDefault(key, newValue);
/* 118 */     }  firePropertyChangeEvent(key, oldValue, newValue);
/*     */   }
/*     */   
/*     */   private EclipsePreferences getPluginPreferences(boolean create) {
/*     */     try {
/* 123 */       if (!create && !this.pluginRoot.nodeExists(this.pluginID))
/* 124 */         return null; 
/* 125 */     } catch (BackingStoreException backingStoreException) {
/* 126 */       return null;
/*     */     } 
/*     */     try {
/* 129 */       return (EclipsePreferences)this.pluginRoot.node(this.pluginID);
/* 130 */     } catch (ClassCastException e) {
/* 131 */       throw new RuntimeException("Plug-in preferences must be instances of EclipsePreferences: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private IEclipsePreferences getDefaultPreferences() {
/* 136 */     return this.defaultsRoot.node(this.pluginID, this.plugin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removePropertyChangeListener(Preferences.IPropertyChangeListener listener) {
/* 147 */     this.listeners.remove(listener);
/* 148 */     if (this.listeners.size() == 0) {
/* 149 */       EclipsePreferences prefs = getPluginPreferences(false);
/* 150 */       if (prefs != null) {
/* 151 */         prefs.removePreferenceChangeListener(this);
/*     */       }
/* 153 */       this.pluginRoot.removeNodeChangeListener(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getDefault(String key, Object obj) {
/* 165 */     IEclipsePreferences defaults = getDefaultPreferences();
/* 166 */     if (obj instanceof String)
/* 167 */       return defaults.get(key, ""); 
/* 168 */     if (obj instanceof Integer)
/* 169 */       return Integer.valueOf(defaults.getInt(key, 0)); 
/* 170 */     if (obj instanceof Double)
/* 171 */       return Double.valueOf(defaults.getDouble(key, 0.0D)); 
/* 172 */     if (obj instanceof Float)
/* 173 */       return Float.valueOf(defaults.getFloat(key, 0.0F)); 
/* 174 */     if (obj instanceof Long)
/* 175 */       return Long.valueOf(defaults.getLong(key, 0L)); 
/* 176 */     if (obj instanceof byte[])
/* 177 */       return defaults.getByteArray(key, BYTE_ARRAY_DEFAULT_DEFAULT); 
/* 178 */     if (obj instanceof Boolean) {
/* 179 */       return defaults.getBoolean(key, false) ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(String name) {
/* 195 */     if (name == null)
/* 196 */       return false; 
/* 197 */     String value = getPluginPreferences(true).get(name, null);
/* 198 */     if (value != null)
/* 199 */       return true; 
/* 200 */     return (getDefaultPreferences().get(name, null) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String name) {
/* 215 */     return getPluginPreferences(true).getBoolean(name, getDefaultPreferences().getBoolean(name, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, boolean value) {
/* 239 */     Boolean oldValue = getBoolean(name) ? Boolean.TRUE : Boolean.FALSE;
/* 240 */     Boolean newValue = value ? Boolean.TRUE : Boolean.FALSE;
/* 241 */     if (newValue == oldValue)
/*     */       return; 
/*     */     try {
/* 244 */       this.notify = false;
/* 245 */       if (getDefaultBoolean(name) == value) {
/* 246 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 248 */         getPluginPreferences(true).putBoolean(name, value);
/* 249 */       }  firePropertyChangeEvent(name, oldValue, newValue);
/*     */     } finally {
/* 251 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDefaultBoolean(String name) {
/* 267 */     return getDefaultPreferences().getBoolean(name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, boolean value) {
/* 287 */     getDefaultPreferences().putBoolean(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble(String name) {
/* 302 */     return getPluginPreferences(true).getDouble(name, getDefaultPreferences().getDouble(name, 0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, double value) {
/* 327 */     if (Double.isNaN(value))
/* 328 */       throw new IllegalArgumentException(); 
/* 329 */     double doubleValue = getDouble(name);
/* 330 */     if (value == doubleValue)
/*     */       return; 
/* 332 */     Double oldValue = Double.valueOf(doubleValue);
/* 333 */     Double newValue = Double.valueOf(value);
/*     */     try {
/* 335 */       this.notify = false;
/* 336 */       if (getDefaultDouble(name) == value) {
/* 337 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 339 */         getPluginPreferences(true).putDouble(name, value);
/* 340 */       }  firePropertyChangeEvent(name, oldValue, newValue);
/*     */     } finally {
/* 342 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDefaultDouble(String name) {
/* 358 */     return getDefaultPreferences().getDouble(name, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, double value) {
/* 379 */     if (Double.isNaN(value))
/* 380 */       throw new IllegalArgumentException(); 
/* 381 */     getDefaultPreferences().putDouble(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat(String name) {
/* 396 */     return getPluginPreferences(true).getFloat(name, getDefaultPreferences().getFloat(name, 0.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, float value) {
/* 421 */     if (Float.isNaN(value))
/* 422 */       throw new IllegalArgumentException(); 
/* 423 */     float floatValue = getFloat(name);
/* 424 */     if (value == floatValue)
/*     */       return; 
/* 426 */     Float oldValue = Float.valueOf(floatValue);
/* 427 */     Float newValue = Float.valueOf(value);
/*     */     try {
/* 429 */       this.notify = false;
/* 430 */       if (getDefaultFloat(name) == value) {
/* 431 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 433 */         getPluginPreferences(true).putFloat(name, value);
/* 434 */       }  firePropertyChangeEvent(name, oldValue, newValue);
/*     */     } finally {
/* 436 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDefaultFloat(String name) {
/* 452 */     return getDefaultPreferences().getFloat(name, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, float value) {
/* 473 */     if (Float.isNaN(value))
/* 474 */       throw new IllegalArgumentException(); 
/* 475 */     getDefaultPreferences().putFloat(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(String name) {
/* 490 */     return getPluginPreferences(true).getInt(name, getDefaultPreferences().getInt(name, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, int value) {
/* 514 */     int intValue = getInt(name);
/* 515 */     if (value == intValue)
/*     */       return; 
/* 517 */     Integer oldValue = Integer.valueOf(intValue);
/* 518 */     Integer newValue = Integer.valueOf(value);
/*     */     try {
/* 520 */       this.notify = false;
/* 521 */       if (getDefaultInt(name) == value) {
/* 522 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 524 */         getPluginPreferences(true).putInt(name, value);
/* 525 */       }  firePropertyChangeEvent(name, oldValue, newValue);
/*     */     } finally {
/* 527 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultInt(String name) {
/* 543 */     return getDefaultPreferences().getInt(name, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, int value) {
/* 563 */     getDefaultPreferences().putInt(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong(String name) {
/* 578 */     return getPluginPreferences(true).getLong(name, getDefaultPreferences().getLong(name, 0L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, long value) {
/* 602 */     long longValue = getLong(name);
/* 603 */     if (value == longValue)
/*     */       return; 
/* 605 */     Long oldValue = Long.valueOf(longValue);
/* 606 */     Long newValue = Long.valueOf(value);
/*     */     try {
/* 608 */       this.notify = false;
/* 609 */       if (getDefaultLong(name) == value) {
/* 610 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 612 */         getPluginPreferences(true).putLong(name, value);
/* 613 */       }  firePropertyChangeEvent(name, oldValue, newValue);
/*     */     } finally {
/* 615 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getDefaultLong(String name) {
/* 631 */     return getDefaultPreferences().getLong(name, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, long value) {
/* 651 */     getDefaultPreferences().putLong(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 665 */     return getPluginPreferences(true).get(name, getDefaultPreferences().get(name, ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, String value) {
/* 689 */     if (value == null)
/* 690 */       throw new IllegalArgumentException(); 
/* 691 */     String oldValue = getString(name);
/* 692 */     if (value.equals(oldValue))
/*     */       return; 
/*     */     try {
/* 695 */       this.notify = false;
/* 696 */       if (getDefaultString(name).equals(value)) {
/* 697 */         getPluginPreferences(true).remove(name);
/*     */       } else {
/* 699 */         getPluginPreferences(true).put(name, value);
/* 700 */       }  firePropertyChangeEvent(name, oldValue, value);
/*     */     } finally {
/* 702 */       this.notify = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultString(String name) {
/* 718 */     return getDefaultPreferences().get(name, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String name, String value) {
/* 738 */     if (value == null)
/* 739 */       throw new IllegalArgumentException(); 
/* 740 */     getDefaultPreferences().put(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault(String name) {
/* 754 */     if (name == null)
/* 755 */       return false; 
/* 756 */     return (getPluginPreferences(true).get(name, null) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToDefault(String name) {
/* 780 */     EclipsePreferences eclipsePreferences = getPluginPreferences(true);
/* 781 */     Object oldValue = eclipsePreferences.get(name, null);
/* 782 */     if (oldValue != null) {
/* 783 */       eclipsePreferences.remove(name);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] propertyNames() {
/* 794 */     return getPluginPreferences(true).keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] defaultPropertyNames() {
/*     */     try {
/* 806 */       return getDefaultPreferences().keys();
/* 807 */     } catch (BackingStoreException e) {
/* 808 */       logError(e.getMessage(), (Exception)e);
/* 809 */       return new String[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needsSaving() {
/* 823 */     return getPluginPreferences(true).isDirty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws BackingStoreException {
/* 832 */     EclipsePreferences eclipsePreferences = getPluginPreferences(false);
/* 833 */     if (eclipsePreferences != null) {
/* 834 */       eclipsePreferences.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void logError(String message, Exception e) {
/* 841 */     Status status = new Status(4, "org.eclipse.equinox.preferences", 4, message, e);
/* 842 */     RuntimeLog.log((IStatus)status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(InputStream in) throws IOException {
/* 850 */     Properties result = new Properties();
/* 851 */     result.load(in);
/* 852 */     convertFromProperties(result);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 857 */       flush();
/* 858 */     } catch (BackingStoreException e) {
/* 859 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(OutputStream out, String header) throws IOException {
/* 868 */     Properties result = convertToProperties();
/* 869 */     result.store(out, header);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 874 */       flush();
/* 875 */     } catch (BackingStoreException e) {
/* 876 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void convertFromProperties(Properties props) {
/* 881 */     EclipsePreferences eclipsePreferences = getPluginPreferences(true);
/* 882 */     for (Object object : props.keySet()) {
/* 883 */       String key = (String)object;
/* 884 */       String value = props.getProperty(key);
/* 885 */       if (value != null) {
/* 886 */         eclipsePreferences.put(key, value);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 892 */     return "PreferenceForwarder(" + this.pluginID + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties convertToProperties() {
/* 900 */     Properties result = new Properties();
/* 901 */     String[] keys = propertyNames(); byte b; int i; String[] arrayOfString1;
/* 902 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 903 */       String value = getString(key);
/* 904 */       if (!"".equals(value))
/* 905 */         result.put(key, value);  b++; }
/*     */     
/* 907 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\preferences\legacy\PreferenceForwarder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */