/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.runtime.messages";
/*    */   public static String auth_alreadySpecified;
/*    */   public static String auth_notAvailable;
/*    */   public static String line_separator_platform_unix;
/*    */   public static String line_separator_platform_windows;
/*    */   public static String meta_appNotInit;
/*    */   public static String meta_exceptionParsingLog;
/*    */   public static String plugin_deactivatedLoad;
/*    */   public static String plugin_shutdownProblems;
/*    */   public static String plugin_startupProblems;
/*    */   public static String preferences_saveProblems;
/*    */   public static String parse_badPrereqOnFrag;
/*    */   public static String parse_duplicateFragment;
/*    */   public static String parse_duplicateLib;
/*    */   public static String parse_internalStack;
/*    */   public static String parse_unknownElement;
/*    */   public static String parse_unknownTopElement;
/*    */   public static String parse_unknownAttribute;
/*    */   public static String parse_error;
/*    */   public static String parse_errorProcessing;
/*    */   public static String parse_errorNameLineColumn;
/*    */   public static String parse_validExport;
/*    */   public static String parse_validMatch;
/*    */   public static String parse_unknownLibraryType;
/*    */   public static String parse_nullFragmentIdentifier;
/*    */   public static String parse_nullPluginIdentifier;
/*    */   public static String parse_duplicatePlugin;
/*    */   public static String parse_unknownEntry;
/*    */   public static String parse_missingPluginId;
/*    */   public static String parse_missingPluginName;
/*    */   public static String parse_missingFPName;
/*    */   public static String parse_missingFPVersion;
/*    */   public static String parse_missingPluginVersion;
/*    */   public static String parse_fragmentMissingAttr;
/*    */   public static String parse_pluginMissingAttr;
/*    */   public static String parse_pluginMissingIdName;
/*    */   public static String parse_fragmentMissingIdName;
/*    */   public static String parse_missingFragmentPd;
/*    */   public static String parse_extPointDisabled;
/*    */   public static String parse_extPointUnknown;
/*    */   public static String parse_unsatisfiedOptPrereq;
/*    */   public static String parse_unsatisfiedPrereq;
/*    */   public static String parse_prereqDisabled;
/*    */   public static String parse_prereqLoop;
/*    */   public static String parse_prereqOptLoop;
/*    */   public static String plugin_notPluginClass;
/*    */   public static String plugin_unableToResolve;
/*    */   public static String plugin_pluginDisabled;
/*    */   public static String plugin_instantiateClassError;
/*    */   public static String plugin_loadClassError;
/*    */   public static String plugin_unableToGetActivator;
/*    */   
/*    */   static {
/* 89 */     reloadMessages();
/*    */   }
/*    */   
/*    */   public static void reloadMessages() {
/* 93 */     NLS.initializeMessages("org.eclipse.core.internal.runtime.messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */