/*     */ package org.eclipse.core.internal.preferences.legacy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.core.internal.preferences.exchange.IProductPreferencesService;
/*     */ import org.eclipse.core.internal.runtime.InternalPlatform;
/*     */ import org.eclipse.core.runtime.FileLocator;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProduct;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProductPreferencesService
/*     */   implements IProductPreferencesService
/*     */ {
/*  28 */   private static final IPath NL_DIR = (IPath)new Path("$nl$");
/*     */   
/*     */   public static final String PRODUCT_KEY = "preferenceCustomization";
/*     */   
/*     */   private static final String LEGACY_PRODUCT_CUSTOMIZATION_FILENAME = "plugin_customization.ini";
/*     */   
/*     */   private static final String PROPERTIES_FILE_EXTENSION = "properties";
/*     */   private boolean initialized = false;
/*  36 */   private String customizationValue = null;
/*  37 */   private Bundle customizationBundle = null;
/*  38 */   private String productID = null;
/*     */   
/*     */   private void initValues() {
/*  41 */     if (this.initialized)
/*     */       return; 
/*  43 */     this.initialized = true;
/*     */     
/*  45 */     IProduct product = Platform.getProduct();
/*  46 */     if (product == null) {
/*  47 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/*  48 */         InternalPlatform.message("Product not available to set product default preference overrides."); 
/*     */       return;
/*     */     } 
/*  51 */     this.productID = product.getId();
/*  52 */     if (this.productID == null) {
/*  53 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/*  54 */         InternalPlatform.message("Product ID not available to apply product-level preference defaults."); 
/*     */       return;
/*     */     } 
/*  57 */     this.customizationBundle = product.getDefiningBundle();
/*  58 */     if (this.customizationBundle == null) {
/*  59 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/*  60 */         InternalPlatform.message("Bundle not available to apply product-level preference defaults for product id: " + this.productID); 
/*     */       return;
/*     */     } 
/*  63 */     this.customizationValue = product.getProperty("preferenceCustomization");
/*  64 */     if (this.customizationValue == null) {
/*  65 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/*  66 */         InternalPlatform.message("Product : " + this.productID + " does not define preference customization file. Using legacy file: plugin_customization.ini"); 
/*  67 */       this.customizationValue = "plugin_customization.ini";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getProductCustomization() {
/*  73 */     initValues();
/*  74 */     URL url = null;
/*  75 */     if (this.customizationValue != null) {
/*     */       
/*     */       try {
/*  78 */         url = new URL(this.customizationValue);
/*  79 */       } catch (MalformedURLException malformedURLException) {
/*     */         
/*  81 */         url = FileLocator.find(this.customizationBundle, (IPath)new Path(this.customizationValue), null);
/*     */       } 
/*     */     }
/*     */     
/*  85 */     if (url == null && 
/*  86 */       InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
/*  87 */       InternalPlatform.message("Product preference customization file: " + this.customizationValue + " not found for bundle: " + this.productID);
/*     */     }
/*     */     
/*  90 */     return loadProperties(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getProductTranslation() {
/*  95 */     initValues();
/*  96 */     URL transURL = null;
/*     */     
/*  98 */     if (this.customizationValue != null) {
/*  99 */       transURL = FileLocator.find(this.customizationBundle, NL_DIR.append(this.customizationValue).removeFileExtension().addFileExtension("properties"), null);
/*     */     }
/* 101 */     if (transURL == null && InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
/* 102 */       InternalPlatform.message("No preference translations found for product/file: " + this.customizationBundle.getSymbolicName() + '/' + this.customizationValue);
/*     */     }
/* 104 */     return loadProperties(transURL);
/*     */   }
/*     */   
/*     */   private Properties loadProperties(URL url) {
/* 108 */     Properties result = new Properties();
/* 109 */     if (url == null)
/* 110 */       return result; 
/* 111 */     InputStream input = null;
/*     */     try {
/* 113 */       input = url.openStream();
/* 114 */       result.load(input);
/* 115 */     } catch (IOException e) {
/* 116 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
/* 117 */         InternalPlatform.message("Problem opening stream to preference customization file: " + url);
/* 118 */         e.printStackTrace();
/*     */       } 
/*     */     } finally {
/* 121 */       if (input != null) {
/*     */         try {
/* 123 */           input.close();
/* 124 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */     
/* 128 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\preferences\legacy\ProductPreferencesService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */