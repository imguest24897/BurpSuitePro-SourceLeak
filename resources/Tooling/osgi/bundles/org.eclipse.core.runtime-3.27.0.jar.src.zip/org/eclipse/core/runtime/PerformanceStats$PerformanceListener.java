package org.eclipse.core.runtime;

public abstract class PerformanceListener {
  public void eventFailed(PerformanceStats event, long duration) {}
  
  public void eventsOccurred(PerformanceStats[] event) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\PerformanceStats$PerformanceListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */