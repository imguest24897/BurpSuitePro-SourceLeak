/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ILog
/*     */ {
/*     */   void addLogListener(ILogListener paramILogListener);
/*     */   
/*     */   Bundle getBundle();
/*     */   
/*     */   void log(IStatus paramIStatus);
/*     */   
/*     */   void removeLogListener(ILogListener paramILogListener);
/*     */   
/*     */   default void info(String message) {
/*  75 */     log((IStatus)new Status(1, getBundle().getSymbolicName(), message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void info(String message, Throwable throwable) {
/*  87 */     log((IStatus)new Status(1, getBundle().getSymbolicName(), message, throwable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void warn(String message) {
/*  98 */     log((IStatus)new Status(2, getBundle().getSymbolicName(), message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void warn(String message, Throwable throwable) {
/* 110 */     log((IStatus)new Status(2, getBundle().getSymbolicName(), message, throwable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void error(String message) {
/* 121 */     log((IStatus)new Status(4, getBundle().getSymbolicName(), message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void error(String message, Throwable throwable) {
/* 133 */     log((IStatus)new Status(4, getBundle().getSymbolicName(), message, throwable));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\ILog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */