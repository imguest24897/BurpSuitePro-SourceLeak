package org.eclipse.core.runtime;

public interface IProductProvider {
  String getName();
  
  IProduct[] getProducts();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\IProductProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */