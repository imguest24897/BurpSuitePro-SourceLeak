package org.eclipse.core.runtime;

import org.osgi.framework.Bundle;

public interface IProduct {
  String getApplication();
  
  String getName();
  
  String getDescription();
  
  String getId();
  
  String getProperty(String paramString);
  
  Bundle getDefiningBundle();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\IProduct.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */