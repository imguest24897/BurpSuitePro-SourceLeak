/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import org.eclipse.core.runtime.ILog;
/*    */ import org.eclipse.core.runtime.Plugin;
/*    */ import org.eclipse.equinox.internal.app.CommandLineArgs;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformActivator
/*    */   extends Plugin
/*    */ {
/*    */   private static BundleContext context;
/*    */   
/*    */   public static BundleContext getContext() {
/* 29 */     return context;
/*    */   }
/*    */ 
/*    */   
/*    */   public void start(BundleContext runtimeContext) throws Exception {
/* 34 */     context = runtimeContext;
/* 35 */     InternalPlatform.getDefault().start(runtimeContext);
/* 36 */     startAppContainer();
/* 37 */     InternalPlatform.getDefault().setRuntimeInstance(this);
/* 38 */     super.start(runtimeContext);
/* 39 */     runtimeContext.registerService(ILog.class, new LogServiceFactory(), null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop(BundleContext runtimeContext) {
/* 45 */     InternalPlatform.getDefault().stop(runtimeContext);
/* 46 */     InternalPlatform.getDefault().setRuntimeInstance(null);
/*    */   }
/*    */ 
/*    */   
/*    */   private void startAppContainer() {
/* 51 */     CommandLineArgs.getApplicationArgs();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\PlatformActivator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */