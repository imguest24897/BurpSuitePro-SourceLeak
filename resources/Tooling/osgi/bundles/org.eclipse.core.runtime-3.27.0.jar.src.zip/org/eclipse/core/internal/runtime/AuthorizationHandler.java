/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ServiceCaller;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationHandler
/*     */ {
/*     */   static final String F_KEYRING = ".keyring";
/*     */   private static long keyringTimeStamp;
/*  35 */   private static String password = "";
/*  36 */   private static String keyringFile = null;
/*     */   
/*  38 */   private static Object keyring = null;
/*     */ 
/*     */   
/*     */   private static Class<?> authClass;
/*     */ 
/*     */   
/*     */   private static boolean authNotAvailableLogged = false;
/*     */ 
/*     */   
/*     */   private static Class<?> getAuthClass() {
/*  48 */     if (authClass == null) {
/*     */       try {
/*  50 */         authClass = Class.forName("org.eclipse.core.internal.runtime.auth.AuthorizationDatabase");
/*  51 */       } catch (ClassNotFoundException e) {
/*  52 */         logAuthNotAvailable(e);
/*     */       } 
/*     */     }
/*  55 */     return authClass;
/*     */   }
/*     */   
/*     */   private static void logAuthNotAvailable(Throwable e) {
/*  59 */     if (authNotAvailableLogged)
/*     */       return; 
/*  61 */     authNotAvailableLogged = true;
/*  62 */     RuntimeLog.log((IStatus)new Status(2, "org.eclipse.core.runtime", 0, Messages.auth_notAvailable, e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean loadKeyring() throws CoreException {
/*  71 */     if (getAuthClass() == null)
/*  72 */       return false; 
/*  73 */     if (keyring != null && (new File(keyringFile)).lastModified() == keyringTimeStamp)
/*  74 */       return true; 
/*  75 */     if (keyringFile == null) {
/*  76 */       boolean found = ServiceCaller.callOnce(AuthorizationHandler.class, Location.class, 
/*  77 */           Location.CONFIGURATION_FILTER, configurationLocation -> {
/*     */             File file = new File(String.valueOf(configurationLocation.getURL().getPath()) + "/org.eclipse.core.runtime");
/*     */             file = new File(file, ".keyring");
/*     */             keyringFile = file.getAbsolutePath();
/*     */           });
/*  82 */       if (!found) {
/*  83 */         return true;
/*     */       }
/*     */     } 
/*     */     try {
/*  87 */       Constructor<?> constructor = authClass.getConstructor(new Class[] { String.class, String.class });
/*  88 */       keyring = constructor.newInstance(new Object[] { keyringFile, password });
/*  89 */     } catch (Exception e) {
/*  90 */       log(e);
/*     */     } 
/*  92 */     if (keyring == null) {
/*     */       
/*  94 */       (new File(keyringFile)).delete();
/*     */       try {
/*  96 */         Constructor<?> constructor = authClass.getConstructor(new Class[] { String.class, String.class });
/*  97 */         keyring = constructor.newInstance(new Object[] { keyringFile, password });
/*  98 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 102 */     keyringTimeStamp = (new File(keyringFile)).lastModified();
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void log(Exception e) throws CoreException {
/* 110 */     if (e instanceof InvocationTargetException) {
/* 111 */       Throwable cause = ((InvocationTargetException)e).getTargetException();
/* 112 */       if (cause instanceof CoreException) {
/* 113 */         throw (CoreException)cause;
/*     */       }
/*     */     } 
/*     */     
/* 117 */     logAuthNotAvailable(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void saveKeyring() throws CoreException {
/*     */     try {
/* 126 */       Method method = authClass.getMethod("save", new Class[0]);
/* 127 */       method.invoke(keyring, new Object[0]);
/* 128 */     } catch (Exception e) {
/* 129 */       log(e);
/*     */     } 
/* 131 */     keyringTimeStamp = (new File(keyringFile)).lastModified();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void addAuthorizationInfo(URL serverUrl, String realm, String authScheme, Map<String, String> info) throws CoreException {
/* 162 */     if (!loadKeyring())
/*     */       return; 
/*     */     try {
/* 165 */       Method method = authClass.getMethod("addAuthorizationInfo", new Class[] { URL.class, String.class, String.class, Map.class });
/* 166 */       method.invoke(keyring, new Object[] { serverUrl, realm, authScheme, new HashMap<>(info) });
/* 167 */     } catch (Exception e) {
/* 168 */       log(e);
/*     */     } 
/* 170 */     saveKeyring();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void addProtectionSpace(URL resourceUrl, String realm) throws CoreException {
/* 192 */     if (!loadKeyring())
/*     */       return; 
/*     */     try {
/* 195 */       Method method = authClass.getMethod("addProtectionSpace", new Class[] { URL.class, String.class });
/* 196 */       method.invoke(keyring, new Object[] { resourceUrl, realm });
/* 197 */     } catch (Exception e) {
/* 198 */       log(e);
/*     */     } 
/* 200 */     saveKeyring();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void flushAuthorizationInfo(URL serverUrl, String realm, String authScheme) throws CoreException {
/* 225 */     if (!loadKeyring())
/*     */       return; 
/*     */     try {
/* 228 */       Method method = authClass.getMethod("flushAuthorizationInfo", new Class[] { URL.class, String.class, String.class });
/* 229 */       method.invoke(keyring, new Object[] { serverUrl, realm, authScheme });
/* 230 */     } catch (Exception e) {
/* 231 */       log(e);
/*     */     } 
/* 233 */     saveKeyring();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized Map<String, String> getAuthorizationInfo(URL serverUrl, String realm, String authScheme) {
/*     */     try {
/* 256 */       if (!loadKeyring())
/* 257 */         return null; 
/*     */       try {
/* 259 */         Method method = authClass.getMethod("getAuthorizationInfo", new Class[] { URL.class, String.class, String.class });
/*     */         
/* 261 */         Map<String, String> info = (Map<String, String>)method.invoke(keyring, new Object[] { serverUrl, realm, authScheme });
/* 262 */         return (info == null) ? null : new HashMap<>(info);
/* 263 */       } catch (Exception e) {
/* 264 */         log(e);
/*     */       } 
/* 266 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String getProtectionSpace(URL resourceUrl) {
/*     */     try {
/* 284 */       if (!loadKeyring())
/* 285 */         return null; 
/*     */       try {
/* 287 */         Method method = authClass.getMethod("getProtectionSpace", new Class[] { URL.class });
/* 288 */         return (String)method.invoke(keyring, new Object[] { resourceUrl });
/* 289 */       } catch (Exception e) {
/* 290 */         log(e);
/*     */       } 
/* 292 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 295 */     return null;
/*     */   }
/*     */   
/*     */   public static void setKeyringFile(String file) {
/* 299 */     if (keyringFile != null)
/* 300 */       throw new IllegalStateException(NLS.bind(Messages.auth_alreadySpecified, keyringFile)); 
/* 301 */     keyringFile = file;
/*     */   }
/*     */   
/*     */   public static void setPassword(String keyringPassword) {
/* 305 */     password = keyringPassword;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\AuthorizationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */