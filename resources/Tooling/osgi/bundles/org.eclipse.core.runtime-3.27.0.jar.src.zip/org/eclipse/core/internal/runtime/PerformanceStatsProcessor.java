/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.PerformanceStats;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerformanceStatsProcessor
/*     */   extends Job
/*     */ {
/*  32 */   private static final PerformanceStatsProcessor instance = new PerformanceStatsProcessor();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long SCHEDULE_DELAY = 2000L;
/*     */ 
/*     */   
/*  39 */   private final ArrayList<PerformanceStats> changes = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private final HashMap<PerformanceStats, Long> failures = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final ListenerList<PerformanceStats.PerformanceListener> listeners = new ListenerList();
/*     */ 
/*     */   
/*     */   private FrameworkLog log;
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addListener(PerformanceStats.PerformanceListener listener) {
/*  58 */     instance.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void changed(PerformanceStats stats) {
/*  67 */     synchronized (instance) {
/*  68 */       instance.changes.add(stats);
/*     */     } 
/*  70 */     instance.schedule(2000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void failed(PerformanceStats stats, String pluginId, long elapsed) {
/*  82 */     synchronized (instance) {
/*  83 */       instance.failures.put(stats, Long.valueOf(elapsed));
/*     */     } 
/*  85 */     instance.schedule(2000L);
/*  86 */     instance.logFailure(stats, pluginId, elapsed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printStats(PrintWriter out) {
/*  94 */     long totalTime = 0L;
/*  95 */     int totalCount = 0;
/*  96 */     PerformanceStats[] allStats = PerformanceStats.getAllStats(); byte b; int i; PerformanceStats[] arrayOfPerformanceStats1;
/*  97 */     for (i = (arrayOfPerformanceStats1 = allStats).length, b = 0; b < i; ) { PerformanceStats stats = arrayOfPerformanceStats1[b];
/*  98 */       totalTime += stats.getRunningTime();
/*  99 */       totalCount += stats.getRunCount();
/*     */       b++; }
/*     */     
/* 102 */     out.println("---------------------------------------------------------------");
/* 103 */     for (i = (arrayOfPerformanceStats1 = allStats).length, b = 0; b < i; ) { PerformanceStats stats = arrayOfPerformanceStats1[b];
/* 104 */       out.print("Event: ");
/* 105 */       out.print(stats.getEvent());
/* 106 */       out.print(" Blame: ");
/* 107 */       out.print(stats.getBlameString());
/* 108 */       if (stats.getContext() != null) {
/* 109 */         out.print(" Context: ");
/* 110 */         out.print(stats.getContext());
/*     */       } 
/* 112 */       out.println();
/*     */       
/* 114 */       int runCount = stats.getRunCount();
/* 115 */       if (runCount > 0) {
/* 116 */         out.print("Run count: ");
/* 117 */         out.print(Integer.toString(runCount));
/* 118 */         out.print(" (");
/* 119 */         out.print(Integer.toString((int)(runCount * 100.0D / totalCount)));
/* 120 */         out.println(" % of total)");
/*     */       } 
/*     */       
/* 123 */       long runTime = stats.getRunningTime();
/* 124 */       if (runTime > 0L) {
/* 125 */         out.print("Duration (ms): ");
/* 126 */         out.print(Long.toString(runTime));
/* 127 */         out.print(" (");
/* 128 */         out.print(Integer.toString((int)(runTime * 100.0D / totalTime)));
/* 129 */         out.println(" % of total)");
/*     */       } 
/* 131 */       out.println("");
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeListener(PerformanceStats.PerformanceListener listener) {
/* 139 */     instance.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PerformanceStatsProcessor() {
/* 146 */     super("Performance Stats");
/* 147 */     setSystem(true);
/* 148 */     setPriority(50);
/* 149 */     BundleContext context = PlatformActivator.getContext();
/* 150 */     String filter = "(performance=" + Boolean.TRUE + ')';
/*     */     
/* 152 */     FrameworkLog perfLog = null;
/*     */     try {
/* 154 */       Collection<ServiceReference<FrameworkLog>> references = context.getServiceReferences(FrameworkLog.class, filter);
/* 155 */       if (references != null && !references.isEmpty()) {
/*     */         
/* 157 */         perfLog = (FrameworkLog)context.getService(references.iterator().next());
/*     */         
/* 159 */         IPath logLocation = Platform.getLogFileLocation();
/* 160 */         logLocation = logLocation.removeLastSegments(1).append("performance.log");
/* 161 */         perfLog.setFile(logLocation.toFile(), false);
/*     */       } 
/* 163 */     } catch (Exception e) {
/* 164 */       Status status = new Status(4, "org.eclipse.core.runtime", 1, "Error loading performance log", e);
/* 165 */       RuntimeLog.log((IStatus)status);
/*     */     } 
/*     */     
/* 168 */     if (perfLog == null)
/* 169 */       perfLog = InternalPlatform.getDefault().getFrameworkLog(); 
/* 170 */     this.log = perfLog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logFailure(PerformanceStats stats, String pluginId, long elapsed) {
/* 178 */     if (this.log == null)
/*     */       return; 
/* 180 */     if (pluginId == null)
/* 181 */       pluginId = "org.eclipse.core.runtime"; 
/* 182 */     String msg = "Performance failure: " + stats.getEvent() + " blame: " + stats.getBlameString() + " context: " + stats.getContext() + " duration: " + elapsed;
/* 183 */     Status status = new Status(2, pluginId, 1, msg, new RuntimeException());
/* 184 */     this.log.log(new FrameworkLogEntry(status, status.getPlugin(), status.getSeverity(), status.getCode(), status.getMessage(), 0, status.getException(), null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*     */     PerformanceStats[] events, failedEvents;
/*     */     Long[] failedTimes;
/* 196 */     synchronized (this) {
/* 197 */       events = this.changes.<PerformanceStats>toArray(new PerformanceStats[this.changes.size()]);
/* 198 */       this.changes.clear();
/* 199 */       failedEvents = (PerformanceStats[])this.failures.keySet().toArray((Object[])new PerformanceStats[this.failures.size()]);
/* 200 */       failedTimes = (Long[])this.failures.values().toArray((Object[])new Long[this.failures.size()]);
/* 201 */       this.failures.clear();
/*     */     } 
/*     */ 
/*     */     
/* 205 */     for (PerformanceStats.PerformanceListener listener : this.listeners) {
/* 206 */       if (events.length > 0)
/* 207 */         listener.eventsOccurred(events); 
/* 208 */       for (int j = 0; j < failedEvents.length; j++)
/* 209 */         listener.eventFailed(failedEvents[j], failedTimes[j].longValue()); 
/*     */     } 
/* 211 */     schedule(2000L);
/* 212 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldRun() {
/* 220 */     return !(this.changes.isEmpty() && this.failures.isEmpty());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\PerformanceStatsProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */