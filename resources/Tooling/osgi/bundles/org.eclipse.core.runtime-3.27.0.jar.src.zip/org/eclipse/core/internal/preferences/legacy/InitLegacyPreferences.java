/*    */ package org.eclipse.core.internal.preferences.legacy;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.eclipse.core.internal.preferences.exchange.ILegacyPreferences;
/*    */ import org.eclipse.core.internal.runtime.InternalPlatform;
/*    */ import org.eclipse.core.internal.runtime.Messages;
/*    */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Plugin;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InitLegacyPreferences
/*    */   implements ILegacyPreferences
/*    */ {
/*    */   @Deprecated
/*    */   public Object init(Object object, String name) {
/* 46 */     Plugin plugin = null;
/* 47 */     if (object instanceof Plugin) {
/* 48 */       plugin = (Plugin)object;
/*    */     } else {
/* 50 */       plugin = getActivator(name);
/* 51 */       if (plugin == null) {
/* 52 */         if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/* 53 */           InternalPlatform.message("No plug-in object available to set plug-in default preference overrides for:" + name); 
/* 54 */         return null;
/*    */       } 
/*    */     } 
/*    */     
/* 58 */     if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
/* 59 */       InternalPlatform.message("Applying plug-in default preference overrides for plug-in: " + plugin.getBundle().getBundleId());
/*    */     }
/* 61 */     plugin.internalInitializeDefaultPluginPreferences();
/* 62 */     return plugin;
/*    */   }
/*    */   
/*    */   private Plugin getActivator(String name) {
/* 66 */     Bundle bundle = InternalPlatform.getDefault().getBundle(name);
/* 67 */     if (bundle == null) {
/* 68 */       return null;
/*    */     }
/* 70 */     BundleContext context = bundle.getBundleContext();
/* 71 */     if (context == null) {
/* 72 */       return null;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 80 */       Field field = context.getClass().getDeclaredField("activator");
/* 81 */       field.setAccessible(true);
/* 82 */       Object activator = field.get(context);
/* 83 */       if (activator instanceof Plugin)
/* 84 */         return (Plugin)activator; 
/* 85 */     } catch (SecurityException|NoSuchFieldException|IllegalArgumentException|IllegalAccessException ex) {
/* 86 */       log(ex, name);
/*    */     } 
/*    */     
/* 89 */     return null;
/*    */   }
/*    */   
/*    */   private static void log(Exception ex, String name) {
/* 93 */     Status status = new Status(4, "org.eclipse.core.runtime", 4, NLS.bind(Messages.plugin_unableToGetActivator, name), ex);
/* 94 */     RuntimeLog.log((IStatus)status);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\preferences\legacy\InitLegacyPreferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */