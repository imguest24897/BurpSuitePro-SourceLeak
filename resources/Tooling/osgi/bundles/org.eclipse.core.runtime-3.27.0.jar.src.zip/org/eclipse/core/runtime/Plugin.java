/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.preferences.legacy.PreferenceForwarder;
/*     */ import org.eclipse.core.internal.runtime.InternalPlatform;
/*     */ import org.eclipse.core.internal.runtime.Messages;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleReference;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Plugin
/*     */   implements BundleActivator
/*     */ {
/*     */   public static final String PLUGIN_PREFERENCE_SCOPE = "instance";
/*     */   private Bundle bundle;
/*     */   private volatile IPath stateLocation;
/*     */   private boolean debug = false;
/* 142 */   private ServiceTracker<DebugOptions, DebugOptions> debugTracker = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREFERENCES_DEFAULT_OVERRIDE_BASE_NAME = "preferences";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREFERENCES_DEFAULT_OVERRIDE_FILE_NAME = "preferences.ini";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 174 */   private Preferences preferences = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final URL find(IPath path) {
/* 209 */     return FileLocator.find(getBundle(), path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final URL find(IPath path, Map<String, String> override) {
/* 228 */     return FileLocator.find(getBundle(), path, override);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ILog getLog() {
/* 239 */     return InternalPlatform.getDefault().getLog(getBundle());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IPath getStateLocation() throws IllegalStateException {
/* 261 */     if (this.stateLocation == null)
/*     */     {
/*     */       
/* 264 */       this.stateLocation = InternalPlatform.getDefault().getStateLocation(getBundle(), true);
/*     */     }
/* 266 */     return this.stateLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final Preferences getPluginPreferences() {
/* 311 */     Bundle bundleCopy = getBundle();
/* 312 */     if (this.preferences != null) {
/* 313 */       if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES)
/* 314 */         InternalPlatform.message("Plugin preferences already loaded for: " + bundleCopy.getSymbolicName()); 
/* 315 */       return this.preferences;
/*     */     } 
/*     */     
/* 318 */     if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
/* 319 */       InternalPlatform.message("Loading preferences for plugin: " + bundleCopy.getSymbolicName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 324 */     Preferences[] preferencesCopy = new Preferences[1];
/* 325 */     Runnable innerCall = () -> paramArrayOfPreferences[0] = (Preferences)new PreferenceForwarder(this, paramBundle.getSymbolicName());
/*     */ 
/*     */     
/* 328 */     innerCall.run();
/* 329 */     this.preferences = preferencesCopy[0];
/* 330 */     return this.preferences;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final void savePluginPreferences() {
/* 347 */     if (InternalPlatform.getDefault().isRunning()) {
/* 348 */       Location instance = InternalPlatform.getDefault().getInstanceLocation();
/* 349 */       if (instance == null || !instance.isSet()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 356 */       getPluginPreferences();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 361 */       Preferences preferencesCopy = this.preferences;
/* 362 */       Runnable innerCall = () -> {
/*     */           try {
/*     */             ((PreferenceForwarder)paramPreferences).flush();
/* 365 */           } catch (BackingStoreException e) {
/*     */             Status status = new Status(4, "org.eclipse.core.runtime", 4, Messages.preferences_saveProblems, (Throwable)e);
/*     */             
/*     */             RuntimeLog.log((IStatus)status);
/*     */           } 
/*     */         };
/* 371 */       innerCall.run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void initializeDefaultPluginPreferences() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final void internalInitializeDefaultPluginPreferences() {
/* 431 */     initializeDefaultPluginPreferences();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugging() {
/* 448 */     Bundle debugBundle = getBundle();
/* 449 */     if (debugBundle == null)
/* 450 */       return this.debug; 
/* 451 */     String key = String.valueOf(debugBundle.getSymbolicName()) + "/debug";
/*     */     
/* 453 */     DebugOptions debugOptions = getDebugOptions();
/* 454 */     if (debugOptions == null) {
/* 455 */       return this.debug;
/*     */     }
/* 457 */     return debugOptions.isDebugEnabled() ? InternalPlatform.getDefault().getBooleanOption(key, false) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final InputStream openStream(IPath file) throws IOException {
/* 473 */     return FileLocator.openStream(getBundle(), file, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final InputStream openStream(IPath file, boolean substituteArgs) throws IOException {
/* 496 */     return FileLocator.openStream(getBundle(), file, substituteArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebugging(boolean value) {
/* 513 */     Bundle debugBundle = getBundle();
/* 514 */     if (debugBundle == null) {
/* 515 */       this.debug = value;
/*     */       return;
/*     */     } 
/* 518 */     String key = String.valueOf(debugBundle.getSymbolicName()) + "/debug";
/* 519 */     DebugOptions options = getDebugOptions();
/* 520 */     if (options == null) {
/* 521 */       this.debug = value;
/*     */     } else {
/* 523 */       if (!options.isDebugEnabled())
/* 524 */         options.setDebugEnabled(true); 
/* 525 */       options.setOption(key, value ? Boolean.TRUE.toString() : Boolean.FALSE.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DebugOptions getDebugOptions() {
/* 536 */     Bundle debugBundle = getBundle();
/* 537 */     if (debugBundle == null)
/* 538 */       return null; 
/* 539 */     if (this.debugTracker == null) {
/* 540 */       BundleContext context = debugBundle.getBundleContext();
/* 541 */       if (context == null)
/* 542 */         return null; 
/* 543 */       this.debugTracker = new ServiceTracker(context, DebugOptions.class.getName(), null);
/* 544 */       this.debugTracker.open();
/*     */     } 
/* 546 */     return (DebugOptions)this.debugTracker.getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void shutdown() throws CoreException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void startup() throws CoreException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 603 */     Bundle myBundle = getBundle();
/* 604 */     if (myBundle == null)
/* 605 */       return ""; 
/* 606 */     String name = myBundle.getSymbolicName();
/* 607 */     return (name == null) ? String.valueOf(myBundle.getBundleId()) : name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/* 653 */     this.bundle = context.getBundle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/* 694 */     if (this.debugTracker != null) {
/* 695 */       this.debugTracker.close();
/* 696 */       this.debugTracker = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Bundle getBundle() {
/* 708 */     if (this.bundle != null)
/* 709 */       return this.bundle; 
/* 710 */     ClassLoader cl = getClass().getClassLoader();
/* 711 */     if (cl instanceof BundleReference)
/* 712 */       return ((BundleReference)cl).getBundle(); 
/* 713 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\Plugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */