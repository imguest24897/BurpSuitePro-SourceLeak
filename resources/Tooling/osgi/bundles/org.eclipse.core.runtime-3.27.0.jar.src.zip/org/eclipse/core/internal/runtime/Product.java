/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProduct;
/*    */ import org.eclipse.equinox.internal.app.IBranding;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Product
/*    */   implements IProduct
/*    */ {
/*    */   IBranding branding;
/*    */   
/*    */   public Product(IBranding branding) {
/* 23 */     this.branding = branding;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getApplication() {
/* 28 */     return this.branding.getApplication();
/*    */   }
/*    */ 
/*    */   
/*    */   public Bundle getDefiningBundle() {
/* 33 */     return this.branding.getDefiningBundle();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 38 */     return this.branding.getDescription();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 43 */     return this.branding.getId();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 48 */     return this.branding.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProperty(String key) {
/* 53 */     return this.branding.getProperty(key);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\Product.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */