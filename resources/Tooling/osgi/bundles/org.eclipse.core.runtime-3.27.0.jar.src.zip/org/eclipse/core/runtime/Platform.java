/*      */ package org.eclipse.core.runtime;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.ResourceBundle;
/*      */ import org.eclipse.core.internal.runtime.AuthorizationHandler;
/*      */ import org.eclipse.core.internal.runtime.InternalPlatform;
/*      */ import org.eclipse.core.internal.runtime.Messages;
/*      */ import org.eclipse.core.internal.runtime.MetaDataKeeper;
/*      */ import org.eclipse.core.internal.runtime.PlatformActivator;
/*      */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*      */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*      */ import org.eclipse.osgi.service.datalocation.Location;
/*      */ import org.eclipse.osgi.service.resolver.PlatformAdmin;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.FrameworkUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Platform
/*      */ {
/*      */   public static final String PI_RUNTIME = "org.eclipse.core.runtime";
/*      */   public static final String PT_APPLICATIONS = "applications";
/*      */   public static final String PT_ADAPTERS = "adapters";
/*      */   public static final String PT_PREFERENCES = "preferences";
/*      */   public static final String PT_PRODUCT = "products";
/*      */   public static final String OPTION_STARTTIME = "org.eclipse.core.runtime/starttime";
/*      */   public static final String PREF_PLATFORM_PERFORMANCE = "runtime.performance";
/*      */   public static final String PREF_LINE_SEPARATOR = "line.separator";
/*      */   public static final int MIN_PERFORMANCE = 1;
/*      */   public static final int MAX_PERFORMANCE = 5;
/*      */   public static final int PARSE_PROBLEM = 1;
/*      */   public static final int PLUGIN_ERROR = 2;
/*      */   public static final int INTERNAL_ERROR = 3;
/*      */   public static final int FAILED_READ_METADATA = 4;
/*      */   public static final int FAILED_WRITE_METADATA = 5;
/*      */   public static final int FAILED_DELETE_METADATA = 6;
/*      */   public static final String OS_WIN32 = "win32";
/*      */   public static final String OS_LINUX = "linux";
/*      */   @Deprecated
/*      */   public static final String OS_AIX = "aix";
/*      */   @Deprecated
/*      */   public static final String OS_SOLARIS = "solaris";
/*      */   @Deprecated
/*      */   public static final String OS_HPUX = "hpux";
/*      */   @Deprecated
/*      */   public static final String OS_QNX = "qnx";
/*      */   public static final String OS_MACOSX = "macosx";
/*      */   public static final String OS_UNKNOWN = "unknown";
/*      */   public static final String ARCH_X86 = "x86";
/*      */   @Deprecated
/*      */   public static final String ARCH_PA_RISC = "PA_RISC";
/*      */   @Deprecated
/*      */   public static final String ARCH_PPC = "ppc";
/*      */   @Deprecated
/*      */   public static final String ARCH_SPARC = "sparc";
/*      */   public static final String ARCH_X86_64 = "x86_64";
/*      */   public static final String ARCH_AARCH64 = "aarch64";
/*      */   @Deprecated
/*      */   public static final String ARCH_AMD64 = "x86_64";
/*      */   @Deprecated
/*      */   public static final String ARCH_IA64 = "ia64";
/*      */   @Deprecated
/*      */   public static final String ARCH_IA64_32 = "ia64_32";
/*      */   public static final String WS_WIN32 = "win32";
/*      */   @Deprecated
/*      */   public static final String WS_MOTIF = "motif";
/*      */   public static final String WS_GTK = "gtk";
/*      */   @Deprecated
/*      */   public static final String WS_PHOTON = "photon";
/*      */   @Deprecated
/*      */   public static final String WS_CARBON = "carbon";
/*      */   public static final String WS_COCOA = "cocoa";
/*      */   public static final String WS_WPF = "wpf";
/*      */   public static final String WS_UNKNOWN = "unknown";
/*  483 */   private static final String LINE_SEPARATOR_KEY_UNIX = Messages.line_separator_platform_unix;
/*  484 */   private static final String LINE_SEPARATOR_KEY_WINDOWS = Messages.line_separator_platform_windows;
/*      */   
/*      */   private static final String LINE_SEPARATOR_VALUE_LF = "\n";
/*      */   private static final String LINE_SEPARATOR_VALUE_CRLF = "\r\n";
/*      */   private static final Charset SYSTEM_CHARSET;
/*      */   
/*      */   static {
/*  491 */     Charset result = null;
/*      */     
/*      */     try {
/*  494 */       String encoding = System.getProperty("native.encoding");
/*  495 */       if (encoding != null && !encoding.isBlank()) {
/*  496 */         result = Charset.forName(encoding);
/*      */       } else {
/*      */         
/*  499 */         encoding = System.getProperty("sun.jnu.encoding");
/*  500 */         if (encoding != null && !encoding.isBlank()) {
/*  501 */           result = Charset.forName(encoding);
/*      */         }
/*      */       } 
/*  504 */     } catch (Exception e) {
/*      */       
/*  506 */       e.printStackTrace();
/*      */     } 
/*  508 */     if (result == null)
/*      */     {
/*  510 */       result = Charset.defaultCharset();
/*      */     }
/*  512 */     SYSTEM_CHARSET = result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addLogListener(ILogListener listener) {
/*  535 */     InternalPlatform.getDefault().addLogListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void addProtectionSpace(URL resourceUrl, String realm) throws CoreException {
/*  562 */     AuthorizationHandler.addProtectionSpace(resourceUrl, realm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static URL asLocalURL(URL url) throws IOException {
/*  588 */     return FileLocator.toFileURL(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void endSplash() {
/*  597 */     InternalPlatform.getDefault().endSplash();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IAdapterManager getAdapterManager() {
/*  609 */     return InternalPlatform.getDefault().getAdapterManager();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getCommandLineArgs() {
/*  626 */     return InternalPlatform.getDefault().getCommandLineArgs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IContentTypeManager getContentTypeManager() {
/*  638 */     return InternalPlatform.getDefault().getContentTypeManager();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDebugOption(String option) {
/*  654 */     return InternalPlatform.getDefault().getOption(option);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getDebugBoolean(String option) {
/*  679 */     return "true".equalsIgnoreCase(InternalPlatform.getDefault().getOption(option));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath getLocation() throws IllegalStateException {
/*  699 */     return InternalPlatform.getDefault().getLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath getLogFileLocation() {
/*  718 */     return MetaDataKeeper.getMetaArea().getLogLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Plugin getPlugin(String id) {
/*  728 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeLogListener(ILogListener listener) {
/*  741 */     InternalPlatform.getDefault().removeLogListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static URL resolve(URL url) throws IOException {
/*  769 */     return FileLocator.resolve(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void run(ISafeRunnable runnable) {
/*  782 */     SafeRunner.run(runnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IExtensionRegistry getExtensionRegistry() {
/*  796 */     return RegistryFactory.getRegistry();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static URL find(Bundle bundle, IPath path) {
/*  815 */     return FileLocator.find(bundle, path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static URL find(Bundle bundle, IPath path, Map<String, String> override) {
/*  877 */     return FileLocator.find(bundle, path, override);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath getStateLocation(Bundle bundle) {
/*  899 */     return InternalPlatform.getDefault().getStateLocation(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getStateStamp() {
/*  914 */     return InternalPlatform.getDefault().getStateTimeStamp();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ILog getLog(Bundle bundle) {
/*  925 */     return InternalPlatform.getDefault().getLog(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ILog getLog(Class<?> clazz) {
/*  938 */     Bundle bundle = FrameworkUtil.getBundle(clazz);
/*  939 */     return InternalPlatform.getDefault().getLog(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ResourceBundle getResourceBundle(Bundle bundle) throws MissingResourceException {
/*  961 */     return InternalPlatform.getDefault().getResourceBundle(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getResourceString(Bundle bundle, String value) {
/*  988 */     return InternalPlatform.getDefault().getResourceString(bundle, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getResourceString(Bundle bundle, String value, ResourceBundle resourceBundle) {
/* 1024 */     return InternalPlatform.getDefault().getResourceString(bundle, value, resourceBundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getOSArch() {
/* 1040 */     return InternalPlatform.getDefault().getOSArch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getNL() {
/* 1054 */     return InternalPlatform.getDefault().getNL();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getNLExtensions() {
/* 1068 */     return InternalPlatform.getDefault().getNLExtensions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getOS() {
/* 1086 */     return InternalPlatform.getDefault().getOS();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getWS() {
/* 1101 */     return InternalPlatform.getDefault().getWS();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getApplicationArgs() {
/* 1113 */     return InternalPlatform.getDefault().getApplicationArgs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PlatformAdmin getPlatformAdmin() {
/* 1134 */     return InternalPlatform.getDefault().getPlatformAdmin();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Location getInstanceLocation() {
/* 1149 */     return InternalPlatform.getDefault().getInstanceLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IBundleGroupProvider[] getBundleGroupProviders() {
/* 1162 */     return InternalPlatform.getDefault().getBundleGroupProviders();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPreferencesService getPreferencesService() {
/* 1177 */     return InternalPlatform.getDefault().getPreferencesService();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IProduct getProduct() {
/* 1187 */     return InternalPlatform.getDefault().getProduct();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerBundleGroupProvider(IBundleGroupProvider provider) {
/* 1200 */     InternalPlatform.getDefault().registerBundleGroupProvider(provider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unregisterBundleGroupProvider(IBundleGroupProvider provider) {
/* 1214 */     InternalPlatform.getDefault().unregisterBundleGroupProvider(provider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Location getConfigurationLocation() {
/* 1233 */     return InternalPlatform.getDefault().getConfigurationLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Location getUserLocation() {
/* 1250 */     return InternalPlatform.getDefault().getUserLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Location getInstallLocation() {
/* 1265 */     return InternalPlatform.getDefault().getInstallLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFragment(Bundle bundle) {
/* 1283 */     return InternalPlatform.getDefault().isFragment(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bundle[] getFragments(Bundle bundle) {
/* 1303 */     return InternalPlatform.getDefault().getFragments(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bundle getBundle(String symbolicName) {
/* 1336 */     return InternalPlatform.getDefault().getBundle(symbolicName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bundle[] getBundles(String symbolicName, String version) {
/* 1362 */     return InternalPlatform.getDefault().getBundles(symbolicName, version);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bundle[] getHosts(Bundle bundle) {
/* 1382 */     return InternalPlatform.getDefault().getHosts(bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isRunning() {
/* 1393 */     return InternalPlatform.getDefault().isRunning();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] knownOSArchValues() {
/* 1410 */     return InternalPlatform.getDefault().knownOSArchValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] knownOSValues() {
/* 1427 */     return InternalPlatform.getDefault().knownOSValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, String> knownPlatformLineSeparators() {
/* 1439 */     Map<String, String> result = new LinkedHashMap<>(5);
/* 1440 */     result.put(LINE_SEPARATOR_KEY_WINDOWS, "\r\n");
/* 1441 */     result.put(LINE_SEPARATOR_KEY_UNIX, "\n");
/* 1442 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] knownWSValues() {
/* 1459 */     return InternalPlatform.getDefault().knownWSValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean inDebugMode() {
/* 1474 */     return (PlatformActivator.getContext().getProperty("osgi.debug") != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean inDevelopmentMode() {
/* 1490 */     return (PlatformActivator.getContext().getProperty("osgi.dev") != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Charset getSystemCharset() {
/* 1515 */     return SYSTEM_CHARSET;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\Platform.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */