/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.ILogListener;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.equinox.log.LogFilter;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.eclipse.equinox.log.SynchronousLogListener;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log
/*     */   implements ILog, SynchronousLogListener, LogFilter
/*     */ {
/*     */   final Bundle bundle;
/*     */   private final Logger logger;
/*  29 */   private final Set<ILogListener> logListeners = new HashSet<>(5);
/*     */   
/*     */   public Log(Bundle plugin, Logger logger) {
/*  32 */     if (plugin == null)
/*  33 */       throw new IllegalArgumentException("Logging bundle must not be null."); 
/*  34 */     this.bundle = plugin;
/*  35 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLogListener(ILogListener listener) {
/*  46 */     synchronized (this.logListeners) {
/*  47 */       this.logListeners.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/*  56 */     return this.bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(IStatus status) {
/*  68 */     this.logger.log(PlatformLogWriter.getLog(status), PlatformLogWriter.getLevel(status), status.getMessage(), status.getException());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLogListener(ILogListener listener) {
/*  79 */     synchronized (this.logListeners) {
/*  80 */       this.logListeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void logged(LogEntry entry) {
/*  86 */     logToListeners(PlatformLogWriter.convertToStatus(entry));
/*     */   }
/*     */ 
/*     */   
/*     */   private void logToListeners(final IStatus status) {
/*     */     ILogListener[] listeners;
/*  92 */     synchronized (this.logListeners) {
/*  93 */       listeners = this.logListeners.<ILogListener>toArray(new ILogListener[this.logListeners.size()]);
/*     */     }  byte b; int i; ILogListener[] arrayOfILogListener1;
/*  95 */     for (i = (arrayOfILogListener1 = listeners).length, b = 0; b < i; ) { final ILogListener listener = arrayOfILogListener1[b];
/*  96 */       ISafeRunnable code = new ISafeRunnable()
/*     */         {
/*     */           public void run() throws Exception {
/*  99 */             listener.logging(status, Log.this.bundle.getSymbolicName());
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void handleException(Throwable e) {}
/*     */         };
/* 107 */       SafeRunner.run(code);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isLoggable(Bundle loggingBundle, String loggerName, int logLevel) {
/* 113 */     return ("org.eclipse.equinox.logger".equals(loggerName) && this.bundle.getBundleId() == loggingBundle.getBundleId());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\Log.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */