/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import org.eclipse.core.runtime.ILog;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogServiceFactory
/*    */   implements ServiceFactory<ILog>
/*    */ {
/*    */   public ILog getService(Bundle bundle, ServiceRegistration<ILog> registration) {
/* 26 */     return InternalPlatform.getDefault().getLog(bundle);
/*    */   }
/*    */   
/*    */   public void ungetService(Bundle bundle, ServiceRegistration<ILog> registration, ILog service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\LogServiceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */