/*     */ package org.eclipse.core.internal.runtime;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.stream.Stream;
/*     */ import org.eclipse.core.internal.preferences.exchange.ILegacyPreferences;
/*     */ import org.eclipse.core.internal.preferences.exchange.IProductPreferencesService;
/*     */ import org.eclipse.core.runtime.IAdapterManager;
/*     */ import org.eclipse.core.runtime.IBundleGroupProvider;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.ILogListener;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProduct;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*     */ import org.eclipse.equinox.app.IApplicationContext;
/*     */ import org.eclipse.equinox.internal.app.Activator;
/*     */ import org.eclipse.equinox.internal.app.CommandLineArgs;
/*     */ import org.eclipse.equinox.internal.app.EclipseAppContainer;
/*     */ import org.eclipse.equinox.internal.app.IBranding;
/*     */ import org.eclipse.equinox.log.ExtendedLogReaderService;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*     */ import org.eclipse.osgi.service.resolver.PlatformAdmin;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.VersionRange;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleRevisions;
/*     */ import org.osgi.framework.wiring.BundleWire;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.framework.wiring.FrameworkWiring;
/*     */ import org.osgi.service.log.LogListener;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ public final class InternalPlatform {
/*  55 */   private static final String[] ARCH_LIST = new String[] { "aarch64", "x86", "x86_64" };
/*     */   
/*     */   public static boolean DEBUG = false;
/*     */   
/*     */   public static boolean DEBUG_PLUGIN_PREFERENCES = false;
/*     */   
/*     */   private boolean splashEnded = false;
/*     */   
/*     */   private volatile boolean initialized;
/*     */   private static final String KEYRING = "-keyring";
/*     */   private String keyringFile;
/*  66 */   private ConcurrentMap<Bundle, Log> logs = new ConcurrentHashMap<>(5);
/*     */   
/*  68 */   private static final String[] OS_LIST = new String[] { "linux", "macosx", "win32" };
/*  69 */   private String password = "";
/*     */   
/*     */   private static final String PASSWORD = "-password";
/*     */   
/*     */   public static final String PROP_APPLICATION = "eclipse.application";
/*     */   
/*     */   public static final String PROP_ARCH = "osgi.arch";
/*     */   
/*     */   public static final String PROP_CONFIG_AREA = "osgi.configuration.area";
/*     */   
/*     */   public static final String PROP_CONSOLE_LOG = "eclipse.consoleLog";
/*     */   
/*     */   public static final String PROP_DEBUG = "osgi.debug";
/*     */   
/*     */   public static final String PROP_DEV = "osgi.dev";
/*     */   
/*     */   public static final String PROP_INSTALL_AREA = "osgi.install.area";
/*     */   public static final String PROP_NL = "osgi.nl";
/*     */   public static final String PROP_OS = "osgi.os";
/*     */   private static final String PROP_REQUIRES_EXPLICIT_INIT = "osgi.dataAreaRequiresExplicitInit";
/*     */   public static final String PROP_PRODUCT = "eclipse.product";
/*     */   public static final String PROP_WS = "osgi.ws";
/*     */   public static final String PROP_ACTIVATE_PLUGINS = "eclipse.activateRuntimePlugins";
/*  92 */   private static final InternalPlatform singleton = new InternalPlatform();
/*     */   
/*  94 */   private static final String[] WS_LIST = new String[] { "cocoa", "gtk", "win32", "wpf" };
/*     */   private Path cachedInstanceLocation;
/*  96 */   private ServiceTracker<Location, Location> configurationLocation = null;
/*     */   
/*     */   private BundleContext context;
/*     */   private FrameworkWiring fwkWiring;
/* 100 */   private Map<IBundleGroupProvider, ServiceRegistration<IBundleGroupProvider>> groupProviders = new HashMap<>(3);
/* 101 */   private ServiceTracker<Location, Location> installLocation = null;
/* 102 */   private ServiceTracker<Location, Location> instanceLocation = null;
/* 103 */   private ServiceTracker<Location, Location> userLocation = null;
/*     */   
/*     */   private Plugin runtimeInstance;
/*     */   
/* 107 */   private ServiceRegistration<ILegacyPreferences> legacyPreferencesService = null;
/* 108 */   private ServiceRegistration<IProductPreferencesService> customPreferencesService = null;
/*     */   
/* 110 */   private ServiceTracker<EnvironmentInfo, EnvironmentInfo> environmentTracker = null;
/* 111 */   private ServiceTracker<FrameworkLog, FrameworkLog> logTracker = null;
/* 112 */   private ServiceTracker<PlatformAdmin, PlatformAdmin> platformTracker = null;
/* 113 */   private ServiceTracker<DebugOptions, DebugOptions> debugTracker = null;
/* 114 */   private ServiceTracker<IContentTypeManager, IContentTypeManager> contentTracker = null;
/* 115 */   private ServiceTracker<IPreferencesService, IPreferencesService> preferencesTracker = null;
/* 116 */   private ServiceTracker<IBundleGroupProvider, IBundleGroupProvider> groupProviderTracker = null;
/* 117 */   private ServiceTracker<ExtendedLogReaderService, ExtendedLogReaderService> logReaderTracker = null;
/* 118 */   private ServiceTracker<ExtendedLogService, ExtendedLogService> extendedLogTracker = null;
/*     */   
/*     */   private IProduct product;
/*     */   
/*     */   public static InternalPlatform getDefault() {
/* 123 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLogListener(ILogListener listener) {
/* 137 */     assertInitialized();
/* 138 */     RuntimeLog.addLogListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   private void assertInitialized() {
/* 143 */     if (!this.initialized) {
/* 144 */       Assert.isTrue(false, Messages.meta_appNotInit);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endSplash() {
/* 151 */     synchronized (this) {
/* 152 */       if (this.splashEnded)
/*     */         return; 
/* 154 */       this.splashEnded = true;
/*     */     } 
/*     */     
/* 157 */     ServiceCaller.callOnce(InternalPlatform.class, IApplicationContext.class, 
/* 158 */         "(eclipse.application.type=main.thread)", IApplicationContext::applicationRunning);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAdapterManager getAdapterManager() {
/* 165 */     assertInitialized();
/* 166 */     return (IAdapterManager)AdapterManager.getDefault();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getApplicationArgs() {
/* 173 */     return CommandLineArgs.getApplicationArgs();
/*     */   }
/*     */   
/*     */   public boolean getBooleanOption(String option, boolean defaultValue) {
/* 177 */     String value = getOption(option);
/* 178 */     return (value == null) ? defaultValue : Boolean.parseBoolean(value);
/*     */   }
/*     */   
/*     */   public BundleContext getBundleContext() {
/* 182 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBundleId(Object object) {
/* 190 */     if (object == null)
/* 191 */       return null; 
/* 192 */     Bundle source = FrameworkUtil.getBundle(object.getClass());
/* 193 */     if (source != null && source.getSymbolicName() != null) {
/* 194 */       return source.getSymbolicName();
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */   
/*     */   public IBundleGroupProvider[] getBundleGroupProviders() {
/* 200 */     return (IBundleGroupProvider[])this.groupProviderTracker.getServices((Object[])new IBundleGroupProvider[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBundleGroupProvider(IBundleGroupProvider provider) {
/* 205 */     ServiceRegistration<IBundleGroupProvider> registration = getBundleContext().registerService(IBundleGroupProvider.class, provider, null);
/*     */     
/* 207 */     synchronized (this.groupProviders) {
/* 208 */       this.groupProviders.put(provider, registration);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void unregisterBundleGroupProvider(IBundleGroupProvider provider) {
/*     */     ServiceRegistration<IBundleGroupProvider> registration;
/* 215 */     synchronized (this.groupProviders) {
/* 216 */       registration = this.groupProviders.remove(provider);
/*     */     } 
/* 218 */     if (registration == null) {
/*     */       return;
/*     */     }
/* 221 */     registration.unregister();
/*     */   }
/*     */   
/*     */   public Bundle getBundle(String symbolicName) {
/* 225 */     Stream<Bundle> bundles = getBundles0(symbolicName, null);
/* 226 */     return bundles.findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Bundle[] getBundles(String symbolicName, String versionRange) {
/* 230 */     Stream<Bundle> result = getBundles0(symbolicName, versionRange);
/* 231 */     Bundle[] results = result.<Bundle>toArray(paramInt -> new Bundle[paramInt]);
/* 232 */     return (results.length > 0) ? results : null;
/*     */   }
/*     */   
/* 235 */   static final Comparator<Bundle> DESCENDING_BUNDLE_VERION = Comparator.<Bundle, Comparable>comparing(Bundle::getVersion).reversed();
/*     */   
/*     */   private Stream<Bundle> getBundles0(String symbolicName, String versionRange) {
/* 238 */     if (!isRunning()) {
/* 239 */       return Stream.empty();
/*     */     }
/* 241 */     if ("system.bundle".equals(symbolicName)) {
/* 242 */       symbolicName = this.context.getBundle("System Bundle").getSymbolicName();
/*     */     }
/* 244 */     Map<String, String> directives = Map.of("filter", 
/* 245 */         getRequirementFilter(symbolicName, versionRange));
/* 246 */     Collection<BundleCapability> matchingBundleCapabilities = this.fwkWiring.findProviders(
/* 247 */         ModuleContainer.createRequirement("osgi.identity", directives, Collections.emptyMap()));
/*     */     
/* 249 */     return matchingBundleCapabilities.stream().map(c -> c.getRevision().getBundle())
/*     */       
/* 251 */       .filter(bundle -> ((bundle.getState() & 0x3) == 0))
/* 252 */       .sorted(DESCENDING_BUNDLE_VERION);
/*     */   }
/*     */   
/*     */   private String getRequirementFilter(String symbolicName, String versionRange) {
/* 256 */     String identity = "(osgi.identity=" + symbolicName + ")";
/* 257 */     if (versionRange == null) {
/* 258 */       return identity;
/*     */     }
/* 260 */     String version = (new VersionRange(versionRange)).toFilterString("version");
/* 261 */     return "(&" + identity + version + ")";
/*     */   }
/*     */   
/*     */   public String[] getCommandLineArgs() {
/* 265 */     return CommandLineArgs.getAllArgs();
/*     */   }
/*     */   
/*     */   public Location getConfigurationLocation() {
/* 269 */     assertInitialized();
/* 270 */     return (Location)this.configurationLocation.getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentTypeManager getContentTypeManager() {
/* 277 */     return (this.contentTracker == null) ? null : (IContentTypeManager)this.contentTracker.getService();
/*     */   }
/*     */   
/*     */   public EnvironmentInfo getEnvironmentInfoService() {
/* 281 */     return (this.environmentTracker == null) ? null : (EnvironmentInfo)this.environmentTracker.getService();
/*     */   }
/*     */   
/*     */   public FrameworkLog getFrameworkLog() {
/* 285 */     return (this.logTracker == null) ? null : (FrameworkLog)this.logTracker.getService();
/*     */   }
/*     */   
/*     */   public Bundle[] getFragments(Bundle bundle) {
/* 289 */     BundleWiring wiring = (BundleWiring)bundle.adapt(BundleWiring.class);
/* 290 */     if (wiring == null) {
/* 291 */       return null;
/*     */     }
/* 293 */     List<BundleWire> hostWires = wiring.getProvidedWires("osgi.wiring.host");
/* 294 */     if (hostWires == null)
/*     */     {
/* 296 */       return null;
/*     */     }
/* 298 */     Bundle[] result = (Bundle[])hostWires.stream().map(wire -> wire.getRequirer().getBundle()).filter(Objects::nonNull)
/* 299 */       .toArray(paramInt -> new Bundle[paramInt]);
/* 300 */     return (result.length > 0) ? result : null;
/*     */   }
/*     */   
/*     */   public Bundle[] getHosts(Bundle bundle) {
/* 304 */     BundleWiring wiring = (BundleWiring)bundle.adapt(BundleWiring.class);
/* 305 */     if (wiring == null) {
/* 306 */       return null;
/*     */     }
/* 308 */     List<BundleWire> hostWires = wiring.getRequiredWires("osgi.wiring.host");
/* 309 */     if (hostWires == null)
/*     */     {
/* 311 */       return null;
/*     */     }
/* 313 */     Bundle[] result = (Bundle[])hostWires.stream().map(wire -> wire.getProvider().getBundle()).filter(Objects::nonNull)
/* 314 */       .toArray(paramInt -> new Bundle[paramInt]);
/* 315 */     return (result.length > 0) ? result : null;
/*     */   }
/*     */   
/*     */   public Location getInstallLocation() {
/* 319 */     assertInitialized();
/* 320 */     return (Location)this.installLocation.getService();
/*     */   }
/*     */   
/*     */   public URL getInstallURL() {
/* 324 */     Location location = getInstallLocation();
/*     */ 
/*     */     
/* 327 */     if (location == null)
/* 328 */       throw new IllegalStateException("The installation location must not be null"); 
/* 329 */     return location.getURL();
/*     */   }
/*     */   
/*     */   public Location getInstanceLocation() {
/* 333 */     assertInitialized();
/* 334 */     return (Location)this.instanceLocation.getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getLocation() throws IllegalStateException {
/* 341 */     if (this.cachedInstanceLocation == null) {
/* 342 */       Location location = getInstanceLocation();
/* 343 */       if (location == null) {
/* 344 */         return null;
/*     */       }
/* 346 */       if (!location.isSet()) {
/* 347 */         boolean explicitInitRequired = 
/* 348 */           Boolean.parseBoolean(getBundleContext().getProperty("osgi.dataAreaRequiresExplicitInit"));
/* 349 */         if (explicitInitRequired)
/*     */         {
/*     */           
/* 352 */           throw new IllegalStateException(CommonMessages.meta_instanceDataUnspecified);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 358 */       URL url = location.getURL();
/* 359 */       if (url == null) {
/* 360 */         throw new IllegalStateException("Instance location is not (yet) set");
/*     */       }
/*     */       
/* 363 */       File file = new File(url.getFile());
/* 364 */       this.cachedInstanceLocation = new Path(file.toString());
/*     */     } 
/* 366 */     return (IPath)this.cachedInstanceLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILog getLog(Bundle bundle) {
/* 377 */     if (isRunning()) {
/* 378 */       return this.logs.computeIfAbsent(bundle, b -> {
/*     */             ExtendedLogService logService = (ExtendedLogService)this.extendedLogTracker.getService();
/*     */             
/*     */             Logger logger = (logService != null) ? logService.getLogger(b, "org.eclipse.equinox.logger") : null;
/*     */             Log log = new Log(b, logger);
/*     */             ExtendedLogReaderService logReader = (ExtendedLogReaderService)this.logReaderTracker.getService();
/*     */             if (logReader != null) {
/*     */               logReader.addLogListener((LogListener)log, log);
/*     */             }
/*     */             return log;
/*     */           });
/*     */     }
/* 390 */     return new Log(bundle, null);
/*     */   }
/*     */   
/*     */   public String getNL() {
/* 394 */     return getBundleContext().getProperty("osgi.nl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNLExtensions() {
/* 402 */     String nlExtensions = PlatformActivator.getContext().getProperty("osgi.nl.extensions");
/* 403 */     if (nlExtensions == null)
/* 404 */       return ""; 
/* 405 */     if (!nlExtensions.startsWith("@"))
/* 406 */       nlExtensions = String.valueOf('@') + nlExtensions; 
/* 407 */     return nlExtensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOption(String option) {
/* 414 */     DebugOptions options = getDebugOptions();
/* 415 */     if (options != null)
/* 416 */       return options.getOption(option); 
/* 417 */     return null;
/*     */   }
/*     */   
/*     */   public String getOS() {
/* 421 */     return getBundleContext().getProperty("osgi.os");
/*     */   }
/*     */   
/*     */   public String getOSArch() {
/* 425 */     return getBundleContext().getProperty("osgi.arch");
/*     */   }
/*     */   
/*     */   public PlatformAdmin getPlatformAdmin() {
/* 429 */     return (this.platformTracker == null) ? null : (PlatformAdmin)this.platformTracker.getService();
/*     */   }
/*     */ 
/*     */   
/*     */   public IPreferencesService getPreferencesService() {
/* 434 */     return (this.preferencesTracker == null) ? null : (IPreferencesService)this.preferencesTracker.getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProduct getProduct() {
/* 441 */     if (this.product != null)
/* 442 */       return this.product; 
/* 443 */     EclipseAppContainer container = Activator.getContainer();
/* 444 */     IBranding branding = (container == null) ? null : container.getBranding();
/* 445 */     if (branding == null)
/* 446 */       return null; 
/* 447 */     Object brandingProduct = branding.getProduct();
/* 448 */     if (!(brandingProduct instanceof IProduct))
/* 449 */       brandingProduct = new Product(branding); 
/* 450 */     this.product = (IProduct)brandingProduct;
/* 451 */     return this.product;
/*     */   }
/*     */   
/*     */   public IExtensionRegistry getRegistry() {
/* 455 */     return RegistryFactory.getRegistry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getResourceBundle(Bundle bundle) {
/* 462 */     return ResourceTranslator.getResourceBundle(bundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResourceString(Bundle bundle, String value) {
/* 469 */     return ResourceTranslator.getResourceString(bundle, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResourceString(Bundle bundle, String value, ResourceBundle resourceBundle) {
/* 476 */     return ResourceTranslator.getResourceString(bundle, value, resourceBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Plugin getRuntimeInstance() {
/* 483 */     return this.runtimeInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getStateLocation(Bundle bundle) {
/* 490 */     return getStateLocation(bundle, true);
/*     */   }
/*     */   
/*     */   public IPath getStateLocation(Bundle bundle, boolean create) throws IllegalStateException {
/* 494 */     assertInitialized();
/* 495 */     IPath result = MetaDataKeeper.getMetaArea().getStateLocation(bundle);
/* 496 */     if (create)
/* 497 */       result.toFile().mkdirs(); 
/* 498 */     return result;
/*     */   }
/*     */   
/*     */   public long getStateTimeStamp() {
/* 502 */     PlatformAdmin admin = getPlatformAdmin();
/* 503 */     return (admin == null) ? -1L : admin.getState(false).getTimeStamp();
/*     */   }
/*     */   
/*     */   public Location getUserLocation() {
/* 507 */     assertInitialized();
/* 508 */     return (Location)this.userLocation.getService();
/*     */   }
/*     */   
/*     */   public String getWS() {
/* 512 */     return getBundleContext().getProperty("osgi.ws");
/*     */   }
/*     */   
/*     */   private void initializeAuthorizationHandler() {
/*     */     try {
/* 517 */       AuthorizationHandler.setKeyringFile(this.keyringFile);
/* 518 */       AuthorizationHandler.setPassword(this.password);
/* 519 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initializeDebugFlags() {
/* 529 */     DEBUG = getBooleanOption("org.eclipse.core.runtime/debug", false);
/* 530 */     if (DEBUG) {
/* 531 */       DEBUG_PLUGIN_PREFERENCES = getBooleanOption("org.eclipse.core.runtime/preferences/plugin", false);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFragment(Bundle bundle) {
/* 536 */     BundleRevisions bundleRevisions = (BundleRevisions)bundle.adapt(BundleRevisions.class);
/* 537 */     List<BundleRevision> revisions = bundleRevisions.getRevisions();
/* 538 */     if (revisions.isEmpty())
/*     */     {
/* 540 */       return false;
/*     */     }
/* 542 */     return ((((BundleRevision)revisions.get(0)).getTypes() & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/*     */     try {
/* 550 */       return (this.initialized && this.context != null && this.context.getBundle().getState() == 32);
/* 551 */     } catch (IllegalStateException illegalStateException) {
/* 552 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] knownOSArchValues() {
/* 563 */     return ARCH_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] knownOSValues() {
/* 573 */     return OS_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] knownWSValues() {
/* 583 */     return WS_LIST;
/*     */   }
/*     */   
/*     */   private void processCommandLine(String[] args) {
/* 587 */     if (args == null || args.length == 0) {
/*     */       return;
/*     */     }
/* 590 */     for (int i = 0; i < args.length; i++) {
/*     */       
/* 592 */       if (i != args.length - 1 && !args[i + 1].startsWith("-")) {
/*     */         
/* 594 */         String arg = args[++i];
/*     */ 
/*     */         
/* 597 */         if (args[i - 1].equalsIgnoreCase("-keyring")) {
/* 598 */           this.keyringFile = arg;
/*     */         }
/* 600 */         if (args[i - 1].equalsIgnoreCase("-password")) {
/* 601 */           this.password = arg;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeLogListener(ILogListener listener) {
/* 609 */     assertInitialized();
/* 610 */     RuntimeLog.removeLogListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRuntimeInstance(Plugin runtime) {
/* 617 */     this.runtimeInstance = runtime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext runtimeContext) {
/* 627 */     this.context = runtimeContext;
/* 628 */     this.fwkWiring = (FrameworkWiring)runtimeContext.getBundle("System Bundle").adapt(FrameworkWiring.class);
/* 629 */     openOSGiTrackers();
/* 630 */     this.splashEnded = false;
/* 631 */     processCommandLine(getEnvironmentInfoService().getNonFrameworkArgs());
/* 632 */     initializeDebugFlags();
/* 633 */     this.initialized = true;
/* 634 */     initializeAuthorizationHandler();
/* 635 */     startServices();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext bundleContext) {
/* 644 */     assertInitialized();
/* 645 */     stopServices();
/* 646 */     this.initialized = false;
/* 647 */     closeOSGITrackers();
/* 648 */     this.context = null;
/*     */   }
/*     */   
/*     */   private void openOSGiTrackers() {
/* 652 */     this.instanceLocation = createOpenTracker(Location.INSTANCE_FILTER);
/* 653 */     this.userLocation = createOpenTracker(Location.USER_FILTER);
/* 654 */     this.configurationLocation = createOpenTracker(Location.CONFIGURATION_FILTER);
/* 655 */     this.installLocation = createOpenTracker(Location.INSTALL_FILTER);
/* 656 */     this.logTracker = createOpenTracker(FrameworkLog.class);
/* 657 */     this.platformTracker = createOpenTracker(PlatformAdmin.class);
/* 658 */     this.contentTracker = createOpenTracker(IContentTypeManager.class);
/* 659 */     this.preferencesTracker = createOpenTracker(IPreferencesService.class);
/* 660 */     this.groupProviderTracker = createOpenTracker("(objectClass=" + IBundleGroupProvider.class.getName() + ")");
/* 661 */     this.logReaderTracker = createOpenTracker(ExtendedLogReaderService.class);
/* 662 */     this.extendedLogTracker = createOpenTracker(ExtendedLogService.class);
/* 663 */     this.environmentTracker = createOpenTracker(EnvironmentInfo.class);
/* 664 */     this.debugTracker = createOpenTracker(DebugOptions.class);
/*     */   }
/*     */   
/*     */   private <T> ServiceTracker<T, T> createOpenTracker(String filterStr) {
/*     */     try {
/* 669 */       Filter filter = FrameworkUtil.createFilter(filterStr);
/* 670 */       ServiceTracker<T, T> tracker = new ServiceTracker(this.context, filter, null);
/* 671 */       tracker.open();
/* 672 */       return tracker;
/* 673 */     } catch (InvalidSyntaxException invalidSyntaxException) {
/*     */       
/* 675 */       throw new AssertionError("Invalid service tracker filter");
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> ServiceTracker<T, T> createOpenTracker(Class<T> service) {
/* 680 */     ServiceTracker<T, T> tracker = new ServiceTracker(this.context, service, null);
/* 681 */     tracker.open();
/* 682 */     return tracker;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void startServices() {
/* 688 */     this.customPreferencesService = this.context.registerService(IProductPreferencesService.class, new ProductPreferencesService(), new Hashtable<>());
/*     */     
/* 690 */     this.legacyPreferencesService = this.context.registerService(ILegacyPreferences.class, new InitLegacyPreferences(), new Hashtable<>());
/*     */   }
/*     */   
/*     */   private void stopServices() {
/* 694 */     if (this.legacyPreferencesService != null) {
/* 695 */       this.legacyPreferencesService.unregister();
/* 696 */       this.legacyPreferencesService = null;
/*     */     } 
/* 698 */     if (this.customPreferencesService != null) {
/* 699 */       this.customPreferencesService.unregister();
/* 700 */       this.customPreferencesService = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private DebugOptions getDebugOptions() {
/* 705 */     return (this.debugTracker == null) ? null : (DebugOptions)this.debugTracker.getService();
/*     */   }
/*     */   
/*     */   private void closeOSGITrackers() {
/* 709 */     ExtendedLogReaderService logReader = (ExtendedLogReaderService)this.logReaderTracker.getService();
/* 710 */     if (logReader != null) {
/* 711 */       this.logs.forEach((b, log) -> paramExtendedLogReaderService.removeLogListener((LogListener)log));
/*     */     }
/* 713 */     this.logs.clear();
/* 714 */     closeTracker(this.preferencesTracker);
/* 715 */     closeTracker(this.contentTracker);
/* 716 */     closeTracker(this.debugTracker);
/* 717 */     closeTracker(this.platformTracker);
/* 718 */     closeTracker(this.logTracker);
/* 719 */     closeTracker(this.groupProviderTracker);
/* 720 */     closeTracker(this.environmentTracker);
/* 721 */     closeTracker(this.logReaderTracker);
/* 722 */     closeTracker(this.extendedLogTracker);
/* 723 */     closeTracker(this.installLocation);
/* 724 */     closeTracker(this.userLocation);
/* 725 */     closeTracker(this.configurationLocation);
/* 726 */     closeTracker(this.instanceLocation);
/*     */   }
/*     */   
/*     */   private static void closeTracker(ServiceTracker<?, ?> tracker) {
/* 730 */     if (tracker != null) {
/* 731 */       tracker.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void message(String message) {
/* 740 */     System.out.println(String.format("%s - [%s] %s", new Object[] { new Date(), Thread.currentThread().getName(), message }));
/*     */   }
/*     */   
/*     */   public static void start(Bundle bundle) throws BundleException {
/* 744 */     int originalState = bundle.getState();
/* 745 */     if ((originalState & 0x20) != 0) {
/*     */       return;
/*     */     }
/*     */     try {
/* 749 */       bundle.start(1);
/* 750 */     } catch (BundleException e) {
/* 751 */       if ((originalState & 0x8) != 0 && (bundle.getState() & 0x8) != 0) {
/*     */         return;
/*     */       }
/* 754 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\internal\runtime\InternalPlatform.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */