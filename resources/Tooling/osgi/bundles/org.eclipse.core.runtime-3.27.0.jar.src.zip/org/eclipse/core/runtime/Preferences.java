/*      */ package org.eclipse.core.runtime;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.util.EventListener;
/*      */ import java.util.EventObject;
/*      */ import java.util.Properties;
/*      */ import org.eclipse.core.internal.preferences.PreferencesService;
/*      */ import org.eclipse.core.internal.preferences.PrefsMessages;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Deprecated
/*      */ public class Preferences
/*      */ {
/*      */   public static final boolean BOOLEAN_DEFAULT_DEFAULT = false;
/*      */   public static final double DOUBLE_DEFAULT_DEFAULT = 0.0D;
/*      */   public static final float FLOAT_DEFAULT_DEFAULT = 0.0F;
/*      */   public static final int INT_DEFAULT_DEFAULT = 0;
/*      */   public static final long LONG_DEFAULT_DEFAULT = 0L;
/*      */   public static final String STRING_DEFAULT_DEFAULT = "";
/*      */   protected static final String TRUE = "true";
/*      */   protected static final String FALSE = "false";
/*  143 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PT_PREFERENCES = "preferences";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PropertyChangeEvent
/*      */     extends EventObject
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String propertyName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object oldValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object newValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected PropertyChangeEvent(Object source, String property, Object oldValue, Object newValue) {
/*  207 */       super(source);
/*  208 */       if (property == null) {
/*  209 */         throw new IllegalArgumentException();
/*      */       }
/*  211 */       this.propertyName = property;
/*  212 */       this.oldValue = oldValue;
/*  213 */       this.newValue = newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getProperty() {
/*  227 */       return this.propertyName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getNewValue() {
/*  237 */       return this.newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getOldValue() {
/*  247 */       return this.oldValue;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   protected ListenerList<IPropertyChangeListener> listeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Properties properties;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Properties defaultProperties;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean dirty = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void exportPreferences(IPath path) throws CoreException {
/*  334 */     File file = path.toFile();
/*  335 */     if (file.exists())
/*  336 */       file.delete(); 
/*  337 */     file.getParentFile().mkdirs();
/*  338 */     PreferencesService preferencesService = PreferencesService.getDefault();
/*  339 */     OutputStream output = null;
/*  340 */     FileOutputStream fos = null;
/*      */     try {
/*  342 */       fos = new FileOutputStream(file);
/*  343 */       output = new BufferedOutputStream(fos);
/*  344 */       IEclipsePreferences node = (IEclipsePreferences)preferencesService.getRootNode().node("instance");
/*  345 */       preferencesService.exportPreferences(node, output, null);
/*  346 */       output.flush();
/*  347 */       fos.getFD().sync();
/*  348 */     } catch (IOException e) {
/*  349 */       String message = NLS.bind(PrefsMessages.preferences_errorWriting, file, e.getMessage());
/*  350 */       Status status = new Status(4, "org.eclipse.equinox.preferences", 4, message, e);
/*  351 */       throw new CoreException(status);
/*      */     } finally {
/*  353 */       if (output != null) {
/*      */         try {
/*  355 */           output.close();
/*  356 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void importPreferences(IPath path) throws CoreException {
/*  385 */     if (!path.toFile().exists()) {
/*  386 */       String msg = NLS.bind(PrefsMessages.preferences_fileNotFound, path.toOSString());
/*  387 */       throw new CoreException(new Status(4, "org.eclipse.equinox.preferences", 1, msg, null));
/*      */     } 
/*  389 */     PreferencesService preferencesService = PreferencesService.getDefault();
/*  390 */     InputStream input = null;
/*      */     try {
/*  392 */       input = new BufferedInputStream(new FileInputStream(path.toFile()));
/*  393 */       preferencesService.importPreferences(input);
/*  394 */     } catch (FileNotFoundException e) {
/*  395 */       String msg = NLS.bind(PrefsMessages.preferences_fileNotFound, path.toOSString());
/*  396 */       throw new CoreException(new Status(4, "org.eclipse.equinox.preferences", 1, msg, e));
/*      */     } finally {
/*  398 */       if (input != null) {
/*      */         try {
/*  400 */           input.close();
/*  401 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IStatus validatePreferenceVersions(IPath file) {
/*  430 */     PreferencesService service = PreferencesService.getDefault();
/*  431 */     return service.validateVersions(file);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Preferences() {
/*  444 */     this.defaultProperties = new Properties();
/*  445 */     this.properties = new Properties(this.defaultProperties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(IPropertyChangeListener listener) {
/*  461 */     this.listeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(IPropertyChangeListener listener) {
/*  471 */     this.listeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(String name) {
/*  484 */     return !(!this.properties.containsKey(name) && !this.defaultProperties.containsKey(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firePropertyChangeEvent(String name, Object oldValue, Object newValue) {
/*  499 */     if (name == null) {
/*  500 */       throw new IllegalArgumentException();
/*      */     }
/*  502 */     if (this.listeners.size() == 0)
/*      */       return; 
/*  504 */     final PropertyChangeEvent pe = new PropertyChangeEvent(this, name, oldValue, newValue);
/*  505 */     for (IPropertyChangeListener l : this.listeners) {
/*  506 */       ISafeRunnable job = new ISafeRunnable()
/*      */         {
/*      */           public void handleException(Throwable exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void run() throws Exception {
/*  514 */             l.propertyChange(pe);
/*      */           }
/*      */         };
/*  517 */       SafeRunner.run(job);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface IPropertyChangeListener
/*      */     extends EventListener
/*      */   {
/*      */     void propertyChange(Preferences.PropertyChangeEvent param1PropertyChangeEvent);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String name) {
/*  533 */     String value = this.properties.getProperty(name);
/*  534 */     if (value == null) {
/*  535 */       return false;
/*      */     }
/*  537 */     return value.equals("true");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, boolean value) {
/*  560 */     boolean defaultValue = getDefaultBoolean(name);
/*  561 */     boolean oldValue = getBoolean(name);
/*  562 */     if (value == defaultValue) {
/*  563 */       Object removed = this.properties.remove(name);
/*  564 */       if (removed != null)
/*      */       {
/*  566 */         this.dirty = true;
/*      */       }
/*      */     } else {
/*  569 */       this.properties.put(name, value ? "true" : "false");
/*      */     } 
/*  571 */     if (oldValue != value) {
/*      */       
/*  573 */       this.dirty = true;
/*      */       
/*  575 */       firePropertyChangeEvent(name, oldValue ? Boolean.TRUE : Boolean.FALSE, value ? Boolean.TRUE : Boolean.FALSE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDefaultBoolean(String name) {
/*  591 */     String value = this.defaultProperties.getProperty(name);
/*  592 */     if (value == null) {
/*  593 */       return false;
/*      */     }
/*  595 */     return value.equals("true");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, boolean value) {
/*  614 */     this.defaultProperties.put(name, value ? "true" : "false");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String name) {
/*  629 */     return convertToDouble(this.properties.getProperty(name), 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, double value) {
/*  653 */     if (Double.isNaN(value)) {
/*  654 */       throw new IllegalArgumentException();
/*      */     }
/*  656 */     double defaultValue = getDefaultDouble(name);
/*  657 */     double oldValue = getDouble(name);
/*  658 */     if (value == defaultValue) {
/*  659 */       Object removed = this.properties.remove(name);
/*  660 */       if (removed != null)
/*      */       {
/*  662 */         this.dirty = true;
/*      */       }
/*      */     } else {
/*  665 */       this.properties.put(name, Double.toString(value));
/*      */     } 
/*  667 */     if (oldValue != value) {
/*      */       
/*  669 */       this.dirty = true;
/*      */       
/*  671 */       firePropertyChangeEvent(name, Double.valueOf(oldValue), Double.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDefaultDouble(String name) {
/*  687 */     return convertToDouble(this.defaultProperties.getProperty(name), 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, double value) {
/*  707 */     if (Double.isNaN(value)) {
/*  708 */       throw new IllegalArgumentException();
/*      */     }
/*  710 */     this.defaultProperties.put(name, Double.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double convertToDouble(String rawPropertyValue, double defaultValue) {
/*  724 */     double result = defaultValue;
/*  725 */     if (rawPropertyValue != null) {
/*      */       try {
/*  727 */         result = Double.parseDouble(rawPropertyValue);
/*  728 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */ 
/*      */     
/*  732 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String name) {
/*  747 */     return convertToFloat(this.properties.getProperty(name), 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, float value) {
/*  771 */     if (Float.isNaN(value)) {
/*  772 */       throw new IllegalArgumentException();
/*      */     }
/*  774 */     float defaultValue = getDefaultFloat(name);
/*  775 */     float oldValue = getFloat(name);
/*  776 */     if (value == defaultValue) {
/*  777 */       Object removed = this.properties.remove(name);
/*  778 */       if (removed != null)
/*      */       {
/*  780 */         this.dirty = true;
/*      */       }
/*      */     } else {
/*  783 */       this.properties.put(name, Float.toString(value));
/*      */     } 
/*  785 */     if (oldValue != value) {
/*      */       
/*  787 */       this.dirty = true;
/*      */       
/*  789 */       firePropertyChangeEvent(name, Float.valueOf(oldValue), Float.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDefaultFloat(String name) {
/*  805 */     return convertToFloat(this.defaultProperties.getProperty(name), 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, float value) {
/*  825 */     if (Float.isNaN(value)) {
/*  826 */       throw new IllegalArgumentException();
/*      */     }
/*  828 */     this.defaultProperties.put(name, Float.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float convertToFloat(String rawPropertyValue, float defaultValue) {
/*  842 */     float result = defaultValue;
/*  843 */     if (rawPropertyValue != null) {
/*      */       try {
/*  845 */         result = Float.parseFloat(rawPropertyValue);
/*  846 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */ 
/*      */     
/*  850 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String name) {
/*  865 */     return convertToInt(this.properties.getProperty(name), 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, int value) {
/*  888 */     int defaultValue = getDefaultInt(name);
/*  889 */     int oldValue = getInt(name);
/*  890 */     if (value == defaultValue) {
/*  891 */       Object removed = this.properties.remove(name);
/*  892 */       if (removed != null)
/*      */       {
/*  894 */         this.dirty = true;
/*      */       }
/*      */     } else {
/*  897 */       this.properties.put(name, Integer.toString(value));
/*      */     } 
/*  899 */     if (oldValue != value) {
/*      */       
/*  901 */       this.dirty = true;
/*      */       
/*  903 */       firePropertyChangeEvent(name, Integer.valueOf(oldValue), Integer.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultInt(String name) {
/*  919 */     return convertToInt(this.defaultProperties.getProperty(name), 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, int value) {
/*  938 */     this.defaultProperties.put(name, Integer.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int convertToInt(String rawPropertyValue, int defaultValue) {
/*  952 */     int result = defaultValue;
/*  953 */     if (rawPropertyValue != null) {
/*      */       try {
/*  955 */         result = Integer.parseInt(rawPropertyValue);
/*  956 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */ 
/*      */     
/*  960 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String name) {
/*  975 */     return convertToLong(this.properties.getProperty(name), 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, long value) {
/*  998 */     long defaultValue = getDefaultLong(name);
/*  999 */     long oldValue = getLong(name);
/* 1000 */     if (value == defaultValue) {
/* 1001 */       Object removed = this.properties.remove(name);
/* 1002 */       if (removed != null)
/*      */       {
/* 1004 */         this.dirty = true;
/*      */       }
/*      */     } else {
/* 1007 */       this.properties.put(name, Long.toString(value));
/*      */     } 
/* 1009 */     if (oldValue != value) {
/*      */       
/* 1011 */       this.dirty = true;
/*      */       
/* 1013 */       firePropertyChangeEvent(name, Long.valueOf(oldValue), Long.valueOf(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getDefaultLong(String name) {
/* 1029 */     return convertToLong(this.defaultProperties.getProperty(name), 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, long value) {
/* 1048 */     this.defaultProperties.put(name, Long.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long convertToLong(String rawPropertyValue, long defaultValue) {
/* 1062 */     long result = defaultValue;
/* 1063 */     if (rawPropertyValue != null) {
/*      */       try {
/* 1065 */         result = Long.parseLong(rawPropertyValue);
/* 1066 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */ 
/*      */     
/* 1070 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String name) {
/* 1084 */     String value = this.properties.getProperty(name);
/* 1085 */     return (value != null) ? value : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, String value) {
/* 1108 */     if (value == null) {
/* 1109 */       throw new IllegalArgumentException();
/*      */     }
/* 1111 */     String defaultValue = getDefaultString(name);
/* 1112 */     String oldValue = getString(name);
/* 1113 */     if (value.equals(defaultValue)) {
/* 1114 */       Object removed = this.properties.remove(name);
/* 1115 */       if (removed != null)
/*      */       {
/* 1117 */         this.dirty = true;
/*      */       }
/*      */     } else {
/* 1120 */       this.properties.put(name, value);
/*      */     } 
/* 1122 */     if (!oldValue.equals(value)) {
/*      */       
/* 1124 */       this.dirty = true;
/*      */       
/* 1126 */       firePropertyChangeEvent(name, oldValue, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultString(String name) {
/* 1142 */     String value = this.defaultProperties.getProperty(name);
/* 1143 */     return (value != null) ? value : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String name, String value) {
/* 1162 */     if (value == null) {
/* 1163 */       throw new IllegalArgumentException();
/*      */     }
/* 1165 */     this.defaultProperties.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefault(String name) {
/* 1179 */     return !this.properties.containsKey(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToDefault(String name) {
/* 1202 */     Object oldPropertyValue = this.properties.remove(name);
/* 1203 */     if (oldPropertyValue != null) {
/* 1204 */       this.dirty = true;
/*      */     }
/* 1206 */     String newValue = this.defaultProperties.getProperty(name, null);
/*      */ 
/*      */     
/* 1209 */     firePropertyChangeEvent(name, oldPropertyValue, newValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] propertyNames() {
/* 1219 */     return this.properties.keySet().<String>toArray(EMPTY_STRING_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] defaultPropertyNames() {
/* 1229 */     return this.defaultProperties.keySet().<String>toArray(EMPTY_STRING_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needsSaving() {
/* 1241 */     return this.dirty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void store(OutputStream out, String header) throws IOException {
/* 1260 */     this.properties.store(out, header);
/* 1261 */     this.dirty = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void load(InputStream in) throws IOException {
/* 1276 */     this.properties.load(in);
/* 1277 */     this.dirty = false;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\Preferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */