/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.internal.runtime.InternalPlatform;
/*     */ import org.eclipse.core.internal.runtime.PerformanceStatsProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerformanceStats
/*     */ {
/*     */   public static abstract class PerformanceListener
/*     */   {
/*     */     public void eventFailed(PerformanceStats event, long duration) {}
/*     */     
/*     */     public void eventsOccurred(PerformanceStats[] event) {}
/*     */   }
/*     */   
/*  96 */   private static final PerformanceStats EMPTY_STATS = new PerformanceStats("", "");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean ENABLED;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NOT_STARTED = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private static final Map<PerformanceStats, PerformanceStats> statMap = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static final Map<String, Long> thresholdMap = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean TRACE_SUCCESS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String blame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String blamePluginId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private long currentStart = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String event;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFailure;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private int runCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private long runningTime = 0L;
/*     */   
/*     */   static {
/* 172 */     ENABLED = InternalPlatform.getDefault().getBooleanOption("org.eclipse.core.runtime/perf", false);
/*     */     
/* 174 */     TRACE_SUCCESS = InternalPlatform.getDefault().getBooleanOption("org.eclipse.core.runtime/perf/success", ENABLED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addListener(PerformanceListener listener) {
/* 185 */     if (ENABLED) {
/* 186 */       PerformanceStatsProcessor.addListener(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/* 193 */     statMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PerformanceStats[] getAllStats() {
/* 203 */     return (PerformanceStats[])statMap.values().toArray((Object[])new PerformanceStats[statMap.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PerformanceStats getStats(String eventName, Object blameObject) {
/* 220 */     if (!ENABLED || eventName == null || blameObject == null)
/* 221 */       return EMPTY_STATS; 
/* 222 */     PerformanceStats newStats = new PerformanceStats(eventName, blameObject);
/* 223 */     if (!TRACE_SUCCESS) {
/* 224 */       return newStats;
/*     */     }
/* 226 */     PerformanceStats oldStats = statMap.get(newStats);
/* 227 */     if (oldStats != null)
/* 228 */       return oldStats; 
/* 229 */     statMap.put(newStats, newStats);
/* 230 */     return newStats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnabled(String eventName) {
/* 247 */     if (!ENABLED)
/* 248 */       return false; 
/* 249 */     String option = Platform.getDebugOption(eventName);
/* 250 */     return (option != null && !"false".equalsIgnoreCase(option) && !"-1".equalsIgnoreCase(option));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printStats() {
/* 257 */     if (!ENABLED)
/*     */       return; 
/* 259 */     PrintWriter writer = new PrintWriter(System.out);
/* 260 */     PerformanceStatsProcessor.printStats(writer);
/* 261 */     writer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printStats(PrintWriter out) {
/* 270 */     if (!ENABLED)
/*     */       return; 
/* 272 */     PerformanceStatsProcessor.printStats(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeListener(PerformanceListener listener) {
/* 283 */     if (ENABLED) {
/* 284 */       PerformanceStatsProcessor.removeListener(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeStats(String eventName, Object blameObject) {
/* 294 */     synchronized (statMap) {
/* 295 */       for (Iterator<PerformanceStats> it = statMap.keySet().iterator(); it.hasNext(); ) {
/* 296 */         PerformanceStats stats = it.next();
/* 297 */         if (stats.getEvent().equals(eventName) && stats.getBlame().equals(blameObject)) {
/* 298 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PerformanceStats(String event, Object blame) {
/* 307 */     this(event, blame, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PerformanceStats(String event, Object blameObject, String context) {
/* 314 */     this.event = event;
/* 315 */     this.blame = (blameObject instanceof String) ? (String)blameObject : blameObject.getClass().getName();
/* 316 */     this.blamePluginId = InternalPlatform.getDefault().getBundleId(blameObject);
/* 317 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRun(long elapsed, String contextName) {
/* 331 */     if (!ENABLED)
/*     */       return; 
/* 333 */     this.runCount++;
/* 334 */     this.runningTime += elapsed;
/* 335 */     if (elapsed > getThreshold(this.event))
/* 336 */       PerformanceStatsProcessor.failed(createFailureStats(contextName, elapsed), this.blamePluginId, elapsed); 
/* 337 */     if (TRACE_SUCCESS) {
/* 338 */       PerformanceStatsProcessor.changed(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PerformanceStats createFailureStats(String contextName, long elapsed) {
/* 349 */     PerformanceStats failedStat = new PerformanceStats(this.event, this.blame, contextName);
/* 350 */     PerformanceStats old = statMap.get(failedStat);
/* 351 */     if (old == null) {
/* 352 */       statMap.put(failedStat, failedStat);
/*     */     } else {
/* 354 */       failedStat = old;
/* 355 */     }  failedStat.isFailure = true;
/* 356 */     failedStat.runCount++;
/* 357 */     failedStat.runningTime += elapsed;
/* 358 */     return failedStat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endRun() {
/* 374 */     if (!ENABLED || this.currentStart == -1L)
/*     */       return; 
/* 376 */     addRun(System.currentTimeMillis() - this.currentStart, this.context);
/* 377 */     this.currentStart = -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 383 */     if (!(obj instanceof PerformanceStats))
/* 384 */       return false; 
/* 385 */     PerformanceStats that = (PerformanceStats)obj;
/* 386 */     return (this.event.equals(that.event) && getBlameString().equals(that.getBlameString()) && 
/* 387 */       Objects.equals(this.context, that.context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBlame() {
/* 397 */     return this.blame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBlameString() {
/* 406 */     return this.blame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContext() {
/* 416 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEvent() {
/* 425 */     return this.event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRunCount() {
/* 434 */     return this.runCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRunningTime() {
/* 444 */     return this.runningTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getThreshold(String eventName) {
/* 451 */     Long value = thresholdMap.get(eventName);
/* 452 */     if (value == null) {
/* 453 */       String option = InternalPlatform.getDefault().getOption(eventName);
/* 454 */       if (option != null) {
/*     */         try {
/* 456 */           value = Long.valueOf(option);
/* 457 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */ 
/*     */       
/* 461 */       if (value == null)
/* 462 */         value = Long.valueOf(Long.MAX_VALUE); 
/* 463 */       thresholdMap.put(eventName, value);
/*     */     } 
/* 465 */     return value.longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 471 */     int hash = this.event.hashCode() * 37 + getBlameString().hashCode();
/* 472 */     if (this.context != null)
/* 473 */       hash = hash * 37 + this.context.hashCode(); 
/* 474 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFailure() {
/* 484 */     return this.isFailure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 491 */     this.runningTime = 0L;
/* 492 */     this.runCount = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startRun() {
/* 500 */     if (ENABLED) {
/* 501 */       startRun(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startRun(String contextName) {
/* 514 */     if (!ENABLED)
/*     */       return; 
/* 516 */     this.context = contextName;
/* 517 */     this.currentStart = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 525 */     StringBuilder result = new StringBuilder("PerformanceStats(");
/* 526 */     result.append(this.event);
/* 527 */     result.append(',');
/* 528 */     result.append(this.blame);
/* 529 */     if (this.context != null) {
/* 530 */       result.append(',');
/* 531 */       result.append(this.context);
/*     */     } 
/* 533 */     result.append(')');
/* 534 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.runtime-3.27.0.jar!\org\eclipse\core\runtime\PerformanceStats.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */