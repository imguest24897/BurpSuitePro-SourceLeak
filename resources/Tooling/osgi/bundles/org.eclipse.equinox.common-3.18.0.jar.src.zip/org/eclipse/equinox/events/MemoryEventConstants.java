package org.eclipse.equinox.events;

public final class MemoryEventConstants {
  public static final String TOPIC_BASE = "org/eclipse/equinox/events/MemoryEvent/";
  
  public static final String TOPIC_NORMAL = "org/eclipse/equinox/events/MemoryEvent/NORMAL";
  
  public static final String TOPIC_SERIOUS = "org/eclipse/equinox/events/MemoryEvent/SERIOUS";
  
  public static final String TOPIC_CRITICAL = "org/eclipse/equinox/events/MemoryEvent/CRITICAL";
  
  public static final String TOPIC_ALL = "org/eclipse/equinox/events/MemoryEvent/*";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\equinox\events\MemoryEventConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */