/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.AssertionFailedException;
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.eclipse.core.runtime.IAdapterManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdapterManager
/*     */   implements IAdapterManager
/*     */ {
/*     */   private final ConcurrentMap<String, Map<String, List<IAdapterFactory>>> adapterLookup;
/*     */   private final ConcurrentMap<IAdapterFactory, ConcurrentMap<String, Class<?>>> classLookup;
/*     */   private final ConcurrentMap<Class<?>, Class<?>[]> classSearchOrderLookup;
/*     */   private final Map<String, List<IAdapterFactory>> factories;
/*     */   private final Queue<IAdapterManagerProvider> lazyFactoryProviders;
/*  81 */   private static final AdapterManager singleton = new AdapterManager();
/*     */   
/*     */   public static AdapterManager getDefault() {
/*  84 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AdapterManager() {
/*  91 */     this.classSearchOrderLookup = (ConcurrentMap)new ConcurrentHashMap<>();
/*  92 */     this.adapterLookup = new ConcurrentHashMap<>();
/*  93 */     this.lazyFactoryProviders = new ConcurrentLinkedQueue<>();
/*  94 */     this.factories = new ConcurrentHashMap<>();
/*  95 */     this.classLookup = new ConcurrentHashMap<>();
/*     */   }
/*     */   
/*     */   private static boolean isFactoryLoaded(IAdapterFactory adapterFactory) {
/*  99 */     return !(adapterFactory instanceof IAdapterFactoryExt && ((IAdapterFactoryExt)adapterFactory).loadFactory(false) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addFactoriesFor(String adaptableTypeName, Map<String, List<IAdapterFactory>> table) {
/* 108 */     List<IAdapterFactory> factoryList = getFactories().get(adaptableTypeName);
/* 109 */     if (factoryList == null)
/*     */       return; 
/* 111 */     for (IAdapterFactory factory : factoryList) {
/* 112 */       if (factory instanceof IAdapterFactoryExt) {
/* 113 */         String[] arrayOfString1 = ((IAdapterFactoryExt)factory).getAdapterNames(); byte b1; int j; String[] arrayOfString2;
/* 114 */         for (j = (arrayOfString2 = arrayOfString1).length, b1 = 0; b1 < j; ) { String adapter = arrayOfString2[b1];
/* 115 */           ((List<IAdapterFactory>)table.computeIfAbsent(adapter, any -> new ArrayList(1))).add(factory); b1++; }
/*     */          continue;
/*     */       } 
/* 118 */       Class[] adapters = factory.getAdapterList(); byte b; int i; Class[] arrayOfClass1;
/* 119 */       for (i = (arrayOfClass1 = adapters).length, b = 0; b < i; ) { Class<?> adapter = arrayOfClass1[b];
/* 120 */         ((List<IAdapterFactory>)table.computeIfAbsent(adapter.getName(), any -> new ArrayList(1))).add(factory);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> classForName(IAdapterFactory adapterFactory, String typeName) {
/* 135 */     return ((ConcurrentMap<String, Class<?>>)this.classLookup.computeIfAbsent(adapterFactory, factory -> new ConcurrentHashMap<>())).computeIfAbsent(typeName, type -> (Class)loadFactory(paramIAdapterFactory, false).<Class<?>>map(()).orElse(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] computeAdapterTypes(Class<? extends Object> adaptable) {
/* 156 */     Set<String> types = getFactories(adaptable).keySet();
/* 157 */     return types.<String>toArray(new String[types.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, List<IAdapterFactory>> getFactories(Class<? extends Object> adaptable) {
/* 167 */     return this.adapterLookup.computeIfAbsent(adaptable.getName(), adaptableType -> {
/*     */           Map<String, List<IAdapterFactory>> table = new HashMap<>(4);
/*     */           Class[] arrayOfClass;
/*     */           int i = (arrayOfClass = computeClassOrder(paramClass)).length;
/*     */           for (byte b = 0; b < i; b++) {
/*     */             Class<?> cl = arrayOfClass[b];
/*     */             addFactoriesFor(cl.getName(), table);
/*     */           } 
/*     */           return Collections.unmodifiableMap(table);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Class<? super T>[] computeClassOrder(Class<T> adaptable) {
/* 183 */     Class[] classOrder = (Class[])getClassOrder(adaptable);
/* 184 */     return Arrays.<Class<? super T>>copyOf((Class<? super T>[])classOrder, classOrder.length);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Class<? super T>[] getClassOrder(Class<T> adaptable) {
/* 189 */     return (Class<? super T>[])this.classSearchOrderLookup.computeIfAbsent(adaptable, AdapterManager::doComputeClassOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?>[] doComputeClassOrder(Class<?> adaptable) {
/* 197 */     List<Class<?>> classes = new ArrayList<>();
/* 198 */     Class<?> clazz = adaptable;
/* 199 */     Set<Class<?>> seen = new HashSet<>(4);
/*     */     
/* 201 */     while (clazz != null) {
/* 202 */       classes.add(clazz);
/* 203 */       clazz = clazz.getSuperclass();
/*     */     } 
/*     */     
/* 206 */     Class[] classHierarchy = (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[classes.size()]); byte b; int i; Class[] arrayOfClass1;
/* 207 */     for (i = (arrayOfClass1 = classHierarchy).length, b = 0; b < i; ) { Class<?> cl = arrayOfClass1[b];
/* 208 */       computeInterfaceOrder(cl.getInterfaces(), classes, seen); b++; }
/*     */     
/* 210 */     return (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[classes.size()]);
/*     */   }
/*     */   
/*     */   private static void computeInterfaceOrder(Class[] interfaces, Collection<Class<?>> classes, Set<Class<?>> seen) {
/* 214 */     List<Class<?>> newInterfaces = new ArrayList<>(interfaces.length); byte b; int i; Class[] arrayOfClass;
/* 215 */     for (i = (arrayOfClass = interfaces).length, b = 0; b < i; ) { Class<?> interfac = arrayOfClass[b];
/* 216 */       if (seen.add(interfac)) {
/*     */         
/* 218 */         classes.add(interfac);
/* 219 */         newInterfaces.add(interfac);
/*     */       }  b++; }
/*     */     
/* 222 */     for (Class<?> clazz : newInterfaces) {
/* 223 */       computeInterfaceOrder(clazz.getInterfaces(), classes, seen);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flushLookup() {
/* 235 */     this.adapterLookup.clear();
/* 236 */     this.classLookup.clear();
/* 237 */     this.classSearchOrderLookup.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Object adaptable, Class<T> adapterType) {
/* 243 */     Assert.isNotNull(adaptable);
/* 244 */     Assert.isNotNull(adapterType);
/* 245 */     List<Map.Entry<IAdapterFactory, Class<?>>> incorrectAdapters = new ArrayList<>();
/* 246 */     T adapterObject = ((List)getFactories((Class)adaptable.getClass()).getOrDefault(adapterType.getName(), Collections.emptyList()))
/* 247 */       .stream()
/* 248 */       .map(factory -> new AbstractMap.SimpleEntry<>(factory, factory.getAdapter(paramObject, paramClass)))
/* 249 */       .filter(entry -> {
/*     */           Object adapter = entry.getValue();
/*     */           if (adapter == null) {
/*     */             return false;
/*     */           }
/*     */           boolean res = paramClass.isInstance(adapter);
/*     */           if (!res) {
/*     */             IAdapterFactory factory = entry.getKey();
/*     */             paramList.add(new AbstractMap.SimpleEntry<>(factory, adapter.getClass()));
/*     */           } 
/*     */           return res;
/* 260 */         }).map(Map.Entry::getValue)
/* 261 */       .findFirst()
/* 262 */       .orElse(null);
/* 263 */     if (adapterObject == null) {
/* 264 */       if (!incorrectAdapters.isEmpty()) {
/* 265 */         throw new AssertionFailedException((String)incorrectAdapters.stream().map(entry -> "Adapter factory " + entry.getKey() + " returned " + ((Class)entry.getValue()).getName() + " that is not an instance of " + paramClass.getName())
/*     */             
/* 267 */             .collect(Collectors.joining("\n")));
/*     */       }
/* 269 */       if (adapterType.isInstance(adaptable)) {
/* 270 */         return (T)adaptable;
/*     */       }
/*     */     } 
/* 273 */     return adapterObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAdapter(Object adaptable, String adapterType) {
/* 278 */     Assert.isNotNull(adaptable);
/* 279 */     Assert.isNotNull(adapterType);
/* 280 */     return getAdapter(adaptable, adapterType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getAdapter(Object adaptable, String adapterType, boolean force) {
/* 292 */     Assert.isNotNull(adaptable);
/* 293 */     Assert.isNotNull(adapterType);
/* 294 */     return ((List)getFactories((Class)adaptable.getClass()).getOrDefault(adapterType, Collections.emptyList()))
/* 295 */       .stream()
/* 296 */       .map(factory -> (paramBoolean && factory instanceof IAdapterFactoryExt) ? ((IAdapterFactoryExt)factory).loadFactory(true) : factory)
/* 297 */       .filter(Objects::nonNull).map(factory -> {
/*     */           Class<?> adapterClass = classForName(factory, paramString);
/*     */ 
/*     */ 
/*     */           
/*     */           return (adapterClass == null) ? null : factory.getAdapter(paramObject, adapterClass);
/* 303 */         }).filter(Objects::nonNull)
/* 304 */       .findFirst()
/* 305 */       .map(Object.class::cast)
/* 306 */       .orElseGet(() -> paramString.equals(paramObject.getClass().getName()) ? paramObject : null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdapter(Object adaptable, String adapterTypeName) {
/* 311 */     return (getFactories((Class)adaptable.getClass()).get(adapterTypeName) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int queryAdapter(Object adaptable, String adapterTypeName) {
/* 316 */     List<IAdapterFactory> eligibleFactories = getFactories((Class)adaptable.getClass()).get(adapterTypeName);
/* 317 */     if (eligibleFactories == null || eligibleFactories.isEmpty()) {
/* 318 */       return 0;
/*     */     }
/* 320 */     if (eligibleFactories.stream().anyMatch(AdapterManager::isFactoryLoaded)) {
/* 321 */       return 2;
/*     */     }
/* 323 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object loadAdapter(Object adaptable, String adapterTypeName) {
/* 328 */     return getAdapter(adaptable, adapterTypeName, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void registerAdapters(IAdapterFactory factory, Class<?> adaptable) {
/* 336 */     registerFactory(factory, adaptable.getName());
/* 337 */     flushLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerFactory(IAdapterFactory factory, String adaptableType) {
/* 344 */     ((List<IAdapterFactory>)this.factories.computeIfAbsent(adaptableType, any -> new CopyOnWriteArrayList())).add(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void unregisterAdapters(IAdapterFactory factory) {
/* 352 */     for (List<IAdapterFactory> list : this.factories.values())
/* 353 */       list.remove(factory); 
/* 354 */     flushLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void unregisterAdapters(IAdapterFactory factory, Class<?> adaptable) {
/* 362 */     List<IAdapterFactory> factoryList = this.factories.get(adaptable.getName());
/* 363 */     if (factoryList == null)
/*     */       return; 
/* 365 */     factoryList.remove(factory);
/* 366 */     flushLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void unregisterAllAdapters() {
/* 375 */     this.lazyFactoryProviders.clear();
/* 376 */     this.factories.clear();
/* 377 */     flushLookup();
/*     */   }
/*     */   
/*     */   public void registerLazyFactoryProvider(IAdapterManagerProvider factoryProvider) {
/* 381 */     this.lazyFactoryProviders.add(factoryProvider);
/*     */   }
/*     */   
/*     */   public boolean unregisterLazyFactoryProvider(IAdapterManagerProvider factoryProvider) {
/* 385 */     return this.lazyFactoryProviders.remove(factoryProvider);
/*     */   }
/*     */   
/*     */   public Map<String, List<IAdapterFactory>> getFactories() {
/*     */     IAdapterManagerProvider provider;
/* 390 */     while ((provider = this.lazyFactoryProviders.poll()) != null) {
/* 391 */       if (provider.addFactories(this)) {
/* 392 */         flushLookup();
/*     */       }
/*     */     } 
/* 395 */     return this.factories;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Optional<IAdapterFactory> loadFactory(IAdapterFactory factory, boolean force) {
/* 405 */     if (factory instanceof IAdapterFactoryExt) {
/* 406 */       return Optional.ofNullable(((IAdapterFactoryExt)factory).loadFactory(force));
/*     */     }
/* 408 */     return Optional.ofNullable(factory);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\AdapterManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */