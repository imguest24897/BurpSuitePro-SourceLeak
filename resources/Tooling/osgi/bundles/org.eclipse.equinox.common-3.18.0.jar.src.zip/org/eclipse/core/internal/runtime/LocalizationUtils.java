/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalizationUtils
/*    */ {
/*    */   public static String safeLocalize(String key) {
/*    */     try {
/* 36 */       Class<?> messageClass = Class.forName("org.eclipse.core.internal.runtime.CommonMessages");
/* 37 */       if (messageClass == null)
/* 38 */         return key; 
/* 39 */       Field field = messageClass.getDeclaredField(key);
/* 40 */       if (field == null)
/* 41 */         return key; 
/* 42 */       Object value = field.get(null);
/* 43 */       if (value instanceof String)
/* 44 */         return (String)value; 
/* 45 */     } catch (ClassNotFoundException|NoClassDefFoundError|SecurityException|NoSuchFieldException|IllegalArgumentException|IllegalAccessException classNotFoundException) {}
/*    */ 
/*    */     
/* 48 */     return key;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\LocalizationUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */