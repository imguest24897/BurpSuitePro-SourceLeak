/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*    */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLPluginConnection
/*    */   extends PlatformURLConnection
/*    */ {
/*    */   private static boolean isRegistered = false;
/*    */   public static final String PLUGIN = "plugin";
/*    */   
/*    */   public PlatformURLPluginConnection(URL url) {
/* 36 */     super(url);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean allowCaching() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object[] parse(String spec, URL originalURL) throws IOException {
/* 51 */     Object[] result = new Object[2];
/* 52 */     if (spec.startsWith("/"))
/* 53 */       spec = spec.substring(1); 
/* 54 */     if (!spec.startsWith("plugin"))
/* 55 */       throw new IOException(NLS.bind(CommonMessages.url_badVariant, originalURL)); 
/* 56 */     int ix = spec.indexOf('/', "plugin".length() + 1);
/* 57 */     String ref = (ix == -1) ? spec.substring("plugin".length() + 1) : spec.substring("plugin".length() + 1, ix);
/* 58 */     String id = getId(ref);
/* 59 */     Activator activator = Activator.getDefault();
/* 60 */     if (activator == null)
/* 61 */       throw new IOException(CommonMessages.activator_not_available); 
/* 62 */     Bundle bundle = activator.getBundle(id);
/* 63 */     if (bundle == null)
/* 64 */       throw new IOException(NLS.bind(CommonMessages.url_resolvePlugin, id)); 
/* 65 */     result[0] = bundle;
/* 66 */     result[1] = (ix == -1 || ix + 1 >= spec.length()) ? "/" : spec.substring(ix + 1);
/* 67 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL resolve() throws IOException {
/* 72 */     String spec = this.url.getFile().trim();
/* 73 */     Object[] obj = parse(spec, this.url);
/* 74 */     Bundle b = (Bundle)obj[0];
/* 75 */     String path = (String)obj[1];
/* 76 */     URL result = b.getEntry(path);
/* 77 */     if (result != null || "/".equals(path)) {
/* 78 */       return result;
/*    */     }
/* 80 */     result = b.getResource(path);
/* 81 */     if (result != null) {
/* 82 */       return result;
/*    */     }
/* 84 */     return new URL(b.getEntry("/"), path);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void startup() {
/* 89 */     if (isRegistered)
/*    */       return; 
/* 91 */     PlatformURLHandler.register("plugin", PlatformURLPluginConnection.class);
/* 92 */     isRegistered = true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformURLPluginConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */