/*     */ package org.eclipse.core.text;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringMatcher
/*     */ {
/*     */   private final String fPattern;
/*     */   private final int fLength;
/*     */   private final boolean fIgnoreCase;
/*     */   private boolean fIgnoreWildCards;
/*     */   private boolean fHasLeadingStar;
/*     */   private boolean fHasTrailingStar;
/*     */   private String[] fSegments;
/*  41 */   private int fBound = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char fSingleWildCard = '\000';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Position
/*     */   {
/*     */     private final int start;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int end;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Position(int start, int end) {
/*  66 */       this.start = start;
/*  67 */       this.end = end;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getStart() {
/*  76 */       return this.start;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getEnd() {
/*  85 */       return this.end;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  91 */       int result = 1;
/*  92 */       result = 31 * result + this.end;
/*  93 */       result = 31 * result + this.start;
/*  94 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  99 */       if (this == obj) {
/* 100 */         return true;
/*     */       }
/* 102 */       if (obj == null || getClass() != obj.getClass()) {
/* 103 */         return false;
/*     */       }
/* 105 */       Position other = (Position)obj;
/* 106 */       return (this.end == other.end && this.start == other.start);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 111 */       return "Position(" + this.start + ',' + this.end + ')';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringMatcher(String pattern, boolean ignoreCase, boolean ignoreWildCards) {
/* 143 */     if (pattern == null) {
/* 144 */       throw new IllegalArgumentException();
/*     */     }
/* 146 */     this.fIgnoreCase = ignoreCase;
/* 147 */     this.fIgnoreWildCards = ignoreWildCards;
/* 148 */     this.fPattern = pattern;
/* 149 */     this.fLength = pattern.length();
/*     */     
/* 151 */     if (this.fIgnoreWildCards) {
/* 152 */       parseNoWildCards();
/*     */     } else {
/* 154 */       parseWildCards();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void usePrefixMatch() {
/* 171 */     this.fIgnoreWildCards = false;
/* 172 */     this.fHasTrailingStar = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Position find(String text, int start, int end) {
/* 202 */     if (text == null) {
/* 203 */       throw new IllegalArgumentException();
/*     */     }
/* 205 */     int tlen = text.length();
/* 206 */     if (start < 0) {
/* 207 */       start = 0;
/*     */     }
/* 209 */     if (end > tlen) {
/* 210 */       end = tlen;
/*     */     }
/* 212 */     if (end < 0 || start >= end) {
/* 213 */       return null;
/*     */     }
/* 215 */     if (this.fLength == 0) {
/* 216 */       return new Position(start, start);
/*     */     }
/* 218 */     if (this.fIgnoreWildCards) {
/* 219 */       int x = textPosIn(text, start, end, this.fPattern);
/* 220 */       return (x < 0) ? null : new Position(x, x + this.fLength);
/*     */     } 
/*     */     
/* 223 */     int segCount = this.fSegments.length;
/* 224 */     if (segCount == 0)
/*     */     {
/* 226 */       return new Position(start, end);
/*     */     }
/*     */     
/* 229 */     int curPos = start;
/* 230 */     int matchStart = -1;
/*     */     int i;
/* 232 */     for (i = 0; i < segCount && curPos < end; i++) {
/* 233 */       String current = this.fSegments[i];
/* 234 */       int nextMatch = regExpPosIn(text, curPos, end, current);
/* 235 */       if (nextMatch < 0) {
/* 236 */         return null;
/*     */       }
/* 238 */       if (i == 0) {
/* 239 */         matchStart = nextMatch;
/*     */       }
/* 241 */       curPos = nextMatch + current.length();
/*     */     } 
/* 243 */     return (i < segCount) ? null : new Position(matchStart, curPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String text) {
/* 255 */     if (text == null) {
/* 256 */       throw new IllegalArgumentException();
/*     */     }
/* 258 */     return match(text, 0, text.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String text, int start, int end) {
/* 275 */     if (text == null) {
/* 276 */       throw new IllegalArgumentException();
/*     */     }
/* 278 */     if (start > end) {
/* 279 */       return false;
/*     */     }
/* 281 */     if (this.fIgnoreWildCards) {
/* 282 */       return (end - start == this.fLength && this.fPattern.regionMatches(this.fIgnoreCase, 0, text, start, this.fLength));
/*     */     }
/*     */     
/* 285 */     int segCount = this.fSegments.length;
/* 286 */     if (segCount == 0 && (this.fHasLeadingStar || this.fHasTrailingStar))
/*     */     {
/* 288 */       return true;
/*     */     }
/* 290 */     if (start == end) {
/* 291 */       return (this.fLength == 0);
/*     */     }
/* 293 */     if (this.fLength == 0) {
/* 294 */       return (start == end);
/*     */     }
/*     */     
/* 297 */     int tlen = text.length();
/* 298 */     if (start < 0) {
/* 299 */       start = 0;
/*     */     }
/* 301 */     if (end > tlen) {
/* 302 */       end = tlen;
/*     */     }
/*     */     
/* 305 */     int tCurPos = start;
/* 306 */     int bound = end - this.fBound;
/* 307 */     if (bound < 0) {
/* 308 */       return false;
/*     */     }
/*     */     
/* 311 */     int i = 0;
/* 312 */     String current = this.fSegments[i];
/* 313 */     int segLength = current.length();
/*     */ 
/*     */     
/* 316 */     if (!this.fHasLeadingStar) {
/* 317 */       if (!regExpRegionMatches(text, start, current, segLength)) {
/* 318 */         return false;
/*     */       }
/* 320 */       i++;
/* 321 */       tCurPos += segLength;
/*     */     } 
/* 323 */     if (this.fSegments.length == 1 && !this.fHasLeadingStar && !this.fHasTrailingStar)
/*     */     {
/* 325 */       return (tCurPos == end);
/*     */     }
/*     */     
/* 328 */     while (i < segCount) {
/* 329 */       int currentMatch; current = this.fSegments[i];
/*     */       
/* 331 */       int k = current.indexOf(false);
/* 332 */       if (k < 0) {
/* 333 */         currentMatch = textPosIn(text, tCurPos, end, current);
/* 334 */         if (currentMatch < 0) {
/* 335 */           return false;
/*     */         }
/*     */       } else {
/* 338 */         currentMatch = regExpPosIn(text, tCurPos, end, current);
/* 339 */         if (currentMatch < 0) {
/* 340 */           return false;
/*     */         }
/*     */       } 
/* 343 */       tCurPos = currentMatch + current.length();
/* 344 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 348 */     if (!this.fHasTrailingStar && tCurPos != end) {
/* 349 */       int clen = current.length();
/* 350 */       return regExpRegionMatches(text, end - clen, current, clen);
/*     */     } 
/* 352 */     return (i == segCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseNoWildCards() {
/* 359 */     this.fSegments = new String[] { this.fPattern };
/* 360 */     this.fBound = this.fLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseWildCards() {
/* 367 */     if (this.fPattern.startsWith("*")) {
/* 368 */       this.fHasLeadingStar = true;
/*     */     }
/*     */     
/* 371 */     List<String> temp = new ArrayList<>();
/*     */     
/* 373 */     int pos = 0;
/* 374 */     StringBuilder buf = new StringBuilder();
/* 375 */     while (pos < this.fLength) {
/* 376 */       char next, c = this.fPattern.charAt(pos++);
/* 377 */       switch (c) {
/*     */         case '\\':
/* 379 */           if (pos >= this.fLength) {
/*     */             
/* 381 */             buf.append(c); continue;
/*     */           } 
/* 383 */           next = this.fPattern.charAt(pos++);
/* 384 */           if (next == '*' || next == '?' || next == '\\') {
/*     */             
/* 386 */             buf.append(next);
/*     */             continue;
/*     */           } 
/* 389 */           buf.append(c);
/* 390 */           buf.append(next);
/*     */           continue;
/*     */ 
/*     */         
/*     */         case '*':
/* 395 */           if (buf.length() > 0) {
/*     */             
/* 397 */             temp.add(buf.toString());
/* 398 */             this.fBound += buf.length();
/* 399 */             buf.setLength(0);
/*     */           } 
/* 401 */           if (pos >= this.fLength) {
/* 402 */             this.fHasTrailingStar = true;
/*     */           }
/*     */           continue;
/*     */         
/*     */         case '?':
/* 407 */           buf.append(false);
/*     */           continue;
/*     */       } 
/* 410 */       buf.append(c);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 415 */     if (buf.length() > 0) {
/* 416 */       temp.add(buf.toString());
/* 417 */       this.fBound += buf.length();
/*     */     } 
/*     */     
/* 420 */     this.fSegments = temp.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int textPosIn(String text, int start, int end, String p) {
/* 434 */     int plen = p.length();
/* 435 */     int max = end - plen;
/*     */     
/* 437 */     if (!this.fIgnoreCase) {
/* 438 */       int j = text.indexOf(p, start);
/* 439 */       if (j < 0 || j > max) {
/* 440 */         return -1;
/*     */       }
/* 442 */       return j;
/*     */     } 
/*     */     
/* 445 */     for (int i = start; i <= max; i++) {
/* 446 */       if (text.regionMatches(true, i, p, 0, plen)) {
/* 447 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 451 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int regExpPosIn(String text, int start, int end, String p) {
/* 466 */     int plen = p.length();
/* 467 */     int max = end - plen;
/*     */     
/* 469 */     for (int i = start; i <= max; i++) {
/* 470 */       if (regExpRegionMatches(text, i, p, plen)) {
/* 471 */         return i;
/*     */       }
/*     */     } 
/* 474 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean regExpRegionMatches(String text, int tStart, String p, int plen) {
/* 489 */     int pStart = 0;
/* 490 */     while (plen-- > 0) {
/* 491 */       char pchar = p.charAt(pStart++);
/* 492 */       if (pchar == '\000') {
/* 493 */         tStart++;
/*     */         continue;
/*     */       } 
/* 496 */       char tchar = text.charAt(tStart++);
/* 497 */       if (pchar == tchar) {
/*     */         continue;
/*     */       }
/* 500 */       if (this.fIgnoreCase) {
/* 501 */         if (Character.toUpperCase(tchar) == Character.toUpperCase(pchar)) {
/*     */           continue;
/*     */         }
/*     */         
/* 505 */         if (Character.toLowerCase(tchar) == Character.toLowerCase(pchar))
/*     */           continue; 
/*     */       } 
/* 508 */       return false;
/*     */     } 
/* 510 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 515 */     String flags = "";
/* 516 */     if (this.fIgnoreCase) {
/* 517 */       flags = String.valueOf(flags) + 'i';
/*     */     }
/* 519 */     if (this.fHasTrailingStar) {
/* 520 */       flags = String.valueOf(flags) + 't';
/*     */     }
/* 522 */     if (!this.fIgnoreWildCards) {
/* 523 */       flags = String.valueOf(flags) + '*';
/*     */     }
/* 525 */     String result = String.valueOf('[') + this.fPattern;
/* 526 */     if (!flags.isEmpty()) {
/* 527 */       result = String.valueOf(result) + '/' + flags;
/*     */     }
/* 529 */     return String.valueOf(result) + ']';
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\text\StringMatcher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */