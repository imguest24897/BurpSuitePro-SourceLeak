/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import org.eclipse.osgi.service.debug.DebugOptions;
/*    */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*    */ 
/*    */ public class TracingOptions {
/*  7 */   public static DebugOptionsListener DEBUG_OPTIONS_LISTENER = new DebugOptionsListener()
/*    */     {
/*    */       public void optionsChanged(DebugOptions options) {
/* 10 */         TracingOptions.debug = options.getBooleanOption("org.eclipse.equinox.common/debug", false);
/*    */         
/* 12 */         TracingOptions.debugProgressMonitors = (TracingOptions.debug && options.getBooleanOption("org.eclipse.equinox.common/progress_monitors", false));
/*    */       }
/*    */     };
/*    */   
/*    */   public static boolean debug;
/*    */   public static boolean debugProgressMonitors;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\TracingOptions.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */