/*      */ package org.eclipse.core.runtime;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Path
/*      */   implements IPath, Cloneable
/*      */ {
/*      */   private static final int HAS_LEADING = 1;
/*      */   private static final int IS_UNC = 2;
/*      */   private static final int HAS_TRAILING = 4;
/*      */   private static final int IS_FOR_WINDOWS = 8;
/*      */   private static final int ALL_SEPARATORS = 7;
/*      */   
/*      */   private static class Constants
/*      */   {
/*   56 */     static final boolean RUNNING_ON_WINDOWS = (File.separatorChar == '\\');
/*      */ 
/*      */     
/*   59 */     static final String[] NO_SEGMENTS = new String[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   public static final Path EMPTY = (Path)IPath.EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   public static final Path ROOT = (Path)IPath.ROOT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String device;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String[] segments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int hash;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte flags;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath fromOSString(String pathString) {
/*  120 */     return IPath.fromOSString(pathString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath fromPortableString(String pathString) {
/*  138 */     return IPath.fromPortableString(pathString);
/*      */   }
/*      */   
/*      */   static IPath parsePortableString(String pathString) {
/*  142 */     int firstMatch = pathString.indexOf(':') + 1;
/*      */     
/*  144 */     if (firstMatch <= 0) {
/*  145 */       return new Path(null, pathString, Constants.RUNNING_ON_WINDOWS);
/*      */     }
/*  147 */     String devicePart = null;
/*  148 */     int pathLength = pathString.length();
/*  149 */     if (firstMatch == pathLength || pathString.charAt(firstMatch) != ':') {
/*  150 */       devicePart = pathString.substring(0, firstMatch);
/*  151 */       pathString = pathString.substring(firstMatch, pathLength);
/*      */     } 
/*      */     
/*  154 */     if (pathString.indexOf(':') == -1) {
/*  155 */       return new Path(devicePart, pathString, Constants.RUNNING_ON_WINDOWS);
/*      */     }
/*  157 */     char[] chars = pathString.toCharArray();
/*  158 */     int readOffset = 0, writeOffset = 0, length = chars.length;
/*  159 */     while (readOffset < length && (
/*  160 */       chars[readOffset] != ':' || ++readOffset < length))
/*      */     {
/*      */       
/*  163 */       chars[writeOffset++] = chars[readOffset++];
/*      */     }
/*  165 */     return new Path(devicePart, new String(chars, 0, writeOffset), Constants.RUNNING_ON_WINDOWS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Path forPosix(String fullPath) {
/*  187 */     return (Path)IPath.forPosix(fullPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Path forWindows(String fullPath) {
/*  210 */     return (Path)IPath.forWindows(fullPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path(String fullPath) {
/*  228 */     this(fullPath, Constants.RUNNING_ON_WINDOWS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path(String device, String path) {
/*  246 */     this(device, backslashToForward(path, Constants.RUNNING_ON_WINDOWS), Constants.RUNNING_ON_WINDOWS);
/*      */   }
/*      */   
/*      */   private static String backslashToForward(String path, boolean forWindows) {
/*  250 */     if (forWindows)
/*      */     {
/*  252 */       return path.replace('\\', '/');
/*      */     }
/*  254 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Path(String fullPath, boolean forWindows) {
/*  271 */     String devicePart = null;
/*  272 */     if (forWindows) {
/*      */       
/*  274 */       fullPath = fullPath.replace('\\', '/');
/*      */       
/*  276 */       int i = fullPath.indexOf(':');
/*  277 */       if (i != -1) {
/*      */         
/*  279 */         int start = (fullPath.charAt(0) == '/') ? 1 : 0;
/*  280 */         devicePart = fullPath.substring(start, i + 1);
/*  281 */         fullPath = fullPath.substring(i + 1, fullPath.length());
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  288 */     Assert.isNotNull(fullPath);
/*  289 */     String collapsedPath = collapseSlashes(devicePart, fullPath);
/*  290 */     int flag = computeFlags(collapsedPath, forWindows);
/*      */     
/*  292 */     String[] canonicalSegments = canonicalize(((flag & 0x1) != 0), computeSegments(collapsedPath));
/*  293 */     if (canonicalSegments.length == 0)
/*      */     {
/*  295 */       flag &= 0xFFFFFFFB;
/*      */     }
/*  297 */     this.device = devicePart;
/*  298 */     this.segments = canonicalSegments;
/*  299 */     this.flags = (byte)flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path(String device, String[] segments, int flags) {
/*  306 */     int flag = flags;
/*  307 */     if (segments.length == 0)
/*      */     {
/*  309 */       flag &= 0xFFFFFFFB;
/*      */     }
/*      */     
/*  312 */     this.segments = segments;
/*  313 */     this.device = device;
/*  314 */     this.flags = (byte)flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath addFileExtension(String extension) {
/*  322 */     if (isRoot() || isEmpty() || hasTrailingSeparator())
/*  323 */       return this; 
/*  324 */     int len = this.segments.length;
/*  325 */     String[] newSegments = new String[len];
/*  326 */     System.arraycopy(this.segments, 0, newSegments, 0, len - 1);
/*  327 */     newSegments[len - 1] = String.valueOf(this.segments[len - 1]) + '.' + extension;
/*  328 */     return new Path(this.device, newSegments, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath addTrailingSeparator() {
/*  336 */     if (hasTrailingSeparator() || isRoot()) {
/*  337 */       return this;
/*      */     }
/*      */     
/*  340 */     if (isEmpty()) {
/*  341 */       return new Path(this.device, this.segments, this.flags & 0x8 | 0x1);
/*      */     }
/*  343 */     return new Path(this.device, this.segments, this.flags | 0x4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath append(IPath tail) {
/*  352 */     if (tail == null || tail.segmentCount() == 0) {
/*  353 */       return this;
/*      */     }
/*      */     
/*  356 */     if (isEmpty() && (((this.flags & 0x8) == 0)) == tail.isValidSegment(":"))
/*  357 */       return tail.setDevice(this.device).makeRelative().makeUNC(isUNC()); 
/*  358 */     if (isRoot() && (((this.flags & 0x8) == 0)) == tail.isValidSegment(":")) {
/*  359 */       return tail.setDevice(this.device).makeAbsolute().makeUNC(isUNC());
/*      */     }
/*      */     
/*  362 */     int myLen = this.segments.length;
/*  363 */     int tailLen = tail.segmentCount();
/*  364 */     String[] newSegments = new String[myLen + tailLen];
/*  365 */     System.arraycopy(this.segments, 0, newSegments, 0, myLen);
/*  366 */     for (int i = 0; i < tailLen; i++) {
/*  367 */       newSegments[myLen + i] = tail.segment(i);
/*      */     }
/*      */     
/*  370 */     String tailFirstSegment = newSegments[myLen];
/*  371 */     if (tailFirstSegment.equals("..") || tailFirstSegment.equals(".")) {
/*  372 */       newSegments = canonicalize(isAbsolute(), newSegments);
/*      */     }
/*  374 */     return new Path(this.device, newSegments, 
/*  375 */         this.flags & 0xB | (tail.hasTrailingSeparator() ? 4 : 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath append(String tail) {
/*  384 */     if (tail.indexOf('/') == -1 && tail.indexOf('\\') == -1 && tail.indexOf(':') == -1) {
/*  385 */       int tailLength = tail.length();
/*  386 */       if (tailLength < 3) {
/*      */         
/*  388 */         if (tailLength == 0 || ".".equals(tail)) {
/*  389 */           return this;
/*      */         }
/*  391 */         if ("..".equals(tail)) {
/*  392 */           return removeLastSegments(1);
/*      */         }
/*      */       } 
/*  395 */       int myLen = this.segments.length;
/*  396 */       String[] newSegments = new String[myLen + 1];
/*  397 */       System.arraycopy(this.segments, 0, newSegments, 0, myLen);
/*  398 */       newSegments[myLen] = tail;
/*  399 */       return new Path(this.device, newSegments, this.flags & 0xFFFFFFFB);
/*      */     } 
/*      */     
/*  402 */     return append(new Path(tail, ((this.flags & 0x8) != 0)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] canonicalize(boolean isAbsolute, String[] segments) {
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  416 */     for (i = (arrayOfString = segments).length, b = 0; b < i; ) { String segment = arrayOfString[b];
/*  417 */       if (segment.charAt(0) == '.' && (segment.equals("..") || segment.equals(".")))
/*      */       {
/*  419 */         return collapseParentReferences(isAbsolute, segments); } 
/*      */       b++; }
/*      */     
/*  422 */     return segments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() {
/*      */     try {
/*  431 */       return super.clone();
/*  432 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  433 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] collapseParentReferences(boolean isAbsolute, String[] segments) {
/*  441 */     int segmentCount = segments.length;
/*  442 */     String[] stack = new String[segmentCount];
/*  443 */     int stackPointer = 0;
/*  444 */     for (int i = 0; i < segmentCount; i++) {
/*  445 */       String segment = segments[i];
/*  446 */       if (segment.equals("..")) {
/*  447 */         if (stackPointer == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  452 */           if (!isAbsolute) {
/*  453 */             stack[stackPointer++] = segment;
/*      */           }
/*      */         }
/*  456 */         else if ("..".equals(stack[stackPointer - 1])) {
/*  457 */           stack[stackPointer++] = "..";
/*      */         } else {
/*  459 */           stackPointer--;
/*      */         }
/*      */       
/*      */       }
/*  463 */       else if (!segment.equals(".") || segmentCount == 1) {
/*  464 */         stack[stackPointer++] = segment;
/*      */       } 
/*      */     } 
/*  467 */     if (stackPointer == segmentCount) {
/*  468 */       return segments;
/*      */     }
/*  470 */     String[] newSegments = new String[stackPointer];
/*  471 */     System.arraycopy(stack, 0, newSegments, 0, stackPointer);
/*  472 */     return newSegments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String collapseSlashes(String device, String path) {
/*  480 */     int length = path.length();
/*      */ 
/*      */     
/*  483 */     if (length < 3) {
/*  484 */       return path;
/*      */     }
/*      */     
/*  487 */     if (path.indexOf("//", 1) == -1) {
/*  488 */       return path;
/*      */     }
/*  490 */     char[] result = new char[path.length()];
/*  491 */     int count = 0;
/*  492 */     boolean hasPrevious = false;
/*  493 */     char[] characters = path.toCharArray();
/*  494 */     for (int index = 0; index < characters.length; index++) {
/*  495 */       char c = characters[index];
/*  496 */       if (c == '/') {
/*  497 */         if (hasPrevious) {
/*      */ 
/*      */           
/*  500 */           if (device == null && index == 1) {
/*  501 */             result[count] = c;
/*  502 */             count++;
/*      */           } 
/*      */         } else {
/*  505 */           hasPrevious = true;
/*  506 */           result[count] = c;
/*  507 */           count++;
/*      */         } 
/*      */       } else {
/*  510 */         hasPrevious = false;
/*  511 */         result[count] = c;
/*  512 */         count++;
/*      */       } 
/*      */     } 
/*  515 */     return new String(result, 0, count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int computeHashCode(String device, String[] segments) {
/*  522 */     int hash = (device == null) ? 17 : device.hashCode();
/*  523 */     int segmentCount = segments.length;
/*  524 */     for (int i = 0; i < segmentCount; i++)
/*      */     {
/*  526 */       hash = hash * 37 + segments[i].hashCode();
/*      */     }
/*  528 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int computeLength() {
/*  535 */     int length = 0;
/*  536 */     if (this.device != null)
/*  537 */       length += this.device.length(); 
/*  538 */     if ((this.flags & 0x1) != 0)
/*  539 */       length++; 
/*  540 */     if ((this.flags & 0x2) != 0) {
/*  541 */       length++;
/*      */     }
/*  543 */     int max = this.segments.length;
/*  544 */     if (max > 0) {
/*  545 */       for (int i = 0; i < max; i++) {
/*  546 */         length += this.segments[i].length();
/*      */       }
/*      */       
/*  549 */       length += max - 1;
/*      */     } 
/*  551 */     if ((this.flags & 0x4) != 0)
/*  552 */       length++; 
/*  553 */     return length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int computeSegmentCount(String path) {
/*  560 */     int len = path.length();
/*  561 */     if (len == 0 || (len == 1 && path.charAt(0) == '/')) {
/*  562 */       return 0;
/*      */     }
/*  564 */     int count = 1;
/*  565 */     int prev = -1;
/*      */     int i;
/*  567 */     while ((i = path.indexOf('/', prev + 1)) != -1) {
/*  568 */       if (i != prev + 1 && i != len) {
/*  569 */         count++;
/*      */       }
/*  571 */       prev = i;
/*      */     } 
/*  573 */     if (path.charAt(len - 1) == '/') {
/*  574 */       count--;
/*      */     }
/*  576 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] computeSegments(String path) {
/*  584 */     int segmentCount = computeSegmentCount(path);
/*  585 */     if (segmentCount == 0)
/*  586 */       return Constants.NO_SEGMENTS; 
/*  587 */     String[] newSegments = new String[segmentCount];
/*  588 */     int len = path.length();
/*      */     
/*  590 */     int firstPosition = (path.charAt(0) == '/') ? 1 : 0;
/*      */     
/*  592 */     if (firstPosition == 1 && len > 1 && path.charAt(1) == '/')
/*  593 */       firstPosition = 2; 
/*  594 */     int lastPosition = (path.charAt(len - 1) != '/') ? (len - 1) : (len - 2);
/*      */ 
/*      */ 
/*      */     
/*  598 */     int next = firstPosition;
/*  599 */     for (int i = 0; i < segmentCount; i++) {
/*  600 */       int start = next;
/*  601 */       int end = path.indexOf('/', next);
/*  602 */       if (end == -1) {
/*  603 */         newSegments[i] = path.substring(start, lastPosition + 1);
/*      */       } else {
/*  605 */         newSegments[i] = path.substring(start, end);
/*      */       } 
/*  607 */       next = end + 1;
/*      */     } 
/*  609 */     return newSegments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void encodeSegment(String string, StringBuilder buf) {
/*  617 */     int len = string.length();
/*  618 */     for (int i = 0; i < len; i++) {
/*  619 */       char c = string.charAt(i);
/*  620 */       buf.append(c);
/*  621 */       if (c == ':') {
/*  622 */         buf.append(':');
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  631 */     if (this == obj)
/*  632 */       return true; 
/*  633 */     if (!(obj instanceof Path))
/*  634 */       return false; 
/*  635 */     Path target = (Path)obj;
/*      */     
/*  637 */     if ((this.flags & 0x3) != (target.flags & 0x3)) {
/*  638 */       return false;
/*      */     }
/*  640 */     String[] targetSegments = target.segments;
/*  641 */     int i = this.segments.length;
/*      */     
/*  643 */     if (i != targetSegments.length) {
/*  644 */       return false;
/*      */     }
/*  646 */     while (--i >= 0) {
/*  647 */       if (!this.segments[i].equals(targetSegments[i]))
/*  648 */         return false; 
/*      */     } 
/*  650 */     return !(this.device != target.device && (this.device == null || !this.device.equals(target.device)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDevice() {
/*  658 */     return this.device;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFileExtension() {
/*  666 */     if (hasTrailingSeparator()) {
/*  667 */       return null;
/*      */     }
/*  669 */     String lastSegment = lastSegment();
/*  670 */     if (lastSegment == null) {
/*  671 */       return null;
/*      */     }
/*  673 */     int index = lastSegment.lastIndexOf('.');
/*  674 */     if (index == -1) {
/*  675 */       return null;
/*      */     }
/*  677 */     return lastSegment.substring(index + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  685 */     int h = this.hash;
/*  686 */     if (h == 0) {
/*  687 */       this.hash = h = computeHashCode(this.device, this.segments);
/*      */     }
/*  689 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTrailingSeparator() {
/*  697 */     return ((this.flags & 0x4) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path(String deviceString, String path, boolean forWindows) {
/*  705 */     Assert.isNotNull(path);
/*  706 */     String collapsedPath = collapseSlashes(deviceString, path);
/*  707 */     int flag = computeFlags(collapsedPath, forWindows);
/*      */     
/*  709 */     String[] canonicalSegments = canonicalize(((flag & 0x1) != 0), computeSegments(collapsedPath));
/*  710 */     if (canonicalSegments.length == 0)
/*      */     {
/*  712 */       flag &= 0xFFFFFFFB;
/*      */     }
/*  714 */     this.device = deviceString;
/*  715 */     this.segments = canonicalSegments;
/*  716 */     this.flags = (byte)flag;
/*      */   }
/*      */   
/*      */   private static int computeFlags(String path, boolean forWindows) {
/*  720 */     int flags, len = path.length();
/*      */ 
/*      */     
/*  723 */     if (len < 2) {
/*  724 */       if (len == 1 && path.charAt(0) == '/') {
/*  725 */         flags = 1;
/*      */       } else {
/*  727 */         flags = 0;
/*      */       } 
/*      */     } else {
/*  730 */       boolean hasLeading = (path.charAt(0) == '/');
/*  731 */       boolean isUNC = (hasLeading && path.charAt(1) == '/');
/*      */       
/*  733 */       boolean hasTrailing = ((!isUNC || len != 2) && path.charAt(len - 1) == '/');
/*  734 */       flags = hasLeading ? 1 : 0;
/*  735 */       if (isUNC)
/*  736 */         flags |= 0x2; 
/*  737 */       if (hasTrailing)
/*  738 */         flags |= 0x4; 
/*      */     } 
/*  740 */     if (forWindows) {
/*  741 */       flags |= 0x8;
/*      */     }
/*  743 */     return flags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAbsolute() {
/*  752 */     return ((this.flags & 0x1) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  761 */     return (this.segments.length == 0 && (this.flags & 0x7) != 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPrefixOf(IPath anotherPath) {
/*  769 */     if (this.device == null) {
/*  770 */       if (anotherPath.getDevice() != null) {
/*  771 */         return false;
/*      */       }
/*      */     }
/*  774 */     else if (!this.device.equalsIgnoreCase(anotherPath.getDevice())) {
/*  775 */       return false;
/*      */     } 
/*      */     
/*  778 */     if (isEmpty() || (isRoot() && anotherPath.isAbsolute())) {
/*  779 */       return true;
/*      */     }
/*  781 */     int len = this.segments.length;
/*  782 */     if (len > anotherPath.segmentCount()) {
/*  783 */       return false;
/*      */     }
/*  785 */     for (int i = 0; i < len; i++) {
/*  786 */       if (!this.segments[i].equals(anotherPath.segment(i)))
/*  787 */         return false; 
/*      */     } 
/*  789 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRoot() {
/*  798 */     return !(this != ROOT && (this.segments.length != 0 || (this.flags & 0x7) != 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUNC() {
/*  806 */     if (this.device != null)
/*  807 */       return false; 
/*  808 */     return ((this.flags & 0x2) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isValidPath(String path) {
/*  816 */     return isValidPath(path, ((this.flags & 0x8) != 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidPosixPath(String path) {
/*  831 */     return isValidPath(path, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidWindowsPath(String path) {
/*  849 */     return isValidPath(path, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isValidPath(String path, boolean forWindows) {
/*  870 */     Path test = new Path(path, forWindows);
/*  871 */     for (int i = 0, max = test.segmentCount(); i < max; i++) {
/*  872 */       if (!isValidSegment(test.segment(i), forWindows))
/*  873 */         return false; 
/*  874 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isValidSegment(String segment) {
/*  882 */     return isValidSegment(segment, ((this.flags & 0x8) != 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidPosixSegment(String segment) {
/*  899 */     return isValidSegment(segment, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidWindowsSegment(String segment) {
/*  918 */     return isValidSegment(segment, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isValidSegment(String segment, boolean forWindows) {
/*  939 */     int size = segment.length();
/*  940 */     if (size == 0)
/*  941 */       return false; 
/*  942 */     for (int i = 0; i < size; i++) {
/*  943 */       char c = segment.charAt(i);
/*  944 */       if (c == '/')
/*  945 */         return false; 
/*  946 */       if (forWindows && (c == '\\' || c == ':'))
/*  947 */         return false; 
/*      */     } 
/*  949 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String lastSegment() {
/*  957 */     int len = this.segments.length;
/*  958 */     return (len == 0) ? null : this.segments[len - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath makeAbsolute() {
/*  966 */     if (isAbsolute()) {
/*  967 */       return this;
/*      */     }
/*  969 */     String[] newSegments = this.segments;
/*      */     
/*  971 */     if (this.segments.length > 0) {
/*  972 */       String first = this.segments[0];
/*  973 */       if (first.equals("..") || first.equals(".")) {
/*  974 */         newSegments = canonicalize(true, this.segments);
/*      */       }
/*      */     } 
/*  977 */     return new Path(this.device, newSegments, this.flags | 0x1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath makeRelative() {
/*  985 */     if (!isAbsolute()) {
/*  986 */       return this;
/*      */     }
/*  988 */     return new Path(this.device, this.segments, this.flags & 0xC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath makeRelativeTo(IPath base) {
/*  998 */     if (this.device != base.getDevice() && (this.device == null || !this.device.equalsIgnoreCase(base.getDevice())))
/*  999 */       return this; 
/* 1000 */     int commonLength = matchingFirstSegments(base);
/* 1001 */     int differenceLength = base.segmentCount() - commonLength;
/* 1002 */     int newSegmentLength = differenceLength + segmentCount() - commonLength;
/* 1003 */     if (newSegmentLength == 0)
/* 1004 */       return EMPTY; 
/* 1005 */     String[] newSegments = new String[newSegmentLength];
/*      */     
/* 1007 */     Arrays.fill((Object[])newSegments, 0, differenceLength, "..");
/*      */     
/* 1009 */     System.arraycopy(this.segments, commonLength, newSegments, differenceLength, newSegmentLength - differenceLength);
/* 1010 */     return new Path(null, newSegments, this.flags & 0xC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath makeUNC(boolean toUNC) {
/* 1019 */     if (!(toUNC ^ isUNC())) {
/* 1020 */       return this;
/*      */     }
/* 1022 */     int newSeparators = this.flags;
/* 1023 */     if (toUNC) {
/* 1024 */       newSeparators |= 0x3;
/*      */     } else {
/*      */       
/* 1027 */       newSeparators &= 0xD;
/*      */     } 
/* 1029 */     return new Path(toUNC ? null : this.device, this.segments, newSeparators);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int matchingFirstSegments(IPath anotherPath) {
/* 1037 */     Assert.isNotNull(anotherPath);
/* 1038 */     int anotherPathLen = anotherPath.segmentCount();
/* 1039 */     int max = Math.min(this.segments.length, anotherPathLen);
/* 1040 */     int count = 0;
/* 1041 */     for (int i = 0; i < max; i++) {
/* 1042 */       if (!this.segments[i].equals(anotherPath.segment(i))) {
/* 1043 */         return count;
/*      */       }
/* 1045 */       count++;
/*      */     } 
/* 1047 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath removeFileExtension() {
/* 1055 */     String extension = getFileExtension();
/* 1056 */     if (extension == null || extension.equals("")) {
/* 1057 */       return this;
/*      */     }
/* 1059 */     String lastSegment = lastSegment();
/* 1060 */     int index = lastSegment.lastIndexOf(extension) - 1;
/* 1061 */     return removeLastSegments(1).append(lastSegment.substring(0, index));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath removeFirstSegments(int count) {
/* 1069 */     if (count == 0)
/* 1070 */       return this; 
/* 1071 */     if (count >= this.segments.length) {
/* 1072 */       return new Path(this.device, Constants.NO_SEGMENTS, this.flags & 0x8);
/*      */     }
/* 1074 */     Assert.isLegal((count > 0));
/* 1075 */     int newSize = this.segments.length - count;
/* 1076 */     String[] newSegments = new String[newSize];
/* 1077 */     System.arraycopy(this.segments, count, newSegments, 0, newSize);
/*      */ 
/*      */     
/* 1080 */     return new Path(this.device, newSegments, this.flags & 0xC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath removeLastSegments(int count) {
/* 1088 */     if (count == 0)
/* 1089 */       return this; 
/* 1090 */     if (count >= this.segments.length)
/*      */     {
/* 1092 */       return new Path(this.device, Constants.NO_SEGMENTS, this.flags & 0xB);
/*      */     }
/* 1094 */     Assert.isLegal((count > 0));
/* 1095 */     int newSize = this.segments.length - count;
/* 1096 */     String[] newSegments = new String[newSize];
/* 1097 */     System.arraycopy(this.segments, 0, newSegments, 0, newSize);
/* 1098 */     return new Path(this.device, newSegments, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath removeTrailingSeparator() {
/* 1106 */     if (!hasTrailingSeparator()) {
/* 1107 */       return this;
/*      */     }
/* 1109 */     return new Path(this.device, this.segments, this.flags & 0xB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String segment(int index) {
/* 1117 */     if (index >= this.segments.length)
/* 1118 */       return null; 
/* 1119 */     return this.segments[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int segmentCount() {
/* 1127 */     return this.segments.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] segments() {
/* 1135 */     String[] segmentCopy = new String[this.segments.length];
/* 1136 */     System.arraycopy(this.segments, 0, segmentCopy, 0, this.segments.length);
/* 1137 */     return segmentCopy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath setDevice(String value) {
/* 1145 */     if (value != null) {
/* 1146 */       Assert.isTrue((value.indexOf(':') == value.length() - 1), "Last character should be the device separator");
/*      */     }
/*      */     
/* 1149 */     if (value == this.device || (value != null && value.equals(this.device))) {
/* 1150 */       return this;
/*      */     }
/* 1152 */     return new Path(value, this.segments, this.flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File toFile() {
/* 1160 */     return new File(toOSString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toOSString() {
/* 1170 */     int resultSize = computeLength();
/* 1171 */     if (resultSize <= 0)
/* 1172 */       return ""; 
/* 1173 */     char FILE_SEPARATOR = File.separatorChar;
/* 1174 */     char[] result = new char[resultSize];
/* 1175 */     int offset = 0;
/* 1176 */     if (this.device != null) {
/* 1177 */       int size = this.device.length();
/* 1178 */       this.device.getChars(0, size, result, offset);
/* 1179 */       offset += size;
/*      */     } 
/* 1181 */     if ((this.flags & 0x1) != 0)
/* 1182 */       result[offset++] = FILE_SEPARATOR; 
/* 1183 */     if ((this.flags & 0x2) != 0)
/* 1184 */       result[offset++] = FILE_SEPARATOR; 
/* 1185 */     int len = this.segments.length - 1;
/* 1186 */     if (len >= 0) {
/*      */       
/* 1188 */       for (int i = 0; i < len; i++) {
/* 1189 */         int j = this.segments[i].length();
/* 1190 */         this.segments[i].getChars(0, j, result, offset);
/* 1191 */         offset += j;
/* 1192 */         result[offset++] = FILE_SEPARATOR;
/*      */       } 
/*      */       
/* 1195 */       int size = this.segments[len].length();
/* 1196 */       this.segments[len].getChars(0, size, result, offset);
/* 1197 */       offset += size;
/*      */     } 
/* 1199 */     if ((this.flags & 0x4) != 0)
/* 1200 */       result[offset++] = FILE_SEPARATOR; 
/* 1201 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toPortableString() {
/* 1209 */     int resultSize = computeLength();
/* 1210 */     if (resultSize <= 0)
/* 1211 */       return ""; 
/* 1212 */     StringBuilder result = new StringBuilder(resultSize);
/* 1213 */     if (this.device != null)
/* 1214 */       result.append(this.device); 
/* 1215 */     if ((this.flags & 0x1) != 0)
/* 1216 */       result.append('/'); 
/* 1217 */     if ((this.flags & 0x2) != 0)
/* 1218 */       result.append('/'); 
/* 1219 */     int len = this.segments.length;
/*      */     
/* 1221 */     for (int i = 0; i < len; i++) {
/* 1222 */       if (this.segments[i].indexOf(':') >= 0) {
/* 1223 */         encodeSegment(this.segments[i], result);
/*      */       } else {
/* 1225 */         result.append(this.segments[i]);
/* 1226 */       }  if (i < len - 1 || (this.flags & 0x4) != 0)
/* 1227 */         result.append('/'); 
/*      */     } 
/* 1229 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1237 */     int resultSize = computeLength();
/* 1238 */     if (resultSize <= 0)
/* 1239 */       return ""; 
/* 1240 */     char[] result = new char[resultSize];
/* 1241 */     int offset = 0;
/* 1242 */     if (this.device != null) {
/* 1243 */       int size = this.device.length();
/* 1244 */       this.device.getChars(0, size, result, offset);
/* 1245 */       offset += size;
/*      */     } 
/* 1247 */     if ((this.flags & 0x1) != 0)
/* 1248 */       result[offset++] = '/'; 
/* 1249 */     if ((this.flags & 0x2) != 0)
/* 1250 */       result[offset++] = '/'; 
/* 1251 */     int len = this.segments.length - 1;
/* 1252 */     if (len >= 0) {
/*      */       
/* 1254 */       for (int i = 0; i < len; i++) {
/* 1255 */         int j = this.segments[i].length();
/* 1256 */         this.segments[i].getChars(0, j, result, offset);
/* 1257 */         offset += j;
/* 1258 */         result[offset++] = '/';
/*      */       } 
/*      */       
/* 1261 */       int size = this.segments[len].length();
/* 1262 */       this.segments[len].getChars(0, size, result, offset);
/* 1263 */       offset += size;
/*      */     } 
/* 1265 */     if ((this.flags & 0x4) != 0)
/* 1266 */       result[offset++] = '/'; 
/* 1267 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath uptoSegment(int count) {
/* 1275 */     if (count == 0)
/* 1276 */       return new Path(this.device, Constants.NO_SEGMENTS, this.flags & 0xB); 
/* 1277 */     if (count >= this.segments.length)
/* 1278 */       return this; 
/* 1279 */     Assert.isTrue((count > 0), "Invalid parameter to Path.uptoSegment");
/* 1280 */     String[] newSegments = new String[count];
/* 1281 */     System.arraycopy(this.segments, 0, newSegments, 0, count);
/* 1282 */     return new Path(this.device, newSegments, this.flags);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\Path.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */