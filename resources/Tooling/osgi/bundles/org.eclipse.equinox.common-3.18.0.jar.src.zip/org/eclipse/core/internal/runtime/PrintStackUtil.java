/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintStackUtil
/*    */ {
/*    */   public static void printChildren(IStatus status, PrintStream output) {
/* 23 */     IStatus[] children = status.getChildren();
/* 24 */     if (children == null || children.length == 0)
/*    */       return;  byte b; int i; IStatus[] arrayOfIStatus1;
/* 26 */     for (i = (arrayOfIStatus1 = children).length, b = 0; b < i; ) { IStatus child = arrayOfIStatus1[b];
/* 27 */       output.println("Contains: " + child.getMessage());
/* 28 */       Throwable exception = child.getException();
/* 29 */       if (exception != null)
/* 30 */         exception.printStackTrace(output); 
/* 31 */       printChildren(child, output);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public static void printChildren(IStatus status, PrintWriter output) {
/* 36 */     IStatus[] children = status.getChildren();
/* 37 */     if (children == null || children.length == 0)
/*    */       return;  byte b; int i; IStatus[] arrayOfIStatus1;
/* 39 */     for (i = (arrayOfIStatus1 = children).length, b = 0; b < i; ) { IStatus child = arrayOfIStatus1[b];
/* 40 */       output.println("Contains: " + child.getMessage());
/* 41 */       output.flush();
/* 42 */       Throwable exception = child.getException();
/* 43 */       if (exception != null)
/* 44 */         exception.printStackTrace(output); 
/* 45 */       printChildren(child, output);
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PrintStackUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */