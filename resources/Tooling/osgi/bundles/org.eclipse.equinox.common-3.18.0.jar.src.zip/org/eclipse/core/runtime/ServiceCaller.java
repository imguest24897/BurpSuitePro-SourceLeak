/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceCaller<S>
/*     */ {
/*     */   private final Bundle bundle;
/*     */   private final Class<S> serviceType;
/*     */   private final String filter;
/*     */   
/*     */   public static <S> boolean callOnce(Class<?> caller, Class<S> serviceType, Consumer<S> consumer) {
/* 140 */     return callOnce(caller, serviceType, null, consumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> boolean callOnce(Class<?> caller, Class<S> serviceType, String filter, Consumer<S> consumer) {
/* 158 */     return ((Boolean)(new ServiceCaller(caller, serviceType, filter)).getCurrent().map(r -> {
/*     */           try {
/*     */             paramConsumer.accept(r.instance);
/*     */             return Boolean.TRUE;
/*     */           } finally {
/*     */             r.unget();
/*     */           } 
/* 165 */         }).orElse(Boolean.FALSE)).booleanValue();
/*     */   }
/*     */   
/*     */   private static int getRank(ServiceReference<?> ref) {
/* 169 */     Object rank = ref.getProperty("service.ranking");
/* 170 */     if (rank instanceof Integer) {
/* 171 */       return ((Integer)rank).intValue();
/*     */     }
/* 173 */     return 0;
/*     */   }
/*     */   
/*     */   private class ReferenceAndService implements SynchronousBundleListener, ServiceListener {
/*     */     final BundleContext context;
/*     */     final ServiceReference<S> ref;
/*     */     final S instance;
/*     */     final int rank;
/*     */     
/*     */     public ReferenceAndService(BundleContext context, ServiceReference<S> ref, S instance) {
/* 183 */       this.context = context;
/* 184 */       this.ref = ref;
/* 185 */       this.instance = instance;
/* 186 */       this.rank = ServiceCaller.getRank(ref);
/*     */     }
/*     */     
/*     */     void unget() {
/* 190 */       untrack();
/*     */       try {
/* 192 */         this.context.ungetService(this.ref);
/* 193 */       } catch (IllegalStateException illegalStateException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void bundleChanged(BundleEvent e) {
/* 200 */       if (ServiceCaller.this.bundle.equals(e.getBundle()) && e.getType() == 256) {
/* 201 */         unget();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void serviceChanged(ServiceEvent e) {
/* 207 */       if (requiresUnget(e)) {
/* 208 */         unget();
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean requiresUnget(ServiceEvent e) {
/* 213 */       if (e.getServiceReference().equals(this.ref)) {
/* 214 */         return !(e.getType() != 4 && (
/* 215 */           ServiceCaller.this.filter == null || e.getType() != 8) && (
/* 216 */           e.getType() != 2 || ServiceCaller.getRank(this.ref) == this.rank));
/*     */       }
/*     */       
/* 219 */       return (e.getType() == 2 && ServiceCaller.getRank(e.getServiceReference()) > this.rank);
/*     */     }
/*     */ 
/*     */     
/*     */     Optional<ReferenceAndService> track() {
/*     */       try {
/* 225 */         ServiceCaller.this.service = this;
/* 226 */         this.context.addServiceListener(this, "(&(objectClass=" + 
/* 227 */             ServiceCaller.this.serviceType.getName() + ")" + (
/* 228 */             (ServiceCaller.this.filter == null) ? "" : ServiceCaller.this.filter) + 
/* 229 */             ")");
/* 230 */         this.context.addBundleListener((BundleListener)this);
/* 231 */         if ((this.ref.getBundle() == null || this.context.getBundle() == null) && ServiceCaller.this.service == this)
/*     */         {
/*     */           
/* 234 */           unget();
/*     */         }
/* 236 */         if (ServiceCaller.getRank(this.ref) != this.rank)
/*     */         {
/*     */           
/* 239 */           unget();
/*     */         }
/* 241 */       } catch (InvalidSyntaxException e) {
/*     */         
/* 243 */         ServiceCaller.this.service = null;
/* 244 */         throw new IllegalStateException(e);
/* 245 */       } catch (IllegalStateException illegalStateException) {
/*     */         
/* 247 */         ServiceCaller.this.service = null;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       return Optional.of(this);
/*     */     }
/*     */     
/*     */     void untrack() {
/* 258 */       synchronized (ServiceCaller.this) {
/* 259 */         if (ServiceCaller.this.service == this) {
/* 260 */           ServiceCaller.this.service = null;
/*     */         }
/*     */         try {
/* 263 */           this.context.removeServiceListener(this);
/* 264 */           this.context.removeBundleListener((BundleListener)this);
/* 265 */         } catch (IllegalStateException illegalStateException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   private volatile ReferenceAndService service = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceCaller(Class<?> caller, Class<S> serviceType) {
/* 289 */     this(caller, serviceType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceCaller(Class<?> caller, Class<S> serviceType, String filter) {
/* 305 */     this.serviceType = Objects.<Class<S>>requireNonNull(serviceType);
/* 306 */     this.bundle = (Bundle)Optional.<Class<?>>of(Objects.<Class<?>>requireNonNull(caller)).map(FrameworkUtil::getBundle)
/* 307 */       .orElseThrow(IllegalStateException::new);
/* 308 */     this.filter = filter;
/* 309 */     if (filter != null) {
/*     */       try {
/* 311 */         FrameworkUtil.createFilter(filter);
/* 312 */       } catch (InvalidSyntaxException e) {
/* 313 */         throw new IllegalArgumentException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private BundleContext getContext() {
/* 319 */     if (System.getSecurityManager() != null) {
/* 320 */       return AccessController.<BundleContext>doPrivileged(() -> this.bundle.getBundleContext());
/*     */     }
/* 322 */     return this.bundle.getBundleContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean call(Consumer<S> consumer) {
/* 350 */     return ((Boolean)trackCurrent().<Boolean>map(r -> {
/*     */           paramConsumer.accept(r.instance);
/*     */           return Boolean.TRUE;
/* 353 */         }).orElse(Boolean.FALSE)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<S> current() {
/* 363 */     return trackCurrent().map(r -> r.instance);
/*     */   }
/*     */   
/*     */   private Optional<ReferenceAndService> trackCurrent() {
/* 367 */     ReferenceAndService current = this.service;
/* 368 */     if (current != null) {
/* 369 */       return Optional.of(current);
/*     */     }
/* 371 */     return getCurrent().flatMap(r -> {
/*     */           synchronized (this) {
/*     */             if (this.service != null) {
/*     */               r.unget();
/*     */               return Optional.of(this.service);
/*     */             } 
/*     */             return r.track();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<ReferenceAndService> getCurrent() {
/* 386 */     BundleContext context = getContext();
/* 387 */     return getServiceReference(context).map(r -> {
/*     */           S current = (S)paramBundleContext.getService(r);
/*     */           return (current == null) ? null : new ReferenceAndService(paramBundleContext, r, current);
/*     */         });
/*     */   }
/*     */   
/*     */   private Optional<ServiceReference<S>> getServiceReference(BundleContext context) {
/* 394 */     if (context == null) {
/* 395 */       return Optional.empty();
/*     */     }
/* 397 */     if (this.filter == null) {
/* 398 */       return Optional.ofNullable(context.getServiceReference(this.serviceType));
/*     */     }
/*     */     try {
/* 401 */       return context.getServiceReferences(this.serviceType, this.filter).stream().findFirst();
/* 402 */     } catch (InvalidSyntaxException invalidSyntaxException) {
/*     */       
/* 404 */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unget() {
/* 414 */     ReferenceAndService current = this.service;
/* 415 */     if (current != null)
/* 416 */       current.unget(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\ServiceCaller.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */