/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.ref.WeakReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceHashSet<T>
/*     */ {
/*     */   HashedReference<T>[] values;
/*     */   public int elementSize;
/*     */   int threshold;
/*     */   
/*     */   private class HashableWeakReference<U>
/*     */     extends WeakReference<U>
/*     */     implements HashedReference<U>
/*     */   {
/*     */     public int hashCode;
/*     */     
/*     */     public HashableWeakReference(U referent, ReferenceQueue<? super U> queue) {
/*  37 */       super(referent, queue);
/*  38 */       this.hashCode = referent.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  43 */       if (!(obj instanceof HashableWeakReference))
/*  44 */         return false; 
/*  45 */       U referent = (U)get();
/*     */       
/*  47 */       Object other = ((HashableWeakReference)obj).get();
/*  48 */       if (referent == null)
/*  49 */         return (other == null); 
/*  50 */       return referent.equals(other);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  55 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  60 */       Object referent = get();
/*  61 */       if (referent == null)
/*  62 */         return "[hashCode=" + this.hashCode + "] <referent was garbage collected>"; 
/*  63 */       return "[hashCode=" + this.hashCode + "] " + referent;
/*     */     }
/*     */   }
/*     */   
/*     */   private class HashableSoftReference<U> extends SoftReference<U> implements HashedReference<U> {
/*     */     public int hashCode;
/*     */     
/*     */     public HashableSoftReference(U referent, ReferenceQueue<? super U> queue) {
/*  71 */       super(referent, queue);
/*  72 */       this.hashCode = referent.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  77 */       if (!(obj instanceof HashableSoftReference))
/*  78 */         return false; 
/*  79 */       Object referent = get();
/*     */       
/*  81 */       Object other = ((HashableSoftReference)obj).get();
/*  82 */       if (referent == null)
/*  83 */         return (other == null); 
/*  84 */       return referent.equals(other);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  89 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  94 */       Object referent = get();
/*  95 */       if (referent == null)
/*  96 */         return "[hashCode=" + this.hashCode + "] <referent was garbage collected>"; 
/*  97 */       return "[hashCode=" + this.hashCode + "] " + referent;
/*     */     }
/*     */   }
/*     */   
/*     */   private class StrongReference<U> implements HashedReference<U> {
/*     */     private U referent;
/*     */     
/*     */     public StrongReference(U referent, ReferenceQueue<? super U> queue) {
/* 105 */       this.referent = referent;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 110 */       return this.referent.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public U get() {
/* 115 */       return this.referent;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 120 */       return this.referent.equals(obj);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   ReferenceQueue<T> referenceQueue = new ReferenceQueue<>(); public static final int HARD = 0;
/*     */   
/*     */   public ReferenceHashSet() {
/* 133 */     this(5);
/*     */   }
/*     */   public static final int SOFT = 1; public static final int WEAK = 2;
/*     */   
/*     */   public ReferenceHashSet(int size) {
/* 138 */     this.elementSize = 0;
/* 139 */     this.threshold = size;
/*     */     
/* 141 */     int extraRoom = (int)(size * 1.75F);
/* 142 */     if (this.threshold == extraRoom)
/* 143 */       extraRoom++; 
/* 144 */     this.values = (HashedReference<T>[])new HashedReference[extraRoom];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashedReference<T> toReference(int type, T referent) {
/* 163 */     switch (type) {
/*     */       case 0:
/* 165 */         return new StrongReference<>(referent, this.referenceQueue);
/*     */       case 1:
/* 167 */         return new HashableSoftReference<>(referent, this.referenceQueue);
/*     */       case 2:
/* 169 */         return new HashableWeakReference<>(referent, this.referenceQueue);
/*     */     } 
/* 171 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T add(T obj, int referenceType) {
/* 181 */     cleanupGarbageCollectedValues();
/* 182 */     int index = (obj.hashCode() & Integer.MAX_VALUE) % this.values.length;
/*     */     HashedReference<T> currentValue;
/* 184 */     while ((currentValue = this.values[index]) != null) {
/*     */       T referent;
/* 186 */       if (obj.equals(referent = currentValue.get())) {
/* 187 */         return referent;
/*     */       }
/* 189 */       index = (index + 1) % this.values.length;
/*     */     } 
/* 191 */     this.values[index] = toReference(referenceType, obj);
/*     */ 
/*     */     
/* 194 */     if (++this.elementSize > this.threshold) {
/* 195 */       rehash();
/*     */     }
/* 197 */     return obj;
/*     */   }
/*     */   
/*     */   private void addValue(HashedReference<T> value) {
/* 201 */     Object obj = value.get();
/* 202 */     if (obj == null)
/*     */       return; 
/* 204 */     int valuesLength = this.values.length;
/* 205 */     int index = (value.hashCode() & Integer.MAX_VALUE) % valuesLength;
/*     */     HashedReference<T> currentValue;
/* 207 */     while ((currentValue = this.values[index]) != null) {
/* 208 */       if (obj.equals(currentValue.get())) {
/*     */         return;
/*     */       }
/* 211 */       index = (index + 1) % valuesLength;
/*     */     } 
/* 213 */     this.values[index] = value;
/*     */ 
/*     */     
/* 216 */     if (++this.elementSize > this.threshold)
/* 217 */       rehash(); 
/*     */   }
/*     */   
/*     */   private void cleanupGarbageCollectedValues() {
/*     */     HashedReference<?> toBeRemoved;
/* 222 */     while ((toBeRemoved = (HashedReference)this.referenceQueue.poll()) != null) {
/* 223 */       int hashCode = toBeRemoved.hashCode();
/* 224 */       int valuesLength = this.values.length;
/* 225 */       int index = (hashCode & Integer.MAX_VALUE) % valuesLength;
/*     */       HashedReference<T> currentValue;
/* 227 */       while ((currentValue = this.values[index]) != null) {
/* 228 */         if (currentValue == toBeRemoved) {
/*     */ 
/*     */           
/* 231 */           int sameHash = index;
/*     */           int current;
/* 233 */           while ((currentValue = this.values[current = (sameHash + 1) % valuesLength]) != null && currentValue.hashCode() == hashCode)
/* 234 */             sameHash = current; 
/* 235 */           this.values[index] = this.values[sameHash];
/* 236 */           this.values[sameHash] = null;
/* 237 */           this.elementSize--;
/*     */           break;
/*     */         } 
/* 240 */         index = (index + 1) % valuesLength;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean contains(T obj) {
/* 246 */     return (get(obj) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(T obj) {
/* 254 */     cleanupGarbageCollectedValues();
/* 255 */     int valuesLength = this.values.length;
/* 256 */     int index = (obj.hashCode() & Integer.MAX_VALUE) % valuesLength;
/*     */     HashedReference<T> currentValue;
/* 258 */     while ((currentValue = this.values[index]) != null) {
/*     */       T referent;
/* 260 */       if (obj.equals(referent = currentValue.get())) {
/* 261 */         return referent;
/*     */       }
/* 263 */       index = (index + 1) % valuesLength;
/*     */     } 
/* 265 */     return null;
/*     */   }
/*     */   
/*     */   private void rehash() {
/* 269 */     ReferenceHashSet<T> newHashSet = new ReferenceHashSet(this.elementSize * 2);
/* 270 */     newHashSet.referenceQueue = this.referenceQueue; byte b; int i;
/*     */     HashedReference<T>[] arrayOfHashedReference;
/* 272 */     for (i = (arrayOfHashedReference = this.values).length, b = 0; b < i; ) { HashedReference<T> value = arrayOfHashedReference[b]; HashedReference<T> currentValue;
/* 273 */       if ((currentValue = value) != null)
/* 274 */         newHashSet.addValue(currentValue);  b++; }
/*     */     
/* 276 */     this.values = newHashSet.values;
/* 277 */     this.threshold = newHashSet.threshold;
/* 278 */     this.elementSize = newHashSet.elementSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(T obj) {
/* 286 */     cleanupGarbageCollectedValues();
/* 287 */     int valuesLength = this.values.length;
/* 288 */     int index = (obj.hashCode() & Integer.MAX_VALUE) % valuesLength;
/*     */     HashedReference<T> currentValue;
/* 290 */     while ((currentValue = this.values[index]) != null) {
/*     */       Object referent;
/* 292 */       if (obj.equals(referent = currentValue.get())) {
/* 293 */         this.elementSize--;
/* 294 */         this.values[index] = null;
/* 295 */         rehash();
/* 296 */         return referent;
/*     */       } 
/* 298 */       index = (index + 1) % valuesLength;
/*     */     } 
/* 300 */     return null;
/*     */   }
/*     */   
/*     */   public int size() {
/* 304 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 309 */     StringBuilder buffer = new StringBuilder("{"); byte b; int i; HashedReference<T>[] arrayOfHashedReference;
/* 310 */     for (i = (arrayOfHashedReference = this.values).length, b = 0; b < i; ) { HashedReference<T> value = arrayOfHashedReference[b];
/* 311 */       if (value != null) {
/* 312 */         Object ref = value.get();
/* 313 */         if (ref != null) {
/* 314 */           buffer.append(ref);
/* 315 */           buffer.append(", ");
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 319 */     buffer.append("}");
/* 320 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object[] toArray() {
/* 324 */     cleanupGarbageCollectedValues();
/* 325 */     Object[] result = new Object[this.elementSize];
/* 326 */     int resultSize = 0; byte b; int i; HashedReference<T>[] arrayOfHashedReference;
/* 327 */     for (i = (arrayOfHashedReference = this.values).length, b = 0; b < i; ) { HashedReference<T> value = arrayOfHashedReference[b];
/* 328 */       if (value != null) {
/*     */ 
/*     */         
/* 331 */         Object tmp = value.get();
/* 332 */         if (tmp != null)
/* 333 */           result[resultSize++] = tmp; 
/*     */       }  b++; }
/* 335 */      if (result.length == resultSize)
/* 336 */       return result; 
/* 337 */     Object[] finalResult = new Object[resultSize];
/* 338 */     System.arraycopy(result, 0, finalResult, 0, resultSize);
/* 339 */     return finalResult;
/*     */   }
/*     */   
/*     */   private static interface HashedReference<T> {
/*     */     int hashCode();
/*     */     
/*     */     T get();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\ReferenceHashSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */