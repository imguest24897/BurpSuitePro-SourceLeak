/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URIUtil
/*     */ {
/*     */   private static final String JAR_SUFFIX = "!/";
/*     */   private static final String UNC_PREFIX = "//";
/*     */   private static final String SCHEME_FILE = "file";
/*     */   private static final String SCHEME_JAR = "jar";
/*  36 */   private static final boolean decodeResolved = (URI.create("foo:/a%20b/").resolve("c").getSchemeSpecificPart().indexOf('%') > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI append(URI base, String extension) {
/*     */     try {
/*  62 */       String path = base.getPath();
/*  63 */       if (path == null) {
/*  64 */         return appendOpaque(base, extension);
/*     */       }
/*     */       
/*  67 */       if (path.endsWith("/")) {
/*  68 */         result = base.resolve(new URI(null, null, extension, null));
/*  69 */         if (decodeResolved)
/*     */         {
/*  71 */           result = new URI(toUnencodedString(result));
/*     */         }
/*     */       } else {
/*  74 */         path = String.valueOf(path) + '/' + extension;
/*  75 */         result = toURI(base.getScheme(), base.getUserInfo(), base.getHost(), base.getPort(), path, 
/*  76 */             base.getQuery(), base.getFragment());
/*     */       } 
/*  78 */       URI result = result.normalize();
/*     */       
/*  80 */       String resultPath = result.getPath();
/*  81 */       if (isFileURI(base) && path != null && path.startsWith("//") && (resultPath == null || !resultPath.startsWith("//")))
/*  82 */         result = new URI(result.getScheme(), ensureUNCPath(result.getSchemeSpecificPart()), result.getFragment()); 
/*  83 */       return result;
/*  84 */     } catch (URISyntaxException e) {
/*     */       
/*  86 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URI appendOpaque(URI base, String extension) throws URISyntaxException {
/*  95 */     String ssp = base.getSchemeSpecificPart();
/*  96 */     if (ssp.endsWith("/")) {
/*  97 */       ssp = String.valueOf(ssp) + extension;
/*     */     } else {
/*  99 */       ssp = String.valueOf(ssp) + "/" + extension;
/* 100 */     }  return new URI(base.getScheme(), ssp, base.getFragment());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String fixUNCPath(String path) {
/* 111 */     if (!path.startsWith("//") || path.startsWith("//", 2))
/* 112 */       return path; 
/* 113 */     return ensureUNCPath(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String ensureUNCPath(String path) {
/* 120 */     int len = path.length();
/* 121 */     StringBuilder result = new StringBuilder(len);
/* 122 */     for (int i = 0; i < 4; i++) {
/*     */       
/* 124 */       if (i >= len || result.length() > 0 || path.charAt(i) != '/')
/* 125 */         result.append('/'); 
/*     */     } 
/* 127 */     result.append(path);
/* 128 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI fromString(String uriString) throws URISyntaxException {
/* 143 */     int colon = uriString.indexOf(':');
/* 144 */     int hash = uriString.lastIndexOf('#');
/* 145 */     boolean noHash = (hash < 0);
/* 146 */     if (noHash)
/* 147 */       hash = uriString.length(); 
/* 148 */     String scheme = (colon < 0) ? null : uriString.substring(0, colon);
/* 149 */     String ssp = uriString.substring(colon + 1, hash);
/* 150 */     String fragment = noHash ? null : uriString.substring(hash + 1);
/*     */     
/* 152 */     if (scheme != null && scheme.equals("file") && !ssp.startsWith("//")) {
/*     */       
/* 154 */       File file = new File(ssp);
/* 155 */       if (file.isAbsolute())
/* 156 */         return file.toURI(); 
/* 157 */       if (File.separatorChar != '/') {
/* 158 */         ssp = ssp.replace(File.separatorChar, '/');
/*     */       }
/* 160 */       if (!ssp.startsWith("/"))
/* 161 */         scheme = null; 
/*     */     } 
/* 163 */     return toURI(scheme, ssp, fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFileURI(URI uri) {
/* 172 */     return "file".equalsIgnoreCase(uri.getScheme());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lastSegment(URI location) {
/* 183 */     String path = location.getPath();
/* 184 */     if (path == null)
/* 185 */       return (new Path(location.getSchemeSpecificPart())).lastSegment(); 
/* 186 */     return (new Path(path)).lastSegment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI removeFileExtension(URI uri) {
/* 203 */     String lastSegment = lastSegment(uri);
/* 204 */     if (lastSegment == null)
/* 205 */       return uri; 
/* 206 */     int lastIndex = lastSegment.lastIndexOf('.');
/* 207 */     if (lastIndex == -1)
/* 208 */       return uri; 
/* 209 */     String uriString = uri.toString();
/* 210 */     lastIndex = uriString.lastIndexOf('.');
/* 211 */     uriString = uriString.substring(0, lastIndex);
/* 212 */     return URI.create(uriString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean sameURI(URI uri1, URI uri2) {
/* 224 */     if (uri1 == uri2)
/* 225 */       return true; 
/* 226 */     if (uri1 == null || uri2 == null) {
/* 227 */       return false;
/*     */     }
/* 229 */     if (uri1.equals(uri2)) {
/* 230 */       return true;
/*     */     }
/* 232 */     if (sameString(uri1.getScheme(), uri2.getScheme()) && sameString(uri1.getSchemeSpecificPart(), uri2.getSchemeSpecificPart()) && sameString(uri1.getFragment(), uri2.getFragment())) {
/* 233 */       return true;
/*     */     }
/* 235 */     if (uri1.isAbsolute() != uri2.isAbsolute()) {
/* 236 */       return false;
/*     */     }
/*     */     
/* 239 */     File file1 = toFile(uri1);
/* 240 */     return (file1 == null) ? false : file1.equals(toFile(uri2));
/*     */   }
/*     */   
/*     */   private static boolean sameString(String s1, String s2) {
/* 244 */     return !(s1 != s2 && (s1 == null || !s1.equals(s2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File toFile(URI uri) {
/* 254 */     if (!isFileURI(uri)) {
/* 255 */       return null;
/*     */     }
/* 257 */     return new File(uri.getSchemeSpecificPart());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toJarURI(URI uri, IPath entryPath) {
/*     */     try {
/* 278 */       if (entryPath == null) {
/* 279 */         entryPath = Path.EMPTY;
/*     */       }
/* 281 */       return new URI("jar", String.valueOf(uri.getScheme()) + ':' + uri.getSchemeSpecificPart() + "!/" + entryPath.toString(), null);
/* 282 */     } catch (URISyntaxException e) {
/*     */       
/* 284 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(URL url) throws URISyntaxException {
/* 297 */     if ("file".equals(url.getProtocol())) {
/* 298 */       String pathString = url.toExternalForm().substring(5);
/*     */       
/* 300 */       if (pathString.indexOf('/') != 0)
/* 301 */         pathString = String.valueOf('/') + pathString; 
/* 302 */       return toURI("file", null, pathString, null);
/*     */     } 
/*     */     try {
/* 305 */       return new URI(url.toExternalForm());
/* 306 */     } catch (URISyntaxException uRISyntaxException) {
/*     */       
/* 308 */       return toURI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(), 
/* 309 */           url.getQuery(), url.getRef());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String scheme, String ssp, String fragment) throws URISyntaxException {
/* 326 */     if (scheme != null && !scheme.equals("file")) {
/* 327 */       return new URI(scheme, ssp, fragment);
/*     */     }
/* 329 */     return new URI(scheme, fixUNCPath(ssp), fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String scheme, String userInfo, String host, int port, String path, String query, String fragment) throws URISyntaxException {
/* 352 */     if (scheme != null && !scheme.equals("file")) {
/* 353 */       return new URI(scheme, userInfo, host, port, path, query, fragment);
/*     */     }
/* 355 */     return new URI(scheme, userInfo, host, port, fixUNCPath(path), query, fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String scheme, String host, String path, String fragment) throws URISyntaxException {
/* 372 */     if (scheme != null && !scheme.equals("file")) {
/* 373 */       return new URI(scheme, host, path, fragment);
/*     */     }
/* 375 */     return new URI(scheme, host, fixUNCPath(path), fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String scheme, String authority, String path, String query, String fragment) throws URISyntaxException {
/* 397 */     if (scheme != null && !scheme.equals("file")) {
/* 398 */       return new URI(scheme, authority, path, query, fragment);
/*     */     }
/* 400 */     return new URI(scheme, authority, fixUNCPath(path), query, fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL toURL(URI uri) throws MalformedURLException {
/* 409 */     return new URL(uri.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toUnencodedString(URI uri) {
/* 419 */     StringBuilder result = new StringBuilder();
/* 420 */     String scheme = uri.getScheme();
/* 421 */     if (scheme != null) {
/* 422 */       result.append(scheme).append(':');
/*     */     }
/* 424 */     result.append(uri.getSchemeSpecificPart());
/* 425 */     String fragment = uri.getFragment();
/* 426 */     if (fragment != null)
/* 427 */       result.append('#').append(fragment); 
/* 428 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI makeAbsolute(URI relative, URI baseURI) {
/* 445 */     if (relative.isAbsolute())
/* 446 */       return relative; 
/* 447 */     return append(baseURI, toUnencodedString(relative));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI makeRelative(URI original, URI baseURI) {
/* 464 */     if (!"file".equals(original.getScheme()) || !"file".equals(baseURI.getScheme())) {
/* 465 */       return baseURI.relativize(original);
/*     */     }
/* 467 */     IPath originalPath = new Path(original.getSchemeSpecificPart());
/* 468 */     IPath basePath = new Path(baseURI.getSchemeSpecificPart());
/*     */ 
/*     */     
/* 471 */     if (!basePath.isAbsolute())
/* 472 */       return original; 
/* 473 */     IPath relativePath = originalPath.makeRelativeTo(basePath);
/*     */     
/* 475 */     if (relativePath == originalPath)
/* 476 */       return original; 
/*     */     try {
/* 478 */       return new URI(null, null, relativePath.toString(), original.getFragment());
/* 479 */     } catch (URISyntaxException uRISyntaxException) {
/*     */       
/* 481 */       return original;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\URIUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */