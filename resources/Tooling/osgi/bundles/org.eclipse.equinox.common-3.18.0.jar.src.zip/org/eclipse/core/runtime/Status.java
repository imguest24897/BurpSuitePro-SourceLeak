/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.eclipse.core.internal.runtime.LocalizationUtils;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Status
/*     */   implements IStatus
/*     */ {
/*     */   private static final String unknownId = "unknown";
/*  46 */   public static final IStatus OK_STATUS = new Status(0, "unknown", 0, LocalizationUtils.safeLocalize("ok"), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final IStatus CANCEL_STATUS = new Status(8, "unknown", 1, "", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private volatile int severity = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile String pluginId;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile int code;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile String message;
/*     */ 
/*     */ 
/*     */   
/*  79 */   private volatile Throwable exception = null;
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static final IStatus[] theEmptyStatusArray = new IStatus[0];
/*     */   
/*  85 */   private static StackWalker walker = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus info(String message) {
/*  99 */     Class<?> callerClass = null;
/*     */     try {
/* 101 */       callerClass = walker.getCallerClass();
/* 102 */     } catch (IllegalCallerException illegalCallerException) {}
/*     */ 
/*     */     
/* 105 */     return new Status(1, callerClass, 0, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus warning(String message) {
/* 120 */     Class<?> callerClass = null;
/*     */     try {
/* 122 */       callerClass = walker.getCallerClass();
/* 123 */     } catch (IllegalCallerException illegalCallerException) {}
/*     */ 
/*     */     
/* 126 */     return new Status(2, callerClass, 0, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Status warning(String message, Throwable exception) {
/* 143 */     Class<?> callerClass = null;
/*     */     try {
/* 145 */       callerClass = walker.getCallerClass();
/* 146 */     } catch (IllegalCallerException illegalCallerException) {}
/*     */ 
/*     */     
/* 149 */     return new Status(2, callerClass, 0, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus error(String message) {
/* 164 */     Class<?> callerClass = null;
/*     */     try {
/* 166 */       callerClass = walker.getCallerClass();
/* 167 */     } catch (IllegalCallerException illegalCallerException) {}
/*     */ 
/*     */     
/* 170 */     return new Status(4, callerClass, 0, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus error(String message, Throwable exception) {
/* 187 */     Class<?> callerClass = null;
/*     */     try {
/* 189 */       callerClass = walker.getCallerClass();
/* 190 */     } catch (IllegalCallerException illegalCallerException) {}
/*     */ 
/*     */     
/* 193 */     return new Status(4, callerClass, 0, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, Class<?> caller, int code, String message, Throwable exception) {
/* 211 */     setSeverity(severity);
/* 212 */     setPlugin(identifier(caller));
/* 213 */     setCode(code);
/* 214 */     setMessage(interpolateMessage(message, exception));
/* 215 */     setException(exception);
/*     */   }
/*     */   
/*     */   private String interpolateMessage(String msg, Throwable e) {
/* 219 */     if ((msg == null || msg.isEmpty()) && e != null) {
/* 220 */       msg = e.getLocalizedMessage();
/* 221 */       if (msg == null || msg.isEmpty()) {
/* 222 */         msg = e.getClass().getSimpleName();
/*     */       }
/*     */     } 
/* 225 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, String pluginId, int code, String message, Throwable exception) {
/* 241 */     setSeverity(severity);
/* 242 */     setPlugin(pluginId);
/* 243 */     setCode(code);
/* 244 */     setMessage(interpolateMessage(message, exception));
/* 245 */     setException(exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, Class<?> caller, String message, Throwable exception) {
/* 263 */     setSeverity(severity);
/* 264 */     setPlugin(identifier(caller));
/* 265 */     setMessage(interpolateMessage(message, exception));
/* 266 */     setException(exception);
/* 267 */     setCode(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, String pluginId, String message, Throwable exception) {
/* 285 */     setSeverity(severity);
/* 286 */     setPlugin(pluginId);
/* 287 */     setMessage(interpolateMessage(message, exception));
/* 288 */     setException(exception);
/* 289 */     setCode(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, Class<?> caller, String message) {
/* 305 */     setSeverity(severity);
/* 306 */     setPlugin(identifier(caller));
/* 307 */     setMessage(message);
/* 308 */     setCode(0);
/* 309 */     setException(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status(int severity, String pluginId, String message) {
/* 325 */     setSeverity(severity);
/* 326 */     setPlugin(pluginId);
/* 327 */     setMessage(message);
/* 328 */     setCode(0);
/* 329 */     setException(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String identifier(Class<?> caller) {
/* 339 */     return Optional.<Class<?>>ofNullable(caller)
/* 340 */       .flatMap(c -> Optional.ofNullable(FrameworkUtil.getBundle(c)))
/* 341 */       .map(b -> b.getSymbolicName())
/* 342 */       .orElseGet(() -> (String)Optional.<Class<?>>ofNullable(paramClass).map(()).orElse("unknown"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus[] getChildren() {
/* 349 */     return theEmptyStatusArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 354 */     return this.code;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/* 359 */     return this.exception;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 364 */     return this.message;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPlugin() {
/* 369 */     return this.pluginId;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSeverity() {
/* 374 */     return this.severity;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMultiStatus() {
/* 379 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOK() {
/* 384 */     return (this.severity == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(int severityMask) {
/* 389 */     return ((this.severity & severityMask) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCode(int code) {
/* 398 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setException(Throwable exception) {
/* 408 */     this.exception = exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMessage(String message) {
/* 419 */     if (message == null) {
/* 420 */       this.message = "";
/*     */     } else {
/* 422 */       this.message = message;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPlugin(String pluginId) {
/* 431 */     Assert.isLegal((pluginId != null && pluginId.length() > 0));
/* 432 */     this.pluginId = pluginId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSeverity(int severity) {
/* 442 */     Assert.isLegal(!(severity != 0 && severity != 4 && severity != 2 && severity != 1 && severity != 8));
/* 443 */     this.severity = severity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 452 */     StringBuilder buf = new StringBuilder();
/* 453 */     buf.append("Status ");
/* 454 */     if (this.severity == 0) {
/* 455 */       buf.append("OK");
/* 456 */     } else if (this.severity == 4) {
/* 457 */       buf.append("ERROR");
/* 458 */     } else if (this.severity == 2) {
/* 459 */       buf.append("WARNING");
/* 460 */     } else if (this.severity == 1) {
/* 461 */       buf.append("INFO");
/* 462 */     } else if (this.severity == 8) {
/* 463 */       buf.append("CANCEL");
/*     */     } else {
/* 465 */       buf.append("severity=");
/* 466 */       buf.append(this.severity);
/*     */     } 
/* 468 */     buf.append(": ");
/* 469 */     buf.append(this.pluginId);
/* 470 */     buf.append(" code=");
/* 471 */     buf.append(this.code);
/* 472 */     buf.append(' ');
/* 473 */     buf.append(this.message);
/* 474 */     if (this.exception != null) {
/* 475 */       buf.append(' ');
/* 476 */       buf.append(this.exception);
/*     */     } 
/* 478 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\Status.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */