/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.runtime.ILogListener;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RuntimeLog
/*     */ {
/*  28 */   private static ArrayList<ILogListener> logListeners = new ArrayList<>(5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   private static ArrayList<IStatus> queuedMessages = new ArrayList<>(5);
/*     */   
/*     */   private static PlatformLogWriter logWriter;
/*     */   
/*     */   static void setLogWriter(PlatformLogWriter logWriter) {
/*  41 */     synchronized (logListeners) {
/*  42 */       boolean firstListener = isEmpty();
/*  43 */       RuntimeLog.logWriter = logWriter;
/*  44 */       if (firstListener && logWriter != null) {
/*  45 */         emptyQueuedMessages();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addLogListener(ILogListener listener) {
/*  53 */     synchronized (logListeners) {
/*  54 */       boolean firstListener = isEmpty();
/*     */ 
/*     */       
/*  57 */       logListeners.remove(listener);
/*  58 */       logListeners.add(listener);
/*  59 */       if (firstListener) {
/*  60 */         emptyQueuedMessages();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeLogListener(ILogListener listener) {
/*  68 */     synchronized (logListeners) {
/*  69 */       logListeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(ILogListener listener) {
/*  77 */     synchronized (logListeners) {
/*  78 */       return logListeners.contains(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(IStatus status) {
/*     */     PlatformLogWriter writer;
/*  87 */     ILogListener[] listeners = null;
/*     */     
/*  89 */     synchronized (logListeners) {
/*  90 */       writer = logWriter;
/*  91 */       if (writer == null) {
/*  92 */         if (logListeners.isEmpty()) {
/*  93 */           queuedMessages.add(status);
/*     */           return;
/*     */         } 
/*  96 */         listeners = logListeners.<ILogListener>toArray(new ILogListener[logListeners.size()]);
/*     */       } 
/*     */     } 
/*  99 */     if (writer != null) {
/* 100 */       writer.logging(status);
/*     */       return;
/*     */     } 
/* 103 */     if (listeners != null) {
/* 104 */       byte b; int i; ILogListener[] arrayOfILogListener; for (i = (arrayOfILogListener = listeners).length, b = 0; b < i; ) { ILogListener listener = arrayOfILogListener[b];
/*     */         try {
/* 106 */           listener.logging(status, "org.eclipse.core.runtime");
/* 107 */         } catch (Exception|LinkageError e) {
/* 108 */           handleException(e);
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   private static void handleException(Throwable e) {
/* 115 */     if (!(e instanceof org.eclipse.core.runtime.OperationCanceledException))
/*     */     {
/* 117 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty() {
/* 126 */     synchronized (logListeners) {
/* 127 */       return (logListeners.isEmpty() && logWriter == null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasListeners() {
/* 136 */     synchronized (logListeners) {
/* 137 */       return !logListeners.isEmpty();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void emptyQueuedMessages() {
/*     */     IStatus[] queued;
/* 143 */     synchronized (logListeners) {
/* 144 */       if (queuedMessages.isEmpty())
/*     */         return; 
/* 146 */       queued = queuedMessages.<IStatus>toArray(new IStatus[queuedMessages.size()]);
/* 147 */       queuedMessages.clear();
/*     */     }  byte b; int i; IStatus[] arrayOfIStatus1;
/* 149 */     for (i = (arrayOfIStatus1 = queued).length, b = 0; b < i; ) { IStatus s = arrayOfIStatus1[b];
/* 150 */       log(s);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   static void logToListeners(IStatus status) {
/*     */     ILogListener[] listeners;
/* 157 */     synchronized (logListeners) {
/* 158 */       listeners = logListeners.<ILogListener>toArray(new ILogListener[logListeners.size()]);
/*     */     }  byte b; int i; ILogListener[] arrayOfILogListener1;
/* 160 */     for (i = (arrayOfILogListener1 = listeners).length, b = 0; b < i; ) { ILogListener listener = arrayOfILogListener1[b];
/*     */       try {
/* 162 */         listener.logging(status, "org.eclipse.core.runtime");
/* 163 */       } catch (Exception|LinkageError e) {
/* 164 */         handleException(e);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\RuntimeLog.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */