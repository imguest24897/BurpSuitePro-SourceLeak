/*    */ package org.eclipse.core.internal.boot;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.util.Hashtable;
/*    */ import org.eclipse.core.internal.runtime.CommonMessages;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.osgi.service.url.AbstractURLStreamHandlerService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLHandler
/*    */   extends AbstractURLStreamHandlerService
/*    */ {
/* 30 */   private static Hashtable<String, Constructor<?>> connectionType = new Hashtable<>();
/*    */ 
/*    */   
/*    */   public static final String PROTOCOL = "platform";
/*    */ 
/*    */   
/*    */   public static final String FILE = "file";
/*    */ 
/*    */   
/*    */   public static final String JAR = "jar";
/*    */ 
/*    */   
/*    */   public static final String BUNDLE = "bundle";
/*    */ 
/*    */   
/*    */   public static final String JAR_SEPARATOR = "!/";
/*    */   
/*    */   public static final String PROTOCOL_SEPARATOR = ":";
/*    */ 
/*    */   
/*    */   public URLConnection openConnection(URL url) throws IOException {
/* 51 */     String spec = url.getFile().trim();
/* 52 */     if (spec.startsWith("/"))
/* 53 */       spec = spec.substring(1); 
/* 54 */     int ix = spec.indexOf('/');
/* 55 */     if (ix == -1) {
/* 56 */       throw new MalformedURLException(NLS.bind(CommonMessages.url_invalidURL, url.toExternalForm()));
/*    */     }
/* 58 */     String type = spec.substring(0, ix);
/* 59 */     Constructor<?> construct = connectionType.get(type);
/* 60 */     if (construct == null) {
/* 61 */       throw new MalformedURLException(NLS.bind(CommonMessages.url_badVariant, type));
/*    */     }
/* 63 */     PlatformURLConnection connection = null;
/*    */     try {
/* 65 */       connection = (PlatformURLConnection)construct.newInstance(new Object[] { url });
/* 66 */     } catch (Exception e) {
/* 67 */       throw new IOException(NLS.bind(CommonMessages.url_createConnection, e.getMessage()));
/*    */     } 
/* 69 */     connection.setResolvedURL(connection.resolve());
/* 70 */     return connection;
/*    */   }
/*    */   
/*    */   public static void register(String type, Class<?> connectionClass) {
/*    */     try {
/* 75 */       Constructor<?> c = connectionClass.getConstructor(new Class[] { URL.class });
/* 76 */       connectionType.put(type, c);
/* 77 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void unregister(String type) {
/* 83 */     connectionType.remove(type);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\boot\PlatformURLHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */