/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import java.util.StringTokenizer;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DevClassPathHelper
/*    */ {
/*    */   public static final String PROP_DEV = "osgi.dev";
/*    */   protected static boolean inDevelopmentMode = false;
/*    */   protected static String[] devDefaultClasspath;
/* 30 */   protected static Properties devProperties = null;
/*    */ 
/*    */   
/*    */   static {
/* 34 */     String osgiDev = (Activator.getContext() == null) ? System.getProperty("osgi.dev") : Activator.getContext().getProperty("osgi.dev");
/* 35 */     if (osgiDev != null) {
/*    */       try {
/* 37 */         inDevelopmentMode = true;
/* 38 */         URL location = new URL(osgiDev);
/* 39 */         devProperties = load(location);
/* 40 */         if (devProperties != null)
/* 41 */           devDefaultClasspath = getArrayFromList(devProperties.getProperty("*")); 
/* 42 */       } catch (MalformedURLException malformedURLException) {
/* 43 */         devDefaultClasspath = getArrayFromList(osgiDev);
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public static String[] getDevClassPath(String id) {
/* 49 */     String[] result = null;
/* 50 */     if (id != null && devProperties != null) {
/* 51 */       String entry = devProperties.getProperty(id);
/* 52 */       if (entry != null)
/* 53 */         result = getArrayFromList(entry); 
/*    */     } 
/* 55 */     if (result == null)
/* 56 */       result = devDefaultClasspath; 
/* 57 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getArrayFromList(String prop) {
/* 67 */     if (prop == null || prop.trim().equals(""))
/* 68 */       return new String[0]; 
/* 69 */     Vector<String> list = new Vector<>();
/* 70 */     StringTokenizer tokens = new StringTokenizer(prop, ",");
/* 71 */     while (tokens.hasMoreTokens()) {
/* 72 */       String token = tokens.nextToken().trim();
/* 73 */       if (!token.equals(""))
/* 74 */         list.addElement(token); 
/*    */     } 
/* 76 */     return list.isEmpty() ? new String[0] : list.<String>toArray(new String[list.size()]);
/*    */   }
/*    */   
/*    */   public static boolean inDevelopmentMode() {
/* 80 */     return inDevelopmentMode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Properties load(URL url) {
/* 87 */     Properties props = new Properties();
/*    */     try {
/* 89 */       Exception exception2, exception1 = null;
/*    */     
/*    */     }
/* 92 */     catch (IOException iOException) {}
/*    */ 
/*    */     
/* 95 */     return props;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\DevClassPathHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */