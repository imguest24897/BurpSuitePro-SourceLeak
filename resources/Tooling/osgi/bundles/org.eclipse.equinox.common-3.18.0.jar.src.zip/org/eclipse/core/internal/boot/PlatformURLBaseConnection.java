/*    */ package org.eclipse.core.internal.boot;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.internal.runtime.CommonMessages;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLBaseConnection
/*    */   extends PlatformURLConnection
/*    */ {
/*    */   public static final String PLATFORM = "base";
/*    */   public static final String PLATFORM_URL_STRING = "platform:/base/";
/*    */   private static URL installURL;
/*    */   
/*    */   public PlatformURLBaseConnection(URL url) {
/* 37 */     super(url);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean allowCaching() {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL resolve() throws IOException {
/* 47 */     String spec = this.url.getFile().trim();
/* 48 */     if (spec.startsWith("/"))
/* 49 */       spec = spec.substring(1); 
/* 50 */     if (!spec.startsWith("base/")) {
/* 51 */       String message = NLS.bind(CommonMessages.url_badVariant, this.url);
/* 52 */       throw new IOException(message);
/*    */     } 
/* 54 */     return (spec.length() == "base".length() + 1) ? installURL : new URL(installURL, spec.substring("base".length() + 1));
/*    */   }
/*    */ 
/*    */   
/*    */   public static void startup(URL url) {
/* 59 */     if (installURL != null)
/*    */       return; 
/* 61 */     installURL = url;
/* 62 */     PlatformURLHandler.register("base", PlatformURLBaseConnection.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\boot\PlatformURLBaseConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */