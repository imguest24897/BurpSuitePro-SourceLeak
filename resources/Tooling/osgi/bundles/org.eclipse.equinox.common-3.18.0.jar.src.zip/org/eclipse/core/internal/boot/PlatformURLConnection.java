/*     */ package org.eclipse.core.internal.boot;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.core.internal.runtime.Activator;
/*     */ import org.eclipse.core.internal.runtime.CommonMessages;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PlatformURLConnection
/*     */   extends URLConnection
/*     */ {
/*     */   private boolean isInCache = false;
/*     */   private boolean isJar = false;
/*  38 */   private URL resolvedURL = null;
/*  39 */   private URL cachedURL = null;
/*     */   
/*  41 */   private URLConnection connection = null;
/*     */ 
/*     */   
/*  44 */   private static Properties cacheIndex = new Properties();
/*     */   
/*     */   private static String cacheLocation;
/*     */   
/*     */   private static String indexName;
/*     */   private static String filePrefix;
/*     */   private static final int BUF_SIZE = 32768;
/*  51 */   private static final Object NOT_FOUND = new Object();
/*     */   private static final String CACHE_PROP = ".cache.properties";
/*     */   private static final String CACHE_LOCATION_PROP = "location";
/*     */   private static final String CACHE_INDEX_PROP = "index";
/*     */   private static final String CACHE_PREFIX_PROP = "prefix";
/*     */   private static final String CACHE_INDEX = ".index.properties";
/*  57 */   private static final String CACHE_DIR = ".eclipse-platform" + File.separator;
/*     */   
/*     */   private static final String OPTION_DEBUG = "org.eclipse.core.runtime/url/debug";
/*     */   
/*     */   private static final String OPTION_DEBUG_CONNECT = "org.eclipse.core.runtime/url/debug/connect";
/*     */   
/*     */   private static final String OPTION_DEBUG_CACHE_LOOKUP = "org.eclipse.core.runtime/url/debug/cachelookup";
/*     */   private static final String OPTION_DEBUG_CACHE_COPY = "org.eclipse.core.runtime/url/debug/cachecopy";
/*     */   public static final boolean DEBUG;
/*     */   public static final boolean DEBUG_CONNECT;
/*     */   public static final boolean DEBUG_CACHE_LOOKUP;
/*     */   public static final boolean DEBUG_CACHE_COPY;
/*     */   
/*     */   static {
/*  71 */     Activator activator = Activator.getDefault();
/*  72 */     if (activator == null) {
/*  73 */       DEBUG = DEBUG_CONNECT = DEBUG_CACHE_LOOKUP = DEBUG_CACHE_COPY = false;
/*     */     } else {
/*  75 */       DebugOptions debugOptions = activator.getDebugOptions();
/*  76 */       if (debugOptions != null) {
/*  77 */         DEBUG = debugOptions.getBooleanOption("org.eclipse.core.runtime/url/debug", false);
/*  78 */         DEBUG_CONNECT = debugOptions.getBooleanOption("org.eclipse.core.runtime/url/debug/connect", true);
/*  79 */         DEBUG_CACHE_LOOKUP = debugOptions.getBooleanOption("org.eclipse.core.runtime/url/debug/cachelookup", true);
/*  80 */         DEBUG_CACHE_COPY = debugOptions.getBooleanOption("org.eclipse.core.runtime/url/debug/cachecopy", true);
/*     */       } else {
/*  82 */         DEBUG = DEBUG_CONNECT = DEBUG_CACHE_LOOKUP = DEBUG_CACHE_COPY = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected PlatformURLConnection(URL url) {
/*  87 */     super(url);
/*     */   }
/*     */   
/*     */   protected boolean allowCaching() {
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  96 */     connect(false);
/*     */   }
/*     */   
/*     */   private synchronized void connect(boolean asLocal) throws IOException {
/* 100 */     if (this.connected) {
/*     */       return;
/*     */     }
/* 103 */     if (shouldCache(asLocal)) {
/*     */       try {
/* 105 */         URL inCache = getURLInCache();
/* 106 */         if (inCache != null)
/* 107 */           this.connection = inCache.openConnection(); 
/* 108 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (this.connection == null)
/* 115 */       this.connection = this.resolvedURL.openConnection(); 
/* 116 */     this.connected = true;
/* 117 */     if (DEBUG && DEBUG_CONNECT)
/* 118 */       debug("Connected as " + this.connection.getURL()); 
/*     */   }
/*     */   
/*     */   private void copyToCache() throws IOException {
/*     */     String key;
/*     */     URL src;
/*     */     String tgt;
/* 125 */     if ((this.isInCache | ((this.cachedURL == null) ? 1 : 0)) != 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (this.isJar) {
/* 133 */       String tmp = this.url.getFile();
/* 134 */       int ix = tmp.lastIndexOf("!/");
/* 135 */       if (ix != -1)
/* 136 */         tmp = tmp.substring(0, ix); 
/* 137 */       key = tmp;
/*     */     } else {
/* 139 */       key = this.url.getFile();
/*     */     } 
/*     */ 
/*     */     
/* 143 */     if (this.isJar) {
/* 144 */       String tmp = this.resolvedURL.getFile();
/* 145 */       int ix = tmp.lastIndexOf("!/");
/* 146 */       if (ix != -1)
/* 147 */         tmp = tmp.substring(0, ix); 
/* 148 */       src = new URL(tmp);
/*     */     } else {
/* 150 */       src = this.resolvedURL;
/* 151 */     }  InputStream srcis = null;
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (this.isJar) {
/* 156 */       String tmp = this.cachedURL.getFile();
/* 157 */       int ix = tmp.indexOf(":");
/* 158 */       if (ix != -1)
/* 159 */         tmp = tmp.substring(ix + 1); 
/* 160 */       ix = tmp.lastIndexOf("!/");
/* 161 */       if (ix != -1)
/* 162 */         tmp = tmp.substring(0, ix); 
/* 163 */       tgt = tmp;
/*     */     } else {
/* 165 */       tgt = this.cachedURL.getFile();
/* 166 */     }  File tgtFile = null;
/* 167 */     FileOutputStream tgtos = null;
/*     */     
/* 169 */     boolean error = false;
/* 170 */     long total = 0L;
/*     */     
/*     */     try {
/* 173 */       if (DEBUG && DEBUG_CACHE_COPY) {
/* 174 */         if (this.isJar) {
/* 175 */           debug("Caching jar as " + tgt);
/*     */         } else {
/* 177 */           debug("Caching as " + tgt);
/*     */         } 
/*     */       }
/* 180 */       srcis = src.openStream();
/* 181 */       byte[] buf = new byte[32768];
/* 182 */       int count = srcis.read(buf);
/*     */       
/* 184 */       tgtFile = new File(tgt);
/* 185 */       tgtos = new FileOutputStream(tgtFile);
/*     */       
/* 187 */       while (count != -1) {
/* 188 */         total += count;
/* 189 */         tgtos.write(buf, 0, count);
/* 190 */         count = srcis.read(buf);
/*     */       } 
/*     */       
/* 193 */       srcis.close();
/* 194 */       srcis = null;
/* 195 */       tgtos.flush();
/* 196 */       tgtos.getFD().sync();
/* 197 */       tgtos.close();
/* 198 */       tgtos = null;
/*     */ 
/*     */       
/* 201 */       cacheIndex.put(key, tgt);
/* 202 */       this.isInCache = true;
/* 203 */     } catch (IOException e) {
/* 204 */       error = true;
/* 205 */       cacheIndex.put(key, NOT_FOUND);
/*     */       
/* 207 */       if (DEBUG && DEBUG_CACHE_COPY)
/* 208 */         debug("Failed to cache due to " + e); 
/* 209 */       throw e;
/*     */     } finally {
/* 211 */       if (!error && DEBUG && DEBUG_CACHE_COPY)
/* 212 */         debug(String.valueOf(total) + " bytes copied"); 
/* 213 */       if (srcis != null)
/* 214 */         srcis.close(); 
/* 215 */       if (tgtos != null)
/* 216 */         tgtos.close(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void debug(String s) {
/* 221 */     System.out.println("URL " + getURL() + "^" + Integer.toHexString(Thread.currentThread().hashCode()) + " " + s);
/*     */   }
/*     */   
/*     */   private static void debugStartup(String s) {
/* 225 */     System.out.println("URL " + s);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized InputStream getInputStream() throws IOException {
/* 230 */     if (!this.connected)
/* 231 */       connect(); 
/* 232 */     return this.connection.getInputStream();
/*     */   }
/*     */   
/*     */   public URL getResolvedURL() {
/* 236 */     return this.resolvedURL;
/*     */   }
/*     */   
/*     */   public URL getURLAsLocal() throws IOException {
/* 240 */     connect(true);
/* 241 */     URL u = this.connection.getURL();
/* 242 */     String up = u.getProtocol();
/* 243 */     if (!up.equals("file") && !up.equals("jar") && !up.startsWith("bundle"))
/* 244 */       throw new IOException(NLS.bind(CommonMessages.url_noaccess, up)); 
/* 245 */     return u;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private URL getURLInCache() throws IOException {
/* 251 */     if (!allowCaching()) {
/* 252 */       return null;
/*     */     }
/* 254 */     if (this.isInCache) {
/* 255 */       return this.cachedURL;
/*     */     }
/* 257 */     if ((((cacheLocation == null) ? 1 : 0) | ((cacheIndex == null) ? 1 : 0)) != 0) {
/* 258 */       return null;
/*     */     }
/*     */     
/* 261 */     String file = "";
/* 262 */     String jarEntry = null;
/* 263 */     if (this.isJar) {
/* 264 */       file = this.url.getFile();
/* 265 */       int ix = file.lastIndexOf("!/");
/* 266 */       if (ix != -1) {
/* 267 */         jarEntry = file.substring(ix + "!/".length());
/* 268 */         file = file.substring(0, ix);
/*     */       } 
/*     */     } else {
/* 271 */       file = this.url.getFile();
/*     */     } 
/*     */ 
/*     */     
/* 275 */     String tmp = (String)cacheIndex.get(file);
/*     */ 
/*     */     
/* 278 */     if (tmp != null && tmp == NOT_FOUND) {
/* 279 */       throw new IOException();
/*     */     }
/*     */     
/* 282 */     if (tmp != null && !(new File(tmp)).exists()) {
/* 283 */       tmp = null;
/* 284 */       cacheIndex.remove(this.url.getFile());
/*     */     } 
/*     */ 
/*     */     
/* 288 */     if (tmp != null) {
/* 289 */       if (this.isJar) {
/* 290 */         if (DEBUG && DEBUG_CACHE_LOOKUP)
/* 291 */           debug("Jar located in cache as " + tmp); 
/* 292 */         tmp = "file:" + tmp + "!/" + jarEntry;
/* 293 */         this.cachedURL = new URL("jar", null, -1, tmp);
/*     */       } else {
/* 295 */         if (DEBUG && DEBUG_CACHE_LOOKUP)
/* 296 */           debug("Located in cache as " + tmp); 
/* 297 */         this.cachedURL = new URL("file", null, -1, tmp);
/*     */       } 
/* 299 */       this.isInCache = true;
/*     */     } else {
/*     */       
/* 302 */       int ix = file.lastIndexOf('/');
/* 303 */       tmp = file.substring(ix + 1);
/* 304 */       tmp = String.valueOf(cacheLocation) + filePrefix + (new Date()).getTime() + "_" + tmp;
/* 305 */       tmp = tmp.replace(File.separatorChar, '/');
/* 306 */       if (this.isJar) {
/* 307 */         tmp = "file:" + tmp + "!/" + jarEntry;
/* 308 */         this.cachedURL = new URL("jar", null, -1, tmp);
/*     */       } else {
/* 310 */         this.cachedURL = new URL("file", null, -1, tmp);
/* 311 */       }  copyToCache();
/*     */     } 
/*     */     
/* 314 */     return this.cachedURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URL resolve() throws IOException {
/* 323 */     throw new IOException();
/*     */   }
/*     */   
/*     */   protected static String getId(String spec) {
/* 327 */     String id = (String)parse(spec)[0];
/* 328 */     return (id == null) ? spec : id;
/*     */   }
/*     */   
/*     */   protected static String getVersion(String spec) {
/* 332 */     Version version = (Version)parse(spec)[1];
/* 333 */     return (version == null) ? "" : version.toString();
/*     */   }
/*     */   
/*     */   private static Object[] parse(String spec) {
/* 337 */     String bsn = null;
/* 338 */     Version version = null;
/* 339 */     int underScore = spec.indexOf('_');
/* 340 */     while (underScore >= 0) {
/*     */       try {
/* 342 */         version = Version.parseVersion(spec.substring(underScore + 1));
/* 343 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */         
/* 345 */         underScore = spec.indexOf('_', underScore + 1);
/*     */         continue;
/*     */       } 
/* 348 */       bsn = spec.substring(0, underScore);
/*     */       break;
/*     */     } 
/* 351 */     return new Object[] { bsn, version };
/*     */   }
/*     */   
/*     */   void setResolvedURL(URL url) throws IOException {
/* 355 */     if (url == null)
/* 356 */       throw new IOException(); 
/* 357 */     if (this.resolvedURL != null)
/*     */       return; 
/* 359 */     int ix = url.getFile().lastIndexOf("!/");
/* 360 */     this.isJar = (-1 != ix);
/*     */ 
/*     */     
/* 363 */     if (this.isJar && !url.getProtocol().equals("jar"))
/* 364 */       url = new URL("jar", "", -1, url.toExternalForm()); 
/* 365 */     this.resolvedURL = url;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldCache(boolean asLocal) {
/* 371 */     String rp = this.resolvedURL.getProtocol();
/* 372 */     String rf = this.resolvedURL.getFile();
/* 373 */     if (rp.equals("file"))
/* 374 */       return false; 
/* 375 */     if (rp.equals("jar") && rf.startsWith("file")) {
/* 376 */       return false;
/*     */     }
/*     */     
/* 379 */     if (asLocal) {
/* 380 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 384 */     return true;
/*     */   }
/*     */   
/*     */   static void shutdown() {
/* 388 */     if (indexName != null && cacheLocation != null) {
/*     */       
/* 390 */       Enumeration<Object> keys = cacheIndex.keys();
/*     */ 
/*     */       
/* 393 */       while (keys.hasMoreElements()) {
/* 394 */         String key = (String)keys.nextElement();
/* 395 */         Object value = cacheIndex.get(key);
/* 396 */         if (value == NOT_FOUND) {
/* 397 */           cacheIndex.remove(key);
/*     */         }
/*     */       } 
/* 400 */       if (cacheIndex.size() == 0) {
/*     */         return;
/*     */       }
/*     */       try {
/* 404 */         FileOutputStream fos = null;
/* 405 */         fos = new FileOutputStream(String.valueOf(cacheLocation) + indexName);
/*     */         try {
/* 407 */           cacheIndex.store(fos, (String)null);
/* 408 */           fos.flush();
/* 409 */           fos.getFD().sync();
/*     */         } finally {
/* 411 */           fos.close();
/*     */         } 
/* 413 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void startup(String location, String os, String ws, String nl) {
/* 421 */     verifyLocation(location);
/* 422 */     String cacheProps = location.trim();
/* 423 */     if (!cacheProps.endsWith(File.separator))
/* 424 */       cacheProps = String.valueOf(cacheProps) + File.separator; 
/* 425 */     cacheProps = String.valueOf(cacheProps) + ".cache.properties";
/* 426 */     File cachePropFile = new File(cacheProps);
/* 427 */     Properties props = null;
/*     */ 
/*     */     
/* 430 */     if (cachePropFile.exists()) {
/*     */       
/*     */       try {
/* 433 */         props = new Properties();
/* 434 */         FileInputStream fis = new FileInputStream(cachePropFile);
/*     */         try {
/* 436 */           props.load(fis);
/*     */         } finally {
/* 438 */           fis.close();
/*     */         } 
/* 440 */       } catch (IOException iOException) {
/* 441 */         props = null;
/*     */       } 
/*     */     }
/*     */     
/* 445 */     if (props == null) {
/*     */       
/* 447 */       props = new Properties();
/*     */       
/* 449 */       String tmp = System.getProperty("user.home");
/* 450 */       if (!tmp.endsWith(File.separator))
/* 451 */         tmp = String.valueOf(tmp) + File.separator; 
/* 452 */       tmp = String.valueOf(tmp) + CACHE_DIR;
/* 453 */       props.put("location", tmp);
/*     */       
/* 455 */       tmp = Long.toString((new Date()).getTime());
/* 456 */       props.put("prefix", tmp);
/*     */       
/* 458 */       tmp = String.valueOf(tmp) + ".index.properties";
/* 459 */       props.put("index", tmp);
/*     */ 
/*     */       
/* 462 */       FileOutputStream fos = null;
/*     */       try {
/* 464 */         fos = new FileOutputStream(cachePropFile);
/*     */         try {
/* 466 */           props.store(fos, (String)null);
/* 467 */           fos.flush();
/* 468 */           fos.getFD().sync();
/*     */         } finally {
/* 470 */           fos.close();
/*     */         } 
/* 472 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     filePrefix = (String)props.get("prefix");
/* 479 */     indexName = (String)props.get("index");
/* 480 */     cacheLocation = (String)props.get("location");
/*     */     
/* 482 */     if (DEBUG) {
/* 483 */       debugStartup("Cache location: " + cacheLocation);
/* 484 */       debugStartup("Cache index: " + indexName);
/* 485 */       debugStartup("Cache file prefix: " + filePrefix);
/*     */     } 
/*     */ 
/*     */     
/* 489 */     if (!verifyLocation(cacheLocation)) {
/* 490 */       indexName = null;
/* 491 */       cacheLocation = null;
/* 492 */       if (DEBUG) {
/* 493 */         debugStartup("Failed to create cache directory structure. Caching suspended");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 498 */     if (cacheLocation != null && indexName != null) {
/*     */       try {
/* 500 */         FileInputStream fis = new FileInputStream(String.valueOf(cacheLocation) + indexName);
/*     */         try {
/* 502 */           cacheIndex.load(fis);
/*     */         } finally {
/* 504 */           fis.close();
/*     */         } 
/* 506 */       } catch (IOException iOException) {
/* 507 */         if (DEBUG) {
/* 508 */           debugStartup("Failed to initialize cache");
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean verifyLocation(String location) {
/* 515 */     File cacheDir = new File(location);
/* 516 */     if (cacheDir.exists())
/* 517 */       return true; 
/* 518 */     return cacheDir.mkdirs();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\boot\PlatformURLConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */