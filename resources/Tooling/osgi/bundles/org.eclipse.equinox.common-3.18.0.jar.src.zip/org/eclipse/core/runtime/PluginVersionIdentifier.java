/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import org.eclipse.core.internal.runtime.CommonMessages;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class PluginVersionIdentifier
/*     */ {
/*     */   private Version version;
/*     */   private static final String SEPARATOR = ".";
/*     */   
/*     */   public PluginVersionIdentifier(int major, int minor, int service) {
/*  77 */     this(major, minor, service, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginVersionIdentifier(int major, int minor, int service, String qualifier) {
/*  94 */     if (major < 0)
/*  95 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveMajor, String.valueOf(major) + "." + minor + "." + service + "." + qualifier)); 
/*  96 */     if (minor < 0)
/*  97 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveMinor, String.valueOf(major) + "." + minor + "." + service + "." + qualifier)); 
/*  98 */     if (service < 0) {
/*  99 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveService, String.valueOf(major) + "." + minor + "." + service + "." + qualifier));
/*     */     }
/* 101 */     this.version = new Version(major, minor, service, qualifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginVersionIdentifier(String versionId) {
/* 122 */     Object[] parts = parseVersion(versionId);
/* 123 */     this.version = new Version(((Integer)parts[0]).intValue(), ((Integer)parts[1]).intValue(), ((Integer)parts[2]).intValue(), (String)parts[3]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateVersion(String version) {
/*     */     try {
/* 137 */       parseVersion(version);
/* 138 */     } catch (RuntimeException e) {
/* 139 */       return new Status(4, "org.eclipse.core.runtime", 4, e.getMessage(), e);
/*     */     } 
/* 141 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object[] parseVersion(String versionId) {
/* 149 */     if (versionId == null)
/* 150 */       Assert.isNotNull(null, CommonMessages.parse_emptyPluginVersion); 
/* 151 */     String s = versionId.trim();
/* 152 */     if (s.equals(""))
/* 153 */       Assert.isTrue(false, CommonMessages.parse_emptyPluginVersion); 
/* 154 */     if (s.startsWith("."))
/* 155 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_separatorStartVersion, s)); 
/* 156 */     if (s.endsWith("."))
/* 157 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_separatorEndVersion, s)); 
/* 158 */     if (s.contains("..")) {
/* 159 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_doubleSeparatorVersion, s));
/*     */     }
/* 161 */     StringTokenizer st = new StringTokenizer(s, ".");
/* 162 */     Vector<String> elements = new Vector<>(4);
/*     */     
/* 164 */     while (st.hasMoreTokens()) {
/* 165 */       elements.addElement(st.nextToken());
/*     */     }
/* 167 */     int elementSize = elements.size();
/*     */     
/* 169 */     if (elementSize <= 0)
/* 170 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_oneElementPluginVersion, s)); 
/* 171 */     if (elementSize > 4) {
/* 172 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_fourElementPluginVersion, s));
/*     */     }
/* 174 */     int[] numbers = new int[3];
/*     */     try {
/* 176 */       numbers[0] = Integer.parseInt((String)elements.elementAt(0));
/* 177 */       if (numbers[0] < 0)
/* 178 */         Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveMajor, s)); 
/* 179 */     } catch (NumberFormatException numberFormatException) {
/* 180 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_numericMajorComponent, s));
/*     */     } 
/*     */     
/*     */     try {
/* 184 */       if (elementSize >= 2)
/* 185 */       { numbers[1] = Integer.parseInt((String)elements.elementAt(1));
/* 186 */         if (numbers[1] < 0)
/* 187 */           Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveMinor, s));  }
/*     */       else
/* 189 */       { numbers[1] = 0; } 
/* 190 */     } catch (NumberFormatException numberFormatException) {
/* 191 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_numericMinorComponent, s));
/*     */     } 
/*     */     
/*     */     try {
/* 195 */       if (elementSize >= 3)
/* 196 */       { numbers[2] = Integer.parseInt((String)elements.elementAt(2));
/* 197 */         if (numbers[2] < 0)
/* 198 */           Assert.isTrue(false, NLS.bind(CommonMessages.parse_postiveService, s));  }
/*     */       else
/* 200 */       { numbers[2] = 0; } 
/* 201 */     } catch (NumberFormatException numberFormatException) {
/* 202 */       Assert.isTrue(false, NLS.bind(CommonMessages.parse_numericServiceComponent, s));
/*     */     } 
/*     */ 
/*     */     
/* 206 */     Object[] result = new Object[4];
/* 207 */     result[0] = Integer.valueOf(numbers[0]);
/* 208 */     result[1] = Integer.valueOf(numbers[1]);
/* 209 */     result[2] = Integer.valueOf(numbers[2]);
/* 210 */     if (elementSize >= 4) {
/* 211 */       result[3] = elements.elementAt(3);
/*     */     } else {
/* 213 */       result[3] = "";
/* 214 */     }  return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 226 */     if (!(object instanceof PluginVersionIdentifier))
/* 227 */       return false; 
/* 228 */     PluginVersionIdentifier v = (PluginVersionIdentifier)object;
/* 229 */     return this.version.equals(v.version);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 239 */     return this.version.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorComponent() {
/* 249 */     return this.version.getMajor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorComponent() {
/* 259 */     return this.version.getMinor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getServiceComponent() {
/* 269 */     return this.version.getMicro();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQualifierComponent() {
/* 279 */     return this.version.getQualifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGreaterOrEqualTo(PluginVersionIdentifier id) {
/* 304 */     if (id == null)
/* 305 */       return false; 
/* 306 */     if (getMajorComponent() > id.getMajorComponent())
/* 307 */       return true; 
/* 308 */     if (getMajorComponent() == id.getMajorComponent() && getMinorComponent() > id.getMinorComponent())
/* 309 */       return true; 
/* 310 */     if (getMajorComponent() == id.getMajorComponent() && getMinorComponent() == id.getMinorComponent() && getServiceComponent() > id.getServiceComponent())
/* 311 */       return true; 
/* 312 */     if (getMajorComponent() == id.getMajorComponent() && getMinorComponent() == id.getMinorComponent() && getServiceComponent() == id.getServiceComponent() && getQualifierComponent().compareTo(id.getQualifierComponent()) >= 0)
/* 313 */       return true; 
/* 314 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatibleWith(PluginVersionIdentifier id) {
/* 337 */     if (id == null)
/* 338 */       return false; 
/* 339 */     if (getMajorComponent() != id.getMajorComponent())
/* 340 */       return false; 
/* 341 */     if (getMinorComponent() > id.getMinorComponent())
/* 342 */       return true; 
/* 343 */     if (getMinorComponent() < id.getMinorComponent())
/* 344 */       return false; 
/* 345 */     if (getServiceComponent() > id.getServiceComponent())
/* 346 */       return true; 
/* 347 */     if (getServiceComponent() < id.getServiceComponent())
/* 348 */       return false; 
/* 349 */     if (getQualifierComponent().compareTo(id.getQualifierComponent()) >= 0)
/* 350 */       return true; 
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalentTo(PluginVersionIdentifier id) {
/* 372 */     if (id == null)
/* 373 */       return false; 
/* 374 */     if (getMajorComponent() != id.getMajorComponent())
/* 375 */       return false; 
/* 376 */     if (getMinorComponent() != id.getMinorComponent())
/* 377 */       return false; 
/* 378 */     if (getServiceComponent() > id.getServiceComponent())
/* 379 */       return true; 
/* 380 */     if (getServiceComponent() < id.getServiceComponent())
/* 381 */       return false; 
/* 382 */     if (getQualifierComponent().compareTo(id.getQualifierComponent()) >= 0)
/* 383 */       return true; 
/* 384 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPerfect(PluginVersionIdentifier id) {
/* 401 */     if (id == null)
/* 402 */       return false; 
/* 403 */     if (getMajorComponent() != id.getMajorComponent() || getMinorComponent() != id.getMinorComponent() || getServiceComponent() != id.getServiceComponent() || !getQualifierComponent().equals(id.getQualifierComponent()))
/* 404 */       return false; 
/* 405 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGreaterThan(PluginVersionIdentifier id) {
/* 419 */     if (id == null) {
/* 420 */       if (getMajorComponent() == 0 && getMinorComponent() == 0 && getServiceComponent() == 0 && getQualifierComponent().equals(""))
/* 421 */         return false; 
/* 422 */       return true;
/*     */     } 
/*     */     
/* 425 */     if (getMajorComponent() > id.getMajorComponent())
/* 426 */       return true; 
/* 427 */     if (getMajorComponent() < id.getMajorComponent())
/* 428 */       return false; 
/* 429 */     if (getMinorComponent() > id.getMinorComponent())
/* 430 */       return true; 
/* 431 */     if (getMinorComponent() < id.getMinorComponent())
/* 432 */       return false; 
/* 433 */     if (getServiceComponent() > id.getServiceComponent())
/* 434 */       return true; 
/* 435 */     if (getServiceComponent() < id.getServiceComponent())
/* 436 */       return false; 
/* 437 */     if (getQualifierComponent().compareTo(id.getQualifierComponent()) > 0)
/* 438 */       return true; 
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 452 */     return this.version.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\PluginVersionIdentifier.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */