/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataArea
/*     */ {
/*     */   private static final String OPTION_DEBUG = "org.eclipse.equinox.common/debug";
/*     */   private static final String REQUIRES_EXPLICIT_INIT = "osgi.dataAreaRequiresExplicitInit";
/*     */   static final String F_META_AREA = ".metadata";
/*     */   static final String F_PLUGIN_DATA = ".plugins";
/*     */   static final String F_LOG = ".log";
/*     */   static final String F_TRACE = "trace.log";
/*     */   static final String PREFERENCES_FILE_NAME = "pref_store.ini";
/*     */   private IPath location;
/*     */   private boolean initialized = false;
/*     */   
/*     */   protected synchronized void assertLocationInitialized() throws IllegalStateException {
/*  47 */     if (this.location != null && this.initialized)
/*     */       return; 
/*  49 */     Activator activator = Activator.getDefault();
/*  50 */     if (activator == null)
/*  51 */       throw new IllegalStateException(CommonMessages.activator_not_available); 
/*  52 */     Location service = activator.getInstanceLocation();
/*  53 */     if (service == null) {
/*  54 */       throw new IllegalStateException(CommonMessages.meta_noDataModeSpecified);
/*     */     }
/*  56 */     boolean explicitInitRequired = Boolean.valueOf(Activator.getContext().getProperty("osgi.dataAreaRequiresExplicitInit")).booleanValue();
/*  57 */     if (explicitInitRequired && !service.isSet())
/*     */     {
/*  59 */       throw new IllegalStateException(CommonMessages.meta_instanceDataUnspecified);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  64 */       URL url = service.getURL();
/*  65 */       if (url == null) {
/*  66 */         throw new IllegalStateException(CommonMessages.meta_instanceDataUnspecified);
/*     */       }
/*     */ 
/*     */       
/*  70 */       this.location = (IPath)new Path((new File(url.getFile())).toString());
/*  71 */       initializeLocation();
/*  72 */     } catch (CoreException e) {
/*  73 */       throw new IllegalStateException(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public IPath getMetadataLocation() throws IllegalStateException {
/*  78 */     assertLocationInitialized();
/*  79 */     return this.location.append(".metadata");
/*     */   }
/*     */   
/*     */   public IPath getInstanceDataLocation() throws IllegalStateException {
/*  83 */     assertLocationInitialized();
/*  84 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getLogLocation() throws IllegalStateException {
/*  93 */     if (isInstanceLocationSet())
/*  94 */       assertLocationInitialized(); 
/*  95 */     FrameworkLog log = Activator.getDefault().getFrameworkLog();
/*  96 */     if (log != null) {
/*  97 */       File file = log.getFile();
/*  98 */       if (file != null)
/*  99 */         return (IPath)new Path(file.getAbsolutePath()); 
/*     */     } 
/* 101 */     if (this.location == null)
/* 102 */       throw new IllegalStateException(CommonMessages.meta_instanceDataUnspecified); 
/* 103 */     return this.location.append(".metadata").append(".log");
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getTraceLocation() throws IllegalStateException {
/* 108 */     DebugOptions debugOptions = Activator.getDefault().getDebugOptions();
/* 109 */     if (debugOptions == null) {
/* 110 */       return null;
/*     */     }
/* 112 */     File file = debugOptions.getFile();
/* 113 */     if (file == null) {
/* 114 */       return null;
/*     */     }
/* 116 */     return (IPath)new Path(file.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInstanceLocationSet() {
/* 123 */     Activator activator = Activator.getDefault();
/* 124 */     if (activator == null)
/* 125 */       return false; 
/* 126 */     Location service = activator.getInstanceLocation();
/* 127 */     if (service == null)
/* 128 */       return false; 
/* 129 */     return service.isSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getStateLocation(Bundle bundle) throws IllegalStateException {
/* 136 */     assertLocationInitialized();
/* 137 */     return getStateLocation(bundle.getSymbolicName());
/*     */   }
/*     */   
/*     */   public IPath getStateLocation(String bundleName) throws IllegalStateException {
/* 141 */     assertLocationInitialized();
/* 142 */     return getMetadataLocation().append(".plugins").append(bundleName);
/*     */   }
/*     */   
/*     */   public IPath getPreferenceLocation(String bundleName, boolean create) throws IllegalStateException {
/* 146 */     IPath result = getStateLocation(bundleName);
/* 147 */     if (create)
/* 148 */       result.toFile().mkdirs(); 
/* 149 */     return result.append("pref_store.ini");
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeLocation() throws CoreException {
/* 154 */     if (this.location.toFile().exists() && 
/* 155 */       !this.location.toFile().isDirectory()) {
/* 156 */       String message = NLS.bind(CommonMessages.meta_notDir, this.location);
/* 157 */       throw new CoreException(new Status(4, "org.eclipse.core.runtime", 5, message, null));
/*     */     } 
/*     */ 
/*     */     
/* 161 */     if (this.location.getDevice() == null)
/* 162 */       this.location = (IPath)new Path(this.location.toFile().getAbsolutePath()); 
/* 163 */     createLocation();
/* 164 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void createLocation() throws CoreException {
/* 169 */     File file = this.location.append(".metadata").toFile();
/*     */     try {
/* 171 */       file.mkdirs();
/* 172 */     } catch (Exception e) {
/* 173 */       String message = NLS.bind(CommonMessages.meta_couldNotCreate, file.getAbsolutePath());
/* 174 */       throw new CoreException(new Status(4, "org.eclipse.core.runtime", 5, message, e));
/*     */     } 
/* 176 */     if (!file.canWrite()) {
/* 177 */       String message = NLS.bind(CommonMessages.meta_readonly, file.getAbsolutePath());
/* 178 */       throw new CoreException(new Status(4, "org.eclipse.core.runtime", 5, message, null));
/*     */     } 
/*     */     
/* 181 */     IPath logPath = this.location.append(".metadata").append(".log");
/*     */     try {
/* 183 */       Activator activator1 = Activator.getDefault();
/* 184 */       if (activator1 != null) {
/* 185 */         FrameworkLog log = activator1.getFrameworkLog();
/* 186 */         if (log != null)
/* 187 */         { log.setFile(logPath.toFile(), true); }
/* 188 */         else if (debug())
/* 189 */         { System.out.println("ERROR: Unable to acquire log service. Application will proceed, but logging will be disabled."); } 
/*     */       } 
/* 191 */     } catch (IOException e) {
/* 192 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 196 */     IPath tracePath = this.location.append(".metadata").append("trace.log");
/* 197 */     Activator activator = Activator.getDefault();
/* 198 */     if (activator != null) {
/* 199 */       DebugOptions debugOptions = activator.getDebugOptions();
/* 200 */       if (debugOptions != null) {
/* 201 */         debugOptions.setFile(tracePath.toFile());
/*     */       } else {
/* 203 */         System.out.println("ERROR: Unable to acquire debug service. Application will proceed, but debugging will be disabled.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean debug() {
/* 209 */     Activator activator = Activator.getDefault();
/* 210 */     if (activator == null)
/* 211 */       return false; 
/* 212 */     DebugOptions debugOptions = activator.getDebugOptions();
/* 213 */     if (debugOptions == null)
/* 214 */       return false; 
/* 215 */     return debugOptions.getBooleanOption("org.eclipse.equinox.common/debug", false);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\DataArea.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */