/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class QualifiedName
/*     */ {
/*  32 */   String qualifier = null;
/*     */ 
/*     */ 
/*     */   
/*  36 */   String localName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifiedName(String qualifier, String localName) {
/*  49 */     Assert.isLegal((localName != null && localName.length() != 0));
/*  50 */     this.qualifier = qualifier;
/*  51 */     this.localName = localName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  68 */     if (obj == this) {
/*  69 */       return true;
/*     */     }
/*  71 */     if (!(obj instanceof QualifiedName)) {
/*  72 */       return false;
/*     */     }
/*  74 */     QualifiedName qName = (QualifiedName)obj;
/*     */     
/*  76 */     if (this.qualifier == null && qName.getQualifier() != null) {
/*  77 */       return false;
/*     */     }
/*  79 */     if (this.qualifier != null && !this.qualifier.equals(qName.getQualifier())) {
/*  80 */       return false;
/*     */     }
/*  82 */     return this.localName.equals(qName.getLocalName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalName() {
/*  91 */     return this.localName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQualifier() {
/* 101 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 111 */     return ((this.qualifier == null) ? 0 : this.qualifier.hashCode()) + this.localName.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return String.valueOf((getQualifier() == null) ? "" : (String.valueOf(getQualifier()) + ':')) + getLocalName();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\QualifiedName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */