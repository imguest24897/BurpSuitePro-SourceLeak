/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.eclipse.core.internal.boot.PlatformURLBaseConnection;
/*     */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.eclipse.core.runtime.IAdapterManager;
/*     */ import org.eclipse.core.runtime.ServiceCaller;
/*     */ import org.eclipse.equinox.log.ExtendedLogReaderService;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.eclipse.osgi.service.localization.BundleLocalization;
/*     */ import org.eclipse.osgi.service.urlconversion.URLConverter;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.log.LogListener;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.service.url.URLStreamHandlerService;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   implements BundleActivator
/*     */ {
/*     */   public static final String PLUGIN_ID = "org.eclipse.equinox.common";
/*  49 */   private static Map<String, ServiceTracker<Object, URLConverter>> urlTrackers = new HashMap<>();
/*     */   private static BundleContext bundleContext;
/*     */   private static Activator singleton;
/*  52 */   private ServiceRegistration<URLConverter> platformURLConverterService = null;
/*  53 */   private ServiceRegistration<IAdapterManager> adapterManagerService = null;
/*  54 */   private final ServiceCaller<Location> installLocationTracker = new ServiceCaller(getClass(), Location.class, Location.INSTALL_FILTER);
/*  55 */   private final ServiceCaller<Location> instanceLocationTracker = new ServiceCaller(getClass(), Location.class, Location.INSTANCE_FILTER);
/*  56 */   private final ServiceCaller<Location> configLocationTracker = new ServiceCaller(getClass(), Location.class, Location.CONFIGURATION_FILTER);
/*     */   
/*  58 */   private final ServiceCaller<PackageAdmin> bundleTracker = new ServiceCaller(getClass(), PackageAdmin.class);
/*  59 */   private final ServiceCaller<DebugOptions> debugTracker = new ServiceCaller(getClass(), DebugOptions.class);
/*  60 */   private final ServiceCaller<FrameworkLog> logTracker = new ServiceCaller(getClass(), FrameworkLog.class);
/*  61 */   private final ServiceCaller<BundleLocalization> localizationTracker = new ServiceCaller(getClass(), BundleLocalization.class);
/*     */ 
/*     */   
/*     */   private ServiceRegistration<DebugOptionsListener> debugRegistration;
/*     */ 
/*     */   
/*     */   private ServiceTracker<IAdapterFactory, ?> adapterFactoryTracker;
/*     */ 
/*     */ 
/*     */   
/*     */   public static Activator getDefault() {
/*  72 */     return singleton;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/*  77 */     bundleContext = context;
/*  78 */     singleton = this;
/*     */     
/*  80 */     RuntimeLog.setLogWriter(getPlatformWriter(context));
/*  81 */     Dictionary<String, Object> urlProperties = new Hashtable<>();
/*  82 */     urlProperties.put("protocol", "platform");
/*  83 */     this.platformURLConverterService = context.registerService(URLConverter.class, new PlatformURLConverter(), urlProperties);
/*  84 */     this.adapterManagerService = context.registerService(IAdapterManager.class, AdapterManager.getDefault(), null);
/*  85 */     installPlatformURLSupport();
/*  86 */     Hashtable<String, String> properties = new Hashtable<>(2);
/*  87 */     properties.put("listener.symbolic.name", "org.eclipse.equinox.common");
/*  88 */     this.debugRegistration = context.registerService(DebugOptionsListener.class, TracingOptions.DEBUG_OPTIONS_LISTENER, properties);
/*  89 */     this.adapterFactoryTracker = new ServiceTracker(context, IAdapterFactory.class, new AdapterFactoryBridge(bundleContext));
/*  90 */     this.adapterFactoryTracker.open();
/*     */   }
/*     */   
/*     */   private PlatformLogWriter getPlatformWriter(BundleContext context) {
/*  94 */     ServiceReference<ExtendedLogService> logRef = context.getServiceReference(ExtendedLogService.class);
/*  95 */     ServiceReference<ExtendedLogReaderService> readerRef = context.getServiceReference(ExtendedLogReaderService.class);
/*  96 */     ServiceReference<PackageAdmin> packageAdminRef = context.getServiceReference(PackageAdmin.class);
/*  97 */     if (logRef == null || readerRef == null || packageAdminRef == null)
/*  98 */       return null; 
/*  99 */     ExtendedLogService logService = (ExtendedLogService)context.getService(logRef);
/* 100 */     ExtendedLogReaderService readerService = (ExtendedLogReaderService)context.getService(readerRef);
/* 101 */     PackageAdmin packageAdmin = (PackageAdmin)context.getService(packageAdminRef);
/* 102 */     if (logService == null || readerService == null || packageAdmin == null)
/* 103 */       return null; 
/* 104 */     PlatformLogWriter writer = new PlatformLogWriter(logService, packageAdmin, context.getBundle());
/* 105 */     readerService.addLogListener((LogListener)writer, writer);
/* 106 */     return writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getConfigurationLocation() {
/* 113 */     return this.configLocationTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DebugOptions getDebugOptions() {
/* 120 */     return this.debugTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameworkLog getFrameworkLog() {
/* 127 */     return this.logTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getInstanceLocation() {
/* 134 */     return this.instanceLocationTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle getBundle(String symbolicName) {
/* 143 */     PackageAdmin admin = getBundleAdmin();
/* 144 */     if (admin == null)
/* 145 */       return null; 
/* 146 */     Bundle[] bundles = admin.getBundles(symbolicName, null);
/* 147 */     if (bundles == null)
/* 148 */       return null;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 150 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 151 */       if ((bundle.getState() & 0x3) == 0)
/* 152 */         return bundle; 
/*     */       b++; }
/*     */     
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PackageAdmin getBundleAdmin() {
/* 162 */     return this.bundleTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle[] getFragments(Bundle host) {
/* 169 */     PackageAdmin admin = getBundleAdmin();
/* 170 */     if (admin == null)
/* 171 */       return new Bundle[0]; 
/* 172 */     return admin.getFragments(host);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getInstallLocation() {
/* 179 */     return this.installLocationTracker.current().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBundleId(Object object) {
/* 187 */     if (object == null)
/* 188 */       return null; 
/* 189 */     Bundle source = FrameworkUtil.getBundle(object.getClass());
/* 190 */     if (source != null && source.getSymbolicName() != null)
/* 191 */       return source.getSymbolicName(); 
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getLocalization(Bundle bundle, String locale) throws MissingResourceException {
/* 201 */     if (this.localizationTracker == null) {
/* 202 */       throw new MissingResourceException(CommonMessages.activator_resourceBundleNotStarted, bundle.getSymbolicName(), "");
/*     */     }
/* 204 */     BundleLocalization location = this.localizationTracker.current().orElse(null);
/* 205 */     ResourceBundle result = null;
/* 206 */     if (location != null)
/* 207 */       result = location.getLocalization(bundle, locale); 
/* 208 */     if (result == null)
/* 209 */       throw new MissingResourceException(NLS.bind(CommonMessages.activator_resourceBundleNotFound, locale), bundle.getSymbolicName(), ""); 
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/* 215 */     if (this.adapterFactoryTracker != null) {
/* 216 */       this.adapterFactoryTracker.close();
/*     */     }
/* 218 */     closeURLTrackerServices();
/* 219 */     if (this.platformURLConverterService != null) {
/* 220 */       this.platformURLConverterService.unregister();
/* 221 */       this.platformURLConverterService = null;
/*     */     } 
/* 223 */     if (this.adapterManagerService != null) {
/* 224 */       this.adapterManagerService.unregister();
/* 225 */       this.adapterManagerService = null;
/*     */     } 
/* 227 */     if (this.debugRegistration != null) {
/* 228 */       this.debugRegistration.unregister();
/* 229 */       this.debugRegistration = null;
/*     */     } 
/* 231 */     RuntimeLog.setLogWriter(null);
/* 232 */     bundleContext = null;
/* 233 */     singleton = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BundleContext getContext() {
/* 240 */     return bundleContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void closeURLTrackerServices() {
/* 247 */     synchronized (urlTrackers) {
/* 248 */       if (!urlTrackers.isEmpty()) {
/* 249 */         for (ServiceTracker<Object, URLConverter> tracker : urlTrackers.values()) {
/* 250 */           tracker.close();
/*     */         }
/* 252 */         urlTrackers = new HashMap<>();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URLConverter getURLConverter(URL url) {
/* 262 */     BundleContext ctx = getContext();
/* 263 */     if (url == null || ctx == null) {
/* 264 */       return null;
/*     */     }
/* 266 */     String protocol = url.getProtocol();
/* 267 */     synchronized (urlTrackers) {
/* 268 */       ServiceTracker<Object, URLConverter> tracker = urlTrackers.get(protocol);
/* 269 */       if (tracker == null) {
/*     */         
/* 271 */         String FILTER_PREFIX = "(&(objectClass=" + URLConverter.class.getName() + ")(protocol=";
/* 272 */         String FILTER_POSTFIX = "))";
/* 273 */         Filter filter = null;
/*     */         try {
/* 275 */           filter = ctx.createFilter(String.valueOf(FILTER_PREFIX) + protocol + FILTER_POSTFIX);
/* 276 */         } catch (InvalidSyntaxException invalidSyntaxException) {
/* 277 */           return null;
/*     */         } 
/* 279 */         tracker = new ServiceTracker(getContext(), filter, null);
/* 280 */         tracker.open();
/*     */         
/* 282 */         urlTrackers.put(protocol, tracker);
/*     */       } 
/* 284 */       return (URLConverter)tracker.getService();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void installPlatformURLSupport() {
/* 292 */     PlatformURLPluginConnection.startup();
/* 293 */     PlatformURLFragmentConnection.startup();
/* 294 */     PlatformURLMetaConnection.startup();
/* 295 */     PlatformURLConfigConnection.startup();
/*     */     
/* 297 */     Location service = getInstallLocation();
/* 298 */     if (service != null) {
/* 299 */       PlatformURLBaseConnection.startup(service.getURL());
/*     */     }
/* 301 */     Hashtable<String, String[]> properties = (Hashtable)new Hashtable<>(1);
/* 302 */     properties.put("url.handler.protocol", new String[] { "platform" });
/* 303 */     getContext().registerService(URLStreamHandlerService.class.getName(), new PlatformURLHandler(), properties);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\Activator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */