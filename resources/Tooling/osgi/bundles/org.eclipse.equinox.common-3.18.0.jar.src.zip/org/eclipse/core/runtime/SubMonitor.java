/*      */ package org.eclipse.core.runtime;
/*      */ 
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*      */ import org.eclipse.core.internal.runtime.TracingOptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SubMonitor
/*      */   implements IProgressMonitorWithBlocking
/*      */ {
/*      */   private static final int TRIVIAL_SPLITS_BEFORE_CANCELLATION_CHECK = 20;
/*      */   private static final int TRIVIAL_OPERATION_COUNT_LIMIT = 20;
/*      */   private static final int TRIVIAL_SPLIT_DELTA = 1;
/*      */   private static final int MINIMUM_RESOLUTION = 1000;
/*      */   private int totalParent;
/*      */   
/*      */   private static final class RootInfo
/*      */   {
/*      */     final IProgressMonitor root;
/*      */     String taskName;
/*      */     String subTask;
/*      */     int cancellationCheckCounter;
/*      */     
/*      */     public RootInfo(IProgressMonitor root) {
/*  231 */       this.root = root;
/*      */     }
/*      */     
/*      */     public boolean isCanceled() {
/*  235 */       return this.root.isCanceled();
/*      */     }
/*      */     
/*      */     public void setCanceled(boolean value) {
/*  239 */       this.root.setCanceled(value);
/*      */     }
/*      */     
/*      */     public void setTaskName(String taskName) {
/*  243 */       if (SubMonitor.eq(taskName, this.taskName)) {
/*      */         return;
/*      */       }
/*  246 */       this.taskName = taskName;
/*  247 */       this.root.setTaskName(taskName);
/*      */     }
/*      */     
/*      */     public void subTask(String name) {
/*  251 */       if (SubMonitor.eq(this.subTask, name)) {
/*      */         return;
/*      */       }
/*      */       
/*  255 */       this.subTask = name;
/*  256 */       this.root.subTask(name);
/*      */     }
/*      */     
/*      */     public void worked(int i) {
/*  260 */       this.root.worked(i);
/*      */     }
/*      */     
/*      */     public void clearBlocked() {
/*  264 */       this.root.clearBlocked();
/*      */     }
/*      */ 
/*      */     
/*      */     public void setBlocked(IStatus reason) {
/*  269 */       this.root.setBlocked(reason);
/*      */     }
/*      */     
/*      */     public void checkForCancellation() {
/*  273 */       if (this.root.isCanceled()) {
/*  274 */         throw new OperationCanceledException();
/*      */       }
/*      */     }
/*      */     
/*      */     public void reportTrivialOperation(int cancellationDelta) {
/*  279 */       this.cancellationCheckCounter += cancellationDelta;
/*      */       
/*  281 */       if (this.cancellationCheckCounter >= 20) {
/*  282 */         this.cancellationCheckCounter = 0;
/*  283 */         checkForCancellation();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   private int usedForParent = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  302 */   private double usedForChildren = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int totalForChildren;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SubMonitor lastSubMonitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final RootInfo root;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int flags;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean beginTaskCalled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ticksAllocated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_SUBTASK = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_BEGINTASK = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_SETTASKNAME = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_ISCANCELED = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_ALL_LABELS = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUPPRESS_NONE = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ALL_PUBLIC_FLAGS = 15;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ALL_INHERITED_FLAGS = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  394 */   private static final Set<String> knownBuggyMethods = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SubMonitor(RootInfo rootInfo, int totalWork, int availableToChildren, int flags) {
/*  405 */     this.root = rootInfo;
/*  406 */     this.totalParent = (totalWork > 0) ? totalWork : 0;
/*  407 */     this.totalForChildren = availableToChildren;
/*  408 */     this.flags = flags;
/*  409 */     this.ticksAllocated = (availableToChildren > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SubMonitor convert(IProgressMonitor monitor) {
/*  428 */     return convert(monitor, "", 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SubMonitor convert(IProgressMonitor monitor, int work) {
/*  449 */     return convert(monitor, "", work);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SubMonitor convert(IProgressMonitor monitor, String taskName, int work) {
/*  471 */     if (monitor == null) {
/*  472 */       monitor = new NullProgressMonitor();
/*  473 */       return new SubMonitor(new RootInfo(monitor), 0, work, 7);
/*      */     } 
/*      */ 
/*      */     
/*  477 */     if (monitor instanceof SubMonitor) {
/*  478 */       SubMonitor subMonitor = (SubMonitor)monitor;
/*  479 */       subMonitor.beginTaskImpl(taskName, work);
/*  480 */       return subMonitor;
/*      */     } 
/*      */     
/*  483 */     monitor.beginTask(taskName, 1000);
/*  484 */     return new SubMonitor(new RootInfo(monitor), 1000, work, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void done(IProgressMonitor monitor) {
/*  498 */     if (monitor != null) {
/*  499 */       monitor.done();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor setWorkRemaining(int workRemaining) {
/*  518 */     if (TracingOptions.debugProgressMonitors && this.ticksAllocated && this.usedForChildren >= this.totalForChildren && workRemaining > 0) {
/*  519 */       logProblem("Attempted to allocate ticks on a SubMonitor which had no space available. This may indicate that a SubMonitor was reused inappropriately (which is a bug) or may indicate that the caller was implementing infinite progress and overflowed (which may not be a bug but may require selecting a higher ratio)");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  526 */     if (workRemaining > 0) {
/*  527 */       this.ticksAllocated = true;
/*      */     } else {
/*  529 */       workRemaining = 0;
/*      */     } 
/*      */ 
/*      */     
/*  533 */     if (this.totalForChildren > 0 && this.totalParent > this.usedForParent) {
/*      */       
/*  535 */       double remainForParent = this.totalParent * (1.0D - this.usedForChildren / this.totalForChildren);
/*  536 */       this.usedForChildren = workRemaining * (1.0D - remainForParent / (this.totalParent - this.usedForParent));
/*      */     } else {
/*  538 */       this.usedForChildren = 0.0D;
/*      */     } 
/*  540 */     this.totalParent -= this.usedForParent;
/*  541 */     this.usedForParent = 0;
/*  542 */     this.totalForChildren = workRemaining;
/*  543 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int consume(double ticks) {
/*  554 */     if (TracingOptions.debugProgressMonitors && !this.ticksAllocated && ticks > 0.0D) {
/*  555 */       logProblem("You must allocate ticks using beginTask or setWorkRemaining before trying to consume them");
/*      */     }
/*      */     
/*  558 */     if (this.totalParent == 0 || this.totalForChildren == 0) {
/*  559 */       return 0;
/*      */     }
/*  561 */     this.usedForChildren += ticks;
/*      */     
/*  563 */     if (this.usedForChildren > this.totalForChildren) {
/*  564 */       this.usedForChildren = this.totalForChildren;
/*  565 */       if (TracingOptions.debugProgressMonitors) {
/*  566 */         logProblem("This progress monitor consumed more ticks than were allocated for it.");
/*      */       }
/*  568 */     } else if (this.usedForChildren < 0.0D) {
/*  569 */       this.usedForChildren = 0.0D;
/*      */     } 
/*  571 */     int parentPosition = (int)(this.totalParent * this.usedForChildren / this.totalForChildren);
/*  572 */     int delta = parentPosition - this.usedForParent;
/*      */     
/*  574 */     this.usedForParent = parentPosition;
/*  575 */     return delta;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCanceled() {
/*  580 */     if ((this.flags & 0x8) == 0) {
/*  581 */       return this.root.isCanceled();
/*      */     }
/*  583 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor checkCanceled() throws OperationCanceledException {
/*  601 */     if (isCanceled()) {
/*  602 */       throw new OperationCanceledException();
/*      */     }
/*  604 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTaskName(String name) {
/*  609 */     if ((this.flags & 0x4) == 0) {
/*  610 */       this.root.setTaskName(name);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginTask(String name, int totalWork) {
/*  629 */     if (TracingOptions.debugProgressMonitors && this.beginTaskCalled) {
/*  630 */       logProblem("beginTask was called on this instance more than once");
/*      */     }
/*  632 */     beginTaskImpl(name, totalWork);
/*      */   }
/*      */   
/*      */   private void beginTaskImpl(String name, int totalWork) {
/*  636 */     if ((this.flags & 0x2) == 0 && name != null)
/*  637 */       this.root.setTaskName(name); 
/*  638 */     setWorkRemaining(totalWork);
/*  639 */     this.beginTaskCalled = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void done() {
/*  644 */     cleanupActiveChild();
/*  645 */     int delta = this.totalParent - this.usedForParent;
/*  646 */     if (delta > 0) {
/*  647 */       this.root.worked(delta);
/*      */     }
/*  649 */     this.totalParent = 0;
/*  650 */     this.usedForParent = 0;
/*  651 */     this.totalForChildren = 0;
/*  652 */     this.usedForChildren = 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public void internalWorked(double work) {
/*  657 */     cleanupActiveChild();
/*      */     
/*  659 */     int delta = consume((work > 0.0D) ? work : 0.0D);
/*  660 */     if (delta != 0) {
/*  661 */       this.root.worked(delta);
/*      */     }
/*      */   }
/*      */   
/*      */   public void subTask(String name) {
/*  666 */     if ((this.flags & 0x1) == 0) {
/*  667 */       this.root.subTask(name);
/*      */     }
/*      */   }
/*      */   
/*      */   public void worked(int work) {
/*  672 */     if (TracingOptions.debugProgressMonitors && work == 0) {
/*  673 */       logProblem("Attempted to report 0 ticks of work");
/*      */     }
/*      */     
/*  676 */     internalWorked(work);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCanceled(boolean b) {
/*  681 */     this.root.setCanceled(b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor newChild(int totalWork) {
/*  696 */     return newChild(totalWork, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor newChild(int totalWork, int suppressFlags) {
/*  768 */     double totalWorkDouble = (totalWork > 0) ? totalWork : 0.0D;
/*  769 */     totalWorkDouble = Math.min(totalWorkDouble, this.totalForChildren - this.usedForChildren);
/*  770 */     SubMonitor oldActiveChild = this.lastSubMonitor;
/*  771 */     cleanupActiveChild();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  778 */     int childFlags = this.flags & 0x9;
/*      */     
/*  780 */     if ((this.flags & 0x4) != 0)
/*      */     {
/*      */ 
/*      */       
/*  784 */       childFlags |= 0x6;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  789 */     childFlags |= suppressFlags & 0xF;
/*      */     
/*  791 */     int consumed = consume(totalWorkDouble);
/*      */     
/*  793 */     if (TracingOptions.debugProgressMonitors) {
/*  794 */       if (totalWork == 0) {
/*  795 */         logProblem("Attempted to create a child without providing it with any ticks");
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  804 */       if (consumed == 0 && oldActiveChild != null && childFlags == oldActiveChild.flags) {
/*  805 */         this.lastSubMonitor = oldActiveChild;
/*  806 */         return oldActiveChild;
/*      */       } 
/*      */ 
/*      */       
/*  810 */       if (this.usedForParent >= this.totalParent && childFlags == this.flags) {
/*  811 */         this.totalParent = consumed;
/*  812 */         this.usedForParent = 0;
/*  813 */         this.totalForChildren = 0;
/*  814 */         this.usedForChildren = 0.0D;
/*  815 */         return this;
/*      */       } 
/*      */     } 
/*      */     
/*  819 */     SubMonitor result = new SubMonitor(this.root, consumed, 0, childFlags);
/*  820 */     this.lastSubMonitor = result;
/*  821 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor split(int totalWork) throws OperationCanceledException {
/*  895 */     return split(totalWork, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubMonitor split(int totalWork, int suppressFlags) throws OperationCanceledException {
/*  970 */     int oldUsedForParent = this.usedForParent;
/*  971 */     SubMonitor result = newChild(totalWork, suppressFlags);
/*      */     
/*  973 */     if ((result.flags & 0x8) == 0) {
/*  974 */       int ticksTheChildWillReportToParent = result.totalParent;
/*      */ 
/*      */       
/*  977 */       if (ticksTheChildWillReportToParent > 0) {
/*      */ 
/*      */         
/*  980 */         if (oldUsedForParent > 0 || this.usedForParent < this.totalParent)
/*      */         {
/*  982 */           this.root.checkForCancellation();
/*      */         }
/*      */       } else {
/*  985 */         this.root.reportTrivialOperation(1);
/*      */       } 
/*      */     } 
/*  988 */     return result;
/*      */   }
/*      */   
/*      */   private void cleanupActiveChild() {
/*  992 */     IProgressMonitor child = this.lastSubMonitor;
/*  993 */     if (child == null) {
/*      */       return;
/*      */     }
/*      */     
/*  997 */     this.lastSubMonitor = null;
/*  998 */     child.done();
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearBlocked() {
/* 1003 */     this.root.clearBlocked();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlocked(IStatus reason) {
/* 1008 */     this.root.setBlocked(reason);
/*      */   }
/*      */   
/*      */   protected static boolean eq(Object o1, Object o2) {
/* 1012 */     if (o1 == null)
/* 1013 */       return (o2 == null); 
/* 1014 */     if (o2 == null)
/* 1015 */       return false; 
/* 1016 */     return o1.equals(o2);
/*      */   }
/*      */   
/*      */   private static String getCallerName() {
/* 1020 */     StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
/*      */     
/* 1022 */     String ourClassName = SubMonitor.class.getCanonicalName();
/* 1023 */     for (int idx = 1; idx < stackTrace.length; ) {
/* 1024 */       String className = stackTrace[idx].getClassName();
/* 1025 */       if (className.equals(ourClassName)) {
/*      */         idx++;
/*      */         continue;
/*      */       } 
/* 1029 */       return stackTrace[idx].toString();
/*      */     } 
/*      */     
/* 1032 */     return "Unknown";
/*      */   }
/*      */   
/*      */   private static void logProblem(String message) {
/* 1036 */     String caller = getCallerName();
/* 1037 */     synchronized (knownBuggyMethods) {
/* 1038 */       if (!knownBuggyMethods.add(caller)) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1042 */     RuntimeLog.log(new Status(2, "org.eclipse.core.runtime", message, new Throwable()));
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1047 */     return "SubMonitor [totalParent=" + this.totalParent + ", usedForParent=" + this.usedForParent + ", usedForChildren=" + this.usedForChildren + ", totalForChildren=" + this.totalForChildren + ", beginTaskCalled=" + this.beginTaskCalled + "]";
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\SubMonitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */