/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SubProgressMonitor
/*     */   extends ProgressMonitorWrapper
/*     */ {
/*     */   public static final int SUPPRESS_SUBTASK_LABEL = 2;
/*     */   public static final int PREPEND_MAIN_LABEL_TO_SUBTASK = 4;
/*  88 */   private int parentTicks = 0;
/*  89 */   private double sentToParent = 0.0D;
/*  90 */   private double scale = 0.0D;
/*  91 */   private int nestedBeginTasks = 0;
/*     */ 
/*     */   
/*     */   private boolean usedUp = false;
/*     */ 
/*     */   
/*     */   private boolean hasSubTask = false;
/*     */ 
/*     */   
/*     */   private int style;
/*     */ 
/*     */   
/*     */   private String mainTaskLabel;
/*     */ 
/*     */   
/*     */   public SubProgressMonitor(IProgressMonitor monitor, int ticks) {
/* 107 */     this(monitor, ticks, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubProgressMonitor(IProgressMonitor monitor, int ticks, int style) {
/* 127 */     super(monitor);
/* 128 */     this.parentTicks = (ticks > 0) ? ticks : 0;
/* 129 */     this.style = style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginTask(String name, int totalWork) {
/* 143 */     this.nestedBeginTasks++;
/*     */     
/* 145 */     if (this.nestedBeginTasks > 1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 151 */     this.scale = (totalWork <= 0) ? 0.0D : (this.parentTicks / totalWork);
/* 152 */     if ((this.style & 0x4) != 0) {
/* 153 */       this.mainTaskLabel = name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void done() {
/* 161 */     if (this.nestedBeginTasks == 0 || --this.nestedBeginTasks > 0) {
/*     */       return;
/*     */     }
/* 164 */     double remaining = this.parentTicks - this.sentToParent;
/* 165 */     if (remaining > 0.0D) {
/* 166 */       super.internalWorked(remaining);
/*     */     }
/* 168 */     if (this.hasSubTask)
/* 169 */       subTask(""); 
/* 170 */     this.sentToParent = 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void internalWorked(double work) {
/* 175 */     if (this.usedUp || this.nestedBeginTasks != 1) {
/*     */       return;
/*     */     }
/*     */     
/* 179 */     double realWork = (work > 0.0D) ? (this.scale * work) : 0.0D;
/* 180 */     super.internalWorked(realWork);
/* 181 */     this.sentToParent += realWork;
/* 182 */     if (this.sentToParent >= this.parentTicks) {
/* 183 */       this.usedUp = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void subTask(String name) {
/* 189 */     if ((this.style & 0x2) != 0) {
/*     */       return;
/*     */     }
/* 192 */     this.hasSubTask = true;
/* 193 */     String label = name;
/* 194 */     if ((this.style & 0x4) != 0 && this.mainTaskLabel != null && this.mainTaskLabel.length() > 0) {
/* 195 */       label = String.valueOf(this.mainTaskLabel) + ' ' + label;
/*     */     }
/* 197 */     super.subTask(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public void worked(int work) {
/* 202 */     internalWorked(work);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\SubProgressMonitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */