/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceTranslator
/*     */ {
/*     */   private static final String KEY_PREFIX = "%";
/*     */   private static final String KEY_DOUBLE_PREFIX = "%%";
/*     */   
/*     */   public static String getResourceString(Bundle bundle, String value) {
/*  31 */     return getResourceString(bundle, value, (ResourceBundle)null);
/*     */   }
/*     */   
/*     */   public static String getResourceString(Bundle bundle, String value, ResourceBundle resourceBundle) {
/*  35 */     String s = value.trim();
/*  36 */     if (!s.startsWith("%", 0))
/*  37 */       return s; 
/*  38 */     if (s.startsWith("%%", 0)) {
/*  39 */       return s.substring(1);
/*     */     }
/*  41 */     int ix = s.indexOf(' ');
/*  42 */     String key = (ix == -1) ? s : s.substring(0, ix);
/*  43 */     String dflt = (ix == -1) ? s : s.substring(ix + 1);
/*     */     
/*  45 */     if (resourceBundle == null && bundle != null) {
/*     */       try {
/*  47 */         resourceBundle = getResourceBundle(bundle);
/*  48 */       } catch (MissingResourceException missingResourceException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  53 */     if (resourceBundle == null) {
/*  54 */       return dflt;
/*     */     }
/*     */     try {
/*  57 */       return resourceBundle.getString(key.substring(1));
/*  58 */     } catch (MissingResourceException missingResourceException) {
/*     */       
/*  60 */       return dflt;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ResourceBundle getResourceBundle(Bundle bundle) throws MissingResourceException {
/*  65 */     return getResourceBundle(bundle, null);
/*     */   }
/*     */   
/*     */   private static ResourceBundle getResourceBundle(Bundle bundle, String language) throws MissingResourceException {
/*  69 */     if (hasRuntime21(bundle)) {
/*  70 */       Locale locale = (language == null) ? Locale.getDefault() : new Locale(language);
/*  71 */       return ResourceBundle.getBundle("plugin", locale, createTempClassloader(bundle));
/*     */     } 
/*  73 */     return Activator.getDefault().getLocalization(bundle, language);
/*     */   }
/*     */   
/*     */   public static String[] getResourceString(Bundle bundle, String[] nonTranslated, String locale) {
/*  77 */     if (bundle == null) {
/*  78 */       return nonTranslated;
/*     */     }
/*  80 */     ResourceBundle resourceBundle = null;
/*     */     try {
/*  82 */       resourceBundle = getResourceBundle(bundle, locale);
/*  83 */     } catch (MissingResourceException missingResourceException) {}
/*     */ 
/*     */     
/*  86 */     String[] translated = new String[nonTranslated.length];
/*  87 */     for (int i = 0; i < nonTranslated.length; i++) {
/*  88 */       translated[i] = getResourceString(bundle, nonTranslated[i], resourceBundle);
/*     */     }
/*  90 */     return translated;
/*     */   }
/*     */   
/*     */   private static boolean hasRuntime21(Bundle b) {
/*     */     try {
/*  95 */       ManifestElement[] prereqs = ManifestElement.parseHeader("Require-Bundle", (String)b.getHeaders("").get("Require-Bundle"));
/*  96 */       if (prereqs == null)
/*  97 */         return false;  byte b1; int i; ManifestElement[] arrayOfManifestElement1;
/*  98 */       for (i = (arrayOfManifestElement1 = prereqs).length, b1 = 0; b1 < i; ) { ManifestElement prereq = arrayOfManifestElement1[b1];
/*  99 */         if ("2.1".equals(prereq.getAttribute("bundle-version")) && "org.eclipse.core.runtime".equals(prereq.getValue()))
/* 100 */           return true; 
/*     */         b1++; }
/*     */     
/* 103 */     } catch (BundleException bundleException) {
/* 104 */       return false;
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   private static ClassLoader createTempClassloader(Bundle b) {
/* 110 */     ArrayList<URL> classpath = new ArrayList<>();
/* 111 */     addClasspathEntries(b, classpath);
/* 112 */     addBundleRoot(b, classpath);
/* 113 */     addDevEntries(b, classpath);
/* 114 */     addFragments(b, classpath);
/* 115 */     URL[] urls = new URL[classpath.size()];
/* 116 */     return new URLClassLoader(classpath.<URL>toArray(urls));
/*     */   }
/*     */   
/*     */   private static void addFragments(Bundle host, ArrayList<URL> classpath) {
/* 120 */     Activator activator = Activator.getDefault();
/* 121 */     if (activator == null)
/*     */       return; 
/* 123 */     Bundle[] fragments = activator.getFragments(host);
/* 124 */     if (fragments == null)
/*     */       return;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 127 */     for (i = (arrayOfBundle1 = fragments).length, b = 0; b < i; ) { Bundle fragment = arrayOfBundle1[b];
/* 128 */       addClasspathEntries(fragment, classpath);
/* 129 */       addDevEntries(fragment, classpath);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   private static void addClasspathEntries(Bundle b, ArrayList<URL> classpath) {
/*     */     try {
/* 136 */       ManifestElement[] classpathElements = ManifestElement.parseHeader("Bundle-ClassPath", (String)b.getHeaders("").get("Bundle-ClassPath"));
/* 137 */       if (classpathElements == null)
/*     */         return;  byte b1; int i; ManifestElement[] arrayOfManifestElement1;
/* 139 */       for (i = (arrayOfManifestElement1 = classpathElements).length, b1 = 0; b1 < i; ) { ManifestElement classpathElement = arrayOfManifestElement1[b1];
/* 140 */         URL classpathEntry = b.getEntry(classpathElement.getValue());
/* 141 */         if (classpathEntry != null)
/* 142 */           classpath.add(classpathEntry);  b1++; }
/*     */     
/* 144 */     } catch (BundleException bundleException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addBundleRoot(Bundle b, ArrayList<URL> classpath) {
/* 150 */     classpath.add(b.getEntry("/"));
/*     */   }
/*     */   
/*     */   private static void addDevEntries(Bundle b, ArrayList<URL> classpath) {
/* 154 */     if (!DevClassPathHelper.inDevelopmentMode()) {
/*     */       return;
/*     */     }
/* 157 */     String[] binaryPaths = DevClassPathHelper.getDevClassPath(b.getSymbolicName()); byte b1; int i; String[] arrayOfString1;
/* 158 */     for (i = (arrayOfString1 = binaryPaths).length, b1 = 0; b1 < i; ) { String binaryPath = arrayOfString1[b1];
/* 159 */       URL classpathEntry = b.getEntry(binaryPath);
/* 160 */       if (classpathEntry != null)
/* 161 */         classpath.add(classpathEntry); 
/*     */       b1++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\ResourceTranslator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */