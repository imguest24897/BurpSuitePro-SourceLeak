/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdapterFactoryBridge
/*     */   implements ServiceTrackerCustomizer<IAdapterFactory, AdapterFactoryBridge.LazyAdapterFactory>
/*     */ {
/*     */   private BundleContext bundleContext;
/*     */   
/*     */   public AdapterFactoryBridge(BundleContext bundleContext) {
/*  31 */     this.bundleContext = bundleContext;
/*     */   }
/*     */   
/*     */   public LazyAdapterFactory addingService(ServiceReference<IAdapterFactory> reference) {
/*     */     LazyAdapterFactory proxy;
/*  36 */     String[] adaptableClasses = getMultiProperty(reference, "adaptableClass");
/*  37 */     String[] adapterNames = getMultiProperty(reference, "adapterNames");
/*     */     
/*  39 */     if (adapterNames.length == 0 && reference.getProperty("adapterNames") == null) {
/*  40 */       proxy = new LazyAdapterFactory(reference, this.bundleContext);
/*     */     } else {
/*  42 */       proxy = new LazyAdapterFactoryExtServiceProxy(adapterNames, reference, this.bundleContext);
/*     */     } 
/*  44 */     AdapterManager manager = AdapterManager.getDefault(); byte b; int i; String[] arrayOfString1;
/*  45 */     for (i = (arrayOfString1 = adaptableClasses).length, b = 0; b < i; ) { String adaptableClass = arrayOfString1[b];
/*  46 */       manager.registerFactory(proxy, adaptableClass); b++; }
/*     */     
/*  48 */     manager.flushLookup();
/*  49 */     return proxy;
/*     */   }
/*     */   
/*     */   private static String[] getMultiProperty(ServiceReference<?> reference, String propertyName) {
/*  53 */     Object property = reference.getProperty(propertyName);
/*  54 */     if (property instanceof String) {
/*  55 */       String string = (String)property;
/*  56 */       if (string.length() > 0)
/*  57 */         return new String[] { string }; 
/*     */     } else {
/*  59 */       if (property instanceof String[])
/*  60 */         return (String[])property; 
/*  61 */       if (property instanceof Collection) {
/*  62 */         Collection<?> collection = (Collection)property;
/*  63 */         return (String[])collection.stream().filter(String.class::isInstance).map(String.class::cast).toArray(paramInt -> new String[paramInt]);
/*     */       } 
/*  65 */     }  return new String[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<IAdapterFactory> reference, LazyAdapterFactory proxy) {
/*  70 */     String[] adaptableClasses = getMultiProperty(reference, "adaptableClass");
/*  71 */     AdapterManager manager = AdapterManager.getDefault();
/*  72 */     manager.unregisterAdapters(proxy);
/*  73 */     if (proxy instanceof LazyAdapterFactoryExtServiceProxy) {
/*  74 */       LazyAdapterFactoryExtServiceProxy lazy = (LazyAdapterFactoryExtServiceProxy)proxy;
/*  75 */       lazy.adapterNames = getMultiProperty(reference, "adapterNames");
/*     */     }  byte b; int i; String[] arrayOfString1;
/*  77 */     for (i = (arrayOfString1 = adaptableClasses).length, b = 0; b < i; ) { String adaptableClass = arrayOfString1[b];
/*  78 */       manager.registerFactory(proxy, adaptableClass); b++; }
/*     */     
/*  80 */     manager.flushLookup();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<IAdapterFactory> reference, LazyAdapterFactory proxy) {
/*  85 */     AdapterManager manager = AdapterManager.getDefault();
/*  86 */     manager.unregisterAdapters(proxy);
/*  87 */     proxy.dispose();
/*     */   }
/*     */   
/*     */   public static class LazyAdapterFactory
/*     */     implements IAdapterFactory {
/*     */     IAdapterFactory service;
/*     */     volatile boolean disposed;
/*     */     private final ServiceReference<IAdapterFactory> reference;
/*     */     private final BundleContext bundleContext;
/*     */     
/*     */     LazyAdapterFactory(ServiceReference<IAdapterFactory> reference, BundleContext bundleContext) {
/*  98 */       this.reference = reference;
/*  99 */       this.bundleContext = bundleContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getAdapter(Object adaptableObject, Class<T> adapterType) {
/* 104 */       if (!this.disposed) {
/* 105 */         IAdapterFactory factory = getFactoryService();
/* 106 */         if (factory != null) {
/* 107 */           return (T)factory.getAdapter(adaptableObject, adapterType);
/*     */         }
/*     */       } 
/* 110 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?>[] getAdapterList() {
/* 115 */       if (!this.disposed) {
/* 116 */         IAdapterFactory factory = getFactoryService();
/* 117 */         if (factory != null) {
/* 118 */           return factory.getAdapterList();
/*     */         }
/*     */       } 
/* 121 */       return new Class[0];
/*     */     }
/*     */     
/*     */     synchronized IAdapterFactory getFactoryService() {
/* 125 */       if (this.service == null && !this.disposed) {
/* 126 */         this.service = (IAdapterFactory)this.bundleContext.getService(this.reference);
/*     */       }
/* 128 */       return this.service;
/*     */     }
/*     */     
/*     */     synchronized void dispose() {
/* 132 */       this.disposed = true;
/* 133 */       if (this.service != null) {
/* 134 */         this.service = null;
/* 135 */         this.bundleContext.ungetService(this.reference);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LazyAdapterFactoryExtServiceProxy
/*     */     extends LazyAdapterFactory
/*     */     implements IAdapterFactoryExt {
/*     */     volatile String[] adapterNames;
/*     */     
/*     */     LazyAdapterFactoryExtServiceProxy(String[] adapterNames, ServiceReference<IAdapterFactory> reference, BundleContext bundleContext) {
/* 146 */       super(reference, bundleContext);
/* 147 */       this.adapterNames = adapterNames;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized IAdapterFactory loadFactory(boolean force) {
/* 152 */       if (force) {
/* 153 */         return getFactoryService();
/*     */       }
/* 155 */       return this.service;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getAdapterNames() {
/* 160 */       return (String[])this.adapterNames.clone();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\AdapterFactoryBridge.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */