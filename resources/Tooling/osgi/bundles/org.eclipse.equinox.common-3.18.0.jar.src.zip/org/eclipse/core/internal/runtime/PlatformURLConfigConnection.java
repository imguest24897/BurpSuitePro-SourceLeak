/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URL;
/*    */ import java.net.UnknownServiceException;
/*    */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*    */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*    */ import org.eclipse.osgi.service.datalocation.Location;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLConfigConnection
/*    */   extends PlatformURLConnection
/*    */ {
/*    */   private static final String FILE_PROTOCOL = "file";
/*    */   private static boolean isRegistered = false;
/*    */   public static final String CONFIG = "config";
/*    */   private boolean parentConfiguration = false;
/*    */   
/*    */   public PlatformURLConfigConnection(URL url) {
/* 35 */     super(url);
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL resolve() throws IOException {
/* 40 */     String spec = this.url.getFile().trim();
/* 41 */     if (spec.startsWith("/"))
/* 42 */       spec = spec.substring(1); 
/* 43 */     if (!spec.startsWith("config"))
/* 44 */       throw new IOException(NLS.bind(CommonMessages.url_badVariant, this.url.toString())); 
/* 45 */     String path = spec.substring("config".length() + 1);
/*    */     
/* 47 */     Activator activator = Activator.getDefault();
/* 48 */     if (activator == null)
/* 49 */       throw new IOException(CommonMessages.activator_not_available); 
/* 50 */     Location localConfig = activator.getConfigurationLocation();
/* 51 */     Location parentConfig = localConfig.getParentLocation();
/*    */     
/* 53 */     URL localURL = new URL(localConfig.getURL(), path);
/* 54 */     if (!"file".equals(localURL.getProtocol()) || parentConfig == null)
/*    */     {
/* 56 */       return localURL; } 
/* 57 */     File localFile = new File(localURL.getPath());
/* 58 */     if (localFile.exists())
/*    */     {
/* 60 */       return localURL;
/*    */     }
/* 62 */     URL parentURL = new URL(parentConfig.getURL(), path);
/* 63 */     if ("file".equals(parentURL.getProtocol())) {
/*    */       
/* 65 */       File parentFile = new File(parentURL.getPath());
/* 66 */       if (parentFile.exists()) {
/*    */         
/* 68 */         this.parentConfiguration = true;
/* 69 */         return parentURL;
/*    */       } 
/*    */     } 
/* 72 */     return localURL;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void startup() {
/* 77 */     if (isRegistered)
/*    */       return; 
/* 79 */     PlatformURLHandler.register("config", PlatformURLConfigConnection.class);
/* 80 */     isRegistered = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public OutputStream getOutputStream() throws IOException {
/* 85 */     if (this.parentConfiguration || Activator.getDefault() == null || Activator.getDefault().getConfigurationLocation().isReadOnly()) {
/* 86 */       throw new UnknownServiceException(NLS.bind(CommonMessages.url_noOutput, this.url));
/*    */     }
/* 88 */     URL resolved = getResolvedURL();
/* 89 */     if (resolved != null) {
/* 90 */       String fileString = resolved.getFile();
/* 91 */       if (fileString != null) {
/* 92 */         File file = new File(fileString);
/* 93 */         String parent = file.getParent();
/* 94 */         if (parent != null)
/* 95 */           (new File(parent)).mkdirs(); 
/* 96 */         return new FileOutputStream(file);
/*    */       } 
/*    */     } 
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformURLConfigConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */