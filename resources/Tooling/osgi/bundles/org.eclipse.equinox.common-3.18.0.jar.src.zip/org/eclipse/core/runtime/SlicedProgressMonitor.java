/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SlicedProgressMonitor
/*     */   implements IProgressMonitor
/*     */ {
/*     */   private final int slicedWork;
/*     */   private final IProgressMonitor monitor;
/*     */   private Boolean canceled;
/*     */   private double increment;
/*     */   private String taskName;
/*     */   private double accumulator;
/*     */   private int workUnits;
/*     */   private boolean beginTaskCalled;
/*     */   private String subTaskName;
/*     */   
/*     */   public SlicedProgressMonitor(IProgressMonitor monitor, int totalWork) {
/*  33 */     this.monitor = monitor;
/*  34 */     this.slicedWork = totalWork;
/*  35 */     this.workUnits = totalWork;
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginTask(String name, int totalWork) {
/*  40 */     if (this.beginTaskCalled) {
/*  41 */       throw new IllegalStateException("This must only be called once on a given progress monitor instance.");
/*     */     }
/*  43 */     this.taskName = name;
/*  44 */     if (totalWork > 0) {
/*  45 */       this.increment = this.slicedWork / totalWork;
/*     */     }
/*  47 */     this.beginTaskCalled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void done() {
/*  52 */     if (this.workUnits > 0) {
/*  53 */       synchronized (this.monitor) {
/*  54 */         this.monitor.worked(this.workUnits);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void internalWorked(double internalWork) {
/*  61 */     this.accumulator += internalWork;
/*  62 */     int workConsumed = 0;
/*  63 */     while (this.accumulator >= 1.0D && this.workUnits > 0) {
/*  64 */       this.accumulator--;
/*  65 */       this.workUnits--;
/*  66 */       workConsumed++;
/*     */     } 
/*  68 */     if (workConsumed > 0) {
/*  69 */       synchronized (this.monitor) {
/*  70 */         this.monitor.worked(workConsumed);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/*  77 */     if (this.canceled != null) {
/*  78 */       return this.canceled.booleanValue();
/*     */     }
/*  80 */     synchronized (this.monitor) {
/*  81 */       return this.monitor.isCanceled();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCanceled(boolean value) {
/*  87 */     this.canceled = Boolean.valueOf(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTaskName(String name) {
/*  92 */     this.taskName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subTask(String name) {
/*  97 */     this.subTaskName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void worked(int work) {
/* 102 */     if (work > 0 && this.increment > 0.0D) {
/* 103 */       internalWorked(work * this.increment);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getName() {
/* 108 */     return this.taskName;
/*     */   }
/*     */   
/*     */   public String getSubTaskName() {
/* 112 */     return this.subTaskName;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\SlicedProgressMonitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */