package org.eclipse.core.runtime;

import java.util.EventListener;

public interface ILogListener extends EventListener {
  void logging(IStatus paramIStatus, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\ILogListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */