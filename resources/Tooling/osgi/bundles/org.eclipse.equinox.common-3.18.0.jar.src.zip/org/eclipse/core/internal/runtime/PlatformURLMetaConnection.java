/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*    */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLMetaConnection
/*    */   extends PlatformURLConnection
/*    */ {
/* 25 */   private Bundle target = null;
/*    */   
/*    */   private static boolean isRegistered = false;
/*    */   
/*    */   public static final String META = "meta";
/*    */ 
/*    */   
/*    */   public PlatformURLMetaConnection(URL url) {
/* 33 */     super(url);
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL resolve() throws IOException {
/* 38 */     String spec = this.url.getFile().trim();
/* 39 */     if (spec.startsWith("/"))
/* 40 */       spec = spec.substring(1); 
/* 41 */     if (!spec.startsWith("meta"))
/* 42 */       throw new IOException(NLS.bind(CommonMessages.url_badVariant, this.url.toString())); 
/* 43 */     int ix = spec.indexOf('/', "meta".length() + 1);
/* 44 */     String ref = (ix == -1) ? spec.substring("meta".length() + 1) : spec.substring("meta".length() + 1, ix);
/* 45 */     String id = getId(ref);
/* 46 */     Activator activator = Activator.getDefault();
/* 47 */     if (activator == null)
/* 48 */       throw new IOException(CommonMessages.activator_not_available); 
/* 49 */     this.target = activator.getBundle(id);
/* 50 */     if (this.target == null)
/* 51 */       throw new IOException(NLS.bind(CommonMessages.url_resolvePlugin, this.url.toString())); 
/* 52 */     IPath path = MetaDataKeeper.getMetaArea().getStateLocation(this.target);
/* 53 */     if (ix != -1 || ix + 1 <= spec.length())
/* 54 */       path = path.append(spec.substring(ix + 1)); 
/* 55 */     return path.toFile().toURL();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void startup() {
/* 60 */     if (isRegistered)
/*    */       return; 
/* 62 */     PlatformURLHandler.register("meta", PlatformURLMetaConnection.class);
/* 63 */     isRegistered = true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public OutputStream getOutputStream() throws IOException {
/* 69 */     URL resolved = getResolvedURL();
/* 70 */     if (resolved != null) {
/* 71 */       String fileString = resolved.getFile();
/* 72 */       if (fileString != null) {
/* 73 */         File file = new File(fileString);
/* 74 */         String parent = file.getParent();
/* 75 */         if (parent != null)
/* 76 */           (new File(parent)).mkdirs(); 
/* 77 */         return new FileOutputStream(file);
/*    */       } 
/*    */     } 
/* 80 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformURLMetaConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */