/*    */ package org.eclipse.core.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullProgressMonitor
/*    */   implements IProgressMonitor
/*    */ {
/*    */   private volatile boolean cancelled = false;
/*    */   
/*    */   public void beginTask(String name, int totalWork) {}
/*    */   
/*    */   public void done() {}
/*    */   
/*    */   public void internalWorked(double work) {}
/*    */   
/*    */   public boolean isCanceled() {
/* 86 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCanceled(boolean cancelled) {
/* 99 */     this.cancelled = cancelled;
/*    */   }
/*    */   
/*    */   public void setTaskName(String name) {}
/*    */   
/*    */   public void subTask(String name) {}
/*    */   
/*    */   public void worked(int work) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\NullProgressMonitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */