/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.StringJoiner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiStatus
/*     */   extends Status
/*     */ {
/*  30 */   private final List<IStatus> children = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(Class<?> caller, int code, IStatus[] newChildren, String message, Throwable exception) {
/*  46 */     this(caller, code, message, exception);
/*  47 */     Assert.isLegal((newChildren != null));
/*  48 */     addAllInternal(newChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(String pluginId, int code, IStatus[] newChildren, String message, Throwable exception) {
/*  63 */     this(pluginId, code, message, exception);
/*  64 */     Assert.isLegal((newChildren != null));
/*  65 */     addAllInternal(newChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(Class<?> caller, int code, String message, Throwable exception) {
/*  81 */     super(0, caller, code, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(String pluginId, int code, String message, Throwable exception) {
/*  95 */     super(0, pluginId, code, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(Class<?> caller, int code, String message) {
/* 108 */     super(0, caller, code, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus(String pluginId, int code, String message) {
/* 120 */     super(0, pluginId, code, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IStatus status) {
/* 129 */     Assert.isLegal((status != null));
/* 130 */     this.children.add(status);
/* 131 */     int newSev = status.getSeverity();
/* 132 */     if (newSev > getSeverity()) {
/* 133 */       setSeverity(newSev);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(IStatus status) {
/* 145 */     Assert.isLegal((status != null));
/* 146 */     addAllInternal(status.getChildren());
/*     */   }
/*     */   
/*     */   private void addAllInternal(IStatus[] newChildren) {
/* 150 */     int maxSeverity = getSeverity(); byte b; int i; IStatus[] arrayOfIStatus;
/* 151 */     for (i = (arrayOfIStatus = newChildren).length, b = 0; b < i; ) { IStatus child = arrayOfIStatus[b];
/* 152 */       Assert.isLegal((child != null));
/* 153 */       int severity = child.getSeverity();
/* 154 */       if (severity > maxSeverity)
/* 155 */         maxSeverity = severity;  b++; }
/*     */     
/* 157 */     this.children.addAll(Arrays.asList(newChildren));
/* 158 */     setSeverity(maxSeverity);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus[] getChildren() {
/* 163 */     return this.children.<IStatus>toArray(new IStatus[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMultiStatus() {
/* 168 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(IStatus status) {
/* 183 */     Assert.isLegal((status != null));
/* 184 */     if (!status.isMultiStatus()) {
/* 185 */       add(status);
/*     */     } else {
/* 187 */       addAll(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 197 */     StringJoiner joiner = new StringJoiner(" ", String.valueOf(super.toString()) + " children=[", "]");
/* 198 */     for (IStatus child : this.children) {
/* 199 */       joiner.add(child.toString());
/*     */     }
/* 201 */     return joiner.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\MultiStatus.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */