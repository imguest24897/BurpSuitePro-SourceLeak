/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*    */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLFragmentConnection
/*    */   extends PlatformURLConnection
/*    */ {
/* 29 */   private Bundle target = null;
/*    */   
/*    */   private static boolean isRegistered = false;
/*    */   
/*    */   public static final String FRAGMENT = "fragment";
/*    */ 
/*    */   
/*    */   public PlatformURLFragmentConnection(URL url) {
/* 37 */     super(url);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean allowCaching() {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL resolve() throws IOException {
/* 47 */     String spec = this.url.getFile().trim();
/* 48 */     if (spec.startsWith("/"))
/* 49 */       spec = spec.substring(1); 
/* 50 */     if (!spec.startsWith("fragment"))
/* 51 */       throw new IOException(NLS.bind(CommonMessages.url_badVariant, this.url)); 
/* 52 */     int ix = spec.indexOf('/', "fragment".length() + 1);
/* 53 */     String ref = (ix == -1) ? spec.substring("fragment".length() + 1) : spec.substring("fragment".length() + 1, ix);
/* 54 */     String id = getId(ref);
/* 55 */     Activator activator = Activator.getDefault();
/* 56 */     if (activator == null)
/* 57 */       throw new IOException(CommonMessages.activator_not_available); 
/* 58 */     this.target = activator.getBundle(id);
/* 59 */     if (this.target == null)
/* 60 */       throw new IOException(NLS.bind(CommonMessages.url_resolveFragment, this.url)); 
/* 61 */     URL result = this.target.getEntry("/");
/* 62 */     if (ix == -1 || ix + 1 >= spec.length())
/* 63 */       return result; 
/* 64 */     return new URL(result, spec.substring(ix + 1));
/*    */   }
/*    */ 
/*    */   
/*    */   public static void startup() {
/* 69 */     if (isRegistered)
/*    */       return; 
/* 71 */     PlatformURLHandler.register("fragment", PlatformURLFragmentConnection.class);
/* 72 */     isRegistered = true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformURLFragmentConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */