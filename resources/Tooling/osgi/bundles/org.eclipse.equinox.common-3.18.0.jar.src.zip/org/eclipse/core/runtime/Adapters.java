/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.eclipse.core.internal.runtime.AdapterManager;
/*     */ import org.eclipse.core.internal.runtime.CommonMessages;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Adapters
/*     */ {
/*     */   public static <T> T adapt(Object sourceObject, Class<T> adapter, boolean allowActivation) {
/*  57 */     if (sourceObject == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     if (adapter.isInstance(sourceObject)) {
/*  61 */       return (T)sourceObject;
/*     */     }
/*     */     
/*  64 */     if (sourceObject instanceof IAdaptable) {
/*  65 */       IAdaptable adaptable = (IAdaptable)sourceObject;
/*     */       
/*  67 */       Object object = adaptable.getAdapter(adapter);
/*  68 */       if (object != null) {
/*     */         
/*  70 */         if (!adapter.isInstance(object)) {
/*  71 */           throw new AssertionFailedException(String.valueOf(adaptable.getClass().getName()) + ".getAdapter(" + adapter.getName() + ".class) returned " + 
/*  72 */               object.getClass().getName() + " that is not an instance the requested type");
/*     */         }
/*  74 */         return (T)object;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  80 */     if (sourceObject instanceof PlatformObject && !allowActivation) {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     String adapterId = adapter.getName();
/*  85 */     Object result = queryAdapterManager(sourceObject, adapterId, allowActivation);
/*  86 */     if (result != null) {
/*     */       
/*  88 */       if (!adapter.isInstance(result)) {
/*  89 */         throw new AssertionFailedException("An adapter factory for " + 
/*  90 */             sourceObject.getClass().getName() + " returned " + result.getClass().getName() + 
/*  91 */             " that is not an instance of " + adapter.getName());
/*     */       }
/*  93 */       return (T)result;
/*     */     } 
/*     */     
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T adapt(Object sourceObject, Class<T> adapter) {
/* 116 */     return adapt(sourceObject, adapter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Optional<T> of(Object sourceObject, Class<T> adapter) {
/* 133 */     if (sourceObject == null) {
/* 134 */       return Optional.empty();
/*     */     }
/* 136 */     Objects.requireNonNull(adapter);
/*     */     try {
/* 138 */       return Optional.ofNullable(adapt(sourceObject, adapter));
/* 139 */     } catch (AssertionFailedException e) {
/* 140 */       RuntimeLog.log(Status.error(
/* 141 */             NLS.bind(CommonMessages.adapters_internal_error_of, new Object[] {
/* 142 */                 sourceObject.getClass().getName(), adapter.getClass().getName(), e.getLocalizedMessage()
/* 143 */               }), e));
/* 144 */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object queryAdapterManager(Object sourceObject, String adapterId, boolean allowActivation) {
/*     */     Object result;
/* 150 */     if (allowActivation) {
/* 151 */       result = AdapterManager.getDefault().loadAdapter(sourceObject, adapterId);
/*     */     } else {
/* 153 */       result = AdapterManager.getDefault().getAdapter(sourceObject, adapterId);
/*     */     } 
/* 155 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\Adapters.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */