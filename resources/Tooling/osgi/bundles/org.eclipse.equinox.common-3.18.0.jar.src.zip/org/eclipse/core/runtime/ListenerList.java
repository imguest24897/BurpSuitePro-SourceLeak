/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Spliterator;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerList<E>
/*     */   implements Iterable<E>
/*     */ {
/*  63 */   private static final Object[] EmptyArray = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int EQUALITY = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int IDENTITY = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean identity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private volatile Object[] listeners = EmptyArray;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerList() {
/*  94 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerList(int mode) {
/* 103 */     if (mode != 0 && mode != 1)
/* 104 */       throw new IllegalArgumentException(); 
/* 105 */     this.identity = (mode == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void add(E listener) {
/* 117 */     if (listener == null) {
/* 118 */       throw new IllegalArgumentException();
/*     */     }
/* 120 */     int oldSize = this.listeners.length;
/* 121 */     for (int i = 0; i < oldSize; i++) {
/* 122 */       Object listener2 = this.listeners[i];
/* 123 */       if (this.identity ? (listener == listener2) : listener.equals(listener2)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 127 */     Object[] newListeners = new Object[oldSize + 1];
/* 128 */     System.arraycopy(this.listeners, 0, newListeners, 0, oldSize);
/* 129 */     newListeners[oldSize] = listener;
/*     */     
/* 131 */     this.listeners = newListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getListeners() {
/* 153 */     return this.listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 168 */     return new ListenerListIterator<>(this.listeners);
/*     */   }
/*     */   
/*     */   private static class ListenerListIterator<E> implements Iterator<E> {
/*     */     private Object[] listeners;
/*     */     private int i;
/*     */     
/*     */     public ListenerListIterator(Object[] listeners) {
/* 176 */       this.listeners = listeners;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 181 */       return (this.i < this.listeners.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 186 */       if (this.i >= this.listeners.length) {
/* 187 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/* 190 */       E next = (E)this.listeners[this.i++];
/* 191 */       return next;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 196 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 207 */     return (this.listeners.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void remove(Object listener) {
/* 219 */     if (listener == null)
/* 220 */       throw new IllegalArgumentException(); 
/* 221 */     int oldSize = this.listeners.length;
/* 222 */     for (int i = 0; i < oldSize; i++) {
/* 223 */       Object listener2 = this.listeners[i];
/* 224 */       if (this.identity ? (listener == listener2) : listener.equals(listener2)) {
/* 225 */         if (oldSize == 1) {
/* 226 */           this.listeners = EmptyArray;
/*     */         } else {
/*     */           
/* 229 */           Object[] newListeners = new Object[oldSize - 1];
/* 230 */           System.arraycopy(this.listeners, 0, newListeners, 0, i);
/* 231 */           System.arraycopy(this.listeners, i + 1, newListeners, i, oldSize - i - 1);
/*     */           
/* 233 */           this.listeners = newListeners;
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 246 */     return this.listeners.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 253 */     this.listeners = EmptyArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spliterator<E> spliterator() {
/* 267 */     return Arrays.spliterator((E[])this.listeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<E> stream() {
/* 277 */     return StreamSupport.stream(spliterator(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<E> parallelStream() {
/* 287 */     return StreamSupport.stream(spliterator(), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 292 */     return Arrays.toString(this.listeners);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\ListenerList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */