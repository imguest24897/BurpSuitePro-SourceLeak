/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.equinox.log.ExtendedLogEntry;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.equinox.log.LogFilter;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.eclipse.equinox.log.SynchronousLogListener;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformLogWriter
/*     */   implements SynchronousLogListener, LogFilter
/*     */ {
/*     */   public static final String EQUINOX_LOGGER_NAME = "org.eclipse.equinox.logger";
/*     */   private final ExtendedLogService logService;
/*     */   private final PackageAdmin packageAdmin;
/*     */   private final Bundle bundle;
/*     */   
/*     */   public PlatformLogWriter(ExtendedLogService logService, PackageAdmin packageAdmin, Bundle bundle) {
/*  39 */     this.logService = logService;
/*  40 */     this.packageAdmin = packageAdmin;
/*  41 */     this.bundle = bundle;
/*     */   }
/*     */   
/*     */   void logging(IStatus status) {
/*  45 */     Bundle b = getBundle(status);
/*  46 */     Logger equinoxLog = this.logService.getLogger(b, "org.eclipse.equinox.logger");
/*  47 */     equinoxLog.log(getLog(status), getLevel(status), status.getMessage(), status.getException());
/*     */   }
/*     */   
/*     */   public static int getLevel(IStatus status) {
/*  51 */     switch (status.getSeverity()) {
/*     */       case 4:
/*  53 */         return 1;
/*     */       case 2:
/*  55 */         return 2;
/*     */       case 1:
/*  57 */         return 3;
/*     */       case 0:
/*  59 */         return 4;
/*     */     } 
/*     */     
/*  62 */     return 32;
/*     */   }
/*     */ 
/*     */   
/*     */   public static FrameworkLogEntry getLog(IStatus status) {
/*  67 */     Throwable t = status.getException();
/*  68 */     ArrayList<FrameworkLogEntry> childlist = new ArrayList<>();
/*     */     
/*  70 */     int stackCode = (t instanceof CoreException) ? 1 : 0;
/*     */     
/*  72 */     if (stackCode == 1) {
/*  73 */       IStatus coreStatus = ((CoreException)t).getStatus();
/*  74 */       if (coreStatus != null) {
/*  75 */         childlist.add(getLog(coreStatus));
/*     */       }
/*     */     } 
/*     */     
/*  79 */     if (status.isMultiStatus()) {
/*  80 */       IStatus[] arrayOfIStatus1 = status.getChildren(); byte b; int i; IStatus[] arrayOfIStatus2;
/*  81 */       for (i = (arrayOfIStatus2 = arrayOfIStatus1).length, b = 0; b < i; ) { IStatus child = arrayOfIStatus2[b];
/*  82 */         childlist.add(getLog(child));
/*     */         b++; }
/*     */     
/*     */     } 
/*  86 */     FrameworkLogEntry[] children = (childlist.size() == 0) ? null : childlist.<FrameworkLogEntry>toArray(new FrameworkLogEntry[childlist.size()]);
/*     */     
/*  88 */     return new FrameworkLogEntry(status, status.getPlugin(), status.getSeverity(), status.getCode(), status.getMessage(), stackCode, t, children);
/*     */   }
/*     */   
/*     */   private Bundle getBundle(IStatus status) {
/*  92 */     String pluginID = status.getPlugin();
/*  93 */     if (pluginID == null)
/*  94 */       return this.bundle; 
/*  95 */     Bundle[] bundles = this.packageAdmin.getBundles(pluginID, null);
/*  96 */     return (bundles == null || bundles.length == 0) ? this.bundle : bundles[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLoggable(Bundle bundle, String loggerName, int logLevel) {
/* 101 */     return ("org.eclipse.equinox.logger".equals(loggerName) && RuntimeLog.hasListeners());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logged(LogEntry entry) {
/* 106 */     RuntimeLog.logToListeners(convertToStatus(entry));
/*     */   }
/*     */   
/*     */   public static IStatus convertToStatus(LogEntry logEntry) {
/* 110 */     Object context = null;
/* 111 */     if (logEntry instanceof ExtendedLogEntry)
/* 112 */       context = ((ExtendedLogEntry)logEntry).getContext(); 
/* 113 */     if (context instanceof IStatus)
/* 114 */       return (IStatus)context; 
/* 115 */     if (context instanceof FrameworkLogEntry) {
/* 116 */       FrameworkLogEntry fLogEntry = (FrameworkLogEntry)context;
/* 117 */       context = fLogEntry.getContext();
/* 118 */       if (context instanceof IStatus)
/* 119 */         return (IStatus)context; 
/* 120 */       return convertToStatus(fLogEntry);
/*     */     } 
/* 122 */     return convertRawEntryToStatus(logEntry);
/*     */   }
/*     */   
/*     */   private static IStatus convertToStatus(FrameworkLogEntry entry) {
/* 126 */     FrameworkLogEntry[] children = entry.getChildren();
/* 127 */     if (children != null) {
/* 128 */       Status[] arrayOfStatus = new Status[children.length];
/* 129 */       for (int i = 0; i < arrayOfStatus.length; i++)
/* 130 */         arrayOfStatus[i] = (Status)convertToStatus(children[i]); 
/* 131 */       return (IStatus)new MultiStatus(entry.getEntry(), entry.getBundleCode(), (IStatus[])arrayOfStatus, entry.getMessage(), entry.getThrowable());
/*     */     } 
/* 133 */     return (IStatus)new Status(entry.getSeverity(), entry.getEntry(), entry.getBundleCode(), entry.getMessage(), entry.getThrowable());
/*     */   }
/*     */   
/*     */   private static IStatus convertRawEntryToStatus(LogEntry logEntry) {
/*     */     int severity;
/* 138 */     switch (logEntry.getLogLevel()) {
/*     */       case ERROR:
/* 140 */         severity = 4;
/*     */         break;
/*     */       case WARN:
/* 143 */         severity = 2;
/*     */         break;
/*     */       case INFO:
/* 146 */         severity = 1;
/*     */         break;
/*     */       case null:
/*     */       case DEBUG:
/*     */       case TRACE:
/* 151 */         severity = 0;
/*     */         break;
/*     */       default:
/* 154 */         severity = -1;
/*     */         break;
/*     */     } 
/* 157 */     Bundle bundle = logEntry.getBundle();
/* 158 */     return (IStatus)new Status(severity, (bundle == null) ? null : bundle.getSymbolicName(), logEntry.getMessage(), logEntry.getException());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformLogWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */