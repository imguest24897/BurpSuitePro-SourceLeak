/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*    */ import org.eclipse.core.runtime.FileLocator;
/*    */ import org.eclipse.osgi.service.urlconversion.URLConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformURLConverter
/*    */   implements URLConverter
/*    */ {
/*    */   public URL toFileURL(URL url) throws IOException {
/* 34 */     URLConnection connection = url.openConnection();
/* 35 */     if (!(connection instanceof PlatformURLConnection))
/* 36 */       return url; 
/* 37 */     URL result = ((PlatformURLConnection)connection).getURLAsLocal();
/*    */     
/* 39 */     if (!result.getProtocol().startsWith("bundle"))
/* 40 */       return result; 
/* 41 */     return FileLocator.toFileURL(result);
/*    */   }
/*    */ 
/*    */   
/*    */   public URL resolve(URL url) throws IOException {
/* 46 */     URLConnection connection = url.openConnection();
/* 47 */     if (!(connection instanceof PlatformURLConnection))
/* 48 */       return url; 
/* 49 */     URL result = ((PlatformURLConnection)connection).getResolvedURL();
/*    */     
/* 51 */     if (!result.getProtocol().startsWith("bundle"))
/* 52 */       return result; 
/* 53 */     return FileLocator.resolve(result);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\PlatformURLConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */