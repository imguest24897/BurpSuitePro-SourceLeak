/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import org.eclipse.core.internal.runtime.Activator;
/*     */ import org.eclipse.core.internal.runtime.CommonMessages;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SafeRunner
/*     */ {
/*     */   public static void run(ISafeRunnable code) {
/*  43 */     Assert.isNotNull(code);
/*     */     try {
/*  45 */       code.run();
/*  46 */     } catch (Exception|LinkageError|AssertionError e) {
/*  47 */       handleException(code, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T run(ISafeRunnableWithResult<T> code) {
/*  68 */     Assert.isNotNull(code);
/*     */     try {
/*  70 */       return code.runWithResult();
/*  71 */     } catch (Exception|LinkageError|AssertionError e) {
/*  72 */       handleException(code, e);
/*  73 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void handleException(ISafeRunnable code, Throwable exception) {
/*  78 */     if (!(exception instanceof OperationCanceledException)) {
/*  79 */       String pluginId = getBundleIdOfSafeRunnable(code);
/*  80 */       IStatus status = convertToStatus(exception, pluginId);
/*  81 */       makeSureUserSeesException(exception, status);
/*     */     } 
/*  83 */     code.handleException(exception);
/*     */   }
/*     */   
/*     */   private static void makeSureUserSeesException(Throwable exception, IStatus status) {
/*  87 */     if (RuntimeLog.isEmpty()) {
/*  88 */       exception.printStackTrace();
/*     */     } else {
/*  90 */       RuntimeLog.log(status);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getBundleIdOfSafeRunnable(ISafeRunnable code) {
/*  95 */     Activator activator = Activator.getDefault();
/*  96 */     String pluginId = null;
/*  97 */     if (activator != null)
/*  98 */       pluginId = activator.getBundleId(code); 
/*  99 */     if (pluginId == null)
/* 100 */       return "org.eclipse.equinox.common"; 
/* 101 */     return pluginId;
/*     */   }
/*     */   
/*     */   private static IStatus convertToStatus(Throwable exception, String pluginId) {
/* 105 */     String message = NLS.bind(CommonMessages.meta_pluginProblems, pluginId);
/* 106 */     if (exception instanceof CoreException) {
/* 107 */       MultiStatus status = new MultiStatus(pluginId, 2, message, exception);
/* 108 */       status.merge(((CoreException)exception).getStatus());
/* 109 */       return status;
/*     */     } 
/* 111 */     return new Status(4, pluginId, 2, message, exception);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\SafeRunner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */