package org.eclipse.core.runtime;

@Deprecated
public interface IProgressMonitorWithBlocking extends IProgressMonitor {}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\IProgressMonitorWithBlocking.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */