/*    */ package org.eclipse.core.internal.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MetaDataKeeper
/*    */ {
/* 25 */   private static DataArea metaArea = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized DataArea getMetaArea() {
/* 33 */     if (metaArea != null) {
/* 34 */       return metaArea;
/*    */     }
/* 36 */     metaArea = new DataArea();
/* 37 */     return metaArea;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\MetaDataKeeper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */