/*     */ package org.eclipse.core.internal.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FindSupport
/*     */ {
/*     */   public static final String PROP_NL = "osgi.nl";
/*     */   public static final String PROP_OS = "osgi.os";
/*     */   public static final String PROP_WS = "osgi.ws";
/*     */   public static final String PROP_ARCH = "osgi.arch";
/*  35 */   private static String[] NL_JAR_VARIANTS = buildNLVariants((Activator.getContext() == null) ? System.getProperty("osgi.nl") : Activator.getContext().getProperty("osgi.nl"));
/*     */   
/*     */   private static String[] buildNLVariants(String nl) {
/*  38 */     ArrayList<String> result = new ArrayList<>();
/*  39 */     if (nl != null) {
/*  40 */       Path path1 = new Path("nl");
/*     */       
/*  42 */       Path path2 = new Path(nl.replace('_', '/'));
/*  43 */       while (path2.segmentCount() > 0) {
/*  44 */         result.add(path1.append((IPath)path2).toString());
/*     */         
/*  46 */         if (path2.segmentCount() > 1)
/*  47 */           result.add(path1.append(path2.toString().replace('/', '_')).toString()); 
/*  48 */         IPath iPath = path2.removeLastSegments(1);
/*     */       } 
/*     */     } 
/*     */     
/*  52 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL find(Bundle bundle, IPath path) {
/*  59 */     return find(bundle, path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL find(Bundle b, IPath path, Map<String, String> override) {
/*  66 */     return find(b, path, override, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL[] findEntries(Bundle bundle, IPath path) {
/*  73 */     return findEntries(bundle, path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL[] findEntries(Bundle bundle, IPath path, Map<String, String> override) {
/*  80 */     ArrayList<URL> results = new ArrayList<>(1);
/*  81 */     find(bundle, path, override, results);
/*  82 */     return results.<URL>toArray(new URL[results.size()]);
/*     */   }
/*     */   
/*     */   private static URL find(Bundle b, IPath path, Map<String, String> override, ArrayList<URL> multiple) {
/*  86 */     if (path == null) {
/*  87 */       return null;
/*     */     }
/*  89 */     URL result = null;
/*     */ 
/*     */     
/*  92 */     if (path.isEmpty() || path.isRoot()) {
/*     */ 
/*     */ 
/*     */       
/*  96 */       result = findInPlugin(b, (IPath)Path.EMPTY, multiple);
/*  97 */       if (result == null || multiple != null)
/*  98 */         result = findInFragments(b, (IPath)Path.EMPTY, multiple); 
/*  99 */       return result;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     String first = path.segment(0);
/* 104 */     if (first.charAt(0) != '$') {
/* 105 */       result = findInPlugin(b, path, multiple);
/* 106 */       if (result == null || multiple != null)
/* 107 */         result = findInFragments(b, path, multiple); 
/* 108 */       return result;
/*     */     } 
/*     */ 
/*     */     
/* 112 */     IPath rest = path.removeFirstSegments(1);
/* 113 */     if (first.equalsIgnoreCase("$nl$"))
/* 114 */       return findNL(b, rest, override, multiple); 
/* 115 */     if (first.equalsIgnoreCase("$os$"))
/* 116 */       return findOS(b, rest, override, multiple); 
/* 117 */     if (first.equalsIgnoreCase("$ws$"))
/* 118 */       return findWS(b, rest, override, multiple); 
/* 119 */     if (first.equalsIgnoreCase("$files$")) {
/* 120 */       return null;
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   private static URL findOS(Bundle b, IPath path, Map<String, String> override, ArrayList<URL> multiple) {
/* 126 */     String os = null;
/* 127 */     if (override != null) {
/*     */       
/*     */       try {
/* 130 */         os = override.get("$os$");
/* 131 */       } catch (ClassCastException classCastException) {}
/*     */     }
/*     */     
/* 134 */     if (os == null)
/*     */     {
/* 136 */       os = Activator.getContext().getProperty("osgi.os"); } 
/* 137 */     if (os.length() == 0) {
/* 138 */       return null;
/*     */     }
/*     */     
/* 141 */     String osArch = null;
/* 142 */     if (override != null) {
/*     */       
/*     */       try {
/* 145 */         osArch = override.get("$arch$");
/* 146 */       } catch (ClassCastException classCastException) {}
/*     */     }
/*     */     
/* 149 */     if (osArch == null)
/*     */     {
/* 151 */       osArch = Activator.getContext().getProperty("osgi.arch"); } 
/* 152 */     if (osArch.length() == 0) {
/* 153 */       return null;
/*     */     }
/* 155 */     URL result = null;
/* 156 */     IPath base = (new Path("os")).append(os).append(osArch);
/*     */     
/* 158 */     while (base.segmentCount() != 1) {
/* 159 */       IPath filePath = base.append(path);
/* 160 */       result = findInPlugin(b, filePath, multiple);
/* 161 */       if (result != null && multiple == null)
/* 162 */         return result; 
/* 163 */       result = findInFragments(b, filePath, multiple);
/* 164 */       if (result != null && multiple == null)
/* 165 */         return result; 
/* 166 */       base = base.removeLastSegments(1);
/*     */     } 
/*     */ 
/*     */     
/* 170 */     result = findInPlugin(b, path, multiple);
/* 171 */     if (result != null && multiple == null)
/* 172 */       return result; 
/* 173 */     return findInFragments(b, path, multiple);
/*     */   }
/*     */   
/*     */   private static URL findWS(Bundle b, IPath path, Map<String, String> override, ArrayList<URL> multiple) {
/* 177 */     String ws = null;
/* 178 */     if (override != null) {
/*     */       
/*     */       try {
/* 181 */         ws = override.get("$ws$");
/* 182 */       } catch (ClassCastException classCastException) {}
/*     */     }
/*     */     
/* 185 */     if (ws == null)
/*     */     {
/* 187 */       ws = Activator.getContext().getProperty("osgi.ws"); } 
/* 188 */     IPath filePath = (new Path("ws")).append(ws).append(path);
/*     */ 
/*     */     
/* 191 */     URL result = findInPlugin(b, filePath, multiple);
/* 192 */     if (result != null && multiple == null)
/* 193 */       return result; 
/* 194 */     result = findInFragments(b, filePath, multiple);
/* 195 */     if (result != null && multiple == null) {
/* 196 */       return result;
/*     */     }
/*     */     
/* 199 */     result = findInPlugin(b, path, multiple);
/* 200 */     if (result != null && multiple == null)
/* 201 */       return result; 
/* 202 */     return findInFragments(b, path, multiple);
/*     */   }
/*     */   
/*     */   private static URL findNL(Bundle b, IPath path, Map<String, String> override, ArrayList<URL> multiple) {
/* 206 */     String nl = null;
/* 207 */     String[] nlVariants = null;
/* 208 */     if (override != null) {
/*     */       
/*     */       try {
/* 211 */         nl = override.get("$nl$");
/* 212 */       } catch (ClassCastException classCastException) {}
/*     */     }
/*     */     
/* 215 */     nlVariants = (nl == null) ? NL_JAR_VARIANTS : buildNLVariants(nl);
/* 216 */     if (nl != null && nl.length() == 0) {
/* 217 */       return null;
/*     */     }
/* 219 */     URL result = null; byte b1; int i; String[] arrayOfString1;
/* 220 */     for (i = (arrayOfString1 = nlVariants).length, b1 = 0; b1 < i; ) { String nlVariant = arrayOfString1[b1];
/* 221 */       IPath filePath = (new Path(nlVariant)).append(path);
/* 222 */       result = findInPlugin(b, filePath, multiple);
/* 223 */       if (result != null && multiple == null)
/* 224 */         return result; 
/* 225 */       result = findInFragments(b, filePath, multiple);
/* 226 */       if (result != null && multiple == null) {
/* 227 */         return result;
/*     */       }
/*     */       b1++; }
/*     */     
/* 231 */     result = findInPlugin(b, path, multiple);
/* 232 */     if (result != null && multiple == null)
/* 233 */       return result; 
/* 234 */     return findInFragments(b, path, multiple);
/*     */   }
/*     */   
/*     */   private static URL findInPlugin(Bundle b, IPath filePath, ArrayList<URL> multiple) {
/* 238 */     URL result = b.getEntry(filePath.toString());
/* 239 */     if (result != null && multiple != null)
/* 240 */       multiple.add(result); 
/* 241 */     return result;
/*     */   }
/*     */   
/*     */   private static URL findInFragments(Bundle b, IPath filePath, ArrayList<URL> multiple) {
/* 245 */     Activator activator = Activator.getDefault();
/* 246 */     if (activator == null)
/* 247 */       return null; 
/* 248 */     Bundle[] fragments = activator.getFragments(b);
/* 249 */     if (fragments == null) {
/* 250 */       return null;
/*     */     }
/* 252 */     if (multiple != null)
/* 253 */       multiple.ensureCapacity(fragments.length + 1);  byte b1; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 255 */     for (i = (arrayOfBundle1 = fragments).length, b1 = 0; b1 < i; ) { Bundle fragment = arrayOfBundle1[b1];
/* 256 */       URL fileURL = fragment.getEntry(filePath.toString());
/* 257 */       if (fileURL != null) {
/* 258 */         if (multiple == null)
/* 259 */           return fileURL; 
/* 260 */         multiple.add(fileURL);
/*     */       }  b1++; }
/*     */     
/* 263 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final InputStream openStream(Bundle bundle, IPath file, boolean substituteArgs) throws IOException {
/* 270 */     URL url = null;
/* 271 */     if (!substituteArgs) {
/* 272 */       url = findInPlugin(bundle, file, null);
/* 273 */       if (url == null)
/* 274 */         url = findInFragments(bundle, file, null); 
/*     */     } else {
/* 276 */       url = find(bundle, file);
/*     */     } 
/* 278 */     if (url != null)
/* 279 */       return url.openStream(); 
/* 280 */     throw new IOException("Cannot find " + file.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL find(URL url) {
/* 288 */     if (!"platform".equalsIgnoreCase(url.getProtocol())) {
/* 289 */       return null;
/*     */     }
/*     */     
/* 292 */     String spec = url.getFile().trim();
/* 293 */     Object[] obj = null;
/*     */     try {
/* 295 */       obj = PlatformURLPluginConnection.parse(spec, url);
/* 296 */     } catch (IOException e) {
/* 297 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.core.runtime", "Invalid input url:" + url, e));
/* 298 */       return null;
/*     */     } 
/* 300 */     Bundle bundle = (Bundle)obj[0];
/* 301 */     String path = (String)obj[1];
/*     */ 
/*     */     
/* 304 */     if ("/".equals(path))
/* 305 */       return bundle.getEntry(path); 
/* 306 */     return find(bundle, (IPath)new Path(path), null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\FindSupport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */