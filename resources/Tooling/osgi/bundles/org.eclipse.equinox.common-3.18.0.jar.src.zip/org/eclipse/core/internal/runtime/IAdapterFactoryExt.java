package org.eclipse.core.internal.runtime;

import org.eclipse.core.runtime.IAdapterFactory;

public interface IAdapterFactoryExt {
  IAdapterFactory loadFactory(boolean paramBoolean);
  
  String[] getAdapterNames();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\internal\runtime\IAdapterFactoryExt.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */