package org.eclipse.core.runtime;

@FunctionalInterface
public interface ISafeRunnable {
  void run() throws Exception;
  
  default void handleException(Throwable exception) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.common-3.18.0.jar!\org\eclipse\core\runtime\ISafeRunnable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */