package org.osgi.service.component.runtime.dto;

import java.util.Map;
import org.osgi.dto.DTO;
import org.osgi.framework.dto.ServiceReferenceDTO;

public class ComponentConfigurationDTO extends DTO {
  public static final int UNSATISFIED_CONFIGURATION = 1;
  
  public static final int UNSATISFIED_REFERENCE = 2;
  
  public static final int SATISFIED = 4;
  
  public static final int ACTIVE = 8;
  
  public static final int FAILED_ACTIVATION = 16;
  
  public ComponentDescriptionDTO description;
  
  public int state;
  
  public long id;
  
  public Map<String, Object> properties;
  
  public SatisfiedReferenceDTO[] satisfiedReferences;
  
  public UnsatisfiedReferenceDTO[] unsatisfiedReferences;
  
  public String failure;
  
  public ServiceReferenceDTO service;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\runtime\dto\ComponentConfigurationDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */