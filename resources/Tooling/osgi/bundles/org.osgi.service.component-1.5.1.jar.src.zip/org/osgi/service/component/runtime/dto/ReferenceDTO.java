package org.osgi.service.component.runtime.dto;

import org.osgi.dto.DTO;

public class ReferenceDTO extends DTO {
  public String name;
  
  public String interfaceName;
  
  public String cardinality;
  
  public String policy;
  
  public String policyOption;
  
  public String target;
  
  public String bind;
  
  public String unbind;
  
  public String updated;
  
  public String field;
  
  public String fieldOption;
  
  public String scope;
  
  public Integer parameter;
  
  public String collectionType;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\runtime\dto\ReferenceDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */