package org.osgi.service.component.propertytypes;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.osgi.service.component.annotations.ComponentPropertyType;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE})
@ComponentPropertyType
public @interface ExportedService {
  Class<?>[] service_exported_interfaces();
  
  String[] service_exported_configs() default {};
  
  String[] service_exported_intents() default {};
  
  String[] service_exported_intents_extra() default {};
  
  String[] service_intents() default {};
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\propertytypes\ExportedService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */