package org.osgi.service.component.propertytypes;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.osgi.service.component.annotations.ComponentPropertyType;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE})
@ComponentPropertyType
public @interface ServiceVendor {
  String value();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\propertytypes\ServiceVendor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */