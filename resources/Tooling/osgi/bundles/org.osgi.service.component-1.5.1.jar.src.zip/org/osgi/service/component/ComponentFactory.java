package org.osgi.service.component;

import java.util.Dictionary;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ComponentFactory<S> {
  ComponentInstance<S> newInstance(Dictionary<String, ?> paramDictionary);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\ComponentFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */