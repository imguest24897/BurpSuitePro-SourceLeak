package org.osgi.service.component;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ComponentInstance<S> {
  void dispose();
  
  S getInstance();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\ComponentInstance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */