package org.osgi.service.component.runtime.dto;

import java.util.Map;
import org.osgi.dto.DTO;
import org.osgi.framework.dto.BundleDTO;

public class ComponentDescriptionDTO extends DTO {
  public String name;
  
  public BundleDTO bundle;
  
  public String factory;
  
  public String scope;
  
  public String implementationClass;
  
  public boolean defaultEnabled;
  
  public boolean immediate;
  
  public String[] serviceInterfaces;
  
  public Map<String, Object> properties;
  
  public ReferenceDTO[] references;
  
  public String activate;
  
  public String deactivate;
  
  public String modified;
  
  public String configurationPolicy;
  
  public String[] configurationPid;
  
  public Map<String, Object> factoryProperties;
  
  public String[] activationFields;
  
  public int init;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\runtime\dto\ComponentDescriptionDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */