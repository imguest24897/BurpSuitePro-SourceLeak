package org.osgi.service.component.runtime;

import java.util.Collection;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.service.component.runtime.dto.ComponentConfigurationDTO;
import org.osgi.service.component.runtime.dto.ComponentDescriptionDTO;
import org.osgi.util.promise.Promise;

@ProviderType
public interface ServiceComponentRuntime {
  Collection<ComponentDescriptionDTO> getComponentDescriptionDTOs(Bundle... paramVarArgs);
  
  ComponentDescriptionDTO getComponentDescriptionDTO(Bundle paramBundle, String paramString);
  
  Collection<ComponentConfigurationDTO> getComponentConfigurationDTOs(ComponentDescriptionDTO paramComponentDescriptionDTO);
  
  boolean isComponentEnabled(ComponentDescriptionDTO paramComponentDescriptionDTO);
  
  Promise<Void> enableComponent(ComponentDescriptionDTO paramComponentDescriptionDTO);
  
  Promise<Void> disableComponent(ComponentDescriptionDTO paramComponentDescriptionDTO);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\runtime\ServiceComponentRuntime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */