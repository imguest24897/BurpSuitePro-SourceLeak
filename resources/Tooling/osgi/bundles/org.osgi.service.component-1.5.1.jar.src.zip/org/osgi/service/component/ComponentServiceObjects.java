package org.osgi.service.component;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.ServiceReference;

@ProviderType
public interface ComponentServiceObjects<S> {
  S getService();
  
  void ungetService(S paramS);
  
  ServiceReference<S> getServiceReference();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\ComponentServiceObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */