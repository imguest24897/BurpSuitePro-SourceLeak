package org.osgi.service.component;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ComponentConstants {
  public static final String SERVICE_COMPONENT = "Service-Component";
  
  public static final String COMPONENT_NAME = "component.name";
  
  public static final String COMPONENT_ID = "component.id";
  
  public static final String COMPONENT_FACTORY = "component.factory";
  
  public static final String REFERENCE_TARGET_SUFFIX = ".target";
  
  public static final int DEACTIVATION_REASON_UNSPECIFIED = 0;
  
  public static final int DEACTIVATION_REASON_DISABLED = 1;
  
  public static final int DEACTIVATION_REASON_REFERENCE = 2;
  
  public static final int DEACTIVATION_REASON_CONFIGURATION_MODIFIED = 3;
  
  public static final int DEACTIVATION_REASON_CONFIGURATION_DELETED = 4;
  
  public static final int DEACTIVATION_REASON_DISPOSED = 5;
  
  public static final int DEACTIVATION_REASON_BUNDLE_STOPPED = 6;
  
  public static final String COMPONENT_CAPABILITY_NAME = "osgi.component";
  
  public static final String COMPONENT_SPECIFICATION_VERSION = "1.5";
  
  public static final String REFERENCE_NAME_SATISFYING_CONDITION = "osgi.ds.satisfying.condition";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\ComponentConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */