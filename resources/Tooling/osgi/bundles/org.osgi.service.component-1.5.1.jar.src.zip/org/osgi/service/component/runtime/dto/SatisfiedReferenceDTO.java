package org.osgi.service.component.runtime.dto;

import org.osgi.dto.DTO;
import org.osgi.framework.dto.ServiceReferenceDTO;

public class SatisfiedReferenceDTO extends DTO {
  public String name;
  
  public String target;
  
  public ServiceReferenceDTO[] boundServices;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\runtime\dto\SatisfiedReferenceDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */