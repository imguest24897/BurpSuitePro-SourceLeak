package org.osgi.service.component;

import java.util.Dictionary;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

@ProviderType
public interface ComponentContext {
  Dictionary<String, Object> getProperties();
  
  <S> S locateService(String paramString);
  
  <S> S locateService(String paramString, ServiceReference<S> paramServiceReference);
  
  Object[] locateServices(String paramString);
  
  BundleContext getBundleContext();
  
  Bundle getUsingBundle();
  
  <S> ComponentInstance<S> getComponentInstance();
  
  void enableComponent(String paramString);
  
  void disableComponent(String paramString);
  
  ServiceReference<?> getServiceReference();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.component-1.5.1.jar!\org\osgi\service\component\ComponentContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */