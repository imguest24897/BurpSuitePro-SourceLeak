/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.preferences.exchange.ILegacyPreferences;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionDelta;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
/*     */ import org.eclipse.core.runtime.preferences.AbstractPreferenceStorage;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScope;
/*     */ import org.eclipse.core.runtime.preferences.PreferenceModifyListener;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ public class PreferenceServiceRegistryHelper
/*     */   implements IRegistryChangeListener
/*     */ {
/*     */   private static final String ELEMENT_INITIALIZER = "initializer";
/*     */   private static final String ATTRIBUTE_NAME = "name";
/*     */   private static final String ATTRIBUTE_CLASS = "class";
/*     */   private static final String ATTRIBUTE_STORAGE = "storage";
/*     */   private static final String ELEMENT_SCOPE = "scope";
/*     */   private static final String ELEMENT_MODIFIER = "modifier";
/*  39 */   private static final IExtension[] EMPTY_EXTENSION_ARRAY = new IExtension[0];
/*  40 */   private static final Map<String, Object> scopeRegistry = Collections.synchronizedMap(new HashMap<>());
/*     */   
/*     */   private ListenerList<PreferenceModifyListener> modifyListeners;
/*     */   
/*     */   private final PreferencesService service;
/*     */   
/*     */   private final IExtensionRegistry registry;
/*     */ 
/*     */   
/*     */   private static IStatus createStatusError(String message, Exception e) {
/*  50 */     return (IStatus)new Status(4, "org.eclipse.equinox.preferences", 4, message, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IStatus createStatusWarning(String message, Exception e) {
/*  58 */     return (IStatus)new Status(2, "org.eclipse.equinox.preferences", 2, message, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void log(IStatus status) {
/*  65 */     RuntimeLog.log(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreferenceServiceRegistryHelper(PreferencesService service, Object registryObject) {
/*  73 */     this.service = service;
/*  74 */     this.registry = (IExtensionRegistry)registryObject;
/*  75 */     initializeScopes();
/*  76 */     this.registry.addRegistryChangeListener(this);
/*     */   }
/*     */   
/*     */   void stop() {
/*  80 */     this.registry.removeRegistryChangeListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addModifyListener(IConfigurationElement element) {
/*  87 */     String key = element.getAttribute("class");
/*  88 */     if (key == null) {
/*  89 */       String message = NLS.bind(PrefsMessages.preferences_missingClassAttribute, element.getDeclaringExtension().getUniqueIdentifier());
/*  90 */       log((IStatus)new Status(4, "org.eclipse.equinox.preferences", 4, message, null));
/*     */       return;
/*     */     } 
/*     */     try {
/*  94 */       Object listener = element.createExecutableExtension("class");
/*  95 */       if (!(listener instanceof PreferenceModifyListener)) {
/*  96 */         log((IStatus)new Status(4, "org.eclipse.equinox.preferences", 4, PrefsMessages.preferences_classCastListener, null));
/*     */         return;
/*     */       } 
/*  99 */       this.modifyListeners.add(listener);
/* 100 */     } catch (CoreException e) {
/* 101 */       log(e.getStatus());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WeakReference<Object> applyRuntimeDefaults(String name, WeakReference<Object> pluginReference) {
/* 111 */     IExtension[] extensions = getPrefExtensions();
/* 112 */     if (extensions.length == 0) {
/* 113 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 114 */         PrefsMessages.message("Skipping runtime default preference customization."); 
/* 115 */       return null;
/*     */     } 
/* 117 */     boolean foundInitializer = false; byte b; int i; IExtension[] arrayOfIExtension1;
/* 118 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 119 */       IConfigurationElement[] elements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 120 */       for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/* 121 */         if ("initializer".equals(element.getName()) && 
/* 122 */           name.equals(element.getContributor().getName())) {
/* 123 */           if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/* 124 */             String ownerName; IExtension theExtension = element.getDeclaringExtension();
/* 125 */             String extensionNamespace = theExtension.getContributor().getName();
/* 126 */             Bundle underlyingBundle = PreferencesOSGiUtils.getDefault().getBundle(extensionNamespace);
/*     */             
/* 128 */             if (underlyingBundle != null) {
/* 129 */               ownerName = underlyingBundle.getSymbolicName();
/*     */             } else {
/* 131 */               ownerName = extensionNamespace;
/* 132 */             }  PrefsMessages.message("Running default preference customization as defined by: " + ownerName);
/*     */           } 
/* 134 */           runInitializer(element);
/*     */           
/* 136 */           foundInitializer = true;
/*     */         }  b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 141 */     if (foundInitializer) {
/* 142 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     Object plugin = pluginReference.get();
/* 149 */     ILegacyPreferences initService = PreferencesOSGiUtils.getDefault().getLegacyPreferences();
/* 150 */     if (initService != null)
/* 151 */       plugin = initService.init(plugin, name); 
/* 152 */     return new WeakReference(plugin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IEclipsePreferences createNode(RootPreferences parent, String name) {
/* 161 */     IScope scope = null;
/* 162 */     Object value = scopeRegistry.get(name);
/* 163 */     if (value instanceof IConfigurationElement) {
/*     */       
/* 165 */       if (((IConfigurationElement)value).getAttribute("class") != null) {
/*     */         try {
/* 167 */           scope = (IScope)((IConfigurationElement)value).createExecutableExtension("class");
/* 168 */           scopeRegistry.put(name, scope);
/* 169 */         } catch (ClassCastException e) {
/* 170 */           log(createStatusError(PrefsMessages.preferences_classCastScope, e));
/* 171 */           return new EclipsePreferences(parent, name);
/* 172 */         } catch (CoreException e) {
/* 173 */           log(e.getStatus());
/* 174 */           return new EclipsePreferences(parent, name);
/*     */         } 
/* 176 */       } else if (((IConfigurationElement)value).getAttribute("storage") != null) {
/*     */         
/*     */         try {
/* 179 */           AbstractPreferenceStorage storage = (AbstractPreferenceStorage)((IConfigurationElement)value).createExecutableExtension("storage");
/* 180 */           ScopeDescriptor descriptor = new ScopeDescriptor(storage);
/* 181 */           EclipsePreferences result = new EclipsePreferences(parent, name);
/* 182 */           result.setDescriptor(descriptor);
/* 183 */           return result;
/* 184 */         } catch (ClassCastException e) {
/* 185 */           log(createStatusError(PrefsMessages.preferences_classCastStorage, e));
/* 186 */           return new EclipsePreferences(parent, name);
/* 187 */         } catch (CoreException e) {
/* 188 */           log(e.getStatus());
/* 189 */           return new EclipsePreferences(parent, name);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 193 */       scope = (IScope)value;
/* 194 */     }  return scope.create(parent, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerList<PreferenceModifyListener> getModifyListeners() {
/* 202 */     if (this.modifyListeners == null) {
/* 203 */       this.modifyListeners = new ListenerList();
/* 204 */       IExtension[] extensions = getPrefExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 205 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 206 */         IConfigurationElement[] elements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 207 */         for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/* 208 */           if ("modifier".equalsIgnoreCase(element.getName()))
/* 209 */             addModifyListener(element);  b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 214 */     return this.modifyListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IExtension[] getPrefExtensions() {
/* 222 */     IExtension[] extensionsOld = EMPTY_EXTENSION_ARRAY;
/* 223 */     IExtension[] extensionsNew = EMPTY_EXTENSION_ARRAY;
/*     */     
/* 225 */     IExtensionPoint pointOld = this.registry.getExtensionPoint("org.eclipse.core.runtime", "preferences");
/* 226 */     if (pointOld != null) {
/* 227 */       extensionsOld = pointOld.getExtensions();
/*     */     }
/* 229 */     IExtensionPoint pointNew = this.registry.getExtensionPoint("org.eclipse.equinox.preferences", "preferences");
/* 230 */     if (pointNew != null) {
/* 231 */       extensionsNew = pointNew.getExtensions();
/*     */     }
/* 233 */     IExtension[] extensions = new IExtension[extensionsOld.length + extensionsNew.length];
/* 234 */     System.arraycopy(extensionsOld, 0, extensions, 0, extensionsOld.length);
/* 235 */     System.arraycopy(extensionsNew, 0, extensions, extensionsOld.length, extensionsNew.length);
/*     */     
/* 237 */     if (extensions.length == 0 && 
/* 238 */       EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/* 239 */       PrefsMessages.message("No extensions for org.eclipse.core.contenttype.");
/*     */     }
/*     */     
/* 242 */     return extensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeScopes() {
/* 249 */     IExtension[] extensions = getPrefExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 250 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 251 */       IConfigurationElement[] elements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 252 */       for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/* 253 */         if ("scope".equalsIgnoreCase(element.getName())) {
/* 254 */           scopeAdded(element);
/*     */         }
/*     */         b1++; }
/*     */       
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/* 263 */     IExtensionDelta[] deltasOld = event.getExtensionDeltas("org.eclipse.core.runtime", "preferences");
/* 264 */     IExtensionDelta[] deltasNew = event.getExtensionDeltas("org.eclipse.equinox.preferences", "preferences");
/* 265 */     IExtensionDelta[] deltas = new IExtensionDelta[deltasOld.length + deltasNew.length];
/* 266 */     System.arraycopy(deltasOld, 0, deltas, 0, deltasOld.length);
/* 267 */     System.arraycopy(deltasNew, 0, deltas, deltasOld.length, deltasNew.length);
/*     */     
/* 269 */     if (deltas.length == 0)
/*     */       return;  byte b; int i;
/*     */     IExtensionDelta[] arrayOfIExtensionDelta1;
/* 272 */     for (i = (arrayOfIExtensionDelta1 = deltas).length, b = 0; b < i; ) { IExtensionDelta delta = arrayOfIExtensionDelta1[b];
/* 273 */       IConfigurationElement[] elements = delta.getExtension().getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 274 */       for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { String scope; IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/* 275 */         switch (delta.getKind()) {
/*     */           case 1:
/* 277 */             if ("scope".equalsIgnoreCase(element.getName())) {
/* 278 */               scopeAdded(element);
/*     */             }
/*     */             break;
/*     */           case 2:
/* 282 */             scope = element.getAttribute("name");
/* 283 */             if (scope != null)
/* 284 */               scopeRemoved(scope);  break;
/*     */         } 
/*     */         b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 290 */     this.modifyListeners = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runInitializer(IConfigurationElement element) {
/*     */     try {
/* 298 */       final AbstractPreferenceInitializer initializer = (AbstractPreferenceInitializer)element.createExecutableExtension("class");
/* 299 */       ISafeRunnable job = new ISafeRunnable()
/*     */         {
/*     */           public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() throws Exception {
/* 307 */             initializer.initializeDefaultPreferences();
/*     */           }
/*     */         };
/* 310 */       SafeRunner.run(job);
/* 311 */     } catch (ClassCastException e) {
/* 312 */       Status status = new Status(4, "org.eclipse.equinox.preferences", 4, PrefsMessages.preferences_invalidExtensionSuperclass, e);
/* 313 */       log((IStatus)status);
/* 314 */     } catch (CoreException e) {
/* 315 */       log(e.getStatus());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scopeAdded(IConfigurationElement element) {
/* 324 */     String key = element.getAttribute("name");
/* 325 */     if (key == null) {
/* 326 */       String message = NLS.bind(PrefsMessages.preferences_missingScopeAttribute, element.getDeclaringExtension().getUniqueIdentifier());
/* 327 */       log(createStatusWarning(message, null));
/*     */       return;
/*     */     } 
/* 330 */     scopeRegistry.put(key, element);
/* 331 */     ((RootPreferences)this.service.getRootNode()).addChild(key, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scopeRemoved(String key) {
/* 339 */     IEclipsePreferences node = (IEclipsePreferences)((RootPreferences)this.service.getRootNode()).getNode(key, false);
/* 340 */     if (node != null) {
/* 341 */       ((RootPreferences)this.service.getRootNode()).removeNode(node);
/*     */     } else {
/* 343 */       ((RootPreferences)this.service.getRootNode()).removeNode(key);
/* 344 */     }  scopeRegistry.remove(key);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\PreferenceServiceRegistryHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */