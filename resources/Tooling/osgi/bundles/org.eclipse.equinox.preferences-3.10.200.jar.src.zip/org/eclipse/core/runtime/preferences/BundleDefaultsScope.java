/*    */ package org.eclipse.core.runtime.preferences;
/*    */ 
/*    */ import org.eclipse.core.internal.preferences.AbstractScope;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BundleDefaultsScope
/*    */   extends AbstractScope
/*    */ {
/*    */   public static final String SCOPE = "bundle_defaults";
/* 54 */   public static final IScopeContext INSTANCE = (IScopeContext)new BundleDefaultsScope();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 67 */     return "bundle_defaults";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 73 */     return super.getNode(qualifier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPath getLocation() {
/* 80 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\BundleDefaultsScope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */