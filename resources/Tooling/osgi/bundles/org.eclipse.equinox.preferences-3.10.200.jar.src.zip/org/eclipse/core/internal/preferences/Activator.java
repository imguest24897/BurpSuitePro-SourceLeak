/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.prefs.PreferencesService;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   implements BundleActivator, ServiceTrackerCustomizer<Object, Object>
/*     */ {
/*     */   public static final String PI_PREFERENCES = "org.eclipse.equinox.preferences";
/*     */   private static final String PROP_REGISTER_PERF_SERVICE = "eclipse.service.pref";
/*     */   private static final String PROP_CUSTOMIZATION = "eclipse.pluginCustomization";
/*     */   private ServiceTracker<?, ?> registryServiceTracker;
/*     */   private static BundleContext bundleContext;
/*     */   private ServiceRegistration<IPreferencesService> preferencesService;
/*     */   private ServiceRegistration<PreferencesService> osgiPreferencesService;
/*     */   private ServiceTracker<?, ?> locationTracker;
/*     */   
/*     */   public void start(final BundleContext context) throws Exception {
/*  70 */     bundleContext = context;
/*     */     
/*  72 */     PreferencesOSGiUtils.getDefault().openServices();
/*  73 */     processCommandLine();
/*     */     
/*  75 */     boolean shouldRegister = !"false".equalsIgnoreCase(context.getProperty("eclipse.service.pref"));
/*  76 */     if (shouldRegister) {
/*  77 */       this.preferencesService = bundleContext.registerService(IPreferencesService.class, PreferencesService.getDefault(), new Hashtable<>());
/*  78 */       this.osgiPreferencesService = bundleContext.registerService(PreferencesService.class, new OSGiPreferencesServiceManager(bundleContext), null);
/*     */     } 
/*     */     
/*  81 */     this.registryServiceTracker = new ServiceTracker(bundleContext, "org.eclipse.core.runtime.IExtensionRegistry", this);
/*  82 */     this.registryServiceTracker.open();
/*  83 */     this.locationTracker = new ServiceTracker(context, 
/*  84 */         context.createFilter("(&" + Location.INSTANCE_FILTER + "(url=*))"), 
/*  85 */         new ServiceTrackerCustomizer<Location, ServiceRegistration<?>>()
/*     */         {
/*     */           public ServiceRegistration<?> addingService(ServiceReference<Location> reference)
/*     */           {
/*  89 */             Location location = (Location)context.getService(reference);
/*  90 */             if (location != null) {
/*  91 */               return context.registerService(IScopeContext.class, new BundleStateScopeServiceFactory(), 
/*  92 */                   FrameworkUtil.asDictionary(
/*  93 */                     Map.of("type", "bundle")));
/*     */             }
/*  95 */             return null;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void modifiedService(ServiceReference<Location> reference, ServiceRegistration<?> service) {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void removedService(ServiceReference<Location> reference, ServiceRegistration<?> service) {
/* 105 */             service.unregister();
/* 106 */             context.ungetService(reference);
/*     */           }
/*     */         });
/* 109 */     this.locationTracker.open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/* 115 */     PreferencesOSGiUtils.getDefault().closeServices();
/* 116 */     if (this.registryServiceTracker != null) {
/* 117 */       this.registryServiceTracker.close();
/* 118 */       this.registryServiceTracker = null;
/*     */     } 
/* 120 */     if (this.preferencesService != null) {
/* 121 */       this.preferencesService.unregister();
/* 122 */       this.preferencesService = null;
/*     */     } 
/* 124 */     if (this.osgiPreferencesService != null) {
/* 125 */       this.osgiPreferencesService.unregister();
/* 126 */       this.osgiPreferencesService = null;
/*     */     } 
/* 128 */     if (this.locationTracker != null) {
/* 129 */       this.locationTracker.close();
/* 130 */       this.locationTracker = null;
/*     */     } 
/* 132 */     bundleContext = null;
/*     */   }
/*     */   
/*     */   static BundleContext getContext() {
/* 136 */     return bundleContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object addingService(ServiceReference<Object> reference) {
/* 142 */     Object service = bundleContext.getService(reference);
/*     */ 
/*     */     
/* 145 */     if (service != null) {
/*     */       try {
/* 147 */         Object helper = new PreferenceServiceRegistryHelper(PreferencesService.getDefault(), service);
/* 148 */         PreferencesService.getDefault().setRegistryHelper(helper);
/* 149 */       } catch (Exception e) {
/* 150 */         RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.preferences", 0, PrefsMessages.noRegistry, e));
/* 151 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 158 */         return null;
/*     */       } 
/*     */     }
/*     */     
/* 162 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<Object> reference, Object service) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removedService(ServiceReference<Object> reference, Object service) {
/* 174 */     PreferencesService.getDefault().setRegistryHelper(null);
/* 175 */     bundleContext.ungetService(reference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processCommandLine() {
/* 184 */     String value = bundleContext.getProperty("eclipse.pluginCustomization");
/* 185 */     if (value != null) {
/* 186 */       DefaultPreferences.pluginCustomizationFile = value;
/*     */       
/*     */       return;
/*     */     } 
/* 190 */     ServiceTracker<?, EnvironmentInfo> environmentTracker = new ServiceTracker(bundleContext, EnvironmentInfo.class, null);
/* 191 */     environmentTracker.open();
/* 192 */     EnvironmentInfo environmentInfo = (EnvironmentInfo)environmentTracker.getService();
/* 193 */     environmentTracker.close();
/* 194 */     if (environmentInfo == null)
/*     */       return; 
/* 196 */     String[] args = environmentInfo.getNonFrameworkArgs();
/* 197 */     if (args == null || args.length == 0) {
/*     */       return;
/*     */     }
/* 200 */     for (int i = 0; i < args.length; i++) {
/* 201 */       if (args[i].equalsIgnoreCase("-plugincustomization")) {
/* 202 */         if (args.length > i + 1)
/* 203 */           DefaultPreferences.pluginCustomizationFile = args[i + 1]; 
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\Activator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */