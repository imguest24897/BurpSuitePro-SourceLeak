/*     */ package org.eclipse.core.runtime.preferences;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.core.internal.preferences.PrefsMessages;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPreferenceStorage
/*     */ {
/*     */   public abstract Properties load(String paramString) throws BackingStoreException;
/*     */   
/*     */   public abstract void save(String paramString, Properties paramProperties) throws BackingStoreException;
/*     */   
/*     */   protected Properties loadProperties(InputStream input) throws BackingStoreException {
/*  75 */     Properties result = new Properties();
/*     */     try {
/*  77 */       input = new BufferedInputStream(input);
/*  78 */       result.load(input);
/*  79 */     } catch (IOException|IllegalArgumentException e) {
/*  80 */       throw new BackingStoreException(PrefsMessages.preferences_loadProblems, e);
/*     */     } finally {
/*  82 */       if (input != null) {
/*     */         try {
/*  84 */           input.close();
/*  85 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */     
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void saveProperties(OutputStream output, Properties properties) throws BackingStoreException {
/*     */     try {
/* 102 */       output = new BufferedOutputStream(output);
/* 103 */       properties.store(output, (String)null);
/* 104 */       output.flush();
/* 105 */     } catch (IOException e) {
/* 106 */       throw new BackingStoreException(PrefsMessages.preferences_saveProblems, e);
/*     */     } finally {
/* 108 */       if (output != null)
/*     */         try {
/* 110 */           output.close();
/* 111 */         } catch (IOException iOException) {} 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract String[] childrenNames(String paramString) throws BackingStoreException;
/*     */   
/*     */   public abstract void removed(String paramString);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\AbstractPreferenceStorage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */