/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SortedProperties
/*    */   extends Properties
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public synchronized Enumeration<Object> keys() {
/* 37 */     TreeSet<Object> set = new TreeSet();
/* 38 */     for (Enumeration<?> e = super.keys(); e.hasMoreElements();) {
/* 39 */       set.add(e.nextElement());
/*    */     }
/* 41 */     return Collections.enumeration(set);
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Map.Entry<Object, Object>> entrySet() {
/* 46 */     TreeSet<Map.Entry<Object, Object>> set = new TreeSet<>((e1, e2) -> {
/*    */           String s1 = (String)e1.getKey();
/*    */           String s2 = (String)e2.getKey();
/*    */           return s1.compareTo(s2);
/*    */         });
/* 51 */     for (Map.Entry<Object, Object> entry : super.entrySet()) {
/* 52 */       set.add(entry);
/*    */     }
/* 54 */     return set;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\SortedProperties.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */