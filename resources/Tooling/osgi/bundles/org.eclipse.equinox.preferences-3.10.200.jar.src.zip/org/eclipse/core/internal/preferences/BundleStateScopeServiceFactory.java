/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleStateScopeServiceFactory
/*    */   implements ServiceFactory<IScopeContext>
/*    */ {
/*    */   public IScopeContext getService(Bundle bundle, ServiceRegistration<IScopeContext> registration) {
/* 23 */     return new BundleStateScope(bundle);
/*    */   }
/*    */   
/*    */   public void ungetService(Bundle bundle, ServiceRegistration<IScopeContext> registration, IScopeContext service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\BundleStateScopeServiceFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */