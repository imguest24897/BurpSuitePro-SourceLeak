/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrefsMessages
/*    */   extends NLS
/*    */ {
/*    */   public static final String OWNER_NAME = "org.eclipse.equinox.preferences";
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.preferences.messages";
/*    */   public static String preferences_applyProblems;
/*    */   public static String preferences_classCastScope;
/*    */   public static String preferences_classCastStorage;
/*    */   public static String preferences_classCastListener;
/*    */   public static String preferences_classCastFilterEntry;
/*    */   public static String preferences_contextError;
/*    */   public static String preferences_errorWriting;
/*    */   public static String preferences_exportProblems;
/*    */   public static String preferences_failedDelete;
/*    */   public static String preferences_fileNotFound;
/*    */   public static String preferences_importProblems;
/*    */   public static String preferences_incompatible;
/*    */   public static String preferences_invalidExtensionSuperclass;
/*    */   public static String preferences_invalidFileFormat;
/*    */   public static String preferences_loadException;
/*    */   public static String preferences_loadProblems;
/*    */   public static String preferences_matching;
/*    */   public static String preferences_missingClassAttribute;
/*    */   public static String preferences_missingScopeAttribute;
/*    */   public static String noRegistry;
/*    */   public static String preferences_removedNode;
/*    */   public static String preferences_saveException;
/*    */   public static String preferences_saveProblems;
/*    */   public static String preferences_validate;
/*    */   public static String preferences_validationException;
/*    */   public static String childrenNames;
/*    */   public static String childrenNames2;
/*    */   public static String OsgiPreferenceMetadataStore_e_null_preference_node;
/*    */   public static String PreferenceMetadata_e_null_default_value;
/*    */   public static String PreferenceMetadata_e_null_description;
/*    */   public static String PreferenceMetadata_e_null_identifier;
/*    */   public static String PreferenceMetadata_e_null_name;
/*    */   public static String PreferenceMetadata_e_null_value_type;
/*    */   public static String PreferenceStorage_e_load_unsupported;
/*    */   public static String PreferenceStorage_e_save_unsupported;
/*    */   
/*    */   static {
/* 69 */     reloadMessages();
/*    */   }
/*    */   
/*    */   public static void reloadMessages() {
/* 73 */     NLS.initializeMessages("org.eclipse.core.internal.preferences.messages", PrefsMessages.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void message(String message) {
/* 81 */     StringBuilder buffer = new StringBuilder();
/* 82 */     buffer.append(new Date(System.currentTimeMillis()));
/* 83 */     buffer.append(" - [");
/* 84 */     buffer.append(Thread.currentThread().getName());
/* 85 */     buffer.append("] ");
/* 86 */     buffer.append(message);
/* 87 */     System.out.println(buffer.toString());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\PrefsMessages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */