/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootPreferences
/*     */   extends EclipsePreferences
/*     */ {
/*     */   public RootPreferences() {
/*  30 */     super(null, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws BackingStoreException {
/*  37 */     BackingStoreException exception = null;
/*  38 */     String[] names = childrenNames(); byte b; int i; String[] arrayOfString1;
/*  39 */     for (i = (arrayOfString1 = names).length, b = 0; b < i; ) { String n = arrayOfString1[b];
/*     */       try {
/*  41 */         node(n).flush();
/*  42 */       } catch (BackingStoreException e) {
/*     */ 
/*     */         
/*  45 */         if (exception == null)
/*  46 */           exception = e; 
/*     */       }  b++; }
/*     */     
/*  49 */     if (exception != null) {
/*  50 */       throw exception;
/*     */     }
/*     */   }
/*     */   
/*     */   protected synchronized IEclipsePreferences getChild(String key, Object context) {
/*  55 */     if (this.children == null)
/*  56 */       return null; 
/*  57 */     Object value = this.children.get(key);
/*  58 */     if (value == null)
/*  59 */       return null; 
/*  60 */     if (value instanceof IEclipsePreferences) {
/*  61 */       return (IEclipsePreferences)value;
/*     */     }
/*  63 */     IEclipsePreferences child = PreferencesService.getDefault().createNode(key);
/*  64 */     addChild(key, child);
/*  65 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized IEclipsePreferences[] getChildren() {
/*  71 */     String[] childNames = new String[0];
/*     */     try {
/*  73 */       childNames = childrenNames();
/*  74 */     } catch (BackingStoreException e) {
/*  75 */       log((IStatus)new Status(4, "org.eclipse.equinox.preferences", PrefsMessages.childrenNames, (Throwable)e));
/*  76 */       return new IEclipsePreferences[0];
/*     */     } 
/*  78 */     IEclipsePreferences[] childNodes = new IEclipsePreferences[childNames.length];
/*  79 */     for (int i = 0; i < childNames.length; i++)
/*  80 */       childNodes[i] = getChild(childNames[i], (Object)null); 
/*  81 */     return childNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Preferences node(String path) {
/*  87 */     return getNode(path, true);
/*     */   }
/*     */   public Preferences getNode(String path, boolean create) {
/*     */     IEclipsePreferences child;
/*  91 */     if (path.length() == 0 || (path.length() == 1 && path.charAt(0) == '/'))
/*  92 */       return (Preferences)this; 
/*  93 */     int startIndex = (path.charAt(0) == '/') ? 1 : 0;
/*  94 */     int endIndex = path.indexOf('/', startIndex + 1);
/*  95 */     String scope = path.substring(startIndex, (endIndex == -1) ? path.length() : endIndex);
/*     */     
/*  97 */     if (create) {
/*  98 */       child = getChild(scope, (Object)null);
/*  99 */       if (child == null) {
/* 100 */         child = new EclipsePreferences(this, scope);
/* 101 */         addChild(scope, child);
/*     */       } 
/*     */     } else {
/* 104 */       child = getChild(scope, null, false);
/* 105 */       if (child == null)
/* 106 */         return null; 
/*     */     } 
/* 108 */     return child.node((endIndex == -1) ? "" : path.substring(endIndex + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sync() throws BackingStoreException {
/* 115 */     BackingStoreException exception = null;
/* 116 */     String[] names = childrenNames(); byte b; int i; String[] arrayOfString1;
/* 117 */     for (i = (arrayOfString1 = names).length, b = 0; b < i; ) { String n = arrayOfString1[b];
/*     */       try {
/* 119 */         node(n).sync();
/* 120 */       } catch (BackingStoreException e) {
/*     */ 
/*     */         
/* 123 */         if (exception == null)
/* 124 */           exception = e; 
/*     */       }  b++; }
/*     */     
/* 127 */     if (exception != null)
/* 128 */       throw exception; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\RootPreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */