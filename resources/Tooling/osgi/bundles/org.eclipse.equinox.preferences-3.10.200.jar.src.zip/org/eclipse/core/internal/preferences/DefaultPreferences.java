/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.preferences.exchange.IProductPreferencesService;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.FileLocator;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPreferences
/*     */   extends EclipsePreferences
/*     */ {
/*  39 */   private static Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */   private static final String KEY_PREFIX = "%";
/*     */   private static final String KEY_DOUBLE_PREFIX = "%%";
/*  42 */   private static final IPath NL_DIR = (IPath)new Path("$nl$");
/*     */   
/*     */   private static final String PROPERTIES_FILE_EXTENSION = "properties";
/*     */   
/*     */   private static Properties productCustomization;
/*     */   
/*     */   private static Properties productTranslation;
/*     */   
/*     */   private static Properties commandLineCustomization;
/*     */   private EclipsePreferences loadLevel;
/*     */   private Thread initializingThread;
/*     */   private String qualifier;
/*     */   private int segmentCount;
/*     */   private WeakReference<Object> pluginReference;
/*  56 */   public static String pluginCustomizationFile = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPreferences() {
/*  62 */     this((EclipsePreferences)null, (String)null);
/*     */   }
/*     */   
/*     */   private DefaultPreferences(EclipsePreferences parent, String name, Object context) {
/*  66 */     this(parent, name);
/*  67 */     this.pluginReference = new WeakReference(context);
/*     */   }
/*     */   
/*     */   private DefaultPreferences(EclipsePreferences parent, String name) {
/*  71 */     super(parent, name);
/*     */     
/*  73 */     if (parent instanceof DefaultPreferences) {
/*  74 */       this.pluginReference = ((DefaultPreferences)parent).pluginReference;
/*     */     }
/*     */     
/*  77 */     String path = absolutePath();
/*  78 */     this.segmentCount = getSegmentCount(path);
/*  79 */     if (this.segmentCount < 2) {
/*     */       return;
/*     */     }
/*     */     
/*  83 */     this.qualifier = getSegment(path, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyBundleDefaults() {
/*  93 */     Bundle bundle = PreferencesOSGiUtils.getDefault().getBundle(name());
/*  94 */     if (bundle == null)
/*     */       return; 
/*  96 */     URL url = FileLocator.find(bundle, (IPath)new Path("preferences.ini"), null);
/*  97 */     if (url == null) {
/*  98 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  99 */         PrefsMessages.message("Preference default override file not found for bundle: " + bundle.getSymbolicName()); 
/*     */       return;
/*     */     } 
/* 102 */     URL transURL = FileLocator.find(bundle, NL_DIR.append("preferences").addFileExtension("properties"), null);
/* 103 */     if (transURL == null && EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 104 */       PrefsMessages.message("Preference translation file not found for bundle: " + bundle.getSymbolicName()); 
/* 105 */     applyDefaults(name(), loadProperties(url), loadProperties(transURL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyCommandLineDefaults() {
/* 113 */     if (commandLineCustomization != null) {
/* 114 */       applyDefaults((String)null, commandLineCustomization, (Properties)null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyDefaults(String id, Properties defaultValues, Properties translations) {
/* 124 */     for (Enumeration<?> e = defaultValues.keys(); e.hasMoreElements(); ) {
/* 125 */       String fullKey = (String)e.nextElement();
/* 126 */       String value = defaultValues.getProperty(fullKey);
/* 127 */       if (value == null)
/*     */         continue; 
/* 129 */       String localQualifier = id;
/* 130 */       String fullPath = fullKey;
/* 131 */       int firstIndex = fullKey.indexOf(PATH_SEPARATOR);
/* 132 */       if (id == null && firstIndex > 0) {
/* 133 */         localQualifier = fullKey.substring(0, firstIndex);
/* 134 */         fullPath = fullKey.substring(firstIndex, fullKey.length());
/*     */       } 
/* 136 */       String[] splitPath = decodePath(fullPath);
/* 137 */       String childPath = splitPath[0];
/* 138 */       childPath = makeRelative(childPath);
/* 139 */       String key = splitPath[1];
/* 140 */       if (name().equals(localQualifier)) {
/* 141 */         value = translatePreference(value, translations);
/* 142 */         if (EclipsePreferences.DEBUG_PREFERENCE_SET)
/* 143 */           PrefsMessages.message("Setting default preference: " + (new Path(absolutePath())).append(childPath).append(key) + '=' + value); 
/* 144 */         ((EclipsePreferences)internalNode(childPath.toString(), false, null)).internalPut(key, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public IEclipsePreferences node(String childName, Object context) {
/* 150 */     return internalNode(childName, true, context);
/*     */   }
/*     */   
/*     */   private boolean containsNode(Properties props, IPath path) {
/* 154 */     if (props == null)
/* 155 */       return false; 
/* 156 */     for (Enumeration<?> e = props.keys(); e.hasMoreElements(); ) {
/* 157 */       String fullKey = (String)e.nextElement();
/* 158 */       if (props.getProperty(fullKey) == null) {
/*     */         continue;
/*     */       }
/* 161 */       IPath nodePath = (new Path(fullKey)).removeLastSegments(1);
/* 162 */       if (path.isPrefixOf(nodePath))
/* 163 */         return true; 
/*     */     } 
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nodeExists(String path) throws BackingStoreException {
/* 171 */     if (path.length() == 0 || path.charAt(0) == '/') {
/* 172 */       return super.nodeExists(path);
/*     */     }
/* 174 */     if (super.nodeExists(path)) {
/* 175 */       return true;
/*     */     }
/* 177 */     initializeCustomizations();
/*     */     
/* 179 */     IPath scopeBasedPath = (new Path(String.valueOf(absolutePath()) + PATH_SEPARATOR + path)).removeFirstSegments(1);
/* 180 */     return !(!containsNode(productCustomization, scopeBasedPath) && !containsNode(commandLineCustomization, scopeBasedPath));
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeCustomizations() {
/* 185 */     if (productCustomization == null) {
/* 186 */       BundleContext context = Activator.getContext();
/* 187 */       if (context != null) {
/* 188 */         ServiceTracker<?, IProductPreferencesService> productTracker = new ServiceTracker(context, IProductPreferencesService.class, null);
/* 189 */         productTracker.open();
/* 190 */         IProductPreferencesService productSpecials = (IProductPreferencesService)productTracker.getService();
/* 191 */         if (productSpecials != null) {
/* 192 */           productCustomization = productSpecials.getProductCustomization();
/* 193 */           productTranslation = productSpecials.getProductTranslation();
/*     */         } 
/* 195 */         productTracker.close();
/*     */       } else {
/* 197 */         PrefsMessages.message("Product-specified preferences called before plugin is started");
/*     */       } 
/* 199 */       if (productCustomization == null)
/* 200 */         productCustomization = new Properties(); 
/*     */     } 
/* 202 */     if (commandLineCustomization == null) {
/* 203 */       String filename = pluginCustomizationFile;
/* 204 */       if (filename == null) {
/* 205 */         if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 206 */           PrefsMessages.message("Command-line preferences customization file not specified."); 
/*     */       } else {
/* 208 */         if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 209 */           PrefsMessages.message("Using command-line preference customization file: " + filename); 
/* 210 */         commandLineCustomization = loadProperties(filename);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyRuntimeDefaults() {
/* 225 */     WeakReference<Object> ref = PreferencesService.getDefault().applyRuntimeDefaults(name(), this.pluginReference);
/* 226 */     if (ref != null) {
/* 227 */       this.pluginReference = ref;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyProductDefaults() {
/* 238 */     if (!productCustomization.isEmpty()) {
/* 239 */       applyDefaults((String)null, productCustomization, productTranslation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected IEclipsePreferences getLoadLevel() {
/* 250 */     if (this.loadLevel == null) {
/* 251 */       if (this.qualifier == null) {
/* 252 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 256 */       EclipsePreferences node = this;
/* 257 */       for (int i = 2; i < this.segmentCount; i++)
/* 258 */         node = (EclipsePreferences)node.parent(); 
/* 259 */       this.loadLevel = node;
/*     */     } 
/* 261 */     return this.loadLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/* 266 */     return new DefaultPreferences(nodeParent, nodeName, context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/* 271 */     return loadedNodes.contains(node.name());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void load() {
/* 277 */     setInitializingBundleDefaults();
/*     */     try {
/* 279 */       applyRuntimeDefaults();
/* 280 */       applyBundleDefaults();
/*     */     } finally {
/* 282 */       clearInitializingBundleDefaults();
/*     */     } 
/* 284 */     initializeCustomizations();
/* 285 */     applyProductDefaults();
/* 286 */     applyCommandLineDefaults();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String internalPut(String key, String newValue) {
/* 293 */     String result = super.internalPut(key, newValue);
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (isInitializingBundleDefaults()) {
/* 298 */       String relativePath = getScopeRelativePath(absolutePath());
/* 299 */       if (relativePath != null) {
/* 300 */         Preferences node = PreferencesService.getDefault().getRootNode().node("bundle_defaults").node(relativePath);
/* 301 */         node.put(key, newValue);
/*     */       } 
/*     */     } 
/* 304 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInitializingBundleDefaults() {
/* 313 */     IEclipsePreferences node = getLoadLevel();
/* 314 */     if (node instanceof DefaultPreferences) {
/* 315 */       DefaultPreferences loader = (DefaultPreferences)node;
/* 316 */       loader.initializingThread = Thread.currentThread();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearInitializingBundleDefaults() {
/* 326 */     IEclipsePreferences node = getLoadLevel();
/* 327 */     if (node instanceof DefaultPreferences) {
/* 328 */       DefaultPreferences loader = (DefaultPreferences)node;
/* 329 */       loader.initializingThread = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInitializingBundleDefaults() {
/* 339 */     IEclipsePreferences node = getLoadLevel();
/* 340 */     if (node instanceof DefaultPreferences) {
/* 341 */       DefaultPreferences loader = (DefaultPreferences)node;
/* 342 */       return (loader.initializingThread == Thread.currentThread());
/*     */     } 
/* 344 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getScopeRelativePath(String absolutePath) {
/* 353 */     if (absolutePath.length() < 2)
/* 354 */       return null; 
/* 355 */     int index = absolutePath.indexOf('/', 1);
/* 356 */     if (index == -1 || index + 1 >= absolutePath.length())
/* 357 */       return null; 
/* 358 */     return absolutePath.substring(index + 1);
/*     */   }
/*     */   
/*     */   private Properties loadProperties(URL url) {
/* 362 */     Properties result = new Properties();
/* 363 */     if (url == null)
/* 364 */       return result; 
/* 365 */     InputStream input = null;
/*     */     try {
/* 367 */       input = url.openStream();
/* 368 */       result.load(input);
/* 369 */     } catch (IOException|IllegalArgumentException e) {
/* 370 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/* 371 */         PrefsMessages.message("Problem opening stream to preference customization file: " + url);
/* 372 */         e.printStackTrace();
/*     */       } 
/*     */     } finally {
/*     */       
/* 376 */       if (input != null) {
/*     */         try {
/* 378 */           input.close();
/* 379 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */     
/* 383 */     return result;
/*     */   }
/*     */   
/*     */   private Properties loadProperties(String filename) {
/* 387 */     Properties result = new Properties();
/* 388 */     InputStream input = null;
/*     */     try {
/* 390 */       input = new BufferedInputStream(new FileInputStream(filename));
/* 391 */       result.load(input);
/* 392 */     } catch (FileNotFoundException fileNotFoundException) {
/* 393 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 394 */         PrefsMessages.message("Preference customization file not found: " + filename); 
/* 395 */     } catch (IOException|IllegalArgumentException e) {
/* 396 */       String message = NLS.bind(PrefsMessages.preferences_loadException, filename);
/* 397 */       Status status = new Status(4, "org.eclipse.equinox.preferences", 4, message, e);
/* 398 */       RuntimeLog.log((IStatus)status);
/*     */     } finally {
/* 400 */       if (input != null) {
/*     */         try {
/* 402 */           input.close();
/* 403 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */     
/* 407 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void loaded() {
/* 412 */     loadedNodes.add(name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sync() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String translatePreference(String origValue, Properties props) {
/* 426 */     if (props == null || origValue.startsWith("%%"))
/* 427 */       return origValue; 
/* 428 */     if (origValue.startsWith("%")) {
/* 429 */       String value = origValue.trim();
/* 430 */       int ix = value.indexOf(" ");
/* 431 */       String key = (ix == -1) ? value.substring(1) : value.substring(1, ix);
/* 432 */       String dflt = (ix == -1) ? value : value.substring(ix + 1);
/* 433 */       return props.getProperty(key, dflt);
/*     */     } 
/* 435 */     return origValue;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\DefaultPreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */