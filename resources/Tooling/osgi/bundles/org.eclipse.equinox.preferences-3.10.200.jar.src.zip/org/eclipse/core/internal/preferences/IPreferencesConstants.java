package org.eclipse.core.internal.preferences;

public interface IPreferencesConstants {
  public static final String RUNTIME_NAME = "org.eclipse.core.runtime";
  
  public static final String PREFERS_NAME = "org.eclipse.equinox.preferences";
  
  public static final String PLUGIN_CUSTOMIZATION = "-plugincustomization";
  
  public static final String PREFERENCES_DEFAULT_OVERRIDE_BASE_NAME = "preferences";
  
  public static final String PREFERENCES_DEFAULT_OVERRIDE_FILE_NAME = "preferences.ini";
  
  public static final String PT_PREFERENCES = "preferences";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\IPreferencesConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */