/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationPreferences
/*     */   extends EclipsePreferences
/*     */ {
/*     */   private int segmentCount;
/*     */   private String qualifier;
/*     */   private IPath location;
/*     */   private IEclipsePreferences loadLevel;
/*  34 */   private static Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */   private static boolean initialized = false;
/*     */   private static IPath baseLocation;
/*     */   
/*     */   static {
/*  39 */     Location location = PreferencesOSGiUtils.getDefault().getConfigurationLocation();
/*  40 */     if (location != null) {
/*  41 */       URL url = location.getURL();
/*  42 */       if (url != null) {
/*  43 */         baseLocation = (IPath)new Path(url.getFile());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPreferences() {
/*  51 */     this((EclipsePreferences)null, (String)null);
/*     */   }
/*     */   
/*     */   private ConfigurationPreferences(EclipsePreferences parent, String name) {
/*  55 */     super(parent, name);
/*     */     
/*  57 */     initializeChildren();
/*     */ 
/*     */     
/*  60 */     String path = absolutePath();
/*  61 */     this.segmentCount = getSegmentCount(path);
/*  62 */     if (this.segmentCount < 2) {
/*     */       return;
/*     */     }
/*     */     
/*  66 */     this.qualifier = getSegment(path, 1);
/*     */ 
/*     */     
/*  69 */     if (this.qualifier == null)
/*     */       return; 
/*  71 */     if (baseLocation != null) {
/*  72 */       this.location = computeLocation(baseLocation, this.qualifier);
/*     */     }
/*     */   }
/*     */   
/*     */   protected IPath getLocation() {
/*  77 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/*  82 */     return loadedNodes.contains(node.name());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void loaded() {
/*  87 */     loadedNodes.add(name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IEclipsePreferences getLoadLevel() {
/*  95 */     if (this.loadLevel == null) {
/*  96 */       if (this.qualifier == null) {
/*  97 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 101 */       IEclipsePreferences node = this;
/* 102 */       for (int i = 2; i < this.segmentCount; i++)
/* 103 */         node = (EclipsePreferences)node.parent(); 
/* 104 */       this.loadLevel = node;
/*     */     } 
/* 106 */     return this.loadLevel;
/*     */   }
/*     */   
/*     */   protected void initializeChildren() {
/* 110 */     if (initialized || this.parent == null)
/*     */       return; 
/*     */     try {
/* 113 */       synchronized (this) {
/* 114 */         if (baseLocation == null)
/*     */           return; 
/* 116 */         for (String n : computeChildren(baseLocation)) {
/* 117 */           addChild(n, null);
/*     */         }
/*     */       } 
/*     */     } finally {
/* 121 */       initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/* 127 */     return new ConfigurationPreferences(nodeParent, nodeName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\ConfigurationPreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */