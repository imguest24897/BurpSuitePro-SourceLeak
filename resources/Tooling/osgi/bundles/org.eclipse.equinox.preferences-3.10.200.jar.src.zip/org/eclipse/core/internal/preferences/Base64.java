/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*     */   private static final byte equalSign = 61;
/*  20 */   static char[] digits = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/*  21 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/*  22 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/*  23 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(byte[] data) {
/*     */     int j;
/*  34 */     if (data.length == 0)
/*  35 */       return data; 
/*  36 */     int lastRealDataIndex = data.length - 1;
/*  37 */     while (data[lastRealDataIndex] == 61) {
/*  38 */       lastRealDataIndex--;
/*     */     }
/*  40 */     int padBytes = data.length - 1 - lastRealDataIndex;
/*  41 */     int byteLength = data.length * 6 / 8 - padBytes;
/*  42 */     byte[] result = new byte[byteLength];
/*     */     
/*  44 */     int dataIndex = 0;
/*  45 */     int resultIndex = 0;
/*  46 */     int allBits = 0;
/*     */     
/*  48 */     int resultChunks = (lastRealDataIndex + 1) / 4;
/*  49 */     for (int i = 0; i < resultChunks; i++) {
/*  50 */       allBits = 0;
/*     */       int k;
/*  52 */       for (k = 0; k < 4; k++) {
/*  53 */         allBits = allBits << 6 | decodeDigit(data[dataIndex++]);
/*     */       }
/*  55 */       for (k = resultIndex + 2; k >= resultIndex; k--) {
/*  56 */         result[k] = (byte)(allBits & 0xFF);
/*  57 */         allBits >>>= 8;
/*     */       } 
/*  59 */       resultIndex += 3;
/*     */     } 
/*     */ 
/*     */     
/*  63 */     switch (padBytes) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*  68 */         allBits = 0;
/*     */         
/*  70 */         for (j = 0; j < 3; j++) {
/*  71 */           allBits = allBits << 6 | decodeDigit(data[dataIndex++]);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  76 */         allBits <<= 6;
/*     */         
/*  78 */         allBits >>>= 8;
/*     */         
/*  80 */         for (j = resultIndex + 1; j >= resultIndex; j--) {
/*  81 */           result[j] = (byte)(allBits & 0xFF);
/*     */           
/*  83 */           allBits >>>= 8;
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*  90 */         allBits = 0;
/*     */         
/*  92 */         for (j = 0; j < 2; j++) {
/*  93 */           allBits = allBits << 6 | decodeDigit(data[dataIndex++]);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  98 */         allBits <<= 6;
/*  99 */         allBits <<= 6;
/*     */         
/* 101 */         allBits >>>= 8;
/* 102 */         allBits >>>= 8;
/* 103 */         result[resultIndex] = (byte)(allBits & 0xFF);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int decodeDigit(byte data) {
/* 118 */     char charData = (char)data;
/* 119 */     if (charData <= 'Z' && charData >= 'A')
/* 120 */       return charData - 65; 
/* 121 */     if (charData <= 'z' && charData >= 'a')
/* 122 */       return charData - 97 + 26; 
/* 123 */     if (charData <= '9' && charData >= '0')
/* 124 */       return charData - 48 + 52; 
/* 125 */     switch (charData) {
/*     */       case '+':
/* 127 */         return 62;
/*     */       case '/':
/* 129 */         return 63;
/*     */     } 
/* 131 */     throw new IllegalArgumentException("Invalid char to decode: " + data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encode(byte[] data) {
/* 143 */     int j, sourceChunks = data.length / 3;
/* 144 */     int len = (data.length + 2) / 3 * 4;
/* 145 */     byte[] result = new byte[len];
/* 146 */     int extraBytes = data.length - sourceChunks * 3;
/*     */     
/* 148 */     int dataIndex = 0;
/* 149 */     int resultIndex = 0;
/* 150 */     int allBits = 0;
/* 151 */     for (int i = 0; i < sourceChunks; i++) {
/* 152 */       allBits = 0;
/*     */       int k;
/* 154 */       for (k = 0; k < 3; k++) {
/* 155 */         allBits = allBits << 8 | data[dataIndex++] & 0xFF;
/*     */       }
/* 157 */       for (k = resultIndex + 3; k >= resultIndex; k--) {
/* 158 */         result[k] = (byte)digits[allBits & 0x3F];
/*     */ 
/*     */         
/* 161 */         allBits >>>= 6;
/*     */       } 
/* 163 */       resultIndex += 4;
/*     */     } 
/*     */ 
/*     */     
/* 167 */     switch (extraBytes) {
/*     */       case 1:
/* 169 */         allBits = data[dataIndex++];
/* 170 */         allBits <<= 8;
/* 171 */         allBits <<= 8;
/*     */         
/* 173 */         for (j = resultIndex + 3; j >= resultIndex; j--) {
/* 174 */           result[j] = (byte)digits[allBits & 0x3F];
/*     */ 
/*     */           
/* 177 */           allBits >>>= 6;
/*     */         } 
/*     */         
/* 180 */         result[result.length - 1] = 61;
/* 181 */         result[result.length - 2] = 61;
/*     */         break;
/*     */       case 2:
/* 184 */         allBits = data[dataIndex++];
/* 185 */         allBits = allBits << 8 | data[dataIndex++] & 0xFF;
/*     */         
/* 187 */         allBits <<= 8;
/*     */         
/* 189 */         for (j = resultIndex + 3; j >= resultIndex; j--) {
/* 190 */           result[j] = (byte)digits[allBits & 0x3F];
/*     */ 
/*     */           
/* 193 */           allBits >>>= 6;
/*     */         } 
/*     */         
/* 196 */         result[result.length - 1] = 61;
/*     */         break;
/*     */     } 
/* 199 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\Base64.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */