/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BundleDefaultPreferences
/*     */   extends EclipsePreferences
/*     */ {
/*  33 */   private static Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */   
/*     */   private String qualifier;
/*     */   
/*     */   private int segmentCount;
/*     */   
/*     */   private IEclipsePreferences loadLevel;
/*     */   
/*     */   public BundleDefaultPreferences() {
/*  42 */     this((EclipsePreferences)null, (String)null);
/*     */   }
/*     */   
/*     */   private BundleDefaultPreferences(EclipsePreferences parent, String name) {
/*  46 */     super(parent, name);
/*     */     
/*  48 */     Path path = new Path(absolutePath());
/*  49 */     this.segmentCount = path.segmentCount();
/*  50 */     if (this.segmentCount < 2) {
/*     */       return;
/*     */     }
/*     */     
/*  54 */     String scope = path.segment(0);
/*  55 */     if ("bundle_defaults".equals(scope)) {
/*  56 */       this.qualifier = path.segment(1);
/*     */     }
/*     */     
/*  59 */     if (this.qualifier == null) {
/*     */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected IEclipsePreferences getLoadLevel() {
/*  66 */     if (this.loadLevel == null) {
/*  67 */       if (this.qualifier == null) {
/*  68 */         return null;
/*     */       }
/*     */ 
/*     */       
/*  72 */       IEclipsePreferences node = this;
/*  73 */       for (int i = 2; i < this.segmentCount; i++)
/*  74 */         node = (IEclipsePreferences)node.parent(); 
/*  75 */       this.loadLevel = node;
/*     */     } 
/*  77 */     return this.loadLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/*  83 */     return loadedNodes.contains(node.name());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loaded() {
/*  89 */     loadedNodes.add(name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void load() {
/*  97 */     String relativePath = DefaultPreferences.getScopeRelativePath(absolutePath());
/*  98 */     if (relativePath != null)
/*     */     {
/* 100 */       PreferencesService.getDefault().getRootNode().node("default").node(relativePath);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/* 107 */     return new BundleDefaultPreferences(nodeParent, nodeName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\BundleDefaultPreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */