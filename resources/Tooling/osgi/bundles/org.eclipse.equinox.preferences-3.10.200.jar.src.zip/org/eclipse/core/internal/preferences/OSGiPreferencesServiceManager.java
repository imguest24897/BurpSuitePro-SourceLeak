/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.eclipse.core.runtime.preferences.ConfigurationScope;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ import org.osgi.service.prefs.PreferencesService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSGiPreferencesServiceManager
/*     */   implements ServiceFactory<PreferencesService>, BundleListener
/*     */ {
/*     */   private static final String ORG_ECLIPSE_CORE_INTERNAL_PREFERENCES_OSGI = "org.eclipse.core.internal.preferences.osgi";
/*     */   private Preferences prefBundles;
/*     */   
/*     */   public OSGiPreferencesServiceManager(BundleContext context) {
/*  43 */     context.addBundleListener(this);
/*     */ 
/*     */     
/*  46 */     this.prefBundles = (Preferences)ConfigurationScope.INSTANCE.getNode("org.eclipse.core.internal.preferences.osgi");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  52 */       Bundle[] allBundles = context.getBundles();
/*  53 */       Set<String> bundleQualifiers = new TreeSet<>(); byte b; int i; Bundle[] arrayOfBundle1;
/*  54 */       for (i = (arrayOfBundle1 = allBundles).length, b = 0; b < i; ) { Bundle allBundle = arrayOfBundle1[b];
/*  55 */         bundleQualifiers.add(getQualifier(allBundle));
/*     */         
/*     */         b++; }
/*     */       
/*  59 */       String[] prefsBundles = this.prefBundles.keys();
/*     */       
/*     */       String[] arrayOfString1;
/*  62 */       for (int j = (arrayOfString1 = prefsBundles).length; i < j; ) { String prefsBundle = arrayOfString1[i];
/*  63 */         if (!bundleQualifiers.contains(prefsBundle)) {
/*  64 */           removePrefs(prefsBundle);
/*     */         }
/*     */         i++; }
/*     */     
/*  68 */     } catch (BackingStoreException backingStoreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreferencesService getService(Bundle bundle, ServiceRegistration<PreferencesService> registration) {
/*  78 */     String qualifier = getQualifier(bundle);
/*     */     
/*  80 */     Preferences bundlesNode = getBundlesNode();
/*  81 */     bundlesNode.put(qualifier, "");
/*     */     try {
/*  83 */       bundlesNode.flush();
/*  84 */     } catch (BackingStoreException backingStoreException) {}
/*     */ 
/*     */ 
/*     */     
/*  88 */     return new OSGiPreferencesServiceImpl(ConfigurationScope.INSTANCE.getNode(getQualifier(bundle)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getQualifier(Bundle bundle) {
/*  95 */     String qualifier = "org.eclipse.core.runtime.preferences.OSGiPreferences." + bundle.getBundleId();
/*  96 */     return qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetService(Bundle bundle, ServiceRegistration<PreferencesService> registration, PreferencesService service) {
/*     */     try {
/* 106 */       ConfigurationScope.INSTANCE.getNode(getQualifier(bundle)).flush();
/* 107 */     } catch (BackingStoreException backingStoreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 117 */     if (event.getType() == 16) {
/*     */       try {
/* 119 */         removePrefs(getQualifier(event.getBundle()));
/* 120 */       } catch (BackingStoreException backingStoreException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removePrefs(String qualifier) throws BackingStoreException {
/* 130 */     ConfigurationScope.INSTANCE.getNode(qualifier).removeNode();
/*     */ 
/*     */     
/* 133 */     Preferences bundlesNode = getBundlesNode();
/* 134 */     bundlesNode.remove(qualifier);
/* 135 */     bundlesNode.flush();
/*     */   }
/*     */   
/*     */   private Preferences getBundlesNode() {
/*     */     try {
/* 140 */       if (this.prefBundles == null || !this.prefBundles.nodeExists("")) {
/* 141 */         this.prefBundles = (Preferences)ConfigurationScope.INSTANCE.getNode("org.eclipse.core.internal.preferences.osgi");
/*     */       }
/* 143 */       return this.prefBundles;
/* 144 */     } catch (BackingStoreException backingStoreException) {
/*     */ 
/*     */       
/* 147 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\OSGiPreferencesServiceManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */