/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.preferences.AbstractPreferenceStorage;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScopeDescriptor
/*     */ {
/*     */   String name;
/*     */   AbstractPreferenceStorage storage;
/*  28 */   Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */ 
/*     */   
/*     */   public ScopeDescriptor(AbstractPreferenceStorage storage) {
/*  32 */     this.storage = storage;
/*     */   }
/*     */   
/*     */   String getName() {
/*  36 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IEclipsePreferences getLoadLevel(IEclipsePreferences node) {
/*  43 */     String path = node.absolutePath();
/*  44 */     int count = EclipsePreferences.getSegmentCount(path);
/*     */     
/*  46 */     if (count == 1 || count == 0) {
/*  47 */       return null;
/*     */     }
/*  49 */     if (count == 2)
/*  50 */       return node; 
/*  51 */     for (int i = count; i > 2 && node.parent() != null; i--)
/*  52 */       node = (IEclipsePreferences)node.parent(); 
/*  53 */     return node;
/*     */   }
/*     */   
/*     */   String[] childrenNames(final String path) throws BackingStoreException {
/*  57 */     if (this.storage == null)
/*  58 */       return new String[0]; 
/*  59 */     final String[][] result = new String[1][];
/*  60 */     final BackingStoreException[] bse = new BackingStoreException[1];
/*  61 */     ISafeRunnable code = new ISafeRunnable()
/*     */       {
/*     */         public void run() throws Exception {
/*  64 */           result[0] = ScopeDescriptor.this.storage.childrenNames(path);
/*     */         }
/*     */ 
/*     */         
/*     */         public void handleException(Throwable exception) {
/*  69 */           if (exception instanceof BackingStoreException) {
/*  70 */             bse[0] = (BackingStoreException)exception;
/*     */           } else {
/*  72 */             bse[0] = new BackingStoreException(NLS.bind(PrefsMessages.childrenNames2, path), exception);
/*     */           }  }
/*     */       };
/*  75 */     SafeRunner.run(code);
/*  76 */     if (bse[0] != null)
/*  77 */       throw bse[0]; 
/*  78 */     return (result[0] == null) ? new String[0] : result[0];
/*     */   }
/*     */   
/*     */   Properties load(final String path) throws BackingStoreException {
/*  82 */     if (this.storage == null)
/*  83 */       return null; 
/*  84 */     final Properties[] result = new Properties[1];
/*  85 */     final BackingStoreException[] bse = new BackingStoreException[1];
/*  86 */     ISafeRunnable code = new ISafeRunnable()
/*     */       {
/*     */         public void run() throws Exception {
/*  89 */           result[0] = ScopeDescriptor.this.storage.load(path);
/*     */         }
/*     */ 
/*     */         
/*     */         public void handleException(Throwable exception) {
/*  94 */           if (exception instanceof BackingStoreException) {
/*  95 */             bse[0] = (BackingStoreException)exception;
/*     */           } else {
/*  97 */             bse[0] = new BackingStoreException(NLS.bind(PrefsMessages.preferences_loadException, path), exception);
/*     */           }  }
/*     */       };
/* 100 */     SafeRunner.run(code);
/* 101 */     if (bse[0] != null)
/* 102 */       throw bse[0]; 
/* 103 */     return (result[0] == null) ? null : result[0];
/*     */   }
/*     */   
/*     */   void save(final String path, final Properties properties) throws BackingStoreException {
/* 107 */     if (this.storage == null)
/*     */       return; 
/* 109 */     final BackingStoreException[] bse = new BackingStoreException[1];
/* 110 */     ISafeRunnable code = new ISafeRunnable()
/*     */       {
/*     */         public void run() throws Exception {
/* 113 */           ScopeDescriptor.this.storage.save(path, properties);
/*     */         }
/*     */ 
/*     */         
/*     */         public void handleException(Throwable exception) {
/* 118 */           if (exception instanceof BackingStoreException) {
/* 119 */             bse[0] = (BackingStoreException)exception;
/*     */           } else {
/* 121 */             bse[0] = new BackingStoreException(NLS.bind(PrefsMessages.preferences_saveException, path), exception);
/*     */           }  }
/*     */       };
/* 124 */     SafeRunner.run(code);
/* 125 */     if (bse[0] != null)
/* 126 */       throw bse[0]; 
/*     */   }
/*     */   
/*     */   boolean isAlreadyLoaded(String node) {
/* 130 */     return this.loadedNodes.contains(node);
/*     */   }
/*     */   
/*     */   void loaded(String node) {
/* 134 */     this.loadedNodes.add(node);
/*     */   }
/*     */   
/*     */   void removed(final String path) {
/* 138 */     if (this.storage == null)
/*     */       return; 
/* 140 */     SafeRunner.run(new ISafeRunnable()
/*     */         {
/*     */           public void run() throws Exception {
/* 143 */             ScopeDescriptor.this.storage.removed(path);
/*     */           }
/*     */           
/*     */           public void handleException(Throwable exception) {}
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\ScopeDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */