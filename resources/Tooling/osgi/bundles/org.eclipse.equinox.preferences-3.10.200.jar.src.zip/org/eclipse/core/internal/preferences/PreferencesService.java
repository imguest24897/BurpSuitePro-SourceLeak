/*      */ package org.eclipse.core.internal.preferences;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.PluginVersionIdentifier;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.core.runtime.preferences.IExportedPreferences;
/*      */ import org.eclipse.core.runtime.preferences.IPreferenceFilter;
/*      */ import org.eclipse.core.runtime.preferences.IPreferenceNodeVisitor;
/*      */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*      */ import org.eclipse.core.runtime.preferences.IScope;
/*      */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*      */ import org.eclipse.core.runtime.preferences.PreferenceFilterEntry;
/*      */ import org.eclipse.core.runtime.preferences.PreferenceModifyListener;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.service.prefs.BackingStoreException;
/*      */ import org.osgi.service.prefs.Preferences;
/*      */ 
/*      */ public class PreferencesService implements IPreferencesService {
/*      */   private static final long STRING_SHARING_INTERVAL = 300000L;
/*      */   private static final String MATCH_TYPE_PREFIX = "prefix";
/*   44 */   private static String[] DEFAULT_DEFAULT_LOOKUP_ORDER = new String[] {
/*   45 */       "instance", 
/*   46 */       "configuration", 
/*   47 */       "default"
/*      */     };
/*      */   private static final char EXPORT_ROOT_PREFIX = '!';
/*      */   private static final char BUNDLE_VERSION_PREFIX = '@';
/*      */   private static final float EXPORT_VERSION = 3.0F;
/*      */   private static final String VERSION_KEY = "file_export_version";
/*      */   private static final String EMPTY_STRING = "";
/*      */   private static PreferencesService instance;
/*   55 */   static final RootPreferences root = new RootPreferences();
/*   56 */   private static final Map<String, LookupOrder> defaultsRegistry = Collections.synchronizedMap(new HashMap<>());
/*   57 */   private Object registryHelper = null;
/*   58 */   private final Map<String, EclipsePreferences> defaultScopes = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   63 */   private long lastStringSharing = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IStatus createStatusError(String message, Exception e) {
/*   70 */     return (IStatus)new Status(4, "org.eclipse.equinox.preferences", 4, message, e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PreferencesService getDefault() {
/*   77 */     if (instance == null)
/*   78 */       instance = new PreferencesService(); 
/*   79 */     return instance;
/*      */   }
/*      */   
/*      */   static void log(IStatus status) {
/*   83 */     RuntimeLog.log(status);
/*      */   }
/*      */ 
/*      */   
/*      */   PreferencesService() {
/*   88 */     initializeDefaultScopes();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyPreferences(IEclipsePreferences tree, IPreferenceFilter[] filters) throws CoreException {
/*   94 */     if (filters == null || filters.length == 0)
/*      */       return; 
/*      */     try {
/*   97 */       internalApply(tree, filters);
/*      */       
/*      */       try {
/*  100 */         getRootNode().node(tree.absolutePath()).flush();
/*  101 */       } catch (BackingStoreException e) {
/*  102 */         throw new CoreException(createStatusError(PrefsMessages.preferences_saveProblems, e));
/*      */       } 
/*      */ 
/*      */       
/*  106 */       this.lastStringSharing = 0L;
/*  107 */       shareStrings();
/*  108 */     } catch (BackingStoreException e) {
/*  109 */       throw new CoreException(createStatusError(PrefsMessages.preferences_applyProblems, e));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus applyPreferences(IExportedPreferences preferences) throws CoreException {
/*  117 */     if (preferences == null) {
/*  118 */       throw new IllegalArgumentException();
/*      */     }
/*  120 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/*  121 */       PrefsMessages.message("Applying exported preferences: " + ((ExportedPreferences)preferences).toDeepDebugString());
/*      */     }
/*  123 */     MultiStatus result = new MultiStatus("org.eclipse.equinox.preferences", 0, PrefsMessages.preferences_applyProblems, null);
/*      */     
/*  125 */     IEclipsePreferences modifiedNode = firePreApplyEvent((IEclipsePreferences)preferences);
/*      */ 
/*      */     
/*  128 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/*      */           IEclipsePreferences globalNode;
/*  132 */           if (node.parent() == null) {
/*  133 */             globalNode = PreferencesService.root;
/*      */           } else {
/*  135 */             globalNode = (IEclipsePreferences)PreferencesService.root.node(node.absolutePath());
/*  136 */           }  ExportedPreferences epNode = (ExportedPreferences)node;
/*      */ 
/*      */ 
/*      */           
/*  140 */           boolean removed = false;
/*  141 */           if (epNode.isExportRoot()) {
/*  142 */             if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/*  143 */               PrefsMessages.message("Found export root: " + epNode.absolutePath());
/*      */             }
/*  145 */             globalNode.removeNode();
/*  146 */             removed = true;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  151 */           String[] keys = epNode.properties.keys();
/*      */ 
/*      */           
/*  154 */           if (removed) {
/*  155 */             globalNode = (IEclipsePreferences)PreferencesService.root.node(node.absolutePath());
/*      */           }
/*      */           
/*  158 */           List<String> propsToRemove = new ArrayList<>(); byte b; int i; String[] arrayOfString1;
/*  159 */           for (i = (arrayOfString1 = globalNode.keys()).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  160 */             propsToRemove.add(key);
/*      */             b++; }
/*      */           
/*  163 */           if (keys.length > 0) {
/*  164 */             String key = null; String[] arrayOfString;
/*  165 */             for (int j = (arrayOfString = keys).length; i < j; ) { String k = arrayOfString[i];
/*  166 */               key = k;
/*      */ 
/*      */               
/*  169 */               propsToRemove.remove(key);
/*      */ 
/*      */ 
/*      */               
/*  173 */               key = key.intern();
/*  174 */               String value = node.get(key, null);
/*  175 */               if (value != null) {
/*  176 */                 if (EclipsePreferences.DEBUG_PREFERENCE_SET)
/*  177 */                   PrefsMessages.message("Setting: " + globalNode.absolutePath() + '/' + key + '=' + value); 
/*  178 */                 globalNode.put(key, value);
/*      */               } 
/*      */               i++; }
/*      */           
/*      */           } 
/*  183 */           String keyToRemove = null;
/*  184 */           for (Iterator<String> it = propsToRemove.iterator(); it.hasNext(); ) {
/*  185 */             keyToRemove = it.next();
/*  186 */             keyToRemove = keyToRemove.intern();
/*  187 */             if (EclipsePreferences.DEBUG_PREFERENCE_SET)
/*  188 */               PrefsMessages.message("Removing: " + globalNode.absolutePath() + '/' + keyToRemove); 
/*  189 */             globalNode.remove(keyToRemove);
/*      */           } 
/*      */ 
/*      */           
/*  193 */           return true;
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*      */     try {
/*  199 */       modifiedNode.accept(visitor);
/*  200 */     } catch (BackingStoreException e) {
/*  201 */       throw new CoreException(createStatusError(PrefsMessages.preferences_applyProblems, e));
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  206 */       getRootNode().node(modifiedNode.absolutePath()).flush();
/*  207 */     } catch (BackingStoreException e) {
/*  208 */       throw new CoreException(createStatusError(PrefsMessages.preferences_saveProblems, e));
/*      */     } 
/*      */     
/*  211 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/*  212 */       PrefsMessages.message("Current list of all settings: " + ((EclipsePreferences)getRootNode()).toDeepDebugString());
/*      */     }
/*  214 */     this.lastStringSharing = 0L;
/*  215 */     shareStrings();
/*  216 */     return (IStatus)result;
/*      */   }
/*      */   
/*      */   private boolean containsKeys(IEclipsePreferences aRoot) throws BackingStoreException {
/*  220 */     final boolean[] result = new boolean[1];
/*  221 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/*  224 */           if ((node.keys()).length != 0)
/*  225 */             result[0] = true; 
/*  226 */           return !result[0];
/*      */         }
/*      */       };
/*  229 */     aRoot.accept(visitor);
/*  230 */     return result[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Properties convertFromLegacy(Properties properties) {
/*  240 */     Properties result = new Properties();
/*  241 */     String prefix = "/instance/";
/*  242 */     for (Map.Entry<?, ?> entry : properties.entrySet()) {
/*  243 */       String key = (String)entry.getKey();
/*  244 */       String value = (String)entry.getValue();
/*  245 */       if (value != null) {
/*  246 */         int index = key.indexOf('/');
/*  247 */         if (index == -1) {
/*  248 */           result.put(String.valueOf('@') + key, value);
/*  249 */           result.put(String.valueOf('!') + prefix + key, ""); continue;
/*      */         } 
/*  251 */         String path = key.substring(0, index);
/*  252 */         key = key.substring(index + 1);
/*  253 */         result.put(EclipsePreferences.encodePath(String.valueOf(prefix) + path, key), value);
/*      */       } 
/*      */     } 
/*      */     
/*  257 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IExportedPreferences convertFromProperties(Properties properties) {
/*  265 */     IExportedPreferences result = ExportedPreferences.newRoot();
/*  266 */     for (Map.Entry<?, ?> entry : properties.entrySet()) {
/*  267 */       String path = (String)entry.getKey();
/*  268 */       String value = (String)entry.getValue();
/*  269 */       if (path.charAt(0) == '!') {
/*  270 */         ExportedPreferences exportedPreferences = (ExportedPreferences)result.node(path.substring(1));
/*  271 */         exportedPreferences.setExportRoot(); continue;
/*  272 */       }  if (path.charAt(0) == '@') {
/*  273 */         ExportedPreferences exportedPreferences = (ExportedPreferences)result.node("instance").node(path.substring(1));
/*  274 */         exportedPreferences.setVersion(value); continue;
/*      */       } 
/*  276 */       String[] decoded = EclipsePreferences.decodePath(path);
/*  277 */       path = (decoded[0] == null) ? "" : decoded[0];
/*  278 */       ExportedPreferences current = (ExportedPreferences)result.node(path);
/*  279 */       String key = decoded[1];
/*  280 */       current.put(key, value);
/*      */     } 
/*      */     
/*  283 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  284 */       PrefsMessages.message("Converted preferences file to IExportedPreferences tree: " + ((ExportedPreferences)result).toDeepDebugString()); 
/*  285 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SortedProperties convertToProperties(IEclipsePreferences preferences, final String[] excludesList) throws BackingStoreException {
/*  292 */     final SortedProperties result = new SortedProperties();
/*  293 */     final int baseLength = preferences.absolutePath().length();
/*      */ 
/*      */     
/*  296 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) throws BackingStoreException
/*      */         {
/*  300 */           String absolutePath = node.absolutePath();
/*  301 */           String scope = PreferencesService.this.getScope(absolutePath);
/*  302 */           if ("default".equals(scope))
/*  303 */             return false; 
/*  304 */           String path = (absolutePath.length() <= baseLength) ? "" : EclipsePreferences.makeRelative(absolutePath.substring(baseLength)); byte b1; int i;
/*      */           String[] arrayOfString1;
/*  306 */           for (i = (arrayOfString1 = excludesList).length, b1 = 0; b1 < i; ) { String exclude = arrayOfString1[b1];
/*  307 */             String exclusion = EclipsePreferences.makeRelative(exclude);
/*  308 */             if (path.startsWith(exclusion))
/*  309 */               return false;  b1++; }
/*      */           
/*  311 */           boolean needToAddVersion = "instance".equals(scope);
/*      */           
/*  313 */           String[] keys = node.keys(); byte b2; int j; String[] arrayOfString2;
/*  314 */           for (j = (arrayOfString2 = keys).length, b2 = 0; b2 < j; ) { String key = arrayOfString2[b2];
/*  315 */             boolean ignore = false;
/*  316 */             for (int k = 0; !ignore && k < excludesList.length; k++) {
/*  317 */               if (EclipsePreferences.encodePath(path, key).startsWith(EclipsePreferences.makeRelative(excludesList[k])))
/*  318 */                 ignore = true; 
/*  319 */             }  if (!ignore) {
/*  320 */               String value = node.get(key, null);
/*  321 */               if (value != null) {
/*  322 */                 if (needToAddVersion) {
/*  323 */                   String bundle = PreferencesService.this.getBundleName(absolutePath);
/*  324 */                   if (bundle != null) {
/*  325 */                     String version = PreferencesService.this.getBundleVersion(bundle);
/*  326 */                     if (version != null)
/*  327 */                       result.put(String.valueOf('@') + bundle, version); 
/*      */                   } 
/*  329 */                   needToAddVersion = false;
/*      */                 } 
/*  331 */                 result.put(EclipsePreferences.encodePath(absolutePath, key), value);
/*      */               } 
/*      */             }  b2++; }
/*      */           
/*  335 */           return true;
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*  340 */     preferences.accept(visitor);
/*      */ 
/*      */     
/*  343 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyFromTo(Preferences source, Preferences destination, String[] keys, int depth) throws BackingStoreException {
/*  356 */     String[] keysToCopy = (keys == null) ? source.keys() : keys; byte b; int i; String[] arrayOfString1;
/*  357 */     for (i = (arrayOfString1 = keysToCopy).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  358 */       String value = source.get(key, null);
/*  359 */       if (value != null)
/*  360 */         destination.put(key, value); 
/*      */       b++; }
/*      */     
/*  363 */     if (depth == 0)
/*      */       return; 
/*  365 */     String[] children = source.childrenNames(); String[] arrayOfString2;
/*  366 */     for (int j = (arrayOfString2 = children).length; i < j; ) { String child = arrayOfString2[i];
/*  367 */       copyFromTo(source.node(child), destination.node(child), keys, depth);
/*      */       i++; }
/*      */   
/*      */   }
/*      */   public WeakReference<Object> applyRuntimeDefaults(String name, WeakReference<Object> pluginReference) {
/*  372 */     if (this.registryHelper == null)
/*  373 */       return null; 
/*  374 */     return ((PreferenceServiceRegistryHelper)this.registryHelper).applyRuntimeDefaults(name, pluginReference);
/*      */   }
/*      */   
/*      */   private void initializeDefaultScopes() {
/*  378 */     this.defaultScopes.put("bundle_defaults", new BundleDefaultPreferences());
/*  379 */     root.addChild("bundle_defaults", null);
/*  380 */     this.defaultScopes.put("default", new DefaultPreferences());
/*  381 */     root.addChild("default", null);
/*  382 */     this.defaultScopes.put("instance", new InstancePreferences());
/*  383 */     root.addChild("instance", null);
/*  384 */     this.defaultScopes.put("configuration", new ConfigurationPreferences());
/*  385 */     root.addChild("configuration", null);
/*      */   }
/*      */   
/*      */   public IEclipsePreferences createNode(String key) {
/*  389 */     IScope scope = this.defaultScopes.get(key);
/*  390 */     if (scope == null) {
/*  391 */       if (this.registryHelper == null)
/*  392 */         return new EclipsePreferences(root, key); 
/*  393 */       return ((PreferenceServiceRegistryHelper)this.registryHelper).createNode(root, key);
/*      */     } 
/*  395 */     return scope.create(root, key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void exportPreferences(IEclipsePreferences node, IPreferenceFilter[] filters, OutputStream stream) throws CoreException {
/*  401 */     if (filters == null || filters.length == 0)
/*      */       return; 
/*      */     try {
/*  404 */       internalExport(node, filters, stream);
/*  405 */     } catch (BackingStoreException e) {
/*  406 */       throw new CoreException(createStatusError(PrefsMessages.preferences_exportProblems, e));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus exportPreferences(IEclipsePreferences node, OutputStream output, String[] excludesList) throws CoreException {
/*  414 */     if (node == null || output == null)
/*  415 */       throw new IllegalArgumentException(); 
/*  416 */     SortedProperties properties = null;
/*  417 */     if (excludesList == null)
/*  418 */       excludesList = new String[0]; 
/*      */     try {
/*  420 */       properties = convertToProperties(node, excludesList);
/*  421 */       if (properties.isEmpty())
/*  422 */         return Status.OK_STATUS; 
/*  423 */       properties.put("file_export_version", Float.toString(3.0F));
/*  424 */       properties.put(String.valueOf('!') + node.absolutePath(), "");
/*  425 */     } catch (BackingStoreException e) {
/*  426 */       throw new CoreException(createStatusError(e.getMessage(), e));
/*      */     } 
/*      */     try {
/*  429 */       properties.store(output, (String)null);
/*  430 */     } catch (IOException e) {
/*  431 */       throw new CoreException(createStatusError(PrefsMessages.preferences_exportProblems, e));
/*      */     } 
/*  433 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IEclipsePreferences firePreApplyEvent(IEclipsePreferences tree) {
/*  440 */     if (this.registryHelper == null)
/*  441 */       return tree; 
/*  442 */     final IEclipsePreferences[] result = { tree };
/*  443 */     ListenerList<PreferenceModifyListener> listeners = ((PreferenceServiceRegistryHelper)this.registryHelper).getModifyListeners();
/*  444 */     for (PreferenceModifyListener listener : listeners) {
/*  445 */       ISafeRunnable job = new ISafeRunnable()
/*      */         {
/*      */           public void handleException(Throwable exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void run() throws Exception {
/*  453 */             result[0] = listener.preApply(result[0]);
/*      */           }
/*      */         };
/*  456 */       SafeRunner.run(job);
/*      */     } 
/*  458 */     return result[0];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String get(String key, String defaultValue, Preferences[] nodes) {
/*  464 */     if (nodes == null)
/*  465 */       return defaultValue;  byte b; int i; Preferences[] arrayOfPreferences;
/*  466 */     for (i = (arrayOfPreferences = nodes).length, b = 0; b < i; ) { Preferences node = arrayOfPreferences[b];
/*  467 */       if (node != null) {
/*  468 */         String result = node.get(key, null);
/*  469 */         if (result != null)
/*  470 */           return result; 
/*      */       }  b++; }
/*      */     
/*  473 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String qualifier, String key, boolean defaultValue, IScopeContext[] scopes) {
/*  479 */     String result = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  480 */     return (result == null) ? defaultValue : Boolean.valueOf(result).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getBundleName(String path) {
/*  490 */     if (path.length() == 0 || path.charAt(0) != '/')
/*  491 */       return null; 
/*  492 */     int first = path.indexOf('/', 1);
/*  493 */     if (first == -1)
/*  494 */       return null; 
/*  495 */     int second = path.indexOf('/', first + 1);
/*  496 */     return (second == -1) ? path.substring(first + 1) : path.substring(first + 1, second);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getBundleVersion(String bundleName) {
/*  504 */     Bundle bundle = PreferencesOSGiUtils.getDefault().getBundle(bundleName);
/*  505 */     if (bundle != null) {
/*  506 */       Object version = bundle.getHeaders("").get("Bundle-Version");
/*  507 */       if (version != null && version instanceof String)
/*  508 */         return (String)version; 
/*      */     } 
/*  510 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getByteArray(String qualifier, String key, byte[] defaultValue, IScopeContext[] scopes) {
/*  516 */     String result = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  517 */     return (result == null) ? defaultValue : Base64.decode(result.getBytes());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getDefaultLookupOrder(String qualifier, String key) {
/*  523 */     LookupOrder order = defaultsRegistry.get(getRegistryKey(qualifier, key));
/*  524 */     return (order == null) ? null : order.getOrder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String qualifier, String key, double defaultValue, IScopeContext[] scopes) {
/*  530 */     String value = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  531 */     if (value == null)
/*  532 */       return defaultValue; 
/*      */     try {
/*  534 */       return Double.parseDouble(value);
/*  535 */     } catch (NumberFormatException numberFormatException) {
/*  536 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String qualifier, String key, float defaultValue, IScopeContext[] scopes) {
/*  543 */     String value = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  544 */     if (value == null)
/*  545 */       return defaultValue; 
/*      */     try {
/*  547 */       return Float.parseFloat(value);
/*  548 */     } catch (NumberFormatException numberFormatException) {
/*  549 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String qualifier, String key, int defaultValue, IScopeContext[] scopes) {
/*  556 */     String value = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  557 */     if (value == null)
/*  558 */       return defaultValue; 
/*      */     try {
/*  560 */       return Integer.parseInt(value);
/*  561 */     } catch (NumberFormatException numberFormatException) {
/*  562 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String qualifier, String key, long defaultValue, IScopeContext[] scopes) {
/*  571 */     String value = get(EclipsePreferences.decodePath(key)[1], null, getNodes(qualifier, key, scopes));
/*  572 */     if (value == null)
/*  573 */       return defaultValue; 
/*      */     try {
/*  575 */       return Long.parseLong(value);
/*  576 */     } catch (NumberFormatException numberFormatException) {
/*  577 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getLookupOrder(String qualifier, String key) {
/*  584 */     String[] order = getDefaultLookupOrder(qualifier, key);
/*      */ 
/*      */     
/*  587 */     if (order == null && key != null)
/*  588 */       order = getDefaultLookupOrder(qualifier, null); 
/*  589 */     if (order == null)
/*  590 */       order = DEFAULT_DEFAULT_LOOKUP_ORDER; 
/*  591 */     return order;
/*      */   }
/*      */   
/*      */   private Preferences[] getNodes(final String qualifier, String key, final IScopeContext[] contexts) {
/*  595 */     String[] order = getLookupOrder(qualifier, key);
/*  596 */     final String childPath = EclipsePreferences.makeRelative(EclipsePreferences.decodePath(key)[0]);
/*  597 */     final ArrayList<Preferences> result = new ArrayList<>(); byte b; int i; String[] arrayOfString1;
/*  598 */     for (i = (arrayOfString1 = order).length, b = 0; b < i; ) { final String scopeString = arrayOfString1[b];
/*  599 */       final AtomicReference<IllegalStateException> error = new AtomicReference<>();
/*  600 */       SafeRunner.run(new ISafeRunnable()
/*      */           {
/*      */             private IScopeContext context;
/*      */ 
/*      */             
/*      */             public void run() throws Exception {
/*  606 */               boolean found = false;
/*  607 */               for (int j = 0; contexts != null && j < contexts.length; j++) {
/*  608 */                 this.context = contexts[j];
/*  609 */                 if (this.context != null && this.context.getName().equals(scopeString)) {
/*  610 */                   IEclipsePreferences iEclipsePreferences = this.context.getNode(qualifier);
/*  611 */                   if (iEclipsePreferences != null) {
/*  612 */                     Preferences preferences; found = true;
/*  613 */                     if (childPath != null)
/*  614 */                       preferences = iEclipsePreferences.node(childPath); 
/*  615 */                     result.add(preferences);
/*      */                   } 
/*      */                 } 
/*      */               } 
/*  619 */               if (!found) {
/*  620 */                 Preferences node = PreferencesService.this.getRootNode().node(scopeString).node(qualifier);
/*  621 */                 if (childPath != null)
/*  622 */                   node = node.node(childPath); 
/*  623 */                 result.add(node);
/*      */               } 
/*  625 */               found = false;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void handleException(Throwable exception) {
/*  632 */               if (this.context instanceof org.eclipse.core.runtime.preferences.InstanceScope && exception instanceof IllegalStateException && Boolean.getBoolean("osgi.dataAreaRequiresExplicitInit")) {
/*  633 */                 error.set((IllegalStateException)exception);
/*      */               } else {
/*  635 */                 PreferencesService.log((IStatus)new Status(4, "org.eclipse.equinox.preferences", PrefsMessages.preferences_contextError, exception));
/*      */               } 
/*      */             }
/*      */           });
/*      */       
/*  640 */       IllegalStateException illegalState = error.get();
/*  641 */       if (illegalState != null)
/*      */       {
/*  643 */         throw illegalState; } 
/*      */       b++; }
/*      */     
/*  646 */     return result.<Preferences>toArray(new Preferences[result.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getRegistryKey(String qualifier, String key) {
/*  653 */     if (qualifier == null)
/*  654 */       throw new IllegalArgumentException(); 
/*  655 */     if (key == null)
/*  656 */       return qualifier; 
/*  657 */     return String.valueOf(qualifier) + '/' + key;
/*      */   }
/*      */ 
/*      */   
/*      */   public IEclipsePreferences getRootNode() {
/*  662 */     return root;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getScope(String path) {
/*  670 */     if (path == null || path.length() == 0)
/*  671 */       return ""; 
/*  672 */     int startIndex = path.indexOf('/');
/*  673 */     if (startIndex == -1)
/*  674 */       return path; 
/*  675 */     if (path.length() == 1)
/*  676 */       return ""; 
/*  677 */     int endIndex = path.indexOf('/', startIndex + 1);
/*  678 */     if (endIndex == -1)
/*  679 */       endIndex = path.length(); 
/*  680 */     return path.substring(startIndex + 1, endIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String qualifier, String key, String defaultValue, IScopeContext[] scopes) {
/*  686 */     return get(EclipsePreferences.decodePath(key)[1], defaultValue, getNodes(qualifier, key, scopes));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus importPreferences(InputStream input) throws CoreException {
/*  692 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  693 */       PrefsMessages.message("Importing preferences..."); 
/*  694 */     return applyPreferences(readPreferences(input));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalApply(IEclipsePreferences tree, IPreferenceFilter[] filters) throws BackingStoreException {
/*  702 */     ArrayList<IEclipsePreferences> trees = new ArrayList<>(); byte b; int i; IPreferenceFilter[] arrayOfIPreferenceFilter;
/*  703 */     for (i = (arrayOfIPreferenceFilter = filters).length, b = 0; b < i; ) { IPreferenceFilter filter = arrayOfIPreferenceFilter[b];
/*  704 */       trees.add(trimTree(tree, filter));
/*      */       b++; }
/*      */     
/*  707 */     IEclipsePreferences toApply = mergeTrees(trees.<IEclipsePreferences>toArray(new IEclipsePreferences[trees.size()]));
/*      */ 
/*      */     
/*  710 */     toApply = firePreApplyEvent(toApply);
/*      */ 
/*      */     
/*  713 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/*  716 */           String[] keys = node.keys();
/*  717 */           if (keys.length == 0)
/*  718 */             return true; 
/*  719 */           PreferencesService.this.copyFromTo((Preferences)node, PreferencesService.this.getRootNode().node(node.absolutePath()), keys, 0);
/*  720 */           return true;
/*      */         }
/*      */       };
/*  723 */     toApply.accept(visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalExport(IEclipsePreferences node, IPreferenceFilter[] filters, OutputStream output) throws BackingStoreException, CoreException {
/*  731 */     ArrayList<IEclipsePreferences> trees = new ArrayList<>(); byte b; int i; IPreferenceFilter[] arrayOfIPreferenceFilter;
/*  732 */     for (i = (arrayOfIPreferenceFilter = filters).length, b = 0; b < i; ) { IPreferenceFilter filter = arrayOfIPreferenceFilter[b];
/*  733 */       trees.add(trimTree(node, filter)); b++; }
/*      */     
/*  735 */     IEclipsePreferences toExport = mergeTrees(trees.<IEclipsePreferences>toArray(new IEclipsePreferences[trees.size()]));
/*  736 */     exportPreferences(toExport, output, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean internalMatches(IEclipsePreferences tree, IPreferenceFilter filter) throws BackingStoreException {
/*  744 */     String[] scopes = filter.getScopes();
/*  745 */     if (scopes == null)
/*  746 */       throw new IllegalArgumentException(); 
/*  747 */     String treePath = tree.absolutePath(); byte b; int i;
/*      */     String[] arrayOfString1;
/*  749 */     for (i = (arrayOfString1 = scopes).length, b = 0; b < i; ) { String scope = arrayOfString1[b];
/*  750 */       Map<String, PreferenceFilterEntry[]> mapping = filter.getMapping(scope);
/*      */       
/*  752 */       if (mapping == null) {
/*      */         
/*  754 */         if (tree.parent() == null && tree.nodeExists(scope) && 
/*  755 */           containsKeys((IEclipsePreferences)tree.node(scope))) {
/*  756 */           return true;
/*      */         }
/*      */         
/*  759 */         if (scopeMatches(scope, tree) && containsKeys(tree)) {
/*  760 */           return true;
/*      */         }
/*      */       } else {
/*      */         
/*  764 */         for (String nodePath : mapping.keySet()) {
/*  765 */           String nodeFullPath = String.valueOf('/') + scope + '/' + nodePath;
/*      */           
/*  767 */           if (!nodeFullPath.startsWith(treePath)) {
/*      */             continue;
/*      */           }
/*  770 */           String childPath = nodeFullPath.substring(treePath.length());
/*  771 */           childPath = EclipsePreferences.makeRelative(childPath);
/*  772 */           if (tree.nodeExists(childPath)) {
/*      */             PreferenceFilterEntry[] entries;
/*      */             
/*      */             try {
/*  776 */               entries = mapping.get(nodePath);
/*  777 */             } catch (ClassCastException e) {
/*  778 */               log(createStatusError(PrefsMessages.preferences_classCastFilterEntry, e));
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*  783 */             Preferences child = tree.node(childPath);
/*  784 */             if (entries == null) {
/*  785 */               if ((child.keys()).length != 0 || (child.childrenNames()).length != 0)
/*  786 */                 return true;  continue;
/*      */             }  byte b1; int j;
/*      */             PreferenceFilterEntry[] arrayOfPreferenceFilterEntry1;
/*  789 */             for (j = (arrayOfPreferenceFilterEntry1 = entries).length, b1 = 0; b1 < j; ) { PreferenceFilterEntry entry = arrayOfPreferenceFilterEntry1[b1];
/*  790 */               if (entry != null)
/*      */               {
/*      */                 
/*  793 */                 if (entry.getMatchType() == null) {
/*  794 */                   if (child.get(entry.getKey(), null) != null) {
/*  795 */                     return true;
/*      */                   }
/*  797 */                 } else if (internalMatchesWithMatchType(entry, child.keys())) {
/*  798 */                   return true;
/*      */                 }  }  b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */       }  b++; }
/*      */     
/*  805 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IPreferenceFilter[] internalMatches(IEclipsePreferences tree, IPreferenceFilter[] filters) throws BackingStoreException {
/*  812 */     ArrayList<IPreferenceFilter> result = new ArrayList<>(); byte b; int i; IPreferenceFilter[] arrayOfIPreferenceFilter;
/*  813 */     for (i = (arrayOfIPreferenceFilter = filters).length, b = 0; b < i; ) { IPreferenceFilter filter = arrayOfIPreferenceFilter[b];
/*  814 */       if (internalMatches(tree, filter))
/*  815 */         result.add(filter); 
/*      */       b++; }
/*      */     
/*  818 */     return result.<IPreferenceFilter>toArray(new IPreferenceFilter[result.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean internalMatchesWithMatchType(PreferenceFilterEntry entry, String[] keys) {
/*  825 */     if (keys == null || keys.length == 0)
/*  826 */       return false; 
/*  827 */     String key = entry.getKey();
/*  828 */     String matchType = entry.getMatchType();
/*  829 */     if (!matchType.equalsIgnoreCase("prefix"))
/*  830 */       return false;  byte b; int i; String[] arrayOfString;
/*  831 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String k = arrayOfString[b];
/*  832 */       if (k.startsWith(key))
/*  833 */         return true; 
/*      */       b++; }
/*      */     
/*  836 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isLegacy(Properties properties) {
/*  847 */     return (properties.getProperty("file_export_version") == null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IPreferenceFilter[] matches(IEclipsePreferences tree, IPreferenceFilter[] filters) throws CoreException {
/*  853 */     if (filters == null || filters.length == 0)
/*  854 */       return new IPreferenceFilter[0]; 
/*      */     try {
/*  856 */       return internalMatches(tree, filters);
/*  857 */     } catch (BackingStoreException e) {
/*  858 */       throw new CoreException(createStatusError(PrefsMessages.preferences_matching, e));
/*      */     } 
/*      */   }
/*      */   
/*      */   private IEclipsePreferences mergeTrees(IEclipsePreferences[] trees) throws BackingStoreException {
/*  863 */     if (trees.length == 1)
/*  864 */       return trees[0]; 
/*  865 */     final IExportedPreferences result = ExportedPreferences.newRoot();
/*  866 */     if (trees.length == 0)
/*  867 */       return (IEclipsePreferences)iExportedPreferences; 
/*  868 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/*  871 */           Preferences destination = result.node(node.absolutePath());
/*  872 */           PreferencesService.this.copyFromTo((Preferences)node, destination, null, 0);
/*  873 */           return true; } }; byte b;
/*      */     int i;
/*      */     IEclipsePreferences[] arrayOfIEclipsePreferences;
/*  876 */     for (i = (arrayOfIEclipsePreferences = trees).length, b = 0; b < i; ) { IEclipsePreferences tree = arrayOfIEclipsePreferences[b];
/*  877 */       tree.accept(visitor); b++; }
/*      */     
/*  879 */     return (IEclipsePreferences)iExportedPreferences;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IExportedPreferences readPreferences(InputStream input) throws CoreException {
/*  885 */     if (input == null) {
/*  886 */       throw new IllegalArgumentException();
/*      */     }
/*  888 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/*  889 */       PrefsMessages.message("Reading preferences from stream...");
/*      */     }
/*      */     
/*  892 */     Properties properties = new Properties();
/*      */     try {
/*  894 */       properties.load(input);
/*  895 */     } catch (IOException|IllegalArgumentException e) {
/*  896 */       throw new CoreException(createStatusError(PrefsMessages.preferences_importProblems, e));
/*      */     } finally {
/*      */       try {
/*  899 */         input.close();
/*  900 */       } catch (IOException iOException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  906 */     if (properties.isEmpty()) {
/*  907 */       throw new CoreException(createStatusError(PrefsMessages.preferences_invalidFileFormat, null));
/*      */     }
/*      */     
/*  910 */     if (isLegacy(properties)) {
/*  911 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  912 */         PrefsMessages.message("Read legacy preferences file, converting to 3.0 format..."); 
/*  913 */       properties = convertFromLegacy(properties);
/*      */     } else {
/*  915 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  916 */         PrefsMessages.message("Read preferences file."); 
/*  917 */       properties.remove("file_export_version");
/*      */     } 
/*      */ 
/*      */     
/*  921 */     return convertFromProperties(properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean scopeMatches(String scope, IEclipsePreferences tree) {
/*  929 */     if (tree.parent() == null) {
/*  930 */       return false;
/*      */     }
/*  932 */     String path = tree.absolutePath();
/*  933 */     int index = path.indexOf('/', 1);
/*  934 */     String sub = path.substring(1, (index == -1) ? path.length() : index);
/*  935 */     return scope.equals(sub);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultLookupOrder(String qualifier, String key, String[] order) {
/*  941 */     String registryKey = getRegistryKey(qualifier, key);
/*  942 */     if (order == null) {
/*  943 */       defaultsRegistry.remove(registryKey);
/*      */     } else {
/*  945 */       LookupOrder obj = new LookupOrder(order);
/*  946 */       defaultsRegistry.put(registryKey, obj);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setRegistryHelper(Object registryHelper) {
/*  951 */     if (this.registryHelper != null && this.registryHelper != registryHelper)
/*  952 */       ((PreferenceServiceRegistryHelper)this.registryHelper).stop(); 
/*  953 */     this.registryHelper = registryHelper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void shareStrings() {
/*  960 */     long now = System.currentTimeMillis();
/*  961 */     if (now - this.lastStringSharing < 300000L)
/*      */       return; 
/*  963 */     StringPool pool = new StringPool();
/*  964 */     root.shareStrings(pool);
/*  965 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/*  966 */       System.out.println("Preference string sharing saved: " + pool.getSavedStringCount()); 
/*  967 */     this.lastStringSharing = now;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IEclipsePreferences trimTree(IEclipsePreferences tree, IPreferenceFilter filter) throws BackingStoreException {
/*  974 */     IEclipsePreferences result = (IEclipsePreferences)ExportedPreferences.newRoot().node(tree.absolutePath());
/*  975 */     String[] scopes = filter.getScopes();
/*  976 */     if (scopes == null)
/*  977 */       throw new IllegalArgumentException(); 
/*  978 */     String treePath = tree.absolutePath(); byte b; int i;
/*      */     String[] arrayOfString1;
/*  980 */     for (i = (arrayOfString1 = scopes).length, b = 0; b < i; ) { String scope = arrayOfString1[b];
/*  981 */       Map<String, PreferenceFilterEntry[]> mapping = filter.getMapping(scope);
/*      */       
/*  983 */       if (mapping == null) {
/*      */         
/*  985 */         if (tree.parent() == null && tree.nodeExists(scope)) {
/*  986 */           copyFromTo(tree.node(scope), result.node(scope), null, -1);
/*      */         }
/*  988 */         else if (scopeMatches(scope, tree)) {
/*  989 */           copyFromTo((Preferences)tree, (Preferences)result, null, -1);
/*      */         } 
/*      */       } else {
/*      */         
/*  993 */         for (String nodePath : mapping.keySet()) {
/*  994 */           String nodeFullPath = String.valueOf('/') + scope + '/' + nodePath;
/*      */           
/*  996 */           if (!nodeFullPath.startsWith(treePath)) {
/*      */             continue;
/*      */           }
/*  999 */           String childPath = nodeFullPath.substring(treePath.length());
/* 1000 */           childPath = EclipsePreferences.makeRelative(childPath);
/* 1001 */           if (tree.nodeExists(childPath)) {
/* 1002 */             PreferenceFilterEntry[] entries; Preferences child = tree.node(childPath);
/*      */ 
/*      */             
/*      */             try {
/* 1006 */               entries = mapping.get(nodePath);
/* 1007 */             } catch (ClassCastException e) {
/* 1008 */               log(createStatusError(PrefsMessages.preferences_classCastFilterEntry, e));
/*      */               continue;
/*      */             } 
/* 1011 */             String[] keys = null;
/* 1012 */             if (entries != null) {
/* 1013 */               ArrayList<String> list = new ArrayList<>(); byte b1; int j; PreferenceFilterEntry[] arrayOfPreferenceFilterEntry;
/* 1014 */               for (j = (arrayOfPreferenceFilterEntry = entries).length, b1 = 0; b1 < j; ) { PreferenceFilterEntry entry = arrayOfPreferenceFilterEntry[b1];
/* 1015 */                 if (entry != null)
/* 1016 */                   addMatchedKeys(list, entry, child.keys()); 
/*      */                 b1++; }
/*      */               
/* 1019 */               keys = list.<String>toArray(new String[list.size()]);
/*      */             } 
/*      */             
/* 1022 */             copyFromTo(tree.node(childPath), result.node(childPath), keys, (keys == null) ? -1 : 0);
/*      */           } 
/*      */         } 
/*      */       }  b++; }
/* 1026 */      return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addMatchedKeys(ArrayList<String> list, PreferenceFilterEntry entry, String[] keys) {
/* 1033 */     String matchType = entry.getMatchType();
/* 1034 */     if (matchType == null) {
/* 1035 */       list.add(entry.getKey());
/*      */       return;
/*      */     } 
/* 1038 */     if (keys == null)
/*      */       return; 
/* 1040 */     String key = entry.getKey(); byte b; int i; String[] arrayOfString;
/* 1041 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String k = arrayOfString[b];
/* 1042 */       if (matchType.equals("prefix") && k.startsWith(key)) {
/* 1043 */         list.add(k);
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IStatus validatePluginVersions(String bundle, PluginVersionIdentifier pref, PluginVersionIdentifier installed) {
/*      */     int severity;
/* 1063 */     if (installed.getMajorComponent() == pref.getMajorComponent() && installed.getMinorComponent() == pref.getMinorComponent()) {
/* 1064 */       return null;
/*      */     }
/* 1066 */     if (installed.getMajorComponent() < pref.getMajorComponent()) {
/* 1067 */       severity = 4;
/*      */     } else {
/* 1069 */       severity = 2;
/* 1070 */     }  String msg = NLS.bind(PrefsMessages.preferences_incompatible, new Object[] { pref, bundle, installed });
/* 1071 */     return (IStatus)new Status(severity, "org.eclipse.equinox.preferences", 1, msg, null);
/*      */   }
/*      */   
/*      */   public IStatus validateVersions(IPath path) {
/* 1075 */     final MultiStatus result = new MultiStatus("org.eclipse.equinox.preferences", 1, PrefsMessages.preferences_validate, null);
/* 1076 */     IPreferenceNodeVisitor visitor = new IPreferenceNodeVisitor()
/*      */       {
/*      */         public boolean visit(IEclipsePreferences node) {
/* 1079 */           if (!(node instanceof ExportedPreferences)) {
/* 1080 */             return false;
/*      */           }
/*      */           
/* 1083 */           ExportedPreferences realNode = (ExportedPreferences)node;
/* 1084 */           String version = realNode.getVersion();
/* 1085 */           if (version == null || !PluginVersionIdentifier.validateVersion(version).isOK())
/* 1086 */             return true; 
/* 1087 */           PluginVersionIdentifier versionInFile = new PluginVersionIdentifier(version);
/*      */ 
/*      */           
/* 1090 */           String bundleName = PreferencesService.this.getBundleName(node.absolutePath());
/* 1091 */           if (bundleName == null)
/* 1092 */             return true; 
/* 1093 */           String stringVersion = PreferencesService.this.getBundleVersion(bundleName);
/* 1094 */           if (stringVersion == null || !PluginVersionIdentifier.validateVersion(stringVersion).isOK())
/* 1095 */             return true; 
/* 1096 */           PluginVersionIdentifier versionInMemory = new PluginVersionIdentifier(stringVersion);
/*      */ 
/*      */           
/* 1099 */           IStatus verification = PreferencesService.this.validatePluginVersions(bundleName, versionInFile, versionInMemory);
/* 1100 */           if (verification != null) {
/* 1101 */             result.add(verification);
/*      */           }
/* 1103 */           return true;
/*      */         }
/*      */       };
/*      */     
/* 1107 */     InputStream input = null;
/*      */     try {
/* 1109 */       input = new BufferedInputStream(new FileInputStream(path.toFile()));
/* 1110 */       IExportedPreferences prefs = readPreferences(input);
/* 1111 */       prefs.accept(visitor);
/* 1112 */     } catch (FileNotFoundException fileNotFoundException) {
/*      */     
/* 1114 */     } catch (CoreException|BackingStoreException e) {
/* 1115 */       result.add(createStatusError(PrefsMessages.preferences_validationException, e));
/*      */     } 
/* 1117 */     return (IStatus)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getDefaultDefaultLookupOrder() {
/* 1124 */     return DEFAULT_DEFAULT_LOOKUP_ORDER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultDefaultLookupOrder(String[] order) {
/* 1135 */     if (order == null)
/* 1136 */       order = new String[0]; 
/* 1137 */     DEFAULT_DEFAULT_LOOKUP_ORDER = order;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\PreferencesService.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */