/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ImmutableMap
/*     */   implements Cloneable
/*     */ {
/*     */   static class ArrayMap
/*     */     extends ImmutableMap
/*     */   {
/*     */     private static final float LOAD_FACTOR = 0.45F;
/*  45 */     private int elementSize = 0; private String[] keyTable;
/*     */     ArrayMap(int size) {
/*  47 */       int tableLen = 1;
/*  48 */       while (tableLen < size)
/*  49 */         tableLen *= 2; 
/*  50 */       this.keyTable = new String[tableLen];
/*  51 */       this.valueTable = new String[tableLen];
/*  52 */       this.threshold = (int)(tableLen * 0.45F);
/*     */     }
/*     */     private int threshold; private String[] valueTable;
/*     */     
/*     */     public String get(String key) {
/*  57 */       int lengthMask = this.keyTable.length - 1;
/*  58 */       int index = key.hashCode() & lengthMask;
/*     */       String currentKey;
/*  60 */       while ((currentKey = this.keyTable[index]) != null) {
/*  61 */         if (currentKey.equals(key))
/*  62 */           return this.valueTable[index]; 
/*  63 */         index = index + 1 & lengthMask;
/*     */       } 
/*  65 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void internalPut(String key, String value) {
/*  77 */       int lengthMask = this.keyTable.length - 1;
/*  78 */       int index = key.hashCode() & lengthMask;
/*     */       String currentKey;
/*  80 */       while ((currentKey = this.keyTable[index]) != null) {
/*  81 */         if (currentKey.equals(key)) {
/*  82 */           this.valueTable[index] = value;
/*     */           return;
/*     */         } 
/*  85 */         index = index + 1 & lengthMask;
/*     */       } 
/*  87 */       this.keyTable[index] = key;
/*  88 */       this.valueTable[index] = value;
/*  89 */       this.elementSize++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] keys() {
/*  97 */       if (this.elementSize == 0)
/*  98 */         return EMPTY_STRING_ARRAY; 
/*  99 */       String[] result = new String[this.elementSize];
/* 100 */       int next = 0; byte b; int i; String[] arrayOfString1;
/* 101 */       for (i = (arrayOfString1 = this.keyTable).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 102 */         if (key != null)
/* 103 */           result[next++] = key; 
/*     */         b++; }
/*     */       
/* 106 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImmutableMap put(String key, String value) {
/*     */       ArrayMap result;
/* 112 */       int oldLen = this.keyTable.length;
/* 113 */       if (this.elementSize + 1 > this.threshold)
/*     */       
/*     */       { 
/* 116 */         result = new ArrayMap(oldLen * 2);
/* 117 */         for (int i = oldLen; --i >= 0;) {
/* 118 */           if ((currentKey = this.keyTable[i]) != null)
/* 119 */             result.internalPut(currentKey, this.valueTable[i]); 
/*     */         }  }
/* 121 */       else { result = new ArrayMap(oldLen);
/* 122 */         System.arraycopy(this.keyTable, 0, result.keyTable, 0, this.keyTable.length);
/* 123 */         System.arraycopy(this.valueTable, 0, result.valueTable, 0, this.valueTable.length);
/* 124 */         result.elementSize = this.elementSize; }
/*     */       
/* 126 */       result.internalPut(key, value);
/* 127 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImmutableMap removeKey(String key) {
/* 132 */       int lengthMask = this.keyTable.length - 1;
/* 133 */       int index = key.hashCode() & lengthMask;
/*     */       String currentKey;
/* 135 */       while ((currentKey = this.keyTable[index]) != null) {
/* 136 */         if (currentKey.equals(key)) {
/* 137 */           if (this.elementSize <= 1) {
/* 138 */             return EMPTY;
/*     */           }
/* 140 */           ImmutableMap result = createMap((int)(this.elementSize / 0.45F)); int i;
/* 141 */           for (i = 0; i < index; i++) {
/* 142 */             if ((currentKey = this.keyTable[i]) != null)
/* 143 */               result.internalPut(currentKey, this.valueTable[i]); 
/* 144 */           }  for (i = index + 1; i <= lengthMask; i++) {
/* 145 */             if ((currentKey = this.keyTable[i]) != null)
/* 146 */               result.internalPut(currentKey, this.valueTable[i]); 
/* 147 */           }  return result;
/*     */         } 
/* 149 */         index = index + 1 & lengthMask;
/*     */       } 
/* 151 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void shareStrings(StringPool set) {
/* 158 */       String[] array = this.keyTable;
/* 159 */       if (array == null)
/*     */         return;  int i;
/* 161 */       for (i = 0; i < array.length; i++) {
/* 162 */         String o = array[i];
/* 163 */         if (o != null)
/* 164 */           array[i] = set.add(o); 
/*     */       } 
/* 166 */       array = this.valueTable;
/* 167 */       if (array == null)
/*     */         return; 
/* 169 */       for (i = 0; i < array.length; i++) {
/* 170 */         String o = array[i];
/* 171 */         if (o != null) {
/* 172 */           array[i] = set.add(o);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public int size() {
/* 178 */       return this.elementSize;
/*     */     }
/*     */   }
/*     */   
/*     */   static class EmptyMap
/*     */     extends ImmutableMap
/*     */   {
/*     */     public String get(String value) {
/* 186 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImmutableMap removeKey(String key) {
/* 191 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void internalPut(String key, String value) {
/* 196 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] keys() {
/* 201 */       return EMPTY_STRING_ARRAY;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImmutableMap put(String key, String value) {
/* 206 */       ImmutableMap result = createMap(4);
/* 207 */       result.internalPut(key, value);
/* 208 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 213 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public static final ImmutableMap EMPTY = new EmptyMap();
/*     */   
/* 223 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String get(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static ImmutableMap createMap(int i) {
/* 234 */     if (i <= 0)
/* 235 */       return EMPTY; 
/* 236 */     return new ArrayMap(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void internalPut(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] keys();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ImmutableMap put(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ImmutableMap removeKey(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 284 */     StringBuilder s = new StringBuilder(); byte b; int i; String[] arrayOfString;
/* 285 */     for (i = (arrayOfString = keys()).length, b = 0; b < i; ) { String key = arrayOfString[b];
/* 286 */       s.append(key).append(" -> ").append(get(key)).append("\n"); b++; }
/* 287 */      return s.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\ImmutableMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */