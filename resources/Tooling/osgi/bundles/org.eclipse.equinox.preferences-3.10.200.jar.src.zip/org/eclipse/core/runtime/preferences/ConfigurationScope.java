/*    */ package org.eclipse.core.runtime.preferences;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.internal.preferences.AbstractScope;
/*    */ import org.eclipse.core.internal.preferences.PreferencesOSGiUtils;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.osgi.service.datalocation.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConfigurationScope
/*    */   extends AbstractScope
/*    */ {
/*    */   public static final String SCOPE = "configuration";
/* 59 */   public static final IScopeContext INSTANCE = (IScopeContext)new ConfigurationScope();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 72 */     return "configuration";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 78 */     return super.getNode(qualifier);
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getLocation() {
/*    */     Path path;
/* 84 */     IPath result = null;
/* 85 */     Location location = PreferencesOSGiUtils.getDefault().getConfigurationLocation();
/* 86 */     if (!location.isReadOnly()) {
/* 87 */       URL url = location.getURL();
/* 88 */       if (url != null) {
/* 89 */         path = new Path(url.getFile());
/* 90 */         if (path.isEmpty())
/* 91 */           path = null; 
/*    */       } 
/*    */     } 
/* 94 */     return (IPath)path;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\ConfigurationScope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */