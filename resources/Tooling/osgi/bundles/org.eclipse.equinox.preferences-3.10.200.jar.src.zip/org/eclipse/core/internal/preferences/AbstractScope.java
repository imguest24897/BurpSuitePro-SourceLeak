/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractScope
/*    */   implements IScopeContext
/*    */ {
/*    */   public abstract String getName();
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 39 */     if (qualifier == null)
/* 40 */       throw new IllegalArgumentException(); 
/* 41 */     return (IEclipsePreferences)PreferencesService.getDefault().getRootNode().node(getName()).node(qualifier);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract IPath getLocation();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 51 */     if (this == obj)
/* 52 */       return true; 
/* 53 */     if (!(obj instanceof IScopeContext))
/* 54 */       return false; 
/* 55 */     IScopeContext other = (IScopeContext)obj;
/* 56 */     if (!getName().equals(other.getName()))
/* 57 */       return false; 
/* 58 */     IPath location = getLocation();
/* 59 */     return (location == null) ? ((other.getLocation() == null)) : location.equals(other.getLocation());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 65 */     return getName().hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\AbstractScope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */