/*     */ package org.eclipse.core.runtime.preferences;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.internal.preferences.PrefsMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreferenceMetadata<V>
/*     */ {
/*     */   private final Class<V> clazz;
/*     */   private final String identifier;
/*     */   private final V defaultValue;
/*     */   private final String name;
/*     */   private final String description;
/*     */   
/*     */   public PreferenceMetadata(Class<V> clazz, String identifier, V defaultValue, String name) {
/*  48 */     this(clazz, identifier, defaultValue, name, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreferenceMetadata(Class<V> clazz, String identifier, V defaultValue, String name, String description) {
/*  63 */     Objects.requireNonNull(clazz, PrefsMessages.PreferenceMetadata_e_null_value_type);
/*  64 */     Objects.requireNonNull(identifier, PrefsMessages.PreferenceMetadata_e_null_identifier);
/*  65 */     Objects.requireNonNull(defaultValue, PrefsMessages.PreferenceMetadata_e_null_default_value);
/*  66 */     Objects.requireNonNull(name, PrefsMessages.PreferenceMetadata_e_null_name);
/*  67 */     Objects.requireNonNull(description, PrefsMessages.PreferenceMetadata_e_null_description);
/*  68 */     this.clazz = clazz;
/*  69 */     this.identifier = identifier;
/*  70 */     this.defaultValue = defaultValue;
/*  71 */     this.name = name;
/*  72 */     this.description = description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String identifer() {
/*  82 */     return this.identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V defaultValue() {
/*  91 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 101 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String description() {
/* 111 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<V> valueClass() {
/* 120 */     return this.clazz;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\PreferenceMetadata.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */