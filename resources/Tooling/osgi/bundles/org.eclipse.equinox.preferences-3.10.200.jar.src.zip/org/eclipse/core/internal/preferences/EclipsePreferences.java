/*      */ package org.eclipse.core.internal.preferences;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.StandardCopyOption;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.core.runtime.preferences.IPreferenceNodeVisitor;
/*      */ import org.eclipse.core.runtime.preferences.IScope;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.service.prefs.BackingStoreException;
/*      */ import org.osgi.service.prefs.Preferences;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class EclipsePreferences
/*      */   implements IEclipsePreferences, IScope
/*      */ {
/*      */   public static final String DEFAULT_PREFERENCES_DIRNAME = ".settings";
/*      */   public static final String PREFS_FILE_EXTENSION = "prefs";
/*   50 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*      */   private static final String FALSE = "false";
/*      */   private static final String TRUE = "true";
/*      */   protected static final String VERSION_KEY = "eclipse.preferences.version";
/*      */   protected static final String VERSION_VALUE = "1";
/*   55 */   protected static final String PATH_SEPARATOR = String.valueOf('/');
/*      */   
/*      */   protected static final String DOUBLE_SLASH = "//";
/*      */   protected static final String EMPTY_STRING = "";
/*      */   private static final String BACKUP_FILE_EXTENSION = ".bak";
/*      */   private String cachedPath;
/*   61 */   protected ImmutableMap properties = ImmutableMap.EMPTY;
/*      */ 
/*      */   
/*      */   protected Map<String, Object> children;
/*      */   
/*   66 */   private final Object childAndPropertyLock = new Object();
/*      */   
/*      */   protected boolean dirty = false;
/*      */   protected boolean loading = false;
/*      */   protected final String name;
/*      */   protected final EclipsePreferences parent;
/*      */   protected boolean removed = false;
/*   73 */   private final ListenerList<IEclipsePreferences.INodeChangeListener> nodeChangeListeners = new ListenerList();
/*   74 */   private final ListenerList<IEclipsePreferences.IPreferenceChangeListener> preferenceChangeListeners = new ListenerList();
/*      */   
/*      */   private ScopeDescriptor descriptor;
/*      */   public static boolean DEBUG_PREFERENCE_GENERAL = false;
/*      */   public static boolean DEBUG_PREFERENCE_SET = false;
/*      */   public static boolean DEBUG_PREFERENCE_GET = false;
/*      */   protected static final String debugPluginName = "org.eclipse.equinox.preferences";
/*      */   private final Object writeLock;
/*      */   
/*      */   static {
/*   84 */     DEBUG_PREFERENCE_GENERAL = PreferencesOSGiUtils.getDefault().getBooleanDebugOption("org.eclipse.equinox.preferences/general", false);
/*   85 */     DEBUG_PREFERENCE_SET = PreferencesOSGiUtils.getDefault().getBooleanDebugOption("org.eclipse.equinox.preferences/set", false);
/*   86 */     DEBUG_PREFERENCE_GET = PreferencesOSGiUtils.getDefault().getBooleanDebugOption("org.eclipse.equinox.preferences/get", false);
/*      */   }
/*      */   
/*      */   public EclipsePreferences() {
/*   90 */     this(null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String absolutePath() {
/*  103 */     if (this.cachedPath == null)
/*  104 */       if (this.parent == null) {
/*  105 */         this.cachedPath = PATH_SEPARATOR;
/*      */       } else {
/*  107 */         String parentPath = this.parent.absolutePath();
/*      */ 
/*      */         
/*  110 */         if (parentPath.length() == 1) {
/*  111 */           this.cachedPath = String.valueOf(parentPath) + name();
/*      */         } else {
/*  113 */           this.cachedPath = String.valueOf(parentPath) + PATH_SEPARATOR + name();
/*      */         } 
/*      */       }  
/*  116 */     return this.cachedPath;
/*      */   }
/*      */ 
/*      */   
/*      */   public void accept(IPreferenceNodeVisitor visitor) throws BackingStoreException {
/*  121 */     if (!visitor.visit(this))
/*      */       return; 
/*  123 */     for (IEclipsePreferences p : getChildren(true)) {
/*  124 */       p.accept(visitor);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected IEclipsePreferences addChild(String childName, IEclipsePreferences child) {
/*  130 */     synchronized (this.childAndPropertyLock) {
/*  131 */       if (this.children == null)
/*  132 */         this.children = Collections.synchronizedMap(new HashMap<>()); 
/*  133 */       this.children.put(childName, (child == null) ? childName : child);
/*  134 */       return child;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNodeChangeListener(IEclipsePreferences.INodeChangeListener listener) {
/*  141 */     checkRemoved();
/*  142 */     this.nodeChangeListeners.add(listener);
/*  143 */     if (DEBUG_PREFERENCE_GENERAL) {
/*  144 */       PrefsMessages.message("Added preference node change listener: " + listener + " to: " + absolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPreferenceChangeListener(IEclipsePreferences.IPreferenceChangeListener listener) {
/*  150 */     checkRemoved();
/*  151 */     this.preferenceChangeListeners.add(listener);
/*  152 */     if (DEBUG_PREFERENCE_GENERAL)
/*  153 */       PrefsMessages.message("Added preference property change listener: " + listener + " to: " + absolutePath()); 
/*      */   }
/*      */   
/*      */   private IEclipsePreferences calculateRoot() {
/*  157 */     IEclipsePreferences result = this;
/*  158 */     while (result.parent() != null)
/*  159 */       result = (IEclipsePreferences)result.parent(); 
/*  160 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkRemoved() {
/*  168 */     if (this.removed) {
/*  169 */       throw new IllegalStateException(NLS.bind(PrefsMessages.preferences_removedNode, this.name));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] childrenNames() throws BackingStoreException {
/*  176 */     checkRemoved();
/*  177 */     String[] internal = internalChildNames();
/*      */     
/*  179 */     if (internal.length != 0) {
/*  180 */       return internal;
/*      */     }
/*      */     
/*  183 */     if (this.descriptor != null && getSegmentCount(absolutePath()) == 1)
/*  184 */       return this.descriptor.childrenNames(absolutePath()); 
/*  185 */     return internal;
/*      */   }
/*      */   
/*      */   protected String[] internalChildNames() {
/*  189 */     synchronized (this.childAndPropertyLock) {
/*  190 */       if (this.children == null || this.children.isEmpty()) {
/*  191 */         return EMPTY_STRING_ARRAY;
/*      */       }
/*  193 */       return (String[])this.children.keySet().toArray(paramInt -> new String[paramInt]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*      */     String[] keys;
/*  201 */     checkRemoved();
/*      */ 
/*      */ 
/*      */     
/*  205 */     synchronized (this.childAndPropertyLock) {
/*  206 */       keys = this.properties.keys();
/*      */     }  byte b; int i;
/*      */     String[] arrayOfString1;
/*  209 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  210 */       remove(key); b++; }
/*      */     
/*  212 */     makeDirty();
/*      */   }
/*      */   
/*      */   protected List<String> computeChildren(IPath root) {
/*  216 */     if (root == null) {
/*  217 */       return List.of();
/*      */     }
/*  219 */     IPath dir = root.append(".settings");
/*  220 */     List<String> result = new ArrayList<>();
/*  221 */     String extension = ".prefs";
/*  222 */     File[] totalFiles = dir.toFile().listFiles();
/*  223 */     if (totalFiles != null) {
/*  224 */       byte b; int i; File[] arrayOfFile; for (i = (arrayOfFile = totalFiles).length, b = 0; b < i; ) { File totalFile = arrayOfFile[b];
/*  225 */         String filename = totalFile.getName();
/*  226 */         if (filename.endsWith(extension) && totalFile.isFile()) {
/*  227 */           String shortName = filename.substring(0, filename.length() - extension.length());
/*  228 */           result.add(shortName);
/*      */         }  b++; }
/*      */     
/*      */     } 
/*  232 */     return result;
/*      */   }
/*      */   
/*      */   protected IPath computeLocation(IPath root, String qualifier) {
/*  236 */     return (root == null) ? null : root.append(".settings").append(qualifier).addFileExtension("prefs");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void convertFromProperties(EclipsePreferences node, Properties table, boolean notify) {
/*  244 */     String version = table.getProperty("eclipse.preferences.version");
/*  245 */     if (version != null) "1".equals(version);
/*      */ 
/*      */     
/*  248 */     table.remove("eclipse.preferences.version");
/*  249 */     for (Object propName : table.keySet()) {
/*  250 */       String fullKey = (String)propName;
/*  251 */       String value = table.getProperty(fullKey);
/*  252 */       if (value != null) {
/*  253 */         String[] splitPath = decodePath(fullKey);
/*  254 */         String path = splitPath[0];
/*  255 */         path = makeRelative(path);
/*  256 */         String key = splitPath[1];
/*  257 */         if (DEBUG_PREFERENCE_SET) {
/*  258 */           PrefsMessages.message("Setting preference: " + path + '/' + key + '=' + value);
/*      */         }
/*  260 */         EclipsePreferences childNode = (EclipsePreferences)node.internalNode(path, false, null);
/*  261 */         String oldValue = childNode.internalPut(key, value);
/*      */         
/*  263 */         if (notify && !value.equals(oldValue))
/*  264 */           childNode.firePreferenceEvent(key, oldValue, value); 
/*      */       } 
/*      */     } 
/*  267 */     PreferencesService.getDefault().shareStrings();
/*      */   }
/*      */   protected EclipsePreferences(EclipsePreferences parent, String name) {
/*  270 */     this.writeLock = new Object();
/*      */     this.parent = parent;
/*      */     this.name = name;
/*      */     this.cachedPath = null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void write(Properties props, IPath location) throws BackingStoreException {
/*  278 */     Path preferenceFile = location.toFile().toPath();
/*  279 */     Path parentFile = preferenceFile.getParent();
/*  280 */     if (parentFile == null) {
/*      */       return;
/*      */     }
/*      */     try {
/*  284 */       Files.createDirectories(parentFile, (FileAttribute<?>[])new FileAttribute[0]);
/*  285 */       String fileContent = removeTimestampFromTable(props);
/*  286 */       synchronized (this.writeLock) {
/*  287 */         if (Files.exists(preferenceFile, new java.nio.file.LinkOption[0])) {
/*      */ 
/*      */           
/*  290 */           Path tmp = preferenceFile.resolveSibling(preferenceFile.getFileName() + ".bak");
/*  291 */           Files.writeString(tmp, fileContent, StandardCharsets.UTF_8, new java.nio.file.OpenOption[0]);
/*  292 */           Files.move(tmp, preferenceFile, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*      */         } else {
/*  294 */           Files.writeString(preferenceFile, fileContent, StandardCharsets.UTF_8, new java.nio.file.OpenOption[0]);
/*      */         } 
/*      */       } 
/*  297 */     } catch (IOException e) {
/*  298 */       String message = NLS.bind(PrefsMessages.preferences_saveException, location);
/*  299 */       log((IStatus)new Status(4, "org.eclipse.equinox.preferences", 4, message, e));
/*  300 */       throw new BackingStoreException(message, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected static String removeTimestampFromTable(Properties properties) throws IOException {
/*  306 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  307 */     properties.store(output, (String)null);
/*  308 */     String string = output.toString(StandardCharsets.UTF_8);
/*  309 */     String separator = System.lineSeparator();
/*  310 */     return string.substring(string.indexOf(separator) + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Properties convertToProperties(Properties result, String prefix) throws BackingStoreException {
/*      */     ImmutableMap temp;
/*  319 */     boolean addSeparator = (prefix.length() != 0);
/*      */ 
/*      */     
/*  322 */     synchronized (this.childAndPropertyLock) {
/*  323 */       temp = this.properties;
/*      */     }  byte b; int i; String[] arrayOfString;
/*  325 */     for (i = (arrayOfString = temp.keys()).length, b = 0; b < i; ) { String key = arrayOfString[b];
/*  326 */       String value = temp.get(key);
/*  327 */       if (value != null)
/*  328 */         result.put(encodePath(prefix, key), value); 
/*      */       b++; }
/*      */     
/*  331 */     for (IEclipsePreferences childNode : getChildren(true)) {
/*  332 */       EclipsePreferences child = (EclipsePreferences)childNode;
/*  333 */       String fullPath = addSeparator ? (String.valueOf(prefix) + PATH_SEPARATOR + child.name()) : child.name();
/*  334 */       child.convertToProperties(result, fullPath);
/*      */     } 
/*  336 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IEclipsePreferences create(IEclipsePreferences nodeParent, String nodeName) {
/*  342 */     return create((EclipsePreferences)nodeParent, nodeName, null);
/*      */   }
/*      */   
/*      */   protected boolean isLoading() {
/*  346 */     return this.loading;
/*      */   }
/*      */   
/*      */   protected void setLoading(boolean isLoading) {
/*  350 */     this.loading = isLoading;
/*      */   }
/*      */   
/*      */   public IEclipsePreferences create(EclipsePreferences nodeParent, String nodeName, Object context) {
/*  354 */     EclipsePreferences result = internalCreate(nodeParent, nodeName, context);
/*  355 */     nodeParent.addChild(nodeName, result);
/*  356 */     IEclipsePreferences loadLevel = result.getLoadLevel();
/*      */ 
/*      */     
/*  359 */     if (loadLevel == null) {
/*  360 */       return result;
/*      */     }
/*      */     
/*  363 */     if (result != loadLevel) {
/*  364 */       return result;
/*      */     }
/*      */     
/*  367 */     if (isAlreadyLoaded(result) || result.isLoading())
/*  368 */       return result; 
/*      */     try {
/*  370 */       result.setLoading(true);
/*  371 */       result.load();
/*  372 */       result.loaded();
/*  373 */       result.flush();
/*  374 */     } catch (BackingStoreException e) {
/*  375 */       IPath location = result.getLocation();
/*  376 */       String message = NLS.bind(PrefsMessages.preferences_loadException, (location == null) ? "" : location.toString());
/*  377 */       Status status = new Status(4, "org.eclipse.equinox.preferences", 4, message, (Throwable)e);
/*  378 */       RuntimeLog.log((IStatus)status);
/*      */     } finally {
/*  380 */       result.setLoading(false);
/*      */     } 
/*  382 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws BackingStoreException {
/*  388 */     IEclipsePreferences toFlush = null;
/*  389 */     synchronized (this.childAndPropertyLock) {
/*  390 */       toFlush = internalFlush();
/*      */     } 
/*      */     
/*  393 */     if (toFlush != null)
/*  394 */       toFlush.flush(); 
/*  395 */     PreferencesService.getDefault().shareStrings();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IEclipsePreferences internalFlush() throws BackingStoreException {
/*  408 */     checkRemoved();
/*      */     
/*  410 */     IEclipsePreferences loadLevel = getLoadLevel();
/*      */ 
/*      */     
/*  413 */     if (loadLevel == null) {
/*  414 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = childrenNames()).length, b = 0; b < i; ) { String childrenName = arrayOfString[b];
/*  415 */         node(childrenName).flush(); b++; }
/*      */       
/*  417 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  421 */     if (this != loadLevel) {
/*  422 */       return loadLevel;
/*      */     }
/*      */ 
/*      */     
/*  426 */     if (!this.dirty) {
/*  427 */       return null;
/*      */     }
/*      */     
/*  430 */     this.dirty = false;
/*      */     try {
/*  432 */       save();
/*  433 */     } catch (BackingStoreException e) {
/*      */       
/*  435 */       this.dirty = true;
/*  436 */       throw e;
/*      */     } 
/*  438 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String get(String key, String defaultValue) {
/*  444 */     String value = internalGet(key);
/*  445 */     return (value == null) ? defaultValue : value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String key, boolean defaultValue) {
/*  451 */     String value = internalGet(key);
/*  452 */     return (value == null) ? defaultValue : "true".equalsIgnoreCase(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getByteArray(String key, byte[] defaultValue) {
/*  458 */     String value = internalGet(key);
/*  459 */     return (value == null) ? defaultValue : Base64.decode(value.getBytes());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean childExists(String childName) {
/*  467 */     synchronized (this.childAndPropertyLock) {
/*  468 */       if (this.children == null)
/*  469 */         return false; 
/*  470 */       return (this.children.get(childName) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IEclipsePreferences getChild(String key, Object context, boolean create) {
/*  479 */     synchronized (this.childAndPropertyLock) {
/*  480 */       if (this.children == null)
/*  481 */         return null; 
/*  482 */       Object value = this.children.get(key);
/*  483 */       if (value == null)
/*  484 */         return null; 
/*  485 */       if (value instanceof IEclipsePreferences) {
/*  486 */         return (IEclipsePreferences)value;
/*      */       }
/*      */       
/*  489 */       if (!create)
/*  490 */         return null; 
/*      */     } 
/*  492 */     return addChild(key, create(this, key, context));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<IEclipsePreferences> getChildren(boolean create) {
/*  499 */     List<IEclipsePreferences> result = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/*  500 */     for (i = (arrayOfString = internalChildNames()).length, b = 0; b < i; ) { String n = arrayOfString[b];
/*  501 */       IEclipsePreferences child = getChild(n, null, create);
/*  502 */       if (child != null)
/*  503 */         result.add(child); 
/*      */       b++; }
/*      */     
/*  506 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String key, double defaultValue) {
/*  512 */     String value = internalGet(key);
/*  513 */     double result = defaultValue;
/*  514 */     if (value != null) {
/*      */       try {
/*  516 */         result = Double.parseDouble(value);
/*  517 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     
/*  520 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String key, float defaultValue) {
/*  526 */     String value = internalGet(key);
/*  527 */     float result = defaultValue;
/*  528 */     if (value != null) {
/*      */       try {
/*  530 */         result = Float.parseFloat(value);
/*  531 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     
/*  534 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String key, int defaultValue) {
/*  540 */     String value = internalGet(key);
/*  541 */     int result = defaultValue;
/*  542 */     if (value != null) {
/*      */       try {
/*  544 */         result = Integer.parseInt(value);
/*  545 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     
/*  548 */     return result;
/*      */   }
/*      */   
/*      */   protected IEclipsePreferences getLoadLevel() {
/*  552 */     return (this.descriptor == null) ? null : this.descriptor.getLoadLevel(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IPath getLocation() {
/*  559 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String key, long defaultValue) {
/*  565 */     String value = internalGet(key);
/*  566 */     long result = defaultValue;
/*  567 */     if (value != null) {
/*      */       try {
/*  569 */         result = Long.parseLong(value);
/*  570 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     
/*  573 */     return result;
/*      */   }
/*      */   
/*      */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/*  577 */     EclipsePreferences result = new EclipsePreferences(nodeParent, nodeName);
/*  578 */     result.descriptor = this.descriptor;
/*  579 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String internalGet(String key) {
/*      */     String result;
/*  588 */     if (key == null) {
/*  589 */       throw new NullPointerException();
/*      */     }
/*  591 */     checkRemoved();
/*      */     
/*  593 */     synchronized (this.childAndPropertyLock) {
/*  594 */       result = this.properties.get(key);
/*      */     } 
/*  596 */     if (DEBUG_PREFERENCE_GET)
/*  597 */       PrefsMessages.message("Getting preference value: " + absolutePath() + '/' + key + "->" + result); 
/*  598 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IEclipsePreferences internalNode(String path, boolean notify, Object context) {
/*  607 */     checkRemoved();
/*      */ 
/*      */     
/*  610 */     if (path.length() == 0) {
/*  611 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  616 */     if (path.charAt(0) == '/') {
/*  617 */       return (IEclipsePreferences)calculateRoot().node(path.substring(1));
/*      */     }
/*  619 */     int index = path.indexOf('/');
/*  620 */     String key = (index == -1) ? path : path.substring(0, index);
/*  621 */     boolean added = false;
/*  622 */     IEclipsePreferences child = getChild(key, context, true);
/*  623 */     if (child == null) {
/*  624 */       child = create(this, key, context);
/*  625 */       added = true;
/*      */     } 
/*      */     
/*  628 */     if (added && notify)
/*  629 */       fireNodeEvent(new IEclipsePreferences.NodeChangeEvent((Preferences)this, (Preferences)child), true); 
/*  630 */     return (IEclipsePreferences)child.node((index == -1) ? "" : path.substring(index + 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String internalPut(String key, String newValue) {
/*  639 */     synchronized (this.childAndPropertyLock) {
/*      */       
/*  641 */       checkRemoved();
/*  642 */       String oldValue = this.properties.get(key);
/*  643 */       if (oldValue != null && oldValue.equals(newValue))
/*  644 */         return oldValue; 
/*  645 */       if (DEBUG_PREFERENCE_SET)
/*  646 */         PrefsMessages.message("Setting preference: " + absolutePath() + '/' + key + '=' + newValue); 
/*  647 */       this.properties = this.properties.put(key, newValue);
/*  648 */       return oldValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/*  656 */     return (this.descriptor == null) ? true : this.descriptor.isAlreadyLoaded(node.absolutePath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] keys() {
/*  663 */     synchronized (this.childAndPropertyLock) {
/*  664 */       checkRemoved();
/*  665 */       return this.properties.keys();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void load() throws BackingStoreException {
/*  677 */     if (this.descriptor == null) {
/*  678 */       load(getLocation());
/*      */     } else {
/*      */       
/*  681 */       Properties props = this.descriptor.load(absolutePath());
/*  682 */       if (props == null || props.isEmpty())
/*      */         return; 
/*  684 */       convertFromProperties(this, props, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static Properties loadProperties(IPath location) throws BackingStoreException {
/*  689 */     if (DEBUG_PREFERENCE_GENERAL)
/*  690 */       PrefsMessages.message("Loading preferences from file: " + location); 
/*  691 */     Properties result = new Properties(); try {
/*  692 */       Exception exception2, exception1 = null;
/*      */     }
/*  694 */     catch (FileNotFoundException fileNotFoundException) {
/*      */       
/*  696 */       if (DEBUG_PREFERENCE_GENERAL)
/*  697 */         PrefsMessages.message("Preference file does not exist: " + location); 
/*  698 */       return result;
/*  699 */     } catch (IOException|IllegalArgumentException e) {
/*  700 */       String message = NLS.bind(PrefsMessages.preferences_loadException, location);
/*  701 */       log((IStatus)new Status(1, "org.eclipse.equinox.preferences", 1, message, e));
/*  702 */       throw new BackingStoreException(message, e);
/*      */     } 
/*  704 */     return result;
/*      */   }
/*      */   
/*      */   private static InputStream getSaveInputStream(IPath location) throws IOException {
/*  708 */     File target = location.toFile().getAbsoluteFile();
/*  709 */     if (!target.exists()) {
/*  710 */       target = new File(target + ".bak");
/*      */     }
/*  712 */     return new FileInputStream(target);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void load(IPath location) throws BackingStoreException {
/*  717 */     if (location == null) {
/*  718 */       if (DEBUG_PREFERENCE_GENERAL)
/*  719 */         PrefsMessages.message("Unable to determine location of preference file for node: " + absolutePath()); 
/*      */       return;
/*      */     } 
/*  722 */     Properties fromDisk = loadProperties(location);
/*  723 */     convertFromProperties(this, fromDisk, false);
/*      */   }
/*      */   
/*      */   protected void loaded() {
/*  727 */     if (this.descriptor != null)
/*      */     {
/*      */       
/*  730 */       this.descriptor.loaded(absolutePath());
/*      */     }
/*      */   }
/*      */   
/*      */   public static void log(IStatus status) {
/*  735 */     RuntimeLog.log(status);
/*      */   }
/*      */   
/*      */   protected void makeDirty() {
/*  739 */     EclipsePreferences node = this;
/*  740 */     while (node != null && !node.removed) {
/*  741 */       node.dirty = true;
/*  742 */       node = (EclipsePreferences)node.parent();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isDirty() {
/*  747 */     return this.dirty;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String name() {
/*  753 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Preferences node(String pathName) {
/*  759 */     return (Preferences)internalNode(pathName, true, null);
/*      */   }
/*      */   
/*      */   protected void fireNodeEvent(final IEclipsePreferences.NodeChangeEvent event, final boolean added) {
/*  763 */     if (this.nodeChangeListeners == null)
/*      */       return; 
/*  765 */     for (IEclipsePreferences.INodeChangeListener listener : this.nodeChangeListeners) {
/*  766 */       ISafeRunnable job = new ISafeRunnable()
/*      */         {
/*      */           public void handleException(Throwable exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void run() throws Exception {
/*  774 */             if (added) {
/*  775 */               listener.added(event);
/*      */             } else {
/*  777 */               listener.removed(event);
/*      */             }  }
/*      */         };
/*  780 */       SafeRunner.run(job);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nodeExists(String path) throws BackingStoreException {
/*  788 */     if (path.length() == 0) {
/*  789 */       return !this.removed;
/*      */     }
/*      */ 
/*      */     
/*  793 */     checkRemoved();
/*      */ 
/*      */ 
/*      */     
/*  797 */     if (path.charAt(0) == '/') {
/*  798 */       return calculateRoot().nodeExists(path.substring(1));
/*      */     }
/*  800 */     int index = path.indexOf('/');
/*  801 */     boolean noSlash = (index == -1);
/*      */ 
/*      */     
/*  804 */     if (noSlash) {
/*  805 */       return childExists(path);
/*      */     }
/*      */     
/*  808 */     String childName = path.substring(0, index);
/*  809 */     if (!childExists(childName))
/*  810 */       return false; 
/*  811 */     IEclipsePreferences child = getChild(childName, null, true);
/*  812 */     if (child == null)
/*  813 */       return false; 
/*  814 */     return child.nodeExists(path.substring(index + 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Preferences parent() {
/*  821 */     checkRemoved();
/*  822 */     return (Preferences)this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firePreferenceEvent(String key, Object oldValue, Object newValue) {
/*  829 */     if (this.preferenceChangeListeners == null)
/*      */       return; 
/*  831 */     final IEclipsePreferences.PreferenceChangeEvent event = new IEclipsePreferences.PreferenceChangeEvent(this, key, oldValue, newValue);
/*  832 */     for (IEclipsePreferences.IPreferenceChangeListener listener : this.preferenceChangeListeners) {
/*  833 */       ISafeRunnable job = new ISafeRunnable()
/*      */         {
/*      */           public void handleException(Throwable exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void run() throws Exception {
/*  841 */             listener.preferenceChange(event);
/*      */           }
/*      */         };
/*  844 */       SafeRunner.run(job);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(String key, String newValue) {
/*  851 */     if (key == null || newValue == null)
/*  852 */       throw new NullPointerException(); 
/*  853 */     String oldValue = internalPut(key, newValue);
/*  854 */     if (!newValue.equals(oldValue)) {
/*  855 */       makeDirty();
/*  856 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putBoolean(String key, boolean value) {
/*  863 */     if (key == null)
/*  864 */       throw new NullPointerException(); 
/*  865 */     String newValue = value ? "true" : "false";
/*  866 */     String oldValue = internalPut(key, newValue);
/*  867 */     if (!newValue.equals(oldValue)) {
/*  868 */       makeDirty();
/*  869 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putByteArray(String key, byte[] value) {
/*  876 */     if (key == null || value == null)
/*  877 */       throw new NullPointerException(); 
/*  878 */     String newValue = new String(Base64.encode(value));
/*  879 */     String oldValue = internalPut(key, newValue);
/*  880 */     if (!newValue.equals(oldValue)) {
/*  881 */       makeDirty();
/*  882 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putDouble(String key, double value) {
/*  889 */     if (key == null)
/*  890 */       throw new NullPointerException(); 
/*  891 */     String newValue = Double.toString(value);
/*  892 */     String oldValue = internalPut(key, newValue);
/*  893 */     if (!newValue.equals(oldValue)) {
/*  894 */       makeDirty();
/*  895 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putFloat(String key, float value) {
/*  902 */     if (key == null)
/*  903 */       throw new NullPointerException(); 
/*  904 */     String newValue = Float.toString(value);
/*  905 */     String oldValue = internalPut(key, newValue);
/*  906 */     if (!newValue.equals(oldValue)) {
/*  907 */       makeDirty();
/*  908 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putInt(String key, int value) {
/*  915 */     if (key == null)
/*  916 */       throw new NullPointerException(); 
/*  917 */     String newValue = Integer.toString(value);
/*  918 */     String oldValue = internalPut(key, newValue);
/*  919 */     if (!newValue.equals(oldValue)) {
/*  920 */       makeDirty();
/*  921 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void putLong(String key, long value) {
/*  928 */     if (key == null)
/*  929 */       throw new NullPointerException(); 
/*  930 */     String newValue = Long.toString(value);
/*  931 */     String oldValue = internalPut(key, newValue);
/*  932 */     if (!newValue.equals(oldValue)) {
/*  933 */       makeDirty();
/*  934 */       firePreferenceEvent(key, oldValue, newValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove(String key) {
/*      */     String oldValue;
/*  942 */     synchronized (this.childAndPropertyLock) {
/*      */       
/*  944 */       checkRemoved();
/*  945 */       oldValue = this.properties.get(key);
/*  946 */       if (oldValue == null)
/*      */         return; 
/*  948 */       this.properties = this.properties.removeKey(key);
/*      */     } 
/*  950 */     makeDirty();
/*  951 */     firePreferenceEvent(key, oldValue, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNode() throws BackingStoreException {
/*  958 */     checkRemoved();
/*      */ 
/*      */     
/*  961 */     String[] keys = keys(); byte b; int i; String[] arrayOfString1;
/*  962 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  963 */       remove(key);
/*      */       
/*      */       b++; }
/*      */     
/*  967 */     if (this.parent != null && !(this.parent instanceof RootPreferences)) {
/*      */       
/*  969 */       this.removed = true;
/*  970 */       this.parent.removeNode(this);
/*      */     } 
/*  972 */     for (IEclipsePreferences childNode : getChildren(false)) {
/*      */       try {
/*  974 */         childNode.removeNode();
/*  975 */       } catch (IllegalStateException illegalStateException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeNode(IEclipsePreferences child) {
/*  987 */     if (removeNode(child.name()) != null) {
/*  988 */       fireNodeEvent(new IEclipsePreferences.NodeChangeEvent((Preferences)this, (Preferences)child), false);
/*  989 */       if (this.descriptor != null) {
/*  990 */         this.descriptor.removed(child.absolutePath());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object removeNode(String key) {
/*  998 */     synchronized (this.childAndPropertyLock) {
/*  999 */       if (this.children != null) {
/* 1000 */         Object result = this.children.remove(key);
/* 1001 */         if (result != null)
/* 1002 */           makeDirty(); 
/* 1003 */         if (this.children.isEmpty())
/* 1004 */           this.children = null; 
/* 1005 */         return result;
/*      */       } 
/*      */     } 
/* 1008 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNodeChangeListener(IEclipsePreferences.INodeChangeListener listener) {
/* 1014 */     checkRemoved();
/* 1015 */     if (this.nodeChangeListeners == null)
/*      */       return; 
/* 1017 */     this.nodeChangeListeners.remove(listener);
/* 1018 */     if (DEBUG_PREFERENCE_GENERAL) {
/* 1019 */       PrefsMessages.message("Removed preference node change listener: " + listener + " from: " + absolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePreferenceChangeListener(IEclipsePreferences.IPreferenceChangeListener listener) {
/* 1025 */     checkRemoved();
/* 1026 */     if (this.preferenceChangeListeners == null)
/*      */       return; 
/* 1028 */     this.preferenceChangeListeners.remove(listener);
/* 1029 */     if (DEBUG_PREFERENCE_GENERAL) {
/* 1030 */       PrefsMessages.message("Removed preference property change listener: " + listener + " from: " + absolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void save() throws BackingStoreException {
/* 1041 */     if (this.descriptor == null) {
/* 1042 */       save(getLocation());
/*      */     } else {
/* 1044 */       this.descriptor.save(absolutePath(), convertToProperties(new Properties(), ""));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void save(IPath location) throws BackingStoreException {
/* 1049 */     if (location == null) {
/* 1050 */       if (DEBUG_PREFERENCE_GENERAL)
/* 1051 */         PrefsMessages.message("Unable to determine location of preference file for node: " + absolutePath()); 
/*      */       return;
/*      */     } 
/* 1054 */     if (DEBUG_PREFERENCE_GENERAL)
/* 1055 */       PrefsMessages.message("Saving preferences to file: " + location); 
/* 1056 */     Properties table = convertToProperties(new SortedProperties(), "");
/* 1057 */     if (table.isEmpty()) {
/*      */       
/* 1059 */       if (location.toFile().exists() && !location.toFile().delete()) {
/* 1060 */         String message = NLS.bind(PrefsMessages.preferences_failedDelete, location);
/* 1061 */         log((IStatus)new Status(2, "org.eclipse.equinox.preferences", 2, message, null));
/*      */       } 
/*      */       return;
/*      */     } 
/* 1065 */     table.put("eclipse.preferences.version", "1");
/* 1066 */     write(table, location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shareStrings(StringPool pool) {
/*      */     ImmutableMap temp;
/* 1080 */     synchronized (this.childAndPropertyLock) {
/* 1081 */       temp = this.properties;
/*      */     } 
/* 1083 */     temp.shareStrings(pool);
/* 1084 */     for (IEclipsePreferences child : getChildren(false)) {
/* 1085 */       if (child instanceof EclipsePreferences) {
/* 1086 */         ((EclipsePreferences)child).shareStrings(pool);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodePath(String path, String key) {
/*      */     String result;
/* 1099 */     int pathLength = (path == null) ? 0 : path.length();
/* 1100 */     if (key.indexOf('/') == -1) {
/* 1101 */       if (pathLength == 0) {
/* 1102 */         result = key;
/*      */       } else {
/* 1104 */         result = String.valueOf(path) + '/' + key;
/*      */       } 
/* 1106 */     } else if (pathLength == 0) {
/* 1107 */       result = "//" + key;
/*      */     } else {
/* 1109 */       result = String.valueOf(path) + "//" + key;
/*      */     } 
/* 1111 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSegment(String path, int segment) {
/* 1119 */     int start = (path.indexOf('/') == 0) ? 1 : 0;
/* 1120 */     int end = path.indexOf('/', start);
/* 1121 */     if (end == path.length() - 1)
/* 1122 */       end = -1; 
/* 1123 */     for (int i = 0; i < segment; i++) {
/* 1124 */       if (end == -1)
/* 1125 */         return null; 
/* 1126 */       start = end + 1;
/* 1127 */       end = path.indexOf('/', start);
/*      */     } 
/* 1129 */     if (end == -1)
/* 1130 */       end = path.length(); 
/* 1131 */     return path.substring(start, end);
/*      */   }
/*      */   
/*      */   public static int getSegmentCount(String path) {
/* 1135 */     StringTokenizer tokenizer = new StringTokenizer(path, String.valueOf('/'));
/* 1136 */     return tokenizer.countTokens();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String makeRelative(String path) {
/* 1143 */     String result = path;
/* 1144 */     if (path == null)
/* 1145 */       return ""; 
/* 1146 */     if (path.length() > 0 && path.charAt(0) == '/')
/* 1147 */       result = path.substring(1); 
/* 1148 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] decodePath(String fullPath) {
/* 1159 */     String key = null;
/* 1160 */     String path = null;
/*      */ 
/*      */     
/* 1163 */     int index = fullPath.indexOf("//");
/* 1164 */     if (index == -1) {
/*      */ 
/*      */       
/* 1167 */       int lastIndex = fullPath.lastIndexOf('/');
/* 1168 */       if (lastIndex == -1) {
/* 1169 */         key = fullPath;
/*      */       } else {
/* 1171 */         path = fullPath.substring(0, lastIndex);
/* 1172 */         key = fullPath.substring(lastIndex + 1);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1177 */       path = fullPath.substring(0, index);
/* 1178 */       key = fullPath.substring(index + 2);
/*      */     } 
/*      */ 
/*      */     
/* 1182 */     if (path != null)
/* 1183 */       if (path.length() == 0) {
/* 1184 */         path = null;
/* 1185 */       } else if (path.charAt(0) == '/') {
/* 1186 */         path = path.substring(1);
/*      */       }  
/* 1188 */     return new String[] { path, key };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sync() throws BackingStoreException {
/* 1196 */     checkRemoved();
/* 1197 */     IEclipsePreferences node = getLoadLevel();
/* 1198 */     if (node == null) {
/* 1199 */       if (DEBUG_PREFERENCE_GENERAL)
/* 1200 */         PrefsMessages.message("Preference node is not a load root: " + absolutePath()); 
/*      */       return;
/*      */     } 
/* 1203 */     if (node instanceof EclipsePreferences) {
/* 1204 */       ((EclipsePreferences)node).load();
/* 1205 */       node.flush();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String toDeepDebugString() {
/* 1210 */     StringBuilder buffer = new StringBuilder();
/* 1211 */     IPreferenceNodeVisitor visitor = node -> {
/*      */         paramStringBuilder.append(node); paramStringBuilder.append('\n'); String[] keys = node.keys(); String[] arrayOfString1;
/*      */         int i = (arrayOfString1 = keys).length;
/*      */         for (byte b = 0; b < i; b++) {
/*      */           String key = arrayOfString1[b];
/*      */           paramStringBuilder.append(node.absolutePath());
/*      */           paramStringBuilder.append(PATH_SEPARATOR);
/*      */           paramStringBuilder.append(key);
/*      */           paramStringBuilder.append('=');
/*      */           paramStringBuilder.append(node.get(key, "*default*"));
/*      */           paramStringBuilder.append('\n');
/*      */         } 
/*      */         return true;
/*      */       };
/*      */     try {
/* 1226 */       accept(visitor);
/* 1227 */     } catch (BackingStoreException e) {
/* 1228 */       System.out.println("Exception while calling #toDeepDebugString()");
/* 1229 */       e.printStackTrace();
/*      */     } 
/* 1231 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1236 */     return absolutePath();
/*      */   }
/*      */   
/*      */   void setDescriptor(ScopeDescriptor descriptor) {
/* 1240 */     this.descriptor = descriptor;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\EclipsePreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */