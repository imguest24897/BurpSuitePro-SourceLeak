/*     */ package org.eclipse.core.runtime.preferences;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.preferences.PrefsMessages;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OsgiPreferenceMetadataStore
/*     */   implements IPreferenceMetadataStore
/*     */ {
/*  30 */   private static final Set<Class<?>> CLASSES = Collections.unmodifiableSet(
/*  31 */       new HashSet<>(Arrays.asList(new Class[] {
/*  32 */             Boolean.class, 
/*  33 */             byte[].class, 
/*  34 */             Double.class, 
/*  35 */             Float.class, 
/*  36 */             Integer.class, 
/*  37 */             Long.class, 
/*  38 */             String.class
/*     */           })));
/*     */ 
/*     */   
/*     */   private final IEclipsePreferences preferences;
/*     */ 
/*     */ 
/*     */   
/*     */   public OsgiPreferenceMetadataStore(IEclipsePreferences preferences) {
/*  47 */     Objects.requireNonNull(preferences, PrefsMessages.OsgiPreferenceMetadataStore_e_null_preference_node);
/*  48 */     this.preferences = preferences;
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> boolean handles(Class<V> valueType) {
/*  53 */     return CLASSES.contains(valueType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> V load(PreferenceMetadata<V> preference) {
/*  58 */     Class<V> valueClass = preference.valueClass();
/*  59 */     String identifer = preference.identifer();
/*  60 */     V defaultValue = preference.defaultValue();
/*  61 */     if (String.class.equals(valueClass))
/*  62 */       return valueClass.cast(this.preferences.get(identifer, String.class.cast(defaultValue))); 
/*  63 */     if (Boolean.class.equals(valueClass))
/*  64 */       return valueClass.cast(Boolean.valueOf(this.preferences.getBoolean(identifer, ((Boolean)Boolean.class.cast(defaultValue)).booleanValue()))); 
/*  65 */     if (byte[].class.equals(valueClass))
/*  66 */       return valueClass.cast(this.preferences.getByteArray(identifer, byte[].class.cast(defaultValue))); 
/*  67 */     if (Double.class.equals(valueClass))
/*  68 */       return valueClass.cast(Double.valueOf(this.preferences.getDouble(identifer, ((Double)Double.class.cast(defaultValue)).doubleValue()))); 
/*  69 */     if (Float.class.equals(valueClass))
/*  70 */       return valueClass.cast(Float.valueOf(this.preferences.getFloat(identifer, ((Float)Float.class.cast(defaultValue)).floatValue()))); 
/*  71 */     if (Integer.class.equals(valueClass))
/*  72 */       return valueClass.cast(Integer.valueOf(this.preferences.getInt(identifer, ((Integer)Integer.class.cast(defaultValue)).intValue()))); 
/*  73 */     if (Long.class.equals(valueClass)) {
/*  74 */       return valueClass.cast(Long.valueOf(this.preferences.getLong(identifer, ((Long)Long.class.cast(defaultValue)).longValue())));
/*     */     }
/*  76 */     String message = PrefsMessages.PreferenceStorage_e_load_unsupported;
/*  77 */     throw new UnsupportedOperationException(NLS.bind(message, preference, valueClass));
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> void save(V value, PreferenceMetadata<V> preference) {
/*  82 */     Class<V> valueClass = preference.valueClass();
/*  83 */     String identifer = preference.identifer();
/*  84 */     if (String.class.equals(valueClass)) {
/*  85 */       this.preferences.put(identifer, String.class.cast(value));
/*  86 */     } else if (Boolean.class.equals(valueClass)) {
/*  87 */       this.preferences.putBoolean(identifer, ((Boolean)Boolean.class.cast(value)).booleanValue());
/*  88 */     } else if (byte[].class.equals(valueClass)) {
/*  89 */       this.preferences.putByteArray(identifer, byte[].class.cast(value));
/*  90 */     } else if (Double.class.equals(valueClass)) {
/*  91 */       this.preferences.putDouble(identifer, ((Double)Double.class.cast(value)).doubleValue());
/*  92 */     } else if (Float.class.equals(valueClass)) {
/*  93 */       this.preferences.putFloat(identifer, ((Float)Float.class.cast(value)).floatValue());
/*  94 */     } else if (Integer.class.equals(valueClass)) {
/*  95 */       this.preferences.putInt(identifer, ((Integer)Integer.class.cast(value)).intValue());
/*  96 */     } else if (Long.class.equals(valueClass)) {
/*  97 */       this.preferences.putLong(identifer, ((Long)Long.class.cast(value)).longValue());
/*     */     } else {
/*  99 */       String message = PrefsMessages.PreferenceStorage_e_save_unsupported;
/* 100 */       throw new UnsupportedOperationException(NLS.bind(message, preference, valueClass));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\OsgiPreferenceMetadataStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */