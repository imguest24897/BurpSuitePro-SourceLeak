/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.runtime.MetaDataKeeper;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstancePreferences
/*     */   extends EclipsePreferences
/*     */ {
/*     */   private String qualifier;
/*     */   private int segmentCount;
/*     */   private IEclipsePreferences loadLevel;
/*     */   private IPath location;
/*  33 */   private static Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */ 
/*     */   
/*     */   private static boolean initialized = false;
/*     */   
/*     */   private static IPath baseLocation;
/*     */ 
/*     */   
/*     */   static IPath getBaseLocation() {
/*  42 */     if (baseLocation == null) {
/*  43 */       Location instanceLocation = PreferencesOSGiUtils.getDefault().getInstanceLocation();
/*  44 */       if (instanceLocation != null && (instanceLocation.isSet() || instanceLocation.allowsDefault()))
/*  45 */         baseLocation = MetaDataKeeper.getMetaArea().getStateLocation("org.eclipse.core.runtime"); 
/*     */     } 
/*  47 */     return baseLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstancePreferences() {
/*  54 */     this((EclipsePreferences)null, (String)null);
/*     */   }
/*     */   
/*     */   private InstancePreferences(EclipsePreferences parent, String name) {
/*  58 */     super(parent, name);
/*     */     
/*  60 */     initializeChildren();
/*     */ 
/*     */     
/*  63 */     String path = absolutePath();
/*  64 */     this.segmentCount = getSegmentCount(path);
/*  65 */     if (this.segmentCount < 2) {
/*     */       return;
/*     */     }
/*     */     
/*  69 */     this.qualifier = getSegment(path, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/*  77 */     return loadedNodes.contains(node.name());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void loaded() {
/*  82 */     loadedNodes.add(name());
/*     */   }
/*     */ 
/*     */   
/*     */   protected IPath getLocation() {
/*  87 */     if (this.location == null)
/*  88 */       this.location = computeLocation(getBaseLocation(), this.qualifier); 
/*  89 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IEclipsePreferences getLoadLevel() {
/*  97 */     if (this.loadLevel == null) {
/*  98 */       if (this.qualifier == null) {
/*  99 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 103 */       IEclipsePreferences node = this;
/* 104 */       for (int i = 2; i < this.segmentCount; i++)
/* 105 */         node = (IEclipsePreferences)node.parent(); 
/* 106 */       this.loadLevel = node;
/*     */     } 
/* 108 */     return this.loadLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeChildren() {
/* 116 */     if (initialized || this.parent == null)
/*     */       return; 
/*     */     try {
/* 119 */       synchronized (this) {
/* 120 */         for (String n : computeChildren(getBaseLocation())) {
/* 121 */           addChild(n, null);
/*     */         }
/*     */       } 
/*     */     } finally {
/* 125 */       initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/* 131 */     return new InstancePreferences(nodeParent, nodeName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\InstancePreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */