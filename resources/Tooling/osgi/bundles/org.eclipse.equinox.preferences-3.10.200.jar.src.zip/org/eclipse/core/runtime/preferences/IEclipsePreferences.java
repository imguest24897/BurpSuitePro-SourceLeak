/*     */ package org.eclipse.core.runtime.preferences;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IEclipsePreferences
/*     */   extends Preferences
/*     */ {
/*     */   void addNodeChangeListener(INodeChangeListener paramINodeChangeListener);
/*     */   
/*     */   void removeNodeChangeListener(INodeChangeListener paramINodeChangeListener);
/*     */   
/*     */   void addPreferenceChangeListener(IPreferenceChangeListener paramIPreferenceChangeListener);
/*     */   
/*     */   void removePreferenceChangeListener(IPreferenceChangeListener paramIPreferenceChangeListener);
/*     */   
/*     */   void removeNode() throws BackingStoreException;
/*     */   
/*     */   Preferences node(String paramString);
/*     */   
/*     */   void accept(IPreferenceNodeVisitor paramIPreferenceNodeVisitor) throws BackingStoreException;
/*     */   
/*     */   public static interface INodeChangeListener
/*     */   {
/*     */     void added(IEclipsePreferences.NodeChangeEvent param1NodeChangeEvent);
/*     */     
/*     */     void removed(IEclipsePreferences.NodeChangeEvent param1NodeChangeEvent);
/*     */   }
/*     */   
/*     */   public static interface IPreferenceChangeListener
/*     */   {
/*     */     void preferenceChange(IEclipsePreferences.PreferenceChangeEvent param1PreferenceChangeEvent);
/*     */   }
/*     */   
/*     */   public static final class NodeChangeEvent
/*     */     extends EventObject
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private Preferences child;
/*     */     
/*     */     public NodeChangeEvent(Preferences parent, Preferences child) {
/*  56 */       super(parent);
/*  57 */       this.child = child;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Preferences getParent() {
/*  67 */       return (Preferences)getSource();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Preferences getChild() {
/*  81 */       return this.child;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class PreferenceChangeEvent
/*     */     extends EventObject
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object newValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object oldValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PreferenceChangeEvent(Object node, String key, Object oldValue, Object newValue) {
/* 148 */       super(node);
/* 149 */       if (key == null || !(node instanceof Preferences))
/* 150 */         throw new IllegalArgumentException(); 
/* 151 */       this.key = key;
/* 152 */       this.newValue = newValue;
/* 153 */       this.oldValue = oldValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Preferences getNode() {
/* 163 */       return (Preferences)this.source;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 173 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getNewValue() {
/* 184 */       return this.newValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getOldValue() {
/* 195 */       return this.oldValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\IEclipsePreferences.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */