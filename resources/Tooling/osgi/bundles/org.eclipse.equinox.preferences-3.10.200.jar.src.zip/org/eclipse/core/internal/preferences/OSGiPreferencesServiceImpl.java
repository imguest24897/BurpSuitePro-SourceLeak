/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ import org.osgi.service.prefs.PreferencesService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSGiPreferencesServiceImpl
/*     */   implements PreferencesService
/*     */ {
/*     */   private IEclipsePreferences bundlePreferences;
/*     */   
/*     */   private static final class OSGiLocalRootPreferences
/*     */     implements Preferences
/*     */   {
/*     */     private Preferences root;
/*     */     private Preferences wrapped;
/*     */     
/*     */     private OSGiLocalRootPreferences(Preferences root) {
/*  47 */       this(root, root);
/*     */     }
/*     */     
/*     */     private OSGiLocalRootPreferences(Preferences wrapped, Preferences root) {
/*  51 */       this.root = root;
/*  52 */       this.wrapped = wrapped;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String fixPath(String pathName) {
/*  60 */       if (pathName.startsWith("/")) {
/*  61 */         if (pathName.equals("/")) {
/*  62 */           return this.root.absolutePath();
/*     */         }
/*     */         
/*  65 */         return this.root.absolutePath().concat(pathName);
/*     */       } 
/*     */       
/*  68 */       return pathName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Preferences node(String pathName) {
/*  78 */       pathName = fixPath(pathName);
/*     */       
/*  80 */       if ((pathName.length() > 1 && pathName.endsWith("/")) || 
/*  81 */         pathName.indexOf("//") != -1) {
/*  82 */         throw new IllegalArgumentException();
/*     */       }
/*  84 */       return new OSGiLocalRootPreferences(this.wrapped.node(pathName), this.root);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] getByteArray(String key, byte[] defaultValue) {
/* 101 */       String value = this.wrapped.get(key, null);
/* 102 */       byte[] byteArray = null;
/* 103 */       if (value != null) {
/* 104 */         byte[] encodedBytes = value.getBytes();
/* 105 */         if (encodedBytes.length % 4 == 0) {
/*     */           try {
/* 107 */             byteArray = Base64.decode(encodedBytes);
/* 108 */           } catch (Exception exception) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 113 */       return (byteArray == null) ? defaultValue : byteArray;
/*     */     }
/*     */ 
/*     */     
/*     */     public Preferences parent() {
/* 118 */       if (this.wrapped == this.root) {
/*     */         try {
/* 120 */           if (!this.wrapped.nodeExists("")) {
/* 121 */             throw new IllegalStateException();
/*     */           }
/* 123 */         } catch (BackingStoreException backingStoreException) {}
/*     */ 
/*     */         
/* 126 */         return null;
/*     */       } 
/* 128 */       return new OSGiLocalRootPreferences(this.wrapped.parent(), this.root);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean nodeExists(String pathName) throws BackingStoreException {
/* 133 */       return this.wrapped.nodeExists(fixPath(pathName));
/*     */     }
/*     */ 
/*     */     
/*     */     public String absolutePath() {
/* 138 */       if (this.wrapped == this.root) {
/* 139 */         return "/";
/*     */       }
/* 141 */       return this.wrapped.absolutePath().substring(this.root.absolutePath().length(), this.wrapped.absolutePath().length());
/*     */     }
/*     */ 
/*     */     
/*     */     public String name() {
/* 146 */       if (this.wrapped == this.root) {
/* 147 */         return "";
/*     */       }
/* 149 */       return this.wrapped.name();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void put(String key, String value) {
/* 155 */       this.wrapped.put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String get(String key, String def) {
/* 160 */       return this.wrapped.get(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove(String key) {
/* 165 */       this.wrapped.remove(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() throws BackingStoreException {
/* 170 */       this.wrapped.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public void putInt(String key, int value) {
/* 175 */       this.wrapped.putInt(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getInt(String key, int def) {
/* 180 */       return this.wrapped.getInt(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putLong(String key, long value) {
/* 185 */       this.wrapped.putLong(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLong(String key, long def) {
/* 190 */       return this.wrapped.getLong(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putBoolean(String key, boolean value) {
/* 195 */       this.wrapped.putBoolean(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getBoolean(String key, boolean def) {
/* 200 */       return this.wrapped.getBoolean(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putFloat(String key, float value) {
/* 205 */       this.wrapped.putFloat(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public float getFloat(String key, float def) {
/* 210 */       return this.wrapped.getFloat(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putDouble(String key, double value) {
/* 215 */       this.wrapped.putDouble(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public double getDouble(String key, double def) {
/* 220 */       return this.wrapped.getDouble(key, def);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putByteArray(String key, byte[] value) {
/* 225 */       this.wrapped.putByteArray(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] keys() throws BackingStoreException {
/* 230 */       return this.wrapped.keys();
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] childrenNames() throws BackingStoreException {
/* 235 */       return this.wrapped.childrenNames();
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeNode() throws BackingStoreException {
/* 240 */       this.wrapped.removeNode();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws BackingStoreException {
/* 245 */       this.wrapped.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     public void sync() throws BackingStoreException {
/* 250 */       this.wrapped.sync();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OSGiPreferencesServiceImpl(IEclipsePreferences bundlePreferences) {
/* 258 */     this.bundlePreferences = bundlePreferences;
/*     */   }
/*     */ 
/*     */   
/*     */   public Preferences getSystemPreferences() {
/* 263 */     return new OSGiLocalRootPreferences(this.bundlePreferences.node("system"));
/*     */   }
/*     */ 
/*     */   
/*     */   public Preferences getUserPreferences(String name) {
/* 268 */     return new OSGiLocalRootPreferences(this.bundlePreferences.node("user/" + name));
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getUsers() {
/* 273 */     String[] users = null;
/*     */     try {
/* 275 */       users = this.bundlePreferences.node("user").childrenNames();
/* 276 */     } catch (BackingStoreException backingStoreException) {}
/*     */ 
/*     */     
/* 279 */     return (users == null) ? new String[0] : users;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\OSGiPreferencesServiceImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */