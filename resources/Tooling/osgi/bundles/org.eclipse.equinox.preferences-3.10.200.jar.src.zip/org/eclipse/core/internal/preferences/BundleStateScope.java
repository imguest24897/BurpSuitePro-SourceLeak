/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import org.eclipse.core.internal.runtime.MetaDataKeeper;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleStateScope
/*    */   implements IScopeContext
/*    */ {
/*    */   private IPath bundleLocation;
/*    */   private final Bundle usingBundle;
/*    */   
/*    */   public BundleStateScope(Bundle usingBundle) {
/* 42 */     this.usingBundle = usingBundle;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 47 */     return String.valueOf(InstanceScope.INSTANCE.getName()) + "/" + this.usingBundle.getSymbolicName();
/*    */   }
/*    */ 
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 52 */     return (IEclipsePreferences)InstanceScope.INSTANCE.getNode(this.usingBundle.getSymbolicName()).node(qualifier);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized IPath getLocation() {
/* 57 */     if (this.bundleLocation == null) {
/* 58 */       this.bundleLocation = MetaDataKeeper.getMetaArea().getStateLocation(this.usingBundle);
/* 59 */       this.bundleLocation.toFile().mkdirs();
/*    */     } 
/* 61 */     return this.bundleLocation;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\BundleStateScope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */