package org.eclipse.core.runtime.preferences;

public abstract class AbstractPreferenceInitializer {
  public abstract void initializeDefaultPreferences();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\AbstractPreferenceInitializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */