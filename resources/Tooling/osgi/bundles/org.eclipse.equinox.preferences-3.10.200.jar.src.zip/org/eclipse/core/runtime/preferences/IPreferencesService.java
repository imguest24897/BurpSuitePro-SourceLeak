package org.eclipse.core.runtime.preferences;

import java.io.InputStream;
import java.io.OutputStream;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.osgi.service.prefs.Preferences;

public interface IPreferencesService {
  String get(String paramString1, String paramString2, Preferences[] paramArrayOfPreferences);
  
  boolean getBoolean(String paramString1, String paramString2, boolean paramBoolean, IScopeContext[] paramArrayOfIScopeContext);
  
  byte[] getByteArray(String paramString1, String paramString2, byte[] paramArrayOfbyte, IScopeContext[] paramArrayOfIScopeContext);
  
  double getDouble(String paramString1, String paramString2, double paramDouble, IScopeContext[] paramArrayOfIScopeContext);
  
  float getFloat(String paramString1, String paramString2, float paramFloat, IScopeContext[] paramArrayOfIScopeContext);
  
  int getInt(String paramString1, String paramString2, int paramInt, IScopeContext[] paramArrayOfIScopeContext);
  
  long getLong(String paramString1, String paramString2, long paramLong, IScopeContext[] paramArrayOfIScopeContext);
  
  String getString(String paramString1, String paramString2, String paramString3, IScopeContext[] paramArrayOfIScopeContext);
  
  IEclipsePreferences getRootNode();
  
  IStatus exportPreferences(IEclipsePreferences paramIEclipsePreferences, OutputStream paramOutputStream, String[] paramArrayOfString) throws CoreException;
  
  IStatus importPreferences(InputStream paramInputStream) throws CoreException;
  
  IStatus applyPreferences(IExportedPreferences paramIExportedPreferences) throws CoreException;
  
  IExportedPreferences readPreferences(InputStream paramInputStream) throws CoreException;
  
  String[] getDefaultLookupOrder(String paramString1, String paramString2);
  
  String[] getLookupOrder(String paramString1, String paramString2);
  
  void setDefaultLookupOrder(String paramString1, String paramString2, String[] paramArrayOfString);
  
  void exportPreferences(IEclipsePreferences paramIEclipsePreferences, IPreferenceFilter[] paramArrayOfIPreferenceFilter, OutputStream paramOutputStream) throws CoreException;
  
  IPreferenceFilter[] matches(IEclipsePreferences paramIEclipsePreferences, IPreferenceFilter[] paramArrayOfIPreferenceFilter) throws CoreException;
  
  void applyPreferences(IEclipsePreferences paramIEclipsePreferences, IPreferenceFilter[] paramArrayOfIPreferenceFilter) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\IPreferencesService.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */