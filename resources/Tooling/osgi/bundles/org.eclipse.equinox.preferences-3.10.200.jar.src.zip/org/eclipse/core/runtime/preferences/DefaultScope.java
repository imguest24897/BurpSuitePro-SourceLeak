/*    */ package org.eclipse.core.runtime.preferences;
/*    */ 
/*    */ import org.eclipse.core.internal.preferences.AbstractScope;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultScope
/*    */   extends AbstractScope
/*    */ {
/*    */   public static final String SCOPE = "default";
/* 58 */   public static final IScopeContext INSTANCE = (IScopeContext)new DefaultScope();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 71 */     return "default";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 77 */     return super.getNode(qualifier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPath getLocation() {
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\runtime\preferences\DefaultScope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */