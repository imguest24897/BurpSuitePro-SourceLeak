/*    */ package org.eclipse.core.internal.preferences;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringPool
/*    */ {
/*    */   private int savings;
/* 33 */   private final HashMap<String, String> map = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String add(String string) {
/* 42 */     if (string == null)
/* 43 */       return string; 
/* 44 */     Object result = this.map.get(string);
/* 45 */     if (result != null) {
/* 46 */       if (result != string)
/* 47 */         this.savings += 44 + 2 * string.length(); 
/* 48 */       return (String)result;
/*    */     } 
/* 50 */     this.map.put(string, string);
/* 51 */     return string;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSavedStringCount() {
/* 69 */     return this.savings;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\StringPool.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */