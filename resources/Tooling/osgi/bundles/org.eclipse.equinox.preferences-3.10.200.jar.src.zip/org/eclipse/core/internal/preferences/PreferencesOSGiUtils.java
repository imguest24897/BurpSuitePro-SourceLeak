/*     */ package org.eclipse.core.internal.preferences;
/*     */ 
/*     */ import org.eclipse.core.internal.preferences.exchange.ILegacyPreferences;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreferencesOSGiUtils
/*     */ {
/*     */   private ServiceTracker<?, ILegacyPreferences> initTracker;
/*     */   private ServiceTracker<?, DebugOptions> debugTracker;
/*     */   private ServiceTracker<?, PackageAdmin> bundleTracker;
/*     */   private ServiceTracker<?, ?> configurationLocationTracker;
/*     */   private ServiceTracker<?, ?> instanceLocationTracker;
/*  36 */   private static final PreferencesOSGiUtils singleton = new PreferencesOSGiUtils();
/*     */   
/*     */   public static PreferencesOSGiUtils getDefault() {
/*  39 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void openServices() {
/*  50 */     BundleContext context = Activator.getContext();
/*  51 */     if (context == null) {
/*  52 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL) {
/*  53 */         PrefsMessages.message("PreferencesOSGiUtils called before plugin started");
/*     */       }
/*     */       return;
/*     */     } 
/*  57 */     this.initTracker = new ServiceTracker(context, ILegacyPreferences.class, null);
/*  58 */     this.initTracker.open(true);
/*     */     
/*  60 */     this.debugTracker = new ServiceTracker(context, DebugOptions.class, null);
/*  61 */     this.debugTracker.open();
/*     */     
/*  63 */     this.bundleTracker = new ServiceTracker(context, PackageAdmin.class, null);
/*  64 */     this.bundleTracker.open();
/*     */ 
/*     */ 
/*     */     
/*  68 */     Filter filter = null;
/*     */     try {
/*  70 */       filter = context.createFilter(Location.CONFIGURATION_FILTER);
/*  71 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/*  74 */     this.configurationLocationTracker = new ServiceTracker(context, filter, null);
/*  75 */     this.configurationLocationTracker.open();
/*     */     
/*     */     try {
/*  78 */       filter = context.createFilter(Location.INSTANCE_FILTER);
/*  79 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/*  82 */     this.instanceLocationTracker = new ServiceTracker(context, filter, null);
/*  83 */     this.instanceLocationTracker.open();
/*     */   }
/*     */   
/*     */   void closeServices() {
/*  87 */     if (this.initTracker != null) {
/*  88 */       this.initTracker.close();
/*  89 */       this.initTracker = null;
/*     */     } 
/*  91 */     if (this.debugTracker != null) {
/*  92 */       this.debugTracker.close();
/*  93 */       this.debugTracker = null;
/*     */     } 
/*  95 */     if (this.bundleTracker != null) {
/*  96 */       this.bundleTracker.close();
/*  97 */       this.bundleTracker = null;
/*     */     } 
/*  99 */     if (this.configurationLocationTracker != null) {
/* 100 */       this.configurationLocationTracker.close();
/* 101 */       this.configurationLocationTracker = null;
/*     */     } 
/* 103 */     if (this.instanceLocationTracker != null) {
/* 104 */       this.instanceLocationTracker.close();
/* 105 */       this.instanceLocationTracker = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ILegacyPreferences getLegacyPreferences() {
/* 110 */     if (this.initTracker != null)
/* 111 */       return (ILegacyPreferences)this.initTracker.getService(); 
/* 112 */     if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 113 */       PrefsMessages.message("Legacy preference tracker is not set"); 
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   public boolean getBooleanDebugOption(String option, boolean defaultValue) {
/* 118 */     if (this.debugTracker == null) {
/* 119 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 120 */         PrefsMessages.message("Debug tracker is not set"); 
/* 121 */       return defaultValue;
/*     */     } 
/* 123 */     DebugOptions options = (DebugOptions)this.debugTracker.getService();
/* 124 */     if (options != null) {
/* 125 */       String value = options.getOption(option);
/* 126 */       if (value != null)
/* 127 */         return value.equalsIgnoreCase("true"); 
/*     */     } 
/* 129 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public Bundle getBundle(String bundleName) {
/* 133 */     if (this.bundleTracker == null) {
/* 134 */       if (EclipsePreferences.DEBUG_PREFERENCE_GENERAL)
/* 135 */         PrefsMessages.message("Bundle tracker is not set"); 
/* 136 */       return null;
/*     */     } 
/* 138 */     PackageAdmin packageAdmin = (PackageAdmin)this.bundleTracker.getService();
/* 139 */     if (packageAdmin == null)
/* 140 */       return null; 
/* 141 */     Bundle[] bundles = packageAdmin.getBundles(bundleName, null);
/* 142 */     if (bundles == null)
/* 143 */       return null;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 145 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 146 */       if ((bundle.getState() & 0x3) == 0)
/* 147 */         return bundle; 
/*     */       b++; }
/*     */     
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   public Location getConfigurationLocation() {
/* 154 */     if (this.configurationLocationTracker != null)
/* 155 */       return (Location)this.configurationLocationTracker.getService(); 
/* 156 */     return null;
/*     */   }
/*     */   
/*     */   public Location getInstanceLocation() {
/* 160 */     if (this.instanceLocationTracker != null)
/* 161 */       return (Location)this.instanceLocationTracker.getService(); 
/* 162 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.preferences-3.10.200.jar!\org\eclipse\core\internal\preferences\PreferencesOSGiUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */