/*    */ package org.eclipse.jdt.internal.launching.macosx;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*    */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*    */ import org.eclipse.jdt.internal.launching.StandardVMType;
/*    */ import org.eclipse.jdt.launching.AbstractVMInstall;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.IVMInstallType;
/*    */ import org.eclipse.jdt.launching.IVMRunner;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOSXVMInstall
/*    */   extends AbstractVMInstall
/*    */ {
/*    */   MacOSXVMInstall(IVMInstallType type, String id) {
/* 30 */     super(type, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public IVMRunner getVMRunner(String mode) {
/* 35 */     if ("run".equals(mode)) {
/* 36 */       return (IVMRunner)new MacOSXVMRunner((IVMInstall)this);
/*    */     }
/*    */     
/* 39 */     if ("debug".equals(mode)) {
/* 40 */       return (IVMRunner)new MacOSXDebugVMRunner((IVMInstall)this);
/*    */     }
/*    */     
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getJavaVersion() {
/* 48 */     File installLocation = getInstallLocation();
/* 49 */     if (installLocation != null) {
/* 50 */       File executable = StandardVMType.findJavaExecutable(installLocation);
/* 51 */       if (executable != null) {
/* 52 */         MacOSXVMInstallType installType = (MacOSXVMInstallType)getVMInstallType();
/* 53 */         String vmVersion = installType.getVMVersion(installLocation, executable);
/*    */         
/* 55 */         StringBuilder version = new StringBuilder();
/* 56 */         for (int i = 0; i < vmVersion.length(); ) {
/* 57 */           char ch = vmVersion.charAt(i);
/* 58 */           if (Character.isDigit(ch) || ch == '.') {
/* 59 */             version.append(ch);
/*    */             i++;
/*    */           } 
/*    */           break;
/*    */         } 
/* 64 */         if (version.length() > 0) {
/* 65 */           return version.toString();
/*    */         }
/*    */       } 
/* 68 */       LaunchingPlugin.log(NLS.bind(LaunchingMessages.vmInstall_could_not_determine_java_Version, installLocation.getAbsolutePath()));
/*    */     } 
/* 70 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching.macosx-3.6.0.jar!\org\eclipse\jdt\internal\launching\macosx\MacOSXVMInstall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */