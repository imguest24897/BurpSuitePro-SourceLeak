/*    */ package org.eclipse.jdt.internal.launching.macosx;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.jdt.internal.launching.macosx.messages";
/*    */   public static String MacOSXVMInstallType_0;
/*    */   public static String MacOSXVMInstallType_1;
/*    */   public static String MacOSXVMInstallType_2;
/*    */   public static String MacOSXVMInstallType_jre;
/*    */   public static String MacOSXVMInstallType_jre_version;
/*    */   
/*    */   static {
/* 27 */     NLS.initializeMessages("org.eclipse.jdt.internal.launching.macosx.messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching.macosx-3.6.0.jar!\org\eclipse\jdt\internal\launching\macosx\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */