/*     */ package org.eclipse.jdt.internal.launching.macosx;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.internal.launching.LibraryInfo;
/*     */ import org.eclipse.jdt.internal.launching.MacInstalledJREs;
/*     */ import org.eclipse.jdt.internal.launching.StandardVMType;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.VMStandin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MacOSXVMInstallType
/*     */   extends StandardVMType
/*     */ {
/*     */   private static final String JVM_VERSION_LOC = "/System/Library/Frameworks/JavaVM.framework/Versions/";
/*  85 */   private static final File JVM_VERSIONS_FOLDER = new File("/System/Library/Frameworks/JavaVM.framework/Versions/");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CURRENT_JDK = "CurrentJDK";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String JVM_HOME = "Home";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String JAVADOC_LOC = "/Developer/Documentation/Java/Reference/";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String JAVADOC_SUBDIR = "/doc/api";
/*     */ 
/*     */ 
/*     */   
/*     */   static final String SRC_ZIP = "src.zip";
/*     */ 
/*     */ 
/*     */   
/*     */   static final String SRC_JAR = "src.jar";
/*     */ 
/*     */ 
/*     */   
/*     */   static final String SRC_NAME = "src";
/*     */ 
/*     */   
/*     */   static final String JVM_CONTENTS = "Contents";
/*     */ 
/*     */   
/*     */   static final String JVM_CLASSES = "Classes";
/*     */ 
/*     */   
/*     */   static final String JVM_VERSIONS = "Versions";
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 127 */     return Messages.MacOSXVMInstallType_0;
/*     */   }
/*     */ 
/*     */   
/*     */   public IVMInstall doCreateVMInstall(String id) {
/* 132 */     return (IVMInstall)new MacOSXVMInstall((IVMInstallType)this, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File detectInstallLocation() {
/*     */     try {
/* 143 */       File defaultLocation = getJavaHomeLocation();
/*     */ 
/*     */       
/* 146 */       VMStandin[] vms = MacInstalledJREs.getInstalledJREs(null);
/* 147 */       File firstLocation = null;
/* 148 */       IVMInstall firstInstall = null;
/* 149 */       IVMInstall defaultInstall = null;
/* 150 */       for (int i = 0; i < vms.length; i++) {
/* 151 */         File location = vms[i].getInstallLocation();
/* 152 */         IVMInstall install = findVMInstall(vms[i].getId());
/* 153 */         if (install == null) {
/* 154 */           install = vms[i].convertToRealVM();
/*     */         }
/* 156 */         if (i == 0) {
/* 157 */           firstLocation = location;
/* 158 */           firstInstall = install;
/*     */         } 
/* 160 */         if (defaultInstall == null && defaultLocation != null && defaultLocation.equals(location)) {
/* 161 */           defaultInstall = install;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 166 */       if (defaultInstall == null) {
/* 167 */         if (defaultLocation != null) {
/*     */           
/* 169 */           String version = System.getProperty("java.version");
/* 170 */           MacInstalledJREs.MacVMStandin macVMStandin = new MacInstalledJREs.MacVMStandin((IVMInstallType)this, 
/* 171 */               defaultLocation, 
/* 172 */               (version == null) ? Messages.MacOSXVMInstallType_jre : NLS.bind(Messages.MacOSXVMInstallType_jre_version, version), 
/* 173 */               (version == null) ? "???" : version, 
/* 174 */               String.valueOf(System.currentTimeMillis()));
/* 175 */           defaultInstall = macVMStandin.convertToRealVM();
/*     */         } else {
/* 177 */           defaultInstall = firstInstall;
/* 178 */           defaultLocation = firstLocation;
/*     */         } 
/*     */       }
/* 181 */       if (defaultInstall != null) {
/*     */         try {
/* 183 */           JavaRuntime.setDefaultVMInstall(defaultInstall, null);
/* 184 */         } catch (CoreException e) {
/* 185 */           LaunchingPlugin.log((Throwable)e);
/*     */         } 
/*     */       }
/* 188 */       return defaultLocation;
/* 189 */     } catch (CoreException e) {
/* 190 */       MacOSXLaunchingPlugin.getDefault().getLog().log(e.getStatus());
/* 191 */       return detectInstallLocationOld();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File detectInstallLocationOld() {
/* 202 */     String javaVMName = System.getProperty("java.vm.name");
/* 203 */     if (javaVMName == null) {
/* 204 */       return null;
/*     */     }
/* 206 */     if (!JVM_VERSIONS_FOLDER.exists() || !JVM_VERSIONS_FOLDER.isDirectory()) {
/* 207 */       String message = NLS.bind(Messages.MacOSXVMInstallType_1, JVM_VERSIONS_FOLDER);
/* 208 */       LaunchingPlugin.log(message);
/* 209 */       return null;
/*     */     } 
/*     */     
/* 212 */     File defaultLocation = null;
/* 213 */     File[] versions = getAllVersionsOld();
/* 214 */     File currentJDK = getCurrentJDKOld();
/* 215 */     for (int i = 0; i < versions.length; i++) {
/* 216 */       File versionFile = versions[i];
/* 217 */       String version = versionFile.getName();
/* 218 */       File home = new File(versionFile, "Home");
/* 219 */       if (home.exists()) {
/* 220 */         boolean isDefault = currentJDK.equals(versionFile);
/* 221 */         IVMInstall install = findVMInstall(version);
/* 222 */         if (install == null) {
/* 223 */           VMStandin vm = new VMStandin((IVMInstallType)this, version);
/* 224 */           vm.setInstallLocation(home);
/* 225 */           vm.setName(version);
/* 226 */           vm.setLibraryLocations(getDefaultLibraryLocations(home));
/* 227 */           vm.setJavadocLocation(getDefaultJavadocLocation(home));
/* 228 */           install = vm.convertToRealVM();
/*     */         } 
/* 230 */         if (isDefault) {
/* 231 */           defaultLocation = home;
/*     */           try {
/* 233 */             JavaRuntime.setDefaultVMInstall(install, null);
/* 234 */           } catch (CoreException e) {
/* 235 */             LaunchingPlugin.log((Throwable)e);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 240 */     return defaultLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File[] getAllVersionsOld() {
/* 250 */     File[] versionFiles = JVM_VERSIONS_FOLDER.listFiles();
/* 251 */     for (int i = 0; i < versionFiles.length; i++) {
/* 252 */       versionFiles[i] = resolveSymbolicLinks(versionFiles[i]);
/*     */     }
/* 254 */     return versionFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getCurrentJDKOld() {
/* 264 */     return resolveSymbolicLinks(new File(JVM_VERSIONS_FOLDER, "CurrentJDK"));
/*     */   }
/*     */   
/*     */   private File resolveSymbolicLinks(File file) {
/*     */     try {
/* 269 */       return file.getCanonicalFile();
/* 270 */     } catch (IOException iOException) {
/* 271 */       return file;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LibraryInfo getDefaultLibraryInfo(File installLocation) {
/* 280 */     IPath rtjar = getDefaultSystemLibrary(installLocation);
/* 281 */     if (rtjar.toFile().isFile())
/*     */     {
/* 283 */       return super.getDefaultLibraryInfo(installLocation);
/*     */     }
/* 285 */     File classes = new File(installLocation, "../Classes");
/* 286 */     File lib1 = new File(classes, "classes.jar");
/* 287 */     File lib2 = new File(classes, "ui.jar");
/*     */     
/* 289 */     String[] libs = { lib1.toString(), lib2.toString() };
/*     */     
/* 291 */     File lib = new File(installLocation, "lib");
/* 292 */     File extDir = new File(lib, "ext");
/* 293 */     String[] dirs = null;
/* 294 */     if (extDir.exists()) {
/* 295 */       dirs = new String[] { extDir.getAbsolutePath() };
/*     */     } else {
/* 297 */       dirs = new String[0];
/*     */     } 
/*     */     
/* 300 */     File endDir = new File(lib, "endorsed");
/* 301 */     String[] endDirs = null;
/* 302 */     if (endDir.exists()) {
/* 303 */       endDirs = new String[] { endDir.getAbsolutePath() };
/*     */     } else {
/* 305 */       endDirs = new String[0];
/*     */     } 
/*     */     
/* 308 */     return new LibraryInfo("???", libs, dirs, endDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getDefaultSystemLibrarySource(File libLocation) {
/* 316 */     File parent = libLocation.getParentFile();
/* 317 */     File src = null;
/*     */ 
/*     */ 
/*     */     
/* 321 */     String pname = parent.getName();
/* 322 */     while (parent != null && !"Contents".equals(pname) && !"Versions".equals(pname)) {
/*     */       
/* 324 */       if ("Classes".equals(pname)) {
/* 325 */         src = new File(parent.getParent(), "Home");
/* 326 */         src = getSourceInParent(src);
/*     */       } else {
/*     */         
/* 329 */         src = getSourceInParent(parent);
/*     */       } 
/* 331 */       if (src != null) {
/* 332 */         if (src.getName().endsWith(".jar")) {
/* 333 */           setDefaultRootPath("src");
/*     */         } else {
/* 335 */           setDefaultRootPath("");
/*     */         } 
/*     */         
/* 338 */         return (IPath)new Path(src.getPath());
/*     */       } 
/* 340 */       parent = parent.getParentFile();
/*     */     } 
/* 342 */     setDefaultRootPath("");
/* 343 */     return (IPath)Path.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getSourceInParent(File parent) {
/* 358 */     if (parent.isDirectory()) {
/* 359 */       File src = new File(parent, "src.zip");
/* 360 */       if (src.isFile()) {
/* 361 */         return src;
/*     */       }
/* 363 */       src = new File(src, "src.jar");
/* 364 */       if (src.isFile()) {
/* 365 */         return src;
/*     */       }
/*     */     } 
/* 368 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateInstallLocation(File javaHome) {
/* 376 */     String id = MacOSXLaunchingPlugin.getUniqueIdentifier();
/* 377 */     File java = new File(javaHome, "bin" + File.separator + "java");
/* 378 */     if (java.isFile())
/*     */     {
/* 380 */       return (IStatus)new Status(0, id, 0, "ok", null);
/*     */     }
/* 382 */     return (IStatus)new Status(4, id, 0, Messages.MacOSXVMInstallType_2, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getDefaultJavadocLocation(File installLocation) {
/* 391 */     String id = null;
/*     */     try {
/* 393 */       String post = String.valueOf(File.separator) + "Home";
/* 394 */       String path = installLocation.getCanonicalPath();
/* 395 */       if (path.startsWith("/System/Library/Frameworks/JavaVM.framework/Versions/") && path.endsWith(post)) {
/* 396 */         id = path.substring("/System/Library/Frameworks/JavaVM.framework/Versions/".length(), path.length() - post.length());
/*     */       }
/* 398 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 401 */     if (id != null) {
/* 402 */       String s = "/Developer/Documentation/Java/Reference/" + id + "/doc/api";
/* 403 */       File docLocation = new File(s);
/* 404 */       if (!docLocation.exists()) {
/* 405 */         s = "/Developer/Documentation/Java/Reference/" + id;
/* 406 */         docLocation = new File(s);
/* 407 */         if (!docLocation.exists()) {
/* 408 */           s = null;
/*     */         }
/*     */       } 
/* 411 */       if (s != null) {
/*     */         try {
/* 413 */           return new URL("file", "", s);
/* 414 */         } catch (MalformedURLException malformedURLException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 421 */     return super.getDefaultJavadocLocation(installLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getVMVersion(File javaHome, File javaExecutable) {
/* 429 */     return super.getVMVersion(javaHome, javaExecutable);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching.macosx-3.6.0.jar!\org\eclipse\jdt\internal\launching\macosx\MacOSXVMInstallType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */