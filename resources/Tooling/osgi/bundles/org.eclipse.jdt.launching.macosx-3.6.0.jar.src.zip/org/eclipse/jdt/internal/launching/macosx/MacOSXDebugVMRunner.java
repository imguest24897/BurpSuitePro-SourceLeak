/*    */ package org.eclipse.jdt.internal.launching.macosx;
/*    */ 
/*    */ import org.eclipse.jdt.internal.launching.StandardVMDebugger;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOSXDebugVMRunner
/*    */   extends StandardVMDebugger
/*    */ {
/*    */   public MacOSXDebugVMRunner(IVMInstall vmInstance) {
/* 29 */     super(vmInstance);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching.macosx-3.6.0.jar!\org\eclipse\jdt\internal\launching\macosx\MacOSXDebugVMRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */