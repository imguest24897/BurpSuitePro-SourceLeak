/*    */ package org.eclipse.jdt.internal.launching.macosx;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOSXLaunchingPlugin
/*    */   extends Plugin
/*    */ {
/*    */   private static MacOSXLaunchingPlugin fgPlugin;
/*    */   
/*    */   public MacOSXLaunchingPlugin() {
/* 26 */     Assert.isTrue((fgPlugin == null));
/* 27 */     fgPlugin = this;
/*    */   }
/*    */   
/*    */   public static MacOSXLaunchingPlugin getDefault() {
/* 31 */     return fgPlugin;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String getUniqueIdentifier() {
/* 38 */     if (getDefault() == null)
/*    */     {
/*    */ 
/*    */       
/* 42 */       return "org.eclipse.jdt.launching.macosx";
/*    */     }
/* 44 */     return getDefault().getBundle().getSymbolicName();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching.macosx-3.6.0.jar!\org\eclipse\jdt\internal\launching\macosx\MacOSXLaunchingPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */