/*    */ package org.eclipse.compare.internal.core;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.compare.internal.core.messages";
/*    */   public static String Activator_1;
/*    */   public static String FileDiffResult_0;
/*    */   public static String FileDiffResult_1;
/*    */   public static String FileDiffResult_2;
/*    */   public static String FileDiffResult_3;
/*    */   public static String Patcher_0;
/*    */   public static String Patcher_1;
/*    */   public static String Patcher_2;
/*    */   public static String WorkspacePatcher_0;
/*    */   public static String WorkspacePatcher_1;
/*    */   public static String RangeComparatorLCS_0;
/*    */   
/*    */   static {
/* 33 */     NLS.initializeMessages("org.eclipse.compare.internal.core.messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */