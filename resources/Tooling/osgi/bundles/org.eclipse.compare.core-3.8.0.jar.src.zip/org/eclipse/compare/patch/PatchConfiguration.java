/*     */ package org.eclipse.compare.patch;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatchConfiguration
/*     */ {
/*     */   private int fStripPrefixSegments;
/*     */   private int fFuzz;
/*     */   private boolean fIgnoreWhitespace = false;
/*     */   private boolean fReverse = false;
/*  33 */   private HashMap<String, Object> properties = new HashMap<>();
/*  34 */   private List<IHunkFilter> hunkFilters = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversed() {
/*  41 */     return this.fReverse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReversed(boolean reversed) {
/*  49 */     this.fReverse = reversed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefixSegmentStripCount() {
/*  59 */     return this.fStripPrefixSegments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefixSegmentStripCount(int stripCount) {
/*  69 */     this.fStripPrefixSegments = stripCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFuzz() {
/*  80 */     return this.fFuzz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFuzz(int fuzz) {
/*  88 */     this.fFuzz = fuzz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnoreWhitespace() {
/*  96 */     return this.fIgnoreWhitespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreWhitespace(boolean ignoreWhitespace) {
/* 104 */     this.fIgnoreWhitespace = ignoreWhitespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String key) {
/* 115 */     return this.properties.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String key, Object value) {
/* 124 */     this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHunkFilter(IHunkFilter filter) {
/* 134 */     this.hunkFilters.add(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHunkFilter(IHunkFilter filter) {
/* 144 */     this.hunkFilters.remove(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IHunkFilter[] getHunkFilters() {
/* 155 */     return this.hunkFilters.<IHunkFilter>toArray(
/* 156 */         new IHunkFilter[this.hunkFilters.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\patch\PatchConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */