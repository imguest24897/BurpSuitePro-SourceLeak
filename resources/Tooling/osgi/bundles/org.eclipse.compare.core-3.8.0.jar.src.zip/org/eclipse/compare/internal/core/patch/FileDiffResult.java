/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.compare.internal.core.Messages;
/*     */ import org.eclipse.compare.patch.IFilePatchResult;
/*     */ import org.eclipse.compare.patch.IHunk;
/*     */ import org.eclipse.compare.patch.PatchConfiguration;
/*     */ import org.eclipse.compare.patch.ReaderCreator;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ public class FileDiffResult
/*     */   implements IFilePatchResult
/*     */ {
/*     */   private FilePatch2 fDiff;
/*     */   private boolean fMatches = false;
/*     */   private boolean fDiffProblem;
/*     */   private String fErrorMessage;
/*  29 */   private Map<Hunk, HunkResult> fHunkResults = new HashMap<>();
/*     */   private List<String> fBeforeLines;
/*     */   private List<String> fAfterLines;
/*     */   private final PatchConfiguration configuration;
/*     */   private String charset;
/*     */   
/*     */   public FileDiffResult(FilePatch2 diff, PatchConfiguration configuration) {
/*  36 */     this.fDiff = diff;
/*  37 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   public PatchConfiguration getConfiguration() {
/*  41 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public boolean canApplyHunk(Hunk hunk) {
/*  45 */     HunkResult result = getHunkResult(hunk);
/*  46 */     return (result.isOK() && !this.fDiffProblem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(ReaderCreator content, IProgressMonitor monitor) {
/*  60 */     this.fMatches = false;
/*  61 */     this.fDiffProblem = false;
/*  62 */     boolean create = false;
/*  63 */     this.charset = Utilities.getCharset(content);
/*     */     
/*  65 */     boolean exists = targetExists(content);
/*  66 */     if (this.fDiff.getDiffType(getConfiguration().isReversed()) == 1) {
/*  67 */       if ((!exists || isEmpty(content)) && canCreateTarget(content)) {
/*  68 */         this.fMatches = true;
/*     */       } else {
/*     */         
/*  71 */         this.fDiffProblem = true;
/*  72 */         this.fErrorMessage = Messages.FileDiffResult_0;
/*     */       } 
/*  74 */       create = true;
/*     */     
/*     */     }
/*  77 */     else if (exists) {
/*  78 */       this.fMatches = true;
/*     */     } else {
/*     */       
/*  81 */       this.fDiffProblem = true;
/*  82 */       this.fErrorMessage = Messages.FileDiffResult_1;
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if (this.fDiffProblem) {
/*     */ 
/*     */ 
/*     */       
/*  90 */       this.fBeforeLines = new ArrayList<>(getLines(content, false));
/*  91 */       this.fAfterLines = this.fMatches ? new ArrayList<>() : this.fBeforeLines;
/*  92 */       IHunk[] hunks = this.fDiff.getHunks(); byte b; int i; IHunk[] arrayOfIHunk1;
/*  93 */       for (i = (arrayOfIHunk1 = hunks).length, b = 0; b < i; ) { IHunk h = arrayOfIHunk1[b];
/*  94 */         Hunk hunk = (Hunk)h;
/*  95 */         hunk.setCharset(getCharset());
/*  96 */         HunkResult result = getHunkResult(hunk);
/*  97 */         result.setMatches(false);
/*     */         b++; }
/*     */     
/*     */     } else {
/* 101 */       patch(getLines(content, create), monitor);
/*     */     } 
/*     */     
/* 104 */     if (containsProblems() && 
/* 105 */       this.fMatches) {
/*     */       
/* 107 */       this.fMatches = false;
/* 108 */       IHunk[] hunks = this.fDiff.getHunks(); byte b; int i; IHunk[] arrayOfIHunk1;
/* 109 */       for (i = (arrayOfIHunk1 = hunks).length, b = 0; b < i; ) { IHunk h = arrayOfIHunk1[b];
/* 110 */         Hunk hunk = (Hunk)h;
/* 111 */         HunkResult result = getHunkResult(hunk);
/* 112 */         if (result.isOK()) {
/* 113 */           this.fMatches = true;
/*     */           break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean canCreateTarget(ReaderCreator content) {
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean targetExists(ReaderCreator content) {
/* 126 */     return (content != null && content.canCreateReader());
/*     */   }
/*     */   
/*     */   protected List<String> getLines(ReaderCreator content, boolean create) {
/* 130 */     List<String> lines = LineReader.load(content, create);
/* 131 */     return lines;
/*     */   }
/*     */   
/*     */   protected boolean isEmpty(ReaderCreator content) {
/* 135 */     if (content == null)
/* 136 */       return true; 
/* 137 */     return LineReader.load(content, false).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void patch(List<String> lines, IProgressMonitor monitor) {
/* 145 */     this.fBeforeLines = new ArrayList<>();
/* 146 */     this.fBeforeLines.addAll(lines);
/* 147 */     if (getConfiguration().getFuzz() != 0) {
/* 148 */       calculateFuzz(this.fBeforeLines, monitor);
/*     */     }
/* 150 */     int shift = 0;
/* 151 */     IHunk[] hunks = this.fDiff.getHunks(); byte b; int i; IHunk[] arrayOfIHunk1;
/* 152 */     for (i = (arrayOfIHunk1 = hunks).length, b = 0; b < i; ) { IHunk h = arrayOfIHunk1[b];
/* 153 */       Hunk hunk = (Hunk)h;
/* 154 */       hunk.setCharset(getCharset());
/* 155 */       HunkResult result = getHunkResult(hunk);
/* 156 */       result.setShift(shift);
/* 157 */       if (result.patch(lines))
/* 158 */         shift = result.getShift(); 
/*     */       b++; }
/*     */     
/* 161 */     this.fAfterLines = lines;
/*     */   }
/*     */   
/*     */   public boolean getDiffProblem() {
/* 165 */     return this.fDiffProblem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsProblems() {
/* 173 */     if (this.fDiffProblem)
/* 174 */       return true; 
/* 175 */     for (HunkResult result : this.fHunkResults.values()) {
/* 176 */       if (!result.isOK())
/* 177 */         return true; 
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */   
/*     */   public String getLabel() {
/* 183 */     String label = getTargetPath().toString();
/* 184 */     if (this.fDiffProblem)
/* 185 */       return NLS.bind(Messages.FileDiffResult_2, (Object[])new String[] { label, this.fErrorMessage }); 
/* 186 */     return label;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMatches() {
/* 191 */     return this.fMatches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getLines() {
/* 199 */     return this.fAfterLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calculateFuzz(List<String> lines, IProgressMonitor monitor) {
/*     */     NullProgressMonitor nullProgressMonitor;
/* 209 */     if (monitor == null)
/* 210 */       nullProgressMonitor = new NullProgressMonitor(); 
/* 211 */     this.fBeforeLines = new ArrayList<>(lines);
/*     */     
/* 213 */     if (this.fDiff.getDiffType(getConfiguration().isReversed()) == 1)
/*     */     {
/*     */       
/* 216 */       return -1;
/*     */     }
/* 218 */     int shift = 0;
/* 219 */     int highestFuzz = -1;
/* 220 */     String name = (getTargetPath() != null) ? getTargetPath().lastSegment() : "";
/* 221 */     IHunk[] hunks = this.fDiff.getHunks();
/* 222 */     for (int j = 0; j < hunks.length; j++) {
/* 223 */       Hunk h = (Hunk)hunks[j];
/* 224 */       nullProgressMonitor.subTask(NLS.bind(Messages.FileDiffResult_3, (Object[])new String[] { name, Integer.toString(j + 1) }));
/* 225 */       HunkResult result = getHunkResult(h);
/* 226 */       result.setShift(shift);
/* 227 */       int fuzz = result.calculateFuzz(lines, (IProgressMonitor)nullProgressMonitor);
/* 228 */       shift = result.getShift();
/* 229 */       if (fuzz > highestFuzz)
/* 230 */         highestFuzz = fuzz; 
/* 231 */       nullProgressMonitor.worked(1);
/*     */     } 
/* 233 */     this.fAfterLines = lines;
/* 234 */     return highestFuzz;
/*     */   }
/*     */   
/*     */   public IPath getTargetPath() {
/* 238 */     return this.fDiff.getStrippedPath(getConfiguration().getPrefixSegmentStripCount(), getConfiguration().isReversed());
/*     */   }
/*     */   
/*     */   private HunkResult getHunkResult(Hunk hunk) {
/* 242 */     HunkResult result = this.fHunkResults.get(hunk);
/* 243 */     if (result == null) {
/* 244 */       result = new HunkResult(this, hunk);
/* 245 */       this.fHunkResults.put(hunk, result);
/*     */     } 
/* 247 */     return result;
/*     */   }
/*     */   
/*     */   public List<Hunk> getFailedHunks() {
/* 251 */     List<Hunk> failedHunks = new ArrayList<>();
/* 252 */     IHunk[] hunks = this.fDiff.getHunks(); byte b; int i; IHunk[] arrayOfIHunk1;
/* 253 */     for (i = (arrayOfIHunk1 = hunks).length, b = 0; b < i; ) { IHunk hunk = arrayOfIHunk1[b];
/* 254 */       HunkResult result = this.fHunkResults.get(hunk);
/* 255 */       if (result != null && !result.isOK())
/* 256 */         failedHunks.add(result.getHunk());  b++; }
/*     */     
/* 258 */     return failedHunks;
/*     */   }
/*     */   
/*     */   public FilePatch2 getDiff() {
/* 262 */     return this.fDiff;
/*     */   }
/*     */   
/*     */   public List<String> getBeforeLines() {
/* 266 */     return this.fBeforeLines;
/*     */   }
/*     */   
/*     */   public List<String> getAfterLines() {
/* 270 */     return this.fAfterLines;
/*     */   }
/*     */ 
/*     */   
/*     */   public HunkResult[] getHunkResults() {
/* 275 */     List<HunkResult> results = new ArrayList<>();
/* 276 */     IHunk[] hunks = this.fDiff.getHunks(); byte b; int i; IHunk[] arrayOfIHunk1;
/* 277 */     for (i = (arrayOfIHunk1 = hunks).length, b = 0; b < i; ) { IHunk hunk = arrayOfIHunk1[b];
/* 278 */       HunkResult result = this.fHunkResults.get(hunk);
/* 279 */       if (result != null)
/* 280 */         results.add(result); 
/*     */       b++; }
/*     */     
/* 283 */     return results.<HunkResult>toArray(new HunkResult[results.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getOriginalContents() {
/* 288 */     String contents = LineReader.createString(isPreserveLineDelimeters(), getBeforeLines());
/* 289 */     return asInputStream(contents, getCharset());
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getPatchedContents() {
/* 294 */     String contents = LineReader.createString(isPreserveLineDelimeters(), getLines());
/* 295 */     return asInputStream(contents, getCharset());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharset() {
/* 300 */     return this.charset;
/*     */   }
/*     */   
/*     */   public boolean isPreserveLineDelimeters() {
/* 304 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IHunk[] getRejects() {
/* 309 */     List<Hunk> failedHunks = getFailedHunks();
/* 310 */     return failedHunks.<IHunk>toArray(new IHunk[failedHunks.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasRejects() {
/* 315 */     return (getFailedHunks().size() > 0);
/*     */   }
/*     */   
/*     */   public static InputStream asInputStream(String contents, String charSet) {
/* 319 */     byte[] bytes = null;
/* 320 */     if (charSet != null) {
/*     */       try {
/* 322 */         bytes = contents.getBytes(charSet);
/* 323 */       } catch (UnsupportedEncodingException e) {
/* 324 */         Platform.getLog(FileDiffResult.class).error(Messages.Activator_1, e);
/*     */       } 
/*     */     }
/* 327 */     if (bytes == null) {
/* 328 */       bytes = contents.getBytes();
/*     */     }
/* 330 */     return new ByteArrayInputStream(bytes);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\FileDiffResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */