/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.patch.IFilePatch2;
/*     */ import org.eclipse.compare.patch.IFilePatchResult;
/*     */ import org.eclipse.compare.patch.IHunk;
/*     */ import org.eclipse.compare.patch.PatchConfiguration;
/*     */ import org.eclipse.compare.patch.ReaderCreator;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePatch2
/*     */   implements IFilePatch2
/*     */ {
/*     */   public static final int ADDITION = 1;
/*     */   public static final int DELETION = 2;
/*     */   public static final int CHANGE = 3;
/*     */   private IPath fOldPath;
/*     */   private IPath fNewPath;
/*     */   private long oldDate;
/*     */   private long newDate;
/*  49 */   private List<Hunk> fHunks = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private DiffProject fProject;
/*     */   
/*     */   private String header;
/*     */   
/*     */   private int addedLines;
/*     */   
/*     */   private int removedLines;
/*     */ 
/*     */   
/*     */   public FilePatch2(IPath oldPath, long oldDate, IPath newPath, long newDate) {
/*  62 */     this.fOldPath = oldPath;
/*  63 */     this.oldDate = oldDate;
/*  64 */     this.fNewPath = newPath;
/*  65 */     this.newDate = newDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiffProject getProject() {
/*  73 */     return this.fProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setProject(DiffProject diffProject) {
/*  83 */     if (this.fProject == diffProject)
/*     */       return; 
/*  85 */     if (this.fProject != null)
/*  86 */       this.fProject.remove(this); 
/*  87 */     this.fProject = diffProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath(boolean reverse) {
/*  97 */     if (getDiffType(reverse) == 1) {
/*  98 */       if (reverse)
/*  99 */         return this.fOldPath; 
/* 100 */       return this.fNewPath;
/*     */     } 
/* 102 */     if (reverse && this.fNewPath != null)
/* 103 */       return this.fNewPath; 
/* 104 */     if (this.fOldPath != null)
/* 105 */       return this.fOldPath; 
/* 106 */     return this.fNewPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Hunk hunk) {
/* 114 */     this.fHunks.add(hunk);
/* 115 */     hunk.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void remove(Hunk hunk) {
/* 123 */     this.fHunks.remove(hunk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IHunk[] getHunks() {
/* 132 */     return this.fHunks.<IHunk>toArray(new IHunk[this.fHunks.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHunkCount() {
/* 140 */     return this.fHunks.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDiffType(boolean reverse) {
/* 149 */     if (this.fHunks.size() == 1) {
/* 150 */       boolean add = false;
/* 151 */       boolean delete = false;
/* 152 */       Iterator<Hunk> iter = this.fHunks.iterator();
/* 153 */       while (iter.hasNext()) {
/* 154 */         Hunk hunk = iter.next();
/* 155 */         int type = hunk.getHunkType(reverse);
/* 156 */         if (type == 1) {
/* 157 */           add = true; continue;
/* 158 */         }  if (type == 2) {
/* 159 */           delete = true;
/*     */         }
/*     */       } 
/* 162 */       if (add && !delete)
/* 163 */         return 1; 
/* 164 */       if (!add && delete) {
/* 165 */         return 2;
/*     */       }
/*     */     } 
/* 168 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getStrippedPath(int strip, boolean reverse) {
/* 180 */     IPath path = getPath(reverse);
/* 181 */     if (strip > 0 && strip < path.segmentCount())
/* 182 */       path = path.removeFirstSegments(strip); 
/* 183 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int segmentCount() {
/* 193 */     int length = 99;
/* 194 */     if (this.fOldPath != null)
/* 195 */       length = Math.min(length, this.fOldPath.segmentCount()); 
/* 196 */     if (this.fNewPath != null)
/* 197 */       length = Math.min(length, this.fNewPath.segmentCount()); 
/* 198 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IFilePatchResult apply(ReaderCreator content, PatchConfiguration configuration, IProgressMonitor monitor) {
/* 204 */     FileDiffResult result = new FileDiffResult(this, configuration);
/* 205 */     result.refresh(content, monitor);
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getTargetPath(PatchConfiguration configuration) {
/* 211 */     return getStrippedPath(configuration.getPrefixSegmentStripCount(), configuration.isReversed());
/*     */   }
/*     */   
/*     */   public FilePatch2 asRelativeDiff() {
/* 215 */     if (this.fProject == null)
/* 216 */       return this; 
/* 217 */     IPath adjustedOldPath = null;
/* 218 */     if (this.fOldPath != null) {
/* 219 */       adjustedOldPath = (new Path(null, this.fProject.getName())).append(this.fOldPath);
/*     */     }
/* 221 */     IPath adjustedNewPath = null;
/* 222 */     if (this.fNewPath != null) {
/* 223 */       adjustedNewPath = (new Path(null, this.fProject.getName())).append(this.fNewPath);
/*     */     }
/* 225 */     FilePatch2 diff = create(adjustedOldPath, 0L, adjustedNewPath, 0L);
/* 226 */     for (Hunk hunk : this.fHunks);
/*     */ 
/*     */ 
/*     */     
/* 230 */     return diff;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FilePatch2 create(IPath oldPath, long oldDate, IPath newPath, long newDate) {
/* 235 */     return new FilePatch2(oldPath, oldDate, newPath, newDate);
/*     */   }
/*     */   
/*     */   public void setHeader(String header) {
/* 239 */     this.header = header;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeader() {
/* 244 */     return this.header;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getBeforeDate() {
/* 249 */     return this.oldDate;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAfterDate() {
/* 254 */     return this.newDate;
/*     */   }
/*     */   
/*     */   public void setAddedLines(int addedLines) {
/* 258 */     this.addedLines = addedLines;
/*     */   }
/*     */   
/*     */   public void setRemovedLines(int removedLines) {
/* 262 */     this.removedLines = removedLines;
/*     */   }
/*     */   
/*     */   public int getAddedLines() {
/* 266 */     return this.addedLines;
/*     */   }
/*     */   
/*     */   public int getRemovedLines() {
/* 270 */     return this.removedLines;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\FilePatch2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */