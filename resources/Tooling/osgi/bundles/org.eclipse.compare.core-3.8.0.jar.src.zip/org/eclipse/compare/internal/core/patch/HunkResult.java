/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.patch.IHunkFilter;
/*     */ import org.eclipse.compare.patch.PatchConfiguration;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HunkResult
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private static final int MAXIMUM_FUZZ_FACTOR = 2;
/*     */   private Hunk fHunk;
/*     */   private boolean fMatches;
/*     */   private int fShift;
/*  36 */   private int fFuzz = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private final FileDiffResult fDiffResult;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HunkResult(FileDiffResult diffResult, Hunk hunk) {
/*  46 */     this.fDiffResult = diffResult;
/*  47 */     this.fHunk = hunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean patch(List<String> lines) {
/*  58 */     this.fMatches = false;
/*  59 */     PatchConfiguration configuration = getConfiguration();
/*     */     
/*  61 */     int fuzz = (this.fFuzz != -1) ? this.fFuzz : configuration.getFuzz();
/*  62 */     if (isEnabled(configuration)) {
/*  63 */       if (this.fHunk.tryPatch(configuration, lines, this.fShift, fuzz)) {
/*     */         
/*  65 */         this.fShift += this.fHunk.doPatch(configuration, lines, this.fShift, fuzz);
/*  66 */         this.fMatches = true;
/*     */       } else {
/*  68 */         boolean found = false;
/*  69 */         int oldShift = this.fShift;
/*     */         
/*  71 */         int hugeShift = lines.size(); int i;
/*  72 */         for (i = 1; i <= hugeShift; i++) {
/*  73 */           if (this.fHunk.tryPatch(configuration, lines, this.fShift - i, fuzz)) {
/*  74 */             if (isAdjustShift())
/*  75 */               this.fShift -= i; 
/*  76 */             found = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*  81 */         if (!found) {
/*  82 */           for (i = 1; i <= hugeShift; i++) {
/*  83 */             if (this.fHunk.tryPatch(configuration, lines, this.fShift + i, fuzz)) {
/*  84 */               if (isAdjustShift())
/*  85 */                 this.fShift += i; 
/*  86 */               found = true;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*  92 */         if (found) {
/*     */           
/*  94 */           this.fShift += this.fHunk.doPatch(configuration, lines, this.fShift, fuzz);
/*  95 */           this.fMatches = true;
/*     */         } 
/*     */       } 
/*     */     }
/*  99 */     return this.fMatches;
/*     */   }
/*     */   
/*     */   private boolean isAdjustShift() {
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   private PatchConfiguration getConfiguration() {
/* 107 */     return getDiffResult().getConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calculateFuzz(List<String> lines, IProgressMonitor monitor) {
/* 122 */     this.fMatches = false;
/* 123 */     PatchConfiguration configuration = getConfiguration();
/* 124 */     int fuzz = 0;
/* 125 */     int maxFuzz = (configuration.getFuzz() == -1) ? 2 : 
/* 126 */       configuration.getFuzz();
/* 127 */     for (; fuzz <= maxFuzz; fuzz++) {
/*     */       
/* 129 */       if (this.fHunk.tryPatch(configuration, lines, this.fShift, fuzz)) {
/*     */         
/* 131 */         this.fShift += this.fHunk.doPatch(configuration, lines, this.fShift, fuzz);
/* 132 */         this.fMatches = true;
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */ 
/*     */       
/* 140 */       int hugeShift = lines.size();
/*     */       
/*     */       int i;
/* 143 */       for (i = 1; i <= hugeShift; i++) {
/* 144 */         if (monitor.isCanceled()) {
/* 145 */           throw new OperationCanceledException();
/*     */         }
/* 147 */         if (this.fHunk.tryPatch(configuration, lines, this.fShift - i, fuzz)) {
/* 148 */           if (isAdjustShift())
/* 149 */             this.fShift -= i; 
/* 150 */           this.fMatches = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 156 */       if (!this.fMatches) {
/* 157 */         for (i = 1; i <= hugeShift; i++) {
/* 158 */           if (monitor.isCanceled()) {
/* 159 */             throw new OperationCanceledException();
/*     */           }
/* 161 */           if (this.fHunk.tryPatch(configuration, lines, this.fShift + i, fuzz)) {
/* 162 */             if (isAdjustShift())
/* 163 */               this.fShift += i; 
/* 164 */             this.fMatches = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 170 */       if (this.fMatches) {
/* 171 */         this.fShift += this.fHunk.doPatch(configuration, lines, this.fShift, fuzz);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 176 */     this.fFuzz = this.fMatches ? fuzz : -1;
/* 177 */     return this.fFuzz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getShift() {
/* 187 */     return this.fShift;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShift(int shift) {
/* 197 */     this.fShift = shift;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hunk getHunk() {
/* 205 */     return this.fHunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileDiffResult getDiffResult() {
/* 213 */     return this.fDiffResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOK() {
/* 221 */     return this.fMatches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents(boolean afterState, boolean fullContext) {
/* 232 */     if (fullContext) {
/* 233 */       boolean problemFound = false;
/* 234 */       List<String> lines = getDiffResult().getBeforeLines();
/* 235 */       if (afterState) {
/* 236 */         if (isOK()) {
/* 237 */           int oldShift = this.fShift;
/*     */           try {
/* 239 */             this.fShift = 0;
/* 240 */             problemFound = !patch(lines);
/*     */           } finally {
/* 242 */             this.fShift = oldShift;
/*     */           } 
/*     */         } else {
/* 245 */           problemFound = true;
/*     */         } 
/*     */       }
/*     */       
/* 249 */       if (!problemFound)
/* 250 */         return LineReader.createString(this.fDiffResult.isPreserveLineDelimeters(), lines); 
/*     */     } 
/* 252 */     return getHunk().getContents(afterState, getConfiguration().isReversed());
/*     */   }
/*     */   
/*     */   private boolean isEnabled(PatchConfiguration configuration) {
/* 256 */     IHunkFilter[] filters = configuration.getHunkFilters(); byte b; int i; IHunkFilter[] arrayOfIHunkFilter1;
/* 257 */     for (i = (arrayOfIHunkFilter1 = filters).length, b = 0; b < i; ) { IHunkFilter filter = arrayOfIHunkFilter1[b];
/* 258 */       if (!filter.select(this.fHunk))
/* 259 */         return false; 
/*     */       b++; }
/*     */     
/* 262 */     return true;
/*     */   }
/*     */   
/*     */   public void setMatches(boolean matches) {
/* 266 */     this.fMatches = matches;
/*     */   }
/*     */   
/*     */   public String getCharset() {
/* 270 */     return this.fDiffResult.getCharset();
/*     */   }
/*     */   
/*     */   public int getFuzz() {
/* 274 */     return this.fFuzz;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\HunkResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */