package org.eclipse.compare.patch;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IFilePatch2 {
  public static final long DATE_UNKNOWN = 0L;
  
  IPath getTargetPath(PatchConfiguration paramPatchConfiguration);
  
  IFilePatchResult apply(ReaderCreator paramReaderCreator, PatchConfiguration paramPatchConfiguration, IProgressMonitor paramIProgressMonitor);
  
  String getHeader();
  
  long getBeforeDate();
  
  long getAfterDate();
  
  IHunk[] getHunks();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\patch\IFilePatch2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */