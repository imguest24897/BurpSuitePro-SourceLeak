package org.eclipse.compare.rangedifferencer;

public interface IRangeComparator {
  int getRangeCount();
  
  boolean rangesEqual(int paramInt1, IRangeComparator paramIRangeComparator, int paramInt2);
  
  boolean skipRangeComparison(int paramInt1, int paramInt2, IRangeComparator paramIRangeComparator);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\IRangeComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */