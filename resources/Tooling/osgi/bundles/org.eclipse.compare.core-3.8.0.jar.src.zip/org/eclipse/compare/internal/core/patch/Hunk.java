/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.patch.IHunk;
/*     */ import org.eclipse.compare.patch.PatchConfiguration;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hunk
/*     */   implements IHunk
/*     */ {
/*     */   private FilePatch2 fParent;
/*     */   private int fOldStart;
/*     */   private int fOldLength;
/*     */   private int fNewStart;
/*     */   private int fNewLength;
/*     */   private String[] fLines;
/*     */   private int hunkType;
/*  32 */   private String charset = null;
/*     */ 
/*     */   
/*     */   public static Hunk createHunk(FilePatch2 parent, int[] oldRange, int[] newRange, List<String> lines, boolean hasLineAdditions, boolean hasLineDeletions, boolean hasContextLines) {
/*  36 */     int oldStart = 0;
/*  37 */     int newStart = 0;
/*  38 */     if (oldRange[0] > 0) {
/*  39 */       oldStart = oldRange[0] - 1;
/*     */     } else {
/*  41 */       oldStart = 0;
/*  42 */     }  int oldLength = oldRange[1];
/*  43 */     if (newRange[0] > 0) {
/*  44 */       newStart = newRange[0] - 1;
/*     */     } else {
/*  46 */       newStart = 0;
/*  47 */     }  int newLength = newRange[1];
/*  48 */     int hunkType = 3;
/*  49 */     if (!hasContextLines) {
/*  50 */       if (hasLineAdditions && !hasLineDeletions) {
/*  51 */         hunkType = 1;
/*  52 */       } else if (!hasLineAdditions && hasLineDeletions) {
/*  53 */         hunkType = 2;
/*     */       } 
/*     */     }
/*  56 */     return new Hunk(parent, hunkType, oldStart, oldLength, newStart, newLength, lines.<String>toArray(new String[lines.size()]));
/*     */   }
/*     */ 
/*     */   
/*     */   public Hunk(FilePatch2 parent, int hunkType, int oldStart, int oldLength, int newStart, int newLength, String[] lines) {
/*  61 */     this.fParent = parent;
/*  62 */     if (this.fParent != null) {
/*  63 */       this.fParent.add(this);
/*     */     }
/*  65 */     this.hunkType = hunkType;
/*  66 */     this.fOldLength = oldLength;
/*  67 */     this.fOldStart = oldStart;
/*  68 */     this.fNewLength = newLength;
/*  69 */     this.fNewStart = newStart;
/*  70 */     this.fLines = lines;
/*     */   }
/*     */   
/*     */   public Hunk(FilePatch2 parent, Hunk toCopy) {
/*  74 */     this(parent, toCopy.hunkType, toCopy.fOldStart, toCopy.fOldLength, toCopy.fNewStart, toCopy.fNewLength, toCopy.fLines);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContent() {
/*  90 */     StringBuilder sb = new StringBuilder(); byte b; int i; String[] arrayOfString;
/*  91 */     for (i = (arrayOfString = this.fLines).length, b = 0; b < i; ) { String line = arrayOfString[b];
/*  92 */       sb.append(line.substring(0, LineReader.length(line)));
/*  93 */       sb.append('\n'); b++; }
/*     */     
/*  95 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDescription() {
/* 103 */     StringBuilder sb = new StringBuilder();
/* 104 */     sb.append(Integer.toString(this.fOldStart));
/* 105 */     sb.append(',');
/* 106 */     sb.append(Integer.toString(this.fOldLength));
/* 107 */     sb.append(" -> ");
/* 108 */     sb.append(Integer.toString(this.fNewStart));
/* 109 */     sb.append(',');
/* 110 */     sb.append(Integer.toString(this.fNewLength));
/* 111 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getRejectedDescription() {
/* 115 */     StringBuilder sb = new StringBuilder();
/* 116 */     sb.append("@@ -");
/* 117 */     sb.append(Integer.toString(this.fOldStart));
/* 118 */     sb.append(',');
/* 119 */     sb.append(Integer.toString(this.fOldLength));
/* 120 */     sb.append(" +");
/* 121 */     sb.append(Integer.toString(this.fNewStart));
/* 122 */     sb.append(',');
/* 123 */     sb.append(Integer.toString(this.fNewLength));
/* 124 */     sb.append(" @@");
/* 125 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public int getHunkType(boolean reverse) {
/* 129 */     if (reverse) {
/* 130 */       if (this.hunkType == 1)
/* 131 */         return 2; 
/* 132 */       if (this.hunkType == 2)
/* 133 */         return 1; 
/*     */     } 
/* 135 */     return this.hunkType;
/*     */   }
/*     */   
/*     */   void setHunkType(int hunkType) {
/* 139 */     this.hunkType = hunkType;
/*     */   }
/*     */   
/*     */   public String[] getLines() {
/* 143 */     return this.fLines;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getUnifiedLines() {
/* 148 */     String[] ret = new String[this.fLines.length];
/* 149 */     System.arraycopy(this.fLines, 0, ret, 0, this.fLines.length);
/* 150 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setParent(FilePatch2 diff) {
/* 159 */     if (this.fParent == diff)
/*     */       return; 
/* 161 */     if (this.fParent != null)
/* 162 */       this.fParent.remove(this); 
/* 163 */     this.fParent = diff;
/*     */   }
/*     */   
/*     */   public FilePatch2 getParent() {
/* 167 */     return this.fParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tryPatch(PatchConfiguration configuration, List<String> lines, int shift, int fuzz) {
/* 176 */     boolean reverse = configuration.isReversed();
/* 177 */     int pos = getStart(reverse) + shift;
/* 178 */     List<String> contextLines = new ArrayList<>();
/* 179 */     boolean contextLinesMatched = true;
/* 180 */     boolean precedingLinesChecked = false; byte b; int i; String[] arrayOfString;
/* 181 */     for (i = (arrayOfString = this.fLines).length, b = 0; b < i; ) { String s = arrayOfString[b];
/* 182 */       Assert.isTrue((s.length() > 0));
/* 183 */       String line = s.substring(1);
/* 184 */       char controlChar = s.charAt(0);
/*     */       
/* 186 */       if (controlChar == ' ') {
/*     */         
/* 188 */         if (pos < 0 || pos >= lines.size())
/* 189 */           return false; 
/* 190 */         contextLines.add(line);
/* 191 */         if (linesMatch(configuration, line, lines.get(pos)))
/* 192 */         { pos++; }
/*     */         
/* 194 */         else if (fuzz > 0)
/*     */         
/* 196 */         { contextLinesMatched = false;
/* 197 */           pos++; }
/*     */         else
/*     */         
/* 200 */         { return false; } 
/* 201 */       } else if (isDeletedDelimeter(controlChar, reverse)) {
/*     */ 
/*     */         
/* 204 */         if (precedingLinesChecked && !contextLinesMatched && contextLines.size() > 0)
/*     */         {
/* 206 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 210 */         if (!precedingLinesChecked && 
/* 211 */           !contextLinesMatched && 
/* 212 */           contextLines.size() >= fuzz && 
/* 213 */           !checkPrecedingContextLines(configuration, lines, 
/* 214 */             fuzz, pos, contextLines)) {
/* 215 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 219 */         precedingLinesChecked = true;
/* 220 */         contextLines.clear();
/* 221 */         contextLinesMatched = true;
/*     */         
/* 223 */         if (pos < 0 || pos >= lines.size())
/* 224 */           return false; 
/* 225 */         if (linesMatch(configuration, line, lines.get(pos)))
/* 226 */         { pos++;
/*     */           
/*     */            }
/*     */         
/*     */         else
/*     */         
/*     */         { 
/* 233 */           return false; } 
/* 234 */       } else if (isAddedDelimeter(controlChar, reverse)) {
/*     */         
/* 236 */         if (precedingLinesChecked && !contextLinesMatched && contextLines.size() > 0) {
/* 237 */           return false;
/*     */         }
/* 239 */         if (!precedingLinesChecked && 
/* 240 */           !contextLinesMatched && 
/* 241 */           contextLines.size() >= fuzz && 
/* 242 */           !checkPrecedingContextLines(configuration, lines, 
/* 243 */             fuzz, pos, contextLines)) {
/* 244 */           return false;
/*     */         }
/* 246 */         precedingLinesChecked = true;
/* 247 */         contextLines.clear();
/* 248 */         contextLinesMatched = true;
/*     */       }
/*     */       else {
/*     */         
/* 252 */         Assert.isTrue(false, "tryPatch: unknown control character: " + controlChar);
/*     */       } 
/*     */       b++; }
/*     */     
/* 256 */     if (!contextLinesMatched && 
/* 257 */       fuzz > 0 && 
/* 258 */       contextLines.size() > fuzz && 
/* 259 */       !checkFollowingContextLines(configuration, lines, fuzz, pos, 
/* 260 */         contextLines)) {
/* 261 */       return false;
/*     */     }
/* 263 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkPrecedingContextLines(PatchConfiguration configuration, List<String> lines, int fuzz, int pos, List<String> contextLines) {
/* 270 */     for (int j = fuzz; j < contextLines.size(); j++) {
/* 271 */       if (!linesMatch(configuration, contextLines.get(j), 
/* 272 */           lines.get(pos - contextLines.size() + j)))
/* 273 */         return false; 
/*     */     } 
/* 275 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkFollowingContextLines(PatchConfiguration configuration, List<String> lines, int fuzz, int pos, List<String> contextLines) {
/* 281 */     if (!contextLines.isEmpty())
/*     */     {
/* 283 */       for (int j = 0; j < contextLines.size() - fuzz; j++) {
/* 284 */         if (!linesMatch(configuration, contextLines.get(j), 
/* 285 */             lines.get(pos - contextLines.size() + j)))
/* 286 */           return false; 
/*     */       } 
/*     */     }
/* 289 */     return true;
/*     */   }
/*     */   
/*     */   public int getStart(boolean after) {
/* 293 */     if (after) {
/* 294 */       return this.fNewStart;
/*     */     }
/* 296 */     return this.fOldStart;
/*     */   }
/*     */   
/*     */   public void setStart(int start, boolean after) {
/* 300 */     if (after) {
/* 301 */       this.fNewStart = start;
/*     */     } else {
/* 303 */       this.fOldStart = start;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLength(boolean after) {
/* 308 */     if (after) {
/* 309 */       return this.fNewLength;
/*     */     }
/* 311 */     return this.fOldLength;
/*     */   }
/*     */   
/*     */   private int getShift(boolean reverse) {
/* 315 */     if (reverse) {
/* 316 */       return this.fOldLength - this.fNewLength;
/*     */     }
/* 318 */     return this.fNewLength - this.fOldLength;
/*     */   }
/*     */   
/*     */   int doPatch(PatchConfiguration configuration, List<String> lines, int shift, int fuzz) {
/* 322 */     boolean reverse = configuration.isReversed();
/* 323 */     int pos = getStart(reverse) + shift;
/* 324 */     List<String> contextLines = new ArrayList<>();
/* 325 */     boolean contextLinesMatched = true;
/* 326 */     boolean precedingLinesChecked = false;
/* 327 */     String lineDelimiter = getLineDelimiter(lines); byte b; int i;
/*     */     String[] arrayOfString;
/* 329 */     for (i = (arrayOfString = this.fLines).length, b = 0; b < i; ) { String s = arrayOfString[b];
/* 330 */       Assert.isTrue((s.length() > 0));
/* 331 */       String line = s.substring(1);
/* 332 */       char controlChar = s.charAt(0);
/* 333 */       if (controlChar == ' ') {
/*     */         
/* 335 */         Assert.isTrue((pos < lines.size()), "doPatch: inconsistency in context");
/* 336 */         contextLines.add(line);
/* 337 */         if (linesMatch(configuration, line, lines.get(pos))) {
/* 338 */           pos++;
/*     */         }
/* 340 */         else if (fuzz > 0) {
/*     */           
/* 342 */           contextLinesMatched = false;
/* 343 */           pos++;
/*     */         } else {
/*     */           
/* 346 */           Assert.isTrue(false, "doPatch: context doesn't match");
/*     */         } 
/* 348 */       } else if (isDeletedDelimeter(controlChar, reverse)) {
/*     */         
/* 350 */         if (precedingLinesChecked && !contextLinesMatched && contextLines.size() > 0)
/*     */         {
/* 352 */           Assert.isTrue(false, "doPatch: context lines inside hunk don't match");
/*     */         }
/*     */ 
/*     */         
/* 356 */         if (!precedingLinesChecked && 
/* 357 */           !contextLinesMatched && 
/* 358 */           contextLines.size() >= fuzz && 
/* 359 */           !checkPrecedingContextLines(configuration, lines, 
/* 360 */             fuzz, pos, contextLines)) {
/* 361 */           Assert.isTrue(false, "doPatch: preceding context lines don't match, even though fuzz factor has been used");
/*     */         }
/*     */ 
/*     */         
/* 365 */         precedingLinesChecked = true;
/* 366 */         contextLines.clear();
/* 367 */         contextLinesMatched = true;
/*     */         
/* 369 */         lines.remove(pos);
/* 370 */       } else if (isAddedDelimeter(controlChar, reverse)) {
/*     */         
/* 372 */         if (precedingLinesChecked && !contextLinesMatched && contextLines.size() > 0) {
/* 373 */           Assert.isTrue(false, "doPatch: context lines inside hunk don't match");
/*     */         }
/* 375 */         if (!precedingLinesChecked && 
/* 376 */           !contextLinesMatched && 
/* 377 */           contextLines.size() >= fuzz && 
/* 378 */           !checkPrecedingContextLines(configuration, lines, 
/* 379 */             fuzz, pos, contextLines)) {
/* 380 */           Assert.isTrue(false, "doPatch: preceding context lines don't match, even though fuzz factor has been used");
/*     */         }
/* 382 */         precedingLinesChecked = true;
/* 383 */         contextLines.clear();
/* 384 */         contextLinesMatched = true;
/*     */ 
/*     */         
/* 387 */         if (line.length() > LineReader.length(line)) {
/* 388 */           line = String.valueOf(line.substring(0, LineReader.length(line))) + lineDelimiter;
/*     */         }
/* 390 */         if (getLength(reverse) == 0 && pos + 1 < lines.size()) {
/* 391 */           lines.add(pos + 1, line);
/*     */         } else {
/* 393 */           lines.add(pos, line);
/* 394 */         }  pos++;
/*     */       } else {
/* 396 */         Assert.isTrue(false, "doPatch: unknown control character: " + controlChar);
/*     */       }  b++; }
/* 398 */      return getShift(reverse);
/*     */   }
/*     */   
/*     */   private boolean isDeletedDelimeter(char controlChar, boolean reverse) {
/* 402 */     return !((reverse || controlChar != '-') && (!reverse || controlChar != '+'));
/*     */   }
/*     */   
/*     */   private boolean isAddedDelimeter(char controlChar, boolean reverse) {
/* 406 */     return !((!reverse || controlChar != '-') && (reverse || controlChar != '+'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean linesMatch(PatchConfiguration configuration, String line1, String line2) {
/* 414 */     if (configuration.isIgnoreWhitespace())
/* 415 */       return stripWhiteSpace(line1).equals(stripWhiteSpace(line2)); 
/* 416 */     if (isIgnoreLineDelimiter()) {
/* 417 */       int l1 = LineReader.length(line1);
/* 418 */       int l2 = LineReader.length(line2);
/* 419 */       if (l1 != l2)
/* 420 */         return false; 
/* 421 */       return line1.regionMatches(0, line2, 0, l1);
/*     */     } 
/* 423 */     return line1.equals(line2);
/*     */   }
/*     */   
/*     */   private boolean isIgnoreLineDelimiter() {
/* 427 */     return true;
/*     */   }
/*     */   
/*     */   private String getLineDelimiter(List<String> lines) {
/* 431 */     if (lines.size() > 0) {
/*     */       
/* 433 */       String line0 = lines.get(0);
/* 434 */       return line0.substring(LineReader.length(line0));
/* 435 */     }  if (this.fLines.length > 0)
/*     */     {
/* 437 */       return this.fLines[0].substring(LineReader.length(this.fLines[0]));
/*     */     }
/* 439 */     return System.getProperty("line.separator");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String stripWhiteSpace(String s) {
/* 447 */     StringBuilder sb = new StringBuilder();
/* 448 */     int l = s.length();
/* 449 */     for (int i = 0; i < l; i++) {
/* 450 */       char c = s.charAt(i);
/* 451 */       if (!Character.isWhitespace(c))
/* 452 */         sb.append(c); 
/*     */     } 
/* 454 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getContents(boolean isAfterState, boolean reverse) {
/* 458 */     StringBuilder result = new StringBuilder(); byte b; int i; String[] arrayOfString;
/* 459 */     for (i = (arrayOfString = this.fLines).length, b = 0; b < i; ) { String line = arrayOfString[b];
/* 460 */       String rest = line.substring(1);
/* 461 */       char c = line.charAt(0);
/* 462 */       if (c == ' ') {
/* 463 */         result.append(rest);
/* 464 */       } else if (isDeletedDelimeter(c, reverse) && !isAfterState) {
/* 465 */         result.append(rest);
/* 466 */       } else if (isAddedDelimeter(c, reverse) && isAfterState) {
/* 467 */         result.append(rest);
/*     */       }  b++; }
/*     */     
/* 470 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 475 */     return getDescription();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStartPosition() {
/* 480 */     return getStart(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getOriginalContents() {
/* 485 */     String contents = getContents(false, false);
/* 486 */     return asInputStream(contents);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getPatchedContents() {
/* 491 */     String contents = getContents(true, false);
/* 492 */     return asInputStream(contents);
/*     */   }
/*     */   
/*     */   private InputStream asInputStream(String contents) {
/* 496 */     String charSet = getCharset();
/* 497 */     return FileDiffResult.asInputStream(contents, charSet);
/*     */   }
/*     */   
/*     */   void setCharset(String charset) {
/* 501 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getCharset() {
/* 515 */     return this.charset;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\Hunk.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */