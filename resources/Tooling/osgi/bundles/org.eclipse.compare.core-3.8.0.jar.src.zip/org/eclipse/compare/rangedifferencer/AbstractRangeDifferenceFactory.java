/*    */ package org.eclipse.compare.rangedifferencer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRangeDifferenceFactory
/*    */ {
/*    */   protected abstract RangeDifference createRangeDifference();
/*    */   
/*    */   RangeDifference createRangeDifference(int changeKind) {
/* 23 */     RangeDifference rangeDifference = createRangeDifference();
/* 24 */     rangeDifference.kind = changeKind;
/* 25 */     return rangeDifference;
/*    */   }
/*    */ 
/*    */   
/*    */   RangeDifference createRangeDifference(int kind, int rightStart, int rightLength, int leftStart, int leftLength) {
/* 30 */     RangeDifference rangeDifference = createRangeDifference();
/* 31 */     rangeDifference.kind = kind;
/* 32 */     rangeDifference.rightStart = rightStart;
/* 33 */     rangeDifference.rightLength = rightLength;
/* 34 */     rangeDifference.leftStart = leftStart;
/* 35 */     rangeDifference.leftLength = leftLength;
/* 36 */     return rangeDifference;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   RangeDifference createRangeDifference(int kind, int rightStart, int rightLength, int leftStart, int leftLength, int ancestorStart, int ancestorLength) {
/* 42 */     RangeDifference rangeDifference = createRangeDifference();
/* 43 */     rangeDifference.kind = kind;
/* 44 */     rangeDifference.rightStart = rightStart;
/* 45 */     rangeDifference.rightLength = rightLength;
/* 46 */     rangeDifference.leftStart = leftStart;
/* 47 */     rangeDifference.leftLength = leftLength;
/* 48 */     rangeDifference.ancestorStart = ancestorStart;
/* 49 */     rangeDifference.ancestorLength = ancestorLength;
/* 50 */     return rangeDifference;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\AbstractRangeDifferenceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */