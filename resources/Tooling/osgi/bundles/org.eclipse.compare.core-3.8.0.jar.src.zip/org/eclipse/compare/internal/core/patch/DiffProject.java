/*    */ package org.eclipse.compare.internal.core.patch;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiffProject
/*    */ {
/*    */   private String project;
/* 26 */   private Set<FilePatch2> fDiffs = new HashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DiffProject(String project) {
/* 33 */     this.project = project;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void add(FilePatch2 diff) {
/* 41 */     this.fDiffs.add(diff);
/* 42 */     if (diff.getProject() != this) {
/* 43 */       diff.setProject(this);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 51 */     return this.project;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove(FilePatch2 diff) {
/* 59 */     this.fDiffs.remove(diff);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contains(FilePatch2 diff) {
/* 68 */     return this.fDiffs.contains(diff);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilePatch2[] getFileDiffs() {
/* 76 */     return this.fDiffs.<FilePatch2>toArray(new FilePatch2[this.fDiffs.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\DiffProject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */