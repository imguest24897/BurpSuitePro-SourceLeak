/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatchReader
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private static final String DEV_NULL = "/dev/null";
/*     */   protected static final String MARKER_TYPE = "org.eclipse.compare.rejectedPatchMarker";
/*  39 */   private DateFormat[] fDateFormats = new DateFormat[] {
/*  40 */       new SimpleDateFormat("EEE MMM dd kk:mm:ss yyyy"), 
/*  41 */       new SimpleDateFormat("yyyy/MM/dd kk:mm:ss"), 
/*  42 */       new SimpleDateFormat("EEE MMM dd kk:mm:ss yyyy", Locale.US)
/*     */     };
/*     */   
/*     */   private boolean fIsWorkspacePatch;
/*     */   
/*     */   private boolean fIsGitPatch;
/*     */   
/*     */   private DiffProject[] fDiffProjects;
/*     */   
/*     */   private FilePatch2[] fDiffs;
/*     */   
/*     */   public static final String MULTIPROJECTPATCH_HEADER = "### Eclipse Workspace Patch";
/*     */   
/*     */   public static final String MULTIPROJECTPATCH_VERSION = "1.0";
/*     */   public static final String MULTIPROJECTPATCH_PROJECT = "#P";
/*  57 */   private static final Pattern GIT_PATCH_PATTERN = Pattern.compile("^diff --git a/.+ b/.+[\r\n]+$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatchReader() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PatchReader(DateFormat[] dateFormats) {
/*  74 */     this();
/*  75 */     this.fDateFormats = dateFormats;
/*     */   }
/*     */   
/*     */   public void parse(BufferedReader reader) throws IOException {
/*  79 */     List<FilePatch2> diffs = new ArrayList<>();
/*  80 */     HashMap<String, DiffProject> diffProjects = new HashMap<>(4);
/*  81 */     boolean reread = false;
/*  82 */     String diffArgs = null;
/*  83 */     String fileName = null;
/*     */ 
/*     */     
/*  86 */     String projectName = "";
/*  87 */     this.fIsWorkspacePatch = false;
/*  88 */     this.fIsGitPatch = false;
/*     */     
/*  90 */     LineReader lr = new LineReader(reader);
/*  91 */     lr.ignoreSingleCR();
/*     */     
/*  93 */     String line = lr.readLine();
/*  94 */     if (line != null && line.startsWith("### Eclipse Workspace Patch")) {
/*  95 */       this.fIsWorkspacePatch = true;
/*     */     } else {
/*  97 */       parse(lr, line);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     while (true) {
/* 103 */       if (!reread)
/* 104 */         line = lr.readLine(); 
/* 105 */       reread = false;
/* 106 */       if (line == null)
/*     */         break; 
/* 108 */       if (line.length() < 4) {
/*     */         continue;
/*     */       }
/* 111 */       if (line.startsWith("#P")) {
/* 112 */         projectName = line.substring(2).trim();
/*     */         
/*     */         continue;
/*     */       } 
/* 116 */       if (line.startsWith("Index: ")) {
/* 117 */         fileName = line.substring(7).trim();
/*     */         continue;
/*     */       } 
/* 120 */       if (line.startsWith("diff")) {
/* 121 */         diffArgs = line.substring(4).trim();
/*     */         
/*     */         continue;
/*     */       } 
/* 125 */       if (line.startsWith("--- ")) {
/*     */         DiffProject diffProject;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 131 */         if (!diffProjects.containsKey(projectName)) {
/* 132 */           diffProject = new DiffProject(projectName);
/* 133 */           diffProjects.put(projectName, diffProject);
/*     */         } else {
/* 135 */           diffProject = diffProjects.get(projectName);
/*     */         } 
/*     */         
/* 138 */         line = readUnifiedDiff(diffs, lr, line, diffArgs, fileName, diffProject);
/* 139 */         diffArgs = fileName = null;
/* 140 */         reread = true;
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     lr.close();
/*     */     
/* 146 */     this.fDiffProjects = (DiffProject[])diffProjects.values().toArray((Object[])new DiffProject[diffProjects.size()]);
/* 147 */     this.fDiffs = diffs.<FilePatch2>toArray(new FilePatch2[diffs.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected FilePatch2 createFileDiff(IPath oldPath, long oldDate, IPath newPath, long newDate) {
/* 152 */     return new FilePatch2(oldPath, oldDate, newPath, newDate);
/*     */   }
/*     */   
/*     */   private String readUnifiedDiff(List<FilePatch2> diffs, LineReader lr, String line, String diffArgs, String fileName, DiffProject diffProject) throws IOException {
/* 156 */     List<FilePatch2> newDiffs = new ArrayList<>();
/* 157 */     String nextLine = readUnifiedDiff(newDiffs, lr, line, diffArgs, fileName);
/* 158 */     for (FilePatch2 diff : newDiffs) {
/* 159 */       diffProject.add(diff);
/* 160 */       diffs.add(diff);
/*     */     } 
/* 162 */     return nextLine;
/*     */   }
/*     */   
/*     */   public void parse(LineReader lr, String line) throws IOException {
/* 166 */     List<FilePatch2> diffs = new ArrayList<>();
/* 167 */     boolean reread = (line != null);
/* 168 */     String diffArgs = null;
/* 169 */     String fileName = null;
/* 170 */     List<String> headerLines = new ArrayList<>();
/* 171 */     boolean foundDiff = false;
/*     */ 
/*     */     
/*     */     while (true) {
/* 175 */       if (!reread)
/* 176 */         line = lr.readLine(); 
/* 177 */       reread = false;
/* 178 */       if (line == null) {
/*     */         break;
/*     */       }
/*     */       
/* 182 */       if (line.startsWith("Index: ")) {
/* 183 */         fileName = line.substring(7).trim();
/* 184 */       } else if (line.startsWith("diff")) {
/* 185 */         if (!foundDiff && GIT_PATCH_PATTERN.matcher(line).matches())
/* 186 */           this.fIsGitPatch = true; 
/* 187 */         foundDiff = true;
/* 188 */         diffArgs = line.substring(4).trim();
/* 189 */       } else if (line.startsWith("--- ")) {
/* 190 */         line = readUnifiedDiff(diffs, lr, line, diffArgs, fileName);
/* 191 */         if (!headerLines.isEmpty())
/* 192 */           setHeader(diffs.get(diffs.size() - 1), headerLines); 
/* 193 */         diffArgs = fileName = null;
/* 194 */         reread = true;
/* 195 */       } else if (line.startsWith("*** ")) {
/* 196 */         line = readContextDiff(diffs, lr, line, diffArgs, fileName);
/* 197 */         if (!headerLines.isEmpty())
/* 198 */           setHeader(diffs.get(diffs.size() - 1), headerLines); 
/* 199 */         diffArgs = fileName = null;
/* 200 */         reread = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 205 */       if (!reread) {
/* 206 */         headerLines.add(line);
/*     */       }
/*     */     } 
/*     */     
/* 210 */     lr.close();
/*     */     
/* 212 */     this.fDiffs = diffs.<FilePatch2>toArray(new FilePatch2[diffs.size()]);
/*     */   }
/*     */   
/*     */   private void setHeader(FilePatch2 diff, List<String> headerLines) {
/* 216 */     String header = LineReader.createString(false, headerLines);
/* 217 */     diff.setHeader(header);
/* 218 */     headerLines.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String readUnifiedDiff(List<FilePatch2> diffs, LineReader reader, String line, String args, String fileName) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_3
/*     */     //   2: iconst_4
/*     */     //   3: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   6: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   9: astore #6
/*     */     //   11: aload_2
/*     */     //   12: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   15: astore_3
/*     */     //   16: aload_3
/*     */     //   17: ifnull -> 30
/*     */     //   20: aload_3
/*     */     //   21: ldc_w '+++ '
/*     */     //   24: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   27: ifne -> 32
/*     */     //   30: aload_3
/*     */     //   31: areturn
/*     */     //   32: aload_0
/*     */     //   33: aload_3
/*     */     //   34: iconst_4
/*     */     //   35: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   38: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   41: astore #7
/*     */     //   43: aload_0
/*     */     //   44: aload_0
/*     */     //   45: aload #6
/*     */     //   47: iconst_0
/*     */     //   48: aload #5
/*     */     //   50: invokevirtual extractPath : ([Ljava/lang/String;ILjava/lang/String;)Lorg/eclipse/core/runtime/IPath;
/*     */     //   53: aload_0
/*     */     //   54: aload #6
/*     */     //   56: iconst_1
/*     */     //   57: invokevirtual extractDate : ([Ljava/lang/String;I)J
/*     */     //   60: aload_0
/*     */     //   61: aload #7
/*     */     //   63: iconst_0
/*     */     //   64: aload #5
/*     */     //   66: invokevirtual extractPath : ([Ljava/lang/String;ILjava/lang/String;)Lorg/eclipse/core/runtime/IPath;
/*     */     //   69: aload_0
/*     */     //   70: aload #7
/*     */     //   72: iconst_1
/*     */     //   73: invokevirtual extractDate : ([Ljava/lang/String;I)J
/*     */     //   76: invokevirtual createFileDiff : (Lorg/eclipse/core/runtime/IPath;JLorg/eclipse/core/runtime/IPath;J)Lorg/eclipse/compare/internal/core/patch/FilePatch2;
/*     */     //   79: astore #8
/*     */     //   81: aload_1
/*     */     //   82: aload #8
/*     */     //   84: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   89: pop
/*     */     //   90: iconst_2
/*     */     //   91: newarray int
/*     */     //   93: astore #9
/*     */     //   95: iconst_2
/*     */     //   96: newarray int
/*     */     //   98: astore #10
/*     */     //   100: iconst_m1
/*     */     //   101: istore #11
/*     */     //   103: iconst_m1
/*     */     //   104: istore #12
/*     */     //   106: new java/util/ArrayList
/*     */     //   109: dup
/*     */     //   110: invokespecial <init> : ()V
/*     */     //   113: astore #13
/*     */     //   115: iconst_0
/*     */     //   116: istore #14
/*     */     //   118: iconst_0
/*     */     //   119: istore #15
/*     */     //   121: iconst_0
/*     */     //   122: istore #16
/*     */     //   124: aload_2
/*     */     //   125: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   128: astore_3
/*     */     //   129: aload_3
/*     */     //   130: ifnonnull -> 163
/*     */     //   133: aload #13
/*     */     //   135: invokeinterface size : ()I
/*     */     //   140: ifle -> 161
/*     */     //   143: aload #8
/*     */     //   145: aload #9
/*     */     //   147: aload #10
/*     */     //   149: aload #13
/*     */     //   151: iload #14
/*     */     //   153: iload #15
/*     */     //   155: iload #16
/*     */     //   157: invokestatic createHunk : (Lorg/eclipse/compare/internal/core/patch/FilePatch2;[I[ILjava/util/List;ZZZ)Lorg/eclipse/compare/internal/core/patch/Hunk;
/*     */     //   160: pop
/*     */     //   161: aconst_null
/*     */     //   162: areturn
/*     */     //   163: aload_2
/*     */     //   164: aload_3
/*     */     //   165: invokevirtual lineContentLength : (Ljava/lang/String;)I
/*     */     //   168: ifne -> 174
/*     */     //   171: goto -> 124
/*     */     //   174: aload_3
/*     */     //   175: iconst_0
/*     */     //   176: invokevirtual charAt : (I)C
/*     */     //   179: istore #17
/*     */     //   181: iload #11
/*     */     //   183: ifne -> 239
/*     */     //   186: iload #12
/*     */     //   188: ifne -> 239
/*     */     //   191: iload #17
/*     */     //   193: bipush #64
/*     */     //   195: if_icmpeq -> 239
/*     */     //   198: iload #17
/*     */     //   200: bipush #92
/*     */     //   202: if_icmpeq -> 239
/*     */     //   205: aload_3
/*     */     //   206: astore #22
/*     */     //   208: aload #13
/*     */     //   210: invokeinterface size : ()I
/*     */     //   215: ifle -> 236
/*     */     //   218: aload #8
/*     */     //   220: aload #9
/*     */     //   222: aload #10
/*     */     //   224: aload #13
/*     */     //   226: iload #14
/*     */     //   228: iload #15
/*     */     //   230: iload #16
/*     */     //   232: invokestatic createHunk : (Lorg/eclipse/compare/internal/core/patch/FilePatch2;[I[ILjava/util/List;ZZZ)Lorg/eclipse/compare/internal/core/patch/Hunk;
/*     */     //   235: pop
/*     */     //   236: aload #22
/*     */     //   238: areturn
/*     */     //   239: iload #17
/*     */     //   241: lookupswitch default -> 624, 32 -> 402, 35 -> 582, 43 -> 423, 45 -> 441, 64 -> 324, 66 -> 611, 73 -> 585, 92 -> 459, 100 -> 598
/*     */     //   324: aload_3
/*     */     //   325: ldc_w '@@ '
/*     */     //   328: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   331: ifeq -> 624
/*     */     //   334: aload #13
/*     */     //   336: invokeinterface size : ()I
/*     */     //   341: ifle -> 369
/*     */     //   344: aload #8
/*     */     //   346: aload #9
/*     */     //   348: aload #10
/*     */     //   350: aload #13
/*     */     //   352: iload #14
/*     */     //   354: iload #15
/*     */     //   356: iload #16
/*     */     //   358: invokestatic createHunk : (Lorg/eclipse/compare/internal/core/patch/FilePatch2;[I[ILjava/util/List;ZZZ)Lorg/eclipse/compare/internal/core/patch/Hunk;
/*     */     //   361: pop
/*     */     //   362: aload #13
/*     */     //   364: invokeinterface clear : ()V
/*     */     //   369: aload_0
/*     */     //   370: aload_3
/*     */     //   371: bipush #45
/*     */     //   373: aload #9
/*     */     //   375: invokevirtual extractPair : (Ljava/lang/String;C[I)V
/*     */     //   378: aload_0
/*     */     //   379: aload_3
/*     */     //   380: bipush #43
/*     */     //   382: aload #10
/*     */     //   384: invokevirtual extractPair : (Ljava/lang/String;C[I)V
/*     */     //   387: aload #9
/*     */     //   389: iconst_1
/*     */     //   390: iaload
/*     */     //   391: istore #11
/*     */     //   393: aload #10
/*     */     //   395: iconst_1
/*     */     //   396: iaload
/*     */     //   397: istore #12
/*     */     //   399: goto -> 124
/*     */     //   402: iconst_1
/*     */     //   403: istore #16
/*     */     //   405: iinc #11, -1
/*     */     //   408: iinc #12, -1
/*     */     //   411: aload #13
/*     */     //   413: aload_3
/*     */     //   414: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   419: pop
/*     */     //   420: goto -> 124
/*     */     //   423: iconst_1
/*     */     //   424: istore #14
/*     */     //   426: iinc #12, -1
/*     */     //   429: aload #13
/*     */     //   431: aload_3
/*     */     //   432: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   437: pop
/*     */     //   438: goto -> 124
/*     */     //   441: iconst_1
/*     */     //   442: istore #15
/*     */     //   444: iinc #11, -1
/*     */     //   447: aload #13
/*     */     //   449: aload_3
/*     */     //   450: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   455: pop
/*     */     //   456: goto -> 124
/*     */     //   459: aload_3
/*     */     //   460: ldc_w 'newline at end'
/*     */     //   463: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   466: ifle -> 624
/*     */     //   469: aload #13
/*     */     //   471: invokeinterface size : ()I
/*     */     //   476: istore #18
/*     */     //   478: iload #18
/*     */     //   480: ifle -> 124
/*     */     //   483: aload #13
/*     */     //   485: iload #18
/*     */     //   487: iconst_1
/*     */     //   488: isub
/*     */     //   489: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   494: checkcast java/lang/String
/*     */     //   497: astore_3
/*     */     //   498: aload_3
/*     */     //   499: invokevirtual length : ()I
/*     */     //   502: iconst_1
/*     */     //   503: isub
/*     */     //   504: istore #19
/*     */     //   506: aload_3
/*     */     //   507: iload #19
/*     */     //   509: invokevirtual charAt : (I)C
/*     */     //   512: istore #20
/*     */     //   514: iload #20
/*     */     //   516: bipush #10
/*     */     //   518: if_icmpne -> 546
/*     */     //   521: iinc #19, -1
/*     */     //   524: iload #19
/*     */     //   526: ifle -> 556
/*     */     //   529: aload_3
/*     */     //   530: iload #19
/*     */     //   532: invokevirtual charAt : (I)C
/*     */     //   535: bipush #13
/*     */     //   537: if_icmpne -> 556
/*     */     //   540: iinc #19, -1
/*     */     //   543: goto -> 556
/*     */     //   546: iload #20
/*     */     //   548: bipush #13
/*     */     //   550: if_icmpne -> 556
/*     */     //   553: iinc #19, -1
/*     */     //   556: aload_3
/*     */     //   557: iconst_0
/*     */     //   558: iload #19
/*     */     //   560: iconst_1
/*     */     //   561: iadd
/*     */     //   562: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   565: astore_3
/*     */     //   566: aload #13
/*     */     //   568: iload #18
/*     */     //   570: iconst_1
/*     */     //   571: isub
/*     */     //   572: aload_3
/*     */     //   573: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   578: pop
/*     */     //   579: goto -> 124
/*     */     //   582: goto -> 624
/*     */     //   585: aload_3
/*     */     //   586: ldc_w 'Index:'
/*     */     //   589: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   592: ifne -> 598
/*     */     //   595: goto -> 624
/*     */     //   598: aload_3
/*     */     //   599: ldc_w 'diff '
/*     */     //   602: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   605: ifne -> 611
/*     */     //   608: goto -> 624
/*     */     //   611: aload_3
/*     */     //   612: ldc_w 'Binary files differ'
/*     */     //   615: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   618: ifne -> 624
/*     */     //   621: goto -> 624
/*     */     //   624: aload_3
/*     */     //   625: astore #22
/*     */     //   627: aload #13
/*     */     //   629: invokeinterface size : ()I
/*     */     //   634: ifle -> 655
/*     */     //   637: aload #8
/*     */     //   639: aload #9
/*     */     //   641: aload #10
/*     */     //   643: aload #13
/*     */     //   645: iload #14
/*     */     //   647: iload #15
/*     */     //   649: iload #16
/*     */     //   651: invokestatic createHunk : (Lorg/eclipse/compare/internal/core/patch/FilePatch2;[I[ILjava/util/List;ZZZ)Lorg/eclipse/compare/internal/core/patch/Hunk;
/*     */     //   654: pop
/*     */     //   655: aload #22
/*     */     //   657: areturn
/*     */     //   658: astore #21
/*     */     //   660: aload #13
/*     */     //   662: invokeinterface size : ()I
/*     */     //   667: ifle -> 688
/*     */     //   670: aload #8
/*     */     //   672: aload #9
/*     */     //   674: aload #10
/*     */     //   676: aload #13
/*     */     //   678: iload #14
/*     */     //   680: iload #15
/*     */     //   682: iload #16
/*     */     //   684: invokestatic createHunk : (Lorg/eclipse/compare/internal/core/patch/FilePatch2;[I[ILjava/util/List;ZZZ)Lorg/eclipse/compare/internal/core/patch/Hunk;
/*     */     //   687: pop
/*     */     //   688: aload #21
/*     */     //   690: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #226	-> 0
/*     */     //   #229	-> 11
/*     */     //   #230	-> 16
/*     */     //   #231	-> 30
/*     */     //   #233	-> 32
/*     */     //   #235	-> 43
/*     */     //   #236	-> 53
/*     */     //   #237	-> 69
/*     */     //   #235	-> 76
/*     */     //   #238	-> 81
/*     */     //   #240	-> 90
/*     */     //   #241	-> 95
/*     */     //   #242	-> 100
/*     */     //   #243	-> 103
/*     */     //   #244	-> 106
/*     */     //   #246	-> 115
/*     */     //   #247	-> 118
/*     */     //   #248	-> 121
/*     */     //   #254	-> 124
/*     */     //   #255	-> 129
/*     */     //   #342	-> 133
/*     */     //   #343	-> 143
/*     */     //   #256	-> 161
/*     */     //   #258	-> 163
/*     */     //   #261	-> 171
/*     */     //   #264	-> 174
/*     */     //   #265	-> 181
/*     */     //   #266	-> 205
/*     */     //   #342	-> 208
/*     */     //   #343	-> 218
/*     */     //   #266	-> 236
/*     */     //   #269	-> 239
/*     */     //   #271	-> 324
/*     */     //   #273	-> 334
/*     */     //   #274	-> 344
/*     */     //   #275	-> 362
/*     */     //   #279	-> 369
/*     */     //   #280	-> 378
/*     */     //   #281	-> 387
/*     */     //   #282	-> 393
/*     */     //   #283	-> 399
/*     */     //   #287	-> 402
/*     */     //   #288	-> 405
/*     */     //   #289	-> 408
/*     */     //   #290	-> 411
/*     */     //   #291	-> 420
/*     */     //   #293	-> 423
/*     */     //   #294	-> 426
/*     */     //   #295	-> 429
/*     */     //   #296	-> 438
/*     */     //   #298	-> 441
/*     */     //   #299	-> 444
/*     */     //   #300	-> 447
/*     */     //   #301	-> 456
/*     */     //   #303	-> 459
/*     */     //   #304	-> 469
/*     */     //   #305	-> 478
/*     */     //   #306	-> 483
/*     */     //   #307	-> 498
/*     */     //   #308	-> 506
/*     */     //   #309	-> 514
/*     */     //   #310	-> 521
/*     */     //   #311	-> 524
/*     */     //   #312	-> 540
/*     */     //   #313	-> 543
/*     */     //   #314	-> 553
/*     */     //   #316	-> 556
/*     */     //   #317	-> 566
/*     */     //   #319	-> 579
/*     */     //   #323	-> 582
/*     */     //   #325	-> 585
/*     */     //   #326	-> 595
/*     */     //   #329	-> 598
/*     */     //   #330	-> 608
/*     */     //   #333	-> 611
/*     */     //   #334	-> 621
/*     */     //   #339	-> 624
/*     */     //   #342	-> 627
/*     */     //   #343	-> 637
/*     */     //   #339	-> 655
/*     */     //   #341	-> 658
/*     */     //   #342	-> 660
/*     */     //   #343	-> 670
/*     */     //   #344	-> 688
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	691	0	this	Lorg/eclipse/compare/internal/core/patch/PatchReader;
/*     */     //   0	691	1	diffs	Ljava/util/List;
/*     */     //   0	691	2	reader	Lorg/eclipse/compare/internal/core/patch/LineReader;
/*     */     //   0	691	3	line	Ljava/lang/String;
/*     */     //   0	691	4	args	Ljava/lang/String;
/*     */     //   0	691	5	fileName	Ljava/lang/String;
/*     */     //   11	680	6	oldArgs	[Ljava/lang/String;
/*     */     //   43	648	7	newArgs	[Ljava/lang/String;
/*     */     //   81	610	8	diff	Lorg/eclipse/compare/internal/core/patch/FilePatch2;
/*     */     //   95	596	9	oldRange	[I
/*     */     //   100	591	10	newRange	[I
/*     */     //   103	588	11	remainingOld	I
/*     */     //   106	585	12	remainingNew	I
/*     */     //   115	576	13	lines	Ljava/util/List;
/*     */     //   118	573	14	encounteredPlus	Z
/*     */     //   121	570	15	encounteredMinus	Z
/*     */     //   124	567	16	encounteredSpace	Z
/*     */     //   181	477	17	c	C
/*     */     //   478	104	18	lastIndex	I
/*     */     //   506	73	19	end	I
/*     */     //   514	65	20	lc	C
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	691	1	diffs	Ljava/util/List<Lorg/eclipse/compare/internal/core/patch/FilePatch2;>;
/*     */     //   115	576	13	lines	Ljava/util/List<Ljava/lang/String;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   124	133	658	finally
/*     */     //   163	208	658	finally
/*     */     //   239	627	658	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readContextDiff(List<FilePatch2> diffs, LineReader reader, String line, String args, String fileName) throws IOException {
/* 352 */     String[] oldArgs = split(line.substring(4));
/*     */ 
/*     */     
/* 355 */     line = reader.readLine();
/* 356 */     if (line == null || !line.startsWith("--- ")) {
/* 357 */       return line;
/*     */     }
/* 359 */     String[] newArgs = split(line.substring(4));
/*     */     
/* 361 */     FilePatch2 diff = createFileDiff(extractPath(oldArgs, 0, fileName), 
/* 362 */         extractDate(oldArgs, 1), extractPath(newArgs, 0, fileName), 
/* 363 */         extractDate(newArgs, 1));
/* 364 */     diffs.add(diff);
/*     */     
/* 366 */     int[] oldRange = new int[2];
/* 367 */     int[] newRange = new int[2];
/* 368 */     List<String> oldLines = new ArrayList<>();
/* 369 */     List<String> newLines = new ArrayList<>();
/* 370 */     List<String> lines = oldLines;
/*     */ 
/*     */     
/* 373 */     boolean encounteredPlus = false;
/* 374 */     boolean encounteredMinus = false;
/* 375 */     boolean encounteredSpace = false;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true) {
/* 381 */         line = reader.readLine();
/* 382 */         if (line == null) {
/* 383 */           return line;
/*     */         }
/* 385 */         int l = line.length();
/* 386 */         if (l == 0)
/*     */           continue; 
/* 388 */         if (l > 1) {
/* 389 */           switch (line.charAt(0)) {
/*     */             case '*':
/* 391 */               if (line.startsWith("***************")) {
/*     */                 
/* 393 */                 if (oldLines.size() > 0 || newLines.size() > 0) {
/* 394 */                   Hunk.createHunk(diff, oldRange, newRange, unifyLines(oldLines, newLines), encounteredPlus, encounteredMinus, encounteredSpace);
/* 395 */                   oldLines.clear();
/* 396 */                   newLines.clear();
/*     */                 } 
/*     */                 continue;
/*     */               } 
/* 400 */               if (line.startsWith("*** ")) {
/*     */                 
/* 402 */                 extractPair(line, ' ', oldRange);
/* 403 */                 if (oldRange[0] == 0) {
/* 404 */                   oldRange[1] = 0;
/*     */                 } else {
/* 406 */                   oldRange[1] = oldRange[1] - oldRange[0] + 1;
/*     */                 } 
/* 408 */                 lines = oldLines;
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */             case ' ':
/* 413 */               if (line.charAt(1) == ' ') {
/* 414 */                 lines.add(line);
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */             case '+':
/* 419 */               if (line.charAt(1) == ' ') {
/* 420 */                 encounteredPlus = true;
/* 421 */                 lines.add(line);
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */             case '!':
/* 426 */               if (line.charAt(1) == ' ') {
/* 427 */                 encounteredSpace = true;
/* 428 */                 lines.add(line);
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */             case '-':
/* 433 */               if (line.charAt(1) == ' ') {
/* 434 */                 encounteredMinus = true;
/* 435 */                 lines.add(line);
/*     */                 continue;
/*     */               } 
/* 438 */               if (line.startsWith("--- ")) {
/*     */                 
/* 440 */                 extractPair(line, ' ', newRange);
/* 441 */                 if (newRange[0] == 0) {
/* 442 */                   newRange[1] = 0;
/*     */                 } else {
/* 444 */                   newRange[1] = newRange[1] - newRange[0] + 1;
/*     */                 } 
/* 446 */                 lines = newLines;
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */           } 
/*     */         }
/*     */         break;
/*     */       } 
/* 454 */       return line;
/*     */     }
/*     */     finally {
/*     */       
/* 458 */       if (oldLines.size() > 0 || newLines.size() > 0) {
/* 459 */         Hunk.createHunk(diff, oldRange, newRange, unifyLines(oldLines, newLines), encounteredPlus, encounteredMinus, encounteredSpace);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> unifyLines(List<String> oldLines, List<String> newLines) {
/* 468 */     List<String> result = new ArrayList<>();
/*     */     
/* 470 */     String[] ol = oldLines.<String>toArray(new String[oldLines.size()]);
/* 471 */     String[] nl = newLines.<String>toArray(new String[newLines.size()]);
/*     */     
/* 473 */     int oi = 0, ni = 0;
/*     */ 
/*     */     
/*     */     label86: while (true) {
/* 477 */       char oc = Character.MIN_VALUE;
/* 478 */       String o = null;
/* 479 */       if (oi < ol.length) {
/* 480 */         o = ol[oi];
/* 481 */         oc = o.charAt(0);
/*     */       } 
/*     */       
/* 484 */       char nc = Character.MIN_VALUE;
/* 485 */       String n = null;
/* 486 */       if (ni < nl.length) {
/* 487 */         n = nl[ni];
/* 488 */         nc = n.charAt(0);
/*     */       } 
/*     */ 
/*     */       
/* 492 */       if (oc == '\000' && nc == '\000') {
/*     */         break;
/*     */       }
/*     */       
/* 496 */       if (oc == '-') {
/*     */         while (true) {
/* 498 */           result.add(String.valueOf('-') + o.substring(2));
/* 499 */           oi++;
/* 500 */           if (oi >= ol.length)
/*     */             continue label86; 
/* 502 */           o = ol[oi];
/* 503 */           if (o.charAt(0) != '-') {
/*     */             continue label86;
/*     */           }
/*     */         } 
/*     */       }
/* 508 */       if (nc == '+') {
/*     */         while (true) {
/* 510 */           result.add(String.valueOf('+') + n.substring(2));
/* 511 */           ni++;
/* 512 */           if (ni >= nl.length)
/*     */             continue label86; 
/* 514 */           n = nl[ni];
/* 515 */           if (n.charAt(0) != '+') {
/*     */             continue label86;
/*     */           }
/*     */         } 
/*     */       }
/* 520 */       if (oc == '!' && nc == '!') {
/*     */         
/*     */         do {
/* 523 */           result.add(String.valueOf('-') + o.substring(2));
/* 524 */           oi++;
/* 525 */           if (oi >= ol.length)
/*     */             break; 
/* 527 */           o = ol[oi];
/* 528 */         } while (o.charAt(0) == '!');
/*     */ 
/*     */         
/*     */         while (true) {
/* 532 */           result.add(String.valueOf('+') + n.substring(2));
/* 533 */           ni++;
/* 534 */           if (ni >= nl.length)
/*     */             continue label86; 
/* 536 */           n = nl[ni];
/* 537 */           if (n.charAt(0) != '!') {
/*     */             continue label86;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 543 */       if (oc == ' ' && nc == ' ')
/*     */         while (true) {
/* 545 */           Assert.isTrue(o.equals(n), "non matching context lines");
/* 546 */           result.add(String.valueOf(' ') + o.substring(2));
/* 547 */           oi++;
/* 548 */           ni++;
/* 549 */           if (oi < ol.length) { if (ni >= nl.length)
/*     */               continue label86; 
/* 551 */             o = ol[oi];
/* 552 */             n = nl[ni];
/* 553 */             if (o.charAt(0) == ' ') { if (n.charAt(0) != ' ')
/*     */                 continue label86;  continue; }
/*     */              continue label86; }
/*     */            continue label86;
/* 557 */         }   if (oc == ' ')
/*     */         while (true) {
/* 559 */           result.add(String.valueOf(' ') + o.substring(2));
/* 560 */           oi++;
/* 561 */           if (oi >= ol.length)
/*     */             continue label86; 
/* 563 */           o = ol[oi];
/* 564 */           if (o.charAt(0) != ' ') {
/*     */             continue label86;
/*     */           }
/*     */         }  
/* 568 */       if (nc == ' ')
/*     */         while (true) {
/* 570 */           result.add(String.valueOf(' ') + n.substring(2));
/* 571 */           ni++;
/* 572 */           if (ni >= nl.length)
/*     */             continue label86; 
/* 574 */           n = nl[ni];
/* 575 */           if (n.charAt(0) != ' ') {
/*     */             continue label86;
/*     */           }
/*     */         }  
/* 579 */       Assert.isTrue(false, "unexpected char <" + oc + "> <" + nc + ">");
/*     */     } 
/*     */     
/* 582 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long extractDate(String[] args, int n) {
/* 590 */     if (n < args.length) {
/* 591 */       String line = args[n]; byte b; int i; DateFormat[] arrayOfDateFormat;
/* 592 */       for (i = (arrayOfDateFormat = this.fDateFormats).length, b = 0; b < i; ) { DateFormat dateFormat = arrayOfDateFormat[b];
/* 593 */         dateFormat.setLenient(true);
/*     */         try {
/* 595 */           Date date = dateFormat.parse(line);
/* 596 */           return date.getTime();
/* 597 */         } catch (ParseException parseException) {}
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/*     */     
/* 603 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath extractPath(String[] args, int n, String path2) {
/* 610 */     if (n < args.length) {
/* 611 */       String path = args[n];
/* 612 */       if ("/dev/null".equals(path))
/* 613 */         return null; 
/* 614 */       int pos = path.lastIndexOf(':');
/* 615 */       if (pos >= 0)
/* 616 */         path = path.substring(0, pos); 
/* 617 */       if (path2 != null && !path2.equals(path))
/*     */       {
/* 619 */         path = path2;
/*     */       }
/* 621 */       return (IPath)new Path(path);
/*     */     } 
/* 623 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void extractPair(String line, char start, int[] pair) {
/* 635 */     pair[1] = -1; pair[0] = -1;
/* 636 */     int startPos = line.indexOf(start);
/* 637 */     if (startPos < 0) {
/*     */       return;
/*     */     }
/*     */     
/* 641 */     line = line.substring(startPos + 1);
/* 642 */     int endPos = line.indexOf(' ');
/* 643 */     if (endPos < 0) {
/*     */       return;
/*     */     }
/*     */     
/* 647 */     line = line.substring(0, endPos);
/* 648 */     int comma = line.indexOf(',');
/* 649 */     if (comma >= 0) {
/* 650 */       pair[0] = Integer.parseInt(line.substring(0, comma));
/* 651 */       pair[1] = Integer.parseInt(line.substring(comma + 1));
/*     */     } else {
/* 653 */       pair[0] = Integer.parseInt(line);
/* 654 */       pair[1] = 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] split(String line) {
/* 663 */     List<String> l = new ArrayList<>();
/* 664 */     StringTokenizer st = new StringTokenizer(line, "\t");
/* 665 */     while (st.hasMoreElements()) {
/* 666 */       String token = st.nextToken().trim();
/* 667 */       if (token.length() > 0)
/* 668 */         l.add(token); 
/*     */     } 
/* 670 */     return l.<String>toArray(new String[l.size()]);
/*     */   }
/*     */   
/*     */   public boolean isWorkspacePatch() {
/* 674 */     return this.fIsWorkspacePatch;
/*     */   }
/*     */   
/*     */   public boolean isGitPatch() {
/* 678 */     return this.fIsGitPatch;
/*     */   }
/*     */   
/*     */   public DiffProject[] getDiffProjects() {
/* 682 */     return this.fDiffProjects;
/*     */   }
/*     */   
/*     */   public FilePatch2[] getDiffs() {
/* 686 */     return this.fDiffs;
/*     */   }
/*     */   
/*     */   public FilePatch2[] getAdjustedDiffs() {
/* 690 */     if (!isWorkspacePatch() || this.fDiffs.length == 0)
/* 691 */       return this.fDiffs; 
/* 692 */     List<FilePatch2> result = new ArrayList<>(); byte b; int i; FilePatch2[] arrayOfFilePatch2;
/* 693 */     for (i = (arrayOfFilePatch2 = this.fDiffs).length, b = 0; b < i; ) { FilePatch2 diff = arrayOfFilePatch2[b];
/* 694 */       result.add(diff.asRelativeDiff()); b++; }
/*     */     
/* 696 */     return result.<FilePatch2>toArray(new FilePatch2[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\PatchReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */