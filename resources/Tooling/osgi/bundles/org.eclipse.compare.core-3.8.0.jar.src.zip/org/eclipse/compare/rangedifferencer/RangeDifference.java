/*     */ package org.eclipse.compare.rangedifferencer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RangeDifference
/*     */ {
/*     */   public static final int NOCHANGE = 0;
/*     */   public static final int CHANGE = 2;
/*     */   public static final int CONFLICT = 1;
/*     */   public static final int RIGHT = 2;
/*     */   public static final int LEFT = 3;
/*     */   public static final int ANCESTOR = 4;
/*     */   public static final int ERROR = 5;
/*     */   protected int kind;
/*     */   protected int leftStart;
/*     */   protected int leftLength;
/*     */   protected int rightStart;
/*     */   protected int rightLength;
/*     */   protected int ancestorStart;
/*     */   protected int ancestorLength;
/*     */   
/*     */   protected RangeDifference(int changeKind) {
/* 108 */     this.kind = changeKind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RangeDifference(int kind, int rightStart, int rightLength, int leftStart, int leftLength) {
/* 128 */     this.kind = kind;
/* 129 */     this.rightStart = rightStart;
/* 130 */     this.rightLength = rightLength;
/* 131 */     this.leftStart = leftStart;
/* 132 */     this.leftLength = leftLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RangeDifference(int kind, int rightStart, int rightLength, int leftStart, int leftLength, int ancestorStart, int ancestorLength) {
/* 157 */     this(kind, rightStart, rightLength, leftStart, leftLength);
/* 158 */     this.ancestorStart = ancestorStart;
/* 159 */     this.ancestorLength = ancestorLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int kind() {
/* 170 */     return this.kind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ancestorStart() {
/* 179 */     return this.ancestorStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ancestorLength() {
/* 188 */     return this.ancestorLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ancestorEnd() {
/* 197 */     return this.ancestorStart + this.ancestorLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rightStart() {
/* 206 */     return this.rightStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rightLength() {
/* 215 */     return this.rightLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rightEnd() {
/* 224 */     return this.rightStart + this.rightLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int leftStart() {
/* 233 */     return this.leftStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int leftLength() {
/* 242 */     return this.leftLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int leftEnd() {
/* 251 */     return this.leftStart + this.leftLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxLength() {
/* 260 */     return Math.max(this.rightLength, Math.max(this.leftLength, this.ancestorLength));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 265 */     if (obj instanceof RangeDifference) {
/* 266 */       RangeDifference other = (RangeDifference)obj;
/* 267 */       return (this.kind == other.kind && 
/* 268 */         this.leftStart == other.leftStart && 
/* 269 */         this.leftLength == other.leftLength && 
/* 270 */         this.rightStart == other.rightStart && 
/* 271 */         this.rightLength == other.rightLength && 
/* 272 */         this.ancestorStart == other.ancestorStart && 
/* 273 */         this.ancestorLength == other.ancestorLength);
/*     */     } 
/* 275 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 281 */     int result = 1;
/* 282 */     result = 31 * result + this.kind;
/* 283 */     result = 31 * result + this.leftStart;
/* 284 */     result = 31 * result + this.leftLength;
/* 285 */     result = 31 * result + this.rightStart;
/* 286 */     result = 31 * result + this.rightLength;
/* 287 */     result = 31 * result + this.ancestorStart;
/* 288 */     result = 31 * result + this.ancestorLength;
/* 289 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 294 */     StringBuilder buf = new StringBuilder("RangeDifference {");
/* 295 */     switch (this.kind) {
/*     */       case 0:
/* 297 */         buf.append("NOCHANGE");
/*     */         break;
/*     */       case 2:
/* 300 */         buf.append("CHANGE/RIGHT");
/*     */         break;
/*     */       case 1:
/* 303 */         buf.append("CONFLICT");
/*     */         break;
/*     */       case 3:
/* 306 */         buf.append("LEFT");
/*     */         break;
/*     */       case 5:
/* 309 */         buf.append("ERROR");
/*     */         break;
/*     */       case 4:
/* 312 */         buf.append("ANCESTOR");
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 318 */     buf.append(", ");
/*     */     
/* 320 */     buf.append("Left: " + toRangeString(this.leftStart, this.leftLength) + " Right: " + toRangeString(this.rightStart, this.rightLength));
/* 321 */     if (this.ancestorLength > 0 || this.ancestorStart > 0) {
/* 322 */       buf.append(" Ancestor: " + toRangeString(this.ancestorStart, this.ancestorLength));
/*     */     }
/* 324 */     buf.append("}");
/* 325 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private String toRangeString(int start, int length) {
/* 329 */     return "(" + start + ", " + length + ")";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\RangeDifference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */