/*     */ package org.eclipse.compare.internal.core;
/*     */ 
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LCS
/*     */ {
/*     */   public static final double TOO_LONG = 1.0E8D;
/*     */   private static final double POW_LIMIT = 1.5D;
/*     */   private int max_differences;
/*     */   private int length;
/*     */   
/*     */   public void longestCommonSubsequence(SubMonitor subMonitor) {
/*  50 */     int length1 = getLength1();
/*  51 */     int length2 = getLength2();
/*  52 */     if (length1 == 0 || length2 == 0) {
/*  53 */       this.length = 0;
/*     */       
/*     */       return;
/*     */     } 
/*  57 */     this.max_differences = (length1 + length2 + 1) / 2;
/*  58 */     if (!isCappingDisabled() && length1 * length2 > 1.0E8D)
/*     */     {
/*  60 */       this.max_differences = (int)Math.pow(this.max_differences, 0.5D);
/*     */     }
/*     */     
/*  63 */     initializeLcs(length1);
/*     */     
/*  65 */     subMonitor.beginTask(null, length1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     int max = Math.min(length1, length2); int forwardBound;
/*  73 */     for (forwardBound = 0; forwardBound < max && 
/*  74 */       isRangeEqual(forwardBound, forwardBound); forwardBound++) {
/*  75 */       setLcs(forwardBound, forwardBound);
/*  76 */       worked(subMonitor, 1);
/*     */     } 
/*     */     
/*  79 */     int backBoundL1 = length1 - 1;
/*  80 */     int backBoundL2 = length2 - 1;
/*     */     
/*  82 */     while (backBoundL1 >= forwardBound && backBoundL2 >= forwardBound && 
/*  83 */       isRangeEqual(backBoundL1, backBoundL2)) {
/*  84 */       setLcs(backBoundL1, backBoundL2);
/*  85 */       backBoundL1--;
/*  86 */       backBoundL2--;
/*  87 */       worked(subMonitor, 1);
/*     */     } 
/*     */     
/*  90 */     this.length = forwardBound + 
/*  91 */       length1 - 
/*  92 */       backBoundL1 - 
/*  93 */       1 + 
/*  94 */       lcs_rec(forwardBound, backBoundL1, forwardBound, 
/*  95 */         backBoundL2, new int[2][length1 + length2 + 1], 
/*  96 */         new int[3], subMonitor);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isCappingDisabled() {
/* 101 */     return CompareSettings.getDefault().isCappingDisabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int lcs_rec(int bottoml1, int topl1, int bottoml2, int topl2, int[][] V, int[] snake, SubMonitor subMonitor) {
/* 132 */     if (bottoml1 > topl1 || bottoml2 > topl2) {
/* 133 */       return 0;
/*     */     }
/*     */     
/* 136 */     int d = find_middle_snake(bottoml1, topl1, bottoml2, topl2, V, snake, subMonitor);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     int len = snake[2];
/* 142 */     int startx = snake[0];
/* 143 */     int starty = snake[1];
/*     */ 
/*     */     
/* 146 */     for (int i = 0; i < len; i++) {
/* 147 */       setLcs(startx + i, starty + i);
/* 148 */       worked(subMonitor, 1);
/*     */     } 
/*     */     
/* 151 */     if (d > 1)
/* 152 */       return len + 
/* 153 */         lcs_rec(bottoml1, startx - 1, bottoml2, starty - 1, V, snake, subMonitor) + 
/* 154 */         lcs_rec(startx + len, topl1, starty + len, topl2, V, snake, subMonitor); 
/* 155 */     if (d == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       int max = Math.min(startx - bottoml1, starty - bottoml2);
/* 162 */       for (int j = 0; j < max; j++) {
/* 163 */         setLcs(bottoml1 + j, bottoml2 + j);
/* 164 */         worked(subMonitor, 1);
/*     */       } 
/* 166 */       return max + len;
/*     */     } 
/*     */     
/* 169 */     return len;
/*     */   }
/*     */   
/*     */   private void worked(SubMonitor subMonitor, int work) {
/* 173 */     if (subMonitor.isCanceled())
/* 174 */       throw new OperationCanceledException(); 
/* 175 */     subMonitor.worked(work);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int find_middle_snake(int bottoml1, int topl1, int bottoml2, int topl2, int[][] V, int[] snake, SubMonitor subMonitor) {
/*     */     boolean isEven;
/* 204 */     int value_to_add_forward, value_to_add_backward, N = topl1 - bottoml1 + 1;
/* 205 */     int M = topl2 - bottoml2 + 1;
/*     */ 
/*     */ 
/*     */     
/* 209 */     int delta = N - M;
/*     */     
/* 211 */     if ((delta & 0x1) == 1) {
/* 212 */       isEven = false;
/*     */     } else {
/* 214 */       isEven = true;
/*     */     } 
/*     */     
/* 217 */     int limit = Math.min(this.max_differences, (N + M + 1) / 2);
/*     */ 
/*     */ 
/*     */     
/* 221 */     if ((M & 0x1) == 1) {
/* 222 */       value_to_add_forward = 1;
/*     */     } else {
/* 224 */       value_to_add_forward = 0;
/*     */     } 
/*     */ 
/*     */     
/* 228 */     if ((N & 0x1) == 1) {
/* 229 */       value_to_add_backward = 1;
/*     */     } else {
/* 231 */       value_to_add_backward = 0;
/*     */     } 
/*     */     
/* 234 */     int start_forward = -M;
/* 235 */     int end_forward = N;
/* 236 */     int start_backward = -N;
/* 237 */     int end_backward = M;
/*     */     
/* 239 */     V[0][limit + 1] = 0;
/* 240 */     V[1][limit - 1] = N;
/* 241 */     for (int d = 0; d <= limit; d++) {
/*     */       
/* 243 */       int start_diag = Math.max(value_to_add_forward + start_forward, -d);
/* 244 */       int end_diag = Math.min(end_forward, d);
/* 245 */       value_to_add_forward = 1 - value_to_add_forward;
/*     */       
/*     */       int k;
/* 248 */       for (k = start_diag; k <= end_diag; k += 2) {
/*     */         int x;
/* 250 */         if (k == -d || (
/* 251 */           k < d && V[0][limit + k - 1] < V[0][limit + k + 1])) {
/* 252 */           x = V[0][limit + k + 1];
/*     */         } else {
/* 254 */           x = V[0][limit + k - 1] + 1;
/*     */         } 
/*     */         
/* 257 */         int y = x - k;
/*     */         
/* 259 */         snake[0] = x + bottoml1;
/* 260 */         snake[1] = y + bottoml2;
/* 261 */         snake[2] = 0;
/*     */ 
/*     */         
/* 264 */         while (x < N && y < M && 
/* 265 */           isRangeEqual(x + bottoml1, y + bottoml2)) {
/* 266 */           x++;
/* 267 */           y++;
/* 268 */           snake[2] = snake[2] + 1;
/*     */         } 
/* 270 */         V[0][limit + k] = x;
/*     */ 
/*     */         
/* 273 */         if (!isEven && k >= delta - d + 1 && k <= delta + d - 1 && 
/* 274 */           x >= V[1][limit + k - delta])
/*     */         {
/* 276 */           return 2 * d - 1;
/*     */         }
/*     */ 
/*     */         
/* 280 */         if (x >= N && end_forward > k - 1) {
/* 281 */           end_forward = k - 1;
/* 282 */         } else if (y >= M) {
/* 283 */           start_forward = k + 1;
/* 284 */           value_to_add_forward = 0;
/*     */         } 
/*     */       } 
/*     */       
/* 288 */       start_diag = Math.max(value_to_add_backward + start_backward, -d);
/* 289 */       end_diag = Math.min(end_backward, d);
/* 290 */       value_to_add_backward = 1 - value_to_add_backward;
/*     */ 
/*     */       
/* 293 */       for (k = start_diag; k <= end_diag; k += 2) {
/*     */         int x;
/* 295 */         if (k == d || (
/* 296 */           k != -d && V[1][limit + k - 1] < V[1][limit + k + 1])) {
/* 297 */           x = V[1][limit + k - 1];
/*     */         } else {
/* 299 */           x = V[1][limit + k + 1] - 1;
/*     */         } 
/*     */         
/* 302 */         int y = x - k - delta;
/*     */         
/* 304 */         snake[2] = 0;
/*     */ 
/*     */         
/* 307 */         while (x > 0 && y > 0 && 
/* 308 */           isRangeEqual(x - 1 + bottoml1, y - 1 + bottoml2)) {
/* 309 */           x--;
/* 310 */           y--;
/* 311 */           snake[2] = snake[2] + 1;
/*     */         } 
/* 313 */         V[1][limit + k] = x;
/*     */         
/* 315 */         if (isEven && k >= -delta - d && k <= d - delta && 
/* 316 */           x <= V[0][limit + k + delta]) {
/*     */           
/* 318 */           snake[0] = bottoml1 + x;
/* 319 */           snake[1] = bottoml2 + y;
/*     */           
/* 321 */           return 2 * d;
/*     */         } 
/*     */ 
/*     */         
/* 325 */         if (x <= 0) {
/* 326 */           start_backward = k + 1;
/* 327 */           value_to_add_backward = 0;
/* 328 */         } else if (y <= 0 && end_backward > k - 1) {
/* 329 */           end_backward = k - 1;
/*     */         } 
/*     */       } 
/* 332 */       worked(subMonitor, 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     int[] most_progress = findMostProgress(M, N, limit, V);
/*     */     
/* 343 */     snake[0] = bottoml1 + most_progress[0];
/* 344 */     snake[1] = bottoml2 + most_progress[1];
/* 345 */     snake[2] = 0;
/* 346 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] findMostProgress(int M, int N, int limit, int[][] V) {
/* 373 */     int forward_start_diag, backward_start_diag, delta = N - M;
/*     */ 
/*     */     
/* 376 */     if ((M & 0x1) == (limit & 0x1)) {
/* 377 */       forward_start_diag = Math.max(-M, -limit);
/*     */     } else {
/* 379 */       forward_start_diag = Math.max(1 - M, -limit);
/*     */     } 
/*     */     
/* 382 */     int forward_end_diag = Math.min(N, limit);
/*     */ 
/*     */     
/* 385 */     if ((N & 0x1) == (limit & 0x1)) {
/* 386 */       backward_start_diag = Math.max(-N, -limit);
/*     */     } else {
/* 388 */       backward_start_diag = Math.max(1 - N, -limit);
/*     */     } 
/*     */     
/* 391 */     int backward_end_diag = Math.min(M, limit);
/*     */     
/* 393 */     int[][] max_progress = new int[Math.max(forward_end_diag - 
/* 394 */           forward_start_diag, backward_end_diag - backward_start_diag) / 2 + 1][3];
/* 395 */     int num_progress = 0;
/*     */ 
/*     */ 
/*     */     
/* 399 */     for (int k = forward_start_diag; k <= forward_end_diag; k += 2) {
/* 400 */       int x = V[0][limit + k];
/* 401 */       int y = x - k;
/* 402 */       if (x <= N && y <= M) {
/*     */ 
/*     */ 
/*     */         
/* 406 */         int progress = x + y;
/* 407 */         if (progress > max_progress[0][2]) {
/* 408 */           num_progress = 0;
/* 409 */           max_progress[0][0] = x;
/* 410 */           max_progress[0][1] = y;
/* 411 */           max_progress[0][2] = progress;
/* 412 */         } else if (progress == max_progress[0][2]) {
/* 413 */           num_progress++;
/* 414 */           max_progress[num_progress][0] = x;
/* 415 */           max_progress[num_progress][1] = y;
/* 416 */           max_progress[num_progress][2] = progress;
/*     */         } 
/*     */       } 
/*     */     } 
/* 420 */     boolean max_progress_forward = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 425 */     for (int i = backward_start_diag; i <= backward_end_diag; i += 2) {
/* 426 */       int x = V[1][limit + i];
/* 427 */       int y = x - i - delta;
/* 428 */       if (x >= 0 && y >= 0) {
/*     */ 
/*     */ 
/*     */         
/* 432 */         int progress = N - x + M - y;
/* 433 */         if (progress > max_progress[0][2]) {
/* 434 */           num_progress = 0;
/* 435 */           max_progress_forward = false;
/* 436 */           max_progress[0][0] = x;
/* 437 */           max_progress[0][1] = y;
/* 438 */           max_progress[0][2] = progress;
/* 439 */         } else if (progress == max_progress[0][2] && !max_progress_forward) {
/* 440 */           num_progress++;
/* 441 */           max_progress[num_progress][0] = x;
/* 442 */           max_progress[num_progress][1] = y;
/* 443 */           max_progress[num_progress][2] = progress;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 448 */     return max_progress[num_progress / 2];
/*     */   }
/*     */   
/*     */   protected abstract int getLength2();
/*     */   
/*     */   protected abstract int getLength1();
/*     */   
/*     */   protected abstract boolean isRangeEqual(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void setLcs(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void initializeLcs(int paramInt);
/*     */   
/*     */   public int getLength() {
/* 462 */     return this.length;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\LCS.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */