/*    */ package org.eclipse.compare.rangedifferencer;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DifferencesIterator
/*    */ {
/*    */   List<RangeDifference> fRange;
/*    */   int fIndex;
/*    */   RangeDifference[] fArray;
/*    */   RangeDifference fDifference;
/*    */   
/*    */   DifferencesIterator(RangeDifference[] differenceRanges) {
/* 35 */     this.fArray = differenceRanges;
/* 36 */     this.fIndex = 0;
/* 37 */     this.fRange = new ArrayList<>();
/* 38 */     if (this.fIndex < this.fArray.length) {
/* 39 */       this.fDifference = this.fArray[this.fIndex++];
/*    */     } else {
/* 41 */       this.fDifference = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   int getCount() {
/* 48 */     return this.fRange.size();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void next() {
/* 55 */     this.fRange.add(this.fDifference);
/* 56 */     if (this.fDifference != null) {
/* 57 */       if (this.fIndex < this.fArray.length) {
/* 58 */         this.fDifference = this.fArray[this.fIndex++];
/*    */       } else {
/* 60 */         this.fDifference = null;
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DifferencesIterator other(DifferencesIterator right, DifferencesIterator left) {
/* 69 */     if (this == right)
/* 70 */       return left; 
/* 71 */     return right;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void removeAll() {
/* 78 */     this.fRange.clear();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\DifferencesIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */