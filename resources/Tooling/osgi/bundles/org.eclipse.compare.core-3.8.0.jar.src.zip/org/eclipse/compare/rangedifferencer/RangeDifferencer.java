/*     */ package org.eclipse.compare.rangedifferencer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.internal.core.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RangeDifferencer
/*     */ {
/*  43 */   private static final RangeDifference[] EMPTY_RESULT = new RangeDifference[0];
/*     */   
/*  45 */   private static final AbstractRangeDifferenceFactory defaultFactory = new AbstractRangeDifferenceFactory()
/*     */     {
/*     */       protected RangeDifference createRangeDifference() {
/*  48 */         return new RangeDifference(0);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(IRangeComparator left, IRangeComparator right) {
/*  69 */     return findDifferences((IProgressMonitor)null, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(IProgressMonitor pm, IRangeComparator left, IRangeComparator right) {
/*  84 */     return findDifferences(defaultFactory, (IProgressMonitor)null, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(AbstractRangeDifferenceFactory factory, IProgressMonitor pm, IRangeComparator left, IRangeComparator right) {
/* 100 */     return RangeComparatorLCS.findDifferences(factory, pm, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/* 116 */     return findDifferences((IProgressMonitor)null, ancestor, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(IProgressMonitor pm, IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/* 134 */     return findDifferences(defaultFactory, pm, ancestor, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findDifferences(AbstractRangeDifferenceFactory factory, IProgressMonitor pm, IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/*     */     try {
/* 154 */       if (ancestor == null)
/* 155 */         return findDifferences(factory, pm, left, right); 
/* 156 */       SubMonitor monitor = SubMonitor.convert(pm, Messages.RangeComparatorLCS_0, 100);
/* 157 */       RangeDifference[] leftAncestorScript = null;
/* 158 */       RangeDifference[] rightAncestorScript = findDifferences(factory, (IProgressMonitor)monitor.newChild(50), ancestor, right);
/* 159 */       if (rightAncestorScript != null) {
/* 160 */         monitor.setWorkRemaining(100);
/* 161 */         leftAncestorScript = findDifferences(factory, (IProgressMonitor)monitor.newChild(50), ancestor, left);
/*     */       } 
/* 163 */       if (rightAncestorScript == null || leftAncestorScript == null) {
/* 164 */         return null;
/*     */       }
/* 166 */       DifferencesIterator myIter = new DifferencesIterator(rightAncestorScript);
/* 167 */       DifferencesIterator yourIter = new DifferencesIterator(leftAncestorScript);
/*     */       
/* 169 */       List<RangeDifference> diff3 = new ArrayList<>();
/* 170 */       diff3.add(factory.createRangeDifference(5));
/*     */       
/* 172 */       int changeRangeStart = 0;
/* 173 */       int changeRangeEnd = 0;
/*     */ 
/*     */ 
/*     */       
/* 177 */       monitor.setWorkRemaining(rightAncestorScript.length + leftAncestorScript.length);
/* 178 */       while (myIter.fDifference != null || yourIter.fDifference != null) {
/*     */         DifferencesIterator startThread;
/*     */         
/* 181 */         myIter.removeAll();
/* 182 */         yourIter.removeAll();
/*     */ 
/*     */ 
/*     */         
/* 186 */         if (myIter.fDifference == null) {
/* 187 */           startThread = yourIter;
/* 188 */         } else if (yourIter.fDifference == null) {
/* 189 */           startThread = myIter;
/*     */         }
/* 191 */         else if (myIter.fDifference.leftStart < yourIter.fDifference.leftStart) {
/* 192 */           startThread = myIter;
/* 193 */         } else if (myIter.fDifference.leftStart > yourIter.fDifference.leftStart) {
/* 194 */           startThread = yourIter;
/*     */         } else {
/* 196 */           if (myIter.fDifference.leftLength == 0 && yourIter.fDifference.leftLength == 0) {
/*     */             
/* 198 */             changeRangeStart = myIter.fDifference.leftStart;
/* 199 */             changeRangeEnd = myIter.fDifference.leftEnd();
/* 200 */             myIter.next();
/* 201 */             yourIter.next();
/* 202 */             diff3.add(createRangeDifference3(factory, myIter, yourIter, diff3, right, left, changeRangeStart, changeRangeEnd)); continue;
/*     */           } 
/* 204 */           if (myIter.fDifference.leftLength == 0) {
/*     */             
/* 206 */             startThread = myIter;
/* 207 */           } else if (yourIter.fDifference.leftLength == 0) {
/* 208 */             startThread = yourIter;
/*     */           } else {
/*     */             
/* 211 */             startThread = myIter;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 216 */         changeRangeStart = startThread.fDifference.leftStart;
/* 217 */         changeRangeEnd = startThread.fDifference.leftEnd();
/*     */         
/* 219 */         startThread.next();
/* 220 */         monitor.worked(1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 225 */         DifferencesIterator other = startThread.other(myIter, yourIter);
/* 226 */         while (other.fDifference != null && other.fDifference.leftStart < changeRangeEnd) {
/* 227 */           int newMax = other.fDifference.leftEnd();
/* 228 */           other.next();
/* 229 */           monitor.worked(1);
/* 230 */           if (newMax > changeRangeEnd) {
/* 231 */             changeRangeEnd = newMax;
/* 232 */             other = other.other(myIter, yourIter);
/*     */           } 
/*     */         } 
/* 235 */         diff3.add(createRangeDifference3(factory, myIter, yourIter, diff3, right, left, changeRangeStart, changeRangeEnd));
/*     */       } 
/*     */ 
/*     */       
/* 239 */       diff3.remove(0);
/* 240 */       return diff3.<RangeDifference>toArray(EMPTY_RESULT);
/*     */     } finally {
/* 242 */       if (pm != null) {
/* 243 */         pm.done();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(IRangeComparator left, IRangeComparator right) {
/* 258 */     return findRanges((IProgressMonitor)null, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(IProgressMonitor pm, IRangeComparator left, IRangeComparator right) {
/* 273 */     return findRanges(defaultFactory, pm, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(AbstractRangeDifferenceFactory factory, IProgressMonitor pm, IRangeComparator left, IRangeComparator right) {
/* 289 */     RangeDifference[] in = findDifferences(factory, pm, left, right);
/* 290 */     List<RangeDifference> out = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 294 */     int mstart = 0;
/* 295 */     int ystart = 0; byte b; int i;
/*     */     RangeDifference[] arrayOfRangeDifference1;
/* 297 */     for (i = (arrayOfRangeDifference1 = in).length, b = 0; b < i; ) { RangeDifference es = arrayOfRangeDifference1[b];
/* 298 */       RangeDifference rangeDifference1 = factory.createRangeDifference(0, mstart, es.rightStart() - mstart, ystart, es.leftStart() - ystart);
/* 299 */       if (rangeDifference1.maxLength() != 0) {
/* 300 */         out.add(rangeDifference1);
/*     */       }
/* 302 */       out.add(es);
/*     */       
/* 304 */       mstart = es.rightEnd();
/* 305 */       ystart = es.leftEnd(); b++; }
/*     */     
/* 307 */     RangeDifference rd = factory.createRangeDifference(0, mstart, right.getRangeCount() - mstart, ystart, left.getRangeCount() - ystart);
/* 308 */     if (rd.maxLength() > 0) {
/* 309 */       out.add(rd);
/*     */     }
/* 311 */     return out.<RangeDifference>toArray(EMPTY_RESULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/* 327 */     return findRanges((IProgressMonitor)null, ancestor, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(IProgressMonitor pm, IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/* 345 */     return findRanges(defaultFactory, pm, ancestor, left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RangeDifference[] findRanges(AbstractRangeDifferenceFactory factory, IProgressMonitor pm, IRangeComparator ancestor, IRangeComparator left, IRangeComparator right) {
/* 364 */     if (ancestor == null) {
/* 365 */       return findRanges(factory, pm, left, right);
/*     */     }
/* 367 */     RangeDifference[] in = findDifferences(factory, pm, ancestor, left, right);
/* 368 */     List<RangeDifference> out = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 372 */     int mstart = 0;
/* 373 */     int ystart = 0;
/* 374 */     int astart = 0; byte b; int i;
/*     */     RangeDifference[] arrayOfRangeDifference1;
/* 376 */     for (i = (arrayOfRangeDifference1 = in).length, b = 0; b < i; ) { RangeDifference es = arrayOfRangeDifference1[b];
/* 377 */       RangeDifference rangeDifference1 = factory.createRangeDifference(0, mstart, es.rightStart() - mstart, ystart, es.leftStart() - ystart, astart, es.ancestorStart() - astart);
/* 378 */       if (rangeDifference1.maxLength() > 0) {
/* 379 */         out.add(rangeDifference1);
/*     */       }
/* 381 */       out.add(es);
/*     */       
/* 383 */       mstart = es.rightEnd();
/* 384 */       ystart = es.leftEnd();
/* 385 */       astart = es.ancestorEnd(); b++; }
/*     */     
/* 387 */     RangeDifference rd = factory.createRangeDifference(0, mstart, right.getRangeCount() - mstart, ystart, left.getRangeCount() - ystart, astart, ancestor.getRangeCount() - astart);
/* 388 */     if (rd.maxLength() > 0) {
/* 389 */       out.add(rd);
/*     */     }
/* 391 */     return out.<RangeDifference>toArray(EMPTY_RESULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static RangeDifference createRangeDifference3(AbstractRangeDifferenceFactory configurator, DifferencesIterator myIter, DifferencesIterator yourIter, List<RangeDifference> diff3, IRangeComparator right, IRangeComparator left, int changeRangeStart, int changeRangeEnd) {
/* 405 */     int rightStart, rightEnd, leftStart, leftEnd, kind = 5;
/* 406 */     RangeDifference last = diff3.get(diff3.size() - 1);
/*     */     
/* 408 */     Assert.isTrue(!(myIter.getCount() == 0 && yourIter.getCount() == 0));
/*     */ 
/*     */ 
/*     */     
/* 412 */     if (myIter.getCount() == 0) {
/* 413 */       rightStart = changeRangeStart - last.ancestorEnd() + last.rightEnd();
/* 414 */       rightEnd = changeRangeEnd - last.ancestorEnd() + last.rightEnd();
/* 415 */       kind = 3;
/*     */     } else {
/* 417 */       RangeDifference f = myIter.fRange.get(0);
/* 418 */       RangeDifference l = myIter.fRange.get(myIter.fRange.size() - 1);
/* 419 */       rightStart = changeRangeStart - f.leftStart + f.rightStart;
/* 420 */       rightEnd = changeRangeEnd - l.leftEnd() + l.rightEnd();
/*     */     } 
/*     */     
/* 423 */     if (yourIter.getCount() == 0) {
/* 424 */       leftStart = changeRangeStart - last.ancestorEnd() + last.leftEnd();
/* 425 */       leftEnd = changeRangeEnd - last.ancestorEnd() + last.leftEnd();
/* 426 */       kind = 2;
/*     */     } else {
/* 428 */       RangeDifference f = yourIter.fRange.get(0);
/* 429 */       RangeDifference l = yourIter.fRange.get(yourIter.fRange.size() - 1);
/* 430 */       leftStart = changeRangeStart - f.leftStart + f.rightStart;
/* 431 */       leftEnd = changeRangeEnd - l.leftEnd() + l.rightEnd();
/*     */     } 
/*     */     
/* 434 */     if (kind == 5)
/* 435 */       if (rangeSpansEqual(right, rightStart, rightEnd - rightStart, left, leftStart, leftEnd - leftStart)) {
/* 436 */         kind = 4;
/*     */       } else {
/* 438 */         kind = 1;
/*     */       }  
/* 440 */     return configurator.createRangeDifference(kind, rightStart, rightEnd - rightStart, leftStart, leftEnd - leftStart, changeRangeStart, changeRangeEnd - changeRangeStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean rangeSpansEqual(IRangeComparator right, int rightStart, int rightLen, IRangeComparator left, int leftStart, int leftLen) {
/* 447 */     if (rightLen == leftLen) {
/* 448 */       int i = 0;
/* 449 */       for (i = 0; i < rightLen && 
/* 450 */         rangesEqual(right, rightStart + i, left, leftStart + i); i++);
/*     */ 
/*     */       
/* 453 */       if (i == rightLen)
/* 454 */         return true; 
/*     */     } 
/* 456 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean rangesEqual(IRangeComparator a, int ai, IRangeComparator b, int bi) {
/* 463 */     return a.rangesEqual(ai, b, bi);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\RangeDifferencer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */