/*    */ package org.eclipse.compare.patch;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.compare.internal.core.patch.PatchReader;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PatchParser
/*    */ {
/*    */   public static IFilePatch2[] parsePatch(ReaderCreator content) throws CoreException {
/* 44 */     BufferedReader reader = new BufferedReader(content.createReader());
/*    */     try {
/* 46 */       PatchReader patchReader = new PatchReader();
/* 47 */       patchReader.parse(reader);
/* 48 */       return (IFilePatch2[])patchReader.getAdjustedDiffs();
/* 49 */     } catch (IOException e) {
/* 50 */       throw new CoreException(new Status(4, 
/* 51 */             "org.eclipse.compare.core", 0, e.getMessage(), e));
/*    */     } finally {
/*    */       try {
/* 54 */         reader.close();
/* 55 */       } catch (IOException iOException) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\patch\PatchParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */