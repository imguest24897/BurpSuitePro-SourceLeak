/*    */ package org.eclipse.compare.internal.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompareSettings
/*    */ {
/*    */   public static final String PLUGIN_ID = "org.eclipse.compare.core";
/*    */   private static CompareSettings compareSettings;
/*    */   private boolean cappingDisabled;
/*    */   
/*    */   public static CompareSettings getDefault() {
/* 42 */     if (compareSettings == null) {
/* 43 */       compareSettings = new CompareSettings();
/*    */     }
/* 45 */     return compareSettings;
/*    */   }
/*    */   
/*    */   public void setCappingDisabled(boolean disable) {
/* 49 */     this.cappingDisabled = disable;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCappingDisabled() {
/* 54 */     return this.cappingDisabled;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\CompareSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */