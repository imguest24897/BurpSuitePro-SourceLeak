/*     */ package org.eclipse.compare.patch;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import org.eclipse.compare.internal.core.patch.FilePatch2;
/*     */ import org.eclipse.compare.internal.core.patch.Hunk;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatchBuilder
/*     */ {
/*     */   public static final char CONTEXT_PREFIX = ' ';
/*     */   public static final char ADDITION_PREFIX = '+';
/*     */   public static final char REMOVAL_PREFIX = '-';
/*     */   
/*     */   public static IHunk createHunk(int start, String[] lines) {
/*  66 */     int type = getHunkType(lines);
/*  67 */     int oldLength = getHunkLength(lines, true);
/*  68 */     int newLength = getHunkLength(lines, false);
/*  69 */     return (IHunk)new Hunk(null, type, start, oldLength, start, newLength, lines);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilePatch2 createFilePatch(IPath oldPath, long oldDate, IPath newPath, long newDate, IHunk[] hunks) {
/*  95 */     reorder(hunks);
/*  96 */     FilePatch2 fileDiff = new FilePatch2(oldPath, oldDate, newPath, newDate); byte b; int i; IHunk[] arrayOfIHunk;
/*  97 */     for (i = (arrayOfIHunk = hunks).length, b = 0; b < i; ) { IHunk hunk = arrayOfIHunk[b];
/*  98 */       fileDiff.add((Hunk)hunk); b++; }
/*     */     
/* 100 */     return (IFilePatch2)fileDiff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilePatch2 addHunks(IFilePatch2 filePatch, IHunk[] toAdd) {
/* 117 */     IHunk[] result = addHunks(filePatch.getHunks(), toAdd);
/* 118 */     reorder(result);
/* 119 */     return createFilePatch(filePatch, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilePatch2 removeHunks(IFilePatch2 filePatch, IHunk[] toRemove) {
/* 137 */     IHunk[] result = removeHunks(filePatch.getHunks(), toRemove);
/* 138 */     reorder(result);
/* 139 */     return createFilePatch(filePatch, result);
/*     */   }
/*     */ 
/*     */   
/*     */   private static IFilePatch2 createFilePatch(IFilePatch2 filePatch, IHunk[] hunks) {
/* 144 */     PatchConfiguration config = new PatchConfiguration();
/* 145 */     IPath beforePath = filePatch.getTargetPath(config);
/* 146 */     config.setReversed(true);
/* 147 */     IPath afterPath = filePatch.getTargetPath(config);
/* 148 */     return createFilePatch(beforePath, filePatch.getBeforeDate(), 
/* 149 */         afterPath, filePatch.getAfterDate(), hunks);
/*     */   }
/*     */   
/*     */   private static int getHunkType(String[] lines) {
/* 153 */     boolean hasContextLines = checkForPrefix(' ', lines);
/* 154 */     if (!hasContextLines) {
/* 155 */       boolean hasLineAdditions = checkForPrefix('+', lines);
/* 156 */       boolean hasLineDeletions = checkForPrefix('-', lines);
/* 157 */       if (hasLineAdditions && !hasLineDeletions)
/* 158 */         return 1; 
/* 159 */       if (!hasLineAdditions && hasLineDeletions) {
/* 160 */         return 2;
/*     */       }
/*     */     } 
/* 163 */     return 3;
/*     */   }
/*     */   
/*     */   private static int getHunkLength(String[] lines, boolean old) {
/* 167 */     int length = 0; byte b; int i; String[] arrayOfString;
/* 168 */     for (i = (arrayOfString = lines).length, b = 0; b < i; ) { String line = arrayOfString[b];
/* 169 */       if (line.length() > 0)
/* 170 */         switch (line.charAt(0)) {
/*     */           case ' ':
/* 172 */             length++;
/*     */             break;
/*     */           case '+':
/* 175 */             if (!old) {
/* 176 */               length++;
/*     */             }
/*     */             break;
/*     */           case '-':
/* 180 */             if (old) {
/* 181 */               length++;
/*     */             }
/*     */             break;
/*     */           default:
/* 185 */             throw new IllegalArgumentException("");
/*     */         }  
/*     */       b++; }
/*     */     
/* 189 */     return length; } private static boolean checkForPrefix(char prefix, String[] lines) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 193 */     for (i = (arrayOfString = lines).length, b = 0; b < i; ) { String line = arrayOfString[b];
/* 194 */       if (line.length() > 0 && 
/* 195 */         line.charAt(0) == prefix) {
/* 196 */         return true;
/*     */       }
/*     */       b++; }
/*     */     
/* 200 */     return false;
/*     */   }
/*     */   
/*     */   private static IHunk[] addHunks(IHunk[] hunks, IHunk[] toAdd) {
/* 204 */     IHunk[] ret = new IHunk[hunks.length + toAdd.length];
/* 205 */     System.arraycopy(hunks, 0, ret, 0, hunks.length);
/* 206 */     System.arraycopy(toAdd, 0, ret, hunks.length, toAdd.length);
/* 207 */     return ret;
/*     */   }
/*     */   
/*     */   private static IHunk[] removeHunks(IHunk[] hunks, IHunk[] toRemove) {
/* 211 */     int removed = 0;
/* 212 */     for (int i = 0; i < hunks.length; i++) {
/* 213 */       byte b; int m; IHunk[] arrayOfIHunk; for (m = (arrayOfIHunk = toRemove).length, b = 0; b < m; ) { IHunk r = arrayOfIHunk[b];
/* 214 */         if (r == hunks[i]) {
/* 215 */           hunks[i] = null;
/* 216 */           removed++;
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 220 */     IHunk[] ret = new IHunk[hunks.length - removed];
/* 221 */     for (int k = 0, j = 0; k < hunks.length; k++) {
/* 222 */       if (hunks[k] != null) {
/* 223 */         ret[j++] = hunks[k];
/*     */       }
/*     */     } 
/* 226 */     return ret;
/*     */   }
/*     */   
/*     */   private static void reorder(IHunk[] hunks) {
/* 230 */     Arrays.sort(hunks, new HunkComparator());
/* 231 */     int shift = 0; byte b; int i; IHunk[] arrayOfIHunk;
/* 232 */     for (i = (arrayOfIHunk = hunks).length, b = 0; b < i; ) { IHunk h = arrayOfIHunk[b];
/* 233 */       Hunk hunk = (Hunk)h;
/* 234 */       int start = hunk.getStart(false) + shift;
/* 235 */       hunk.setStart(start, true);
/* 236 */       shift += hunk.getLength(true) - hunk.getLength(false);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   static class HunkComparator implements Comparator<IHunk> {
/*     */     public int compare(IHunk arg0, IHunk arg1) {
/* 243 */       if (arg0 != null && arg0 instanceof Hunk && 
/* 244 */         arg1 != null && arg1 instanceof Hunk) {
/* 245 */         Hunk hunk0 = (Hunk)arg0;
/* 246 */         Hunk hunk1 = (Hunk)arg1;
/* 247 */         int shift = hunk0.getStart(true) - hunk1.getStart(true);
/* 248 */         return shift;
/*     */       } 
/* 250 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\patch\PatchBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */