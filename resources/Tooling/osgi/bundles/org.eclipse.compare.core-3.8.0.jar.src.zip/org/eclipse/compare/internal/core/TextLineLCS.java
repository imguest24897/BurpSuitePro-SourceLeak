/*     */ package org.eclipse.compare.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextLineLCS
/*     */   extends LCS
/*     */ {
/*     */   private final TextLine[] lines1;
/*     */   private final TextLine[] lines2;
/*     */   private TextLine[][] lcs;
/*     */   
/*     */   public TextLineLCS(TextLine[] lines1, TextLine[] lines2) {
/*  27 */     this.lines1 = lines1;
/*  28 */     this.lines2 = lines2;
/*     */   }
/*     */   
/*     */   public TextLine[][] getResult() {
/*  32 */     int length = getLength();
/*  33 */     if (length == 0)
/*  34 */       return new TextLine[2][0]; 
/*  35 */     TextLine[][] result = new TextLine[2][];
/*     */ 
/*     */     
/*  38 */     result[0] = compactAndShiftLCS(this.lcs[0], length, this.lines1);
/*  39 */     result[1] = compactAndShiftLCS(this.lcs[1], length, this.lines2);
/*     */     
/*  41 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getLength2() {
/*  46 */     return this.lines2.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getLength1() {
/*  51 */     return this.lines1.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isRangeEqual(int i1, int i2) {
/*  56 */     return this.lines1[i1].sameText(this.lines2[i2]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setLcs(int sl1, int sl2) {
/*  61 */     this.lcs[0][sl1] = this.lines1[sl1];
/*  62 */     this.lcs[1][sl1] = this.lines2[sl2];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initializeLcs(int length) {
/*  67 */     this.lcs = new TextLine[2][length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TextLine[] compactAndShiftLCS(TextLine[] lcsSide, int len, TextLine[] original) {
/*  89 */     TextLine[] result = new TextLine[len];
/*     */     
/*  91 */     if (len == 0) {
/*  92 */       return result;
/*     */     }
/*     */     
/*  95 */     int j = 0;
/*     */     
/*  97 */     while (lcsSide[j] == null) {
/*  98 */       j++;
/*     */     }
/*     */     
/* 101 */     result[0] = lcsSide[j];
/* 102 */     j++;
/*     */     
/* 104 */     for (int i = 1; i < len; i++) {
/* 105 */       while (lcsSide[j] == null) {
/* 106 */         j++;
/*     */       }
/*     */       
/* 109 */       if (original[result[i - 1].lineNumber() + 1].sameText(lcsSide[j])) {
/* 110 */         result[i] = original[result[i - 1].lineNumber() + 1];
/*     */       } else {
/* 112 */         result[i] = lcsSide[j];
/*     */       } 
/* 114 */       j++;
/*     */     } 
/*     */     
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextLine[] getTextLines(String text) {
/* 132 */     List<TextLine> lines = new ArrayList<>();
/* 133 */     int begin = 0;
/* 134 */     int end = getEOL(text, 0);
/* 135 */     int lineNum = 0;
/* 136 */     while (end != -1) {
/* 137 */       lines.add(new TextLine(lineNum++, text.substring(begin, end)));
/* 138 */       begin = end + 1;
/* 139 */       end = getEOL(text, begin);
/* 140 */       if (end == begin && text.charAt(begin - 1) == '\r' && 
/* 141 */         text.charAt(begin) == '\n') {
/*     */         
/* 143 */         begin = end + 1;
/* 144 */         end = getEOL(text, begin);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     lines.add(new TextLine(lineNum, text.substring(begin)));
/* 153 */     TextLine[] aLines = new TextLine[lines.size()];
/* 154 */     lines.toArray(aLines);
/* 155 */     return aLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getEOL(String text, int start) {
/* 168 */     int max = text.length();
/* 169 */     for (int i = start; i < max; i++) {
/* 170 */       char c = text.charAt(i);
/* 171 */       if (c == '\n' || c == '\r') {
/* 172 */         return i;
/*     */       }
/*     */     } 
/* 175 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class TextLine
/*     */   {
/*     */     private int number;
/*     */     private String text;
/*     */     
/*     */     public TextLine(int number, String text) {
/* 185 */       this.number = number;
/* 186 */       this.text = text;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean sameText(TextLine l) {
/* 199 */       return (this.text.hashCode() == l.text.hashCode() && l.text.equals(this.text));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int lineNumber() {
/* 208 */       return this.number;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 213 */       return this.number + " " + this.text + "\n";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\TextLineLCS.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */