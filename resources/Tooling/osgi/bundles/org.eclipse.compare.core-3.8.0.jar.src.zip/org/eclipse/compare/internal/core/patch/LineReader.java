/*     */ package org.eclipse.compare.internal.core.patch;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.internal.core.Messages;
/*     */ import org.eclipse.compare.patch.ReaderCreator;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineReader
/*     */ {
/*     */   public static List<String> load(ReaderCreator content, boolean create) {
/*  30 */     List<String> lines = null;
/*  31 */     BufferedReader bufferedReader = null;
/*  32 */     if (!create && content != null && content.canCreateReader()) {
/*     */       
/*     */       try {
/*  35 */         bufferedReader = new BufferedReader(content.createReader());
/*  36 */         lines = readLines(bufferedReader);
/*  37 */       } catch (CoreException ex) {
/*  38 */         Platform.getLog(LineReader.class).error(Messages.Activator_1, (Throwable)ex);
/*     */       } finally {
/*  40 */         if (bufferedReader != null) {
/*     */           try {
/*  42 */             bufferedReader.close();
/*  43 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  50 */     if (lines == null)
/*  51 */       lines = new ArrayList<>(); 
/*  52 */     return lines;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> readLines(BufferedReader reader) {
/*  57 */     LineReader lr = new LineReader(reader);
/*  58 */     lr.ignoreSingleCR();
/*  59 */     List<String> lines = lr.readLines();
/*  60 */     return lines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createString(boolean preserveLineDelimeters, List<String> lines) {
/*  67 */     StringBuilder sb = new StringBuilder();
/*  68 */     Iterator<String> iter = lines.iterator();
/*  69 */     if (preserveLineDelimeters) {
/*  70 */       while (iter.hasNext())
/*  71 */         sb.append(iter.next()); 
/*     */     } else {
/*  73 */       String lineSeparator = System.getProperty("line.separator");
/*  74 */       while (iter.hasNext()) {
/*  75 */         String line = iter.next();
/*  76 */         int l = length(line);
/*  77 */         if (l < line.length()) {
/*  78 */           sb.append(line.substring(0, l));
/*  79 */           sb.append(lineSeparator); continue;
/*     */         } 
/*  81 */         sb.append(line);
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int length(String s) {
/*  93 */     int l = s.length();
/*  94 */     if (l > 0) {
/*  95 */       char c = s.charAt(l - 1);
/*  96 */       if (c == '\r')
/*  97 */         return l - 1; 
/*  98 */       if (c == '\n') {
/*  99 */         if (l > 1 && s.charAt(l - 2) == '\r')
/* 100 */           return l - 2; 
/* 101 */         return l - 1;
/*     */       } 
/*     */     } 
/* 104 */     return l;
/*     */   }
/*     */   
/*     */   private boolean fHaveChar = false;
/*     */   private int fLastChar;
/*     */   private boolean fSawEOF = false;
/*     */   private BufferedReader fReader;
/*     */   private boolean fIgnoreSingleCR = false;
/* 112 */   private StringBuilder fBuffer = new StringBuilder();
/*     */   
/*     */   public LineReader(BufferedReader reader) {
/* 115 */     this.fReader = reader;
/* 116 */     Assert.isNotNull(reader);
/*     */   }
/*     */   
/*     */   public void ignoreSingleCR() {
/* 120 */     this.fIgnoreSingleCR = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String readLine() throws IOException {
/*     */     try {
/* 134 */       while (!this.fSawEOF) {
/* 135 */         int c = readChar();
/* 136 */         if (c == -1) {
/* 137 */           this.fSawEOF = true;
/*     */           break;
/*     */         } 
/* 140 */         this.fBuffer.append((char)c);
/* 141 */         if (c == 10)
/*     */           break; 
/* 143 */         if (c == 13) {
/* 144 */           c = readChar();
/* 145 */           if (c == -1) {
/* 146 */             this.fSawEOF = true;
/*     */             break;
/*     */           } 
/* 149 */           if (c != 10) {
/* 150 */             if (this.fIgnoreSingleCR) {
/* 151 */               this.fBuffer.append((char)c);
/*     */               continue;
/*     */             } 
/* 154 */             this.fHaveChar = true;
/* 155 */             this.fLastChar = c; break;
/*     */           } 
/* 157 */           this.fBuffer.append((char)c);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 162 */       if (this.fBuffer.length() != 0) {
/* 163 */         return this.fBuffer.toString();
/*     */       }
/* 165 */       return null;
/*     */     } finally {
/* 167 */       this.fBuffer.setLength(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   void close() {
/*     */     try {
/* 173 */       this.fReader.close();
/* 174 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> readLines() {
/*     */     try {
/* 181 */       List<String> lines = new ArrayList<>();
/*     */       String line;
/* 183 */       while ((line = readLine()) != null)
/* 184 */         lines.add(line); 
/* 185 */       return lines;
/* 186 */     } catch (IOException iOException) {
/*     */ 
/*     */     
/*     */     } finally {
/* 190 */       close();
/*     */     } 
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int lineContentLength(String line) {
/* 200 */     if (line == null)
/* 201 */       return 0; 
/* 202 */     int length = line.length();
/* 203 */     for (int i = length - 1; i >= 0; ) {
/* 204 */       char c = line.charAt(i);
/* 205 */       if (c == '\n' || c == '\r') {
/* 206 */         length--; i--;
/*     */       } 
/*     */       break;
/*     */     } 
/* 210 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int readChar() throws IOException {
/* 216 */     if (this.fHaveChar) {
/* 217 */       this.fHaveChar = false;
/* 218 */       return this.fLastChar;
/*     */     } 
/* 220 */     return this.fReader.read();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\LineReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */