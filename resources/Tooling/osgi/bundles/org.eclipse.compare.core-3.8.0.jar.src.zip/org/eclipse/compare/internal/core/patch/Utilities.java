/*    */ package org.eclipse.compare.internal.core.patch;
/*    */ 
/*    */ import java.io.InputStreamReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Utilities
/*    */ {
/*    */   public static String getCharset(Object resource) {
/* 21 */     if (resource instanceof InputStreamReader) {
/* 22 */       return ((InputStreamReader)resource).getEncoding();
/*    */     }
/* 24 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\internal\core\patch\Utilities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */