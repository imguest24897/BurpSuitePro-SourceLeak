/*     */ package org.eclipse.compare.rangedifferencer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.compare.internal.core.LCS;
/*     */ import org.eclipse.compare.internal.core.Messages;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RangeComparatorLCS
/*     */   extends LCS
/*     */ {
/*     */   private final IRangeComparator comparator1;
/*     */   private final IRangeComparator comparator2;
/*     */   private int[][] lcs;
/*     */   
/*     */   public static RangeDifference[] findDifferences(AbstractRangeDifferenceFactory factory, IProgressMonitor pm, IRangeComparator left, IRangeComparator right) {
/*  29 */     RangeComparatorLCS lcs = new RangeComparatorLCS(left, right);
/*  30 */     SubMonitor monitor = SubMonitor.convert(pm, Messages.RangeComparatorLCS_0, 100);
/*     */     try {
/*  32 */       lcs.longestCommonSubsequence(monitor.newChild(95));
/*  33 */       return lcs.getDifferences(monitor.newChild(5), factory);
/*     */     } finally {
/*  35 */       if (pm != null)
/*  36 */         pm.done(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public RangeComparatorLCS(IRangeComparator comparator1, IRangeComparator comparator2) {
/*  41 */     this.comparator1 = comparator1;
/*  42 */     this.comparator2 = comparator2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getLength1() {
/*  47 */     return this.comparator1.getRangeCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getLength2() {
/*  52 */     return this.comparator2.getRangeCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initializeLcs(int lcsLength) {
/*  57 */     this.lcs = new int[2][lcsLength];
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isRangeEqual(int i1, int i2) {
/*  62 */     return this.comparator1.rangesEqual(i1, this.comparator2, i2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLcs(int sl1, int sl2) {
/*  68 */     this.lcs[0][sl1] = sl1 + 1;
/*  69 */     this.lcs[1][sl1] = sl2 + 1;
/*     */   }
/*     */   
/*     */   public RangeDifference[] getDifferences(SubMonitor subMonitor, AbstractRangeDifferenceFactory factory) {
/*     */     try {
/*  74 */       List<RangeDifference> differences = new ArrayList<>();
/*  75 */       int length = getLength();
/*  76 */       if (length == 0) {
/*  77 */         differences.add(factory.createRangeDifference(2, 0, this.comparator2.getRangeCount(), 0, this.comparator1.getRangeCount()));
/*     */       } else {
/*  79 */         subMonitor.beginTask(null, length);
/*     */         
/*  81 */         int index2 = 0, index1 = index2;
/*     */         
/*  83 */         int s1 = -1;
/*  84 */         int s2 = -1;
/*  85 */         while (index1 < (this.lcs[0]).length && index2 < (this.lcs[1]).length) {
/*     */           int l1;
/*     */           do {
/*  88 */             index1++;
/*  89 */           } while ((l1 = this.lcs[0][index1]) == 0 && index1 < (this.lcs[0]).length);
/*     */ 
/*     */           
/*  92 */           if (index1 >= (this.lcs[0]).length)
/*     */             break;  int l2;
/*     */           do {
/*  95 */             index2++;
/*  96 */           } while ((l2 = this.lcs[1][index2]) == 0 && index2 < (this.lcs[1]).length);
/*     */ 
/*     */           
/*  99 */           if (index2 >= (this.lcs[1]).length) {
/*     */             break;
/*     */           }
/* 102 */           int end1 = l1 - 1;
/* 103 */           int end2 = l2 - 1;
/* 104 */           if (s1 == -1 && (end1 != 0 || end2 != 0)) {
/*     */ 
/*     */             
/* 107 */             differences.add(factory.createRangeDifference(2, 0, end2, 0, end1));
/* 108 */           } else if (end1 != s1 + 1 || end2 != s2 + 1) {
/*     */             
/* 110 */             int leftStart = s1 + 1;
/* 111 */             int leftLength = end1 - leftStart;
/* 112 */             int rightStart = s2 + 1;
/* 113 */             int rightLength = end2 - rightStart;
/*     */             
/* 115 */             differences.add(factory.createRangeDifference(2, rightStart, rightLength, leftStart, leftLength));
/*     */           } 
/* 117 */           s1 = end1;
/* 118 */           s2 = end2;
/* 119 */           index1++;
/* 120 */           index2++;
/* 121 */           worked(subMonitor, 1);
/*     */         } 
/* 123 */         if (s1 != -1 && (s1 + 1 < this.comparator1.getRangeCount() || s2 + 1 < this.comparator2.getRangeCount())) {
/*     */           
/* 125 */           int leftStart = (s1 < this.comparator1.getRangeCount()) ? (s1 + 1) : s1;
/* 126 */           int rightStart = (s2 < this.comparator2.getRangeCount()) ? (s2 + 1) : s2;
/*     */           
/* 128 */           differences.add(factory.createRangeDifference(2, rightStart, this.comparator2.getRangeCount() - s2 + 1, leftStart, this.comparator1.getRangeCount() - s1 + 1));
/*     */         } 
/*     */       } 
/*     */       
/* 132 */       return differences.<RangeDifference>toArray(new RangeDifference[differences.size()]);
/*     */     } finally {
/* 134 */       subMonitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void worked(SubMonitor subMonitor, int work) {
/* 139 */     if (subMonitor.isCanceled())
/* 140 */       throw new OperationCanceledException(); 
/* 141 */     subMonitor.worked(work);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compactAndShiftLCS(int[] lcsSide, int length, IRangeComparator comparator) {
/* 157 */     if (length == 0) {
/*     */       return;
/*     */     }
/* 160 */     int j = 0;
/* 161 */     while (lcsSide[j] == 0) {
/* 162 */       j++;
/*     */     }
/*     */     
/* 165 */     lcsSide[0] = lcsSide[j];
/* 166 */     j++;
/*     */     int i;
/* 168 */     for (i = 1; i < length; i++) {
/* 169 */       while (lcsSide[j] == 0) {
/* 170 */         j++;
/*     */       }
/*     */ 
/*     */       
/* 174 */       int nextLine = lcsSide[i - 1] + 1;
/* 175 */       if (nextLine != lcsSide[j] && comparator.rangesEqual(nextLine - 1, comparator, lcsSide[j] - 1)) {
/* 176 */         lcsSide[i] = nextLine;
/*     */       } else {
/* 178 */         lcsSide[i] = lcsSide[j];
/*     */       } 
/* 180 */       j++;
/*     */     } 
/*     */     
/* 183 */     for (i = length; i < lcsSide.length; i++) {
/* 184 */       lcsSide[i] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void longestCommonSubsequence(SubMonitor subMonitor) {
/* 190 */     super.longestCommonSubsequence(subMonitor);
/* 191 */     if (this.lcs != null) {
/* 192 */       compactAndShiftLCS(this.lcs[0], getLength(), this.comparator1);
/* 193 */       compactAndShiftLCS(this.lcs[1], getLength(), this.comparator2);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\rangedifferencer\RangeComparatorLCS.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */