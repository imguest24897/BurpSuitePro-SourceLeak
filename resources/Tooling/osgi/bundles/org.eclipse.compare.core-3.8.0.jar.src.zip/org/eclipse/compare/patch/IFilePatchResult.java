package org.eclipse.compare.patch;

import java.io.InputStream;
import org.eclipse.core.runtime.CoreException;

public interface IFilePatchResult {
  InputStream getOriginalContents();
  
  InputStream getPatchedContents();
  
  boolean hasMatches();
  
  boolean hasRejects();
  
  IHunk[] getRejects();
  
  String getCharset() throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.compare.core-3.8.0.jar!\org\eclipse\compare\patch\IFilePatchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */