/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Extension
/*     */   extends RegistryObject
/*     */ {
/*  24 */   public static final Extension[] EMPTY_ARRAY = new Extension[0];
/*     */   
/*     */   private String simpleId;
/*     */   
/*     */   private String namespaceIdentifier;
/*     */   
/*     */   private Object extraInformation;
/*     */   
/*     */   private static final byte LABEL = 0;
/*     */   
/*     */   private static final byte XPT_NAME = 1;
/*     */   
/*     */   private static final byte CONTRIBUTOR_ID = 2;
/*     */   private static final int EXTRA_SIZE = 3;
/*     */   
/*     */   protected Extension(ExtensionRegistry registry, boolean persist) {
/*  40 */     super(registry, persist);
/*     */   }
/*     */   
/*     */   protected Extension(int self, String simpleId, String namespace, int[] children, int extraData, ExtensionRegistry registry, boolean persist) {
/*  44 */     super(registry, persist);
/*     */     
/*  46 */     setObjectId(self);
/*  47 */     this.simpleId = simpleId;
/*  48 */     setRawChildren(children);
/*  49 */     setExtraDataOffset(extraData);
/*  50 */     this.namespaceIdentifier = namespace;
/*     */   }
/*     */   
/*     */   protected String getExtensionPointIdentifier() {
/*  54 */     String[] extraData = getExtraData();
/*  55 */     if (extraData == null) {
/*  56 */       return null;
/*     */     }
/*  58 */     return extraData[1];
/*     */   }
/*     */   
/*     */   protected String getSimpleIdentifier() {
/*  62 */     return this.simpleId;
/*     */   }
/*     */   
/*     */   protected String getUniqueIdentifier() {
/*  66 */     return (this.simpleId == null) ? null : (String.valueOf(getNamespaceIdentifier()) + '.' + this.simpleId);
/*     */   }
/*     */   
/*     */   void setExtensionPointIdentifier(String value) {
/*  70 */     ensureExtraInformationType();
/*  71 */     ((String[])this.extraInformation)[1] = value;
/*     */   }
/*     */   
/*     */   void setSimpleIdentifier(String value) {
/*  75 */     this.simpleId = value;
/*     */   }
/*     */ 
/*     */   
/*     */   private String[] getExtraData() {
/*  80 */     if (noExtraData()) {
/*  81 */       if (this.extraInformation != null)
/*  82 */         return (String[])this.extraInformation; 
/*  83 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     String[] result = null;
/*  88 */     if (this.extraInformation != null) { if ((result = (String[])((this.extraInformation instanceof SoftReference) ? ((SoftReference<String[]>)this.extraInformation).get() : this.extraInformation)) == null)
/*  89 */       { result = this.registry.getTableReader().loadExtensionExtraData(getExtraDataOffset());
/*  90 */         this.extraInformation = new SoftReference<>(result);
/*     */         
/*  92 */         return result; }  return result; }  result = this.registry.getTableReader().loadExtensionExtraData(getExtraDataOffset()); this.extraInformation = new SoftReference<>(result); return result;
/*     */   }
/*     */   
/*     */   String getLabel() {
/*  96 */     String s = getExtraData()[0];
/*  97 */     if (s == null)
/*  98 */       return ""; 
/*  99 */     return s;
/*     */   }
/*     */   
/*     */   void setLabel(String value) {
/* 103 */     ensureExtraInformationType();
/* 104 */     ((String[])this.extraInformation)[0] = value;
/*     */   }
/*     */   
/*     */   String getContributorId() {
/* 108 */     String s = getExtraData()[2];
/* 109 */     if (s == null)
/* 110 */       return ""; 
/* 111 */     return s;
/*     */   }
/*     */   
/*     */   public IContributor getContributor() {
/* 115 */     return (IContributor)this.registry.getObjectManager().getContributor(getContributorId());
/*     */   }
/*     */   
/*     */   void setContributorId(String value) {
/* 119 */     ensureExtraInformationType();
/* 120 */     ((String[])this.extraInformation)[2] = value;
/*     */   }
/*     */   
/*     */   public String getNamespaceIdentifier() {
/* 124 */     return this.namespaceIdentifier;
/*     */   }
/*     */   
/*     */   void setNamespaceIdentifier(String value) {
/* 128 */     this.namespaceIdentifier = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     return String.valueOf(getUniqueIdentifier()) + " -> " + getExtensionPointIdentifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureExtraInformationType() {
/* 140 */     if (this.extraInformation instanceof SoftReference) {
/* 141 */       this.extraInformation = ((SoftReference)this.extraInformation).get();
/*     */     }
/* 143 */     if (this.extraInformation == null) {
/* 144 */       this.extraInformation = new String[3];
/*     */     }
/*     */   }
/*     */   
/*     */   String getLabelAsIs() {
/* 149 */     String s = getExtraData()[0];
/* 150 */     if (s == null)
/* 151 */       return ""; 
/* 152 */     return s;
/*     */   }
/*     */   
/*     */   String getLabel(String locale) {
/* 156 */     this.registry.logMultiLangError();
/* 157 */     return getLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\Extension.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */