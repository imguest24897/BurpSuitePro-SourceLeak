/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.eclipse.core.internal.registry.ExtensionRegistry;
/*     */ import org.eclipse.core.internal.registry.ReferenceMap;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.registry.RegistryProperties;
/*     */ import org.eclipse.core.internal.registry.RegistryTimestamp;
/*     */ import org.eclipse.core.internal.runtime.ResourceTranslator;
/*     */ import org.eclipse.core.runtime.ContributorFactoryOSGi;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ import org.eclipse.core.runtime.spi.RegistryStrategy;
/*     */ import org.eclipse.osgi.service.localization.LocaleProvider;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryStrategyOSGI
/*     */   extends RegistryStrategy
/*     */ {
/*     */   private final Object token;
/*     */   protected boolean DEBUG;
/*     */   protected boolean DEBUG_REGISTRY_EVENTS;
/*  67 */   private ServiceTracker<?, ?> xmlTracker = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private ServiceTracker<?, ?> localeTracker = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean trackTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegistryStrategyOSGI(File[] theStorageDir, boolean[] cacheReadOnly, Object key) {
/*  88 */     super(theStorageDir, cacheReadOnly);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     this.bundleMap = new ReferenceMap(1, DEFAULT_BUNDLECACHE_SIZE, DEFAULT_BUNDLECACHE_LOADFACTOR);
/*     */     
/* 141 */     this.bundleMapLock = new ReentrantReadWriteLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     this.pluginBundleListener = null; this.token = key; BundleContext context = Activator.getContext();
/*     */     if (context != null) {
/*     */       this.trackTimestamp = "true".equalsIgnoreCase(context.getProperty("osgi.checkConfiguration"));
/*     */     } else {
/*     */       this.trackTimestamp = false;
/*     */     } 
/*     */   } public final String translate(String key, ResourceBundle resources) { return ResourceTranslator.getResourceString(null, key, resources); } public String[] translate(String[] nonTranslated, IContributor contributor, String locale) { return ResourceTranslator.getResourceString(ContributorFactoryOSGi.resolve(contributor), nonTranslated, locale); } private static float DEFAULT_BUNDLECACHE_LOADFACTOR = 0.75F; private static int DEFAULT_BUNDLECACHE_SIZE = 200; private final ReferenceMap bundleMap;
/* 228 */   public void onStart(IExtensionRegistry registry, boolean loadedFromCache) { super.onStart(registry, loadedFromCache);
/*     */     
/* 230 */     if (!(registry instanceof ExtensionRegistry)) {
/*     */       return;
/*     */     }
/* 233 */     this.pluginBundleListener = new EclipseBundleListener((ExtensionRegistry)registry, this.token, this);
/* 234 */     Activator.getContext().addBundleListener((BundleListener)this.pluginBundleListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     if (!loadedFromCache)
/* 243 */       this.pluginBundleListener.processBundles(Activator.getContext().getBundles());  }
/*     */   private final ReadWriteLock bundleMapLock; private EclipseBundleListener pluginBundleListener; private Bundle getBundle(String id) { long OSGiId; if (id == null)
/*     */       return null;  try { OSGiId = Long.parseLong(id); } catch (NumberFormatException numberFormatException) { return null; }
/*     */      this.bundleMapLock.readLock().lock(); try { bundle = (Bundle)this.bundleMap.get((int)OSGiId); }
/*     */     finally { this.bundleMapLock.readLock().unlock(); }
/*     */      if (bundle != null)
/*     */       return bundle;  Bundle bundle = Activator.getContext().getBundle(OSGiId); this.bundleMapLock.writeLock().lock(); try { this.bundleMap.put((int)OSGiId, bundle); }
/*     */     finally { this.bundleMapLock.writeLock().unlock(); }
/* 251 */      return bundle; } public void onStop(IExtensionRegistry registry) { if (this.pluginBundleListener != null)
/* 252 */       Activator.getContext().removeBundleListener((BundleListener)this.pluginBundleListener); 
/* 253 */     if (this.xmlTracker != null) {
/* 254 */       this.xmlTracker.close();
/* 255 */       this.xmlTracker = null;
/*     */     } 
/* 257 */     if (this.localeTracker != null) {
/* 258 */       this.localeTracker.close();
/* 259 */       this.localeTracker = null;
/*     */     } 
/* 261 */     super.onStop(registry); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cacheUse() {
/* 272 */     return !"true".equals(RegistryProperties.getProperty("eclipse.noRegistryCache")); } public Object createExecutableExtension(RegistryContributor contributor, String className, String overridenContributorName) throws CoreException { Bundle contributingBundle; if (overridenContributorName != null && !overridenContributorName.equals("")) { contributingBundle = OSGIUtils.getDefault().getBundle(overridenContributorName); }
/*     */     else { contributingBundle = getBundle(contributor.getId()); }
/*     */      if (contributingBundle == null)
/*     */       throwException(NLS.bind(RegistryMessages.plugin_loadClassError, "UNKNOWN BUNDLE", className), (Throwable)new InvalidRegistryObjectException());  Class<?> classInstance = null; try { classInstance = contributingBundle.loadClass(className); }
/*     */     catch (Exception|LinkageError e1) { throwException(NLS.bind(RegistryMessages.plugin_loadClassError, contributingBundle.getSymbolicName(), className), e1); }
/*     */      Object result = null; try { result = classInstance.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]); }
/*     */     catch (Exception|LinkageError e) { throwException(NLS.bind(RegistryMessages.plugin_instantiateClassError, contributingBundle.getSymbolicName(), className), e); }
/*     */      return result; }
/* 280 */   public boolean cacheLazyLoading() { return !"true".equalsIgnoreCase(RegistryProperties.getProperty("eclipse.noLazyRegistryCacheLoading")); }
/*     */ 
/*     */   
/*     */   private void throwException(String message, Throwable exception) throws CoreException {
/*     */     throw new CoreException(new Status(4, "org.eclipse.equinox.registry", 1, message, exception));
/*     */   }
/*     */   
/*     */   public long getContributionsTimestamp() {
/* 288 */     if (!checkContributionsTimestamp())
/* 289 */       return 0L; 
/* 290 */     RegistryTimestamp expectedTimestamp = new RegistryTimestamp();
/* 291 */     BundleContext context = Activator.getContext();
/* 292 */     Bundle[] allBundles = context.getBundles(); byte b; int i; Bundle[] arrayOfBundle1;
/* 293 */     for (i = (arrayOfBundle1 = allBundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 294 */       URL pluginManifest = EclipseBundleListener.getExtensionURL(bundle, false);
/* 295 */       if (pluginManifest != null) {
/*     */         
/* 297 */         long timestamp = getExtendedTimestamp(bundle, pluginManifest);
/* 298 */         expectedTimestamp.add(timestamp);
/*     */       }  b++; }
/* 300 */      return expectedTimestamp.getContentsTimestamp();
/*     */   }
/*     */   
/*     */   public boolean checkContributionsTimestamp() {
/* 304 */     return this.trackTimestamp;
/*     */   }
/*     */   
/*     */   public long getExtendedTimestamp(Bundle bundle, URL pluginManifest) {
/* 308 */     if (pluginManifest == null)
/* 309 */       return 0L; 
/*     */     try {
/* 311 */       return pluginManifest.openConnection().getLastModified() + bundle.getBundleId();
/* 312 */     } catch (IOException e) {
/* 313 */       if (debug()) {
/* 314 */         System.out.println("Unable to obtain timestamp for the bundle " + bundle.getSymbolicName());
/* 315 */         e.printStackTrace();
/*     */       } 
/* 317 */       return 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAXParserFactory getXMLParser() {
/* 326 */     if (this.xmlTracker == null) {
/* 327 */       this.xmlTracker = new ServiceTracker(Activator.getContext(), SAXParserFactory.class.getName(), null);
/* 328 */       this.xmlTracker.open();
/*     */     } 
/* 330 */     return (SAXParserFactory)this.xmlTracker.getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocale() {
/* 338 */     if (this.localeTracker == null) {
/* 339 */       this.localeTracker = new ServiceTracker(Activator.getContext(), LocaleProvider.class.getName(), null);
/* 340 */       this.localeTracker.open();
/*     */     } 
/* 342 */     LocaleProvider localeProvider = (LocaleProvider)this.localeTracker.getService();
/* 343 */     if (localeProvider != null) {
/* 344 */       Locale currentLocale = localeProvider.getLocale();
/* 345 */       if (currentLocale != null)
/* 346 */         return currentLocale.toString(); 
/*     */     } 
/* 348 */     return super.getLocale();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\RegistryStrategyOSGI.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */