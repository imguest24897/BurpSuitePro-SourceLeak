/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtensionHandle
/*    */   extends BaseExtensionHandle
/*    */ {
/* 27 */   static final ExtensionHandle[] EMPTY_ARRAY = new ExtensionHandle[0];
/*    */   
/*    */   public ExtensionHandle(IObjectManager objectManager, int id) {
/* 30 */     super(objectManager, id);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */