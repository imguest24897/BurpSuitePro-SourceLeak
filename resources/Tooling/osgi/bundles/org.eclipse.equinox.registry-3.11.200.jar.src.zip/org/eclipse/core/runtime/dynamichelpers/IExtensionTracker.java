package org.eclipse.core.runtime.dynamichelpers;

import org.eclipse.core.runtime.IExtension;

public interface IExtensionTracker {
  public static final int REF_STRONG = 0;
  
  public static final int REF_SOFT = 1;
  
  public static final int REF_WEAK = 2;
  
  void registerHandler(IExtensionChangeHandler paramIExtensionChangeHandler, IFilter paramIFilter);
  
  void unregisterHandler(IExtensionChangeHandler paramIExtensionChangeHandler);
  
  void registerObject(IExtension paramIExtension, Object paramObject, int paramInt);
  
  void unregisterObject(IExtension paramIExtension, Object paramObject);
  
  Object[] unregisterObject(IExtension paramIExtension);
  
  Object[] getObjects(IExtension paramIExtension);
  
  void close();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\dynamichelpers\IExtensionTracker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */