/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.LinkedList;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionDelta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryDelta
/*    */ {
/* 24 */   private final Set<IExtensionDelta> extensionDeltas = new HashSet<>();
/*    */ 
/*    */   
/*    */   private IObjectManager objectManager;
/*    */ 
/*    */ 
/*    */   
/*    */   public int getExtensionDeltasCount() {
/* 32 */     return this.extensionDeltas.size();
/*    */   }
/*    */   
/*    */   public IExtensionDelta[] getExtensionDeltas() {
/* 36 */     return this.extensionDeltas.<IExtensionDelta>toArray((IExtensionDelta[])new ExtensionDelta[this.extensionDeltas.size()]);
/*    */   }
/*    */   
/*    */   public IExtensionDelta[] getExtensionDeltas(String extensionPoint) {
/* 40 */     Collection<IExtensionDelta> selectedExtDeltas = new LinkedList<>();
/* 41 */     for (IExtensionDelta extensionDelta : this.extensionDeltas) {
/* 42 */       if (extensionDelta.getExtension().getExtensionPointUniqueIdentifier().equals(extensionPoint))
/* 43 */         selectedExtDeltas.add(extensionDelta); 
/*    */     } 
/* 45 */     return selectedExtDeltas.<IExtensionDelta>toArray(new IExtensionDelta[selectedExtDeltas.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IExtensionDelta getExtensionDelta(String extensionPointId, String extensionId) {
/* 53 */     for (IExtensionDelta extensionDelta : this.extensionDeltas) {
/* 54 */       IExtension extension = extensionDelta.getExtension();
/* 55 */       if (extension.getExtensionPointUniqueIdentifier().equals(extensionPointId) && extension.getUniqueIdentifier() != null && extension.getUniqueIdentifier().equals(extensionId))
/* 56 */         return extensionDelta; 
/*    */     } 
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   void addExtensionDelta(IExtensionDelta extensionDelta) {
/* 62 */     this.extensionDeltas.add(extensionDelta);
/* 63 */     ((ExtensionDelta)extensionDelta).setContainingDelta(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return "\n\tHost : " + this.extensionDeltas;
/*    */   }
/*    */   
/*    */   void setObjectManager(IObjectManager objectManager) {
/* 72 */     this.objectManager = objectManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public IObjectManager getObjectManager() {
/* 77 */     return this.objectManager;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryDelta.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */