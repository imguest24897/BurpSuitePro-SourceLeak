/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.eclipse.core.internal.registry.ExtensionRegistry;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.runtime.ResourceTranslator;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.ContributorFactoryOSGi;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseBundleListener
/*     */   implements SynchronousBundleListener
/*     */ {
/*     */   private static final String PLUGIN_MANIFEST = "plugin.xml";
/*     */   private static final String FRAGMENT_MANIFEST = "fragment.xml";
/*     */   private final ExtensionRegistry registry;
/*     */   private final RegistryStrategyOSGI strategy;
/*     */   private final Object token;
/*  44 */   private final HashMap<String, Long> dynamicAddStateStamps = new HashMap<>();
/*  45 */   private final long[] currentStateStamp = new long[1];
/*     */   
/*     */   public EclipseBundleListener(ExtensionRegistry registry, Object key, RegistryStrategyOSGI strategy) {
/*  48 */     this.registry = registry;
/*  49 */     this.token = key;
/*  50 */     this.strategy = strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/*  72 */     Bundle bundle = event.getBundle();
/*  73 */     switch (event.getType()) {
/*     */       case 32:
/*  75 */         synchronized (this.currentStateStamp) {
/*  76 */           long newStateStamp = this.registry.computeState();
/*  77 */           if (this.currentStateStamp[0] != newStateStamp) {
/*     */             
/*  79 */             this.currentStateStamp[0] = newStateStamp;
/*  80 */             this.dynamicAddStateStamps.clear();
/*     */           } 
/*     */         } 
/*  83 */         addBundle(bundle, true);
/*     */         break;
/*     */       case 64:
/*  86 */         removeBundle(bundle);
/*     */         break;
/*     */     }  } public void processBundles(Bundle[] bundles) {
/*     */     byte b;
/*     */     int i;
/*     */     Bundle[] arrayOfBundle;
/*  92 */     for (i = (arrayOfBundle = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle[b];
/*  93 */       if (isBundleResolved(bundle)) {
/*  94 */         addBundle(bundle, false);
/*     */       } else {
/*  96 */         removeBundle(bundle);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private boolean isBundleResolved(Bundle bundle) {
/* 102 */     return ((bundle.getState() & 0x3C) != 0);
/*     */   }
/*     */   
/*     */   private void removeBundle(Bundle bundle) {
/* 106 */     long timestamp = 0L;
/* 107 */     if (this.strategy.checkContributionsTimestamp()) {
/* 108 */       URL pluginManifest = getExtensionURL(bundle, false);
/* 109 */       if (pluginManifest != null)
/* 110 */         timestamp = this.strategy.getExtendedTimestamp(bundle, pluginManifest); 
/*     */     } 
/* 112 */     this.registry.remove(Long.toString(bundle.getBundleId()), timestamp);
/*     */   }
/*     */ 
/*     */   
/*     */   public static URL getExtensionURL(Bundle bundle, boolean report) {
/* 117 */     if (bundle.getSymbolicName() == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     boolean isFragment = OSGIUtils.getDefault().isFragment(bundle);
/* 121 */     String manifestName = isFragment ? "fragment.xml" : "plugin.xml";
/* 122 */     URL extensionURL = bundle.getEntry(manifestName);
/* 123 */     if (extensionURL == null) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     if (!isSingleton(bundle)) {
/* 128 */       if (report && !isGeneratedManifest(bundle)) {
/* 129 */         String message = NLS.bind(RegistryMessages.parse_nonSingleton, bundle.getSymbolicName());
/* 130 */         RuntimeLog.log((IStatus)new Status(2, "org.eclipse.equinox.registry", 0, message, null));
/*     */       } 
/* 132 */       return null;
/*     */     } 
/* 134 */     if (!isFragment) {
/* 135 */       return extensionURL;
/*     */     }
/*     */     
/* 138 */     Bundle[] hosts = OSGIUtils.getDefault().getHosts(bundle);
/* 139 */     if (hosts == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     if (isSingleton(hosts[0])) {
/* 143 */       return extensionURL;
/*     */     }
/* 145 */     if (report) {
/*     */       
/* 147 */       String message = NLS.bind(RegistryMessages.parse_nonSingletonFragment, bundle.getSymbolicName(), hosts[0].getSymbolicName());
/* 148 */       RuntimeLog.log((IStatus)new Status(2, "org.eclipse.equinox.registry", 0, message, null));
/*     */     } 
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isGeneratedManifest(Bundle bundle) {
/* 154 */     return (bundle.getHeaders("").get("Generated-from") != null);
/*     */   }
/*     */   private void addBundle(Bundle bundle, boolean checkNLSFragments) {
/*     */     InputStream is;
/* 158 */     if (checkNLSFragments) {
/* 159 */       checkForNLSFragment(bundle);
/*     */     }
/*     */     
/* 162 */     IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
/* 163 */     if (this.registry.hasContributor(contributor))
/*     */       return; 
/* 165 */     URL pluginManifest = getExtensionURL(bundle, true);
/* 166 */     if (pluginManifest == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 170 */       is = new BufferedInputStream(pluginManifest.openStream());
/* 171 */     } catch (IOException iOException) {
/* 172 */       is = null;
/*     */     } 
/* 174 */     if (is == null) {
/*     */       return;
/*     */     }
/* 177 */     ResourceBundle translationBundle = null;
/*     */     try {
/* 179 */       translationBundle = ResourceTranslator.getResourceBundle(bundle);
/* 180 */     } catch (MissingResourceException missingResourceException) {}
/*     */ 
/*     */     
/* 183 */     long timestamp = 0L;
/* 184 */     if (this.strategy.checkContributionsTimestamp())
/* 185 */       timestamp = this.strategy.getExtendedTimestamp(bundle, pluginManifest); 
/* 186 */     this.registry.addContribution(is, contributor, true, pluginManifest.getPath(), translationBundle, this.token, timestamp);
/*     */   }
/*     */   
/*     */   private void checkForNLSFragment(Bundle bundle) {
/* 190 */     if (!OSGIUtils.getDefault().isFragment(bundle)) {
/*     */       
/* 192 */       synchronized (this.currentStateStamp) {
/*     */         
/* 194 */         this.dynamicAddStateStamps.put(Long.toString(bundle.getBundleId()), Long.valueOf(this.currentStateStamp[0]));
/*     */       } 
/*     */       return;
/*     */     } 
/* 198 */     Bundle[] hosts = OSGIUtils.getDefault().getHosts(bundle);
/* 199 */     if (hosts == null)
/*     */       return;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 202 */     for (i = (arrayOfBundle1 = hosts).length, b = 0; b < i; ) { Bundle host = arrayOfBundle1[b];
/* 203 */       checkForNLSFiles(host, bundle);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void checkForNLSFiles(Bundle host, Bundle fragment) {
/* 208 */     String hostID = Long.toString(host.getBundleId());
/*     */     
/* 210 */     synchronized (this.currentStateStamp) {
/* 211 */       Long hostStateStamp = this.dynamicAddStateStamps.get(hostID);
/* 212 */       if (hostStateStamp != null && this.currentStateStamp[0] == hostStateStamp.longValue()) {
/*     */         return;
/*     */       }
/*     */     } 
/* 216 */     Bundle[] fragments = OSGIUtils.getDefault().getFragments(host);
/* 217 */     boolean refresh = false;
/*     */     
/* 219 */     if (hasNLSFilesFor(host, fragment)) {
/* 220 */       refresh = true;
/*     */     } else {
/*     */       
/* 223 */       for (int i = 0; i < fragments.length && !refresh; i++) {
/* 224 */         if (!fragment.equals(fragments[i]))
/*     */         {
/* 226 */           if (hasNLSFilesFor(fragments[i], fragment))
/* 227 */             refresh = true; 
/*     */         }
/*     */       } 
/*     */     } 
/* 231 */     if (refresh) {
/*     */       
/* 233 */       removeBundle(host);
/* 234 */       addBundle(host, false); byte b; int i; Bundle[] arrayOfBundle;
/* 235 */       for (i = (arrayOfBundle = fragments).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle[b];
/* 236 */         if (!fragment.equals(bundle)) {
/*     */ 
/*     */           
/* 239 */           removeBundle(bundle);
/* 240 */           addBundle(bundle, false);
/*     */         }  b++; }
/* 242 */        synchronized (this.currentStateStamp) {
/*     */         
/* 244 */         this.dynamicAddStateStamps.put(hostID, Long.valueOf(this.currentStateStamp[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasNLSFilesFor(Bundle target, Bundle fragment) {
/* 250 */     if (!this.registry.hasContributor(Long.toString(target.getBundleId()))) {
/* 251 */       return false;
/*     */     }
/* 253 */     Dictionary<?, ?> targetHeaders = target.getHeaders("");
/* 254 */     String localization = (String)targetHeaders.get("Bundle-Localization");
/* 255 */     if (localization == null)
/*     */     {
/* 257 */       localization = "OSGI-INF/l10n/bundle";
/*     */     }
/*     */     
/* 260 */     URL baseNLS = target.getEntry(String.valueOf(localization) + ".properties");
/* 261 */     if (baseNLS == null)
/* 262 */       return false; 
/* 263 */     int lastSlash = localization.lastIndexOf('/');
/* 264 */     if (lastSlash == localization.length() - 1)
/* 265 */       return false; 
/* 266 */     String baseDir = (lastSlash < 0) ? "" : localization.substring(0, lastSlash);
/* 267 */     String filePattern = String.valueOf((lastSlash < 0) ? localization : localization.substring(lastSlash + 1)) + "_*.properties";
/* 268 */     Enumeration<?> nlsFiles = fragment.findEntries(baseDir, filePattern, false);
/* 269 */     return (nlsFiles != null);
/*     */   }
/*     */   
/*     */   private static boolean isSingleton(Bundle bundle) {
/* 273 */     Dictionary<?, ?> allHeaders = bundle.getHeaders("");
/* 274 */     String symbolicNameHeader = (String)allHeaders.get("Bundle-SymbolicName");
/*     */     try {
/* 276 */       if (symbolicNameHeader != null) {
/* 277 */         ManifestElement[] symbolicNameElements = ManifestElement.parseHeader("Bundle-SymbolicName", symbolicNameHeader);
/* 278 */         if (symbolicNameElements.length > 0) {
/* 279 */           String singleton = symbolicNameElements[0].getDirective("singleton");
/* 280 */           if (singleton == null) {
/* 281 */             singleton = symbolicNameElements[0].getAttribute("singleton");
/*     */           }
/* 283 */           if (!"true".equalsIgnoreCase(singleton)) {
/* 284 */             String manifestVersion = (String)allHeaders.get("Bundle-ManifestVersion");
/* 285 */             if (manifestVersion == null)
/*     */             {
/* 287 */               if (OSGIUtils.getDefault().getBundle(symbolicNameElements[0].getValue()) == bundle)
/* 288 */                 return true; 
/*     */             }
/* 290 */             return false;
/*     */           } 
/*     */         } 
/*     */       } 
/* 294 */     } catch (BundleException bundleException) {}
/*     */ 
/*     */     
/* 297 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\EclipseBundleListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */