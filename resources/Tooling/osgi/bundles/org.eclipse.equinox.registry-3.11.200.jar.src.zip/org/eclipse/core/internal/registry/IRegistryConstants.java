package org.eclipse.core.internal.registry;

public interface IRegistryConstants {
  public static final String RUNTIME_NAME = "org.eclipse.core.runtime";
  
  public static final String NO_REGISTRY_CACHE = "-noregistrycache";
  
  public static final String NO_LAZY_REGISTRY_CACHE_LOADING = "-noLazyRegistryCacheLoading";
  
  public static final String MULTI_LANGUAGE = "-registryMultiLanguage";
  
  public static final String PROP_NO_LAZY_CACHE_LOADING = "eclipse.noLazyRegistryCacheLoading";
  
  public static final String PROP_CHECK_CONFIG = "osgi.checkConfiguration";
  
  public static final String PROP_NO_REGISTRY_CACHE = "eclipse.noRegistryCache";
  
  public static final String PROP_DEFAULT_REGISTRY = "eclipse.createRegistry";
  
  public static final String PROP_REGISTRY_NULL_USER_TOKEN = "eclipse.registry.nulltoken";
  
  public static final String PROP_MULTI_LANGUAGE = "eclipse.registry.MultiLanguage";
  
  public static final String PROP_NL = "osgi.nl";
  
  public static final String PROP_OS = "osgi.os";
  
  public static final String PROP_WS = "osgi.ws";
  
  public static final int PLUGIN_ERROR = 1;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\IRegistryConstants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */