/*     */ package org.eclipse.core.runtime.dynamichelpers;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.runtime.ReferenceHashSet;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionDelta;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtensionTracker
/*     */   implements IExtensionTracker, IRegistryChangeListener
/*     */ {
/*  34 */   private Map<IExtension, ReferenceHashSet<Object>> extensionToObjects = new HashMap<>();
/*  35 */   private ListenerList<HandlerWrapper> handlers = new ListenerList();
/*  36 */   private final Object lock = new Object();
/*     */   
/*     */   private boolean closed = false;
/*     */   private final IExtensionRegistry registry;
/*  40 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtensionTracker() {
/*  46 */     this(RegistryFactory.getRegistry());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtensionTracker(IExtensionRegistry theRegistry) {
/*  57 */     this.registry = theRegistry;
/*  58 */     if (this.registry != null) {
/*  59 */       this.registry.addRegistryChangeListener(this);
/*     */     } else {
/*  61 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.registry_no_default, null));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHandler(IExtensionChangeHandler handler, IFilter filter) {
/*  69 */     synchronized (this.lock) {
/*  70 */       if (this.closed) {
/*     */         return;
/*     */       }
/*  73 */       this.handlers.add(new HandlerWrapper(handler, filter));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterHandler(IExtensionChangeHandler handler) {
/*  82 */     synchronized (this.lock) {
/*  83 */       if (this.closed)
/*     */         return; 
/*  85 */       this.handlers.remove(new HandlerWrapper(handler, null));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerObject(IExtension element, Object object, int referenceType) {
/*  94 */     if (element == null || object == null) {
/*     */       return;
/*     */     }
/*  97 */     synchronized (this.lock) {
/*  98 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 101 */       ReferenceHashSet<Object> associatedObjects = this.extensionToObjects.get(element);
/* 102 */       if (associatedObjects == null) {
/* 103 */         associatedObjects = new ReferenceHashSet();
/* 104 */         this.extensionToObjects.put(element, associatedObjects);
/*     */       } 
/* 106 */       associatedObjects.add(object, referenceType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/* 118 */     IExtensionDelta[] delta = event.getExtensionDeltas();
/* 119 */     int len = delta.length;
/* 120 */     for (int i = 0; i < len; i++) {
/* 121 */       switch (delta[i].getKind()) {
/*     */         case 1:
/* 123 */           doAdd(delta[i]);
/*     */           break;
/*     */         case 2:
/* 126 */           doRemove(delta[i]);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notify(IExtensionDelta delta, Object[] objects) {
/* 144 */     Object[] handlersCopy = null;
/* 145 */     synchronized (this.lock) {
/* 146 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 149 */       if (this.handlers == null || this.handlers.isEmpty())
/*     */         return; 
/* 151 */       handlersCopy = this.handlers.getListeners();
/*     */     }  byte b; int i;
/*     */     Object[] arrayOfObject1;
/* 154 */     for (i = (arrayOfObject1 = handlersCopy).length, b = 0; b < i; ) { Object w = arrayOfObject1[b];
/* 155 */       HandlerWrapper wrapper = (HandlerWrapper)w;
/* 156 */       if (wrapper.filter == null || wrapper.filter.matches(delta.getExtensionPoint()))
/* 157 */         if (objects == null) {
/* 158 */           applyAdd(wrapper.handler, delta.getExtension());
/*     */         } else {
/* 160 */           applyRemove(wrapper.handler, delta.getExtension(), objects);
/*     */         }  
/*     */       b++; }
/*     */   
/*     */   }
/*     */   protected void applyAdd(IExtensionChangeHandler handler, IExtension extension) {
/* 166 */     handler.addExtension(this, extension);
/*     */   }
/*     */   
/*     */   private void doAdd(IExtensionDelta delta) {
/* 170 */     notify(delta, null);
/*     */   }
/*     */   
/*     */   private void doRemove(IExtensionDelta delta) {
/* 174 */     Object[] removedObjects = null;
/* 175 */     synchronized (this.lock) {
/* 176 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 179 */       ReferenceHashSet<?> associatedObjects = this.extensionToObjects.remove(delta.getExtension());
/* 180 */       if (associatedObjects == null) {
/* 181 */         removedObjects = EMPTY_ARRAY;
/*     */       } else {
/*     */         
/* 184 */         removedObjects = associatedObjects.toArray();
/*     */       } 
/* 186 */     }  notify(delta, removedObjects);
/*     */   }
/*     */   
/*     */   protected void applyRemove(IExtensionChangeHandler handler, IExtension removedExtension, Object[] removedObjects) {
/* 190 */     handler.removeExtension(removedExtension, removedObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getObjects(IExtension element) {
/* 198 */     synchronized (this.lock) {
/* 199 */       if (this.closed)
/* 200 */         return EMPTY_ARRAY; 
/* 201 */       ReferenceHashSet<?> objectSet = this.extensionToObjects.get(element);
/* 202 */       if (objectSet == null) {
/* 203 */         return EMPTY_ARRAY;
/*     */       }
/* 205 */       return objectSet.toArray();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 214 */     synchronized (this.lock) {
/* 215 */       if (this.closed)
/*     */         return; 
/* 217 */       if (this.registry != null)
/* 218 */         this.registry.removeRegistryChangeListener(this); 
/* 219 */       this.extensionToObjects = null;
/* 220 */       this.handlers = null;
/*     */       
/* 222 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterObject(IExtension extension, Object object) {
/* 231 */     synchronized (this.lock) {
/* 232 */       if (this.closed)
/*     */         return; 
/* 234 */       ReferenceHashSet<Object> associatedObjects = this.extensionToObjects.get(extension);
/* 235 */       if (associatedObjects != null) {
/* 236 */         associatedObjects.remove(object);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] unregisterObject(IExtension extension) {
/* 245 */     synchronized (this.lock) {
/* 246 */       if (this.closed)
/* 247 */         return EMPTY_ARRAY; 
/* 248 */       ReferenceHashSet<?> associatedObjects = this.extensionToObjects.remove(extension);
/* 249 */       if (associatedObjects == null)
/* 250 */         return EMPTY_ARRAY; 
/* 251 */       return associatedObjects.toArray();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilter createExtensionPointFilter(IExtensionPoint xpt) {
/* 262 */     return xpt::equals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilter createExtensionPointFilter(IExtensionPoint[] xpts) {
/* 272 */     return target -> {
/*     */         IExtensionPoint[] arrayOfIExtensionPoint;
/*     */         int i = (arrayOfIExtensionPoint = paramArrayOfIExtensionPoint).length;
/*     */         for (byte b = 0; b < i; b++) {
/*     */           IExtensionPoint xpt = arrayOfIExtensionPoint[b];
/*     */           if (xpt.equals(target)) {
/*     */             return true;
/*     */           }
/*     */         } 
/*     */         return false;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFilter createNamespaceFilter(String id) {
/* 289 */     return target -> paramString.equals(target.getNamespaceIdentifier());
/*     */   }
/*     */   
/*     */   private class HandlerWrapper {
/*     */     IExtensionChangeHandler handler;
/*     */     IFilter filter;
/*     */     
/*     */     public HandlerWrapper(IExtensionChangeHandler handler, IFilter filter) {
/* 297 */       this.handler = handler;
/* 298 */       this.filter = filter;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object target) {
/* 303 */       return this.handler.equals(((HandlerWrapper)target).handler);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 308 */       return this.handler.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\dynamichelpers\ExtensionTracker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */