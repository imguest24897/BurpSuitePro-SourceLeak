/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxRegistryStrategy
/*     */   extends RegistryStrategyOSGI
/*     */ {
/*     */   public static final String PLUGIN_NAME = "org.eclipse.equinox.registry";
/*     */   public static final String OPTION_DEBUG = "org.eclipse.equinox.registry/debug";
/*     */   public static final String OPTION_DEBUG_EVENTS = "org.eclipse.equinox.registry/debug/events";
/*  43 */   private static boolean DEBUG_ECLIPSE_REGISTRY = OSGIUtils.getDefault().getBooleanDebugOption("org.eclipse.equinox.registry/debug", false);
/*  44 */   private static boolean DEBUG_ECLIPSE_EVENTS = OSGIUtils.getDefault().getBooleanDebugOption("org.eclipse.equinox.registry/debug/events", false);
/*     */   
/*     */   private boolean useJobs = true;
/*     */   
/*     */   public EquinoxRegistryStrategy(File[] theStorageDir, boolean[] cacheReadOnly, Object key) {
/*  49 */     super(theStorageDir, cacheReadOnly, key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean debug() {
/*  54 */     return DEBUG_ECLIPSE_REGISTRY;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean debugRegistryEvents() {
/*  59 */     return DEBUG_ECLIPSE_EVENTS;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void log(IStatus status) {
/*  64 */     RuntimeLog.log(status);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContainerTimestamp() {
/*  69 */     BundleContext context = Activator.getContext();
/*  70 */     if (context == null) {
/*  71 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
/*  72 */       return -1L;
/*     */     } 
/*     */     
/*  75 */     ServiceReference<?> ref = context.getServiceReference("org.eclipse.osgi.service.resolver.PlatformAdmin");
/*  76 */     if (ref == null)
/*  77 */       return -1L; 
/*  78 */     return EquinoxUtils.getContainerTimestamp(context, ref);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scheduleChangeEvent(Object[] listeners, Map<String, ?> deltas, Object registry) {
/*  92 */     if (this.useJobs) {
/*     */       try {
/*  94 */         (new ExtensionEventDispatcherJob(listeners, deltas, registry)).schedule();
/*     */         return;
/*  96 */       } catch (NoClassDefFoundError|IllegalStateException noClassDefFoundError) {
/*  97 */         this.useJobs = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 102 */     super.scheduleChangeEvent(listeners, deltas, registry);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\EquinoxRegistryStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */