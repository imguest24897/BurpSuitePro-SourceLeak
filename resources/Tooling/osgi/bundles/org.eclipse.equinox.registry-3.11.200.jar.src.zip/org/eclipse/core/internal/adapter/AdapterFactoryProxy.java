/*     */ package org.eclipse.core.internal.adapter;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.eclipse.core.internal.registry.Handle;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.registry.osgi.EquinoxUtils;
/*     */ import org.eclipse.core.internal.runtime.IAdapterFactoryExt;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AdapterFactoryProxy
/*     */   implements IAdapterFactory, IAdapterFactoryExt
/*     */ {
/*     */   private String adaptableType;
/*     */   private String[] adapterNames;
/*     */   private String contributorName;
/*     */   private IExtension declaringExtension;
/*     */   private Optional<IAdapterFactory> factory;
/*     */   private Callable<IAdapterFactory> factoryLoader;
/*     */   private String ownerId;
/*  48 */   private int internalOwnerId = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AdapterFactoryProxy createProxy(IConfigurationElement element) {
/*  55 */     AdapterFactoryProxy result = new AdapterFactoryProxy();
/*  56 */     result.contributorName = element.getContributor().getName();
/*  57 */     if (!"factory".equals(element.getName())) {
/*  58 */       result.logError();
/*  59 */       return null;
/*     */     } 
/*     */     
/*  62 */     result.adaptableType = element.getAttribute("adaptableType");
/*  63 */     if (result.adaptableType == null) {
/*  64 */       result.logError();
/*  65 */       return null;
/*     */     } 
/*     */     
/*  68 */     result.adapterNames = (String[])Arrays.<IConfigurationElement>stream(element.getChildren())
/*     */       
/*  70 */       .filter(child -> "adapter".equals(child.getName()))
/*  71 */       .map(child -> child.getAttribute("type"))
/*  72 */       .filter(Objects::nonNull).toArray(paramInt -> new String[paramInt]);
/*  73 */     if (result.adapterNames.length == 0) {
/*  74 */       result.logError();
/*  75 */       return null;
/*     */     } 
/*     */     
/*  78 */     result.declaringExtension = element.getDeclaringExtension();
/*  79 */     result.ownerId = result.declaringExtension.getUniqueIdentifier();
/*  80 */     if (result.declaringExtension instanceof Handle) {
/*  81 */       result.internalOwnerId = ((Handle)result.declaringExtension).getId();
/*     */     }
/*  83 */     result.factoryLoader = (() -> (IAdapterFactory)paramIConfigurationElement.createExecutableExtension("class"));
/*     */ 
/*     */ 
/*     */     
/*  87 */     return result;
/*     */   }
/*     */   
/*     */   public boolean originatesFrom(IExtension extension) {
/*  91 */     String id = extension.getUniqueIdentifier();
/*  92 */     if (id != null) {
/*  93 */       return id.equals(this.ownerId);
/*     */     }
/*  95 */     if (!(extension instanceof Handle)) {
/*  96 */       return false;
/*     */     }
/*  98 */     return (this.internalOwnerId == ((Handle)extension).getId());
/*     */   }
/*     */   
/*     */   String getAdaptableType() {
/* 102 */     return this.adaptableType;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Object adaptableObject, Class<T> adapterType) {
/* 107 */     Optional<IAdapterFactory> adapterFactory = this.factory;
/* 108 */     if (adapterFactory == null) {
/* 109 */       adapterFactory = Optional.ofNullable(loadFactory(false));
/*     */     }
/* 111 */     return adapterFactory.<T>map(f -> f.getAdapter(paramObject, paramClass)).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getAdapterList() {
/* 116 */     Optional<IAdapterFactory> adapterFactory = this.factory;
/* 117 */     if (adapterFactory == null) {
/* 118 */       adapterFactory = Optional.ofNullable(loadFactory(false));
/*     */     }
/* 120 */     return adapterFactory.<Class<?>[]>map(f -> f.getAdapterList()).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAdapterNames() {
/* 125 */     return this.adapterNames;
/*     */   }
/*     */   
/*     */   IExtension getExtension() {
/* 129 */     return this.declaringExtension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IAdapterFactory loadFactory(boolean force) {
/* 141 */     if (this.factory == null) {
/*     */       boolean isActive;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 148 */         isActive = EquinoxUtils.isActive(this.contributorName);
/* 149 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*     */         
/* 151 */         isActive = true;
/*     */       } 
/* 153 */       if (!force && !isActive) {
/* 154 */         return null;
/*     */       }
/*     */       try {
/* 157 */         this.factory = Optional.of(this.factoryLoader.call());
/* 158 */       } catch (Exception e) {
/* 159 */         String msg = NLS.bind(RegistryMessages.adapters_cantInstansiate, this.adaptableType, this.contributorName);
/* 160 */         RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, msg, e));
/*     */         
/* 162 */         this.factory = Optional.empty();
/*     */       } 
/*     */     } 
/* 165 */     return this.factory.orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logError() {
/* 172 */     String msg = NLS.bind(RegistryMessages.adapters_badAdapterFactory, this.contributorName);
/* 173 */     RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, msg, null));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     StringBuilder sb = new StringBuilder();
/* 179 */     sb.append("AdapterFactoryProxy [contributor: ");
/* 180 */     sb.append(this.contributorName);
/* 181 */     sb.append(", adaptableType: ");
/* 182 */     sb.append(this.adaptableType);
/* 183 */     if (this.factory != null) {
/* 184 */       sb.append(", factory: ");
/* 185 */       sb.append(this.factory);
/*     */     } 
/* 187 */     sb.append("]");
/* 188 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\adapter\AdapterFactoryProxy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */