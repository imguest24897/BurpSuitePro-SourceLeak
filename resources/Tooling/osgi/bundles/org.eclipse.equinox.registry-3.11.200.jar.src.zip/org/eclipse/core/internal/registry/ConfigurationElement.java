/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExecutableExtension;
/*     */ import org.eclipse.core.runtime.IExecutableExtensionFactory;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationElement
/*     */   extends RegistryObject
/*     */ {
/*  26 */   static final ConfigurationElement[] EMPTY_ARRAY = new ConfigurationElement[0];
/*     */ 
/*     */ 
/*     */   
/*     */   int parentId;
/*     */ 
/*     */ 
/*     */   
/*     */   byte parentType;
/*     */ 
/*     */   
/*     */   protected String[] propertiesAndValue;
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */   
/*     */   private String contributorId;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConfigurationElement(ExtensionRegistry registry, boolean persist) {
/*  48 */     super(registry, persist);
/*     */   }
/*     */   
/*     */   protected ConfigurationElement(int self, String contributorId, String name, String[] propertiesAndValue, int[] children, int extraDataOffset, int parent, byte parentType, ExtensionRegistry registry, boolean persist) {
/*  52 */     super(registry, persist);
/*     */     
/*  54 */     setObjectId(self);
/*  55 */     this.contributorId = contributorId;
/*  56 */     this.name = name;
/*  57 */     this.propertiesAndValue = propertiesAndValue;
/*  58 */     setRawChildren(children);
/*  59 */     setExtraDataOffset(extraDataOffset);
/*  60 */     this.parentId = parent;
/*  61 */     this.parentType = parentType;
/*     */   }
/*     */   
/*     */   void throwException(String message, Throwable exception) throws CoreException {
/*  65 */     throw new CoreException(new Status(4, "org.eclipse.equinox.registry", 1, message, exception));
/*     */   }
/*     */   
/*     */   protected String getValue() {
/*  69 */     return getValueAsIs();
/*     */   }
/*     */   
/*     */   String getValueAsIs() {
/*  73 */     if (this.propertiesAndValue.length != 0 && this.propertiesAndValue.length % 2 == 1)
/*  74 */       return this.propertiesAndValue[this.propertiesAndValue.length - 1]; 
/*  75 */     return null;
/*     */   }
/*     */   
/*     */   public String getAttribute(String attrName) {
/*  79 */     return getAttributeAsIs(attrName);
/*     */   }
/*     */   
/*     */   String getAttributeAsIs(String attrName) {
/*  83 */     if (this.propertiesAndValue.length <= 1)
/*  84 */       return null; 
/*  85 */     int size = this.propertiesAndValue.length - this.propertiesAndValue.length % 2;
/*  86 */     for (int i = 0; i < size; i += 2) {
/*  87 */       if (this.propertiesAndValue[i].equals(attrName))
/*  88 */         return this.propertiesAndValue[i + 1]; 
/*     */     } 
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   protected String[] getAttributeNames() {
/*  94 */     if (this.propertiesAndValue.length <= 1) {
/*  95 */       return RegistryObjectManager.EMPTY_STRING_ARRAY;
/*     */     }
/*  97 */     int size = this.propertiesAndValue.length / 2;
/*  98 */     String[] result = new String[size];
/*  99 */     for (int i = 0; i < size; i++) {
/* 100 */       result[i] = this.propertiesAndValue[i * 2];
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   void setProperties(String[] value) {
/* 106 */     this.propertiesAndValue = value;
/*     */   }
/*     */   
/*     */   protected String[] getPropertiesAndValue() {
/* 110 */     return this.propertiesAndValue;
/*     */   }
/*     */   
/*     */   void setValue(String value) {
/* 114 */     if (this.propertiesAndValue.length == 0) {
/* 115 */       this.propertiesAndValue = new String[] { value };
/*     */       return;
/*     */     } 
/* 118 */     if (this.propertiesAndValue.length % 2 == 1) {
/* 119 */       this.propertiesAndValue[this.propertiesAndValue.length - 1] = value;
/*     */       return;
/*     */     } 
/* 122 */     String[] newPropertiesAndValue = new String[this.propertiesAndValue.length + 1];
/* 123 */     System.arraycopy(this.propertiesAndValue, 0, newPropertiesAndValue, 0, this.propertiesAndValue.length);
/* 124 */     newPropertiesAndValue[this.propertiesAndValue.length] = value;
/* 125 */     this.propertiesAndValue = newPropertiesAndValue;
/*     */   }
/*     */   
/*     */   void setContributorId(String id) {
/* 129 */     this.contributorId = id;
/*     */   }
/*     */   
/*     */   protected String getContributorId() {
/* 133 */     return this.contributorId;
/*     */   }
/*     */   
/*     */   public ConfigurationElement[] getChildren(String childrenName) {
/* 137 */     if ((getRawChildren()).length == 0) {
/* 138 */       return EMPTY_ARRAY;
/*     */     }
/* 140 */     ConfigurationElement[] result = new ConfigurationElement[1];
/* 141 */     int idx = 0;
/* 142 */     RegistryObjectManager objectManager = this.registry.getObjectManager(); byte b; int i, arrayOfInt[];
/* 143 */     for (i = (arrayOfInt = this.children).length, b = 0; b < i; ) { int child = arrayOfInt[b];
/* 144 */       ConfigurationElement toTest = (ConfigurationElement)objectManager.getObject(child, noExtraData() ? 1 : 4);
/* 145 */       if (toTest.name.equals(childrenName)) {
/* 146 */         if (idx != 0) {
/* 147 */           ConfigurationElement[] copy = new ConfigurationElement[result.length + 1];
/* 148 */           System.arraycopy(result, 0, copy, 0, result.length);
/* 149 */           result = copy;
/*     */         } 
/* 151 */         result[idx++] = toTest;
/*     */       }  b++; }
/*     */     
/* 154 */     if (idx == 0)
/* 155 */       result = EMPTY_ARRAY; 
/* 156 */     return result;
/*     */   }
/*     */   
/*     */   void setParentId(int objectId) {
/* 160 */     this.parentId = objectId;
/*     */   }
/*     */   
/*     */   protected String getName() {
/* 164 */     return this.name;
/*     */   }
/*     */   
/*     */   void setName(String name) {
/* 168 */     this.name = name;
/*     */   }
/*     */   
/*     */   void setParentType(byte type) {
/* 172 */     this.parentType = type;
/*     */   }
/*     */   
/*     */   public IContributor getContributor() {
/* 176 */     return (IContributor)this.registry.getObjectManager().getContributor(this.contributorId);
/*     */   }
/*     */   
/*     */   protected Object createExecutableExtension(String attributeName) throws CoreException {
/* 180 */     String prop = null;
/*     */     
/* 182 */     String contributorName = null;
/* 183 */     String className = null;
/* 184 */     Object<String, String> initData = null;
/*     */ 
/*     */     
/* 187 */     if (attributeName != null) {
/* 188 */       prop = getAttribute(attributeName);
/*     */     } else {
/*     */       
/* 191 */       prop = getValue();
/* 192 */       if (prop != null) {
/* 193 */         prop = prop.trim();
/* 194 */         if (prop.equals("")) {
/* 195 */           prop = null;
/*     */         }
/*     */       } 
/*     */     } 
/* 199 */     if (prop == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       ConfigurationElement[] exec = getChildren(attributeName);
/* 208 */       if (exec.length != 0) {
/* 209 */         ConfigurationElement element = exec[0];
/* 210 */         contributorName = element.getAttribute("plugin");
/* 211 */         className = element.getAttribute("class");
/* 212 */         ConfigurationElement[] parms = element.getChildren("parameter");
/* 213 */         if (parms.length != 0) {
/* 214 */           Hashtable<String, String> initParms = new Hashtable<>(parms.length + 1);
/* 215 */           for (int i = 0; i < parms.length; i++) {
/* 216 */             String pname = parms[i].getAttribute("name");
/* 217 */             if (pname != null)
/* 218 */               initParms.put(pname, parms[i].getAttribute("value")); 
/*     */           } 
/* 220 */           if (!initParms.isEmpty()) {
/* 221 */             initData = (Object<String, String>)initParms;
/*     */           }
/*     */         } 
/*     */       } else {
/* 225 */         throwException(NLS.bind(RegistryMessages.exExt_extDefNotFound, attributeName), (Throwable)null);
/*     */       } 
/*     */     } else {
/*     */       String executable;
/* 229 */       int i = prop.indexOf(':');
/* 230 */       if (i != -1) {
/* 231 */         executable = prop.substring(0, i).trim();
/* 232 */         initData = (Object<String, String>)prop.substring(i + 1).trim();
/*     */       } else {
/* 234 */         executable = prop;
/*     */       } 
/* 236 */       i = executable.indexOf('/');
/* 237 */       if (i != -1) {
/* 238 */         contributorName = executable.substring(0, i).trim();
/* 239 */         className = executable.substring(i + 1).trim();
/*     */       } else {
/* 241 */         className = executable;
/*     */       } 
/*     */     } 
/*     */     
/* 245 */     RegistryContributor defaultContributor = this.registry.getObjectManager().getContributor(this.contributorId);
/* 246 */     Object result = this.registry.createExecutableExtension(defaultContributor, className, contributorName);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 252 */       ConfigurationElementHandle confElementHandle = new ConfigurationElementHandle(this.registry.getObjectManager(), getObjectId());
/* 253 */       if (result instanceof IExecutableExtension)
/* 254 */         ((IExecutableExtension)result).setInitializationData(confElementHandle, attributeName, initData); 
/* 255 */     } catch (CoreException ce) {
/*     */       
/* 257 */       throw ce;
/* 258 */     } catch (Exception te) {
/*     */       
/* 260 */       throwException(NLS.bind(RegistryMessages.plugin_initObjectError, getContributor().getName(), className), te);
/*     */     } 
/*     */ 
/*     */     
/* 264 */     if (result instanceof IExecutableExtensionFactory) {
/* 265 */       result = ((IExecutableExtensionFactory)result).create();
/*     */     }
/* 267 */     return result;
/*     */   }
/*     */   
/*     */   String getAttribute(String attrName, String locale) {
/* 271 */     this.registry.logMultiLangError();
/* 272 */     return getAttribute(attrName);
/*     */   }
/*     */   
/*     */   String getValue(String locale) {
/* 276 */     this.registry.logMultiLangError();
/* 277 */     return getValue();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ConfigurationElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */