/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationElementMulti
/*     */   extends ConfigurationElement
/*     */ {
/*  25 */   private DirectMap translatedProperties = new DirectMap(10, 0.5F);
/*     */   
/*     */   protected ConfigurationElementMulti(ExtensionRegistry registry, boolean persist) {
/*  28 */     super(registry, persist);
/*     */   }
/*     */   
/*     */   protected ConfigurationElementMulti(int self, String contributorId, String name, String[] propertiesAndValue, int[] children, int extraDataOffset, int parent, byte parentType, ExtensionRegistry registry, boolean persist) {
/*  32 */     super(self, contributorId, name, propertiesAndValue, children, extraDataOffset, parent, parentType, registry, persist);
/*     */   }
/*     */ 
/*     */   
/*     */   String getAttribute(String attrName, String locale) {
/*  37 */     if (this.propertiesAndValue.length <= 1) {
/*  38 */       return null;
/*     */     }
/*  40 */     int size = this.propertiesAndValue.length - this.propertiesAndValue.length % 2;
/*  41 */     int index = -1;
/*  42 */     for (int i = 0, j = 0; i < size; ) {
/*  43 */       if (!this.propertiesAndValue[i].equals(attrName)) {
/*     */         i += 2; j++; continue;
/*  45 */       }  index = j;
/*     */       break;
/*     */     } 
/*  48 */     if (index == -1) {
/*  49 */       return null;
/*     */     }
/*  51 */     String result = getTranslatedAtIndex(index, locale);
/*  52 */     if (result != null)
/*  53 */       return result; 
/*  54 */     return this.propertiesAndValue[index * 2 + 1];
/*     */   }
/*     */ 
/*     */   
/*     */   String getValue(String locale) {
/*  59 */     if (this.propertiesAndValue.length == 0 || this.propertiesAndValue.length % 2 == 0)
/*  60 */       return null; 
/*  61 */     int index = this.propertiesAndValue.length - 1;
/*  62 */     return getTranslatedAtIndex(index, locale);
/*     */   }
/*     */   
/*     */   private synchronized String getTranslatedAtIndex(int index, String locale) {
/*  66 */     String[] translated = null;
/*  67 */     if (!this.translatedProperties.containsKey(locale)) {
/*  68 */       String[] propertiesNonTranslated = getNonTranslated();
/*  69 */       translated = this.registry.translate(propertiesNonTranslated, getContributor(), locale);
/*  70 */       this.translatedProperties.put(locale, translated);
/*  71 */       this.registry.getObjectManager().markDirty();
/*     */     } else {
/*  73 */       translated = this.translatedProperties.get(locale);
/*     */     } 
/*  75 */     if (translated != null)
/*  76 */       return translated[index]; 
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   private String[] getNonTranslated() {
/*  81 */     int size = this.propertiesAndValue.length / 2;
/*  82 */     boolean hasValue = (this.propertiesAndValue.length % 2 == 1);
/*  83 */     if (hasValue)
/*  84 */       size++; 
/*  85 */     String[] propertiesNonTranslated = new String[size];
/*  86 */     int pos = 0;
/*  87 */     for (int i = 1; i < this.propertiesAndValue.length; i += 2) {
/*  88 */       propertiesNonTranslated[pos] = this.propertiesAndValue[i];
/*  89 */       pos++;
/*     */     } 
/*  91 */     if (hasValue)
/*  92 */       propertiesNonTranslated[pos] = this.propertiesAndValue[this.propertiesAndValue.length - 1]; 
/*  93 */     return propertiesNonTranslated;
/*     */   }
/*     */   
/*     */   synchronized int getNumCachedLocales() {
/*  97 */     return this.translatedProperties.getSzie();
/*     */   }
/*     */   
/*     */   synchronized String[] getCachedLocales() {
/* 101 */     return this.translatedProperties.getKeys();
/*     */   }
/*     */   
/*     */   synchronized String[][] getCachedTranslations() {
/* 105 */     return this.translatedProperties.getValues();
/*     */   }
/*     */   
/*     */   synchronized void setTranslatedProperties(DirectMap translated) {
/* 109 */     this.translatedProperties = translated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String attrName) {
/* 117 */     return getAttribute(attrName, getLocale());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 122 */     return getValue(getLocale());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ConfigurationElementMulti.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */