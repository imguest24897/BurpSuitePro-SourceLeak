/*     */ package org.eclipse.core.runtime;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.eclipse.core.internal.registry.ExtensionRegistry;
/*     */ import org.eclipse.core.internal.registry.RegistryProviderFactory;
/*     */ import org.eclipse.core.internal.registry.osgi.RegistryStrategyOSGI;
/*     */ import org.eclipse.core.runtime.spi.IRegistryProvider;
/*     */ import org.eclipse.core.runtime.spi.RegistryStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RegistryFactory
/*     */ {
/*     */   public static IExtensionRegistry createRegistry(RegistryStrategy strategy, Object masterToken, Object userToken) {
/*  61 */     return (IExtensionRegistry)new ExtensionRegistry(strategy, masterToken, userToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IExtensionRegistry getRegistry() {
/*  72 */     IRegistryProvider defaultRegistryProvider = RegistryProviderFactory.getDefault();
/*  73 */     if (defaultRegistryProvider == null)
/*  74 */       return null; 
/*  75 */     return defaultRegistryProvider.getRegistry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegistryStrategy createOSGiStrategy(File[] storageDirs, boolean[] cacheReadOnly, Object token) {
/* 105 */     return (RegistryStrategy)new RegistryStrategyOSGI(storageDirs, cacheReadOnly, token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultRegistryProvider(IRegistryProvider provider) throws CoreException {
/* 120 */     RegistryProviderFactory.setDefault(provider);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\RegistryFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */