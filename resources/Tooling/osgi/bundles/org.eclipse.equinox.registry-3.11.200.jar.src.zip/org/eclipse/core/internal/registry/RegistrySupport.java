/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistrySupport
/*    */ {
/*    */   public static String translate(String key, ResourceBundle resources) {
/* 36 */     if (key == null)
/* 37 */       return null; 
/* 38 */     if (resources == null)
/* 39 */       return key; 
/* 40 */     String trimmedKey = key.trim();
/* 41 */     if (trimmedKey.length() == 0)
/* 42 */       return key; 
/* 43 */     if (trimmedKey.charAt(0) != '%')
/* 44 */       return key; 
/* 45 */     return resources.getString(trimmedKey.substring(1));
/*    */   }
/*    */   
/*    */   public static void log(IStatus status, String prefix) {
/* 49 */     String message = status.getMessage();
/* 50 */     int severity = status.getSeverity();
/*    */ 
/*    */     
/* 53 */     switch (severity) {
/*    */       case 4:
/* 55 */         statusMsg = RegistryMessages.log_error;
/*    */         break;
/*    */       case 2:
/* 58 */         statusMsg = RegistryMessages.log_warning;
/*    */         break;
/*    */       default:
/* 61 */         statusMsg = RegistryMessages.log_log;
/*    */         break;
/*    */     } 
/* 64 */     String statusMsg = String.valueOf(statusMsg) + message;
/*    */     
/* 66 */     if (prefix != null)
/* 67 */       statusMsg = String.valueOf(prefix) + statusMsg; 
/* 68 */     System.out.println(statusMsg);
/*    */ 
/*    */     
/* 71 */     IStatus[] children = status.getChildren();
/* 72 */     if (children.length != 0) {
/*    */       String newPrefix;
/* 74 */       if (prefix == null) {
/* 75 */         newPrefix = "\t";
/*    */       } else {
/* 77 */         newPrefix = String.valueOf(prefix) + "\t";
/* 78 */       }  byte b; int i; IStatus[] arrayOfIStatus; for (i = (arrayOfIStatus = children).length, b = 0; b < i; ) { IStatus child = arrayOfIStatus[b];
/* 79 */         log(child, newPrefix);
/*    */         b++; }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistrySupport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */