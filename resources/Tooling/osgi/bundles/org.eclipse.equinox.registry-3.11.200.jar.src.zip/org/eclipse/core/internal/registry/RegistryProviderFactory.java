/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.spi.IRegistryProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RegistryProviderFactory
/*    */ {
/*    */   private static IRegistryProvider defaultRegistryProvider;
/*    */   
/*    */   public static IRegistryProvider getDefault() {
/* 28 */     return defaultRegistryProvider;
/*    */   }
/*    */   
/*    */   public static void setDefault(IRegistryProvider provider) throws CoreException {
/* 32 */     if (defaultRegistryProvider != null) {
/* 33 */       Status status = new Status(4, "org.eclipse.equinox.registry", 1, RegistryMessages.registry_default_exists, null);
/* 34 */       throw new CoreException(status);
/*    */     } 
/* 36 */     defaultRegistryProvider = provider;
/*    */   }
/*    */   
/*    */   public static void releaseDefault() {
/* 40 */     defaultRegistryProvider = null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryProviderFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */