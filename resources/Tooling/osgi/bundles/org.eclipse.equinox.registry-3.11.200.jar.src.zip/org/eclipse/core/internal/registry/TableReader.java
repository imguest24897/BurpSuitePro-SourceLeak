/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableReader
/*     */ {
/*     */   static final int NULL = 0;
/*     */   static final int OBJECT = 1;
/*     */   static final int LOBJECT = 2;
/*     */   static final int CACHE_VERSION = 8;
/*     */   static final String MAIN = ".mainData";
/*  44 */   BufferedRandomInputStream mainDataFile = null;
/*  45 */   DataInputStream mainInput = null;
/*     */   
/*     */   static final String EXTRA = ".extraData";
/*     */   
/*  49 */   BufferedRandomInputStream extraDataFile = null;
/*  50 */   DataInputStream extraInput = null;
/*     */   
/*     */   static final String TABLE = ".table";
/*     */   
/*     */   File tableFile;
/*     */   
/*     */   static final String CONTRIBUTIONS = ".contributions";
/*     */   
/*     */   File contributionsFile;
/*     */   
/*     */   static final String CONTRIBUTORS = ".contributors";
/*     */   
/*     */   File contributorsFile;
/*     */   
/*     */   static final String NAMESPACES = ".namespaces";
/*     */   
/*     */   File namespacesFile;
/*     */   
/*     */   static final String ORPHANS = ".orphans";
/*     */   
/*     */   File orphansFile;
/*     */   
/*     */   private static final byte fileError = 0;
/*     */   
/*     */   private static final boolean DEBUG = false;
/*     */   
/*     */   private boolean holdObjects = false;
/*     */   
/*     */   private final ExtensionRegistry registry;
/*     */   private SoftReference<Map<String, String>> stringPool;
/*     */   static final float contributorsLoadFactor = 1.2F;
/*     */   
/*     */   void setMainDataFile(File main) throws IOException {
/*  83 */     this.mainDataFile = new BufferedRandomInputStream(main);
/*  84 */     this.mainInput = new DataInputStream(this.mainDataFile);
/*     */   }
/*     */   
/*     */   void setExtraDataFile(File extra) throws IOException {
/*  88 */     this.extraDataFile = new BufferedRandomInputStream(extra);
/*  89 */     this.extraInput = new DataInputStream(this.extraDataFile);
/*     */   }
/*     */   
/*     */   void setTableFile(File table) {
/*  93 */     this.tableFile = table;
/*     */   }
/*     */   
/*     */   void setContributionsFile(File namespace) {
/*  97 */     this.contributionsFile = namespace;
/*     */   }
/*     */   
/*     */   void setContributorsFile(File file) {
/* 101 */     this.contributorsFile = file;
/*     */   }
/*     */   
/*     */   void setNamespacesFile(File file) {
/* 105 */     this.namespacesFile = file;
/*     */   }
/*     */   
/*     */   void setOrphansFile(File orphan) {
/* 109 */     this.orphansFile = orphan;
/*     */   }
/*     */   
/*     */   public TableReader(ExtensionRegistry registry) {
/* 113 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] loadTables(long expectedTimestamp) {
/* 120 */     DataInputStream tableInput = null;
/*     */     try {
/* 122 */       tableInput = new DataInputStream(new BufferedInputStream(new FileInputStream(this.tableFile)));
/* 123 */       if (!checkCacheValidity(tableInput, expectedTimestamp)) {
/* 124 */         return null;
/*     */       }
/* 126 */       Integer nextId = Integer.valueOf(tableInput.readInt());
/* 127 */       OffsetTable offsets = OffsetTable.load(tableInput);
/* 128 */       HashtableOfStringAndInt extensionPoints = new HashtableOfStringAndInt();
/* 129 */       extensionPoints.load(tableInput);
/* 130 */       return new Object[] { offsets, extensionPoints, nextId };
/* 131 */     } catch (IOException e) {
/* 132 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_registryCacheReadProblems, e));
/* 133 */       return null;
/*     */     } finally {
/* 135 */       if (tableInput != null) {
/*     */         try {
/* 137 */           tableInput.close();
/* 138 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkCacheValidity(DataInputStream in, long expectedTimestamp) {
/*     */     try {
/* 149 */       int version = in.readInt();
/* 150 */       if (version != 8) {
/* 151 */         return false;
/*     */       }
/* 153 */       long installStamp = in.readLong();
/* 154 */       long registryStamp = in.readLong();
/* 155 */       long mainDataFileSize = in.readLong();
/* 156 */       long extraDataFileSize = in.readLong();
/* 157 */       long contributionsFileSize = in.readLong();
/* 158 */       long contributorsFileSize = in.readLong();
/* 159 */       long namespacesFileSize = in.readLong();
/* 160 */       long orphansFileSize = in.readLong();
/* 161 */       String osStamp = readUTF(in, 1);
/* 162 */       String windowsStamp = readUTF(in, 1);
/* 163 */       String localeStamp = readUTF(in, 1);
/* 164 */       boolean multiLanguage = in.readBoolean();
/*     */       
/* 166 */       boolean validTime = !(expectedTimestamp != 0L && expectedTimestamp != registryStamp);
/* 167 */       boolean validInstall = (installStamp == this.registry.computeState());
/* 168 */       boolean validOS = osStamp.equals(RegistryProperties.getProperty("osgi.os", ""));
/* 169 */       boolean validWS = windowsStamp.equals(RegistryProperties.getProperty("osgi.ws", ""));
/* 170 */       boolean validNL = localeStamp.equals(RegistryProperties.getProperty("osgi.nl", ""));
/* 171 */       boolean validMultiLang = (this.registry.isMultiLanguage() == multiLanguage);
/*     */       
/* 173 */       if (!validTime || !validInstall || !validOS || !validWS || !validNL || !validMultiLang) {
/* 174 */         return false;
/*     */       }
/* 176 */       boolean validMain = (mainDataFileSize == this.mainDataFile.length());
/* 177 */       boolean validExtra = (extraDataFileSize == this.extraDataFile.length());
/* 178 */       boolean validContrib = (contributionsFileSize == this.contributionsFile.length());
/* 179 */       boolean validContributors = (contributorsFileSize == this.contributorsFile.length());
/* 180 */       boolean validNamespace = (namespacesFileSize == this.namespacesFile.length());
/* 181 */       boolean validOrphan = (orphansFileSize == this.orphansFile.length());
/*     */       
/* 183 */       return (validMain && validExtra && validContrib && validContributors && validNamespace && validOrphan);
/* 184 */     } catch (IOException e) {
/* 185 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_registryCacheInconsistent, e));
/* 186 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object loadConfigurationElement(int offset) {
/*     */     try {
/* 192 */       synchronized (this.mainDataFile) {
/* 193 */         goToInputFile(offset);
/* 194 */         return basicLoadConfigurationElement(this.mainInput, null);
/*     */       } 
/* 196 */     } catch (IOException e) {
/* 197 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.mainDataFile);
/* 198 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 201 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private ConfigurationElement basicLoadConfigurationElement(DataInputStream is, String actualContributorId) throws IOException {
/* 206 */     int self = is.readInt();
/* 207 */     String contributorId = readStringOrNull(is);
/* 208 */     String name = readStringOrNull(is);
/* 209 */     int parentId = is.readInt();
/* 210 */     byte parentType = is.readByte();
/* 211 */     int misc = is.readInt();
/* 212 */     String[] propertiesAndValue = readPropertiesAndValue(is);
/* 213 */     int[] children = readArray(is);
/* 214 */     if (actualContributorId == null)
/* 215 */       actualContributorId = contributorId; 
/* 216 */     ConfigurationElement result = getObjectFactory().createConfigurationElement(self, actualContributorId, name, propertiesAndValue, children, misc, parentId, parentType, true);
/* 217 */     if (this.registry.isMultiLanguage()) {
/* 218 */       int numberOfLocales = is.readInt();
/* 219 */       DirectMap translated = null;
/* 220 */       if (numberOfLocales != 0) {
/* 221 */         translated = new DirectMap(numberOfLocales, 0.5F);
/* 222 */         String[] NLs = readStringArray(is);
/* 223 */         for (int i = 0; i < numberOfLocales; i++) {
/* 224 */           String[] translatedProperties = readStringArray(is);
/* 225 */           translated.put(NLs[i], translatedProperties);
/*     */         } 
/*     */       } 
/* 228 */       ConfigurationElementMulti multiCE = (ConfigurationElementMulti)result;
/* 229 */       if (translated != null)
/* 230 */         multiCE.setTranslatedProperties(translated); 
/*     */     } 
/* 232 */     return result;
/*     */   }
/*     */   
/*     */   private String[] readStringArray(DataInputStream is) throws IOException {
/* 236 */     int size = is.readInt();
/* 237 */     if (size == 0)
/* 238 */       return null; 
/* 239 */     String[] result = new String[size];
/* 240 */     for (int i = 0; i < size; i++) {
/* 241 */       result[i] = readStringOrNull(is);
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */   
/*     */   public Object loadThirdLevelConfigurationElements(int offset, RegistryObjectManager objectManager) {
/*     */     try {
/* 248 */       synchronized (this.extraDataFile) {
/* 249 */         goToExtraFile(offset);
/* 250 */         return loadConfigurationElementAndChildren(null, this.extraInput, 3, 2147483647, objectManager, null);
/*     */       } 
/* 252 */     } catch (IOException e) {
/* 253 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.extraDataFile);
/* 254 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 257 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ConfigurationElement loadConfigurationElementAndChildren(DataInputStream is, DataInputStream extraIs, int depth, int maxDepth, RegistryObjectManager objectManager, String namespaceOwnerId) throws IOException {
/* 263 */     DataInputStream currentStream = is;
/* 264 */     if (depth > 2) {
/* 265 */       currentStream = extraIs;
/*     */     }
/* 267 */     ConfigurationElement ce = basicLoadConfigurationElement(currentStream, namespaceOwnerId);
/* 268 */     if (namespaceOwnerId == null)
/* 269 */       namespaceOwnerId = ce.getContributorId(); 
/* 270 */     int[] children = ce.getRawChildren();
/* 271 */     if (depth + 1 > maxDepth) {
/* 272 */       return ce;
/*     */     }
/* 274 */     for (int i = 0; i < children.length; i++) {
/* 275 */       ConfigurationElement tmp = loadConfigurationElementAndChildren(currentStream, extraIs, depth + 1, maxDepth, objectManager, namespaceOwnerId);
/* 276 */       objectManager.add(tmp, this.holdObjects);
/*     */     } 
/* 278 */     return ce;
/*     */   }
/*     */   
/*     */   private String[] readPropertiesAndValue(DataInputStream inputStream) throws IOException {
/* 282 */     int numberOfProperties = inputStream.readInt();
/* 283 */     if (numberOfProperties == 0)
/* 284 */       return RegistryObjectManager.EMPTY_STRING_ARRAY; 
/* 285 */     String[] properties = new String[numberOfProperties];
/* 286 */     for (int i = 0; i < numberOfProperties; i++) {
/* 287 */       properties[i] = readStringOrNull(inputStream);
/*     */     }
/* 289 */     return properties;
/*     */   }
/*     */   
/*     */   public Object loadExtension(int offset) {
/*     */     try {
/* 294 */       synchronized (this.mainDataFile) {
/* 295 */         goToInputFile(offset);
/* 296 */         return basicLoadExtension(this.mainInput);
/*     */       } 
/* 298 */     } catch (IOException e) {
/* 299 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.mainDataFile);
/* 300 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */ 
/*     */       
/* 304 */       return null;
/*     */     } 
/*     */   }
/*     */   private Extension basicLoadExtension(DataInputStream inputStream) throws IOException {
/* 308 */     int self = inputStream.readInt();
/* 309 */     String simpleId = readStringOrNull(this.mainInput);
/* 310 */     String namespace = readStringOrNull(this.mainInput);
/* 311 */     int[] children = readArray(this.mainInput);
/* 312 */     int extraData = this.mainInput.readInt();
/* 313 */     return getObjectFactory().createExtension(self, simpleId, namespace, children, extraData, true);
/*     */   }
/*     */   
/*     */   public ExtensionPoint loadExtensionPointTree(int offset, RegistryObjectManager objects) {
/*     */     try {
/* 318 */       synchronized (this.mainDataFile) {
/* 319 */         ExtensionPoint xpt = (ExtensionPoint)loadExtensionPoint(offset);
/* 320 */         int[] children = xpt.getRawChildren();
/* 321 */         int nbrOfExtension = children.length; int i;
/* 322 */         for (i = 0; i < nbrOfExtension; i++) {
/* 323 */           Extension loaded = basicLoadExtension(this.mainInput);
/* 324 */           objects.add(loaded, this.holdObjects);
/*     */         } 
/*     */         
/* 327 */         for (i = 0; i < nbrOfExtension; i++) {
/* 328 */           int nbrOfCe = this.mainInput.readInt();
/* 329 */           for (int j = 0; j < nbrOfCe; j++)
/*     */           {
/*     */             
/* 332 */             objects.add(loadConfigurationElementAndChildren(this.mainInput, null, 1, 2, objects, null), this.holdObjects);
/*     */           }
/*     */         } 
/* 335 */         return xpt;
/*     */       } 
/* 337 */     } catch (IOException e) {
/* 338 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.mainDataFile);
/* 339 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 342 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object loadExtensionPoint(int offset) {
/*     */     try {
/* 348 */       goToInputFile(offset);
/* 349 */       return basicLoadExtensionPoint();
/* 350 */     } catch (IOException e) {
/* 351 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.mainDataFile);
/* 352 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 355 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private ExtensionPoint basicLoadExtensionPoint() throws IOException {
/* 360 */     int self = this.mainInput.readInt();
/* 361 */     int[] children = readArray(this.mainInput);
/* 362 */     int extraData = this.mainInput.readInt();
/* 363 */     return getObjectFactory().createExtensionPoint(self, children, extraData, true);
/*     */   }
/*     */   
/*     */   private int[] readArray(DataInputStream in) throws IOException {
/* 367 */     int arraySize = in.readInt();
/* 368 */     if (arraySize == 0)
/* 369 */       return RegistryObjectManager.EMPTY_INT_ARRAY; 
/* 370 */     int[] result = new int[arraySize];
/* 371 */     for (int i = 0; i < arraySize; i++) {
/* 372 */       result[i] = in.readInt();
/*     */     }
/* 374 */     return result;
/*     */   }
/*     */   
/*     */   private void goToInputFile(int offset) throws IOException {
/* 378 */     this.mainDataFile.seek(offset);
/*     */   }
/*     */   
/*     */   private void goToExtraFile(int offset) throws IOException {
/* 382 */     this.extraDataFile.seek(offset);
/*     */   }
/*     */   
/*     */   private String readStringOrNull(DataInputStream in) throws IOException {
/* 386 */     byte type = in.readByte();
/* 387 */     if (type == 0)
/* 388 */       return null; 
/* 389 */     return readUTF(in, type);
/*     */   }
/*     */   
/*     */   public String[] loadExtensionExtraData(int dataPosition) {
/*     */     try {
/* 394 */       synchronized (this.extraDataFile) {
/* 395 */         goToExtraFile(dataPosition);
/* 396 */         return basicLoadExtensionExtraData();
/*     */       } 
/* 398 */     } catch (IOException e) {
/* 399 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.extraDataFile);
/* 400 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 403 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String[] basicLoadExtensionExtraData() throws IOException {
/* 408 */     return new String[] { readStringOrNull(this.extraInput), readStringOrNull(this.extraInput), readStringOrNull(this.extraInput) };
/*     */   }
/*     */   
/*     */   public String[] loadExtensionPointExtraData(int offset) {
/*     */     try {
/* 413 */       synchronized (this.extraDataFile) {
/* 414 */         goToExtraFile(offset);
/* 415 */         return basicLoadExtensionPointExtraData();
/*     */       } 
/* 417 */     } catch (IOException e) {
/* 418 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.extraDataFile);
/* 419 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*     */ 
/*     */       
/* 422 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String[] basicLoadExtensionPointExtraData() throws IOException {
/* 427 */     String[] result = new String[5];
/* 428 */     result[0] = readStringOrNull(this.extraInput);
/* 429 */     result[1] = readStringOrNull(this.extraInput);
/* 430 */     result[2] = readStringOrNull(this.extraInput);
/* 431 */     result[3] = readStringOrNull(this.extraInput);
/* 432 */     result[4] = readStringOrNull(this.extraInput);
/* 433 */     return result;
/*     */   }
/*     */   
/*     */   public KeyedHashSet loadContributions() {
/* 437 */     DataInputStream namespaceInput = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/* 451 */     } catch (IOException e) {
/* 452 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.contributionsFile);
/* 453 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/* 454 */       return null;
/*     */     } finally {
/* 456 */       if (namespaceInput != null) {
/*     */         try {
/* 458 */           namespaceInput.close();
/* 459 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<String, RegistryContributor> loadContributors() {
/* 468 */     HashMap<String, RegistryContributor> result = null;
/* 469 */     DataInputStream contributorsInput = null;
/*     */     try {
/* 471 */       synchronized (this.contributorsFile) {
/* 472 */         contributorsInput = new DataInputStream(new BufferedInputStream(new FileInputStream(this.contributorsFile)));
/* 473 */         int size = contributorsInput.readInt();
/* 474 */         result = new HashMap<>((int)(size * 1.2F));
/* 475 */         for (int i = 0; i < size; i++) {
/* 476 */           String id = readStringOrNull(contributorsInput);
/* 477 */           String name = readStringOrNull(contributorsInput);
/* 478 */           String hostId = readStringOrNull(contributorsInput);
/* 479 */           String hostName = readStringOrNull(contributorsInput);
/* 480 */           result.put(id, new RegistryContributor(id, name, hostId, hostName));
/*     */         } 
/*     */       } 
/* 483 */       return result;
/* 484 */     } catch (IOException e) {
/* 485 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.contributorsFile);
/* 486 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/* 487 */       return null;
/*     */     } finally {
/* 489 */       if (contributorsInput != null) {
/*     */         try {
/* 491 */           contributorsInput.close();
/* 492 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyedHashSet loadNamespaces() {
/* 499 */     DataInputStream namespaceInput = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/* 514 */     } catch (IOException e) {
/* 515 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.namespacesFile);
/* 516 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/* 517 */       return null;
/*     */     } finally {
/* 519 */       if (namespaceInput != null) {
/*     */         try {
/* 521 */           namespaceInput.close();
/* 522 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAllOrphans(RegistryObjectManager objectManager) throws IOException {
/* 530 */     int orphans = objectManager.getOrphanExtensions().size();
/* 531 */     for (int k = 0; k < orphans; k++) {
/* 532 */       int numberOfOrphanExtensions = this.mainInput.readInt(); int i;
/* 533 */       for (i = 0; i < numberOfOrphanExtensions; i++) {
/* 534 */         loadFullExtension(objectManager);
/*     */       }
/* 536 */       for (i = 0; i < numberOfOrphanExtensions; i++) {
/* 537 */         int nbrOfCe = this.mainInput.readInt();
/* 538 */         for (int j = 0; j < nbrOfCe; j++) {
/* 539 */           objectManager.add(loadConfigurationElementAndChildren(this.mainInput, this.extraInput, 1, 2147483647, objectManager, null), true);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readAllCache(RegistryObjectManager objectManager) {
/*     */     try {
/* 548 */       int size = objectManager.getExtensionPoints().size();
/* 549 */       for (int i = 0; i < size; i++) {
/* 550 */         objectManager.add(readAllExtensionPointTree(objectManager), this.holdObjects);
/*     */       }
/* 552 */       loadAllOrphans(objectManager);
/* 553 */     } catch (IOException e) {
/* 554 */       String message = NLS.bind(RegistryMessages.meta_regCacheIOExceptionReading, this.mainDataFile);
/* 555 */       log(new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/* 556 */       return false;
/*     */     } 
/* 558 */     return true;
/*     */   }
/*     */   
/*     */   private ExtensionPoint readAllExtensionPointTree(RegistryObjectManager objectManager) throws IOException {
/* 562 */     ExtensionPoint xpt = loadFullExtensionPoint();
/* 563 */     int[] children = xpt.getRawChildren();
/* 564 */     int nbrOfExtension = children.length; int i;
/* 565 */     for (i = 0; i < nbrOfExtension; i++) {
/* 566 */       loadFullExtension(objectManager);
/*     */     }
/*     */     
/* 569 */     for (i = 0; i < nbrOfExtension; i++) {
/* 570 */       int nbrOfCe = this.mainInput.readInt();
/* 571 */       for (int j = 0; j < nbrOfCe; j++) {
/* 572 */         objectManager.add(loadConfigurationElementAndChildren(this.mainInput, this.extraInput, 1, 2147483647, objectManager, null), true);
/*     */       }
/*     */     } 
/* 575 */     return xpt;
/*     */   }
/*     */   
/*     */   private ExtensionPoint loadFullExtensionPoint() throws IOException {
/* 579 */     ExtensionPoint xpt = basicLoadExtensionPoint();
/* 580 */     String[] tmp = basicLoadExtensionPointExtraData();
/* 581 */     xpt.setLabel(tmp[0]);
/* 582 */     xpt.setSchema(tmp[1]);
/* 583 */     xpt.setUniqueIdentifier(tmp[2]);
/* 584 */     xpt.setNamespace(tmp[3]);
/* 585 */     xpt.setContributorId(tmp[4]);
/* 586 */     return xpt;
/*     */   }
/*     */ 
/*     */   
/*     */   private Extension loadFullExtension(RegistryObjectManager objectManager) throws IOException {
/* 591 */     Extension loaded = basicLoadExtension(this.mainInput);
/* 592 */     String[] tmp = basicLoadExtensionExtraData();
/* 593 */     loaded.setLabel(tmp[0]);
/* 594 */     loaded.setExtensionPointIdentifier(tmp[1]);
/* 595 */     loaded.setContributorId(tmp[2]);
/* 596 */     objectManager.add(loaded, this.holdObjects);
/* 597 */     return loaded;
/*     */   }
/*     */   
/*     */   public HashMap<String, int[]> loadOrphans() {
/* 601 */     DataInputStream orphanInput = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/* 614 */     } catch (IOException iOException) {
/* 615 */       return null;
/*     */     } finally {
/* 617 */       if (orphanInput != null) {
/*     */         try {
/* 619 */           orphanInput.close();
/* 620 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHoldObjects(boolean holdObjects) {
/* 628 */     this.holdObjects = holdObjects;
/*     */   }
/*     */   
/*     */   private void log(Status status) {
/* 632 */     this.registry.log((IStatus)status);
/*     */   }
/*     */   
/*     */   private RegistryObjectFactory getObjectFactory() {
/* 636 */     return this.registry.getElementFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getTestFileName() {
/* 641 */     return ".table";
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 646 */       if (this.mainInput != null)
/* 647 */         this.mainInput.close(); 
/* 648 */       if (this.extraInput != null)
/* 649 */         this.extraInput.close(); 
/* 650 */     } catch (IOException e) {
/* 651 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_registryCacheReadProblems, e));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String readUTF(DataInputStream in, int type) throws IOException {
/*     */     String value;
/* 657 */     if (type == 2) {
/* 658 */       int length = in.readInt();
/* 659 */       byte[] data = new byte[length];
/* 660 */       in.readFully(data);
/* 661 */       value = new String(data, StandardCharsets.UTF_8);
/*     */     } else {
/* 663 */       value = in.readUTF();
/*     */     } 
/*     */     
/* 666 */     Map<String, String> map = null;
/* 667 */     if (this.stringPool != null) {
/* 668 */       map = this.stringPool.get();
/*     */     }
/* 670 */     if (map == null) {
/* 671 */       map = new HashMap<>();
/* 672 */       this.stringPool = new SoftReference<>(map);
/*     */     } 
/*     */     
/* 675 */     String pooledString = map.get(value);
/* 676 */     if (pooledString == null) {
/* 677 */       map.put(value, value);
/* 678 */       return value;
/*     */     } 
/*     */     
/* 681 */     return pooledString;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\TableReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */