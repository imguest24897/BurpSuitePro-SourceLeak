/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseExtensionHandle
/*     */   extends Handle
/*     */   implements IExtension
/*     */ {
/*     */   public BaseExtensionHandle(IObjectManager objectManager, int id) {
/*  29 */     super(objectManager, id);
/*     */   }
/*     */   
/*     */   protected Extension getExtension() {
/*  33 */     return (Extension)this.objectManager.getObject(getId(), (byte)2);
/*     */   }
/*     */   
/*     */   protected boolean shouldPersist() {
/*  37 */     return getExtension().shouldPersist();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  43 */     return getContributor().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceIdentifier() {
/*  48 */     return getExtension().getNamespaceIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContributor getContributor() {
/*  53 */     return getExtension().getContributor();
/*     */   }
/*     */   
/*     */   String getContributorId() {
/*  57 */     return getExtension().getContributorId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExtensionPointUniqueIdentifier() {
/*  62 */     return getExtension().getExtensionPointIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  67 */     return getExtension().getLabel();
/*     */   }
/*     */   
/*     */   public String getLabelAsIs() {
/*  71 */     return getExtension().getLabelAsIs();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel(String locale) {
/*  76 */     return getExtension().getLabel(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSimpleIdentifier() {
/*  81 */     return getExtension().getSimpleIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUniqueIdentifier() {
/*  86 */     return getExtension().getUniqueIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public IConfigurationElement[] getConfigurationElements() {
/*  91 */     return (IConfigurationElement[])this.objectManager.getHandles(getExtension().getRawChildren(), (byte)1);
/*     */   }
/*     */ 
/*     */   
/*     */   RegistryObject getObject() {
/*  96 */     return getExtension();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/*     */     try {
/* 102 */       getExtension();
/* 103 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/* 104 */       return false;
/*     */     } 
/* 106 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\BaseExtensionHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */