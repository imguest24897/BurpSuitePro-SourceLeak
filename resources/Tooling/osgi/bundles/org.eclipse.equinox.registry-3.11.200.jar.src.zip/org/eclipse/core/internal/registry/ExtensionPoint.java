/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtensionPoint
/*     */   extends RegistryObject
/*     */ {
/*  25 */   public static final ExtensionPoint[] EMPTY_ARRAY = new ExtensionPoint[0];
/*     */   
/*     */   private Object extraInformation;
/*     */   
/*     */   private static final byte LABEL = 0;
/*     */   
/*     */   private static final byte SCHEMA = 1;
/*     */   
/*     */   private static final byte QUALIFIED_NAME = 2;
/*     */   private static final byte NAMESPACE = 3;
/*     */   private static final byte CONTRIBUTOR_ID = 4;
/*     */   private static final int EXTRA_SIZE = 5;
/*     */   
/*     */   protected ExtensionPoint(ExtensionRegistry registry, boolean persist) {
/*  39 */     super(registry, persist);
/*     */   }
/*     */   
/*     */   protected ExtensionPoint(int self, int[] children, int dataOffset, ExtensionRegistry registry, boolean persist) {
/*  43 */     super(registry, persist);
/*     */     
/*  45 */     setObjectId(self);
/*  46 */     setRawChildren(children);
/*  47 */     setExtraDataOffset(dataOffset);
/*     */   }
/*     */   
/*     */   protected String getSimpleIdentifier() {
/*  51 */     return getUniqueIdentifier().substring(getUniqueIdentifier().lastIndexOf('.') + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private String[] getExtraData() {
/*  56 */     if (noExtraData()) {
/*  57 */       if (this.extraInformation != null)
/*  58 */         return (String[])this.extraInformation; 
/*  59 */       return new String[5];
/*     */     } 
/*     */ 
/*     */     
/*  63 */     String[] result = null;
/*  64 */     if (this.extraInformation != null) { if ((result = (String[])((this.extraInformation instanceof SoftReference) ? ((SoftReference<String[]>)this.extraInformation).get() : this.extraInformation)) == null)
/*  65 */       { result = this.registry.getTableReader().loadExtensionPointExtraData(getExtraDataOffset());
/*  66 */         this.extraInformation = new SoftReference<>(result);
/*     */         
/*  68 */         return result; }  return result; }  result = this.registry.getTableReader().loadExtensionPointExtraData(getExtraDataOffset()); this.extraInformation = new SoftReference<>(result); return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureExtraInformationType() {
/*  75 */     if (this.extraInformation instanceof SoftReference) {
/*  76 */       this.extraInformation = ((SoftReference)this.extraInformation).get();
/*     */     }
/*  78 */     if (this.extraInformation == null) {
/*  79 */       this.extraInformation = new String[5];
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getSchemaReference() {
/*  84 */     String[] result = getExtraData();
/*  85 */     return (result[1] == null) ? "" : result[1].replace(File.separatorChar, '/');
/*     */   }
/*     */   
/*     */   protected String getLabel() {
/*  89 */     String[] result = getExtraData();
/*  90 */     return (result[0] == null) ? "" : result[0];
/*     */   }
/*     */   
/*     */   protected String getUniqueIdentifier() {
/*  94 */     return getExtraData()[2];
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/*  98 */     return getExtraData()[3];
/*     */   }
/*     */   
/*     */   protected String getContributorId() {
/* 102 */     return getExtraData()[4];
/*     */   }
/*     */   
/*     */   public IContributor getContributor() {
/* 106 */     return (IContributor)this.registry.getObjectManager().getContributor(getContributorId());
/*     */   }
/*     */   
/*     */   void setSchema(String value) {
/* 110 */     ensureExtraInformationType();
/* 111 */     ((String[])this.extraInformation)[1] = value;
/*     */   }
/*     */   
/*     */   void setLabel(String value) {
/* 115 */     ensureExtraInformationType();
/* 116 */     ((String[])this.extraInformation)[0] = value;
/*     */   }
/*     */   
/*     */   void setUniqueIdentifier(String value) {
/* 120 */     ensureExtraInformationType();
/* 121 */     ((String[])this.extraInformation)[2] = value;
/*     */   }
/*     */   
/*     */   void setNamespace(String value) {
/* 125 */     ensureExtraInformationType();
/* 126 */     ((String[])this.extraInformation)[3] = value;
/*     */   }
/*     */   
/*     */   void setContributorId(String id) {
/* 130 */     ensureExtraInformationType();
/* 131 */     ((String[])this.extraInformation)[4] = id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return getUniqueIdentifier();
/*     */   }
/*     */   
/*     */   protected String getLabelAsIs() {
/* 140 */     String[] result = getExtraData();
/* 141 */     return (result[0] == null) ? "" : result[0];
/*     */   }
/*     */   
/*     */   protected String getLabel(String locale) {
/* 145 */     this.registry.logMultiLangError();
/* 146 */     return getLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionPoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */