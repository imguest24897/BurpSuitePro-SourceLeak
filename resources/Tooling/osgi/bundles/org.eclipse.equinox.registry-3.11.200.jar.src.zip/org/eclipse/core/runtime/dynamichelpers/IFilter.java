package org.eclipse.core.runtime.dynamichelpers;

import org.eclipse.core.runtime.IExtensionPoint;

public interface IFilter {
  boolean matches(IExtensionPoint paramIExtensionPoint);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\dynamichelpers\IFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */