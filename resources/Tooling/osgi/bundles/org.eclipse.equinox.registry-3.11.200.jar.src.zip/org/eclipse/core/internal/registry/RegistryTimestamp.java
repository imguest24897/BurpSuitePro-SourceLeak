/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RegistryTimestamp
/*    */ {
/*    */   private long aggregateTimestamp;
/*    */   private boolean modified;
/*    */   
/*    */   public RegistryTimestamp() {
/* 37 */     reset();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getContentsTimestamp() {
/* 45 */     return this.aggregateTimestamp;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(long timestamp) {
/* 53 */     this.aggregateTimestamp = timestamp;
/* 54 */     this.modified = false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 61 */     this.aggregateTimestamp = 0L;
/* 62 */     this.modified = false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isModifed() {
/* 71 */     return this.modified;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void add(long timestamp) {
/* 79 */     this.aggregateTimestamp ^= timestamp;
/* 80 */     this.modified = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove(long timestamp) {
/* 88 */     this.aggregateTimestamp ^= timestamp;
/* 89 */     this.modified = true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryTimestamp.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */