/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryIndexElement
/*    */   implements KeyedElement
/*    */ {
/*    */   protected final String key;
/*    */   private RegistryIndexChildren extensionPoints;
/*    */   private RegistryIndexChildren extensions;
/*    */   
/*    */   public RegistryIndexElement(String key) {
/* 28 */     this.key = key;
/*    */   }
/*    */   
/*    */   public RegistryIndexElement(String key, int[] extensionPoints, int[] extensions) {
/* 32 */     this.key = key;
/* 33 */     this.extensionPoints = new RegistryIndexChildren(extensionPoints);
/* 34 */     this.extensions = new RegistryIndexChildren(extensions);
/*    */   }
/*    */   
/*    */   protected int[] getExtensions() {
/* 38 */     if (this.extensions == null)
/* 39 */       return RegistryIndexChildren.EMPTY_ARRAY; 
/* 40 */     return this.extensions.getChildren();
/*    */   }
/*    */   
/*    */   protected int[] getExtensionPoints() {
/* 44 */     if (this.extensionPoints == null)
/* 45 */       return RegistryIndexChildren.EMPTY_ARRAY; 
/* 46 */     return this.extensionPoints.getChildren();
/*    */   }
/*    */   
/*    */   public boolean updateExtension(int id, boolean add) {
/* 50 */     if (this.extensions == null) {
/* 51 */       this.extensions = new RegistryIndexChildren();
/*    */     }
/* 53 */     if (add)
/* 54 */       return this.extensions.linkChild(id); 
/* 55 */     return this.extensions.unlinkChild(id);
/*    */   }
/*    */   
/*    */   public boolean updateExtensions(int[] IDs, boolean add) {
/* 59 */     if (this.extensions == null) {
/* 60 */       this.extensions = new RegistryIndexChildren();
/*    */     }
/* 62 */     if (add)
/* 63 */       return this.extensions.linkChildren(IDs); 
/* 64 */     return this.extensions.unlinkChildren(IDs);
/*    */   }
/*    */   
/*    */   public boolean updateExtensionPoint(int id, boolean add) {
/* 68 */     if (this.extensionPoints == null) {
/* 69 */       this.extensionPoints = new RegistryIndexChildren();
/*    */     }
/* 71 */     if (add)
/* 72 */       return this.extensionPoints.linkChild(id); 
/* 73 */     return this.extensionPoints.unlinkChild(id);
/*    */   }
/*    */   
/*    */   public boolean updateExtensionPoints(int[] IDs, boolean add) {
/* 77 */     if (this.extensionPoints == null) {
/* 78 */       this.extensionPoints = new RegistryIndexChildren();
/*    */     }
/* 80 */     if (add)
/* 81 */       return this.extensionPoints.linkChildren(IDs); 
/* 82 */     return this.extensionPoints.unlinkChildren(IDs);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getKeyHashCode() {
/* 88 */     return getKey().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getKey() {
/* 93 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean compare(KeyedElement other) {
/* 98 */     return this.key.equals(((RegistryIndexElement)other).key);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryIndexElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */