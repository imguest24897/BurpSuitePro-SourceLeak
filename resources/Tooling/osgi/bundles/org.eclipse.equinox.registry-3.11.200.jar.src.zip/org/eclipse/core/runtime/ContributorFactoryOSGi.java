/*    */ package org.eclipse.core.runtime;
/*    */ 
/*    */ import org.eclipse.core.internal.registry.osgi.OSGIUtils;
/*    */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ContributorFactoryOSGi
/*    */ {
/*    */   public static IContributor createContributor(Bundle contributor) {
/* 40 */     String id = Long.toString(contributor.getBundleId());
/* 41 */     String name = contributor.getSymbolicName();
/* 42 */     String hostId = null;
/* 43 */     String hostName = null;
/*    */ 
/*    */     
/* 46 */     if (OSGIUtils.getDefault().isFragment(contributor)) {
/* 47 */       Bundle[] hosts = OSGIUtils.getDefault().getHosts(contributor);
/* 48 */       if (hosts != null) {
/* 49 */         Bundle hostBundle = hosts[0];
/* 50 */         hostId = Long.toString(hostBundle.getBundleId());
/* 51 */         hostName = hostBundle.getSymbolicName();
/*    */       } 
/*    */     } 
/*    */     
/* 55 */     return (IContributor)new RegistryContributor(id, name, hostId, hostName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Bundle resolve(IContributor contributor) {
/* 71 */     if (contributor == null)
/* 72 */       return null; 
/* 73 */     if (!(contributor instanceof RegistryContributor))
/* 74 */       return null; 
/* 75 */     String symbolicName = ((RegistryContributor)contributor).getActualName();
/* 76 */     return OSGIUtils.getDefault().getBundle(symbolicName);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\ContributorFactoryOSGi.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */