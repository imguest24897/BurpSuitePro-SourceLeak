/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedRandomInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private RandomAccessFile inputFile;
/*     */   private String filePath;
/*     */   private int buffer_size;
/*     */   private int buffer_pos;
/*  30 */   private long buffer_start = 0L;
/*     */ 
/*     */   
/*     */   private long file_pointer;
/*     */ 
/*     */   
/*     */   private byte[] buffer;
/*     */ 
/*     */   
/*     */   public BufferedRandomInputStream(File file) throws IOException {
/*  40 */     this(file, 2048);
/*     */   }
/*     */   
/*     */   public BufferedRandomInputStream(File file, int bufferSize) throws IOException {
/*  44 */     this.filePath = file.getCanonicalPath();
/*  45 */     this.inputFile = new RandomAccessFile(file, "r");
/*  46 */     this.buffer = new byte[bufferSize];
/*  47 */     this.file_pointer = 0L;
/*  48 */     resetBuffer();
/*     */   }
/*     */   
/*     */   private void resetBuffer() {
/*  52 */     this.buffer_pos = 0;
/*  53 */     this.buffer_size = 0;
/*  54 */     this.buffer_start = 0L;
/*     */   }
/*     */   
/*     */   private int fillBuffer() throws IOException {
/*  58 */     this.buffer_pos = 0;
/*  59 */     this.buffer_start = this.file_pointer;
/*  60 */     this.buffer_size = this.inputFile.read(this.buffer, 0, this.buffer.length);
/*  61 */     this.file_pointer += this.buffer_size;
/*  62 */     return this.buffer_size;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  67 */     if (this.buffer_pos >= this.buffer_size && 
/*  68 */       fillBuffer() <= 0) {
/*  69 */       return -1;
/*     */     }
/*  71 */     return this.buffer[this.buffer_pos++] & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/*  76 */     int available = this.buffer_size - this.buffer_pos;
/*  77 */     if (available < 0) {
/*  78 */       return -1;
/*     */     }
/*  80 */     if (len <= available) {
/*  81 */       System.arraycopy(this.buffer, this.buffer_pos, b, off, len);
/*  82 */       this.buffer_pos += len;
/*  83 */       return len;
/*     */     } 
/*     */     
/*  86 */     System.arraycopy(this.buffer, this.buffer_pos, b, off, available);
/*  87 */     if (fillBuffer() <= 0) {
/*  88 */       return available;
/*     */     }
/*  90 */     return available + read(b, off + available, len - available);
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/*  95 */     if (n <= 0L) {
/*  96 */       return 0L;
/*     */     }
/*  98 */     int available = this.buffer_size - this.buffer_pos;
/*  99 */     if (n <= available) {
/* 100 */       this.buffer_pos = (int)(this.buffer_pos + n);
/* 101 */       return n;
/*     */     } 
/* 103 */     resetBuffer();
/* 104 */     int skipped = this.inputFile.skipBytes((int)(n - available));
/* 105 */     this.file_pointer += skipped;
/* 106 */     return (available + skipped);
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() {
/* 111 */     return this.buffer_size - this.buffer_pos;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 116 */     this.inputFile.close();
/* 117 */     this.inputFile = null;
/* 118 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 123 */     return this.filePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 134 */     if (pos >= this.buffer_start && pos < this.buffer_start + this.buffer_size) {
/*     */       
/* 136 */       this.buffer_pos = (int)(pos - this.buffer_start);
/*     */     } else {
/*     */       
/* 139 */       this.inputFile.seek(pos);
/* 140 */       this.file_pointer = pos;
/* 141 */       resetBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 151 */     return this.inputFile.length();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\BufferedRandomInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */