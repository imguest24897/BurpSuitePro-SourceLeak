/*    */ package org.eclipse.core.internal.registry.osgi;
/*    */ 
/*    */ import org.eclipse.core.runtime.IExtensionRegistry;
/*    */ import org.eclipse.core.runtime.spi.IRegistryProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RegistryProviderOSGI
/*    */   implements IRegistryProvider
/*    */ {
/*    */   private final IExtensionRegistry registry;
/*    */   
/*    */   public RegistryProviderOSGI(IExtensionRegistry registry) {
/* 24 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IExtensionRegistry getRegistry() {
/* 32 */     return this.registry;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\RegistryProviderOSGI.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */