/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Stack;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ public class ExtensionsParser
/*     */   extends DefaultHandler
/*     */ {
/*     */   private static final String NO_EXTENSION_MUNGING = "eclipse.noExtensionMunging";
/*     */   private static final String VERSION_3_0 = "3.0";
/*     */   private static final String VERSION_3_2 = "3.2";
/*     */   private static Map<String, String> extensionPointMap;
/*     */   
/*     */   static {
/*  34 */     initializeExtensionPointMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializeExtensionPointMap() {
/*  41 */     Map<String, String> map = new HashMap<>(13);
/*  42 */     map.put("org.eclipse.ui.markerImageProvider", "org.eclipse.ui.ide.markerImageProvider");
/*  43 */     map.put("org.eclipse.ui.markerHelp", "org.eclipse.ui.ide.markerHelp");
/*  44 */     map.put("org.eclipse.ui.markerImageProviders", "org.eclipse.ui.ide.markerImageProviders");
/*  45 */     map.put("org.eclipse.ui.markerResolution", "org.eclipse.ui.ide.markerResolution");
/*  46 */     map.put("org.eclipse.ui.projectNatureImages", "org.eclipse.ui.ide.projectNatureImages");
/*  47 */     map.put("org.eclipse.ui.resourceFilters", "org.eclipse.ui.ide.resourceFilters");
/*  48 */     map.put("org.eclipse.ui.markerUpdaters", "org.eclipse.ui.editors.markerUpdaters");
/*  49 */     map.put("org.eclipse.ui.documentProviders", "org.eclipse.ui.editors.documentProviders");
/*  50 */     map.put("org.eclipse.ui.workbench.texteditor.markerAnnotationSpecification", "org.eclipse.ui.editors.markerAnnotationSpecification");
/*  51 */     map.put("org.eclipse.help.browser", "org.eclipse.help.base.browser");
/*  52 */     map.put("org.eclipse.help.luceneAnalyzer", "org.eclipse.help.base.luceneAnalyzer");
/*  53 */     map.put("org.eclipse.help.webapp", "org.eclipse.help.base.webapp");
/*  54 */     map.put("org.eclipse.help.support", "org.eclipse.ui.helpSupport");
/*  55 */     extensionPointMap = map;
/*     */   }
/*     */   
/*  58 */   private static long cumulativeTime = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compatibilityMode;
/*     */ 
/*     */   
/*  65 */   private String locationName = null;
/*     */ 
/*     */   
/*  68 */   private final Stack<Integer> stateStack = new Stack<>();
/*     */ 
/*     */ 
/*     */   
/*  72 */   private final Stack<KeyedElement> objectStack = new Stack<>();
/*     */   
/*  74 */   private String schemaVersion = null;
/*     */   
/*     */   private final MultiStatus status;
/*     */   
/*     */   private final ExtensionRegistry registry;
/*     */   
/*     */   protected ResourceBundle resources;
/*     */   
/*     */   private RegistryObjectManager objectManager;
/*     */   
/*     */   private Contribution contribution;
/*     */   
/*     */   private String configurationElementValue;
/*     */   
/*     */   public static final int PARSE_PROBLEM = 1;
/*     */   
/*     */   public static final String PLUGIN = "plugin";
/*     */   
/*     */   public static final String PLUGIN_ID = "id";
/*     */   
/*     */   public static final String PLUGIN_NAME = "name";
/*     */   
/*     */   public static final String FRAGMENT = "fragment";
/*     */   
/*     */   public static final String BUNDLE_UID = "id";
/*     */   
/*     */   public static final String EXTENSION_POINT = "extension-point";
/*     */   
/*     */   public static final String EXTENSION_POINT_NAME = "name";
/*     */   
/*     */   public static final String EXTENSION_POINT_ID = "id";
/*     */   
/*     */   public static final String EXTENSION_POINT_SCHEMA = "schema";
/*     */   
/*     */   public static final String EXTENSION = "extension";
/*     */   
/*     */   public static final String EXTENSION_NAME = "name";
/*     */   
/*     */   public static final String EXTENSION_ID = "id";
/*     */   
/*     */   public static final String EXTENSION_TARGET = "point";
/*     */   
/*     */   public static final String ELEMENT = "element";
/*     */   
/*     */   public static final String ELEMENT_NAME = "name";
/*     */   
/*     */   public static final String ELEMENT_VALUE = "value";
/*     */   
/*     */   public static final String PROPERTY = "property";
/*     */   
/*     */   public static final String PROPERTY_NAME = "name";
/*     */   
/*     */   public static final String PROPERTY_VALUE = "value";
/*     */   
/*     */   private static final int IGNORED_ELEMENT_STATE = 0;
/*     */   
/*     */   private static final int INITIAL_STATE = 1;
/*     */   
/*     */   private static final int BUNDLE_STATE = 2;
/*     */   private static final int BUNDLE_EXTENSION_POINT_STATE = 5;
/*     */   private static final int BUNDLE_EXTENSION_STATE = 6;
/*     */   private static final int CONFIGURATION_ELEMENT_STATE = 10;
/*     */   private static final int EXTENSION_POINT_INDEX = 0;
/*     */   private static final int EXTENSION_INDEX = 1;
/*     */   private static final int LAST_INDEX = 1;
/* 139 */   private final ArrayList<RegistryObject>[] scratchVectors = (ArrayList<RegistryObject>[])new ArrayList[2];
/*     */   
/* 141 */   private Locator locator = null;
/*     */ 
/*     */   
/*     */   private boolean extractNamespaces = false;
/*     */   
/* 146 */   private ArrayList<String> processedExtensionIds = null;
/*     */ 
/*     */ 
/*     */   
/* 150 */   private final ArrayList<RegistryObject> addedRegistryObjects = new ArrayList<>(5);
/*     */ 
/*     */   
/*     */   public ExtensionsParser(MultiStatus status, ExtensionRegistry registry) {
/* 154 */     this.status = status;
/* 155 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {
/* 163 */     this.locator = locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/* 171 */     int state = ((Integer)this.stateStack.peek()).intValue();
/* 172 */     if (state != 10)
/*     */       return; 
/* 174 */     if (state == 10) {
/*     */ 
/*     */       
/* 177 */       ConfigurationElement currentConfigElement = (ConfigurationElement)this.objectStack.peek();
/* 178 */       String value = new String(ch, start, length);
/* 179 */       if (this.configurationElementValue == null) {
/* 180 */         if (value.trim().length() != 0) {
/* 181 */           this.configurationElementValue = value;
/*     */         }
/*     */       } else {
/* 184 */         this.configurationElementValue = String.valueOf(this.configurationElementValue) + value;
/*     */       } 
/* 186 */       if (this.configurationElementValue != null)
/* 187 */         currentConfigElement.setValue(this.configurationElementValue); 
/*     */     } 
/*     */   }
/*     */   public void endDocument() {}
/*     */   
/*     */   public void endElement(String uri, String elementName, String qName) {
/*     */     ArrayList<?> extensionPoints;
/*     */     ArrayList<?> extensions;
/*     */     int[] namespaceChildren;
/*     */     int position;
/*     */     ConfigurationElement currentConfigElement;
/*     */     String value;
/*     */     RegistryObject parent;
/*     */     int[] oldValues;
/*     */     int size;
/*     */     int[] newValues;
/*     */     int i;
/* 204 */     switch (((Integer)this.stateStack.peek()).intValue()) {
/*     */       case 0:
/* 206 */         this.stateStack.pop();
/*     */         break;
/*     */       
/*     */       case 1:
/* 210 */         internalError(NLS.bind(RegistryMessages.parse_internalStack, elementName));
/*     */         break;
/*     */       case 2:
/* 213 */         this.stateStack.pop();
/*     */         
/* 215 */         extensionPoints = this.scratchVectors[0];
/* 216 */         extensions = this.scratchVectors[1];
/* 217 */         namespaceChildren = new int[2 + extensionPoints.size() + extensions.size()];
/* 218 */         position = 2;
/*     */         
/* 220 */         if (extensionPoints.size() > 0) {
/* 221 */           namespaceChildren[0] = extensionPoints.size();
/* 222 */           for (Object extPoint : extensionPoints) {
/* 223 */             namespaceChildren[position++] = ((RegistryObject)extPoint).getObjectId();
/*     */           }
/* 225 */           extensionPoints.clear();
/*     */         } 
/*     */ 
/*     */         
/* 229 */         if (extensions.size() > 0) {
/* 230 */           Extension[] renamedExtensions = fixRenamedExtensionPoints(extensions.<Extension>toArray(new Extension[extensions.size()]));
/* 231 */           namespaceChildren[1] = renamedExtensions.length; byte b; int j; Extension[] arrayOfExtension1;
/* 232 */           for (j = (arrayOfExtension1 = renamedExtensions).length, b = 0; b < j; ) { Extension renamedExtension = arrayOfExtension1[b];
/* 233 */             namespaceChildren[position++] = renamedExtension.getObjectId(); b++; }
/*     */           
/* 235 */           extensions.clear();
/*     */         } 
/* 237 */         this.contribution.setRawChildren(namespaceChildren);
/*     */         break;
/*     */       case 5:
/* 240 */         if (elementName.equals("extension-point")) {
/* 241 */           this.stateStack.pop();
/*     */         }
/*     */         break;
/*     */       case 6:
/* 245 */         if (elementName.equals("extension")) {
/* 246 */           this.stateStack.pop();
/*     */           
/* 248 */           Extension currentExtension = (Extension)this.objectStack.pop();
/* 249 */           if (currentExtension.getNamespaceIdentifier() == null)
/* 250 */             currentExtension.setNamespaceIdentifier(this.contribution.getDefaultNamespace()); 
/* 251 */           currentExtension.setContributorId(this.contribution.getContributorId());
/* 252 */           this.scratchVectors[1].add(currentExtension);
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 10:
/* 257 */         this.stateStack.pop();
/*     */         
/* 259 */         this.configurationElementValue = null;
/* 260 */         currentConfigElement = (ConfigurationElement)this.objectStack.pop();
/*     */         
/* 262 */         value = currentConfigElement.getValueAsIs();
/* 263 */         if (value != null) {
/* 264 */           currentConfigElement.setValue(translate(value).trim());
/*     */         }
/*     */         
/* 267 */         parent = (RegistryObject)this.objectStack.peek();
/*     */         
/* 269 */         oldValues = parent.getRawChildren();
/* 270 */         size = oldValues.length;
/* 271 */         newValues = new int[size + 1];
/* 272 */         for (i = 0; i < size; i++) {
/* 273 */           newValues[i] = oldValues[i];
/*     */         }
/* 275 */         newValues[size] = currentConfigElement.getObjectId();
/* 276 */         parent.setRawChildren(newValues);
/* 277 */         currentConfigElement.setParentId(parent.getObjectId());
/* 278 */         currentConfigElement.setParentType((parent instanceof ConfigurationElement) ? 1 : 2);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(SAXParseException ex) {
/* 288 */     logStatus(ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatalError(SAXParseException ex) throws SAXException {
/* 296 */     cleanup();
/* 297 */     logStatus(ex);
/* 298 */     throw ex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanup() {
/* 305 */     for (RegistryObject object : this.addedRegistryObjects) {
/* 306 */       if (object instanceof ExtensionPoint) {
/* 307 */         String id = ((ExtensionPoint)object).getUniqueIdentifier();
/* 308 */         this.objectManager.removeExtensionPoint(id); continue;
/*     */       } 
/* 310 */       this.objectManager.remove(object.getObjectId(), true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleExtensionPointState(String elementName) {
/* 316 */     this.stateStack.push(Integer.valueOf(0));
/* 317 */     unknownElement("extension-point", elementName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleExtensionState(String elementName, Attributes attributes) {
/* 328 */     this.stateStack.push(Integer.valueOf(10));
/*     */     
/* 330 */     this.configurationElementValue = null;
/*     */ 
/*     */     
/* 333 */     ConfigurationElement currentConfigurationElement = this.registry.getElementFactory().createConfigurationElement(this.contribution.shouldPersist());
/* 334 */     currentConfigurationElement.setContributorId(this.contribution.getContributorId());
/* 335 */     this.objectStack.push(currentConfigurationElement);
/* 336 */     currentConfigurationElement.setName(elementName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     parseConfigurationElementAttributes(attributes);
/* 343 */     this.objectManager.add(currentConfigurationElement, true);
/* 344 */     this.addedRegistryObjects.add(currentConfigurationElement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleInitialState(String elementName, Attributes attributes) {
/* 350 */     this.compatibilityMode = (attributes.getLength() > 0);
/* 351 */     this.stateStack.push(Integer.valueOf(2));
/* 352 */     this.objectStack.push(this.contribution);
/*     */   }
/*     */   
/*     */   private void handleBundleState(String elementName, Attributes attributes) {
/* 356 */     if (elementName.equals("extension-point")) {
/* 357 */       this.stateStack.push(Integer.valueOf(5));
/* 358 */       parseExtensionPointAttributes(attributes);
/*     */       return;
/*     */     } 
/* 361 */     if (elementName.equals("extension")) {
/* 362 */       this.stateStack.push(Integer.valueOf(6));
/* 363 */       parseExtensionAttributes(attributes);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 369 */     this.stateStack.push(Integer.valueOf(0));
/* 370 */     if (!this.compatibilityMode)
/* 371 */       unknownElement("plugin", elementName); 
/*     */   }
/*     */   
/*     */   private void logStatus(SAXParseException ex) {
/* 375 */     String msg, name = ex.getSystemId();
/* 376 */     if (name == null)
/* 377 */       name = this.locationName; 
/* 378 */     if (name == null) {
/* 379 */       name = "";
/*     */     } else {
/* 381 */       name = name.substring(1 + name.lastIndexOf("/"));
/*     */     } 
/*     */     
/* 384 */     if (name.equals("")) {
/* 385 */       msg = NLS.bind(RegistryMessages.parse_error, ex.getMessage());
/*     */     } else {
/* 387 */       msg = NLS.bind(RegistryMessages.parse_errorNameLineColumn, new Object[] { name, Integer.toString(ex.getLineNumber()), Integer.toString(ex.getColumnNumber()), ex.getMessage() });
/* 388 */     }  error((IStatus)new Status(2, "org.eclipse.equinox.registry", 1, msg, ex));
/*     */   }
/*     */   
/*     */   public Contribution parseManifest(SAXParserFactory factory, InputSource in, String manifestName, RegistryObjectManager registryObjects, Contribution currentNamespace, ResourceBundle bundle) throws ParserConfigurationException, SAXException, IOException {
/* 392 */     long start = 0L;
/* 393 */     this.resources = bundle;
/* 394 */     this.objectManager = registryObjects;
/*     */     
/* 396 */     this.contribution = currentNamespace;
/* 397 */     if (this.registry.debug()) {
/* 398 */       start = System.currentTimeMillis();
/*     */     }
/* 400 */     if (factory == null) {
/* 401 */       throw new SAXException(RegistryMessages.parse_xmlParserNotAvailable);
/*     */     }
/*     */     try {
/* 404 */       this.locationName = in.getSystemId();
/* 405 */       if (this.locationName == null)
/* 406 */         this.locationName = manifestName; 
/* 407 */       factory.setNamespaceAware(true);
/*     */       try {
/* 409 */         factory.setFeature("http://xml.org/sax/features/string-interning", true);
/* 410 */       } catch (SAXException sAXException) {}
/*     */ 
/*     */       
/* 413 */       factory.setValidating(false);
/* 414 */       factory.newSAXParser().parse(in, this);
/* 415 */       return (Contribution)this.objectStack.pop();
/*     */     } finally {
/* 417 */       if (this.registry.debug()) {
/* 418 */         cumulativeTime += System.currentTimeMillis() - start;
/* 419 */         System.out.println("Cumulative parse time so far : " + cumulativeTime);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseConfigurationElementAttributes(Attributes attributes) {
/* 425 */     ConfigurationElement parentConfigurationElement = (ConfigurationElement)this.objectStack.peek();
/*     */ 
/*     */     
/* 428 */     int len = (attributes != null) ? attributes.getLength() : 0;
/* 429 */     if (len == 0) {
/* 430 */       parentConfigurationElement.setProperties(RegistryObjectManager.EMPTY_STRING_ARRAY);
/*     */       return;
/*     */     } 
/* 433 */     String[] properties = new String[len * 2];
/* 434 */     for (int i = 0; i < len; i++) {
/* 435 */       properties[i * 2] = attributes.getLocalName(i);
/* 436 */       properties[i * 2 + 1] = translate(attributes.getValue(i));
/*     */     } 
/* 438 */     parentConfigurationElement.setProperties(properties);
/* 439 */     properties = null;
/*     */   }
/*     */   
/*     */   private void parseExtensionAttributes(Attributes attributes) {
/* 443 */     Extension currentExtension = this.registry.getElementFactory().createExtension(this.contribution.shouldPersist());
/* 444 */     this.objectStack.push(currentExtension);
/*     */     
/* 446 */     String simpleId = null;
/* 447 */     String namespaceName = null;
/*     */     
/* 449 */     int len = (attributes != null) ? attributes.getLength() : 0;
/* 450 */     for (int i = 0; i < len; i++) {
/* 451 */       String attrName = attributes.getLocalName(i);
/* 452 */       String attrValue = attributes.getValue(i).trim();
/*     */       
/* 454 */       if (attrName.equals("name")) {
/* 455 */         currentExtension.setLabel(translate(attrValue));
/* 456 */       } else if (attrName.equals("id")) {
/* 457 */         int simpleIdStart = attrValue.lastIndexOf('.');
/* 458 */         if (simpleIdStart != -1 && this.extractNamespaces) {
/* 459 */           simpleId = attrValue.substring(simpleIdStart + 1);
/* 460 */           namespaceName = attrValue.substring(0, simpleIdStart);
/*     */         } else {
/* 462 */           simpleId = attrValue;
/* 463 */           namespaceName = this.contribution.getDefaultNamespace();
/*     */         } 
/* 465 */         currentExtension.setSimpleIdentifier(simpleId);
/* 466 */         currentExtension.setNamespaceIdentifier(namespaceName);
/* 467 */       } else if (attrName.equals("point")) {
/*     */         String targetName;
/*     */         
/* 470 */         if (attrValue.lastIndexOf('.') == -1) {
/* 471 */           String baseId = this.contribution.getDefaultNamespace();
/* 472 */           targetName = String.valueOf(baseId) + '.' + attrValue;
/*     */         } else {
/* 474 */           targetName = attrValue;
/* 475 */         }  currentExtension.setExtensionPointIdentifier(targetName);
/*     */       } else {
/* 477 */         unknownAttribute(attrName, "extension");
/*     */       } 
/* 479 */     }  if (currentExtension.getExtensionPointIdentifier() == null) {
/* 480 */       missingAttribute("point", "extension");
/* 481 */       this.stateStack.pop();
/* 482 */       this.stateStack.push(Integer.valueOf(0));
/* 483 */       this.objectStack.pop();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 488 */     if (simpleId != null && this.registry.debug()) {
/* 489 */       String uniqueId = String.valueOf(namespaceName) + '.' + simpleId;
/* 490 */       IExtension existingExtension = this.registry.getExtension(uniqueId);
/* 491 */       if (existingExtension != null) {
/* 492 */         String currentSupplier = this.contribution.getDefaultNamespace();
/* 493 */         String existingSupplier = existingExtension.getContributor().getName();
/* 494 */         String msg = NLS.bind(RegistryMessages.parse_duplicateExtension, (Object[])new String[] { currentSupplier, existingSupplier, uniqueId });
/* 495 */         this.registry.log((IStatus)new Status(2, "org.eclipse.equinox.registry", 0, msg, null));
/* 496 */       } else if (this.processedExtensionIds != null) {
/* 497 */         for (String extensionId : this.processedExtensionIds) {
/* 498 */           if (uniqueId.equals(extensionId)) {
/* 499 */             String currentSupplier = this.contribution.getDefaultNamespace();
/* 500 */             String existingSupplier = currentSupplier;
/* 501 */             String msg = NLS.bind(RegistryMessages.parse_duplicateExtension, (Object[])new String[] { currentSupplier, existingSupplier, uniqueId });
/* 502 */             this.registry.log((IStatus)new Status(2, "org.eclipse.equinox.registry", 0, msg, null));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 507 */       if (this.processedExtensionIds == null)
/* 508 */         this.processedExtensionIds = new ArrayList<>(10); 
/* 509 */       this.processedExtensionIds.add(uniqueId);
/*     */     } 
/*     */     
/* 512 */     this.objectManager.add(currentExtension, true);
/* 513 */     this.addedRegistryObjects.add(currentExtension);
/*     */   }
/*     */ 
/*     */   
/*     */   private void missingAttribute(String attribute, String element) {
/* 518 */     if (this.locator == null) {
/* 519 */       internalError(NLS.bind(RegistryMessages.parse_missingAttribute, attribute, element));
/*     */     } else {
/* 521 */       internalError(NLS.bind(RegistryMessages.parse_missingAttributeLine, (Object[])new String[] { attribute, element, Integer.toString(this.locator.getLineNumber()) }));
/*     */     } 
/*     */   }
/*     */   private void unknownAttribute(String attribute, String element) {
/* 525 */     if (this.locator == null) {
/* 526 */       internalError(NLS.bind(RegistryMessages.parse_unknownAttribute, attribute, element));
/*     */     } else {
/* 528 */       internalError(NLS.bind(RegistryMessages.parse_unknownAttributeLine, (Object[])new String[] { attribute, element, Integer.toString(this.locator.getLineNumber()) }));
/*     */     } 
/*     */   }
/*     */   private void unknownElement(String parent, String element) {
/* 532 */     if (this.locator == null) {
/* 533 */       internalError(NLS.bind(RegistryMessages.parse_unknownElement, element, parent));
/*     */     } else {
/* 535 */       internalError(NLS.bind(RegistryMessages.parse_unknownElementLine, (Object[])new String[] { element, parent, Integer.toString(this.locator.getLineNumber()) }));
/*     */     } 
/*     */   }
/*     */   private void parseExtensionPointAttributes(Attributes attributes) {
/* 539 */     ExtensionPoint currentExtPoint = this.registry.getElementFactory().createExtensionPoint(this.contribution.shouldPersist());
/*     */ 
/*     */     
/* 542 */     int len = (attributes != null) ? attributes.getLength() : 0;
/* 543 */     for (int i = 0; i < len; i++) {
/* 544 */       String attrName = attributes.getLocalName(i);
/* 545 */       String attrValue = attributes.getValue(i).trim();
/*     */       
/* 547 */       if (attrName.equals("name")) {
/* 548 */         currentExtPoint.setLabel(translate(attrValue));
/* 549 */       } else if (attrName.equals("id")) {
/*     */         String uniqueId, namespaceName;
/*     */         
/* 552 */         int simpleIdStart = attrValue.lastIndexOf('.');
/* 553 */         if (simpleIdStart != -1 && this.extractNamespaces) {
/* 554 */           namespaceName = attrValue.substring(0, simpleIdStart);
/* 555 */           uniqueId = attrValue;
/*     */         } else {
/* 557 */           namespaceName = this.contribution.getDefaultNamespace();
/* 558 */           uniqueId = String.valueOf(namespaceName) + '.' + attrValue;
/*     */         } 
/* 560 */         currentExtPoint.setUniqueIdentifier(uniqueId);
/* 561 */         currentExtPoint.setNamespace(namespaceName);
/*     */       }
/* 563 */       else if (attrName.equals("schema")) {
/* 564 */         currentExtPoint.setSchema(attrValue);
/*     */       } else {
/* 566 */         unknownAttribute(attrName, "extension-point");
/*     */       } 
/* 568 */     }  if (currentExtPoint.getSimpleIdentifier() == null || currentExtPoint.getLabel() == null) {
/* 569 */       String attribute = (currentExtPoint.getSimpleIdentifier() == null) ? "id" : "name";
/* 570 */       missingAttribute(attribute, "extension-point");
/* 571 */       this.stateStack.pop();
/* 572 */       this.stateStack.push(Integer.valueOf(0));
/*     */       return;
/*     */     } 
/* 575 */     if (!this.objectManager.addExtensionPoint(currentExtPoint, true)) {
/*     */ 
/*     */ 
/*     */       
/* 579 */       if (this.registry.debug()) {
/* 580 */         String msg = NLS.bind(RegistryMessages.parse_duplicateExtensionPoint, currentExtPoint.getUniqueIdentifier(), this.contribution.getDefaultNamespace());
/* 581 */         this.registry.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, msg, null));
/*     */       } 
/* 583 */       this.stateStack.pop();
/* 584 */       this.stateStack.push(Integer.valueOf(0));
/*     */       return;
/*     */     } 
/* 587 */     if (currentExtPoint.getNamespace() == null)
/* 588 */       currentExtPoint.setNamespace(this.contribution.getDefaultNamespace()); 
/* 589 */     currentExtPoint.setContributorId(this.contribution.getContributorId());
/* 590 */     this.addedRegistryObjects.add(currentExtPoint);
/*     */ 
/*     */     
/* 593 */     this.scratchVectors[0].add(currentExtPoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() {
/* 601 */     this.stateStack.push(Integer.valueOf(1));
/* 602 */     for (int i = 0; i <= 1; i++) {
/* 603 */       this.scratchVectors[i] = new ArrayList<>();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String elementName, String qName, Attributes attributes) {
/* 612 */     switch (((Integer)this.stateStack.peek()).intValue()) {
/*     */       case 1:
/* 614 */         handleInitialState(elementName, attributes);
/*     */         return;
/*     */       case 2:
/* 617 */         handleBundleState(elementName, attributes);
/*     */         return;
/*     */       case 5:
/* 620 */         handleExtensionPointState(elementName);
/*     */         return;
/*     */       case 6:
/*     */       case 10:
/* 624 */         handleExtensionState(elementName, attributes);
/*     */         return;
/*     */     } 
/* 627 */     this.stateStack.push(Integer.valueOf(0));
/* 628 */     if (!this.compatibilityMode) {
/* 629 */       internalError(NLS.bind(RegistryMessages.parse_unknownTopElement, elementName));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warning(SAXParseException ex) {
/* 638 */     logStatus(ex);
/*     */   }
/*     */   
/*     */   private void internalError(String message) {
/* 642 */     error((IStatus)new Status(2, "org.eclipse.equinox.registry", 1, message, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) {
/* 656 */     if (target.equalsIgnoreCase("eclipse")) {
/*     */ 
/*     */       
/* 659 */       this.schemaVersion = "3.0";
/* 660 */       StringTokenizer tokenizer = new StringTokenizer(data, "=\"");
/* 661 */       while (tokenizer.hasMoreTokens()) {
/* 662 */         String token = tokenizer.nextToken();
/* 663 */         if (token.equalsIgnoreCase("version")) {
/* 664 */           if (!tokenizer.hasMoreTokens()) {
/*     */             break;
/*     */           }
/* 667 */           this.schemaVersion = tokenizer.nextToken();
/*     */           break;
/*     */         } 
/*     */       } 
/* 671 */       initializeExtractNamespace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(IStatus error) {
/* 682 */     this.status.add(error);
/*     */   }
/*     */   
/*     */   protected String translate(String key) {
/* 686 */     return this.registry.translate(key, this.resources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Extension[] fixRenamedExtensionPoints(Extension[] extensions) {
/* 694 */     if (extensions == null || versionAtLeast("3.0") || RegistryProperties.getProperty("eclipse.noExtensionMunging") != null)
/* 695 */       return extensions;  byte b; int i; Extension[] arrayOfExtension;
/* 696 */     for (i = (arrayOfExtension = extensions).length, b = 0; b < i; ) { Extension extension = arrayOfExtension[b];
/* 697 */       String oldPointId = extension.getExtensionPointIdentifier();
/* 698 */       String newPointId = extensionPointMap.get(oldPointId);
/* 699 */       if (newPointId != null)
/* 700 */         extension.setExtensionPointIdentifier(newPointId); 
/*     */       b++; }
/*     */     
/* 703 */     return extensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeExtractNamespace() {
/* 711 */     this.extractNamespaces = Boolean.valueOf(versionAtLeast("3.2")).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean versionAtLeast(String testVersion) {
/* 720 */     if (this.schemaVersion == null) {
/* 721 */       return false;
/*     */     }
/* 723 */     StringTokenizer testVersionTokenizer = new StringTokenizer(testVersion, ".");
/* 724 */     StringTokenizer schemaVersionTokenizer = new StringTokenizer(this.schemaVersion, ".");
/* 725 */     while (testVersionTokenizer.hasMoreTokens() && schemaVersionTokenizer.hasMoreTokens()) {
/*     */       try {
/* 727 */         if (Integer.parseInt(schemaVersionTokenizer.nextToken()) < Integer.parseInt(testVersionTokenizer.nextToken()))
/* 728 */           return false; 
/* 729 */       } catch (NumberFormatException numberFormatException) {
/* 730 */         return false;
/*     */       } 
/*     */     } 
/* 733 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionsParser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */