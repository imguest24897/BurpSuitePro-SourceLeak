package org.eclipse.core.runtime;

import java.util.EventListener;

public interface IRegistryChangeListener extends EventListener {
  void registryChanged(IRegistryChangeEvent paramIRegistryChangeEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\IRegistryChangeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */