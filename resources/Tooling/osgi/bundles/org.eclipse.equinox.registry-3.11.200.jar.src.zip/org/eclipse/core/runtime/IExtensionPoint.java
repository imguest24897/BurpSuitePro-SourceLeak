package org.eclipse.core.runtime;

public interface IExtensionPoint {
  IConfigurationElement[] getConfigurationElements() throws InvalidRegistryObjectException;
  
  String getNamespace() throws InvalidRegistryObjectException;
  
  String getNamespaceIdentifier() throws InvalidRegistryObjectException;
  
  IContributor getContributor() throws InvalidRegistryObjectException;
  
  IExtension getExtension(String paramString) throws InvalidRegistryObjectException;
  
  IExtension[] getExtensions() throws InvalidRegistryObjectException;
  
  String getLabel() throws InvalidRegistryObjectException;
  
  String getLabel(String paramString) throws InvalidRegistryObjectException;
  
  String getSchemaReference() throws InvalidRegistryObjectException;
  
  String getSimpleIdentifier() throws InvalidRegistryObjectException;
  
  String getUniqueIdentifier() throws InvalidRegistryObjectException;
  
  boolean equals(Object paramObject);
  
  boolean isValid();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\IExtensionPoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */