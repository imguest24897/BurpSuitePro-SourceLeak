/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Contribution
/*     */   implements KeyedElement
/*     */ {
/*  23 */   static final int[] EMPTY_CHILDREN = new int[2];
/*     */ 
/*     */   
/*     */   protected ExtensionRegistry registry;
/*     */ 
/*     */   
/*     */   protected final String contributorId;
/*     */ 
/*     */   
/*  32 */   private String defaultNamespace = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean persist;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private int[] children = EMPTY_CHILDREN;
/*     */   public static final byte EXTENSION_POINT = 0;
/*     */   public static final byte EXTENSION = 1;
/*     */   
/*     */   protected Contribution(String contributorId, ExtensionRegistry registry, boolean persist) {
/*  47 */     this.contributorId = contributorId;
/*  48 */     this.registry = registry;
/*  49 */     this.persist = persist;
/*     */   }
/*     */   
/*     */   void mergeContribution(Contribution addContribution) {
/*  53 */     Assert.isTrue(this.contributorId.equals(addContribution.contributorId));
/*  54 */     Assert.isTrue((this.registry == addContribution.registry));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     if (shouldPersist() != addContribution.shouldPersist()) {
/*  63 */       this.persist = true;
/*     */     }
/*  65 */     int[] existing = getRawChildren();
/*  66 */     int[] addition = addContribution.getRawChildren();
/*     */     
/*  68 */     int extensionPoints = existing[0] + addition[0];
/*  69 */     int extensions = existing[1] + addition[1];
/*  70 */     int[] allChildren = new int[2 + extensionPoints + extensions];
/*     */     
/*  72 */     allChildren[0] = extensionPoints;
/*  73 */     System.arraycopy(existing, 2, allChildren, 2, existing[0]);
/*  74 */     System.arraycopy(addition, 2, allChildren, 2 + existing[0], addition[0]);
/*  75 */     allChildren[1] = extensions;
/*  76 */     System.arraycopy(existing, 2 + existing[0], allChildren, 2 + extensionPoints, existing[1]);
/*  77 */     System.arraycopy(addition, 2 + addition[0], allChildren, 2 + extensionPoints + existing[1], addition[1]);
/*     */     
/*  79 */     this.children = allChildren;
/*     */   }
/*     */   
/*     */   void setRawChildren(int[] children) {
/*  83 */     this.children = children;
/*     */   }
/*     */   
/*     */   protected String getContributorId() {
/*  87 */     return this.contributorId;
/*     */   }
/*     */   
/*     */   protected int[] getRawChildren() {
/*  91 */     return this.children;
/*     */   }
/*     */   
/*     */   protected int[] getExtensions() {
/*  95 */     int[] results = new int[this.children[1]];
/*  96 */     System.arraycopy(this.children, 2 + this.children[0], results, 0, this.children[1]);
/*  97 */     return results;
/*     */   }
/*     */   
/*     */   protected int[] getExtensionPoints() {
/* 101 */     int[] results = new int[this.children[0]];
/* 102 */     System.arraycopy(this.children, 2, results, 0, this.children[0]);
/* 103 */     return results;
/*     */   }
/*     */   
/*     */   public String getDefaultNamespace() {
/* 107 */     if (this.defaultNamespace == null)
/* 108 */       this.defaultNamespace = this.registry.getObjectManager().getContributor(this.contributorId).getName(); 
/* 109 */     return this.defaultNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "Contribution: " + this.contributorId + " in namespace" + getDefaultNamespace();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKeyHashCode() {
/* 120 */     return getKey().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getKey() {
/* 125 */     return this.contributorId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean compare(KeyedElement other) {
/* 130 */     return this.contributorId.equals(((Contribution)other).contributorId);
/*     */   }
/*     */   
/*     */   public boolean shouldPersist() {
/* 134 */     return this.persist;
/*     */   }
/*     */ 
/*     */   
/*     */   public void unlinkChild(int id) {
/* 139 */     int index = -1;
/* 140 */     for (int i = 2; i < this.children.length; i++) {
/* 141 */       if (this.children[i] == id) {
/* 142 */         index = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 146 */     if (index == -1) {
/* 147 */       throw new InvalidRegistryObjectException();
/*     */     }
/*     */     
/* 150 */     int[] result = new int[this.children.length - 1];
/* 151 */     System.arraycopy(this.children, 0, result, 0, index);
/* 152 */     System.arraycopy(this.children, index + 1, result, index, this.children.length - index - 1);
/*     */ 
/*     */     
/* 155 */     if (index < this.children[0] + 2) {
/* 156 */       result[0] = result[0] - 1;
/*     */     } else {
/* 158 */       result[1] = result[1] - 1;
/*     */     } 
/* 160 */     this.children = result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 167 */     return !(this.children[0] != 0 && this.children[1] != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChild(int id) {
/* 176 */     for (int i = 2; i < this.children.length; i++) {
/* 177 */       if (this.children[i] == id)
/* 178 */         return true; 
/*     */     } 
/* 180 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\Contribution.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */