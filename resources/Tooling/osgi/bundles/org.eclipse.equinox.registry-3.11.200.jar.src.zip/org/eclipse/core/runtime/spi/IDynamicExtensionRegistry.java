package org.eclipse.core.runtime.spi;

import org.eclipse.core.runtime.IContributor;

public interface IDynamicExtensionRegistry {
  void removeContributor(IContributor paramIContributor, Object paramObject);
  
  boolean hasContributor(IContributor paramIContributor);
  
  IContributor[] getAllContributors();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\spi\IDynamicExtensionRegistry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */