/*     */ package org.eclipse.core.runtime.spi;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.eclipse.core.internal.registry.ExtensionRegistry;
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.registry.RegistrySupport;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryStrategy
/*     */ {
/*  43 */   private SAXParserFactory theXMLParserFactory = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final File[] storageDirs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean[] cacheReadOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegistryStrategy(File[] storageDirs, boolean[] cacheReadOnly) {
/*  75 */     this.storageDirs = storageDirs;
/*  76 */     this.cacheReadOnly = cacheReadOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLocationsLength() {
/*  85 */     if (this.storageDirs == null)
/*  86 */       return 0; 
/*  87 */     return this.storageDirs.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final File getStorage(int index) {
/*  97 */     if (this.storageDirs != null)
/*  98 */       return this.storageDirs[index]; 
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCacheReadOnly(int index) {
/* 110 */     if (this.cacheReadOnly != null)
/* 111 */       return this.cacheReadOnly[index]; 
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(IStatus status) {
/* 131 */     RegistrySupport.log(status, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String translate(String key, ResourceBundle resources) {
/* 148 */     return RegistrySupport.translate(key, resources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void onStart(IExtensionRegistry registry) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onStart(IExtensionRegistry registry, boolean loadedFromCache) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onStop(IExtensionRegistry registry) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createExecutableExtension(RegistryContributor contributor, String className, String overridenContributorName) throws CoreException {
/* 216 */     Object result = null;
/* 217 */     Class<?> classInstance = null;
/*     */     try {
/* 219 */       classInstance = Class.forName(className);
/* 220 */     } catch (ClassNotFoundException e1) {
/* 221 */       String message = NLS.bind(RegistryMessages.exExt_findClassError, contributor.getActualName(), className);
/* 222 */       throw new CoreException(new Status(4, "org.eclipse.equinox.registry", 1, message, e1));
/*     */     } 
/*     */     
/*     */     try {
/* 226 */       result = classInstance.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 227 */     } catch (Exception e) {
/* 228 */       String message = NLS.bind(RegistryMessages.exExt_instantiateClassError, contributor.getActualName(), className);
/* 229 */       throw new CoreException(new Status(4, "org.eclipse.equinox.registry", 1, message, e));
/*     */     } 
/* 231 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scheduleChangeEvent(Object[] listeners, Map<String, ?> deltas, Object registry) {
/* 249 */     ((ExtensionRegistry)registry).scheduleChangeEvent(listeners, deltas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final IStatus processChangeEvent(Object[] listeners, Map<String, ?> deltas, Object registry) {
/* 263 */     if (registry instanceof ExtensionRegistry)
/* 264 */       return ((ExtensionRegistry)registry).processChangeEvent(listeners, deltas); 
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean debug() {
/* 281 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean debugRegistryEvents() {
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cacheUse() {
/* 310 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cacheLazyLoading() {
/* 323 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getContainerTimestamp() {
/* 351 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getContributionsTimestamp() {
/* 374 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAXParserFactory getXMLParser() {
/* 385 */     if (this.theXMLParserFactory == null)
/* 386 */       this.theXMLParserFactory = SAXParserFactory.newInstance(); 
/* 387 */     return this.theXMLParserFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] translate(String[] nonTranslated, IContributor contributor, String locale) {
/* 408 */     return nonTranslated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocale() {
/* 431 */     return Locale.getDefault().toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\spi\RegistryStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */