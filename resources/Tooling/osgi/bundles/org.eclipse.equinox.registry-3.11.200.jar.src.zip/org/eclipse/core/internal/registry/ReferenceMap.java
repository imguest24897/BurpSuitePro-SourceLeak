/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceMap
/*     */ {
/*     */   public static final int HARD = 0;
/*     */   public static final int SOFT = 1;
/*     */   private final float loadFactor;
/*     */   
/*     */   private static class HardRef
/*     */     implements IEntry
/*     */   {
/*     */     private final int key;
/*     */     private ReferenceMap.IEntry next;
/*     */     private final Object value;
/*     */     
/*     */     public HardRef(int key, Object value, ReferenceMap.IEntry next) {
/*  69 */       this.key = key;
/*  70 */       this.value = value;
/*  71 */       this.next = next;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getKey() {
/*  76 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public ReferenceMap.IEntry getNext() {
/*  81 */       return this.next;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue() {
/*  86 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setNext(ReferenceMap.IEntry next) {
/*  91 */       this.next = next;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  96 */       return "HardRef(" + this.key + ',' + this.value + ')';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface IEntry
/*     */   {
/*     */     int getKey();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     IEntry getNext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setNext(IEntry param1IEntry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SoftRef
/*     */     extends SoftReference<Object>
/*     */     implements IEntry
/*     */   {
/*     */     private final int key;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ReferenceMap.IEntry next;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SoftRef(int key, Object value, ReferenceMap.IEntry next, ReferenceQueue<Object> q) {
/* 146 */       super(value, q);
/* 147 */       this.key = key;
/* 148 */       this.next = next;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getKey() {
/* 153 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public ReferenceMap.IEntry getNext() {
/* 158 */       return this.next;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue() {
/* 163 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setNext(ReferenceMap.IEntry next) {
/* 168 */       this.next = next;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   private transient ReferenceQueue<Object> queue = new ReferenceQueue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient IEntry[] table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int threshold;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int valueType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceMap(int referenceType, int capacity, float loadFactor) {
/* 232 */     if (referenceType != 0 && referenceType != 1)
/* 233 */       throw new IllegalArgumentException(" must be HARD or SOFT."); 
/* 234 */     if (capacity <= 0)
/* 235 */       throw new IllegalArgumentException("capacity must be positive"); 
/* 236 */     if (loadFactor <= 0.0F || loadFactor >= 1.0F) {
/* 237 */       throw new IllegalArgumentException("Load factor must be greater than 0 and less than 1.");
/*     */     }
/* 239 */     this.valueType = referenceType;
/*     */     
/* 241 */     int initialSize = 1;
/* 242 */     while (initialSize < capacity) {
/* 243 */       initialSize *= 2;
/*     */     }
/* 245 */     this.table = new IEntry[initialSize];
/* 246 */     this.loadFactor = loadFactor;
/* 247 */     this.threshold = (int)(initialSize * loadFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object doRemove(int key, boolean cleanup) {
/* 256 */     int index = indexFor(key);
/* 257 */     IEntry previous = null;
/* 258 */     IEntry entry = this.table[index];
/* 259 */     while (entry != null) {
/* 260 */       if (key == entry.getKey())
/*     */       {
/*     */ 
/*     */         
/* 264 */         if (!cleanup || entry.getValue() == null) {
/* 265 */           if (previous == null) {
/* 266 */             this.table[index] = entry.getNext();
/*     */           } else {
/* 268 */             previous.setNext(entry.getNext());
/* 269 */           }  this.size--;
/* 270 */           return entry.getValue();
/*     */         } 
/*     */       }
/* 273 */       previous = entry;
/* 274 */       entry = entry.getNext();
/*     */     } 
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int key) {
/* 286 */     for (IEntry entry = this.table[indexFor(key)]; entry != null; entry = entry.getNext()) {
/* 287 */       if (entry.getKey() == key) {
/* 288 */         Object value = entry.getValue();
/* 289 */         if (value == null) {
/* 290 */           purge();
/*     */         }
/* 292 */         return value;
/*     */       } 
/* 294 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexFor(int hash) {
/* 303 */     hash += hash << 15 ^ 0xFFFFFFFF;
/* 304 */     hash ^= hash >>> 10;
/* 305 */     hash += hash << 3;
/* 306 */     hash ^= hash >>> 6;
/* 307 */     hash += hash << 11 ^ 0xFFFFFFFF;
/* 308 */     hash ^= hash >>> 16;
/* 309 */     return hash & this.table.length - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IEntry newEntry(int key, Object value, IEntry next) {
/* 321 */     switch (this.valueType) {
/*     */       case 0:
/* 323 */         return new HardRef(key, value, next);
/*     */       case 1:
/* 325 */         return new SoftRef(key, value, next, this.queue);
/*     */     } 
/* 327 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void purge() {
/* 345 */     Reference<?> ref = this.queue.poll();
/* 346 */     while (ref != null) {
/* 347 */       doRemove(((IEntry)ref).getKey(), true);
/* 348 */       ref.clear();
/* 349 */       ref = this.queue.poll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int key, Object value) {
/* 363 */     if (value == null) {
/* 364 */       throw new NullPointerException("null values not allowed");
/*     */     }
/* 366 */     if (this.size + 1 > this.threshold) {
/* 367 */       resize();
/*     */     }
/* 369 */     int index = indexFor(key);
/* 370 */     IEntry previous = null;
/* 371 */     IEntry entry = this.table[index];
/* 372 */     while (entry != null) {
/* 373 */       if (key == entry.getKey()) {
/* 374 */         if (previous == null) {
/* 375 */           this.table[index] = newEntry(key, value, entry.getNext());
/*     */         } else {
/* 377 */           previous.setNext(newEntry(key, value, entry.getNext()));
/*     */         }  return;
/*     */       } 
/* 380 */       previous = entry;
/* 381 */       entry = entry.getNext();
/*     */     } 
/* 383 */     this.size++;
/* 384 */     this.table[index] = newEntry(key, value, this.table[index]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(int key) {
/* 395 */     purge();
/* 396 */     return doRemove(key, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resize() {
/* 406 */     IEntry[] old = this.table;
/* 407 */     this.table = new IEntry[old.length * 2];
/*     */     
/* 409 */     for (int i = 0; i < old.length; i++) {
/* 410 */       IEntry next = old[i];
/* 411 */       while (next != null) {
/* 412 */         IEntry entry = next;
/* 413 */         next = next.getNext();
/* 414 */         int index = indexFor(entry.getKey());
/* 415 */         entry.setNext(this.table[index]);
/* 416 */         this.table[index] = entry;
/*     */       } 
/* 418 */       old[i] = null;
/*     */     } 
/* 420 */     this.threshold = (int)(this.table.length * this.loadFactor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ReferenceMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */