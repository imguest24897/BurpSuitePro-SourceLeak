/*      */ package org.eclipse.core.internal.registry;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Set;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.eclipse.core.internal.registry.spi.ConfigurationElementAttribute;
/*      */ import org.eclipse.core.internal.registry.spi.ConfigurationElementDescription;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IContributor;
/*      */ import org.eclipse.core.runtime.IExtension;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IExtensionRegistry;
/*      */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*      */ import org.eclipse.core.runtime.IRegistryEventListener;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*      */ import org.eclipse.core.runtime.spi.RegistryStrategy;
/*      */ import org.eclipse.osgi.storagemanager.StorageManager;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ public class ExtensionRegistry implements IExtensionRegistry, IDynamicExtensionRegistry {
/*      */   protected class ListenerInfo {
/*      */     public String filter;
/*      */     public EventListener listener;
/*      */     
/*      */     public ListenerInfo(EventListener listener, String filter) {
/*   40 */       this.listener = listener;
/*   41 */       this.filter = filter;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object another) {
/*   49 */       return (another instanceof ListenerInfo && ((ListenerInfo)another).listener == this.listener);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*   57 */       return (this.listener == null) ? 0 : this.listener.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*   62 */   private final ReadWriteMonitor access = new ReadWriteMonitor();
/*      */ 
/*      */   
/*   65 */   private transient Map<String, Object> deltas = new HashMap<>(11);
/*      */ 
/*      */   
/*      */   protected StorageManager cacheStorageManager;
/*      */ 
/*      */   
/*   71 */   private transient ListenerList<ListenerInfo> listeners = new ListenerList();
/*      */   
/*   73 */   private RegistryObjectManager registryObjects = null;
/*      */ 
/*      */   
/*   76 */   protected TableReader theTableReader = new TableReader(this);
/*      */   
/*      */   private final Object masterToken;
/*      */   
/*      */   private final Object userToken;
/*      */   
/*      */   protected RegistryStrategy strategy;
/*   83 */   private final RegistryTimestamp aggregatedTimestamp = new RegistryTimestamp();
/*      */ 
/*      */   
/*   86 */   private CombinedEventDelta eventDelta = null;
/*      */   
/*      */   private static final String notNamespace = "";
/*      */   
/*      */   private final boolean isMultiLanguage;
/*      */   private boolean mlErrorLogged = false;
/*      */   protected RegistryObjectFactory theRegistryObjectFactory;
/*      */   private RegistryEventThread eventThread;
/*      */   protected final List<QueueElement> queue;
/*      */   
/*      */   public RegistryObjectManager getObjectManager() {
/*   97 */     return this.registryObjects;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setFileManager(File cacheBase, boolean isCacheReadOnly) {
/*  108 */     if (this.cacheStorageManager != null) {
/*  109 */       this.cacheStorageManager.close();
/*      */     }
/*  111 */     if (cacheBase != null) {
/*  112 */       this.cacheStorageManager = new StorageManager(cacheBase, isCacheReadOnly ? "none" : null, isCacheReadOnly);
/*      */       try {
/*  114 */         this.cacheStorageManager.open(!isCacheReadOnly);
/*  115 */       } catch (IOException iOException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void add(Contribution element) {
/*  130 */     this.access.enterWrite();
/*      */     try {
/*  132 */       this.eventDelta = CombinedEventDelta.recordAddition();
/*  133 */       basicAdd(element, true);
/*  134 */       fireRegistryChangeEvent();
/*  135 */       this.eventDelta = null;
/*      */     } finally {
/*  137 */       this.access.exitWrite();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static Object concatArrays(Object a, Object b) {
/*  143 */     Object[] result = (Object[])Array.newInstance(a.getClass().getComponentType(), Array.getLength(a) + Array.getLength(b));
/*  144 */     System.arraycopy(a, 0, result, 0, Array.getLength(a));
/*  145 */     System.arraycopy(b, 0, result, Array.getLength(a), Array.getLength(b));
/*  146 */     return result;
/*      */   }
/*      */   
/*      */   private String addExtension(int extension) {
/*  150 */     Extension addedExtension = (Extension)this.registryObjects.getObject(extension, (byte)2);
/*  151 */     String extensionPointToAddTo = addedExtension.getExtensionPointIdentifier();
/*  152 */     ExtensionPoint extPoint = this.registryObjects.getExtensionPointObject(extensionPointToAddTo);
/*      */     
/*  154 */     if (extPoint == null) {
/*  155 */       this.registryObjects.addOrphan(extensionPointToAddTo, extension);
/*  156 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  160 */     int[] existingExtensions = extPoint.getRawChildren();
/*  161 */     int[] newExtensions = new int[existingExtensions.length + 1];
/*  162 */     System.arraycopy(existingExtensions, 0, newExtensions, 0, existingExtensions.length);
/*  163 */     newExtensions[newExtensions.length - 1] = extension;
/*  164 */     link(extPoint, newExtensions);
/*  165 */     if (this.eventDelta != null)
/*  166 */       this.eventDelta.rememberExtension(extPoint, extension); 
/*  167 */     return recordChange(extPoint, extension, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String addExtensionPoint(int extPoint) {
/*  175 */     ExtensionPoint extensionPoint = (ExtensionPoint)this.registryObjects.getObject(extPoint, (byte)3);
/*  176 */     if (this.eventDelta != null)
/*  177 */       this.eventDelta.rememberExtensionPoint(extensionPoint); 
/*  178 */     int[] orphans = this.registryObjects.removeOrphans(extensionPoint.getUniqueIdentifier());
/*  179 */     if (orphans == null)
/*  180 */       return null; 
/*  181 */     link(extensionPoint, orphans);
/*  182 */     if (this.eventDelta != null)
/*  183 */       this.eventDelta.rememberExtensions(extensionPoint, orphans); 
/*  184 */     return recordChange(extensionPoint, orphans, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   private Set<String> addExtensionsAndExtensionPoints(Contribution element) {
/*  189 */     Set<String> affectedNamespaces = new HashSet<>(); byte b; int i, arrayOfInt[];
/*  190 */     for (i = (arrayOfInt = element.getExtensionPoints()).length, b = 0; b < i; ) { int extPoint = arrayOfInt[b];
/*  191 */       String namespace = addExtensionPoint(extPoint);
/*  192 */       if (namespace != null)
/*  193 */         affectedNamespaces.add(namespace);  b++; }
/*      */     
/*  195 */     for (i = (arrayOfInt = element.getExtensions()).length, b = 0; b < i; ) { int extension = arrayOfInt[b];
/*  196 */       String namespace = addExtension(extension);
/*  197 */       if (namespace != null)
/*  198 */         affectedNamespaces.add(namespace);  b++; }
/*      */     
/*  200 */     return affectedNamespaces;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addListener(IRegistryEventListener listener) {
/*  205 */     addListenerInternal((EventListener)listener, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addListener(IRegistryEventListener listener, String extensionPointId) {
/*  210 */     addListenerInternal((EventListener)listener, extensionPointId);
/*      */   }
/*      */   
/*      */   private void addListenerInternal(EventListener listener, String filter) {
/*  214 */     synchronized (this.listeners) {
/*  215 */       this.listeners.add(new ListenerInfo(listener, filter));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRegistryChangeListener(IRegistryChangeListener listener) {
/*  222 */     addListenerInternal((EventListener)listener, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addRegistryChangeListener(IRegistryChangeListener listener, String filter) {
/*  227 */     addListenerInternal((EventListener)listener, filter);
/*      */   }
/*      */   
/*      */   private void basicAdd(Contribution element, boolean link) {
/*  231 */     this.registryObjects.addContribution(element);
/*  232 */     if (!link)
/*      */       return; 
/*  234 */     Set<String> affectedNamespaces = addExtensionsAndExtensionPoints(element);
/*  235 */     setObjectManagers(affectedNamespaces, this.registryObjects.createDelegatingObjectManager(this.registryObjects.getAssociatedObjects(element.getContributorId())));
/*      */   }
/*      */   
/*      */   private void setObjectManagers(Set<String> affectedNamespaces, IObjectManager manager) {
/*  239 */     for (String namespace : affectedNamespaces) {
/*  240 */       getDelta(namespace).setObjectManager(manager);
/*      */     }
/*  242 */     if (this.eventDelta != null) {
/*  243 */       this.eventDelta.setObjectManager(manager);
/*      */     }
/*      */   }
/*      */   
/*      */   private void basicRemove(String contributorId) {
/*  248 */     Set<String> affectedNamespaces = removeExtensionsAndExtensionPoints(contributorId);
/*  249 */     Map<Integer, RegistryObject> associatedObjects = this.registryObjects.getAssociatedObjects(contributorId);
/*  250 */     this.registryObjects.removeObjects(associatedObjects);
/*  251 */     this.registryObjects.addNavigableObjects(associatedObjects);
/*  252 */     setObjectManagers(affectedNamespaces, this.registryObjects.createDelegatingObjectManager(associatedObjects));
/*      */     
/*  254 */     this.registryObjects.removeContribution(contributorId);
/*  255 */     this.registryObjects.removeContributor(contributorId);
/*      */   }
/*      */ 
/*      */   
/*      */   void enterRead() {
/*  260 */     this.access.enterRead();
/*      */   }
/*      */ 
/*      */   
/*      */   void exitRead() {
/*  265 */     this.access.exitRead();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireRegistryChangeEvent() {
/*  273 */     this.deltas.put("", this.eventDelta);
/*      */     
/*  275 */     if (this.listeners.isEmpty()) {
/*  276 */       this.deltas.clear();
/*      */       
/*      */       return;
/*      */     } 
/*  280 */     Object[] tmpListeners = this.listeners.getListeners();
/*  281 */     Map<String, Object> tmpDeltas = new HashMap<>(this.deltas);
/*      */     
/*  283 */     this.deltas.clear();
/*      */     
/*  285 */     this.strategy.scheduleChangeEvent(tmpListeners, tmpDeltas, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IConfigurationElement[] getConfigurationElementsFor(String extensionPointId) {
/*  295 */     int lastdot = extensionPointId.lastIndexOf('.');
/*  296 */     if (lastdot == -1)
/*  297 */       return new IConfigurationElement[0]; 
/*  298 */     return getConfigurationElementsFor(extensionPointId.substring(0, lastdot), extensionPointId.substring(lastdot + 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IConfigurationElement[] getConfigurationElementsFor(String pluginId, String extensionPointSimpleId) {
/*  308 */     IExtensionPoint extPoint = getExtensionPoint(pluginId, extensionPointSimpleId);
/*  309 */     if (extPoint == null)
/*  310 */       return new IConfigurationElement[0]; 
/*  311 */     return extPoint.getConfigurationElements();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IConfigurationElement[] getConfigurationElementsFor(String pluginId, String extensionPointName, String extensionId) {
/*  321 */     IExtension extension = getExtension(pluginId, extensionPointName, extensionId);
/*  322 */     if (extension == null)
/*  323 */       return new IConfigurationElement[0]; 
/*  324 */     return extension.getConfigurationElements();
/*      */   }
/*      */ 
/*      */   
/*      */   private RegistryDelta getDelta(String namespace) {
/*  329 */     RegistryDelta existingDelta = (RegistryDelta)this.deltas.get(namespace);
/*  330 */     if (existingDelta != null) {
/*  331 */       return existingDelta;
/*      */     }
/*      */     
/*  334 */     RegistryDelta delta = new RegistryDelta();
/*  335 */     this.deltas.put(namespace, delta);
/*  336 */     return delta;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtension getExtension(String extensionId) {
/*      */     ExtensionHandle[] extensions;
/*  345 */     if (extensionId == null)
/*  346 */       return null; 
/*  347 */     int lastdot = extensionId.lastIndexOf('.');
/*  348 */     if (lastdot == -1)
/*  349 */       return null; 
/*  350 */     String namespace = extensionId.substring(0, lastdot);
/*      */ 
/*      */     
/*  353 */     this.access.enterRead();
/*      */     try {
/*  355 */       extensions = this.registryObjects.getExtensionsFromNamespace(namespace);
/*      */     } finally {
/*  357 */       this.access.exitRead();
/*      */     }  byte b; int i; ExtensionHandle[] arrayOfExtensionHandle1;
/*  359 */     for (i = (arrayOfExtensionHandle1 = extensions).length, b = 0; b < i; ) { ExtensionHandle suspect = arrayOfExtensionHandle1[b];
/*  360 */       if (extensionId.equals(suspect.getUniqueIdentifier()))
/*  361 */         return suspect;  b++; }
/*      */     
/*  363 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtension getExtension(String extensionPointId, String extensionId) {
/*  373 */     int lastdot = extensionPointId.lastIndexOf('.');
/*  374 */     if (lastdot == -1)
/*  375 */       return null; 
/*  376 */     return getExtension(extensionPointId.substring(0, lastdot), extensionPointId.substring(lastdot + 1), extensionId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtension getExtension(String pluginId, String extensionPointName, String extensionId) {
/*  386 */     IExtensionPoint extPoint = getExtensionPoint(pluginId, extensionPointName);
/*  387 */     if (extPoint != null)
/*  388 */       return extPoint.getExtension(extensionId); 
/*  389 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtensionPoint getExtensionPoint(String xptUniqueId) {
/*  398 */     this.access.enterRead();
/*      */     try {
/*  400 */       return this.registryObjects.getExtensionPointHandle(xptUniqueId);
/*      */     } finally {
/*  402 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtensionPoint getExtensionPoint(String elementName, String xpt) {
/*  412 */     this.access.enterRead();
/*      */     try {
/*  414 */       return this.registryObjects.getExtensionPointHandle(String.valueOf(elementName) + '.' + xpt);
/*      */     } finally {
/*  416 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtensionPoint[] getExtensionPoints() {
/*  426 */     this.access.enterRead();
/*      */     try {
/*  428 */       return (IExtensionPoint[])this.registryObjects.getExtensionPointsHandles();
/*      */     } finally {
/*  430 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtensionPoint[] getExtensionPoints(String namespaceName) {
/*  440 */     this.access.enterRead();
/*      */     try {
/*  442 */       return (IExtensionPoint[])this.registryObjects.getExtensionPointsFromNamespace(namespaceName);
/*      */     } finally {
/*  444 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IExtension[] getExtensions(String namespaceName) {
/*  454 */     this.access.enterRead();
/*      */     try {
/*  456 */       return (IExtension[])this.registryObjects.getExtensionsFromNamespace(namespaceName);
/*      */     } finally {
/*  458 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IExtension[] getExtensions(IContributor contributor) {
/*  464 */     if (!(contributor instanceof RegistryContributor))
/*  465 */       throw new IllegalArgumentException(); 
/*  466 */     String contributorId = ((RegistryContributor)contributor).getActualId();
/*  467 */     this.access.enterRead();
/*      */     try {
/*  469 */       return (IExtension[])this.registryObjects.getExtensionsFromContributor(contributorId);
/*      */     } finally {
/*  471 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IExtensionPoint[] getExtensionPoints(IContributor contributor) {
/*  477 */     if (!(contributor instanceof RegistryContributor))
/*  478 */       throw new IllegalArgumentException(); 
/*  479 */     String contributorId = ((RegistryContributor)contributor).getActualId();
/*  480 */     this.access.enterRead();
/*      */     try {
/*  482 */       return (IExtensionPoint[])this.registryObjects.getExtensionPointsFromContributor(contributorId);
/*      */     } finally {
/*  484 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getNamespaces() {
/*  494 */     this.access.enterRead();
/*      */     try {
/*  496 */       KeyedElement[] namespaceElements = this.registryObjects.getNamespacesIndex().elements();
/*  497 */       String[] namespaceNames = new String[namespaceElements.length];
/*  498 */       for (int i = 0; i < namespaceElements.length; i++) {
/*  499 */         namespaceNames[i] = (String)((RegistryIndexElement)namespaceElements[i]).getKey();
/*      */       }
/*  501 */       return namespaceNames;
/*      */     } finally {
/*  503 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasContributor(IContributor contributor) {
/*  509 */     if (!(contributor instanceof RegistryContributor))
/*  510 */       throw new IllegalArgumentException(); 
/*  511 */     String contributorId = ((RegistryContributor)contributor).getActualId();
/*  512 */     return hasContributor(contributorId);
/*      */   }
/*      */   
/*      */   public boolean hasContributor(String contributorId) {
/*  516 */     this.access.enterRead();
/*      */     try {
/*  518 */       return this.registryObjects.hasContribution(contributorId);
/*      */     } finally {
/*  520 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void link(ExtensionPoint extPoint, int[] extensions) {
/*  525 */     extPoint.setRawChildren(extensions);
/*  526 */     this.registryObjects.add(extPoint, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String recordChange(ExtensionPoint extPoint, int extension, int kind) {
/*  534 */     if (this.listeners.isEmpty())
/*  535 */       return null; 
/*  536 */     ExtensionDelta extensionDelta = new ExtensionDelta();
/*  537 */     extensionDelta.setExtension(extension);
/*  538 */     extensionDelta.setExtensionPoint(extPoint.getObjectId());
/*  539 */     extensionDelta.setKind(kind);
/*  540 */     getDelta(extPoint.getNamespace()).addExtensionDelta(extensionDelta);
/*  541 */     return extPoint.getNamespace();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String recordChange(ExtensionPoint extPoint, int[] extensions, int kind) {
/*  548 */     if (this.listeners.isEmpty())
/*  549 */       return null; 
/*  550 */     String namespace = extPoint.getNamespace();
/*  551 */     if (extensions == null || extensions.length == 0)
/*  552 */       return namespace; 
/*  553 */     RegistryDelta pluginDelta = getDelta(extPoint.getNamespace()); byte b; int i, arrayOfInt[];
/*  554 */     for (i = (arrayOfInt = extensions).length, b = 0; b < i; ) { int extension = arrayOfInt[b];
/*  555 */       ExtensionDelta extensionDelta = new ExtensionDelta();
/*  556 */       extensionDelta.setExtension(extension);
/*  557 */       extensionDelta.setExtensionPoint(extPoint.getObjectId());
/*  558 */       extensionDelta.setKind(kind);
/*  559 */       pluginDelta.addExtensionDelta(extensionDelta); b++; }
/*      */     
/*  561 */     return namespace;
/*      */   }
/*      */   
/*      */   public void remove(String removedContributorId, long timestamp) {
/*  565 */     remove(removedContributorId);
/*  566 */     if (timestamp != 0L) {
/*  567 */       this.aggregatedTimestamp.remove(timestamp);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeContributor(IContributor contributor, Object key) {
/*  572 */     if (!(contributor instanceof RegistryContributor))
/*  573 */       throw new IllegalArgumentException(); 
/*  574 */     if (!checkReadWriteAccess(key, true))
/*  575 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.removeContributor() method. Check if proper access token is supplied."); 
/*  576 */     String contributorId = ((RegistryContributor)contributor).getActualId();
/*  577 */     remove(contributorId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove(String removedContributorId) {
/*  589 */     this.access.enterWrite();
/*      */     try {
/*  591 */       this.eventDelta = CombinedEventDelta.recordRemoval();
/*  592 */       basicRemove(removedContributorId);
/*  593 */       fireRegistryChangeEvent();
/*  594 */       this.eventDelta = null;
/*      */     } finally {
/*  596 */       this.access.exitWrite();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private String removeExtension(int extensionId) {
/*  602 */     Extension extension = (Extension)this.registryObjects.getObject(extensionId, (byte)2);
/*  603 */     this.registryObjects.removeExtensionFromNamespaceIndex(extensionId, extension.getNamespaceIdentifier());
/*  604 */     String xptName = extension.getExtensionPointIdentifier();
/*  605 */     ExtensionPoint extPoint = this.registryObjects.getExtensionPointObject(xptName);
/*  606 */     if (extPoint == null) {
/*  607 */       this.registryObjects.removeOrphan(xptName, extensionId);
/*  608 */       return null;
/*      */     } 
/*      */     
/*  611 */     int[] existingExtensions = extPoint.getRawChildren();
/*  612 */     int[] newExtensions = RegistryObjectManager.EMPTY_INT_ARRAY;
/*  613 */     if (existingExtensions.length > 1) {
/*  614 */       newExtensions = new int[existingExtensions.length - 1];
/*  615 */       for (int i = 0, j = 0; i < existingExtensions.length; i++) {
/*  616 */         if (existingExtensions[i] != extension.getObjectId())
/*  617 */           newExtensions[j++] = existingExtensions[i]; 
/*      */       } 
/*  619 */     }  link(extPoint, newExtensions);
/*  620 */     if (this.eventDelta != null)
/*  621 */       this.eventDelta.rememberExtension(extPoint, extensionId); 
/*  622 */     return recordChange(extPoint, extension.getObjectId(), 2);
/*      */   }
/*      */   
/*      */   private String removeExtensionPoint(int extPoint) {
/*  626 */     ExtensionPoint extensionPoint = (ExtensionPoint)this.registryObjects.getObject(extPoint, (byte)3);
/*  627 */     this.registryObjects.removeExtensionPointFromNamespaceIndex(extPoint, extensionPoint.getNamespace());
/*  628 */     int[] existingExtensions = extensionPoint.getRawChildren();
/*  629 */     if (existingExtensions != null && existingExtensions.length != 0) {
/*  630 */       this.registryObjects.addOrphans(extensionPoint.getUniqueIdentifier(), existingExtensions);
/*  631 */       link(extensionPoint, RegistryObjectManager.EMPTY_INT_ARRAY);
/*      */     } 
/*  633 */     if (this.eventDelta != null) {
/*  634 */       this.eventDelta.rememberExtensionPoint(extensionPoint);
/*  635 */       this.eventDelta.rememberExtensions(extensionPoint, existingExtensions);
/*      */     } 
/*  637 */     return recordChange(extensionPoint, existingExtensions, 2);
/*      */   }
/*      */   
/*      */   private Set<String> removeExtensionsAndExtensionPoints(String contributorId) {
/*  641 */     Set<String> affectedNamespaces = new HashSet<>(); byte b; int i, arrayOfInt[];
/*  642 */     for (i = (arrayOfInt = this.registryObjects.getExtensionsFrom(contributorId)).length, b = 0; b < i; ) { int extension = arrayOfInt[b];
/*  643 */       String namespace = removeExtension(extension);
/*  644 */       if (namespace != null) {
/*  645 */         affectedNamespaces.add(namespace);
/*      */       }
/*      */       b++; }
/*      */     
/*  649 */     for (i = (arrayOfInt = this.registryObjects.getExtensionPointsFrom(contributorId)).length, b = 0; b < i; ) { int extPoint = arrayOfInt[b];
/*  650 */       String namespace = removeExtensionPoint(extPoint);
/*  651 */       if (namespace != null)
/*  652 */         affectedNamespaces.add(namespace);  b++; }
/*      */     
/*  654 */     return affectedNamespaces;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeRegistryChangeListener(IRegistryChangeListener listener) {
/*  659 */     synchronized (this.listeners) {
/*  660 */       this.listeners.remove(new ListenerInfo((EventListener)listener, null));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeListener(IRegistryEventListener listener) {
/*  666 */     synchronized (this.listeners) {
/*  667 */       this.listeners.remove(new ListenerInfo((EventListener)listener, null));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop(Object key) {
/*  752 */     if (this.masterToken != null && this.masterToken != key) {
/*  753 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.stop() method. Check if proper access token is supplied.");
/*      */     }
/*      */ 
/*      */     
/*  757 */     this.strategy.onStop(this);
/*      */     
/*  759 */     stopChangeEventScheduler();
/*      */     
/*  761 */     if (this.cacheStorageManager == null) {
/*      */       return;
/*      */     }
/*  764 */     if (!this.registryObjects.isDirty() || this.cacheStorageManager.isReadOnly()) {
/*  765 */       this.cacheStorageManager.close();
/*  766 */       this.theTableReader.close();
/*      */       
/*      */       return;
/*      */     } 
/*  770 */     File tableFile = null;
/*  771 */     File mainFile = null;
/*  772 */     File extraFile = null;
/*  773 */     File contributionsFile = null;
/*  774 */     File contributorsFile = null;
/*  775 */     File namespacesFile = null;
/*  776 */     File orphansFile = null;
/*      */     
/*  778 */     TableWriter theTableWriter = new TableWriter(this);
/*      */     
/*      */     try {
/*  781 */       this.cacheStorageManager.lookup(".table", true);
/*  782 */       this.cacheStorageManager.lookup(".mainData", true);
/*  783 */       this.cacheStorageManager.lookup(".extraData", true);
/*  784 */       this.cacheStorageManager.lookup(".contributions", true);
/*  785 */       this.cacheStorageManager.lookup(".contributors", true);
/*  786 */       this.cacheStorageManager.lookup(".namespaces", true);
/*  787 */       this.cacheStorageManager.lookup(".orphans", true);
/*  788 */       tableFile = File.createTempFile(".table", ".new", this.cacheStorageManager.getBase());
/*  789 */       mainFile = File.createTempFile(".mainData", ".new", this.cacheStorageManager.getBase());
/*  790 */       extraFile = File.createTempFile(".extraData", ".new", this.cacheStorageManager.getBase());
/*  791 */       contributionsFile = File.createTempFile(".contributions", ".new", this.cacheStorageManager.getBase());
/*  792 */       contributorsFile = File.createTempFile(".contributors", ".new", this.cacheStorageManager.getBase());
/*  793 */       namespacesFile = File.createTempFile(".namespaces", ".new", this.cacheStorageManager.getBase());
/*  794 */       orphansFile = File.createTempFile(".orphans", ".new", this.cacheStorageManager.getBase());
/*  795 */       theTableWriter.setTableFile(tableFile);
/*  796 */       theTableWriter.setExtraDataFile(extraFile);
/*  797 */       theTableWriter.setMainDataFile(mainFile);
/*  798 */       theTableWriter.setContributionsFile(contributionsFile);
/*  799 */       theTableWriter.setContributorsFile(contributorsFile);
/*  800 */       theTableWriter.setNamespacesFile(namespacesFile);
/*  801 */       theTableWriter.setOrphansFile(orphansFile);
/*  802 */     } catch (IOException iOException) {
/*  803 */       this.cacheStorageManager.close();
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*      */       long timestamp;
/*      */       
/*  813 */       if (this.aggregatedTimestamp.isModifed()) {
/*  814 */         timestamp = this.aggregatedTimestamp.getContentsTimestamp();
/*      */       } else {
/*  816 */         timestamp = this.strategy.getContributionsTimestamp();
/*      */       } 
/*  818 */       if (theTableWriter.saveCache(this.registryObjects, timestamp))
/*  819 */         this.cacheStorageManager.update(new String[] { ".table", ".mainData", ".extraData", ".contributions", ".contributors", ".namespaces", ".orphans" }, new String[] { tableFile.getName(), mainFile.getName(), extraFile.getName(), contributionsFile.getName(), contributorsFile.getName(), namespacesFile.getName(), orphansFile.getName() }); 
/*  820 */     } catch (IOException iOException) {}
/*      */ 
/*      */     
/*  823 */     this.theTableReader.close();
/*  824 */     this.cacheStorageManager.close();
/*      */   }
/*      */   
/*      */   public void clearRegistryCache() {
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  831 */     for (i = (arrayOfString = new String[] { ".table", ".mainData", ".extraData", ".contributions", ".orphans" }, ).length, b = 0; b < i; ) { String key = arrayOfString[b];
/*      */       try {
/*  833 */         this.cacheStorageManager.remove(key);
/*  834 */       } catch (IOException e) {
/*  835 */         log((IStatus)new Status(4, "org.eclipse.equinox.registry", 4, RegistryMessages.meta_registryCacheReadProblems, e));
/*      */       }  b++; }
/*  837 */      this.aggregatedTimestamp.reset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExtensionRegistry(RegistryStrategy registryStrategy, Object masterToken, Object userToken) {
/*  844 */     this.theRegistryObjectFactory = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  976 */     this.eventThread = null;
/*  977 */     this.queue = new LinkedList<>(); this.isMultiLanguage = "true".equals(RegistryProperties.getProperty("eclipse.registry.MultiLanguage")); if (registryStrategy != null) { this.strategy = registryStrategy; } else { this.strategy = new RegistryStrategy(null, null); }  this.masterToken = masterToken; this.userToken = userToken; this.registryObjects = new RegistryObjectManager(this); boolean isRegistryFilledFromCache = false; if (this.strategy.cacheUse()) { long start = 0L; if (debug()) start = System.currentTimeMillis();  if (checkCache()) try { this.theTableReader.setTableFile(this.cacheStorageManager.lookup(".table", false)); this.theTableReader.setExtraDataFile(this.cacheStorageManager.lookup(".extraData", false)); this.theTableReader.setMainDataFile(this.cacheStorageManager.lookup(".mainData", false)); this.theTableReader.setContributionsFile(this.cacheStorageManager.lookup(".contributions", false)); this.theTableReader.setContributorsFile(this.cacheStorageManager.lookup(".contributors", false)); this.theTableReader.setNamespacesFile(this.cacheStorageManager.lookup(".namespaces", false)); this.theTableReader.setOrphansFile(this.cacheStorageManager.lookup(".orphans", false)); long timestamp = this.strategy.getContributionsTimestamp(); isRegistryFilledFromCache = this.registryObjects.init(timestamp); if (isRegistryFilledFromCache) this.aggregatedTimestamp.set(timestamp);  } catch (IOException e) { isRegistryFilledFromCache = false; clearRegistryCache(); log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.registry_bad_cache, e)); }   if (!isRegistryFilledFromCache) for (int index = 0; index < this.strategy.getLocationsLength(); index++) { if (!this.strategy.isCacheReadOnly(index)) { setFileManager(this.strategy.getStorage(index), false); break; }  }   if (debug() && isRegistryFilledFromCache) System.out.println("Reading registry cache: " + (System.currentTimeMillis() - start));  if (debug()) if (!isRegistryFilledFromCache) { System.out.println("Reloading registry from manifest files..."); } else { System.out.println("Using registry cache..."); }   }  if (debugEvents()) addRegistryChangeListener(System.out::println);  this.strategy.onStart(this); this.strategy.onStart(this, isRegistryFilledFromCache);
/*      */   }
/*      */   protected void setElementFactory() { if (this.isMultiLanguage) { this.theRegistryObjectFactory = new RegistryObjectFactoryMulti(this); } else { this.theRegistryObjectFactory = new RegistryObjectFactory(this); }  }
/*      */   public RegistryObjectFactory getElementFactory() { if (this.theRegistryObjectFactory == null) setElementFactory();  return this.theRegistryObjectFactory; }
/*      */   TableReader getTableReader() { return this.theTableReader; }
/*  982 */   public void log(IStatus status) { this.strategy.log(status); } public String translate(String key, ResourceBundle resources) { if (this.isMultiLanguage) return key;  return this.strategy.translate(key, resources); } public boolean debug() { return this.strategy.debug(); } public void scheduleChangeEvent(Object[] listenerInfos, Map<String, ?> scheduledDeltas) { QueueElement newElement = new QueueElement(listenerInfos, scheduledDeltas);
/*  983 */     if (this.eventThread == null) {
/*  984 */       this.eventThread = new RegistryEventThread(this);
/*  985 */       this.eventThread.start();
/*      */     } 
/*  987 */     synchronized (this.queue)
/*  988 */     { this.queue.add(newElement);
/*  989 */       this.queue.notify(); }  }
/*      */   public boolean debugEvents() { return this.strategy.debugRegistryEvents(); }
/*      */   public boolean useLazyCacheLoading() { return this.strategy.cacheLazyLoading(); }
/*      */   public long computeState() { return this.strategy.getContainerTimestamp(); }
/*      */   protected boolean checkCache() { for (int index = 0; index < this.strategy.getLocationsLength(); index++) { File possibleCacheLocation = this.strategy.getStorage(index); if (possibleCacheLocation == null) break;  setFileManager(possibleCacheLocation, this.strategy.isCacheReadOnly(index)); if (this.cacheStorageManager != null) { File cacheFile = null; try { cacheFile = this.cacheStorageManager.lookup(TableReader.getTestFileName(), false); } catch (IOException iOException) {} if (cacheFile != null && cacheFile.isFile()) return true;  }  }  return false; } public Object createExecutableExtension(RegistryContributor defaultContributor, String className, String requestedContributorName) throws CoreException { return this.strategy.createExecutableExtension(defaultContributor, className, requestedContributorName); } public IStatus processChangeEvent(Object[] listenerInfos, final Map<String, ?> scheduledDeltas) { CombinedEventDelta extendedDelta = (CombinedEventDelta)scheduledDeltas.remove(""); final MultiStatus result = new MultiStatus("org.eclipse.equinox.registry", 0, RegistryMessages.plugin_eventListenerError, null); byte b; int i; Object[] arrayOfObject; for (i = (arrayOfObject = listenerInfos).length, b = 0; b < i; ) { Object info = arrayOfObject[b]; final ListenerInfo listenerInfo = (ListenerInfo)info; if (listenerInfo.listener instanceof IRegistryChangeListener && scheduledDeltas.size() != 0 && (listenerInfo.filter == null || scheduledDeltas.containsKey(listenerInfo.filter))) SafeRunner.run(new ISafeRunnable() {
/*      */               public void run() throws Exception { ((IRegistryChangeListener)listenerInfo.listener).registryChanged(new RegistryChangeEvent(scheduledDeltas, listenerInfo.filter)); } public void handleException(Throwable exception) { result.add((IStatus)new Status(4, "org.eclipse.equinox.registry", RegistryMessages.plugin_eventListenerError, exception)); }
/*      */             });  if (listenerInfo.listener instanceof IRegistryEventListener) { IRegistryEventListener extensionListener = (IRegistryEventListener)listenerInfo.listener; IExtension[] extensions = extendedDelta.getExtensions(listenerInfo.filter); IExtensionPoint[] extensionPoints = extendedDelta.getExtensionPoints(listenerInfo.filter); if (extendedDelta.isAddition()) { if (extensionPoints != null) extensionListener.added(extensionPoints);  if (extensions != null) extensionListener.added(extensions);  } else { if (extensions != null) extensionListener.removed(extensions);  if (extensionPoints != null) extensionListener.removed(extensionPoints);  }  }  b++; }  for (Object delta : scheduledDeltas.values())
/*      */       ((RegistryDelta)delta).getObjectManager().close();  IObjectManager manager = extendedDelta.getObjectManager(); if (manager != null)
/*      */       manager.close();  return (IStatus)result; } private static class QueueElement
/*      */   {
/*  999 */     Object[] listenerInfos; Map<String, ?> scheduledDeltas; QueueElement(Object[] infos, Map<String, ?> deltas) { this.scheduledDeltas = deltas;
/* 1000 */       this.listenerInfos = infos; }
/*      */   
/*      */   }
/*      */   
/*      */   private class RegistryEventThread extends Thread {
/*      */     private final ExtensionRegistry registry;
/*      */     
/*      */     public RegistryEventThread(ExtensionRegistry registry) {
/* 1008 */       super("Extension Registry Event Dispatcher");
/* 1009 */       setDaemon(true);
/* 1010 */       this.registry = registry;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       while (true) {
/*      */         ExtensionRegistry.QueueElement element;
/* 1017 */         synchronized (ExtensionRegistry.this.queue) {
/*      */           try {
/* 1019 */             while (ExtensionRegistry.this.queue.isEmpty())
/* 1020 */               ExtensionRegistry.this.queue.wait(); 
/* 1021 */           } catch (InterruptedException interruptedException) {
/*      */             return;
/*      */           } 
/* 1024 */           element = ExtensionRegistry.this.queue.remove(0);
/*      */         } 
/* 1026 */         this.registry.processChangeEvent(element.listenerInfos, element.scheduledDeltas);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected void stopChangeEventScheduler() {
/* 1032 */     if (this.eventThread != null) {
/* 1033 */       synchronized (this.queue) {
/* 1034 */         this.eventThread.interrupt();
/* 1035 */         this.eventThread = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkReadWriteAccess(Object key, boolean persist) {
/* 1050 */     if (this.masterToken == key)
/* 1051 */       return true; 
/* 1052 */     if (this.userToken == key && !persist)
/* 1053 */       return true; 
/* 1054 */     return false;
/*      */   }
/*      */   
/*      */   public boolean addContribution(InputStream is, IContributor contributor, boolean persist, String contributionName, ResourceBundle translationBundle, Object key, long timestamp) {
/* 1058 */     boolean result = addContribution(is, contributor, persist, contributionName, translationBundle, key);
/* 1059 */     if (timestamp != 0L)
/* 1060 */       this.aggregatedTimestamp.add(timestamp); 
/* 1061 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean addContribution(InputStream is, IContributor contributor, boolean persist, String contributionName, ResourceBundle translationBundle, Object key) {
/* 1066 */     if (!checkReadWriteAccess(key, persist))
/* 1067 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.addContribution() method. Check if proper access token is supplied."); 
/* 1068 */     if (contributionName == null) {
/* 1069 */       contributionName = "";
/*      */     }
/* 1071 */     RegistryContributor internalContributor = (RegistryContributor)contributor;
/* 1072 */     this.registryObjects.addContributor(internalContributor);
/*      */     
/* 1074 */     String ownerName = internalContributor.getActualName();
/* 1075 */     String message = NLS.bind(RegistryMessages.parse_problems, ownerName);
/* 1076 */     MultiStatus problems = new MultiStatus("org.eclipse.equinox.registry", 1, message, null);
/* 1077 */     ExtensionsParser parser = new ExtensionsParser(problems, this);
/* 1078 */     Contribution contribution = getElementFactory().createContribution(internalContributor.getActualId(), persist);
/*      */     
/*      */     try {
/* 1081 */       parser.parseManifest(this.strategy.getXMLParser(), new InputSource(is), contributionName, getObjectManager(), contribution, translationBundle);
/* 1082 */       int status = problems.getSeverity();
/* 1083 */       if (status != 0) {
/* 1084 */         log((IStatus)problems);
/* 1085 */         if (status == 4 || status == 8)
/* 1086 */           return false; 
/*      */       } 
/* 1088 */     } catch (ParserConfigurationException|org.xml.sax.SAXException|IOException e) {
/* 1089 */       logError(ownerName, contributionName, e);
/* 1090 */       return false;
/*      */     } finally {
/*      */       try {
/* 1093 */         is.close();
/* 1094 */       } catch (IOException iOException) {}
/*      */     } 
/*      */ 
/*      */     
/* 1098 */     add(contribution);
/* 1099 */     return true;
/*      */   }
/*      */   
/*      */   private void logError(String owner, String contributionName, Exception e) {
/* 1103 */     String message = NLS.bind(RegistryMessages.parse_failedParsingManifest, String.valueOf(owner) + "/" + contributionName);
/* 1104 */     log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, message, e));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addExtensionPoint(String identifier, IContributor contributor, boolean persist, String label, String schemaReference, Object token) throws IllegalArgumentException {
/*      */     String uniqueId, namespaceName;
/* 1129 */     if (!checkReadWriteAccess(token, persist)) {
/* 1130 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.addExtensionPoint() method. Check if proper access token is supplied.");
/*      */     }
/* 1132 */     RegistryContributor internalContributor = (RegistryContributor)contributor;
/* 1133 */     this.registryObjects.addContributor(internalContributor);
/* 1134 */     String contributorId = internalContributor.getActualId();
/*      */ 
/*      */     
/* 1137 */     if (identifier == null) {
/* 1138 */       String message = NLS.bind(RegistryMessages.create_failedExtensionPoint, label);
/* 1139 */       log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, message, null));
/* 1140 */       throw new NullPointerException(message);
/*      */     } 
/* 1142 */     if (schemaReference == null) {
/* 1143 */       schemaReference = "";
/*      */     }
/*      */     
/* 1146 */     Contribution contribution = getElementFactory().createContribution(contributorId, persist);
/* 1147 */     ExtensionPoint currentExtPoint = getElementFactory().createExtensionPoint(persist);
/*      */ 
/*      */ 
/*      */     
/* 1151 */     int simpleIdStart = identifier.lastIndexOf('.');
/* 1152 */     if (simpleIdStart == -1) {
/* 1153 */       namespaceName = contribution.getDefaultNamespace();
/* 1154 */       uniqueId = String.valueOf(namespaceName) + '.' + identifier;
/*      */     } else {
/* 1156 */       namespaceName = identifier.substring(0, simpleIdStart);
/* 1157 */       uniqueId = identifier;
/*      */     } 
/* 1159 */     currentExtPoint.setUniqueIdentifier(uniqueId);
/* 1160 */     currentExtPoint.setNamespace(namespaceName);
/* 1161 */     String labelNLS = translate(label, null);
/* 1162 */     currentExtPoint.setLabel(labelNLS);
/* 1163 */     currentExtPoint.setSchema(schemaReference);
/*      */     
/* 1165 */     if (!getObjectManager().addExtensionPoint(currentExtPoint, true)) {
/* 1166 */       if (debug()) {
/* 1167 */         String msg = NLS.bind(RegistryMessages.parse_duplicateExtensionPoint, uniqueId, contribution.getDefaultNamespace());
/* 1168 */         log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, msg, null));
/*      */       } 
/* 1170 */       return false;
/*      */     } 
/*      */     
/* 1173 */     currentExtPoint.setContributorId(contributorId);
/*      */ 
/*      */     
/* 1176 */     int[] contributionChildren = new int[3];
/*      */     
/* 1178 */     contributionChildren[0] = 1;
/* 1179 */     contributionChildren[1] = 0;
/* 1180 */     contributionChildren[2] = currentExtPoint.getObjectId();
/*      */     
/* 1182 */     contribution.setRawChildren(contributionChildren);
/*      */     
/* 1184 */     add(contribution);
/* 1185 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addExtension(String identifier, IContributor contributor, boolean persist, String label, String extensionPointId, ConfigurationElementDescription configurationElements, Object token) throws IllegalArgumentException {
/*      */     String simpleId, namespaceName, targetExtensionPointId;
/* 1213 */     if (!checkReadWriteAccess(token, persist)) {
/* 1214 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.addExtensionPoint() method. Check if proper access token is supplied.");
/*      */     }
/* 1216 */     RegistryContributor internalContributor = (RegistryContributor)contributor;
/* 1217 */     this.registryObjects.addContributor(internalContributor);
/* 1218 */     String contributorId = internalContributor.getActualId();
/*      */ 
/*      */     
/* 1221 */     Contribution contribution = getElementFactory().createContribution(contributorId, persist);
/* 1222 */     Extension currentExtension = getElementFactory().createExtension(persist);
/*      */ 
/*      */ 
/*      */     
/* 1226 */     int simpleIdStart = identifier.lastIndexOf('.');
/* 1227 */     if (simpleIdStart != -1) {
/* 1228 */       simpleId = identifier.substring(simpleIdStart + 1);
/* 1229 */       namespaceName = identifier.substring(0, simpleIdStart);
/*      */     } else {
/* 1231 */       simpleId = identifier;
/* 1232 */       namespaceName = contribution.getDefaultNamespace();
/*      */     } 
/* 1234 */     currentExtension.setSimpleIdentifier(simpleId);
/* 1235 */     currentExtension.setNamespaceIdentifier(namespaceName);
/*      */     
/* 1237 */     String extensionLabelNLS = translate(label, null);
/* 1238 */     currentExtension.setLabel(extensionLabelNLS);
/*      */ 
/*      */     
/* 1241 */     if (extensionPointId.indexOf('.') == -1) {
/* 1242 */       targetExtensionPointId = String.valueOf(contribution.getDefaultNamespace()) + '.' + extensionPointId;
/*      */     } else {
/* 1244 */       targetExtensionPointId = extensionPointId;
/* 1245 */     }  currentExtension.setExtensionPointIdentifier(targetExtensionPointId);
/*      */ 
/*      */ 
/*      */     
/* 1249 */     if (simpleId != null && debug()) {
/* 1250 */       String uniqueId = String.valueOf(namespaceName) + '.' + simpleId;
/* 1251 */       IExtension existingExtension = getExtension(uniqueId);
/* 1252 */       if (existingExtension != null) {
/* 1253 */         String currentSupplier = contribution.getDefaultNamespace();
/* 1254 */         String existingSupplier = existingExtension.getContributor().getName();
/* 1255 */         String msg = NLS.bind(RegistryMessages.parse_duplicateExtension, (Object[])new String[] { currentSupplier, existingSupplier, uniqueId });
/* 1256 */         log((IStatus)new Status(2, "org.eclipse.equinox.registry", 0, msg, null));
/* 1257 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1261 */     getObjectManager().add(currentExtension, true);
/*      */     
/* 1263 */     createExtensionData(contributorId, configurationElements, currentExtension, persist);
/*      */     
/* 1265 */     currentExtension.setContributorId(contributorId);
/*      */     
/* 1267 */     int[] contributionChildren = new int[3];
/*      */     
/* 1269 */     contributionChildren[0] = 0;
/* 1270 */     contributionChildren[1] = 1;
/* 1271 */     contributionChildren[2] = currentExtension.getObjectId();
/* 1272 */     contribution.setRawChildren(contributionChildren);
/*      */     
/* 1274 */     add(contribution);
/* 1275 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private void createExtensionData(String contributorId, ConfigurationElementDescription description, RegistryObject parent, boolean persist) {
/* 1280 */     ConfigurationElement currentConfigurationElement = getElementFactory().createConfigurationElement(persist);
/* 1281 */     currentConfigurationElement.setContributorId(contributorId);
/* 1282 */     currentConfigurationElement.setName(description.getName());
/*      */     
/* 1284 */     ConfigurationElementAttribute[] descriptionProperties = description.getAttributes();
/*      */     
/* 1286 */     if (descriptionProperties != null && descriptionProperties.length != 0) {
/* 1287 */       int len = descriptionProperties.length;
/* 1288 */       String[] properties = new String[len * 2];
/* 1289 */       for (int j = 0; j < len; j++) {
/* 1290 */         properties[j * 2] = descriptionProperties[j].getName();
/* 1291 */         properties[j * 2 + 1] = translate(descriptionProperties[j].getValue(), null);
/*      */       } 
/* 1293 */       currentConfigurationElement.setProperties(properties);
/*      */     } else {
/* 1295 */       currentConfigurationElement.setProperties(RegistryObjectManager.EMPTY_STRING_ARRAY);
/*      */     } 
/* 1297 */     String value = description.getValue();
/* 1298 */     if (value != null) {
/* 1299 */       currentConfigurationElement.setValue(value);
/*      */     }
/* 1301 */     getObjectManager().add(currentConfigurationElement, true);
/*      */ 
/*      */     
/* 1304 */     ConfigurationElementDescription[] children = description.getChildren();
/* 1305 */     if (children != null) {
/* 1306 */       byte b; int j; ConfigurationElementDescription[] arrayOfConfigurationElementDescription; for (j = (arrayOfConfigurationElementDescription = children).length, b = 0; b < j; ) { ConfigurationElementDescription element = arrayOfConfigurationElementDescription[b];
/* 1307 */         createExtensionData(contributorId, element, currentConfigurationElement, persist);
/*      */         b++; }
/*      */     
/*      */     } 
/* 1311 */     int[] oldValues = parent.getRawChildren();
/* 1312 */     int size = oldValues.length;
/* 1313 */     int[] newValues = new int[size + 1];
/* 1314 */     for (int i = 0; i < size; i++) {
/* 1315 */       newValues[i] = oldValues[i];
/*      */     }
/* 1317 */     newValues[size] = currentConfigurationElement.getObjectId();
/* 1318 */     parent.setRawChildren(newValues);
/* 1319 */     currentConfigurationElement.setParentId(parent.getObjectId());
/* 1320 */     currentConfigurationElement.setParentType((parent instanceof ConfigurationElement) ? 1 : 2);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean removeExtension(IExtension extension, Object token) throws IllegalArgumentException {
/* 1325 */     if (!(extension instanceof ExtensionHandle))
/* 1326 */       return false; 
/* 1327 */     return removeObject(((ExtensionHandle)extension).getObject(), false, token);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean removeExtensionPoint(IExtensionPoint extensionPoint, Object token) throws IllegalArgumentException {
/* 1332 */     if (!(extensionPoint instanceof ExtensionPointHandle))
/* 1333 */       return false; 
/* 1334 */     return removeObject(((ExtensionPointHandle)extensionPoint).getObject(), true, token);
/*      */   }
/*      */   
/*      */   private boolean removeObject(RegistryObject registryObject, boolean isExtensionPoint, Object token) {
/* 1338 */     if (!checkReadWriteAccess(token, registryObject.shouldPersist()))
/* 1339 */       throw new IllegalArgumentException("Unauthorized access to the ExtensionRegistry.removeExtension() method. Check if proper access token is supplied."); 
/* 1340 */     int id = registryObject.getObjectId();
/*      */     
/* 1342 */     this.access.enterWrite(); try {
/*      */       String namespace;
/* 1344 */       this.eventDelta = CombinedEventDelta.recordRemoval();
/*      */       
/* 1346 */       if (isExtensionPoint) {
/* 1347 */         namespace = removeExtensionPoint(id);
/*      */       } else {
/* 1349 */         namespace = removeExtension(id);
/* 1350 */       }  Map<Integer, RegistryObject> removed = new HashMap<>(1);
/* 1351 */       removed.put(Integer.valueOf(id), registryObject);
/*      */ 
/*      */       
/* 1354 */       if (!isExtensionPoint)
/* 1355 */         this.registryObjects.addAssociatedObjects(removed, registryObject); 
/* 1356 */       this.registryObjects.removeObjects(removed);
/* 1357 */       this.registryObjects.addNavigableObjects(removed);
/* 1358 */       IObjectManager manager = this.registryObjects.createDelegatingObjectManager(removed);
/* 1359 */       getDelta(namespace).setObjectManager(manager);
/* 1360 */       this.eventDelta.setObjectManager(manager);
/*      */       
/* 1362 */       this.registryObjects.unlinkChildFromContributions(id);
/* 1363 */       fireRegistryChangeEvent();
/* 1364 */       this.eventDelta = null;
/*      */     } finally {
/* 1366 */       this.access.exitWrite();
/*      */     } 
/* 1368 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public IContributor[] getAllContributors() {
/* 1373 */     this.access.enterRead();
/*      */     try {
/* 1375 */       return this.registryObjects.getContributorsSync();
/*      */     } finally {
/* 1377 */       this.access.exitRead();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getTemporaryUserToken() {
/* 1387 */     return this.userToken;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMultiLanguage() {
/* 1392 */     return this.isMultiLanguage;
/*      */   }
/*      */   
/*      */   public String[] translate(String[] nonTranslated, IContributor contributor, String locale) {
/* 1396 */     return this.strategy.translate(nonTranslated, contributor, locale);
/*      */   }
/*      */   
/*      */   public String getLocale() {
/* 1400 */     return this.strategy.getLocale();
/*      */   }
/*      */   
/*      */   public void logMultiLangError() {
/* 1404 */     if (this.mlErrorLogged)
/*      */       return; 
/* 1406 */     log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.registry_non_multi_lang, new IllegalArgumentException()));
/* 1407 */     this.mlErrorLogged = true;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionRegistry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */