/*     */ package org.eclipse.core.internal.adapter;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.runtime.AdapterManager;
/*     */ import org.eclipse.core.internal.runtime.IAdapterManagerProvider;
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IRegistryEventListener;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdapterManagerListener
/*     */   implements IRegistryEventListener, IAdapterManagerProvider
/*     */ {
/*     */   public static final String ADAPTER_POINT_ID = "org.eclipse.core.runtime.adapters";
/*     */   private final AdapterManager theAdapterManager;
/*     */   
/*     */   public AdapterManagerListener() {
/*  34 */     this.theAdapterManager = AdapterManager.getDefault();
/*  35 */     this.theAdapterManager.registerLazyFactoryProvider(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addFactories(AdapterManager adapterManager) {
/*  45 */     IExtensionPoint point = RegistryFactory.getRegistry().getExtensionPoint("org.eclipse.core.runtime.adapters");
/*  46 */     if (point == null) {
/*  47 */       return false;
/*     */     }
/*  49 */     boolean factoriesAdded = false;
/*  50 */     IExtension[] extensions = point.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/*  51 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/*  52 */       IConfigurationElement[] elements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  53 */       for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/*  54 */         AdapterFactoryProxy proxy = AdapterFactoryProxy.createProxy(element);
/*  55 */         if (proxy != null) {
/*  56 */           adapterManager.registerFactory(proxy, proxy.getAdaptableType());
/*  57 */           factoriesAdded = true;
/*     */         }  b1++; }
/*     */        b++; }
/*     */     
/*  61 */     RegistryFactory.getRegistry().addListener(this, "org.eclipse.core.runtime.adapters");
/*  62 */     return factoriesAdded;
/*     */   }
/*     */   
/*     */   private void registerExtension(IExtension extension) {
/*  66 */     IConfigurationElement[] elements = extension.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  67 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/*  68 */       AdapterFactoryProxy proxy = AdapterFactoryProxy.createProxy(element);
/*  69 */       if (proxy != null)
/*  70 */         this.theAdapterManager.registerFactory(proxy, proxy.getAdaptableType()); 
/*     */       b++; }
/*     */      } public synchronized void added(IExtension[] extensions) {
/*     */     byte b;
/*     */     int i;
/*     */     IExtension[] arrayOfIExtension;
/*  76 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/*  77 */       registerExtension(extension); b++; }
/*     */     
/*  79 */     this.theAdapterManager.flushLookup();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void removed(IExtension[] extensions) {
/*  84 */     this.theAdapterManager.flushLookup(); byte b; int i; IExtension[] arrayOfIExtension;
/*  85 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/*  86 */       for (List<IAdapterFactory> adapterFactories : (Iterable<List<IAdapterFactory>>)this.theAdapterManager.getFactories().values()) {
/*  87 */         adapterFactories.removeIf(factory -> (factory instanceof AdapterFactoryProxy && ((AdapterFactoryProxy)factory).originatesFrom(paramIExtension)));
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void added(IExtensionPoint[] extensionPoints) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removed(IExtensionPoint[] extensionPoints) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void stop() {
/* 108 */     RegistryFactory.getRegistry().removeListener(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\adapter\AdapterManagerListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */