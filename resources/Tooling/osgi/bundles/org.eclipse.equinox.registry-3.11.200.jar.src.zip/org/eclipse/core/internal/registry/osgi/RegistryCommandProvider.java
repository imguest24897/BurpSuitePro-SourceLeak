/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.osgi.framework.console.CommandInterpreter;
/*     */ import org.eclipse.osgi.framework.console.CommandProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryCommandProvider
/*     */   implements CommandProvider
/*     */ {
/*     */   private static final String NEW_LINE = "\r\n";
/*     */   private static final String indent = "   ";
/*     */   private boolean verbose = false;
/*     */   
/*     */   public String getHelp() {
/*  32 */     return getHelp(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getHelp(String commandName) {
/*  40 */     boolean all = (commandName == null);
/*  41 */     StringBuilder sb = new StringBuilder();
/*  42 */     if (all) {
/*  43 */       sb.append("---Extension Registry Commands---");
/*  44 */       sb.append("\r\n");
/*     */     } 
/*  46 */     if (all || "ns".equals(commandName)) {
/*  47 */       sb.append("\tns [-v] [name] - display extension points in the namespace; add -v to display extensions");
/*  48 */       sb.append("\r\n");
/*     */     } 
/*  50 */     if (all || "pt".equals(commandName)) {
/*  51 */       sb.append("\tpt [-v] uniqueExtensionPointId - display the extension point and extensions; add -v to display config elements");
/*  52 */       sb.append("\r\n");
/*     */     } 
/*  54 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void _ns(CommandInterpreter ci) throws Exception {
/*  58 */     String namespace = getArgument(ci);
/*  59 */     if (namespace == null) {
/*  60 */       String[] namespaces = RegistryFactory.getRegistry().getNamespaces();
/*  61 */       ci.println("Namespace(s):");
/*  62 */       ci.println("-------------------"); byte b1; int j; String[] arrayOfString1;
/*  63 */       for (j = (arrayOfString1 = namespaces).length, b1 = 0; b1 < j; ) { String n = arrayOfString1[b1];
/*  64 */         ci.println(n);
/*     */         b1++; }
/*     */       
/*     */       return;
/*     */     } 
/*  69 */     IExtensionRegistry registry = RegistryFactory.getRegistry();
/*  70 */     IExtensionPoint[] extpts = registry.getExtensionPoints(namespace);
/*  71 */     ci.println("Extension point(s):");
/*  72 */     ci.println("-------------------"); byte b; int i; IExtensionPoint[] arrayOfIExtensionPoint1;
/*  73 */     for (i = (arrayOfIExtensionPoint1 = extpts).length, b = 0; b < i; ) { IExtensionPoint extpt = arrayOfIExtensionPoint1[b];
/*  74 */       displayExtensionPoint(extpt, ci);
/*     */       b++; }
/*     */     
/*  77 */     if (this.verbose) {
/*  78 */       ci.println("\nExtension(s):");
/*  79 */       ci.println("-------------------");
/*  80 */       IExtension[] exts = RegistryFactory.getRegistry().getExtensions(namespace); IExtension[] arrayOfIExtension1;
/*  81 */       for (int j = (arrayOfIExtension1 = exts).length; i < j; ) { IExtension ext = arrayOfIExtension1[i];
/*  82 */         displayExtension(ext, ci, true);
/*     */         i++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   public void _pt(CommandInterpreter ci) throws Exception {
/*  88 */     String extensionPointId = getArgument(ci);
/*  89 */     if (extensionPointId == null)
/*     */       return; 
/*  91 */     IExtensionPoint extpt = RegistryFactory.getRegistry().getExtensionPoint(extensionPointId);
/*  92 */     if (extpt == null)
/*     */       return; 
/*  94 */     ci.print("Extension point: ");
/*  95 */     displayExtensionPoint(extpt, ci);
/*  96 */     IExtension[] exts = extpt.getExtensions();
/*  97 */     ci.println("\nExtension(s):");
/*  98 */     ci.println("-------------------"); byte b; int i; IExtension[] arrayOfIExtension1;
/*  99 */     for (i = (arrayOfIExtension1 = exts).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 100 */       displayExtension(ext, ci, false);
/* 101 */       if (this.verbose) {
/* 102 */         IConfigurationElement[] ce = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 103 */         for (j = (arrayOfIConfigurationElement1 = ce).length, b1 = 0; b1 < j; ) { IConfigurationElement ce1 = arrayOfIConfigurationElement1[b1];
/* 104 */           displayConfigElement(ci, ce1, 1); b1++; }
/*     */         
/* 106 */         ci.println();
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object _help(CommandInterpreter intp) {
/* 118 */     String commandName = intp.nextArgument();
/* 119 */     if (commandName == null) {
/* 120 */       return Boolean.FALSE;
/*     */     }
/* 122 */     String help = getHelp(commandName);
/*     */     
/* 124 */     if (help.length() > 0) {
/* 125 */       return help;
/*     */     }
/*     */     
/* 128 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getArgument(CommandInterpreter ci) {
/* 133 */     String firstParm = ci.nextArgument();
/* 134 */     if ("-v".equals(firstParm)) {
/* 135 */       this.verbose = true;
/* 136 */       return ci.nextArgument();
/*     */     } 
/*     */     
/* 139 */     this.verbose = false;
/* 140 */     return firstParm;
/*     */   }
/*     */   
/*     */   private void displayExtensionPoint(IExtensionPoint extentionPoint, CommandInterpreter ci) {
/* 144 */     if (extentionPoint == null)
/*     */       return; 
/* 146 */     ci.println(String.valueOf(extentionPoint.getUniqueIdentifier()) + " [from " + extentionPoint.getContributor().getName() + ']');
/*     */   }
/*     */   
/*     */   private void displayExtension(IExtension extention, CommandInterpreter ci, boolean full) {
/* 150 */     if (extention == null)
/*     */       return; 
/* 152 */     if (full) {
/* 153 */       ci.print("Id: " + extention.getUniqueIdentifier());
/* 154 */       ci.print(" PointId: " + extention.getExtensionPointUniqueIdentifier());
/* 155 */       ci.println(" [from " + extention.getContributor().getName() + "]");
/*     */     } else {
/* 157 */       ci.println(String.valueOf(extention.getUniqueIdentifier()) + " [from " + extention.getContributor().getName() + "]");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void displayConfigElement(CommandInterpreter ci, IConfigurationElement ce, int level) throws Exception {
/* 162 */     String spacing = spacing(ci, level);
/* 163 */     ci.println(String.valueOf(spacing) + '<' + ce.getName() + '>');
/* 164 */     String[] attrs = ce.getAttributeNames(); byte b1; int i; String[] arrayOfString1;
/* 165 */     for (i = (arrayOfString1 = attrs).length, b1 = 0; b1 < i; ) { String attr = arrayOfString1[b1];
/* 166 */       ci.println("   " + spacing + attr + " = " + ce.getAttribute(attr)); b1++; }
/*     */     
/* 168 */     String value = ce.getValue();
/* 169 */     if (value != null)
/* 170 */       ci.println("   " + spacing + value); 
/* 171 */     IConfigurationElement[] children = ce.getChildren(); byte b2; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 172 */     for (j = (arrayOfIConfigurationElement1 = children).length, b2 = 0; b2 < j; ) { IConfigurationElement child = arrayOfIConfigurationElement1[b2];
/* 173 */       displayConfigElement(ci, child, level + 1); b2++; }
/*     */     
/* 175 */     ci.println(String.valueOf(spacing) + "</" + ce.getName() + '>');
/*     */   }
/*     */   
/*     */   private String spacing(CommandInterpreter ci, int level) {
/* 179 */     StringBuilder b = new StringBuilder();
/* 180 */     for (int i = 0; i < level; i++)
/* 181 */       b.append("   "); 
/* 182 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\RegistryCommandProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */