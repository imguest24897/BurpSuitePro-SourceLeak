/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectMap
/*     */ {
/*     */   private final float growthFactor;
/*     */   private String[] keyArray;
/*     */   private String[][] valueArray;
/*     */   private int size;
/*     */   
/*     */   public DirectMap(int initialSize, float growthFactor) {
/*  32 */     if (initialSize < 1)
/*  33 */       throw new IllegalArgumentException(); 
/*  34 */     if (growthFactor <= 0.0F)
/*  35 */       throw new IllegalArgumentException(); 
/*  36 */     this.growthFactor = growthFactor;
/*  37 */     this.keyArray = new String[initialSize];
/*  38 */     this.valueArray = new String[initialSize][];
/*  39 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public synchronized void put(String key, String[] value) {
/*  43 */     if (key == null)
/*  44 */       throw new IllegalArgumentException(); 
/*  45 */     int id = findKey(key);
/*  46 */     if (id != -1) {
/*  47 */       throw new IllegalArgumentException();
/*     */     }
/*  49 */     if (this.size >= this.keyArray.length) {
/*  50 */       int newSize = recalcSize(this.keyArray.length);
/*  51 */       if (newSize <= this.size) {
/*  52 */         newSize = this.size + 1;
/*     */       }
/*  54 */       String[] newKeyArray = new String[newSize];
/*  55 */       System.arraycopy(this.keyArray, 0, newKeyArray, 0, this.keyArray.length);
/*  56 */       this.keyArray = newKeyArray;
/*     */       
/*  58 */       String[][] newValueArray = new String[newSize][];
/*  59 */       System.arraycopy(this.valueArray, 0, newValueArray, 0, this.valueArray.length);
/*  60 */       this.valueArray = newValueArray;
/*     */     } 
/*  62 */     this.keyArray[this.size] = key;
/*  63 */     this.valueArray[this.size] = value;
/*  64 */     this.size++;
/*     */   }
/*     */   
/*     */   public synchronized boolean containsKey(String key) {
/*  68 */     if (key == null)
/*  69 */       throw new IllegalArgumentException(); 
/*  70 */     return (findKey(key) != -1);
/*     */   }
/*     */   
/*     */   public synchronized String[] get(String key) {
/*  74 */     if (key == null)
/*  75 */       throw new IllegalArgumentException(); 
/*  76 */     int id = findKey(key);
/*  77 */     if (id == -1)
/*  78 */       return null; 
/*  79 */     return this.valueArray[id];
/*     */   }
/*     */   
/*     */   String[] getKeys() {
/*  83 */     return this.keyArray;
/*     */   }
/*     */   
/*     */   String[][] getValues() {
/*  87 */     return this.valueArray;
/*     */   }
/*     */   
/*     */   int getSzie() {
/*  91 */     return this.size;
/*     */   }
/*     */   
/*     */   private int recalcSize(int currentSize) {
/*  95 */     return (int)(currentSize * (1.0F + this.growthFactor));
/*     */   }
/*     */   
/*     */   private int findKey(String key) {
/*  99 */     for (int i = 0; i < this.keyArray.length; i++) {
/* 100 */       if (this.keyArray[i] != null)
/*     */       {
/* 102 */         if (this.keyArray[i].equals(key))
/* 103 */           return i;  } 
/*     */     } 
/* 105 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\DirectMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */