/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HashtableOfStringAndInt
/*     */   implements Cloneable
/*     */ {
/*     */   public static final int MISSING_ELEMENT = -2147483648;
/*     */   private String[] keyTable;
/*     */   private int[] valueTable;
/*     */   private int elementSize;
/*     */   private int threshold;
/*     */   private static final float GROWTH_FACTOR = 1.33F;
/*     */   private static final byte NULL = 0;
/*     */   private static final byte OBJECT = 1;
/*     */   
/*     */   public HashtableOfStringAndInt() {
/*  33 */     this(13);
/*     */   }
/*     */   
/*     */   public HashtableOfStringAndInt(int size) {
/*  37 */     this.elementSize = 0;
/*  38 */     this.threshold = size;
/*  39 */     int extraRoom = (int)(size * 1.75F);
/*  40 */     if (this.threshold == extraRoom)
/*  41 */       extraRoom++; 
/*  42 */     this.keyTable = new String[extraRoom];
/*  43 */     this.valueTable = new int[extraRoom];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*  48 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/*  64 */     int index = (key.hashCode() & Integer.MAX_VALUE) % this.valueTable.length;
/*  65 */     int keyLength = key.length();
/*     */     String currentKey;
/*  67 */     while ((currentKey = this.keyTable[index]) != null) {
/*  68 */       if (currentKey.length() == keyLength && currentKey.equals(key))
/*  69 */         return true; 
/*  70 */       index = (index + 1) % this.keyTable.length;
/*     */     } 
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public int get(String key) {
/*  76 */     int index = (key.hashCode() & Integer.MAX_VALUE) % this.valueTable.length;
/*  77 */     int keyLength = key.length();
/*     */     String currentKey;
/*  79 */     while ((currentKey = this.keyTable[index]) != null) {
/*  80 */       if (currentKey.length() == keyLength && currentKey.equals(key))
/*  81 */         return this.valueTable[index]; 
/*  82 */       index = (index + 1) % this.keyTable.length;
/*     */     } 
/*  84 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public int put(String key, int value) {
/*  88 */     int index = (key.hashCode() & Integer.MAX_VALUE) % this.valueTable.length;
/*  89 */     int keyLength = key.length();
/*     */     String currentKey;
/*  91 */     while ((currentKey = this.keyTable[index]) != null) {
/*  92 */       if (currentKey.length() == keyLength && currentKey.equals(key)) {
/*  93 */         this.valueTable[index] = value; return value;
/*  94 */       }  index = (index + 1) % this.keyTable.length;
/*     */     } 
/*  96 */     this.keyTable[index] = key;
/*  97 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/* 100 */     if (++this.elementSize > this.threshold)
/* 101 */       rehash(); 
/* 102 */     return value;
/*     */   }
/*     */   
/*     */   public int removeKey(String key) {
/* 106 */     int index = (key.hashCode() & Integer.MAX_VALUE) % this.valueTable.length;
/* 107 */     int keyLength = key.length();
/*     */     String currentKey;
/* 109 */     while ((currentKey = this.keyTable[index]) != null) {
/* 110 */       if (currentKey.length() == keyLength && currentKey.equals(key)) {
/* 111 */         int value = this.valueTable[index];
/* 112 */         this.elementSize--;
/* 113 */         this.keyTable[index] = null;
/* 114 */         this.valueTable[index] = Integer.MIN_VALUE;
/* 115 */         rehash();
/* 116 */         return value;
/*     */       } 
/* 118 */       index = (index + 1) % this.keyTable.length;
/*     */     } 
/* 120 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   private void rehash() {
/* 124 */     HashtableOfStringAndInt newHashtable = new HashtableOfStringAndInt((int)(this.elementSize * 1.33F));
/*     */     
/* 126 */     for (int i = this.keyTable.length; --i >= 0;) {
/* 127 */       if ((currentKey = this.keyTable[i]) != null)
/* 128 */         newHashtable.put(currentKey, this.valueTable[i]); 
/*     */     } 
/* 130 */     this.keyTable = newHashtable.keyTable;
/* 131 */     this.valueTable = newHashtable.valueTable;
/* 132 */     this.threshold = newHashtable.threshold;
/*     */   }
/*     */   
/*     */   public int size() {
/* 136 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     String s = "";
/*     */     
/* 143 */     for (int i = 0, length = this.valueTable.length; i < length; i++) {
/* 144 */       int object; if ((object = this.valueTable[i]) != Integer.MIN_VALUE)
/* 145 */         s = String.valueOf(s) + new String(this.keyTable[i]) + " -> " + object + "\n"; 
/* 146 */     }  return s;
/*     */   }
/*     */   
/*     */   public int[] getValues() {
/* 150 */     int keyTableLength = this.keyTable.length;
/* 151 */     int[] result = new int[size()];
/* 152 */     int j = 0;
/* 153 */     for (int i = 0; i < keyTableLength; i++) {
/* 154 */       if (this.keyTable[i] != null)
/* 155 */         result[j++] = this.valueTable[i]; 
/*     */     } 
/* 157 */     return result;
/*     */   }
/*     */   
/*     */   public void save(DataOutputStream out) throws IOException {
/* 161 */     out.writeInt(this.elementSize);
/* 162 */     int tableSize = this.keyTable.length;
/* 163 */     out.writeInt(tableSize);
/* 164 */     out.writeInt(this.threshold);
/* 165 */     for (int i = 0; i < tableSize; i++) {
/* 166 */       writeStringOrNull(this.keyTable[i], out);
/* 167 */       out.writeInt(this.valueTable[i]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(DataOutputStream out, RegistryObjectManager objectManager) throws IOException {
/* 175 */     HashtableOfStringAndInt filteredHashtable = new HashtableOfStringAndInt((int)(this.elementSize * 1.33F));
/*     */     
/* 177 */     for (int i = this.keyTable.length; --i >= 0;) {
/* 178 */       if ((currentKey = this.keyTable[i]) != null && objectManager.shouldPersist(this.valueTable[i]))
/* 179 */         filteredHashtable.put(currentKey, this.valueTable[i]); 
/* 180 */     }  filteredHashtable.save(out);
/*     */   }
/*     */   
/*     */   public void load(DataInputStream in) throws IOException {
/* 184 */     this.elementSize = in.readInt();
/* 185 */     int tableSize = in.readInt();
/* 186 */     this.threshold = in.readInt();
/* 187 */     boolean fastMode = true;
/* 188 */     if (tableSize / this.elementSize < 1.3300000429153442D) {
/* 189 */       this.keyTable = new String[(int)(this.elementSize * 1.33F)];
/* 190 */       this.valueTable = new int[(int)(this.elementSize * 1.33F)];
/* 191 */       this.elementSize = 0;
/* 192 */       fastMode = false;
/*     */     } else {
/* 194 */       this.keyTable = new String[tableSize];
/* 195 */       this.valueTable = new int[tableSize];
/*     */     } 
/* 197 */     for (int i = 0; i < tableSize; i++) {
/* 198 */       String key = readStringOrNull(in);
/* 199 */       int value = in.readInt();
/* 200 */       if (fastMode) {
/* 201 */         this.keyTable[i] = key;
/* 202 */         this.valueTable[i] = value;
/*     */       }
/* 204 */       else if (key != null) {
/* 205 */         put(key, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeStringOrNull(String string, DataOutputStream out) throws IOException {
/* 214 */     if (string == null) {
/* 215 */       out.writeByte(0);
/*     */     } else {
/* 217 */       out.writeByte(1);
/* 218 */       out.writeUTF(string);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String readStringOrNull(DataInputStream in) throws IOException {
/* 223 */     byte type = in.readByte();
/* 224 */     if (type == 0)
/* 225 */       return null; 
/* 226 */     return in.readUTF();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\HashtableOfStringAndInt.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */