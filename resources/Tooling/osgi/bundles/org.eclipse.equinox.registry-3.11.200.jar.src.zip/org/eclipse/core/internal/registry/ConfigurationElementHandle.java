/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationElementHandle
/*     */   extends Handle
/*     */   implements IConfigurationElement
/*     */ {
/*  22 */   static final ConfigurationElementHandle[] EMPTY_ARRAY = new ConfigurationElementHandle[0];
/*     */   
/*     */   public ConfigurationElementHandle(IObjectManager objectManager, int id) {
/*  25 */     super(objectManager, id);
/*     */   }
/*     */   
/*     */   protected ConfigurationElement getConfigurationElement() {
/*  29 */     return (ConfigurationElement)this.objectManager.getObject(getId(), (byte)1);
/*     */   }
/*     */   
/*     */   protected boolean shouldPersist() {
/*  33 */     return getConfigurationElement().shouldPersist();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(String propertyName) {
/*  38 */     return getConfigurationElement().getAttribute(propertyName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(String attrName, String locale) {
/*  43 */     return getConfigurationElement().getAttribute(attrName, locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAttributeNames() {
/*  48 */     return getConfigurationElement().getAttributeNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public IConfigurationElement[] getChildren() {
/*  53 */     ConfigurationElement actualCe = getConfigurationElement();
/*  54 */     if (actualCe.noExtraData()) {
/*  55 */       return (IConfigurationElement[])this.objectManager.getHandles(actualCe.getRawChildren(), (byte)1);
/*     */     }
/*  57 */     return (IConfigurationElement[])this.objectManager.getHandles(actualCe.getRawChildren(), (byte)4);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object createExecutableExtension(String propertyName) throws CoreException {
/*     */     try {
/*  63 */       return getConfigurationElement().createExecutableExtension(propertyName);
/*  64 */     } catch (InvalidRegistryObjectException e) {
/*  65 */       Status status = new Status(4, "org.eclipse.equinox.registry", 1, "Invalid registry object", (Throwable)e);
/*  66 */       if (this.objectManager instanceof RegistryObjectManager)
/*  67 */         ((RegistryObjectManager)this.objectManager).getRegistry().log((IStatus)status); 
/*  68 */       throw new CoreException(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeAsIs(String name) {
/*  74 */     return getConfigurationElement().getAttributeAsIs(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public IConfigurationElement[] getChildren(String name) {
/*  79 */     ConfigurationElement actualCE = getConfigurationElement();
/*  80 */     ConfigurationElement[] children = (ConfigurationElement[])this.objectManager.getObjects(actualCE.getRawChildren(), actualCE.noExtraData() ? 1 : 4);
/*  81 */     if (children.length == 0) {
/*  82 */       return (IConfigurationElement[])EMPTY_ARRAY;
/*     */     }
/*  84 */     IConfigurationElement[] result = new IConfigurationElement[1];
/*  85 */     int idx = 0; byte b; int i; ConfigurationElement[] arrayOfConfigurationElement1;
/*  86 */     for (i = (arrayOfConfigurationElement1 = children).length, b = 0; b < i; ) { ConfigurationElement child = arrayOfConfigurationElement1[b];
/*  87 */       if (child.getName().equals(name)) {
/*  88 */         if (idx != 0) {
/*  89 */           IConfigurationElement[] copy = new IConfigurationElement[result.length + 1];
/*  90 */           System.arraycopy(result, 0, copy, 0, result.length);
/*  91 */           result = copy;
/*     */         } 
/*  93 */         result[idx++] = (IConfigurationElement)this.objectManager.getHandle(child.getObjectId(), actualCE.noExtraData() ? 1 : 4);
/*     */       }  b++; }
/*     */     
/*  96 */     if (idx == 0)
/*  97 */       return (IConfigurationElement[])EMPTY_ARRAY; 
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IExtension getDeclaringExtension() {
/* 103 */     Object result = this; do {  }
/* 104 */     while (!(result = ((ConfigurationElementHandle)result).getParent() instanceof ExtensionHandle));
/*     */     
/* 106 */     return (IExtension)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 111 */     return getConfigurationElement().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getParent() {
/* 116 */     ConfigurationElement actualCe = getConfigurationElement();
/* 117 */     return this.objectManager.getHandle(actualCe.parentId, actualCe.parentType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 122 */     return getConfigurationElement().getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(String locale) {
/* 127 */     return getConfigurationElement().getValue(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValueAsIs() {
/* 132 */     return getConfigurationElement().getValueAsIs();
/*     */   }
/*     */ 
/*     */   
/*     */   RegistryObject getObject() {
/* 137 */     return getConfigurationElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/* 143 */     return getContributor().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceIdentifier() {
/* 149 */     return getDeclaringExtension().getNamespaceIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContributor getContributor() {
/* 154 */     return getConfigurationElement().getContributor();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/*     */     try {
/* 160 */       getConfigurationElement();
/* 161 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/* 162 */       return false;
/*     */     } 
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHandleId() {
/* 169 */     return getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 181 */     StringBuilder sb = new StringBuilder();
/* 182 */     sb.append("ConfigurationElementHandle [");
/* 183 */     sb.append("name: ");
/* 184 */     sb.append(getName());
/* 185 */     String id = getAttribute("id");
/* 186 */     if (id != null && id.length() > 0) {
/* 187 */       sb.append(", id: ").append(id);
/*     */     }
/* 189 */     String value = getValue();
/* 190 */     if (value != null) {
/* 191 */       sb.append(", value: ").append(value);
/*     */     }
/* 193 */     sb.append(", handle id: ").append(getHandleId());
/* 194 */     sb.append(", namespace: ");
/* 195 */     sb.append(getNamespaceIdentifier());
/* 196 */     sb.append("]");
/* 197 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ConfigurationElementHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */