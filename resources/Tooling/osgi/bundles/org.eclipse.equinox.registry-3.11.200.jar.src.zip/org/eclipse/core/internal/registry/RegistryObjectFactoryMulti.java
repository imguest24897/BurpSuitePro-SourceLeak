/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryObjectFactoryMulti
/*    */   extends RegistryObjectFactory
/*    */ {
/*    */   public RegistryObjectFactoryMulti(ExtensionRegistry registry) {
/* 23 */     super(registry);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtensionPoint createExtensionPoint(boolean persist) {
/* 28 */     return new ExtensionPointMulti(this.registry, persist);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtensionPoint createExtensionPoint(int self, int[] children, int dataOffset, boolean persist) {
/* 33 */     return new ExtensionPointMulti(self, children, dataOffset, this.registry, persist);
/*    */   }
/*    */ 
/*    */   
/*    */   public Extension createExtension(boolean persist) {
/* 38 */     return new ExtensionMulti(this.registry, persist);
/*    */   }
/*    */ 
/*    */   
/*    */   public Extension createExtension(int self, String simpleId, String namespace, int[] children, int extraData, boolean persist) {
/* 43 */     return new ExtensionMulti(self, simpleId, namespace, children, extraData, this.registry, persist);
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationElement createConfigurationElement(boolean persist) {
/* 48 */     return new ConfigurationElementMulti(this.registry, persist);
/*    */   }
/*    */ 
/*    */   
/*    */   public ConfigurationElement createConfigurationElement(int self, String contributorId, String name, String[] propertiesAndValue, int[] children, int extraDataOffset, int parent, byte parentType, boolean persist) {
/* 53 */     return new ConfigurationElementMulti(self, contributorId, name, propertiesAndValue, children, extraDataOffset, parent, parentType, this.registry, persist);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryObjectFactoryMulti.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */