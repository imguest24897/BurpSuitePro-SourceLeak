/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryProperties
/*    */ {
/*    */   public static final String empty = "";
/* 27 */   private static Properties registryProperties = new Properties();
/* 28 */   private static Object context = null;
/*    */   
/*    */   public static void setContext(Object object) {
/* 31 */     context = object;
/*    */   }
/*    */   
/*    */   public static String getProperty(String propertyName) {
/* 35 */     String propertyValue = registryProperties.getProperty(propertyName);
/* 36 */     if (propertyValue != null) {
/* 37 */       return propertyValue;
/*    */     }
/* 39 */     return getContextProperty(propertyName);
/*    */   }
/*    */   
/*    */   public static String getProperty(String property, String defaultValue) {
/* 43 */     String result = getProperty(property);
/* 44 */     return (result == null) ? defaultValue : result;
/*    */   }
/*    */   
/*    */   public static void setProperty(String propertyName, String propertyValue) {
/* 48 */     registryProperties.setProperty(propertyName, propertyValue);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getContextProperty(String propertyName) {
/* 55 */     if (context == null) {
/* 56 */       return System.getProperty(propertyName);
/*    */     }
/* 58 */     String[] result = new String[1];
/*    */ 
/*    */     
/*    */     try {
/* 62 */       Runnable innerClass = () -> {
/*    */           BundleContext bundleContext = (BundleContext)context;
/*    */           paramArrayOfString[0] = bundleContext.getProperty(paramString);
/*    */         };
/* 66 */       innerClass.run();
/* 67 */     } catch (Exception e) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 72 */       Status status = new Status(4, "org.eclipse.core.runtime", 0, e.getMessage(), e);
/* 73 */       RuntimeLog.log((IStatus)status);
/* 74 */       return null;
/*    */     } 
/* 76 */     return result[0];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryProperties.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */