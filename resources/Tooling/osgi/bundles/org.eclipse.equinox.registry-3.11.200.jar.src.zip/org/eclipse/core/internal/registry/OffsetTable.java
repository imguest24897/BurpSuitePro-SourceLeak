/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OffsetTable
/*    */ {
/*    */   private static final float GROWTH_FACTOR = 1.33F;
/*    */   private int[] valueTable;
/*    */   
/*    */   public OffsetTable(int size) {
/* 29 */     this.valueTable = new int[size];
/*    */   }
/*    */   
/*    */   public int get(int key) {
/* 33 */     if (key < this.valueTable.length)
/* 34 */       return this.valueTable[key]; 
/* 35 */     return Integer.MIN_VALUE;
/*    */   }
/*    */   
/*    */   public void removeKey(int key) {
/* 39 */     if (key < this.valueTable.length)
/* 40 */       this.valueTable[key] = Integer.MIN_VALUE; 
/*    */   }
/*    */   
/*    */   public void put(int key, int value) {
/* 44 */     if (key >= this.valueTable.length) {
/* 45 */       int[] newTable = new int[(int)(key * 1.33F)];
/* 46 */       System.arraycopy(this.valueTable, 0, newTable, 0, this.valueTable.length);
/* 47 */       this.valueTable = newTable;
/*    */     } 
/* 49 */     this.valueTable[key] = value;
/*    */   }
/*    */   
/*    */   public void save(DataOutputStream out) throws IOException {
/* 53 */     int tableSize = this.valueTable.length;
/* 54 */     out.writeInt(tableSize);
/* 55 */     for (int i = 0; i < tableSize; i++) {
/* 56 */       out.writeInt(this.valueTable[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   public static OffsetTable load(DataInputStream in) throws IOException {
/* 61 */     int tableSize = in.readInt();
/* 62 */     OffsetTable result = new OffsetTable(tableSize);
/* 63 */     result.valueTable = new int[tableSize];
/* 64 */     for (int i = 0; i < tableSize; i++)
/* 65 */       result.valueTable[i] = in.readInt(); 
/* 66 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\OffsetTable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */