/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ 
/*     */ 
/*     */ public class TableWriter
/*     */ {
/*     */   private static final byte fileError = 0;
/*     */   File mainDataFile;
/*     */   File extraDataFile;
/*     */   File tableFile;
/*     */   File contributionsFile;
/*     */   File contributorsFile;
/*     */   File namespacesFile;
/*     */   File orphansFile;
/*     */   DataOutputStream mainOutput;
/*     */   DataOutputStream extraOutput;
/*     */   
/*     */   void setMainDataFile(File main) {
/*  35 */     this.mainDataFile = main;
/*     */   }
/*     */   
/*     */   void setExtraDataFile(File extra) {
/*  39 */     this.extraDataFile = extra;
/*     */   }
/*     */   
/*     */   void setTableFile(File table) {
/*  43 */     this.tableFile = table;
/*     */   }
/*     */   
/*     */   void setContributionsFile(File fileName) {
/*  47 */     this.contributionsFile = fileName;
/*     */   }
/*     */   
/*     */   void setContributorsFile(File fileName) {
/*  51 */     this.contributorsFile = fileName;
/*     */   }
/*     */   
/*     */   void setNamespacesFile(File fileName) {
/*  55 */     this.namespacesFile = fileName;
/*     */   }
/*     */   
/*     */   void setOrphansFile(File orphan) {
/*  59 */     this.orphansFile = orphan;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  64 */   FileOutputStream mainFileOutput = null;
/*  65 */   FileOutputStream extraFileOutput = null;
/*     */   
/*     */   private OffsetTable offsets;
/*     */   
/*     */   private final ExtensionRegistry registry;
/*     */   private RegistryObjectManager objectManager;
/*     */   
/*     */   public TableWriter(ExtensionRegistry registry) {
/*  73 */     this.registry = registry;
/*     */   }
/*     */   
/*     */   private int getExtraDataPosition() {
/*  77 */     return this.extraOutput.size();
/*     */   }
/*     */   
/*     */   public boolean saveCache(RegistryObjectManager objectManager, long timestamp) {
/*  81 */     this.objectManager = objectManager;
/*     */     
/*  83 */     try { if (!openFiles()) {
/*  84 */         return false;
/*     */       
/*     */       }
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*  92 */       closeFiles(); }  closeFiles();
/*     */     
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   private boolean openFiles() {
/*     */     try {
/*  99 */       this.mainFileOutput = new FileOutputStream(this.mainDataFile);
/* 100 */       this.mainOutput = new DataOutputStream(new BufferedOutputStream(this.mainFileOutput));
/* 101 */       this.extraFileOutput = new FileOutputStream(this.extraDataFile);
/* 102 */       this.extraOutput = new DataOutputStream(new BufferedOutputStream(this.extraFileOutput));
/* 103 */     } catch (FileNotFoundException e) {
/* 104 */       if (this.mainFileOutput != null) {
/*     */         try {
/* 106 */           this.mainFileOutput.close();
/* 107 */         } catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 111 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_unableToCreateCache, e));
/* 112 */       return false;
/*     */     } 
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   private void closeFiles() {
/*     */     try {
/* 119 */       if (this.mainOutput != null) {
/* 120 */         this.mainOutput.flush();
/* 121 */         if (this.mainFileOutput.getFD().valid()) {
/* 122 */           this.mainFileOutput.getFD().sync();
/*     */         }
/* 124 */         this.mainOutput.close();
/*     */       } 
/* 126 */     } catch (IOException e) {
/* 127 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_registryCacheWriteProblems, e));
/* 128 */       e.printStackTrace();
/*     */     } 
/*     */     try {
/* 131 */       if (this.extraOutput != null) {
/* 132 */         this.extraOutput.flush();
/* 133 */         if (this.extraFileOutput.getFD().valid()) {
/* 134 */           this.extraFileOutput.getFD().sync();
/*     */         }
/* 136 */         this.extraOutput.close();
/*     */       } 
/* 138 */     } catch (IOException e) {
/* 139 */       log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.meta_registryCacheWriteProblems, e));
/* 140 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void saveExtensionRegistry(long timestamp) throws IOException {
/* 145 */     ExtensionPointHandle[] points = this.objectManager.getExtensionPointsHandles();
/* 146 */     this.offsets = new OffsetTable(this.objectManager.getNextId()); byte b; int i; ExtensionPointHandle[] arrayOfExtensionPointHandle1;
/* 147 */     for (i = (arrayOfExtensionPointHandle1 = points).length, b = 0; b < i; ) { ExtensionPointHandle point = arrayOfExtensionPointHandle1[b];
/* 148 */       saveExtensionPoint(point); b++; }
/*     */     
/* 150 */     saveOrphans();
/* 151 */     saveContributions(this.objectManager.getContributions());
/* 152 */     saveContributors(this.objectManager.getContributors());
/* 153 */     saveNamespaces(this.objectManager.getNamespacesIndex());
/* 154 */     closeFiles();
/* 155 */     saveTables(timestamp);
/*     */   }
/*     */   
/*     */   private void saveContributions(KeyedHashSet[] contributions) throws IOException {
/* 159 */     FileOutputStream fosNamespace = new FileOutputStream(this.contributionsFile);
/* 160 */     DataOutputStream outputNamespace = new DataOutputStream(new BufferedOutputStream(fosNamespace));
/* 161 */     KeyedElement[] newElements = contributions[0].elements();
/* 162 */     KeyedElement[] formerElements = contributions[1].elements();
/*     */ 
/*     */     
/* 165 */     int cacheSize = 0; byte b; int i; KeyedElement[] arrayOfKeyedElement1;
/* 166 */     for (i = (arrayOfKeyedElement1 = newElements).length, b = 0; b < i; ) { KeyedElement newElement = arrayOfKeyedElement1[b];
/* 167 */       if (((Contribution)newElement).shouldPersist())
/* 168 */         cacheSize++; 
/*     */       b++; }
/*     */     
/* 171 */     for (i = (arrayOfKeyedElement1 = formerElements).length, b = 0; b < i; ) { KeyedElement formerElement = arrayOfKeyedElement1[b];
/* 172 */       if (((Contribution)formerElement).shouldPersist())
/* 173 */         cacheSize++; 
/*     */       b++; }
/*     */     
/* 176 */     outputNamespace.writeInt(cacheSize);
/*     */     
/* 178 */     for (i = (arrayOfKeyedElement1 = newElements).length, b = 0; b < i; ) { KeyedElement newElement = arrayOfKeyedElement1[b];
/* 179 */       Contribution element = (Contribution)newElement;
/* 180 */       if (element.shouldPersist()) {
/* 181 */         writeStringOrNull(element.getContributorId(), outputNamespace);
/* 182 */         saveArray(filterContributionChildren(element), outputNamespace);
/*     */       }  b++; }
/*     */     
/* 185 */     for (i = (arrayOfKeyedElement1 = formerElements).length, b = 0; b < i; ) { KeyedElement formerElement = arrayOfKeyedElement1[b];
/* 186 */       Contribution element = (Contribution)formerElement;
/* 187 */       if (element.shouldPersist()) {
/* 188 */         writeStringOrNull(element.getContributorId(), outputNamespace);
/* 189 */         saveArray(filterContributionChildren(element), outputNamespace);
/*     */       }  b++; }
/*     */     
/* 192 */     outputNamespace.flush();
/* 193 */     fosNamespace.getFD().sync();
/* 194 */     outputNamespace.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] filterContributionChildren(Contribution element) {
/* 200 */     int[] extensionPoints = filter(element.getExtensionPoints());
/* 201 */     int[] extensions = filter(element.getExtensions());
/* 202 */     int[] filteredRawChildren = new int[2 + extensionPoints.length + extensions.length];
/* 203 */     System.arraycopy(extensionPoints, 0, filteredRawChildren, 2, extensionPoints.length);
/* 204 */     System.arraycopy(extensions, 0, filteredRawChildren, 2 + extensionPoints.length, extensions.length);
/* 205 */     filteredRawChildren[0] = extensionPoints.length;
/* 206 */     filteredRawChildren[1] = extensions.length;
/* 207 */     return filteredRawChildren;
/*     */   }
/*     */   
/*     */   private void saveNamespaces(KeyedHashSet namespacesIndex) throws IOException {
/* 211 */     FileOutputStream fosNamespace = new FileOutputStream(this.namespacesFile);
/* 212 */     DataOutputStream outputNamespace = new DataOutputStream(new BufferedOutputStream(fosNamespace));
/* 213 */     KeyedElement[] elements = namespacesIndex.elements();
/*     */     
/* 215 */     KeyedElement[] cachedElements = new KeyedElement[elements.length];
/* 216 */     int cacheSize = 0; byte b; int j; KeyedElement[] arrayOfKeyedElement1;
/* 217 */     for (j = (arrayOfKeyedElement1 = elements).length, b = 0; b < j; ) { KeyedElement e = arrayOfKeyedElement1[b];
/* 218 */       RegistryIndexElement element = (RegistryIndexElement)e;
/* 219 */       int[] extensionPoints = filter(element.getExtensionPoints());
/* 220 */       int[] extensions = filter(element.getExtensions());
/* 221 */       if (extensionPoints.length != 0 || extensions.length != 0) {
/*     */         
/* 223 */         RegistryIndexElement cachedElement = new RegistryIndexElement((String)element.getKey(), extensionPoints, extensions);
/* 224 */         cachedElements[cacheSize] = cachedElement;
/* 225 */         cacheSize++;
/*     */       }  b++; }
/*     */     
/* 228 */     outputNamespace.writeInt(cacheSize);
/* 229 */     for (int i = 0; i < cacheSize; i++) {
/* 230 */       RegistryIndexElement element = (RegistryIndexElement)cachedElements[i];
/* 231 */       writeStringOrNull((String)element.getKey(), outputNamespace);
/* 232 */       saveArray(element.getExtensionPoints(), outputNamespace);
/* 233 */       saveArray(element.getExtensions(), outputNamespace);
/*     */     } 
/* 235 */     outputNamespace.flush();
/* 236 */     fosNamespace.getFD().sync();
/* 237 */     outputNamespace.close();
/*     */   }
/*     */   
/*     */   private void saveContributors(HashMap<?, ?> contributors) throws IOException {
/* 241 */     FileOutputStream fosContributors = new FileOutputStream(this.contributorsFile);
/* 242 */     DataOutputStream outputContributors = new DataOutputStream(new BufferedOutputStream(fosContributors));
/*     */     
/* 244 */     Collection<?> entries = contributors.values();
/* 245 */     outputContributors.writeInt(entries.size());
/*     */     
/* 247 */     for (Object entry : entries) {
/* 248 */       RegistryContributor contributor = (RegistryContributor)entry;
/* 249 */       writeStringOrNull(contributor.getActualId(), outputContributors);
/* 250 */       writeStringOrNull(contributor.getActualName(), outputContributors);
/* 251 */       writeStringOrNull(contributor.getId(), outputContributors);
/* 252 */       writeStringOrNull(contributor.getName(), outputContributors);
/*     */     } 
/*     */     
/* 255 */     outputContributors.flush();
/* 256 */     fosContributors.getFD().sync();
/* 257 */     outputContributors.close();
/*     */   }
/*     */   
/*     */   private void saveTables(long registryTimeStamp) throws IOException {
/* 261 */     FileOutputStream fosTable = new FileOutputStream(this.tableFile);
/* 262 */     DataOutputStream outputTable = new DataOutputStream(new BufferedOutputStream(fosTable));
/* 263 */     writeCacheHeader(outputTable, registryTimeStamp);
/* 264 */     outputTable.writeInt(this.objectManager.getNextId());
/* 265 */     this.offsets.save(outputTable);
/* 266 */     this.objectManager.getExtensionPoints().save(outputTable, this.objectManager);
/* 267 */     outputTable.flush();
/* 268 */     fosTable.getFD().sync();
/* 269 */     outputTable.close();
/*     */   }
/*     */   
/*     */   private void writeCacheHeader(DataOutputStream output, long registryTimeStamp) throws IOException {
/* 273 */     output.writeInt(8);
/* 274 */     output.writeLong(this.registry.computeState());
/* 275 */     output.writeLong(registryTimeStamp);
/* 276 */     output.writeLong(this.mainDataFile.length());
/* 277 */     output.writeLong(this.extraDataFile.length());
/* 278 */     output.writeLong(this.contributionsFile.length());
/* 279 */     output.writeLong(this.contributorsFile.length());
/* 280 */     output.writeLong(this.namespacesFile.length());
/* 281 */     output.writeLong(this.orphansFile.length());
/* 282 */     output.writeUTF(RegistryProperties.getProperty("osgi.os", ""));
/* 283 */     output.writeUTF(RegistryProperties.getProperty("osgi.ws", ""));
/* 284 */     output.writeUTF(RegistryProperties.getProperty("osgi.nl", ""));
/* 285 */     output.writeBoolean(this.registry.isMultiLanguage());
/*     */   }
/*     */   
/*     */   private void saveArray(int[] array, DataOutputStream out) throws IOException {
/* 289 */     if (array == null) {
/* 290 */       out.writeInt(0);
/*     */       return;
/*     */     } 
/* 293 */     out.writeInt(array.length); byte b; int i, arrayOfInt[];
/* 294 */     for (i = (arrayOfInt = array).length, b = 0; b < i; ) { int element = arrayOfInt[b];
/* 295 */       out.writeInt(element);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void saveExtensionPoint(ExtensionPointHandle xpt) throws IOException {
/* 300 */     if (!xpt.shouldPersist()) {
/*     */       return;
/*     */     }
/* 303 */     this.offsets.put(xpt.getId(), this.mainOutput.size());
/*     */     
/* 305 */     this.mainOutput.writeInt(xpt.getId());
/* 306 */     saveArray(filter(xpt.getObject().getRawChildren()), this.mainOutput);
/* 307 */     this.mainOutput.writeInt(getExtraDataPosition());
/* 308 */     saveExtensionPointData(xpt);
/*     */     
/* 310 */     saveExtensions(xpt.getExtensions(), this.mainOutput);
/*     */   }
/*     */   
/*     */   private void saveExtension(ExtensionHandle ext, DataOutputStream outputStream) throws IOException {
/* 314 */     if (!ext.shouldPersist())
/*     */       return; 
/* 316 */     this.offsets.put(ext.getId(), outputStream.size());
/* 317 */     outputStream.writeInt(ext.getId());
/* 318 */     writeStringOrNull(ext.getSimpleIdentifier(), outputStream);
/* 319 */     writeStringOrNull(ext.getNamespaceIdentifier(), outputStream);
/* 320 */     saveArray(filter(ext.getObject().getRawChildren()), outputStream);
/* 321 */     outputStream.writeInt(getExtraDataPosition());
/* 322 */     saveExtensionData(ext);
/*     */   }
/*     */   
/*     */   private void writeStringArray(String[] array, DataOutputStream outputStream) throws IOException {
/* 326 */     outputStream.writeInt((array == null) ? 0 : array.length);
/* 327 */     for (int i = 0; i < ((array == null) ? 0 : array.length); i++) {
/* 328 */       writeStringOrNull(array[i], outputStream);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeStringArray(String[] array, int size, DataOutputStream outputStream) throws IOException {
/* 333 */     outputStream.writeInt((array == null) ? 0 : size);
/* 334 */     if (array == null)
/*     */       return; 
/* 336 */     for (int i = 0; i < size; i++) {
/* 337 */       writeStringOrNull(array[i], outputStream);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveConfigurationElement(ConfigurationElementHandle element, DataOutputStream outputStream, DataOutputStream extraOutputStream, int depth) throws IOException {
/* 343 */     if (!element.shouldPersist())
/*     */       return; 
/* 345 */     DataOutputStream currentOutput = outputStream;
/* 346 */     if (depth > 2) {
/* 347 */       currentOutput = extraOutputStream;
/*     */     }
/* 349 */     this.offsets.put(element.getId(), currentOutput.size());
/*     */     
/* 351 */     currentOutput.writeInt(element.getId());
/* 352 */     ConfigurationElement actualCe = (ConfigurationElement)element.getObject();
/*     */     
/* 354 */     writeStringOrNull(actualCe.getContributorId(), currentOutput);
/* 355 */     writeStringOrNull(actualCe.getName(), currentOutput);
/* 356 */     currentOutput.writeInt(actualCe.parentId);
/* 357 */     currentOutput.writeByte(actualCe.parentType);
/* 358 */     currentOutput.writeInt((depth > 1) ? extraOutputStream.size() : -1);
/* 359 */     writeStringArray(actualCe.getPropertiesAndValue(), currentOutput);
/*     */     
/* 361 */     saveArray(filter(actualCe.getRawChildren()), currentOutput);
/*     */     
/* 363 */     if (actualCe instanceof ConfigurationElementMulti) {
/* 364 */       ConfigurationElementMulti multiCE = (ConfigurationElementMulti)actualCe;
/* 365 */       int NLs = multiCE.getNumCachedLocales();
/* 366 */       currentOutput.writeInt(NLs);
/* 367 */       if (NLs != 0) {
/* 368 */         writeStringArray(multiCE.getCachedLocales(), NLs, currentOutput);
/* 369 */         String[][] translated = multiCE.getCachedTranslations();
/* 370 */         for (int j = 0; j < NLs; j++) {
/* 371 */           writeStringArray(translated[j], currentOutput);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 376 */     ConfigurationElementHandle[] childrenCEs = (ConfigurationElementHandle[])element.getChildren(); byte b; int i; ConfigurationElementHandle[] arrayOfConfigurationElementHandle1;
/* 377 */     for (i = (arrayOfConfigurationElementHandle1 = childrenCEs).length, b = 0; b < i; ) { ConfigurationElementHandle childrenCE = arrayOfConfigurationElementHandle1[b];
/* 378 */       saveConfigurationElement(childrenCE, outputStream, extraOutputStream, depth + 1);
/*     */       b++; }
/*     */      } private void saveExtensions(IExtension[] exts, DataOutputStream outputStream) throws IOException {
/*     */     byte b;
/*     */     int i;
/*     */     IExtension[] arrayOfIExtension;
/* 384 */     for (i = (arrayOfIExtension = exts).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension[b];
/* 385 */       saveExtension((ExtensionHandle)ext, outputStream); b++; }
/*     */     
/* 387 */     for (i = (arrayOfIExtension = exts).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension[b];
/* 388 */       if (((ExtensionHandle)ext).shouldPersist()) {
/*     */ 
/*     */         
/* 391 */         IConfigurationElement[] ces = ext.getConfigurationElements();
/* 392 */         int countCElements = 0;
/* 393 */         boolean[] save = new boolean[ces.length]; int j;
/* 394 */         for (j = 0; j < ces.length; j++) {
/* 395 */           if (((ConfigurationElementHandle)ces[j]).shouldPersist()) {
/* 396 */             save[j] = true;
/* 397 */             countCElements++;
/*     */           } else {
/* 399 */             save[j] = false;
/*     */           } 
/* 401 */         }  outputStream.writeInt(countCElements);
/* 402 */         for (j = 0; j < ces.length; j++) {
/* 403 */           if (save[j])
/* 404 */             saveConfigurationElement((ConfigurationElementHandle)ces[j], outputStream, this.extraOutput, 1); 
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   } private void saveExtensionPointData(ExtensionPointHandle xpt) throws IOException {
/* 410 */     writeStringOrNull(xpt.getLabelAsIs(), this.extraOutput);
/* 411 */     writeStringOrNull(xpt.getSchemaReference(), this.extraOutput);
/* 412 */     writeStringOrNull(xpt.getUniqueIdentifier(), this.extraOutput);
/* 413 */     writeStringOrNull(xpt.getNamespaceIdentifier(), this.extraOutput);
/* 414 */     writeStringOrNull(((ExtensionPoint)xpt.getObject()).getContributorId(), this.extraOutput);
/*     */   }
/*     */   
/*     */   private void saveExtensionData(ExtensionHandle extension) throws IOException {
/* 418 */     writeStringOrNull(extension.getLabelAsIs(), this.extraOutput);
/* 419 */     writeStringOrNull(extension.getExtensionPointUniqueIdentifier(), this.extraOutput);
/* 420 */     writeStringOrNull(extension.getContributorId(), this.extraOutput);
/*     */   }
/*     */   
/*     */   private void writeStringOrNull(String string, DataOutputStream out) throws IOException {
/* 424 */     if (string == null) {
/* 425 */       out.writeByte(0);
/*     */     } else {
/* 427 */       byte[] data = string.getBytes(StandardCharsets.UTF_8);
/* 428 */       if (data.length > 65535) {
/* 429 */         out.writeByte(2);
/* 430 */         out.writeInt(data.length);
/* 431 */         out.write(data);
/*     */       } else {
/* 433 */         out.writeByte(1);
/* 434 */         out.writeUTF(string);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void saveOrphans() throws IOException {
/* 440 */     Map<String, int[]> orphans = this.objectManager.getOrphanExtensions();
/* 441 */     Map<String, int[]> filteredOrphans = (Map)new HashMap<>();
/* 442 */     for (Map.Entry<String, int[]> entry : orphans.entrySet()) {
/* 443 */       int[] filteredValue = filter(entry.getValue());
/* 444 */       if (filteredValue.length != 0)
/* 445 */         filteredOrphans.put(entry.getKey(), filteredValue); 
/*     */     } 
/* 447 */     FileOutputStream fosOrphan = new FileOutputStream(this.orphansFile);
/* 448 */     DataOutputStream outputOrphan = new DataOutputStream(new BufferedOutputStream(fosOrphan));
/* 449 */     outputOrphan.writeInt(filteredOrphans.size());
/* 450 */     Set<Map.Entry<String, int[]>> elements = (Set)filteredOrphans.entrySet();
/* 451 */     for (Map.Entry<String, int[]> entry : elements) {
/* 452 */       outputOrphan.writeUTF(entry.getKey());
/* 453 */       saveArray(entry.getValue(), outputOrphan);
/*     */     } 
/* 455 */     for (Map.Entry<String, int[]> entry : elements) {
/* 456 */       this.mainOutput.writeInt(((int[])entry.getValue()).length);
/* 457 */       saveExtensions((IExtension[])this.objectManager.getHandles(entry.getValue(), (byte)2), this.mainOutput);
/*     */     } 
/* 459 */     outputOrphan.flush();
/* 460 */     fosOrphan.getFD().sync();
/* 461 */     outputOrphan.close();
/*     */   }
/*     */   
/*     */   private void log(Status status) {
/* 465 */     this.registry.log((IStatus)status);
/*     */   }
/*     */ 
/*     */   
/*     */   private int[] filter(int[] input) {
/* 470 */     boolean[] save = new boolean[input.length];
/* 471 */     int resultSize = 0;
/* 472 */     for (int i = 0; i < input.length; i++) {
/* 473 */       if (this.objectManager.shouldPersist(input[i])) {
/* 474 */         save[i] = true;
/* 475 */         resultSize++;
/*     */       } else {
/* 477 */         save[i] = false;
/*     */       } 
/* 479 */     }  int[] result = new int[resultSize];
/* 480 */     int pos = 0;
/* 481 */     for (int j = 0; j < input.length; j++) {
/* 482 */       if (save[j]) {
/* 483 */         result[pos] = input[j];
/* 484 */         pos++;
/*     */       } 
/*     */     } 
/* 487 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\TableWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */