/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import org.eclipse.core.internal.registry.RegistryMessages;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSGIUtils
/*     */ {
/*  33 */   private ServiceTracker<?, ?> debugTracker = null;
/*  34 */   private ServiceTracker<?, ?> bundleTracker = null;
/*  35 */   private ServiceTracker<?, ?> configurationLocationTracker = null;
/*     */   
/*     */   public static final String PROP_CONFIG_AREA = "osgi.configuration.area";
/*     */   
/*     */   public static final String PROP_INSTANCE_AREA = "osgi.instance.area";
/*     */   
/*  41 */   private static final OSGIUtils singleton = new OSGIUtils();
/*     */   
/*     */   public static OSGIUtils getDefault() {
/*  44 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OSGIUtils() {
/*  52 */     initServices();
/*     */   }
/*     */   
/*     */   private void initServices() {
/*  56 */     BundleContext context = Activator.getContext();
/*  57 */     if (context == null) {
/*  58 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
/*     */       
/*     */       return;
/*     */     } 
/*  62 */     this.debugTracker = new ServiceTracker(context, DebugOptions.class.getName(), null);
/*  63 */     this.debugTracker.open();
/*     */     
/*  65 */     this.bundleTracker = new ServiceTracker(context, PackageAdmin.class.getName(), null);
/*  66 */     this.bundleTracker.open();
/*     */ 
/*     */ 
/*     */     
/*  70 */     Filter filter = null;
/*     */     try {
/*  72 */       filter = context.createFilter("(&(objectClass=org.eclipse.osgi.service.datalocation.Location)(type=osgi.configuration.area))");
/*  73 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/*  76 */     this.configurationLocationTracker = new ServiceTracker(context, filter, null);
/*  77 */     this.configurationLocationTracker.open();
/*     */   }
/*     */ 
/*     */   
/*     */   void closeServices() {
/*  82 */     if (this.debugTracker != null) {
/*  83 */       this.debugTracker.close();
/*  84 */       this.debugTracker = null;
/*     */     } 
/*  86 */     if (this.bundleTracker != null) {
/*  87 */       this.bundleTracker.close();
/*  88 */       this.bundleTracker = null;
/*     */     } 
/*  90 */     if (this.configurationLocationTracker != null) {
/*  91 */       this.configurationLocationTracker.close();
/*  92 */       this.configurationLocationTracker = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getBooleanDebugOption(String option, boolean defaultValue) {
/*  97 */     if (this.debugTracker == null) {
/*  98 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
/*  99 */       return defaultValue;
/*     */     } 
/* 101 */     DebugOptions options = (DebugOptions)this.debugTracker.getService();
/* 102 */     if (options != null) {
/* 103 */       String value = options.getOption(option);
/* 104 */       if (value != null)
/* 105 */         return value.equalsIgnoreCase("true"); 
/*     */     } 
/* 107 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public PackageAdmin getPackageAdmin() {
/* 111 */     if (this.bundleTracker == null) {
/* 112 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
/* 113 */       return null;
/*     */     } 
/* 115 */     return (PackageAdmin)this.bundleTracker.getService();
/*     */   }
/*     */   
/*     */   public Bundle getBundle(String bundleName) {
/* 119 */     PackageAdmin packageAdmin = getPackageAdmin();
/* 120 */     if (packageAdmin == null)
/* 121 */       return null; 
/* 122 */     Bundle[] bundles = packageAdmin.getBundles(bundleName, null);
/* 123 */     if (bundles == null)
/* 124 */       return null;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 126 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 127 */       if ((bundle.getState() & 0x3) == 0)
/* 128 */         return bundle; 
/*     */       b++; }
/*     */     
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   public Bundle[] getFragments(Bundle bundle) {
/* 135 */     PackageAdmin packageAdmin = getPackageAdmin();
/* 136 */     if (packageAdmin == null)
/* 137 */       return null; 
/* 138 */     return packageAdmin.getFragments(bundle);
/*     */   }
/*     */   
/*     */   public boolean isFragment(Bundle bundle) {
/* 142 */     PackageAdmin packageAdmin = getPackageAdmin();
/* 143 */     if (packageAdmin == null)
/* 144 */       return false; 
/* 145 */     return ((packageAdmin.getBundleType(bundle) & 0x1) > 0);
/*     */   }
/*     */   
/*     */   public Bundle[] getHosts(Bundle bundle) {
/* 149 */     PackageAdmin packageAdmin = getPackageAdmin();
/* 150 */     if (packageAdmin == null)
/* 151 */       return null; 
/* 152 */     return packageAdmin.getHosts(bundle);
/*     */   }
/*     */   
/*     */   public Location getConfigurationLocation() {
/* 156 */     if (this.configurationLocationTracker == null)
/* 157 */       return null; 
/* 158 */     return (Location)this.configurationLocationTracker.getService();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\OSGIUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */