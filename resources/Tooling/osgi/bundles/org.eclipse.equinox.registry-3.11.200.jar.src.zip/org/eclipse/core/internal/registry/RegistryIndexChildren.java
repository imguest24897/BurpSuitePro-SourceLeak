/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryIndexChildren
/*     */ {
/*  18 */   static final int[] EMPTY_ARRAY = new int[0];
/*     */   
/*     */   private int[] children;
/*     */   
/*     */   public RegistryIndexChildren() {
/*  23 */     this.children = EMPTY_ARRAY;
/*     */   }
/*     */   
/*     */   public RegistryIndexChildren(int[] children) {
/*  27 */     this.children = children;
/*     */   }
/*     */   
/*     */   public int[] getChildren() {
/*  31 */     return this.children;
/*     */   }
/*     */   
/*     */   public int findChild(int id) {
/*  35 */     for (int i = 0; i < this.children.length; i++) {
/*  36 */       if (this.children[i] == id)
/*  37 */         return i; 
/*     */     } 
/*  39 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean unlinkChild(int id) {
/*  43 */     int index = findChild(id);
/*  44 */     if (index == -1) {
/*  45 */       return false;
/*     */     }
/*     */     
/*  48 */     int[] result = new int[this.children.length - 1];
/*  49 */     System.arraycopy(this.children, 0, result, 0, index);
/*  50 */     System.arraycopy(this.children, index + 1, result, index, this.children.length - index - 1);
/*  51 */     this.children = result;
/*  52 */     return true;
/*     */   }
/*     */   
/*     */   public boolean linkChild(int id) {
/*  56 */     if (this.children.length == 0) {
/*  57 */       this.children = new int[] { id };
/*  58 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  62 */     int[] result = new int[this.children.length + 1];
/*  63 */     System.arraycopy(this.children, 0, result, 0, this.children.length);
/*  64 */     result[this.children.length] = id;
/*  65 */     this.children = result;
/*  66 */     return true;
/*     */   }
/*     */   
/*     */   public boolean linkChildren(int[] IDs) {
/*  70 */     if (this.children.length == 0) {
/*  71 */       this.children = IDs;
/*  72 */       return true;
/*     */     } 
/*  74 */     int[] result = new int[this.children.length + IDs.length];
/*  75 */     System.arraycopy(this.children, 0, result, 0, this.children.length);
/*  76 */     System.arraycopy(IDs, 0, result, this.children.length, IDs.length);
/*  77 */     this.children = result;
/*  78 */     return true;
/*     */   }
/*     */   
/*     */   public boolean unlinkChildren(int[] IDs) {
/*  82 */     if (this.children.length == 0) {
/*  83 */       return (IDs.length == 0);
/*     */     }
/*  85 */     int size = this.children.length;
/*  86 */     for (int i = 0; i < IDs.length; i++) {
/*  87 */       int index = findChild(IDs[i]);
/*  88 */       if (index != -1) {
/*  89 */         this.children[i] = -1;
/*  90 */         size--;
/*     */       } 
/*     */     } 
/*  93 */     if (size == 0) {
/*  94 */       this.children = EMPTY_ARRAY;
/*  95 */       return true;
/*     */     } 
/*  97 */     int[] result = new int[size];
/*  98 */     int pos = 0; byte b; int j, arrayOfInt1[];
/*  99 */     for (j = (arrayOfInt1 = this.children).length, b = 0; b < j; ) { int child = arrayOfInt1[b];
/* 100 */       if (child != -1) {
/*     */         
/* 102 */         result[pos] = child;
/* 103 */         pos++;
/*     */       }  b++; }
/* 105 */      return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryIndexChildren.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */