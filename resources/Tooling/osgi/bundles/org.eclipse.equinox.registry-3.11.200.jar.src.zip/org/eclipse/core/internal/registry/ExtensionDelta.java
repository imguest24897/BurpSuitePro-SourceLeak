/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionDelta;
/*    */ import org.eclipse.core.runtime.IExtensionPoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtensionDelta
/*    */   implements IExtensionDelta
/*    */ {
/*    */   private int kind;
/*    */   private int extension;
/*    */   private int extensionPoint;
/*    */   private RegistryDelta containingDelta;
/*    */   
/*    */   void setContainingDelta(RegistryDelta containingDelta) {
/* 25 */     this.containingDelta = containingDelta;
/*    */   }
/*    */   
/*    */   int getExtensionId() {
/* 29 */     return this.extension;
/*    */   }
/*    */   
/*    */   int getExtensionPointId() {
/* 33 */     return this.extensionPoint;
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtensionPoint getExtensionPoint() {
/* 38 */     return new ExtensionPointHandle(this.containingDelta.getObjectManager(), this.extensionPoint);
/*    */   }
/*    */   
/*    */   public void setExtensionPoint(int extensionPoint) {
/* 42 */     this.extensionPoint = extensionPoint;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getKind() {
/* 47 */     return this.kind;
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtension getExtension() {
/* 52 */     return new ExtensionHandle(this.containingDelta.getObjectManager(), this.extension);
/*    */   }
/*    */   
/*    */   public void setExtension(int extension) {
/* 56 */     this.extension = extension;
/*    */   }
/*    */   
/*    */   public void setKind(int kind) {
/* 60 */     this.kind = kind;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "\n\t\t" + getExtensionPoint().getUniqueIdentifier() + " - " + getExtension().getNamespaceIdentifier() + '.' + getExtension().getSimpleIdentifier() + " (" + getKindString(getKind()) + ")";
/*    */   }
/*    */   
/*    */   public static String getKindString(int kind) {
/* 69 */     switch (kind) {
/*    */       case 1:
/* 71 */         return "ADDED";
/*    */       case 2:
/* 73 */         return "REMOVED";
/*    */     } 
/* 75 */     return "UNKNOWN";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionDelta.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */