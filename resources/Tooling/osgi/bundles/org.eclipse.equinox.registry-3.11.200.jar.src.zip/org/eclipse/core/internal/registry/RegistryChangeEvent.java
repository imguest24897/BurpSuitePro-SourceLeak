/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IExtensionDelta;
/*    */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RegistryChangeEvent
/*    */   implements IRegistryChangeEvent
/*    */ {
/*    */   private final String filter;
/*    */   private final Map<String, ?> deltas;
/*    */   
/*    */   public RegistryChangeEvent(Map<String, ?> deltas, String filter) {
/* 30 */     this.deltas = deltas;
/* 31 */     this.filter = filter;
/*    */   }
/*    */ 
/*    */   
/*    */   private RegistryDelta[] getHostDeltas() {
/* 36 */     if (this.filter != null) {
/* 37 */       RegistryDelta singleDelta = getHostDelta(this.filter);
/* 38 */       (new RegistryDelta[1])[0] = singleDelta; return (singleDelta == null) ? new RegistryDelta[0] : new RegistryDelta[1];
/*    */     } 
/*    */     
/* 41 */     return (RegistryDelta[])this.deltas.values().toArray((Object[])new RegistryDelta[this.deltas.size()]);
/*    */   }
/*    */   
/*    */   private RegistryDelta getHostDelta(String pluginId) {
/* 45 */     if (this.filter != null && !pluginId.equals(this.filter))
/* 46 */       return null; 
/* 47 */     return (RegistryDelta)this.deltas.get(pluginId);
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtensionDelta[] getExtensionDeltas() {
/* 52 */     RegistryDelta[] hostDeltas = getHostDeltas();
/* 53 */     if (hostDeltas.length == 0)
/* 54 */       return new IExtensionDelta[0]; 
/* 55 */     int extensionDeltasSize = 0; byte b; int j; RegistryDelta[] arrayOfRegistryDelta1;
/* 56 */     for (j = (arrayOfRegistryDelta1 = hostDeltas).length, b = 0; b < j; ) { RegistryDelta hostDelta = arrayOfRegistryDelta1[b];
/* 57 */       extensionDeltasSize += hostDelta.getExtensionDeltasCount(); b++; }
/*    */     
/* 59 */     IExtensionDelta[] extensionDeltas = new IExtensionDelta[extensionDeltasSize];
/* 60 */     for (int i = 0, offset = 0; i < hostDeltas.length; i++) {
/* 61 */       IExtensionDelta[] hostExtDeltas = hostDeltas[i].getExtensionDeltas();
/* 62 */       System.arraycopy(hostExtDeltas, 0, extensionDeltas, offset, hostExtDeltas.length);
/* 63 */       offset += hostExtDeltas.length;
/*    */     } 
/* 65 */     return extensionDeltas;
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtensionDelta[] getExtensionDeltas(String hostName) {
/* 70 */     RegistryDelta hostDelta = getHostDelta(hostName);
/* 71 */     if (hostDelta == null)
/* 72 */       return new IExtensionDelta[0]; 
/* 73 */     return hostDelta.getExtensionDeltas();
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtensionDelta[] getExtensionDeltas(String hostName, String extensionPoint) {
/* 78 */     RegistryDelta hostDelta = getHostDelta(hostName);
/* 79 */     if (hostDelta == null)
/* 80 */       return new IExtensionDelta[0]; 
/* 81 */     return hostDelta.getExtensionDeltas(String.valueOf(hostName) + '.' + extensionPoint);
/*    */   }
/*    */ 
/*    */   
/*    */   public IExtensionDelta getExtensionDelta(String hostName, String extensionPoint, String extension) {
/* 86 */     RegistryDelta hostDelta = getHostDelta(hostName);
/* 87 */     if (hostDelta == null)
/* 88 */       return null; 
/* 89 */     return hostDelta.getExtensionDelta(String.valueOf(hostName) + '.' + extensionPoint, extension);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "RegistryChangeEvent:  " + Arrays.<RegistryDelta>asList(getHostDeltas());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryChangeEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */