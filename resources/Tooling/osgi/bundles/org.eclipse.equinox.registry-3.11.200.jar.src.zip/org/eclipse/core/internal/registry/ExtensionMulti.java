/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtensionMulti
/*    */   extends Extension
/*    */ {
/*    */   protected ExtensionMulti(ExtensionRegistry registry, boolean persist) {
/* 22 */     super(registry, persist);
/*    */   }
/*    */   
/*    */   protected ExtensionMulti(int self, String simpleId, String namespace, int[] children, int extraData, ExtensionRegistry registry, boolean persist) {
/* 26 */     super(self, simpleId, namespace, children, extraData, registry, persist);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getLabel(String locale) {
/* 32 */     String[] translated = this.registry.translate(new String[] { getLabelAsIs() }, getContributor(), locale);
/* 33 */     return translated[0];
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getLabel() {
/* 38 */     return getLabel(getLocale());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionMulti.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */