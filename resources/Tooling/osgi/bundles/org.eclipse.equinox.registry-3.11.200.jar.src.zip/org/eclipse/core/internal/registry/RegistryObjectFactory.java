/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryObjectFactory
/*    */ {
/*    */   protected ExtensionRegistry registry;
/*    */   
/*    */   public RegistryObjectFactory(ExtensionRegistry registry) {
/* 25 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Contribution createContribution(String contributorId, boolean persist) {
/* 31 */     return new Contribution(contributorId, this.registry, persist);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtensionPoint createExtensionPoint(boolean persist) {
/* 37 */     return new ExtensionPoint(this.registry, persist);
/*    */   }
/*    */   
/*    */   public ExtensionPoint createExtensionPoint(int self, int[] children, int dataOffset, boolean persist) {
/* 41 */     return new ExtensionPoint(self, children, dataOffset, this.registry, persist);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Extension createExtension(boolean persist) {
/* 47 */     return new Extension(this.registry, persist);
/*    */   }
/*    */   
/*    */   public Extension createExtension(int self, String simpleId, String namespace, int[] children, int extraData, boolean persist) {
/* 51 */     return new Extension(self, simpleId, namespace, children, extraData, this.registry, persist);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationElement createConfigurationElement(boolean persist) {
/* 57 */     return new ConfigurationElement(this.registry, persist);
/*    */   }
/*    */   
/*    */   public ConfigurationElement createConfigurationElement(int self, String contributorId, String name, String[] propertiesAndValue, int[] children, int extraDataOffset, int parent, byte parentType, boolean persist) {
/* 61 */     return new ConfigurationElement(self, contributorId, name, propertiesAndValue, children, extraDataOffset, parent, parentType, this.registry, persist);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryObjectFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */