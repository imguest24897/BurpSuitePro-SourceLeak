/*     */ package org.eclipse.core.runtime.spi;
/*     */ 
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RegistryContributor
/*     */   implements IContributor
/*     */ {
/*     */   private String actualContributorId;
/*     */   private String actualContributorName;
/*     */   private String hostId;
/*     */   private String hostName;
/*     */   
/*     */   public RegistryContributor(String actualId, String actualName, String hostId, String hostName) {
/*  89 */     this.actualContributorId = actualId;
/*  90 */     this.actualContributorName = actualName;
/*  91 */     if (hostId != null) {
/*  92 */       this.hostId = hostId;
/*  93 */       this.hostName = hostName;
/*     */     } else {
/*  95 */       this.hostId = actualId;
/*  96 */       this.hostName = actualName;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActualId() {
/* 107 */     return this.actualContributorId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActualName() {
/* 116 */     return this.actualContributorName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 127 */     return this.hostId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 138 */     return this.hostName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return String.valueOf(this.actualContributorName) + "[" + this.actualContributorId + "]";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\spi\RegistryContributor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */