package org.eclipse.core.internal.registry;

public interface IObjectManager {
  Handle getHandle(int paramInt, byte paramByte);
  
  Handle[] getHandles(int[] paramArrayOfint, byte paramByte);
  
  Object getObject(int paramInt, byte paramByte);
  
  RegistryObject[] getObjects(int[] paramArrayOfint, byte paramByte);
  
  void close();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\IObjectManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */