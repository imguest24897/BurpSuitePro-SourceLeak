/*    */ package org.eclipse.core.internal.registry.osgi;
/*    */ 
/*    */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*    */ import org.eclipse.osgi.service.resolver.PlatformAdmin;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EquinoxUtils
/*    */ {
/*    */   public static String[] getCommandLine(BundleContext context, ServiceReference<?> ref) {
/* 35 */     if (ref == null)
/* 36 */       return null; 
/*    */     try {
/* 38 */       EnvironmentInfo environmentInfo = (EnvironmentInfo)context.getService(ref);
/* 39 */       return (environmentInfo == null) ? null : environmentInfo.getNonFrameworkArgs();
/*    */     } finally {
/* 41 */       context.ungetService(ref);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long getContainerTimestamp(BundleContext context, ServiceReference<?> ref) {
/* 49 */     if (ref == null)
/* 50 */       return -1L; 
/*    */     try {
/* 52 */       PlatformAdmin admin = (PlatformAdmin)context.getService(ref);
/* 53 */       return (admin == null) ? -1L : admin.getState(false).getTimeStamp();
/*    */     } finally {
/* 55 */       context.ungetService(ref);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ServiceRegistration<?> registerCommandProvider(BundleContext context) {
/*    */     try {
/* 65 */       return context.registerService("org.eclipse.osgi.framework.console.CommandProvider", new RegistryCommandProvider(), null);
/* 66 */     } catch (NoClassDefFoundError noClassDefFoundError) {
/*    */ 
/*    */       
/* 69 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isActive(String bundleId) {
/*    */     try {
/* 78 */       Bundle bundle = OSGIUtils.getDefault().getBundle(bundleId);
/* 79 */       if (bundle == null)
/* 80 */         return false; 
/* 81 */       return (bundle.getState() == 32);
/* 82 */     } catch (NoClassDefFoundError noClassDefFoundError) {
/*    */       
/* 84 */       return true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\EquinoxUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */