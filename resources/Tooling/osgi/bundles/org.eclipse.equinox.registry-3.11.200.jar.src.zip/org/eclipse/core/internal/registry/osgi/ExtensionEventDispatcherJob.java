/*    */ package org.eclipse.core.internal.registry.osgi;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ import org.eclipse.core.runtime.spi.RegistryStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExtensionEventDispatcherJob
/*    */   extends Job
/*    */ {
/* 28 */   private static final ISchedulingRule EXTENSION_EVENT_RULE = new ISchedulingRule()
/*    */     {
/*    */       public boolean contains(ISchedulingRule rule) {
/* 31 */         return (rule == this);
/*    */       }
/*    */ 
/*    */       
/*    */       public boolean isConflicting(ISchedulingRule rule) {
/* 36 */         return (rule == this);
/*    */       }
/*    */     };
/*    */   
/*    */   private final Map<String, ?> deltas;
/*    */   private final Object[] listenerInfos;
/*    */   private final Object registry;
/*    */   
/*    */   public ExtensionEventDispatcherJob(Object[] listenerInfos, Map<String, ?> deltas, Object registry) {
/* 45 */     super("Registry event dispatcher");
/* 46 */     setSystem(true);
/* 47 */     this.listenerInfos = listenerInfos;
/* 48 */     this.deltas = deltas;
/* 49 */     this.registry = registry;
/*    */     
/* 51 */     setRule(EXTENSION_EVENT_RULE);
/*    */   }
/*    */ 
/*    */   
/*    */   public IStatus run(IProgressMonitor monitor) {
/* 56 */     return RegistryStrategy.processChangeEvent(this.listenerInfos, this.deltas, this.registry);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\ExtensionEventDispatcherJob.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */