/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThirdLevelConfigurationElementHandle
/*    */   extends ConfigurationElementHandle
/*    */ {
/*    */   public ThirdLevelConfigurationElementHandle(IObjectManager objectManager, int id) {
/* 24 */     super(objectManager, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConfigurationElement getConfigurationElement() {
/* 29 */     return (ConfigurationElement)this.objectManager.getObject(getId(), (byte)4);
/*    */   }
/*    */ 
/*    */   
/*    */   public IConfigurationElement[] getChildren() {
/* 34 */     return (IConfigurationElement[])this.objectManager.getHandles(getConfigurationElement().getRawChildren(), (byte)4);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ThirdLevelConfigurationElementHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */