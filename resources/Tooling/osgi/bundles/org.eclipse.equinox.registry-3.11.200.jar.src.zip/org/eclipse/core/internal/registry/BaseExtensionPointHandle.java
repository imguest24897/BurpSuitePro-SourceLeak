/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseExtensionPointHandle
/*     */   extends Handle
/*     */   implements IExtensionPoint
/*     */ {
/*     */   public BaseExtensionPointHandle(IObjectManager objectManager, int id) {
/*  31 */     super(objectManager, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public IExtension[] getExtensions() {
/*  36 */     return (IExtension[])this.objectManager.getHandles(getExtensionPoint().getRawChildren(), (byte)2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  42 */     return getContributor().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceIdentifier() {
/*  47 */     return getExtensionPoint().getNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContributor getContributor() {
/*  52 */     return getExtensionPoint().getContributor();
/*     */   }
/*     */   
/*     */   protected boolean shouldPersist() {
/*  56 */     return getExtensionPoint().shouldPersist();
/*     */   }
/*     */ 
/*     */   
/*     */   public IExtension getExtension(String extensionId) {
/*  61 */     if (extensionId == null)
/*  62 */       return null;  byte b; int i; int[] arrayOfInt;
/*  63 */     for (i = (arrayOfInt = getExtensionPoint().getRawChildren()).length, b = 0; b < i; ) { int element = arrayOfInt[b];
/*     */       
/*  65 */       if (extensionId.equals(((Extension)this.objectManager.getObject(element, (byte)2)).getUniqueIdentifier()))
/*  66 */         return (ExtensionHandle)this.objectManager.getHandle(element, (byte)2);  b++; }
/*     */     
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IConfigurationElement[] getConfigurationElements() {
/*  74 */     Extension[] tmpExtensions = (Extension[])this.objectManager.getObjects(getExtensionPoint().getRawChildren(), (byte)2);
/*  75 */     if (tmpExtensions.length == 0) {
/*  76 */       return (IConfigurationElement[])ConfigurationElementHandle.EMPTY_ARRAY;
/*     */     }
/*  78 */     ArrayList<Handle> result = new ArrayList<>(); byte b; int i; Extension[] arrayOfExtension1;
/*  79 */     for (i = (arrayOfExtension1 = tmpExtensions).length, b = 0; b < i; ) { Extension tmpExtension = arrayOfExtension1[b];
/*  80 */       result.addAll(Arrays.asList(this.objectManager.getHandles(tmpExtension.getRawChildren(), (byte)1))); b++; }
/*     */     
/*  82 */     return result.<IConfigurationElement>toArray(new IConfigurationElement[result.size()]);
/*     */   }
/*     */   
/*     */   public String getLabelAsIs() {
/*  86 */     return getExtensionPoint().getLabelAsIs();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  91 */     return getExtensionPoint().getLabel();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel(String locale) {
/*  96 */     return getExtensionPoint().getLabel(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemaReference() {
/* 101 */     return getExtensionPoint().getSchemaReference();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSimpleIdentifier() {
/* 106 */     return getExtensionPoint().getSimpleIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUniqueIdentifier() {
/* 111 */     return getExtensionPoint().getUniqueIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   RegistryObject getObject() {
/* 116 */     return getExtensionPoint();
/*     */   }
/*     */   
/*     */   protected ExtensionPoint getExtensionPoint() {
/* 120 */     return (ExtensionPoint)this.objectManager.getObject(getId(), (byte)3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/*     */     try {
/* 126 */       getExtensionPoint();
/* 127 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/* 128 */       return false;
/*     */     } 
/* 130 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\BaseExtensionPointHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */