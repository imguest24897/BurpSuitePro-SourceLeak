package org.eclipse.core.runtime;

public interface IConfigurationElement {
  Object createExecutableExtension(String paramString) throws CoreException;
  
  String getAttribute(String paramString) throws InvalidRegistryObjectException;
  
  String getAttribute(String paramString1, String paramString2) throws InvalidRegistryObjectException;
  
  @Deprecated
  String getAttributeAsIs(String paramString) throws InvalidRegistryObjectException;
  
  String[] getAttributeNames() throws InvalidRegistryObjectException;
  
  IConfigurationElement[] getChildren() throws InvalidRegistryObjectException;
  
  IConfigurationElement[] getChildren(String paramString) throws InvalidRegistryObjectException;
  
  IExtension getDeclaringExtension() throws InvalidRegistryObjectException;
  
  String getName() throws InvalidRegistryObjectException;
  
  Object getParent() throws InvalidRegistryObjectException;
  
  String getValue() throws InvalidRegistryObjectException;
  
  String getValue(String paramString) throws InvalidRegistryObjectException;
  
  @Deprecated
  String getValueAsIs() throws InvalidRegistryObjectException;
  
  @Deprecated
  String getNamespace() throws InvalidRegistryObjectException;
  
  String getNamespaceIdentifier() throws InvalidRegistryObjectException;
  
  IContributor getContributor() throws InvalidRegistryObjectException;
  
  boolean equals(Object paramObject);
  
  boolean isValid();
  
  int getHandleId();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\IConfigurationElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */