/*    */ package org.eclipse.core.internal.registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtensionPointHandle
/*    */   extends BaseExtensionPointHandle
/*    */ {
/* 27 */   static final ExtensionPointHandle[] EMPTY_ARRAY = new ExtensionPointHandle[0];
/*    */   
/*    */   public ExtensionPointHandle(IObjectManager objectManager, int id) {
/* 30 */     super(objectManager, id);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ExtensionPointHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */