package org.eclipse.core.runtime;

public interface IExtension {
  IConfigurationElement[] getConfigurationElements() throws InvalidRegistryObjectException;
  
  @Deprecated
  String getNamespace() throws InvalidRegistryObjectException;
  
  String getNamespaceIdentifier() throws InvalidRegistryObjectException;
  
  IContributor getContributor() throws InvalidRegistryObjectException;
  
  String getExtensionPointUniqueIdentifier() throws InvalidRegistryObjectException;
  
  String getLabel() throws InvalidRegistryObjectException;
  
  String getLabel(String paramString) throws InvalidRegistryObjectException;
  
  String getSimpleIdentifier() throws InvalidRegistryObjectException;
  
  String getUniqueIdentifier() throws InvalidRegistryObjectException;
  
  boolean equals(Object paramObject);
  
  boolean isValid();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\IExtension.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */