/*     */ package org.eclipse.core.internal.registry.osgi;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.core.internal.adapter.AdapterManagerListener;
/*     */ import org.eclipse.core.internal.registry.RegistryProperties;
/*     */ import org.eclipse.core.internal.registry.RegistryProviderFactory;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.core.runtime.spi.RegistryStrategy;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   implements BundleActivator
/*     */ {
/*     */   private static BundleContext bundleContext;
/*     */   private static final String STORAGE_DIR = "org.eclipse.core.runtime";
/*  43 */   private Object masterRegistryKey = new Object();
/*  44 */   private Object userRegistryKey = new Object();
/*     */   
/*  46 */   private IExtensionRegistry defaultRegistry = null;
/*     */   private ServiceRegistration<?> registryRegistration;
/*     */   private ServiceRegistration<?> commandRegistration;
/*     */   private RegistryProviderOSGI defaultProvider;
/*  50 */   private AdapterManagerListener adapterManagerListener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/*  57 */     bundleContext = context;
/*  58 */     RegistryProperties.setContext(bundleContext);
/*  59 */     processCommandLine();
/*  60 */     startRegistry();
/*  61 */     this.adapterManagerListener = new AdapterManagerListener();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/*  69 */     if (this.adapterManagerListener != null)
/*  70 */       this.adapterManagerListener.stop(); 
/*  71 */     stopRegistry();
/*  72 */     RegistryProperties.setContext(null);
/*  73 */     bundleContext = null;
/*     */   }
/*     */   
/*     */   public static BundleContext getContext() {
/*  77 */     return bundleContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processCommandLine() {
/*  87 */     ServiceReference<?> ref = getContext().getServiceReference("org.eclipse.osgi.service.environment.EnvironmentInfo");
/*  88 */     if (ref == null)
/*     */       return; 
/*  90 */     String[] args = EquinoxUtils.getCommandLine(bundleContext, ref);
/*  91 */     if (args == null || args.length == 0)
/*     */       return;  byte b; int i; String[] arrayOfString1;
/*  93 */     for (i = (arrayOfString1 = args).length, b = 0; b < i; ) { String arg = arrayOfString1[b];
/*  94 */       if (arg.equalsIgnoreCase("-noregistrycache")) {
/*  95 */         RegistryProperties.setProperty("eclipse.noRegistryCache", "true");
/*  96 */       } else if (arg.equalsIgnoreCase("-noLazyRegistryCacheLoading")) {
/*  97 */         RegistryProperties.setProperty("eclipse.noLazyRegistryCacheLoading", "true");
/*  98 */       } else if (arg.equalsIgnoreCase("-registryMultiLanguage")) {
/*  99 */         RegistryProperties.setProperty("eclipse.registry.MultiLanguage", "true");
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void startRegistry() throws CoreException {
/* 106 */     String property = bundleContext.getProperty("eclipse.createRegistry");
/* 107 */     if (property != null && property.equalsIgnoreCase("false")) {
/*     */       return;
/*     */     }
/*     */     
/* 111 */     if ("true".equals(bundleContext.getProperty("eclipse.registry.nulltoken"))) {
/* 112 */       this.userRegistryKey = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     RegistryStrategy strategy = null;
/* 122 */     Location configuration = OSGIUtils.getDefault().getConfigurationLocation();
/* 123 */     if (configuration == null) {
/* 124 */       RegistryProperties.setProperty("eclipse.noRegistryCache", "true");
/* 125 */       RegistryProperties.setProperty("eclipse.noLazyRegistryCacheLoading", "true");
/* 126 */       strategy = new RegistryStrategyOSGI(null, null, this.masterRegistryKey);
/*     */     } else {
/* 128 */       File[] registryLocations; boolean[] readOnlyLocations; File primaryDir = new File(String.valueOf(configuration.getURL().getPath()) + '/' + "org.eclipse.core.runtime");
/* 129 */       boolean primaryReadOnly = configuration.isReadOnly();
/*     */       
/* 131 */       Location parentLocation = configuration.getParentLocation();
/* 132 */       if (parentLocation != null) {
/* 133 */         File secondaryDir = new File(String.valueOf(parentLocation.getURL().getFile()) + '/' + "org.eclipse.core.runtime");
/* 134 */         registryLocations = new File[] { primaryDir, secondaryDir };
/* 135 */         readOnlyLocations = new boolean[] { primaryReadOnly, true };
/*     */       } else {
/* 137 */         registryLocations = new File[] { primaryDir };
/* 138 */         readOnlyLocations = new boolean[] { primaryReadOnly };
/*     */       } 
/* 140 */       strategy = new EquinoxRegistryStrategy(registryLocations, readOnlyLocations, this.masterRegistryKey);
/*     */     } 
/*     */     
/* 143 */     this.defaultRegistry = RegistryFactory.createRegistry(strategy, this.masterRegistryKey, this.userRegistryKey);
/*     */     
/* 145 */     this.registryRegistration = getContext().registerService(IExtensionRegistry.class.getName(), this.defaultRegistry, new Hashtable<>());
/* 146 */     this.defaultProvider = new RegistryProviderOSGI(this.defaultRegistry);
/*     */     
/* 148 */     RegistryProviderFactory.setDefault(this.defaultProvider);
/* 149 */     this.commandRegistration = EquinoxUtils.registerCommandProvider(getContext());
/*     */   }
/*     */   
/*     */   private void stopRegistry() {
/* 153 */     if (this.defaultRegistry != null) {
/* 154 */       RegistryProviderFactory.releaseDefault();
/* 155 */       this.registryRegistration.unregister();
/* 156 */       this.defaultRegistry.stop(this.masterRegistryKey);
/*     */     } 
/* 158 */     if (this.commandRegistration != null)
/* 159 */       this.commandRegistration.unregister(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\osgi\Activator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */