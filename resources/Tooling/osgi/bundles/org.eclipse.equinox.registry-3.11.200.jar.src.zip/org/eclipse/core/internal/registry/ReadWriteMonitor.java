/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadWriteMonitor
/*     */ {
/*  29 */   private int status = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread writeLockowner;
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void enterRead() {
/*  38 */     if (this.writeLockowner == Thread.currentThread())
/*     */       return; 
/*  40 */     while (this.status < 0) {
/*     */       try {
/*  42 */         wait();
/*  43 */       } catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */ 
/*     */     
/*  47 */     this.status++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void enterWrite() {
/*  55 */     if (this.writeLockowner != Thread.currentThread()) {
/*  56 */       while (this.status != 0) {
/*     */         try {
/*  58 */           wait();
/*  59 */         } catch (InterruptedException interruptedException) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  64 */       this.writeLockowner = Thread.currentThread();
/*     */     } 
/*  66 */     this.status--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void exitRead() {
/*  73 */     if (this.writeLockowner == Thread.currentThread())
/*     */       return; 
/*  75 */     if (--this.status == 0) {
/*  76 */       notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void exitWrite() {
/*  84 */     if (this.writeLockowner != Thread.currentThread())
/*  85 */       throw new IllegalStateException("Current owner is " + this.writeLockowner); 
/*  86 */     if (++this.status == 0) {
/*     */       
/*  88 */       this.writeLockowner = null;
/*  89 */       notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     StringBuilder buffer = new StringBuilder();
/*  96 */     buffer.append(hashCode());
/*  97 */     if (this.status == 0) {
/*  98 */       buffer.append("Monitor idle ");
/*  99 */     } else if (this.status < 0) {
/* 100 */       buffer.append("Monitor writing ");
/* 101 */     } else if (this.status > 0) {
/* 102 */       buffer.append("Monitor reading ");
/*     */     } 
/* 104 */     buffer.append("(status = ");
/* 105 */     buffer.append(this.status);
/* 106 */     buffer.append(")");
/* 107 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\ReadWriteMonitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */