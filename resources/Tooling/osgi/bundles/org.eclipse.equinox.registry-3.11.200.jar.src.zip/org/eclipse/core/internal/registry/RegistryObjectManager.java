/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryObjectManager
/*     */   implements IObjectManager
/*     */ {
/*     */   public static final byte CONFIGURATION_ELEMENT = 1;
/*     */   public static final byte EXTENSION = 2;
/*     */   public static final byte EXTENSION_POINT = 3;
/*     */   public static final byte THIRDLEVEL_CONFIGURATION_ELEMENT = 4;
/*     */   static final int CACHE_INITIAL_SIZE = 512;
/*     */   static final float DEFAULT_LOADFACTOR = 0.75F;
/*  37 */   static final int[] EMPTY_INT_ARRAY = new int[0];
/*  38 */   static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  40 */   static final ExtensionHandle[] EMPTY_EXTENSIONS_ARRAY = new ExtensionHandle[0];
/*     */   
/*  42 */   static int UNKNOWN = -1;
/*     */ 
/*     */   
/*     */   private HashtableOfStringAndInt extensionPoints;
/*     */   
/*     */   private ReferenceMap cache;
/*     */   
/*  49 */   private OffsetTable fileOffsets = null;
/*     */   
/*  51 */   private int nextId = 1;
/*     */ 
/*     */   
/*     */   private final KeyedHashSet newContributions;
/*     */   
/*     */   private Object formerContributions;
/*     */   
/*     */   private HashMap<String, RegistryContributor> contributors;
/*     */   
/*     */   private HashMap<String, RegistryContributor> removedContributors;
/*     */   
/*     */   private KeyedHashSet namespacesIndex;
/*     */   
/*     */   private Object orphanExtensions;
/*     */   
/*  66 */   private final KeyedHashSet heldObjects = new KeyedHashSet();
/*     */ 
/*     */   
/*     */   private boolean isDirty = false;
/*     */ 
/*     */   
/*     */   private boolean fromCache = false;
/*     */   
/*     */   private final ExtensionRegistry registry;
/*     */   
/*     */   public static final String PROP_NO_REGISTRY_FLUSHING = "eclipse.noRegistryFlushing";
/*     */ 
/*     */   
/*     */   public RegistryObjectManager(ExtensionRegistry registry) {
/*  80 */     this.extensionPoints = new HashtableOfStringAndInt();
/*  81 */     if ("true".equalsIgnoreCase(RegistryProperties.getProperty("eclipse.noRegistryFlushing"))) {
/*  82 */       this.cache = new ReferenceMap(0, 512, 0.75F);
/*     */     } else {
/*  84 */       this.cache = new ReferenceMap(1, 512, 0.75F);
/*     */     } 
/*  86 */     this.newContributions = new KeyedHashSet();
/*     */     
/*  88 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean init(long timeStamp) {
/*  95 */     TableReader reader = this.registry.getTableReader();
/*  96 */     Object[] results = reader.loadTables(timeStamp);
/*  97 */     if (results == null) {
/*  98 */       return false;
/*     */     }
/* 100 */     this.fileOffsets = (OffsetTable)results[0];
/* 101 */     this.extensionPoints = (HashtableOfStringAndInt)results[1];
/* 102 */     this.nextId = ((Integer)results[2]).intValue();
/* 103 */     this.fromCache = true;
/*     */     
/* 105 */     if (!this.registry.useLazyCacheLoading()) {
/*     */       
/* 107 */       reader.setHoldObjects(true);
/* 108 */       markOrphansHasDirty(getOrphans());
/* 109 */       this.fromCache = reader.readAllCache(this);
/* 110 */       this.formerContributions = getFormerContributions();
/*     */     } 
/* 112 */     return this.fromCache;
/*     */   }
/*     */   
/*     */   synchronized void addContribution(Contribution contribution) {
/* 116 */     this.isDirty = true;
/* 117 */     Object Id = contribution.getKey();
/*     */     
/* 119 */     KeyedElement existingContribution = getFormerContributions().getByKey(Id);
/* 120 */     if (existingContribution != null) {
/* 121 */       removeContribution(Id);
/* 122 */       this.newContributions.add(existingContribution);
/*     */     } else {
/* 124 */       existingContribution = this.newContributions.getByKey(Id);
/*     */     } 
/* 126 */     if (existingContribution != null) {
/* 127 */       ((Contribution)existingContribution).mergeContribution(contribution);
/*     */     } else {
/* 129 */       this.newContributions.add(contribution);
/*     */     } 
/* 131 */     updateNamespaceIndex(contribution, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String findCommonNamespaceIdentifier(RegistryObject[] registryObjects) {
/* 138 */     String namespaceName = null; byte b; int i; RegistryObject[] arrayOfRegistryObject;
/* 139 */     for (i = (arrayOfRegistryObject = registryObjects).length, b = 0; b < i; ) { RegistryObject currentObject = arrayOfRegistryObject[b];
/* 140 */       String tmp = null;
/* 141 */       if (currentObject instanceof ExtensionPoint) {
/* 142 */         tmp = ((ExtensionPoint)currentObject).getNamespace();
/* 143 */       } else if (currentObject instanceof Extension) {
/* 144 */         tmp = ((Extension)currentObject).getNamespaceIdentifier();
/*     */       } 
/* 146 */       if (namespaceName == null) {
/* 147 */         namespaceName = tmp;
/*     */       
/*     */       }
/* 150 */       else if (!namespaceName.equals(tmp)) {
/* 151 */         return null;
/*     */       }  b++; }
/*     */     
/* 154 */     return namespaceName;
/*     */   }
/*     */   
/*     */   synchronized void removeExtensionPointFromNamespaceIndex(int extensionPoint, String namespaceName) {
/* 158 */     RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 159 */     indexElement.updateExtensionPoint(extensionPoint, false);
/*     */   }
/*     */   
/*     */   synchronized void removeExtensionFromNamespaceIndex(int extensions, String namespaceName) {
/* 163 */     RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 164 */     indexElement.updateExtension(extensions, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateNamespaceIndex(Contribution contribution, boolean added) {
/* 170 */     int[] contribExtensionPoints = contribution.getExtensionPoints();
/* 171 */     RegistryObject[] extensionPointObjects = getObjects(contribExtensionPoints, (byte)3);
/* 172 */     String commonExptsNamespace = null;
/* 173 */     if (contribExtensionPoints.length > 1)
/* 174 */       commonExptsNamespace = findCommonNamespaceIdentifier(extensionPointObjects); 
/* 175 */     if (commonExptsNamespace != null) {
/* 176 */       RegistryIndexElement indexElement = getNamespaceIndex(commonExptsNamespace);
/* 177 */       indexElement.updateExtensionPoints(contribExtensionPoints, added);
/*     */     } else {
/* 179 */       for (int i = 0; i < contribExtensionPoints.length; i++) {
/* 180 */         String namespaceName = ((ExtensionPoint)extensionPointObjects[i]).getNamespace();
/* 181 */         RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 182 */         indexElement.updateExtensionPoint(contribExtensionPoints[i], added);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 187 */     int[] contrExtensions = contribution.getExtensions();
/* 188 */     RegistryObject[] extensionObjects = getObjects(contrExtensions, (byte)2);
/* 189 */     String commonExtNamespace = null;
/* 190 */     if (contrExtensions.length > 1)
/* 191 */       commonExtNamespace = findCommonNamespaceIdentifier(extensionObjects); 
/* 192 */     if (commonExtNamespace != null) {
/* 193 */       RegistryIndexElement indexElement = getNamespaceIndex(commonExtNamespace);
/* 194 */       indexElement.updateExtensions(contrExtensions, added);
/*     */     } else {
/* 196 */       for (int i = 0; i < contrExtensions.length; i++) {
/* 197 */         String namespaceName = ((Extension)extensionObjects[i]).getNamespaceIdentifier();
/* 198 */         RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 199 */         indexElement.updateExtension(contrExtensions[i], added);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized int[] getExtensionPointsFrom(String id) {
/* 205 */     KeyedElement tmp = this.newContributions.getByKey(id);
/* 206 */     if (tmp == null)
/* 207 */       tmp = getFormerContributions().getByKey(id); 
/* 208 */     if (tmp == null)
/* 209 */       return EMPTY_INT_ARRAY; 
/* 210 */     return ((Contribution)tmp).getExtensionPoints();
/*     */   }
/*     */   
/*     */   synchronized boolean hasContribution(String id) {
/* 214 */     Object result = this.newContributions.getByKey(id);
/* 215 */     if (result == null)
/* 216 */       result = getFormerContributions().getByKey(id); 
/* 217 */     return (result != null);
/*     */   }
/*     */ 
/*     */   
/*     */   private KeyedHashSet getFormerContributions() {
/* 222 */     if (!this.fromCache) {
/* 223 */       return new KeyedHashSet(0);
/*     */     }
/* 225 */     if (this.formerContributions != null) { KeyedHashSet result; if ((result = (this.formerContributions instanceof SoftReference) ? ((SoftReference<KeyedHashSet>)this.formerContributions).get() : (KeyedHashSet)this.formerContributions) == null)
/* 226 */       { result = this.registry.getTableReader().loadContributions();
/* 227 */         this.formerContributions = new SoftReference<>(result);
/*     */         
/* 229 */         return result; }  return result; }  KeyedHashSet keyedHashSet = this.registry.getTableReader().loadContributions(); this.formerContributions = new SoftReference<>(keyedHashSet); return keyedHashSet;
/*     */   }
/*     */   
/*     */   public synchronized void add(RegistryObject registryObject, boolean hold) {
/* 233 */     if (registryObject.getObjectId() == UNKNOWN) {
/* 234 */       int id = this.nextId++;
/* 235 */       registryObject.setObjectId(id);
/*     */     } 
/* 237 */     this.cache.put(registryObject.getObjectId(), registryObject);
/* 238 */     if (hold)
/* 239 */       hold(registryObject); 
/*     */   }
/*     */   
/*     */   private void remove(RegistryObject registryObject, boolean release) {
/* 243 */     this.cache.remove(registryObject.getObjectId());
/* 244 */     if (release)
/* 245 */       release(registryObject); 
/*     */   }
/*     */   
/*     */   synchronized void remove(int id, boolean release) {
/* 249 */     RegistryObject toRemove = (RegistryObject)this.cache.get(id);
/* 250 */     if (this.fileOffsets != null)
/* 251 */       this.fileOffsets.removeKey(id); 
/* 252 */     if (toRemove != null)
/* 253 */       remove(toRemove, release); 
/*     */   }
/*     */   
/*     */   private void hold(RegistryObject toHold) {
/* 257 */     this.heldObjects.add(toHold);
/*     */   }
/*     */   
/*     */   private void release(RegistryObject toRelease) {
/* 261 */     this.heldObjects.remove(toRelease);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Object getObject(int id, byte type) {
/* 266 */     return basicGetObject(id, type);
/*     */   }
/*     */   
/*     */   private Object basicGetObject(int id, byte type) {
/* 270 */     Object result = this.cache.get(id);
/* 271 */     if (result != null)
/* 272 */       return result; 
/* 273 */     if (this.fromCache)
/* 274 */       result = load(id, type); 
/* 275 */     if (result == null)
/* 276 */       throw new InvalidRegistryObjectException(); 
/* 277 */     this.cache.put(id, result);
/* 278 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldPersist(int id) {
/* 290 */     Object result = this.cache.get(id);
/* 291 */     if (result != null)
/* 292 */       return ((RegistryObject)result).shouldPersist(); 
/* 293 */     return true;
/*     */   } public synchronized RegistryObject[] getObjects(int[] values, byte type) {
/*     */     ExtensionPoint[] arrayOfExtensionPoint;
/*     */     Extension[] arrayOfExtension;
/*     */     ConfigurationElement[] arrayOfConfigurationElement;
/* 298 */     if (values.length == 0) {
/* 299 */       switch (type) {
/*     */         case 3:
/* 301 */           return (RegistryObject[])ExtensionPoint.EMPTY_ARRAY;
/*     */         case 2:
/* 303 */           return (RegistryObject[])Extension.EMPTY_ARRAY;
/*     */         case 1:
/*     */         case 4:
/* 306 */           return (RegistryObject[])ConfigurationElement.EMPTY_ARRAY;
/*     */       } 
/*     */     
/*     */     }
/* 310 */     RegistryObject[] results = null;
/* 311 */     switch (type) {
/*     */       case 3:
/* 313 */         arrayOfExtensionPoint = new ExtensionPoint[values.length];
/*     */         break;
/*     */       case 2:
/* 316 */         arrayOfExtension = new Extension[values.length];
/*     */         break;
/*     */       case 1:
/*     */       case 4:
/* 320 */         arrayOfConfigurationElement = new ConfigurationElement[values.length];
/*     */         break;
/*     */     } 
/* 323 */     for (int i = 0; i < values.length; i++) {
/* 324 */       arrayOfConfigurationElement[i] = (ConfigurationElement)basicGetObject(values[i], type);
/*     */     }
/* 326 */     return (RegistryObject[])arrayOfConfigurationElement;
/*     */   }
/*     */   
/*     */   synchronized ExtensionPoint getExtensionPointObject(String xptUniqueId) {
/*     */     int id;
/* 331 */     if ((id = this.extensionPoints.get(xptUniqueId)) == Integer.MIN_VALUE)
/* 332 */       return null; 
/* 333 */     return (ExtensionPoint)getObject(id, (byte)3);
/*     */   }
/*     */ 
/*     */   
/*     */   public Handle getHandle(int id, byte type) {
/* 338 */     switch (type) {
/*     */       case 3:
/* 340 */         return new ExtensionPointHandle(this, id);
/*     */       
/*     */       case 2:
/* 343 */         return new ExtensionHandle(this, id);
/*     */       
/*     */       case 1:
/* 346 */         return new ConfigurationElementHandle(this, id);
/*     */     } 
/*     */ 
/*     */     
/* 350 */     return new ThirdLevelConfigurationElementHandle(this, id); } public Handle[] getHandles(int[] ids, byte type) {
/*     */     ExtensionPointHandle[] arrayOfExtensionPointHandle;
/*     */     ExtensionHandle[] arrayOfExtensionHandle;
/*     */     ConfigurationElementHandle[] arrayOfConfigurationElementHandle;
/*     */     ThirdLevelConfigurationElementHandle[] arrayOfThirdLevelConfigurationElementHandle;
/*     */     int i;
/* 356 */     Handle[] results = null;
/* 357 */     int nbrId = ids.length;
/* 358 */     switch (type) {
/*     */       case 3:
/* 360 */         if (nbrId == 0)
/* 361 */           return (Handle[])ExtensionPointHandle.EMPTY_ARRAY; 
/* 362 */         arrayOfExtensionPointHandle = new ExtensionPointHandle[nbrId];
/* 363 */         for (i = 0; i < nbrId; i++) {
/* 364 */           arrayOfExtensionPointHandle[i] = new ExtensionPointHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 2:
/* 369 */         if (nbrId == 0)
/* 370 */           return (Handle[])ExtensionHandle.EMPTY_ARRAY; 
/* 371 */         arrayOfExtensionHandle = new ExtensionHandle[nbrId];
/* 372 */         for (i = 0; i < nbrId; i++) {
/* 373 */           arrayOfExtensionHandle[i] = new ExtensionHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 1:
/* 378 */         if (nbrId == 0)
/* 379 */           return (Handle[])ConfigurationElementHandle.EMPTY_ARRAY; 
/* 380 */         arrayOfConfigurationElementHandle = new ConfigurationElementHandle[nbrId];
/* 381 */         for (i = 0; i < nbrId; i++) {
/* 382 */           arrayOfConfigurationElementHandle[i] = new ConfigurationElementHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 4:
/* 387 */         if (nbrId == 0)
/* 388 */           return (Handle[])ConfigurationElementHandle.EMPTY_ARRAY; 
/* 389 */         arrayOfThirdLevelConfigurationElementHandle = new ThirdLevelConfigurationElementHandle[nbrId];
/* 390 */         for (i = 0; i < nbrId; i++) {
/* 391 */           arrayOfThirdLevelConfigurationElementHandle[i] = new ThirdLevelConfigurationElementHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */     } 
/* 395 */     return (Handle[])arrayOfThirdLevelConfigurationElementHandle;
/*     */   }
/*     */   
/*     */   synchronized ExtensionPointHandle[] getExtensionPointsHandles() {
/* 399 */     return (ExtensionPointHandle[])getHandles(this.extensionPoints.getValues(), (byte)3);
/*     */   }
/*     */   
/*     */   synchronized ExtensionPointHandle getExtensionPointHandle(String xptUniqueId) {
/* 403 */     int id = this.extensionPoints.get(xptUniqueId);
/* 404 */     if (id == Integer.MIN_VALUE)
/* 405 */       return null; 
/* 406 */     return (ExtensionPointHandle)getHandle(id, (byte)3);
/*     */   }
/*     */   
/*     */   private Object load(int id, byte type) {
/* 410 */     TableReader reader = this.registry.getTableReader();
/* 411 */     if (this.fileOffsets == null)
/* 412 */       return null; 
/* 413 */     int offset = this.fileOffsets.get(id);
/* 414 */     if (offset == Integer.MIN_VALUE)
/* 415 */       return null; 
/* 416 */     switch (type) {
/*     */       case 1:
/* 418 */         return reader.loadConfigurationElement(offset);
/*     */       
/*     */       case 4:
/* 421 */         return reader.loadThirdLevelConfigurationElements(offset, this);
/*     */       
/*     */       case 2:
/* 424 */         return reader.loadExtension(offset);
/*     */     } 
/*     */ 
/*     */     
/* 428 */     return reader.loadExtensionPointTree(offset, this);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized int[] getExtensionsFrom(String contributorId) {
/* 433 */     KeyedElement tmp = this.newContributions.getByKey(contributorId);
/* 434 */     if (tmp == null)
/* 435 */       tmp = getFormerContributions().getByKey(contributorId); 
/* 436 */     if (tmp == null)
/* 437 */       return EMPTY_INT_ARRAY; 
/* 438 */     return ((Contribution)tmp).getExtensions();
/*     */   }
/*     */   
/*     */   synchronized boolean addExtensionPoint(ExtensionPoint currentExtPoint, boolean hold) {
/* 442 */     String uniqueId = currentExtPoint.getUniqueIdentifier();
/* 443 */     if (this.extensionPoints.get(uniqueId) != Integer.MIN_VALUE)
/* 444 */       return false; 
/* 445 */     add(currentExtPoint, hold);
/* 446 */     this.extensionPoints.put(uniqueId, currentExtPoint.getObjectId());
/* 447 */     return true;
/*     */   }
/*     */   
/*     */   synchronized void removeExtensionPoint(String extensionPointId) {
/* 451 */     int pointId = this.extensionPoints.removeKey(extensionPointId);
/* 452 */     if (pointId == Integer.MIN_VALUE)
/*     */       return; 
/* 454 */     remove(pointId, true);
/*     */   }
/*     */   
/*     */   public boolean isDirty() {
/* 458 */     return this.isDirty;
/*     */   }
/*     */   
/*     */   public void markDirty() {
/* 462 */     this.isDirty = true;
/*     */   }
/*     */   
/*     */   synchronized void removeContribution(Object contributorId) {
/* 466 */     boolean removed = this.newContributions.removeByKey(contributorId);
/* 467 */     if (!removed) {
/* 468 */       removed = getFormerContributions().removeByKey(contributorId);
/* 469 */       if (removed) {
/* 470 */         this.formerContributions = getFormerContributions();
/*     */       }
/*     */     } 
/* 473 */     if (removed) {
/* 474 */       this.isDirty = true;
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, int[]> getOrphans() {
/*     */     HashMap<String, int[]> hashMap;
/* 483 */     if (this.orphanExtensions == null && !this.fromCache)
/* 484 */     { Object<Object, Object> result = (Object<Object, Object>)new HashMap<>();
/* 485 */       this.orphanExtensions = result; }
/* 486 */     else { if (this.orphanExtensions != null) { Object<String, int[]> result; if ((result = (Object<String, int[]>)((this.orphanExtensions instanceof SoftReference) ? ((SoftReference)this.orphanExtensions).get() : this.orphanExtensions)) == null) {
/* 487 */           result = (Object<String, int[]>)this.registry.getTableReader().loadOrphans();
/* 488 */           this.orphanExtensions = new SoftReference<>(result);
/*     */         } 
/* 490 */         return (HashMap)result; }  hashMap = this.registry.getTableReader().loadOrphans(); this.orphanExtensions = new SoftReference<>(hashMap); }  return (Map<String, int[]>)hashMap;
/*     */   }
/*     */   
/*     */   void addOrphans(String extensionPoint, int[] extensions) {
/* 494 */     Map<String, int[]> orphans = getOrphans();
/* 495 */     int[] existingOrphanExtensions = orphans.get(extensionPoint);
/*     */     
/* 497 */     if (existingOrphanExtensions != null) {
/*     */       
/* 499 */       int[] newOrphanExtensions = new int[existingOrphanExtensions.length + extensions.length];
/* 500 */       System.arraycopy(existingOrphanExtensions, 0, newOrphanExtensions, 0, existingOrphanExtensions.length);
/* 501 */       System.arraycopy(extensions, 0, newOrphanExtensions, existingOrphanExtensions.length, extensions.length);
/* 502 */       orphans.put(extensionPoint, newOrphanExtensions);
/*     */     } else {
/*     */       
/* 505 */       orphans.put(extensionPoint, extensions);
/*     */     } 
/* 507 */     markOrphansHasDirty(orphans);
/*     */   }
/*     */   
/*     */   void markOrphansHasDirty(Map<String, int[]> orphans) {
/* 511 */     this.orphanExtensions = orphans;
/*     */   }
/*     */   
/*     */   void addOrphan(String extensionPoint, int extension) {
/* 515 */     Map<String, int[]> orphans = getOrphans();
/* 516 */     int[] existingOrphanExtensions = orphans.get(extensionPoint);
/*     */     
/* 518 */     if (existingOrphanExtensions != null) {
/*     */       
/* 520 */       int[] newOrphanExtensions = new int[existingOrphanExtensions.length + 1];
/* 521 */       System.arraycopy(existingOrphanExtensions, 0, newOrphanExtensions, 0, existingOrphanExtensions.length);
/* 522 */       newOrphanExtensions[existingOrphanExtensions.length] = extension;
/* 523 */       orphans.put(extensionPoint, newOrphanExtensions);
/*     */     } else {
/*     */       
/* 526 */       orphans.put(extensionPoint, new int[] { extension });
/*     */     } 
/* 528 */     markOrphansHasDirty(orphans);
/*     */   }
/*     */   
/*     */   int[] removeOrphans(String extensionPoint) {
/* 532 */     Map<String, int[]> orphans = getOrphans();
/* 533 */     int[] existingOrphanExtensions = orphans.remove(extensionPoint);
/* 534 */     if (existingOrphanExtensions != null) {
/* 535 */       markOrphansHasDirty(orphans);
/*     */     }
/* 537 */     return existingOrphanExtensions;
/*     */   }
/*     */   
/*     */   void removeOrphan(String extensionPoint, int extension) {
/* 541 */     Map<String, int[]> orphans = getOrphans();
/* 542 */     int[] existingOrphanExtensions = orphans.get(extensionPoint);
/*     */     
/* 544 */     if (existingOrphanExtensions == null) {
/*     */       return;
/*     */     }
/* 547 */     markOrphansHasDirty(orphans);
/* 548 */     int newSize = existingOrphanExtensions.length - 1;
/* 549 */     if (newSize == 0) {
/* 550 */       orphans.remove(extensionPoint);
/*     */       
/*     */       return;
/*     */     } 
/* 554 */     int[] newOrphanExtensions = new int[existingOrphanExtensions.length - 1];
/* 555 */     for (int i = 0, j = 0; i < existingOrphanExtensions.length; i++) {
/* 556 */       if (extension != existingOrphanExtensions[i])
/* 557 */         newOrphanExtensions[j++] = existingOrphanExtensions[i]; 
/*     */     } 
/* 559 */     orphans.put(extensionPoint, newOrphanExtensions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, int[]> getOrphanExtensions() {
/* 565 */     return getOrphans();
/*     */   }
/*     */ 
/*     */   
/*     */   int getNextId() {
/* 570 */     return this.nextId;
/*     */   }
/*     */ 
/*     */   
/*     */   HashtableOfStringAndInt getExtensionPoints() {
/* 575 */     return this.extensionPoints;
/*     */   }
/*     */ 
/*     */   
/*     */   KeyedHashSet[] getContributions() {
/* 580 */     return new KeyedHashSet[] { this.newContributions, getFormerContributions() };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   HashMap<String, RegistryContributor> getContributors() {
/* 586 */     if (this.contributors == null)
/* 587 */       if (!this.fromCache) {
/* 588 */         this.contributors = new HashMap<>();
/*     */       } else {
/* 590 */         this.contributors = this.registry.getTableReader().loadContributors();
/*     */       }  
/* 592 */     return this.contributors;
/*     */   }
/*     */   
/*     */   synchronized IContributor[] getContributorsSync() {
/* 596 */     Collection<RegistryContributor> contributorValues = getContributors().values();
/* 597 */     return contributorValues.<IContributor>toArray(new IContributor[contributorValues.size()]);
/*     */   }
/*     */   
/*     */   synchronized RegistryContributor getContributor(String id) {
/* 601 */     RegistryContributor contributor = getContributors().get(id);
/* 602 */     if (contributor != null) {
/* 603 */       return contributor;
/*     */     }
/*     */ 
/*     */     
/* 607 */     if (this.removedContributors != null)
/* 608 */       return this.removedContributors.get(id); 
/* 609 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void addContributor(RegistryContributor newContributor) {
/* 614 */     String key = newContributor.getActualId();
/* 615 */     if (!getContributors().containsKey(key)) {
/* 616 */       this.isDirty = true;
/* 617 */       if (this.removedContributors != null)
/* 618 */         this.removedContributors.remove(key); 
/* 619 */       getContributors().put(key, newContributor);
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized void removeContributor(String id) {
/* 624 */     this.isDirty = true;
/* 625 */     RegistryContributor removed = getContributors().remove(id);
/* 626 */     if (removed != null) {
/* 627 */       if (this.removedContributors == null)
/* 628 */         this.removedContributors = new HashMap<>(); 
/* 629 */       this.removedContributors.put(id, removed);
/*     */     } 
/*     */   }
/*     */   
/*     */   KeyedHashSet getNamespacesIndex() {
/* 634 */     if (this.namespacesIndex == null)
/* 635 */       if (!this.fromCache) {
/* 636 */         this.namespacesIndex = new KeyedHashSet(0);
/*     */       } else {
/* 638 */         this.namespacesIndex = this.registry.getTableReader().loadNamespaces();
/*     */       }  
/* 640 */     return this.namespacesIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   private RegistryIndexElement getNamespaceIndex(String namespaceName) {
/* 645 */     RegistryIndexElement indexElement = (RegistryIndexElement)getNamespacesIndex().getByKey(namespaceName);
/* 646 */     if (indexElement == null) {
/* 647 */       indexElement = new RegistryIndexElement(namespaceName);
/* 648 */       this.namespacesIndex.add(indexElement);
/*     */     } 
/* 650 */     return indexElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized Map<Integer, RegistryObject> getAssociatedObjects(String contributionId) {
/* 660 */     int[] xpts = getExtensionPointsFrom(contributionId);
/* 661 */     int[] exts = getExtensionsFrom(contributionId);
/* 662 */     Map<Integer, RegistryObject> actualObjects = new HashMap<>(xpts.length + exts.length); byte b; int i, arrayOfInt1[];
/* 663 */     for (i = (arrayOfInt1 = exts).length, b = 0; b < i; ) { int ext = arrayOfInt1[b];
/* 664 */       Extension tmp = (Extension)basicGetObject(ext, (byte)2);
/* 665 */       actualObjects.put(Integer.valueOf(ext), tmp);
/* 666 */       collectChildren(tmp, 0, actualObjects); b++; }
/*     */     
/* 668 */     for (i = (arrayOfInt1 = xpts).length, b = 0; b < i; ) { int xpt2 = arrayOfInt1[b];
/* 669 */       ExtensionPoint xpt = (ExtensionPoint)basicGetObject(xpt2, (byte)3);
/* 670 */       actualObjects.put(Integer.valueOf(xpt2), xpt);
/*     */       b++; }
/*     */     
/* 673 */     return actualObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void addAssociatedObjects(Map<Integer, RegistryObject> map, RegistryObject registryObject) {
/* 680 */     collectChildren(registryObject, 0, map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void addNavigableObjects(Map<Integer, RegistryObject> associatedObjects) {
/* 688 */     Map<Integer, RegistryObject> result = new HashMap<>();
/* 689 */     for (RegistryObject object : associatedObjects.values()) {
/* 690 */       if (object instanceof Extension) {
/*     */         
/* 692 */         ExtensionPoint extPoint = getExtensionPointObject(((Extension)object).getExtensionPointIdentifier());
/* 693 */         if (extPoint == null) {
/*     */           continue;
/*     */         }
/* 696 */         Integer extPointIndex = Integer.valueOf(extPoint.getKeyHashCode());
/* 697 */         if (!associatedObjects.containsKey(extPointIndex))
/* 698 */           result.put(Integer.valueOf(extPoint.getKeyHashCode()), extPoint); 
/*     */         byte b;
/*     */         int i, arrayOfInt[];
/* 701 */         for (i = (arrayOfInt = extPoint.getRawChildren()).length, b = 0; b < i; ) { int childId = arrayOfInt[b];
/* 702 */           Extension tmp = (Extension)basicGetObject(childId, (byte)2);
/* 703 */           if (tmp != null) {
/*     */             
/* 705 */             Integer extensionIndex = Integer.valueOf(childId);
/* 706 */             if (!associatedObjects.containsKey(extensionIndex))
/* 707 */             { result.put(extensionIndex, tmp);
/* 708 */               collectChildren(tmp, 0, result); } 
/*     */           }  b++; }
/*     */          continue;
/* 711 */       }  if (object instanceof ExtensionPoint) {
/*     */         
/* 713 */         Map<String, int[]> orphans = getOrphans();
/* 714 */         String name = ((ExtensionPoint)object).getUniqueIdentifier();
/* 715 */         int[] extensions = orphans.get(name);
/* 716 */         if (extensions != null) {
/* 717 */           byte b; int i; int[] arrayOfInt; for (i = (arrayOfInt = extensions).length, b = 0; b < i; ) { int orphanId = arrayOfInt[b];
/* 718 */             Extension tmp = (Extension)basicGetObject(orphanId, (byte)2);
/* 719 */             if (tmp != null) {
/*     */               
/* 721 */               Integer extensionIndex = Integer.valueOf(orphanId);
/* 722 */               if (!associatedObjects.containsKey(extensionIndex)) {
/* 723 */                 result.put(extensionIndex, tmp);
/* 724 */                 collectChildren(tmp, 0, result);
/*     */               } 
/*     */             }  b++; }
/*     */         
/*     */         } 
/*     */       } 
/* 730 */     }  associatedObjects.putAll(result);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void removeObjects(Map<?, ?> associatedObjects) {
/* 735 */     for (Object registryObject : associatedObjects.values()) {
/* 736 */       RegistryObject toRemove = (RegistryObject)registryObject;
/* 737 */       remove(toRemove.getObjectId(), true);
/* 738 */       if (toRemove instanceof ExtensionPoint)
/* 739 */         removeExtensionPoint(((ExtensionPoint)toRemove).getUniqueIdentifier()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   IObjectManager createDelegatingObjectManager(Map<?, ?> object) {
/* 744 */     return new TemporaryObjectManager(object, this);
/*     */   }
/*     */   
/*     */   private void collectChildren(RegistryObject ce, int level, Map<Integer, RegistryObject> collector) {
/* 748 */     ConfigurationElement[] children = (ConfigurationElement[])getObjects(ce.getRawChildren(), (level == 0 || ce.noExtraData()) ? 1 : 4); byte b; int i; ConfigurationElement[] arrayOfConfigurationElement1;
/* 749 */     for (i = (arrayOfConfigurationElement1 = children).length, b = 0; b < i; ) { ConfigurationElement child = arrayOfConfigurationElement1[b];
/* 750 */       collector.put(Integer.valueOf(child.getObjectId()), child);
/* 751 */       collectChildren(child, level + 1, collector);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   public ExtensionRegistry getRegistry() {
/* 761 */     return this.registry;
/*     */   } private boolean unlinkChildFromContributions(KeyedElement[] contributions, int id) {
/*     */     byte b;
/*     */     int i;
/*     */     KeyedElement[] arrayOfKeyedElement;
/* 766 */     for (i = (arrayOfKeyedElement = contributions).length, b = 0; b < i; ) { KeyedElement contribution = arrayOfKeyedElement[b];
/* 767 */       Contribution candidate = (Contribution)contribution;
/* 768 */       if (candidate != null)
/*     */       {
/* 770 */         if (candidate.hasChild(id)) {
/* 771 */           candidate.unlinkChild(id);
/* 772 */           if (candidate.isEmpty())
/* 773 */             removeContribution(candidate.getContributorId()); 
/* 774 */           return true;
/*     */         }  }  b++; }
/*     */     
/* 777 */     return false;
/*     */   }
/*     */   
/*     */   synchronized boolean unlinkChildFromContributions(int id) {
/* 781 */     if (unlinkChildFromContributions(this.newContributions.elements, id))
/* 782 */       return true; 
/* 783 */     return unlinkChildFromContributions((getFormerContributions()).elements, id);
/*     */   }
/*     */   
/*     */   public synchronized ExtensionPointHandle[] getExtensionPointsFromNamespace(String namespaceName) {
/* 787 */     RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 788 */     int[] namespaceExtensionPoints = indexElement.getExtensionPoints();
/* 789 */     return (ExtensionPointHandle[])getHandles(namespaceExtensionPoints, (byte)3);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ExtensionHandle[] getExtensionsFromNamespace(String namespaceName) {
/* 794 */     RegistryIndexElement indexElement = getNamespaceIndex(namespaceName);
/* 795 */     int[] namespaceExtensions = indexElement.getExtensions();
/*     */ 
/*     */     
/* 798 */     List<Handle> tmp = new ArrayList<>();
/* 799 */     Extension[] exts = (Extension[])getObjects(namespaceExtensions, (byte)2); byte b; int i; Extension[] arrayOfExtension1;
/* 800 */     for (i = (arrayOfExtension1 = exts).length, b = 0; b < i; ) { Extension ext = arrayOfExtension1[b];
/* 801 */       if (getExtensionPointObject(ext.getExtensionPointIdentifier()) != null)
/* 802 */         tmp.add(getHandle(ext.getObjectId(), (byte)2)); 
/*     */       b++; }
/*     */     
/* 805 */     if (tmp.size() == 0)
/* 806 */       return EMPTY_EXTENSIONS_ARRAY; 
/* 807 */     ExtensionHandle[] result = new ExtensionHandle[tmp.size()];
/* 808 */     return tmp.<ExtensionHandle>toArray(result);
/*     */   }
/*     */   
/*     */   public ExtensionHandle[] getExtensionsFromContributor(String contributorId) {
/* 812 */     int[] ids = getExtensionsFrom(contributorId);
/* 813 */     return (ExtensionHandle[])getHandles(ids, (byte)2);
/*     */   }
/*     */   
/*     */   public ExtensionPointHandle[] getExtensionPointsFromContributor(String contributorId) {
/* 817 */     int[] ids = getExtensionPointsFrom(contributorId);
/* 818 */     return (ExtensionPointHandle[])getHandles(ids, (byte)3);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryObjectManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */