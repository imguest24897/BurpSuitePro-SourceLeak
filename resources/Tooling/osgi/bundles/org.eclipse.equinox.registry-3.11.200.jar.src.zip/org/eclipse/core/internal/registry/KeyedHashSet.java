/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyedHashSet
/*     */ {
/*     */   protected static final int MINIMUM_SIZE = 7;
/*     */   private final int capacity;
/*  24 */   protected int elementCount = 0;
/*     */   protected KeyedElement[] elements;
/*     */   protected final boolean replace;
/*     */   
/*     */   public KeyedHashSet() {
/*  29 */     this(7, true);
/*     */   }
/*     */   
/*     */   public KeyedHashSet(int capacity) {
/*  33 */     this(capacity, true);
/*     */   }
/*     */   
/*     */   public KeyedHashSet(int capacity, boolean replace) {
/*  37 */     this.elements = new KeyedElement[Math.max(7, capacity * 2)];
/*  38 */     this.replace = replace;
/*  39 */     this.capacity = capacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(KeyedElement element) {
/*  48 */     int hash = hash(element);
/*     */     
/*     */     int i;
/*  51 */     for (i = hash; i < this.elements.length; i++) {
/*  52 */       if (this.elements[i] == null) {
/*  53 */         this.elements[i] = element;
/*  54 */         this.elementCount++;
/*     */         
/*  56 */         if (shouldGrow())
/*  57 */           expand(); 
/*  58 */         return true;
/*     */       } 
/*  60 */       if (this.elements[i].compare(element)) {
/*  61 */         if (this.replace)
/*  62 */           this.elements[i] = element; 
/*  63 */         return this.replace;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  68 */     for (i = 0; i < hash - 1; i++) {
/*  69 */       if (this.elements[i] == null) {
/*  70 */         this.elements[i] = element;
/*  71 */         this.elementCount++;
/*     */         
/*  73 */         if (shouldGrow())
/*  74 */           expand(); 
/*  75 */         return true;
/*     */       } 
/*  77 */       if (this.elements[i].compare(element)) {
/*  78 */         if (this.replace)
/*  79 */           this.elements[i] = element; 
/*  80 */         return this.replace;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  85 */     expand();
/*  86 */     return add(element);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  90 */     this.elements = new KeyedElement[Math.max(7, this.capacity * 2)];
/*  91 */     this.elementCount = 0;
/*     */   }
/*     */   
/*     */   public KeyedElement[] elements() {
/*  95 */     return (KeyedElement[])elements((Object[])new KeyedElement[this.elementCount]);
/*     */   }
/*     */   
/*     */   public Object[] elements(Object[] result) {
/*  99 */     int j = 0; byte b; int i; KeyedElement[] arrayOfKeyedElement;
/* 100 */     for (i = (arrayOfKeyedElement = this.elements).length, b = 0; b < i; ) { KeyedElement element = arrayOfKeyedElement[b];
/* 101 */       if (element != null)
/* 102 */         result[j++] = element;  b++; }
/*     */     
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expand() {
/* 112 */     KeyedElement[] oldElements = this.elements;
/* 113 */     this.elements = new KeyedElement[this.elements.length * 2];
/*     */     
/* 115 */     int maxArrayIndex = this.elements.length - 1; byte b; int i; KeyedElement[] arrayOfKeyedElement1;
/* 116 */     for (i = (arrayOfKeyedElement1 = oldElements).length, b = 0; b < i; ) { KeyedElement element = arrayOfKeyedElement1[b];
/* 117 */       if (element != null) {
/* 118 */         int hash = hash(element);
/* 119 */         while (this.elements[hash] != null) {
/* 120 */           hash++;
/* 121 */           if (hash > maxArrayIndex)
/* 122 */             hash = 0; 
/*     */         } 
/* 124 */         this.elements[hash] = element;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedElement get(KeyedElement key) {
/* 134 */     if (this.elementCount == 0)
/* 135 */       return null; 
/* 136 */     int hash = hash(key);
/*     */     
/*     */     int i;
/* 139 */     for (i = hash; i < this.elements.length; i++) {
/* 140 */       KeyedElement element = this.elements[i];
/* 141 */       if (element == null)
/* 142 */         return null; 
/* 143 */       if (element.compare(key)) {
/* 144 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 148 */     for (i = 0; i < hash - 1; i++) {
/* 149 */       KeyedElement element = this.elements[i];
/* 150 */       if (element == null)
/* 151 */         return null; 
/* 152 */       if (element.compare(key)) {
/* 153 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedElement getByKey(Object key) {
/* 165 */     if (this.elementCount == 0)
/* 166 */       return null; 
/* 167 */     int hash = keyHash(key);
/*     */     
/*     */     int i;
/* 170 */     for (i = hash; i < this.elements.length; i++) {
/* 171 */       KeyedElement element = this.elements[i];
/* 172 */       if (element == null)
/* 173 */         return null; 
/* 174 */       if (element.getKey().equals(key)) {
/* 175 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 179 */     for (i = 0; i < hash - 1; i++) {
/* 180 */       KeyedElement element = this.elements[i];
/* 181 */       if (element == null)
/* 182 */         return null; 
/* 183 */       if (element.getKey().equals(key)) {
/* 184 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 188 */     return null;
/*     */   }
/*     */   
/*     */   private int hash(KeyedElement element) {
/* 192 */     return (element.getKeyHashCode() & Integer.MAX_VALUE) % this.elements.length;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 196 */     return (this.elementCount == 0);
/*     */   }
/*     */   
/*     */   private int keyHash(Object key) {
/* 200 */     return (key.hashCode() & Integer.MAX_VALUE) % this.elements.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehashTo(int anIndex) {
/* 209 */     int target = anIndex;
/* 210 */     int index = anIndex + 1;
/* 211 */     if (index >= this.elements.length)
/* 212 */       index = 0; 
/* 213 */     KeyedElement element = this.elements[index];
/* 214 */     while (element != null) {
/* 215 */       boolean match; int hashIndex = hash(element);
/*     */       
/* 217 */       if (index < target) {
/* 218 */         match = !(hashIndex > target || hashIndex <= index);
/*     */       } else {
/* 220 */         match = !(hashIndex > target && hashIndex <= index);
/* 221 */       }  if (match) {
/* 222 */         this.elements[target] = element;
/* 223 */         target = index;
/*     */       } 
/* 225 */       index++;
/* 226 */       if (index >= this.elements.length)
/* 227 */         index = 0; 
/* 228 */       element = this.elements[index];
/*     */     } 
/* 230 */     this.elements[target] = null;
/*     */   }
/*     */   
/*     */   public boolean remove(KeyedElement toRemove) {
/* 234 */     if (this.elementCount == 0) {
/* 235 */       return false;
/*     */     }
/* 237 */     int hash = hash(toRemove);
/*     */     int i;
/* 239 */     for (i = hash; i < this.elements.length; i++) {
/* 240 */       KeyedElement element = this.elements[i];
/* 241 */       if (element == null)
/* 242 */         return false; 
/* 243 */       if (element.compare(toRemove)) {
/* 244 */         rehashTo(i);
/* 245 */         this.elementCount--;
/* 246 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     for (i = 0; i < hash - 1; i++) {
/* 251 */       KeyedElement element = this.elements[i];
/* 252 */       if (element == null)
/* 253 */         return false; 
/* 254 */       if (element.compare(toRemove)) {
/* 255 */         rehashTo(i);
/* 256 */         this.elementCount--;
/* 257 */         return true;
/*     */       } 
/*     */     } 
/* 260 */     return false;
/*     */   }
/*     */   
/*     */   public boolean removeByKey(Object key) {
/* 264 */     if (this.elementCount == 0)
/* 265 */       return false; 
/* 266 */     int hash = keyHash(key);
/*     */     int i;
/* 268 */     for (i = hash; i < this.elements.length; i++) {
/* 269 */       KeyedElement element = this.elements[i];
/* 270 */       if (element == null)
/* 271 */         return false; 
/* 272 */       if (element.getKey().equals(key)) {
/* 273 */         rehashTo(i);
/* 274 */         this.elementCount--;
/* 275 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 279 */     for (i = 0; i < hash - 1; i++) {
/* 280 */       KeyedElement element = this.elements[i];
/* 281 */       if (element == null)
/* 282 */         return false; 
/* 283 */       if (element.getKey().equals(key)) {
/* 284 */         rehashTo(i);
/* 285 */         this.elementCount--;
/* 286 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 290 */     return true;
/*     */   }
/*     */   
/*     */   private boolean shouldGrow() {
/* 294 */     return (this.elementCount > this.elements.length * 0.75D);
/*     */   }
/*     */   
/*     */   public int size() {
/* 298 */     return this.elementCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 303 */     StringBuilder result = new StringBuilder(100);
/* 304 */     result.append("{");
/* 305 */     boolean first = true; byte b; int i; KeyedElement[] arrayOfKeyedElement;
/* 306 */     for (i = (arrayOfKeyedElement = this.elements).length, b = 0; b < i; ) { KeyedElement element = arrayOfKeyedElement[b];
/* 307 */       if (element != null) {
/* 308 */         if (first) {
/* 309 */           first = false;
/*     */         } else {
/* 311 */           result.append(", ");
/* 312 */         }  result.append(element);
/*     */       }  b++; }
/*     */     
/* 315 */     result.append("}");
/* 316 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\KeyedHashSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */