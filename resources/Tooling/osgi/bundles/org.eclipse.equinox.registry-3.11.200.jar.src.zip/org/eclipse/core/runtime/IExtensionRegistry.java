package org.eclipse.core.runtime;

import java.io.InputStream;
import java.util.ResourceBundle;

public interface IExtensionRegistry {
  void addRegistryChangeListener(IRegistryChangeListener paramIRegistryChangeListener, String paramString);
  
  void addRegistryChangeListener(IRegistryChangeListener paramIRegistryChangeListener);
  
  IConfigurationElement[] getConfigurationElementsFor(String paramString);
  
  IConfigurationElement[] getConfigurationElementsFor(String paramString1, String paramString2);
  
  IConfigurationElement[] getConfigurationElementsFor(String paramString1, String paramString2, String paramString3);
  
  IExtension getExtension(String paramString);
  
  IExtension getExtension(String paramString1, String paramString2);
  
  IExtension getExtension(String paramString1, String paramString2, String paramString3);
  
  IExtensionPoint getExtensionPoint(String paramString);
  
  IExtensionPoint getExtensionPoint(String paramString1, String paramString2);
  
  IExtensionPoint[] getExtensionPoints();
  
  IExtensionPoint[] getExtensionPoints(String paramString);
  
  IExtensionPoint[] getExtensionPoints(IContributor paramIContributor);
  
  IExtension[] getExtensions(String paramString);
  
  IExtension[] getExtensions(IContributor paramIContributor);
  
  String[] getNamespaces();
  
  void removeRegistryChangeListener(IRegistryChangeListener paramIRegistryChangeListener);
  
  boolean addContribution(InputStream paramInputStream, IContributor paramIContributor, boolean paramBoolean, String paramString, ResourceBundle paramResourceBundle, Object paramObject) throws IllegalArgumentException;
  
  boolean removeExtension(IExtension paramIExtension, Object paramObject) throws IllegalArgumentException;
  
  boolean removeExtensionPoint(IExtensionPoint paramIExtensionPoint, Object paramObject) throws IllegalArgumentException;
  
  void stop(Object paramObject) throws IllegalArgumentException;
  
  void addListener(IRegistryEventListener paramIRegistryEventListener);
  
  void addListener(IRegistryEventListener paramIRegistryEventListener, String paramString);
  
  void removeListener(IRegistryEventListener paramIRegistryEventListener);
  
  boolean isMultiLanguage();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\runtime\IExtensionRegistry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */