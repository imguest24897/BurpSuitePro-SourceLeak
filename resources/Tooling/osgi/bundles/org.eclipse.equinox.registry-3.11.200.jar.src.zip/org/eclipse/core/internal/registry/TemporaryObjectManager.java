/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemporaryObjectManager
/*     */   implements IObjectManager
/*     */ {
/*     */   private Map<?, ?> actualObjects;
/*     */   private final RegistryObjectManager parent;
/*     */   
/*     */   public TemporaryObjectManager(Map<?, ?> actualObjects, RegistryObjectManager parent) {
/*  27 */     this.actualObjects = actualObjects;
/*  28 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public Handle getHandle(int id, byte type) {
/*  33 */     switch (type) {
/*     */       case 3:
/*  35 */         return new ExtensionPointHandle(this, id);
/*     */       
/*     */       case 2:
/*  38 */         return new ExtensionHandle(this, id);
/*     */       
/*     */       case 1:
/*  41 */         return new ConfigurationElementHandle(this, id);
/*     */     } 
/*     */ 
/*     */     
/*  45 */     return new ThirdLevelConfigurationElementHandle(this, id); } public Handle[] getHandles(int[] ids, byte type) {
/*     */     ExtensionPointHandle[] arrayOfExtensionPointHandle;
/*     */     ExtensionHandle[] arrayOfExtensionHandle;
/*     */     ConfigurationElementHandle[] arrayOfConfigurationElementHandle;
/*     */     ThirdLevelConfigurationElementHandle[] arrayOfThirdLevelConfigurationElementHandle;
/*     */     int i;
/*  51 */     Handle[] results = null;
/*  52 */     int nbrId = ids.length;
/*  53 */     switch (type) {
/*     */       case 3:
/*  55 */         if (nbrId == 0)
/*  56 */           return (Handle[])ExtensionPointHandle.EMPTY_ARRAY; 
/*  57 */         arrayOfExtensionPointHandle = new ExtensionPointHandle[nbrId];
/*  58 */         for (i = 0; i < nbrId; i++) {
/*  59 */           arrayOfExtensionPointHandle[i] = new ExtensionPointHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 2:
/*  64 */         if (nbrId == 0)
/*  65 */           return (Handle[])ExtensionHandle.EMPTY_ARRAY; 
/*  66 */         arrayOfExtensionHandle = new ExtensionHandle[nbrId];
/*  67 */         for (i = 0; i < nbrId; i++) {
/*  68 */           arrayOfExtensionHandle[i] = new ExtensionHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 1:
/*  73 */         if (nbrId == 0)
/*  74 */           return (Handle[])ConfigurationElementHandle.EMPTY_ARRAY; 
/*  75 */         arrayOfConfigurationElementHandle = new ConfigurationElementHandle[nbrId];
/*  76 */         for (i = 0; i < nbrId; i++) {
/*  77 */           arrayOfConfigurationElementHandle[i] = new ConfigurationElementHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 4:
/*  82 */         if (nbrId == 0)
/*  83 */           return (Handle[])ConfigurationElementHandle.EMPTY_ARRAY; 
/*  84 */         arrayOfThirdLevelConfigurationElementHandle = new ThirdLevelConfigurationElementHandle[nbrId];
/*  85 */         for (i = 0; i < nbrId; i++) {
/*  86 */           arrayOfThirdLevelConfigurationElementHandle[i] = new ThirdLevelConfigurationElementHandle(this, ids[i]);
/*     */         }
/*     */         break;
/*     */     } 
/*  90 */     return (Handle[])arrayOfThirdLevelConfigurationElementHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Object getObject(int id, byte type) {
/*  95 */     Object result = null;
/*     */     try {
/*  97 */       result = this.parent.getObject(id, type);
/*  98 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/*  99 */       if (this.actualObjects != null) {
/* 100 */         result = this.actualObjects.get(Integer.valueOf(id));
/*     */       }
/*     */     } 
/* 103 */     if (result == null)
/* 104 */       throw new InvalidRegistryObjectException(); 
/* 105 */     return result;
/*     */   } public synchronized RegistryObject[] getObjects(int[] values, byte type) {
/*     */     ExtensionPoint[] arrayOfExtensionPoint;
/*     */     Extension[] arrayOfExtension;
/*     */     ConfigurationElement[] arrayOfConfigurationElement;
/* 110 */     if (values.length == 0) {
/* 111 */       switch (type) {
/*     */         case 3:
/* 113 */           return (RegistryObject[])ExtensionPoint.EMPTY_ARRAY;
/*     */         case 2:
/* 115 */           return (RegistryObject[])Extension.EMPTY_ARRAY;
/*     */         case 1:
/*     */         case 4:
/* 118 */           return (RegistryObject[])ConfigurationElement.EMPTY_ARRAY;
/*     */       } 
/*     */     
/*     */     }
/* 122 */     RegistryObject[] results = null;
/* 123 */     switch (type) {
/*     */       case 3:
/* 125 */         arrayOfExtensionPoint = new ExtensionPoint[values.length];
/*     */         break;
/*     */       case 2:
/* 128 */         arrayOfExtension = new Extension[values.length];
/*     */         break;
/*     */       case 1:
/*     */       case 4:
/* 132 */         arrayOfConfigurationElement = new ConfigurationElement[values.length];
/*     */         break;
/*     */     } 
/* 135 */     for (int i = 0; i < values.length; i++) {
/* 136 */       arrayOfConfigurationElement[i] = (ConfigurationElement)getObject(values[i], type);
/*     */     }
/* 138 */     return (RegistryObject[])arrayOfConfigurationElement;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/* 143 */     this.actualObjects = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\TemporaryObjectManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */