/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedEventDelta
/*     */ {
/*     */   private final boolean addition;
/*     */   private IObjectManager objectManager;
/*     */   private static final int arrayGrowthSpace = 5;
/*     */   private Map<String, List<Integer>> extensionsByID;
/*     */   private Map<String, List<Integer>> extPointsByID;
/*     */   private List<Integer> allExtensions;
/*     */   private List<Integer> allExtensionPoints;
/*     */   
/*     */   private CombinedEventDelta(boolean addition) {
/*  45 */     this.addition = addition;
/*     */   }
/*     */   
/*     */   public static CombinedEventDelta recordAddition() {
/*  49 */     return new CombinedEventDelta(true);
/*     */   }
/*     */   
/*     */   public static CombinedEventDelta recordRemoval() {
/*  53 */     return new CombinedEventDelta(false);
/*     */   }
/*     */   
/*     */   public boolean isAddition() {
/*  57 */     return this.addition;
/*     */   }
/*     */   
/*     */   public boolean isRemoval() {
/*  61 */     return !this.addition;
/*     */   }
/*     */   
/*     */   public void setObjectManager(IObjectManager manager) {
/*  65 */     this.objectManager = manager;
/*     */   }
/*     */   
/*     */   public IObjectManager getObjectManager() {
/*  69 */     return this.objectManager;
/*     */   }
/*     */   
/*     */   private List<Integer> getExtensionsBucket(String id) {
/*  73 */     if (this.extensionsByID == null) {
/*  74 */       this.extensionsByID = new HashMap<>();
/*     */     }
/*  76 */     List<Integer> extensions = this.extensionsByID.get(id);
/*  77 */     if (extensions == null) {
/*  78 */       extensions = new ArrayList<>(5);
/*  79 */       this.extensionsByID.put(id, extensions);
/*     */     } 
/*  81 */     return extensions;
/*     */   }
/*     */   
/*     */   private List<Integer> getExtPointsBucket(String id) {
/*  85 */     if (this.extPointsByID == null) {
/*  86 */       this.extPointsByID = new HashMap<>();
/*     */     }
/*  88 */     List<Integer> extensionPoints = this.extPointsByID.get(id);
/*  89 */     if (extensionPoints == null) {
/*  90 */       extensionPoints = new ArrayList<>(5);
/*  91 */       this.extPointsByID.put(id, extensionPoints);
/*     */     } 
/*  93 */     return extensionPoints;
/*     */   }
/*     */   
/*     */   private List<Integer> getExtPointsGlobal() {
/*  97 */     if (this.allExtensionPoints == null) {
/*  98 */       this.allExtensionPoints = new ArrayList<>();
/*     */     }
/* 100 */     return this.allExtensionPoints;
/*     */   }
/*     */   
/*     */   private List<Integer> getExtensionsGlobal() {
/* 104 */     if (this.allExtensions == null) {
/* 105 */       this.allExtensions = new ArrayList<>();
/*     */     }
/* 107 */     return this.allExtensions;
/*     */   }
/*     */   
/*     */   public void rememberExtensionPoint(ExtensionPoint extensionPoint) {
/* 111 */     String bucketId = extensionPoint.getUniqueIdentifier();
/* 112 */     Integer extPt = Integer.valueOf(extensionPoint.getObjectId());
/* 113 */     getExtPointsBucket(bucketId).add(extPt);
/* 114 */     getExtPointsGlobal().add(extPt);
/*     */   }
/*     */   
/*     */   public void rememberExtension(ExtensionPoint extensionPoint, int ext) {
/* 118 */     String bucketId = extensionPoint.getUniqueIdentifier();
/* 119 */     Integer extension = Integer.valueOf(ext);
/*     */     
/* 121 */     getExtensionsBucket(bucketId).add(extension);
/* 122 */     getExtensionsGlobal().add(extension);
/*     */   }
/*     */   
/*     */   public void rememberExtensions(ExtensionPoint extensionPoint, int[] exts) {
/* 126 */     if (exts == null)
/*     */       return; 
/* 128 */     if (exts.length == 0)
/*     */       return;  byte b; int i; int[] arrayOfInt;
/* 130 */     for (i = (arrayOfInt = exts).length, b = 0; b < i; ) { int ext = arrayOfInt[b];
/* 131 */       rememberExtension(extensionPoint, ext);
/*     */       b++; }
/*     */   
/*     */   } public IExtensionPoint[] getExtensionPoints(String id) {
/* 135 */     List<Integer> extensionPoints = null;
/* 136 */     if (id != null && this.extPointsByID != null) {
/* 137 */       extensionPoints = this.extPointsByID.get(id);
/* 138 */     } else if (id == null) {
/* 139 */       extensionPoints = this.allExtensionPoints;
/* 140 */     }  if (extensionPoints == null)
/* 141 */       return null; 
/* 142 */     int size = extensionPoints.size();
/* 143 */     ArrayList<IExtensionPoint> result = new ArrayList<>(size);
/* 144 */     for (int i = 0; i < size; i++) {
/* 145 */       Integer extPt = extensionPoints.get(i);
/* 146 */       IExtensionPoint extensionPoint = new ExtensionPointHandle(this.objectManager, extPt.intValue());
/* 147 */       result.add(extensionPoint);
/*     */     } 
/* 149 */     if (result.size() == 0)
/* 150 */       return null; 
/* 151 */     return result.<IExtensionPoint>toArray(new IExtensionPoint[result.size()]);
/*     */   }
/*     */   
/*     */   public IExtension[] getExtensions(String id) {
/* 155 */     List<Integer> extensions = null;
/* 156 */     if (id != null && this.extensionsByID != null) {
/* 157 */       extensions = this.extensionsByID.get(id);
/* 158 */     } else if (id == null) {
/* 159 */       extensions = this.allExtensions;
/*     */     } 
/* 161 */     if (extensions == null)
/* 162 */       return null; 
/* 163 */     int size = extensions.size();
/* 164 */     ArrayList<IExtension> result = new ArrayList<>(size);
/* 165 */     for (int i = 0; i < size; i++) {
/* 166 */       Integer ext = extensions.get(i);
/* 167 */       IExtension extension = new ExtensionHandle(this.objectManager, ext.intValue());
/* 168 */       result.add(extension);
/*     */     } 
/* 170 */     return result.<IExtension>toArray(new IExtension[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\CombinedEventDelta.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */