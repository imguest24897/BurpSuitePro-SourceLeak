/*     */ package org.eclipse.core.internal.registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegistryObject
/*     */   implements KeyedElement
/*     */ {
/*  22 */   private int objectId = RegistryObjectManager.UNKNOWN;
/*     */   
/*  24 */   protected int[] children = RegistryObjectManager.EMPTY_INT_ARRAY;
/*     */ 
/*     */   
/*  27 */   private int extraDataOffset = Integer.MIN_VALUE;
/*     */ 
/*     */   
/*     */   static final int EMPTY_MASK = -2147483648;
/*     */ 
/*     */   
/*     */   static final int PERSIST_MASK = 1073741824;
/*     */ 
/*     */   
/*     */   static final int OFFSET_MASK = 1073741823;
/*     */   
/*     */   protected ExtensionRegistry registry;
/*     */ 
/*     */   
/*     */   protected RegistryObject(ExtensionRegistry registry, boolean persist) {
/*  42 */     this.registry = registry;
/*  43 */     setPersist(persist);
/*     */   }
/*     */   
/*     */   void setRawChildren(int[] values) {
/*  47 */     this.children = values;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int[] getRawChildren() {
/*  52 */     return this.children;
/*     */   }
/*     */   
/*     */   void setObjectId(int value) {
/*  56 */     this.objectId = value;
/*     */   }
/*     */   
/*     */   protected int getObjectId() {
/*  60 */     return this.objectId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKeyHashCode() {
/*  66 */     return this.objectId;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getKey() {
/*  71 */     return Integer.valueOf(this.objectId);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean compare(KeyedElement other) {
/*  76 */     return (this.objectId == ((RegistryObject)other).objectId);
/*     */   }
/*     */   
/*     */   protected boolean shouldPersist() {
/*  80 */     return ((this.extraDataOffset & 0x40000000) == 1073741824);
/*     */   }
/*     */   
/*     */   private void setPersist(boolean persist) {
/*  84 */     if (persist) {
/*  85 */       this.extraDataOffset |= 0x40000000;
/*     */     } else {
/*  87 */       this.extraDataOffset &= 0xBFFFFFFF;
/*     */     } 
/*     */   }
/*     */   protected boolean noExtraData() {
/*  91 */     return ((this.extraDataOffset & Integer.MIN_VALUE) == Integer.MIN_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getExtraDataOffset() {
/*  96 */     if (noExtraData())
/*  97 */       return -1; 
/*  98 */     return this.extraDataOffset & 0x3FFFFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setExtraDataOffset(int offset) {
/* 103 */     if (offset == -1) {
/* 104 */       this.extraDataOffset &= 0xC0000000;
/* 105 */       this.extraDataOffset |= Integer.MIN_VALUE;
/*     */       
/*     */       return;
/*     */     } 
/* 109 */     if ((offset & 0x3FFFFFFF) != offset) {
/* 110 */       throw new IllegalArgumentException("Registry object: extra data offset is out of range");
/*     */     }
/* 112 */     this.extraDataOffset &= 0x40000000;
/* 113 */     this.extraDataOffset |= offset & 0x3FFFFFFF;
/*     */   }
/*     */   
/*     */   protected String getLocale() {
/* 117 */     return this.registry.getLocale();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.registry-3.11.200.jar!\org\eclipse\core\internal\registry\RegistryObject.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */