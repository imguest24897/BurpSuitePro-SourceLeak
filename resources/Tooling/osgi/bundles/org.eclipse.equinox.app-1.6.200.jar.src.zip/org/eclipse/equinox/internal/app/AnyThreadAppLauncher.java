/*    */ package org.eclipse.equinox.internal.app;
/*    */ 
/*    */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnyThreadAppLauncher
/*    */   implements Runnable
/*    */ {
/*    */   private EclipseAppHandle appHandle;
/*    */   
/*    */   private AnyThreadAppLauncher(EclipseAppHandle appHandle) {
/* 23 */     this.appHandle = appHandle;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 30 */       this.appHandle.run((Object)null);
/* 31 */     } catch (Throwable e) {
/* 32 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 4, 0, e.getMessage(), 0, e, null));
/*    */     } 
/*    */   }
/*    */   
/*    */   static void launchEclipseApplication(EclipseAppHandle appHandle) {
/* 37 */     AnyThreadAppLauncher launchable = new AnyThreadAppLauncher(appHandle);
/* 38 */     (new Thread(launchable, "app thread - " + appHandle.getInstanceId())).start();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\AnyThreadAppLauncher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */