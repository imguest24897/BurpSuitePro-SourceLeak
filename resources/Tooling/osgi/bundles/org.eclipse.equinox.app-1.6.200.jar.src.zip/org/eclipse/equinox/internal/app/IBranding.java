package org.eclipse.equinox.internal.app;

import org.osgi.framework.Bundle;

public interface IBranding {
  String getApplication();
  
  String getName();
  
  String getDescription();
  
  String getId();
  
  String getProperty(String paramString);
  
  Bundle getDefiningBundle();
  
  Object getProduct();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\IBranding.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */