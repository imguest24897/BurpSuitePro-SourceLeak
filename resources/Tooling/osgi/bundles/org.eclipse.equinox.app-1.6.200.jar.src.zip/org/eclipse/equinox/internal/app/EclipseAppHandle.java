/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.equinox.app.IApplication;
/*     */ import org.eclipse.equinox.app.IApplicationContext;
/*     */ import org.eclipse.osgi.service.runnable.ApplicationRunnable;
/*     */ import org.eclipse.osgi.service.runnable.StartupMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.application.ApplicationException;
/*     */ import org.osgi.service.application.ApplicationHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseAppHandle
/*     */   extends ApplicationHandle
/*     */   implements ApplicationRunnable, IApplicationContext
/*     */ {
/*     */   private static final int FLAG_STARTING = 1;
/*     */   private static final int FLAG_ACTIVE = 2;
/*     */   private static final int FLAG_STOPPING = 4;
/*     */   private static final int FLAG_STOPPED = 8;
/*     */   private static final String STARTING = "org.eclipse.equinox.app.starting";
/*     */   private static final String STOPPED = "org.eclipse.equinox.app.stopped";
/*     */   private static final String PROP_ECLIPSE_EXITCODE = "eclipse.exitcode";
/*  44 */   private static final Object NULL_RESULT = new Object();
/*     */   
/*     */   private volatile ServiceRegistration handleRegistration;
/*  47 */   private int status = 1;
/*     */   private final Map<String, Object> arguments;
/*     */   private Object application;
/*     */   private final Boolean defaultAppInstance;
/*     */   private Object result;
/*     */   private boolean setResult = false;
/*     */   private boolean setAsyncResult = false;
/*  54 */   private final boolean[] registrationLock = new boolean[] { true };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EclipseAppHandle(String instanceId, Map<String, Object> arguments, EclipseAppDescriptor descriptor) {
/*  60 */     super(instanceId, descriptor);
/*  61 */     this.defaultAppInstance = (arguments == null || arguments.get("eclipse.application.default") == null) ? Boolean.FALSE : (Boolean)arguments.remove("eclipse.application.default");
/*  62 */     if (arguments == null) {
/*  63 */       this.arguments = new HashMap<>(2);
/*     */     } else {
/*  65 */       this.arguments = new HashMap<>(arguments);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized String getState() {
/*  70 */     switch (this.status) {
/*     */       case 1:
/*  72 */         return "org.eclipse.equinox.app.starting";
/*     */       case 2:
/*  74 */         return "RUNNING";
/*     */       case 4:
/*  76 */         return "STOPPING";
/*     */     } 
/*     */ 
/*     */     
/*  80 */     if (getServiceRegistration() == null)
/*  81 */       throw new IllegalStateException(NLS.bind(Messages.application_error_state_stopped, getInstanceId())); 
/*  82 */     return "org.eclipse.equinox.app.stopped";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroySpecific() {
/*  90 */     setAppStatus(4);
/*     */     
/*  92 */     IApplication app = getApplication();
/*  93 */     if (app != null) {
/*  94 */       app.stop();
/*     */     }
/*  96 */     setAppStatus(8);
/*     */   }
/*     */   
/*     */   void setServiceRegistration(ServiceRegistration sr) {
/* 100 */     synchronized (this.registrationLock) {
/* 101 */       this.handleRegistration = sr;
/* 102 */       this.registrationLock[0] = (sr != null);
/* 103 */       this.registrationLock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   private ServiceRegistration getServiceRegistration() {
/* 108 */     synchronized (this.registrationLock) {
/* 109 */       if (this.handleRegistration == null && this.registrationLock[0]) {
/*     */         try {
/* 111 */           this.registrationLock.wait(1000L);
/* 112 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */ 
/*     */       
/* 116 */       return this.handleRegistration;
/*     */     } 
/*     */   }
/*     */   
/*     */   ServiceReference getServiceReference() {
/* 121 */     ServiceRegistration reg = getServiceRegistration();
/* 122 */     if (reg == null)
/* 123 */       return null; 
/*     */     try {
/* 125 */       return reg.getReference();
/* 126 */     } catch (IllegalStateException illegalStateException) {
/* 127 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Dictionary<String, Object> getServiceProperties() {
/* 135 */     Dictionary<String, Object> props = new Hashtable<>(6);
/* 136 */     props.put("service.pid", getInstanceId());
/* 137 */     props.put("application.state", getState());
/* 138 */     props.put("application.descriptor", getApplicationDescriptor().getApplicationId());
/* 139 */     props.put("eclipse.application.type", ((EclipseAppDescriptor)getApplicationDescriptor()).getThreadTypeString());
/* 140 */     props.put("application.supports.exitvalue", Boolean.TRUE);
/* 141 */     if (this.defaultAppInstance.booleanValue())
/* 142 */       props.put("eclipse.application.default", this.defaultAppInstance); 
/* 143 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void setAppStatus(int status) {
/* 151 */     if (this.status == status)
/*     */       return; 
/* 153 */     if ((status & 0x1) != 0) {
/* 154 */       throw new IllegalArgumentException("Cannot set app status to starting");
/*     */     }
/* 156 */     if ((status & 0x4) != 0 && (
/* 157 */       this.status & 0xC) != 0) {
/*     */       return;
/*     */     }
/* 160 */     this.status = status;
/* 161 */     ServiceRegistration handleReg = getServiceRegistration();
/* 162 */     if (handleReg == null)
/*     */       return; 
/* 164 */     handleReg.setProperties(getServiceProperties());
/*     */     
/* 166 */     if ((this.status & 0x8) != 0) {
/* 167 */       ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().unlock(this);
/* 168 */       handleReg.unregister();
/* 169 */       setServiceRegistration((ServiceRegistration)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Map getArguments() {
/* 175 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object run(Object context) throws Exception {
/* 180 */     if (context != null) {
/*     */       
/* 182 */       this.arguments.put("application.args", context);
/*     */     } else {
/*     */       
/* 185 */       context = this.arguments.get("application.args");
/* 186 */       if (context == null) {
/*     */         
/* 188 */         context = CommandLineArgs.getApplicationArgs();
/* 189 */         this.arguments.put("application.args", context);
/*     */       } 
/*     */     } 
/* 192 */     Object tempResult = null;
/*     */     try {
/*     */       Object app;
/* 195 */       synchronized (this) {
/* 196 */         if ((this.status & 0x5) == 0)
/* 197 */           throw new ApplicationException(3, NLS.bind(Messages.application_instance_stopped, getInstanceId())); 
/* 198 */         this.application = getConfiguration().createExecutableExtension("run");
/* 199 */         app = this.application;
/* 200 */         notifyAll();
/*     */       } 
/* 202 */       if (app instanceof IApplication) {
/* 203 */         tempResult = ((IApplication)app).start(this);
/*     */       } else {
/* 205 */         tempResult = EclipseAppContainer.callMethodWithException(app, "run", new Class[] { Object.class }, new Object[] { context });
/* 206 */       }  if (tempResult == null)
/* 207 */         tempResult = NULL_RESULT; 
/*     */     } finally {
/* 209 */       tempResult = setInternalResult(tempResult, false, (IApplication)null);
/*     */     } 
/*     */     
/* 212 */     if (Activator.DEBUG)
/* 213 */       System.out.println(NLS.bind(Messages.application_returned, (Object[])new String[] { getApplicationDescriptor().getApplicationId(), (tempResult == null) ? "null" : tempResult.toString() })); 
/* 214 */     return tempResult;
/*     */   }
/*     */   
/*     */   private synchronized Object setInternalResult(Object result, boolean isAsync, IApplication tokenApp) {
/* 218 */     if (this.setResult)
/* 219 */       throw new IllegalStateException("The result of the application is already set."); 
/* 220 */     if (isAsync) {
/* 221 */       if (!this.setAsyncResult)
/* 222 */         throw new IllegalStateException("The application must return IApplicationContext.EXIT_ASYNC_RESULT to set asynchronous results."); 
/* 223 */       if (this.application != tokenApp) {
/* 224 */         throw new IllegalArgumentException("The application is not the correct instance for this application context.");
/*     */       }
/* 226 */     } else if (result == IApplicationContext.EXIT_ASYNC_RESULT) {
/* 227 */       this.setAsyncResult = true;
/* 228 */       return NULL_RESULT;
/*     */     } 
/*     */     
/* 231 */     this.result = result;
/* 232 */     this.setResult = true;
/* 233 */     this.application = null;
/* 234 */     notifyAll();
/*     */     
/* 236 */     setAppStatus(4);
/* 237 */     setAppStatus(8);
/*     */ 
/*     */     
/* 240 */     if (isDefault() && result != null) {
/* 241 */       int exitCode = (result instanceof Integer) ? ((Integer)result).intValue() : 0;
/*     */       
/* 243 */       Activator.setProperty("eclipse.exitcode", Integer.toString(exitCode));
/*     */     } 
/* 245 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/*     */     try {
/* 251 */       destroy();
/* 252 */     } catch (IllegalStateException illegalStateException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applicationRunning() {
/* 262 */     setAppStatus(2);
/*     */     
/* 264 */     final ServiceReference[] monitors = getStartupMonitors();
/* 265 */     if (monitors == null)
/*     */       return; 
/* 267 */     SafeRunner.run(new ISafeRunnable()
/*     */         {
/*     */           public void handleException(Throwable e) {}
/*     */ 
/*     */           
/*     */           public void run() throws Exception {
/*     */             byte b;
/*     */             int i;
/*     */             ServiceReference[] arrayOfServiceReference;
/* 276 */             for (i = (arrayOfServiceReference = monitors).length, b = 0; b < i; ) { ServiceReference m = arrayOfServiceReference[b];
/* 277 */               StartupMonitor monitor = (StartupMonitor)Activator.getContext().getService(m);
/* 278 */               if (monitor != null) {
/* 279 */                 monitor.applicationRunning();
/* 280 */                 Activator.getContext().ungetService(m);
/*     */               } 
/*     */               b++; }
/*     */           
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private ServiceReference[] getStartupMonitors() {
/* 290 */     ServiceReference[] refs = null;
/*     */     try {
/* 292 */       refs = Activator.getContext().getServiceReferences(StartupMonitor.class.getName(), null);
/* 293 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/* 296 */     if (refs == null || refs.length == 0) {
/* 297 */       return null;
/*     */     }
/* 299 */     Arrays.sort(refs, new Comparator<ServiceReference>()
/*     */         {
/*     */           
/*     */           public int compare(ServiceReference ref1, ServiceReference ref2)
/*     */           {
/* 304 */             Object property = ref1.getProperty("service.ranking");
/* 305 */             int rank1 = (property instanceof Integer) ? ((Integer)property).intValue() : 0;
/* 306 */             property = ref2.getProperty("service.ranking");
/* 307 */             int rank2 = (property instanceof Integer) ? ((Integer)property).intValue() : 0;
/* 308 */             if (rank1 != rank2) {
/* 309 */               return (rank1 > rank2) ? -1 : 1;
/*     */             }
/* 311 */             long id1 = ((Long)ref1.getProperty("service.id")).longValue();
/* 312 */             long id2 = ((Long)ref2.getProperty("service.id")).longValue();
/* 313 */             return (id2 > id1) ? -1 : 1;
/*     */           }
/*     */         });
/* 316 */     return refs;
/*     */   }
/*     */   
/*     */   private synchronized IApplication getApplication() {
/* 320 */     if (this.handleRegistration != null && this.application == null) {
/*     */       
/*     */       try {
/*     */         
/* 324 */         wait(5000L);
/* 325 */       } catch (InterruptedException interruptedException) {}
/*     */     }
/*     */     
/* 328 */     return (this.application instanceof IApplication) ? (IApplication)this.application : null;
/*     */   }
/*     */   
/*     */   private IConfigurationElement getConfiguration() {
/* 332 */     IExtension applicationExtension = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getAppExtension(getApplicationDescriptor().getApplicationId());
/* 333 */     if (applicationExtension == null)
/* 334 */       throw new RuntimeException(NLS.bind(Messages.application_notFound, getApplicationDescriptor().getApplicationId(), ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getAvailableAppsMsg())); 
/* 335 */     IConfigurationElement[] configs = applicationExtension.getConfigurationElements();
/* 336 */     if (configs.length == 0)
/* 337 */       throw new RuntimeException(NLS.bind(Messages.application_invalidExtension, getApplicationDescriptor().getApplicationId())); 
/* 338 */     return configs[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBrandingApplication() {
/* 343 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 344 */     return (branding == null) ? null : branding.getApplication();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBrandingBundle() {
/* 349 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 350 */     return (branding == null) ? null : branding.getDefiningBundle();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBrandingDescription() {
/* 356 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 357 */     return (branding == null) ? null : branding.getDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBrandingId() {
/* 363 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 364 */     return (branding == null) ? null : branding.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBrandingName() {
/* 369 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 370 */     return (branding == null) ? null : branding.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBrandingProperty(String key) {
/* 376 */     IBranding branding = ((EclipseAppDescriptor)getApplicationDescriptor()).getContainerManager().getBranding();
/* 377 */     return (branding == null) ? null : branding.getProperty(key);
/*     */   }
/*     */   
/*     */   boolean isDefault() {
/* 381 */     return this.defaultAppInstance.booleanValue();
/*     */   }
/*     */   
/*     */   public synchronized Object waitForResult(int timeout) {
/*     */     try {
/* 386 */       return getExitValue(timeout);
/* 387 */     } catch (ApplicationException|InterruptedException applicationException) {
/*     */ 
/*     */       
/* 390 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized Object getExitValue(long timeout) throws ApplicationException, InterruptedException {
/* 395 */     if (this.handleRegistration == null && this.application == null)
/* 396 */       return this.result; 
/* 397 */     long startTime = System.currentTimeMillis();
/* 398 */     long delay = timeout;
/* 399 */     while (!this.setResult && (delay > 0L || timeout == 0L)) {
/* 400 */       wait(delay);
/* 401 */       if (timeout > 0L)
/* 402 */         delay -= System.currentTimeMillis() - startTime; 
/*     */     } 
/* 404 */     if (this.result == null)
/* 405 */       throw new ApplicationException(6); 
/* 406 */     if (this.result == NULL_RESULT)
/* 407 */       return null; 
/* 408 */     return this.result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResult(Object result, IApplication application) {
/* 413 */     setInternalResult((result == null) ? NULL_RESULT : result, true, application);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\EclipseAppHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */