/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandLineArgs
/*     */ {
/*     */   private static final String NO_PACKAGE_PREFIXES = "-noPackagePrefixes";
/*     */   private static final String NO_UPDATE = "-noUpdate";
/*     */   private static final String BOOT = "-boot";
/*     */   private static final String CLASSLOADER_PROPERTIES = "-classloaderProperties";
/*     */   private static final String PLUGINS = "-plugins";
/*     */   private static final String FIRST_USE = "-firstUse";
/*     */   private static final String NEW_UPDATES = "-newUpdates";
/*     */   private static final String UPDATE = "-update";
/*     */   private static final String PASSWORD = "-password";
/*     */   private static final String KEYRING = "-keyring";
/*     */   private static final String PLUGIN_CUSTOMIZATION = "-pluginCustomization";
/*     */   private static final String PRODUCT = "-product";
/*     */   private static final String FEATURE = "-feature";
/*     */   private static final String APPLICATION = "-application";
/*  39 */   private static String[] appArgs = new String[0];
/*  40 */   private static String[] allArgs = new String[0];
/*     */   private static String product;
/*     */   private static String application;
/*     */   
/*     */   static String[] processCommandLine(EnvironmentInfo envInfo) {
/*  45 */     String[] args = envInfo.getNonFrameworkArgs();
/*  46 */     if (args == null)
/*  47 */       return args; 
/*  48 */     if (args.length == 0)
/*  49 */       return args; 
/*  50 */     allArgs = args;
/*  51 */     int[] configArgs = new int[args.length];
/*     */     
/*  53 */     configArgs[0] = -1;
/*  54 */     int configArgIndex = 0;
/*  55 */     for (int i = 0; i < args.length; i++) {
/*  56 */       boolean found = false;
/*     */ 
/*     */ 
/*     */       
/*  60 */       if (args[i].equalsIgnoreCase("-classloaderProperties"))
/*  61 */         found = true; 
/*  62 */       if (args[i].equalsIgnoreCase("-noPackagePrefixes"))
/*  63 */         found = true; 
/*  64 */       if (args[i].equalsIgnoreCase("-plugins"))
/*  65 */         found = true; 
/*  66 */       if (args[i].equalsIgnoreCase("-firstUse"))
/*  67 */         found = true; 
/*  68 */       if (args[i].equalsIgnoreCase("-noUpdate"))
/*  69 */         found = true; 
/*  70 */       if (args[i].equalsIgnoreCase("-newUpdates"))
/*  71 */         found = true; 
/*  72 */       if (args[i].equalsIgnoreCase("-update"))
/*  73 */         found = true; 
/*  74 */       if (args[i].equalsIgnoreCase("-boot"))
/*  75 */         found = true; 
/*  76 */       if (args[i].equalsIgnoreCase("-keyring"))
/*  77 */         found = true; 
/*  78 */       if (args[i].equalsIgnoreCase("-password"))
/*  79 */         found = true; 
/*  80 */       if (args[i].equalsIgnoreCase("-pluginCustomization")) {
/*  81 */         found = true;
/*     */       }
/*     */       
/*  84 */       if (found) {
/*  85 */         configArgs[configArgIndex++] = i;
/*     */         
/*  87 */         if (i < args.length - 1 && !args[i + 1].startsWith("-")) {
/*  88 */           configArgs[configArgIndex++] = ++i;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  93 */       else if (i != args.length - 1 && !args[i + 1].startsWith("-")) {
/*     */         
/*  95 */         String arg = args[++i];
/*     */ 
/*     */ 
/*     */         
/*  99 */         if (args[i - 1].equalsIgnoreCase("-product") || args[i - 1].equalsIgnoreCase("-feature")) {
/* 100 */           product = arg;
/* 101 */           envInfo.setProperty("eclipse.product", product);
/* 102 */           found = true;
/*     */         } 
/*     */ 
/*     */         
/* 106 */         if (args[i - 1].equalsIgnoreCase("-application")) {
/* 107 */           application = arg;
/* 108 */           envInfo.setProperty("eclipse.application", application);
/* 109 */           found = true;
/*     */         } 
/*     */ 
/*     */         
/* 113 */         if (found) {
/* 114 */           configArgs[configArgIndex++] = i - 1;
/* 115 */           configArgs[configArgIndex++] = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     if (configArgIndex == 0) {
/* 121 */       appArgs = args;
/* 122 */       return args;
/*     */     } 
/* 124 */     appArgs = new String[args.length - configArgIndex];
/* 125 */     configArgIndex = 0;
/* 126 */     int j = 0;
/* 127 */     for (int k = 0; k < args.length; k++) {
/* 128 */       if (k == configArgs[configArgIndex]) {
/* 129 */         configArgIndex++;
/*     */       } else {
/* 131 */         appArgs[j++] = args[k];
/*     */       } 
/* 133 */     }  return appArgs;
/*     */   }
/*     */   
/*     */   static String getApplication() {
/* 137 */     return application;
/*     */   }
/*     */   
/*     */   static String getProduct() {
/* 141 */     return product;
/*     */   }
/*     */   
/*     */   public static String[] getApplicationArgs() {
/* 145 */     return appArgs;
/*     */   }
/*     */   
/*     */   public static String[] getAllArgs() {
/* 149 */     return allArgs;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\CommandLineArgs.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */