/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.security.Guard;
/*     */ import java.security.GuardedObject;
/*     */ import java.security.Permission;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.application.ApplicationDescriptor;
/*     */ import org.osgi.service.application.ScheduledApplication;
/*     */ import org.osgi.service.event.Event;
/*     */ import org.osgi.service.event.EventHandler;
/*     */ import org.osgi.service.event.TopicPermission;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseScheduledApplication
/*     */   implements ScheduledApplication, EventHandler
/*     */ {
/*  30 */   private static final String FILTER_PREFIX = "(&(objectclass=" + ApplicationDescriptor.class.getName() + ")(" + "service.pid" + "=";
/*     */   
/*     */   private static final String FILTER_POSTFIX = "))";
/*     */   private boolean recurring;
/*     */   private String topic;
/*     */   private String eventFilter;
/*     */   private Map<String, Object> args;
/*     */   private String appPid;
/*     */   private String id;
/*     */   private ServiceRegistration sr;
/*     */   private ServiceTracker appTracker;
/*     */   private boolean removed = false;
/*     */   
/*     */   EclipseScheduledApplication(BundleContext context, String id, String appPid, Map<String, Object> args, String topic, String eventFilter, boolean recurring) throws InvalidSyntaxException {
/*  44 */     this.id = id;
/*  45 */     this.appPid = appPid;
/*  46 */     this.args = args;
/*  47 */     this.topic = (topic == null || topic.trim().equals("") || topic.trim().equals("*")) ? null : topic;
/*  48 */     this.eventFilter = eventFilter;
/*  49 */     this.recurring = recurring;
/*  50 */     this.appTracker = new ServiceTracker(context, context.createFilter(String.valueOf(FILTER_PREFIX) + appPid + "))"), null);
/*  51 */     Activator.openTracker(this.appTracker, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getScheduleId() {
/*  56 */     return this.id;
/*     */   }
/*     */   
/*     */   String getAppPid() {
/*  60 */     return this.appPid;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String getTopic() {
/*  65 */     if (this.removed)
/*  66 */       throw new IllegalStateException(Messages.scheduled_app_removed); 
/*  67 */     return this.topic;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String getEventFilter() {
/*  72 */     if (this.removed)
/*  73 */       throw new IllegalStateException(Messages.scheduled_app_removed); 
/*  74 */     return this.eventFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isRecurring() {
/*  79 */     if (this.removed)
/*  80 */       throw new IllegalStateException(Messages.scheduled_app_removed); 
/*  81 */     return this.recurring;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ApplicationDescriptor getApplicationDescriptor() {
/*  86 */     if (this.removed)
/*  87 */       throw new IllegalStateException(Messages.scheduled_app_removed); 
/*  88 */     return (ApplicationDescriptor)Activator.getService(this.appTracker);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Map<String, Object> getArguments() {
/*  93 */     if (this.removed)
/*  94 */       throw new IllegalStateException(Messages.scheduled_app_removed); 
/*  95 */     return (this.args == null) ? null : new HashMap<>(this.args);
/*     */   }
/*     */   
/*     */   private Map<String, Object> getArguments(Event trigger) {
/*  99 */     Map<String, Object> result = (this.args == null) ? new HashMap<>() : getArguments();
/* 100 */     result.put("org.osgi.triggeringevent", new GuardedObject(trigger, new TriggerGuard(trigger.getTopic())));
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void remove() {
/* 106 */     if (this.removed)
/*     */       return; 
/* 108 */     this.removed = true;
/* 109 */     AppPersistence.removeScheduledApp(this);
/* 110 */     if (this.sr != null)
/* 111 */       this.sr.unregister(); 
/* 112 */     this.sr = null;
/* 113 */     this.appTracker.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void handleEvent(Event event) {
/*     */     try {
/* 119 */       if (this.removed)
/*     */         return; 
/* 121 */       ApplicationDescriptor desc = getApplicationDescriptor();
/* 122 */       if (desc == null) {
/*     */         return;
/*     */       }
/*     */       
/* 126 */       desc.launch(getArguments(event));
/* 127 */     } catch (Exception e) {
/* 128 */       String message = NLS.bind(Messages.scheduled_app_launch_error, this.sr);
/* 129 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 2, 0, message, 0, e, null));
/*     */       return;
/*     */     } 
/* 132 */     if (!isRecurring())
/* 133 */       remove(); 
/*     */   }
/*     */   
/*     */   synchronized void setServiceRegistration(ServiceRegistration sr) {
/* 137 */     this.sr = sr;
/* 138 */     if (this.removed) {
/* 139 */       sr.unregister();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class TriggerGuard
/*     */     implements Guard
/*     */   {
/*     */     String eventTopic;
/*     */     
/*     */     public TriggerGuard(String topic) {
/* 150 */       this.eventTopic = topic;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkGuard(Object object) throws SecurityException {
/* 158 */       SecurityManager sm = System.getSecurityManager();
/* 159 */       if (sm != null)
/* 160 */         sm.checkPermission((Permission)new TopicPermission(this.eventTopic, "subscribe")); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\EclipseScheduledApplication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */