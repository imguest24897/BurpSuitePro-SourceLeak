/*    */ package org.eclipse.equinox.app;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IApplication
/*    */ {
/* 33 */   public static final Integer EXIT_OK = Integer.valueOf(0);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public static final Integer EXIT_RESTART = Integer.valueOf(23);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public static final Integer EXIT_RELAUNCH = Integer.valueOf(24);
/*    */   
/*    */   Object start(IApplicationContext paramIApplicationContext) throws Exception;
/*    */   
/*    */   void stop();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\app\IApplication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */