/*    */ package org.eclipse.equinox.internal.app;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProviderExtensionBranding
/*    */   implements IBranding
/*    */ {
/*    */   Object product;
/*    */   
/*    */   public ProviderExtensionBranding(Object product) {
/* 22 */     this.product = product;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getApplication() {
/* 27 */     return (String)EclipseAppContainer.callMethod(this.product, "getApplication", null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Bundle getDefiningBundle() {
/* 32 */     return (Bundle)EclipseAppContainer.callMethod(this.product, "getDefiningBundle", null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 37 */     return (String)EclipseAppContainer.callMethod(this.product, "getDescription", null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 42 */     return (String)EclipseAppContainer.callMethod(this.product, "getId", null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 47 */     return (String)EclipseAppContainer.callMethod(this.product, "getName", null, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProperty(String key) {
/* 52 */     return (String)EclipseAppContainer.callMethod(this.product, "getProperty", new Class[] { String.class }, new Object[] { key });
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProduct() {
/* 57 */     return this.product;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\ProviderExtensionBranding.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */