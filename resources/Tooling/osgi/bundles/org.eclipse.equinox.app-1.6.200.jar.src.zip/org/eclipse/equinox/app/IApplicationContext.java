/*    */ package org.eclipse.equinox.app;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IApplicationContext
/*    */ {
/*    */   public static final String EXIT_DATA_PROPERTY = "eclipse.exitdata";
/*    */   public static final String APPLICATION_ARGS = "application.args";
/* 74 */   public static final Object EXIT_ASYNC_RESULT = new Object();
/*    */   
/*    */   Map getArguments();
/*    */   
/*    */   void applicationRunning();
/*    */   
/*    */   String getBrandingApplication();
/*    */   
/*    */   String getBrandingName();
/*    */   
/*    */   String getBrandingDescription();
/*    */   
/*    */   String getBrandingId();
/*    */   
/*    */   String getBrandingProperty(String paramString);
/*    */   
/*    */   Bundle getBrandingBundle();
/*    */   
/*    */   void setResult(Object paramObject, IApplication paramIApplication);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\app\IApplicationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */