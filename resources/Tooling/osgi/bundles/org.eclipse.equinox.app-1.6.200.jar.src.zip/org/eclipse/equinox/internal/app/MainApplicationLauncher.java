/*    */ package org.eclipse.equinox.internal.app;
/*    */ 
/*    */ import org.eclipse.osgi.service.runnable.ApplicationRunnable;
/*    */ import org.osgi.service.application.ApplicationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MainApplicationLauncher
/*    */   implements ApplicationRunnable
/*    */ {
/*    */   private final EclipseAppContainer appContainer;
/*    */   private ApplicationRunnable launchMainApp;
/*    */   
/*    */   public MainApplicationLauncher(EclipseAppContainer appContainer) {
/* 28 */     this.appContainer = appContainer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run(Object context) throws Exception {
/* 33 */     this.appContainer.startDefaultApp(false);
/* 34 */     ApplicationRunnable mainHandle = getMainHandle();
/* 35 */     if (mainHandle != null)
/* 36 */       return mainHandle.run(context); 
/* 37 */     throw new ApplicationException(3, Messages.application_noIdFound);
/*    */   }
/*    */   
/*    */   private synchronized ApplicationRunnable getMainHandle() {
/* 41 */     return this.launchMainApp;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 47 */     ApplicationRunnable handle = getMainHandle();
/* 48 */     if (handle != null)
/* 49 */       handle.stop(); 
/*    */   }
/*    */   
/*    */   synchronized void launch(ApplicationRunnable app) {
/* 53 */     this.launchMainApp = app;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\MainApplicationLauncher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */