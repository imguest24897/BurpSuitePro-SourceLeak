/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.framework.console.CommandInterpreter;
/*     */ import org.eclipse.osgi.framework.console.CommandProvider;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.application.ApplicationDescriptor;
/*     */ import org.osgi.service.application.ApplicationHandle;
/*     */ import org.osgi.service.application.ScheduledApplication;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppCommands
/*     */   implements CommandProvider
/*     */ {
/*     */   private static final String LAUNCHABLE_APP_FILTER = "(&(application.locked=false)(application.launchable=true)(application.visible=true))";
/*     */   private static final String ACTIVE_APP_FILTER = "(!(application.state=STOPPING))";
/*     */   private static final String LOCKED_APP_FILTER = "(application.locked=true)";
/*     */   private static final String NEW_LINE = "\r\n";
/*     */   private static final String TAB = "\t";
/*  34 */   private Map<String, String[]> commandsHelp = null;
/*     */   
/*     */   private static AppCommands instance;
/*     */   private BundleContext context;
/*     */   private ServiceTracker applicationDescriptors;
/*     */   private ServiceTracker applicationHandles;
/*     */   private ServiceTracker scheduledApplications;
/*     */   private Filter launchableApp;
/*     */   private Filter activeApp;
/*     */   private Filter lockedApp;
/*     */   private ServiceRegistration providerRegistration;
/*     */   
/*     */   static synchronized void create(BundleContext context) {
/*  47 */     if (instance != null)
/*     */       return; 
/*  49 */     instance = new AppCommands();
/*  50 */     instance.start(context);
/*     */   }
/*     */   
/*     */   static synchronized void destroy(BundleContext context) {
/*  54 */     if (instance == null)
/*     */       return; 
/*  56 */     instance.stop(context);
/*  57 */     instance = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext ctx) {
/*  65 */     this.context = ctx;
/*     */     try {
/*  67 */       this.applicationDescriptors = new ServiceTracker(ctx, ApplicationDescriptor.class.getName(), null);
/*  68 */       this.applicationDescriptors.open();
/*  69 */       this.applicationHandles = new ServiceTracker(ctx, ApplicationHandle.class.getName(), null);
/*  70 */       this.applicationHandles.open();
/*  71 */       this.scheduledApplications = new ServiceTracker(ctx, ScheduledApplication.class.getName(), null);
/*  72 */       this.scheduledApplications.open();
/*  73 */       this.launchableApp = ctx.createFilter("(&(application.locked=false)(application.launchable=true)(application.visible=true))");
/*  74 */       this.activeApp = ctx.createFilter("(!(application.state=STOPPING))");
/*  75 */       this.lockedApp = ctx.createFilter("(application.locked=true)");
/*  76 */       this.providerRegistration = ctx.registerService(CommandProvider.class.getName(), this, null);
/*  77 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext ctx) {
/*  83 */     this.providerRegistration.unregister();
/*  84 */     if (this.applicationDescriptors != null)
/*  85 */       this.applicationDescriptors.close(); 
/*  86 */     if (this.applicationHandles != null)
/*  87 */       this.applicationHandles.close(); 
/*  88 */     if (this.scheduledApplications != null) {
/*  89 */       this.scheduledApplications.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHelp() {
/*  94 */     return getHelp(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getHelp(String commandName) {
/* 102 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 104 */     if (this.commandsHelp == null) {
/* 105 */       initializeCommandsHelp();
/*     */     }
/*     */     
/* 108 */     if (commandName != null) {
/* 109 */       if (this.commandsHelp.containsKey(commandName)) {
/* 110 */         addCommand(commandName, this.commandsHelp.get(commandName), sb);
/*     */       }
/* 112 */       return sb.toString();
/*     */     } 
/*     */     
/* 115 */     addHeader(Messages.console_help_app_commands_header, sb);
/* 116 */     for (Map.Entry<String, String[]> entry : this.commandsHelp.entrySet()) {
/* 117 */       String command = entry.getKey();
/* 118 */       String[] attributes = entry.getValue();
/* 119 */       addCommand(command, attributes, sb);
/*     */     } 
/*     */     
/* 122 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private void initializeCommandsHelp() {
/* 126 */     this.commandsHelp = (Map)new LinkedHashMap<>();
/* 127 */     this.commandsHelp.put("activeApps", new String[] { Messages.console_help_activeapps_description });
/* 128 */     this.commandsHelp.put("apps", new String[] { Messages.console_help_apps_description });
/* 129 */     this.commandsHelp.put("lockApp", new String[] { Messages.console_help_arguments, Messages.console_help_lockapp_description });
/* 130 */     this.commandsHelp.put("schedApp", new String[] { Messages.console_help_schedapp_arguments, Messages.console_help_schedapp_description });
/* 131 */     this.commandsHelp.put("startApp", new String[] { Messages.console_help_arguments, Messages.console_help_startapp_description });
/* 132 */     this.commandsHelp.put("stopApp", new String[] { Messages.console_help_arguments, Messages.console_help_stopapp_description });
/* 133 */     this.commandsHelp.put("unlockApp", new String[] { Messages.console_help_arguments, Messages.console_help_unlockapp_description });
/* 134 */     this.commandsHelp.put("unschedApp", new String[] { Messages.console_help_arguments, Messages.console_help_unschedapp_description });
/*     */   }
/*     */ 
/*     */   
/*     */   private void addHeader(String header, StringBuffer help) {
/* 139 */     help.append("---");
/* 140 */     help.append(header);
/* 141 */     help.append("---");
/* 142 */     help.append("\r\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCommand(String command, String description, StringBuffer help) {
/* 147 */     help.append("\t");
/* 148 */     help.append(command);
/* 149 */     help.append(" - ");
/* 150 */     help.append(description);
/* 151 */     help.append("\r\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCommand(String command, String parameters, String description, StringBuffer help) {
/* 156 */     help.append("\t");
/* 157 */     help.append(command);
/* 158 */     help.append(" ");
/* 159 */     help.append(parameters);
/* 160 */     help.append(" - ");
/* 161 */     help.append(description);
/* 162 */     help.append("\r\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCommand(String command, String[] attributes, StringBuffer help) {
/* 167 */     if (attributes.length == 1) {
/* 168 */       addCommand(command, attributes[0], help);
/* 169 */     } else if (attributes.length == 2) {
/* 170 */       addCommand(command, attributes[0], attributes[1], help);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Dictionary<String, Object> getServiceProps(ServiceReference ref) {
/* 175 */     String[] keys = ref.getPropertyKeys();
/* 176 */     Hashtable<String, Object> props = new Hashtable<>(keys.length); byte b; int i; String[] arrayOfString1;
/* 177 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 178 */       props.put(key, ref.getProperty(key)); b++; }
/*     */     
/* 180 */     return props;
/*     */   }
/*     */   
/*     */   public void _apps(CommandInterpreter intp) {
/* 184 */     ServiceReference[] apps = this.applicationDescriptors.getServiceReferences();
/* 185 */     if (apps == null) {
/* 186 */       intp.println("No applications found."); return;
/*     */     }  byte b; int i;
/*     */     ServiceReference[] arrayOfServiceReference1;
/* 189 */     for (i = (arrayOfServiceReference1 = apps).length, b = 0; b < i; ) { ServiceReference app = arrayOfServiceReference1[b];
/* 190 */       String application = (String)app.getProperty("service.pid");
/* 191 */       intp.print(application);
/*     */       
/* 193 */       if (getApplication(this.applicationHandles.getServiceReferences(), application, "application.descriptor", true) != null) {
/* 194 */         intp.print(" [running]");
/*     */       }
/* 196 */       if (getApplication(this.scheduledApplications.getServiceReferences(), application, "service.pid", true) != null)
/* 197 */         intp.print(" [scheduled]"); 
/* 198 */       if (!this.launchableApp.match(getServiceProps(app))) {
/* 199 */         intp.print(" [not launchable]");
/*     */       } else {
/* 201 */         intp.print(" [launchable]");
/*     */       } 
/* 203 */       if (this.lockedApp.match(getServiceProps(app))) {
/* 204 */         intp.print(" [locked]");
/*     */       }
/* 206 */       intp.println();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public void _activeApps(CommandInterpreter intp) {
/* 211 */     ServiceReference[] active = this.applicationHandles.getServiceReferences();
/* 212 */     if (active == null) {
/* 213 */       intp.println("No active applications found"); return;
/*     */     }  byte b; int i;
/*     */     ServiceReference[] arrayOfServiceReference1;
/* 216 */     for (i = (arrayOfServiceReference1 = active).length, b = 0; b < i; ) { ServiceReference r = arrayOfServiceReference1[b];
/* 217 */       intp.print(r.getProperty("service.pid"));
/* 218 */       intp.print(" [");
/* 219 */       intp.print(this.activeApp.match(getServiceProps(r)) ? "running" : "stopping");
/* 220 */       intp.println("]");
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private ServiceReference getApplication(ServiceReference[] apps, String targetId, String idKey, boolean perfectMatch) {
/* 225 */     if (apps == null || targetId == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     ServiceReference result = null;
/* 229 */     boolean ambigous = false; byte b; int i; ServiceReference[] arrayOfServiceReference;
/* 230 */     for (i = (arrayOfServiceReference = apps).length, b = 0; b < i; ) { ServiceReference app = arrayOfServiceReference[b];
/* 231 */       String id = (String)app.getProperty(idKey);
/* 232 */       if (targetId.equals(id)) {
/* 233 */         return app;
/*     */       }
/* 235 */       if (!perfectMatch)
/*     */       {
/* 237 */         if (id.contains(targetId)) {
/* 238 */           if (result != null)
/* 239 */             ambigous = true; 
/* 240 */           result = app;
/*     */         }  }  b++; }
/*     */     
/* 243 */     return ambigous ? null : result;
/*     */   }
/*     */   
/*     */   public void _startApp(CommandInterpreter intp) throws Exception {
/* 247 */     String appId = intp.nextArgument();
/* 248 */     ServiceReference application = getApplication(this.applicationDescriptors.getServiceReferences(), appId, "service.pid", false);
/* 249 */     if (application == null) {
/* 250 */       intp.println("\"" + appId + "\" does not exist or is ambigous.");
/*     */     } else {
/* 252 */       ArrayList<String> argList = new ArrayList<>();
/* 253 */       String arg = null;
/* 254 */       while ((arg = intp.nextArgument()) != null)
/* 255 */         argList.add(arg); 
/* 256 */       String[] args = (argList.size() == 0) ? null : argList.<String>toArray(new String[argList.size()]);
/*     */       try {
/* 258 */         HashMap<String, Object> launchArgs = new HashMap<>(1);
/* 259 */         if (args != null)
/* 260 */           launchArgs.put("application.args", args); 
/* 261 */         ApplicationDescriptor appDesc = (ApplicationDescriptor)this.context.getService(application);
/* 262 */         ApplicationHandle handle = appDesc.launch(launchArgs);
/* 263 */         intp.println("Launched application instance: " + handle.getInstanceId());
/*     */       } finally {
/* 265 */         this.context.ungetService(application);
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void _stopApp(CommandInterpreter intp) throws Exception {
/* 272 */     String appId = intp.nextArgument();
/*     */     
/* 274 */     ServiceReference application = getApplication(this.applicationHandles.getServiceReferences(), appId, "service.pid", false);
/* 275 */     if (application == null)
/* 276 */       application = getApplication(this.applicationHandles.getServiceReferences(), appId, "application.descriptor", false); 
/* 277 */     if (application == null) {
/* 278 */       intp.println("\"" + appId + "\" does not exist, is not running or is ambigous.");
/*     */     } else {
/* 280 */       if (this.activeApp.match(getServiceProps(application))) {
/*     */         try {
/* 282 */           ApplicationHandle appHandle = (ApplicationHandle)this.context.getService(application);
/* 283 */           appHandle.destroy();
/* 284 */           intp.println("Stopped application instance: " + appHandle.getInstanceId());
/*     */         } finally {
/* 286 */           this.context.ungetService(application);
/*     */         } 
/*     */       } else {
/* 289 */         intp.println("Application instance is already stopping: " + application.getProperty("service.pid"));
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void _lockApp(CommandInterpreter intp) throws Exception {
/* 296 */     String appId = intp.nextArgument();
/* 297 */     ServiceReference application = getApplication(this.applicationDescriptors.getServiceReferences(), appId, "service.pid", false);
/* 298 */     if (application == null) {
/* 299 */       intp.println("\"" + appId + "\" does not exist or is ambigous.");
/*     */     } else {
/*     */       try {
/* 302 */         ApplicationDescriptor appDesc = (ApplicationDescriptor)this.context.getService(application);
/* 303 */         appDesc.lock();
/* 304 */         intp.println("Locked application: " + appDesc.getApplicationId());
/*     */       } finally {
/* 306 */         this.context.ungetService(application);
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void _unlockApp(CommandInterpreter intp) throws Exception {
/* 313 */     String appId = intp.nextArgument();
/* 314 */     ServiceReference application = getApplication(this.applicationDescriptors.getServiceReferences(), appId, "service.pid", false);
/* 315 */     if (application == null) {
/* 316 */       intp.println("\"" + appId + "\" does not exist or is ambigous.");
/*     */     } else {
/*     */       try {
/* 319 */         ApplicationDescriptor appDesc = (ApplicationDescriptor)this.context.getService(application);
/* 320 */         appDesc.unlock();
/* 321 */         intp.println("Unlocked application: " + appDesc.getApplicationId());
/*     */       } finally {
/* 323 */         this.context.ungetService(application);
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void _schedApp(CommandInterpreter intp) throws Exception {
/* 330 */     String appId = intp.nextArgument();
/* 331 */     ServiceReference application = getApplication(this.applicationDescriptors.getServiceReferences(), appId, "service.pid", false);
/* 332 */     if (application == null) {
/* 333 */       intp.println("\"" + appId + "\" does not exist or is ambigous.");
/*     */     } else {
/*     */       try {
/* 336 */         ApplicationDescriptor appDesc = (ApplicationDescriptor)this.context.getService(application);
/* 337 */         String filter = intp.nextArgument();
/* 338 */         boolean recure = Boolean.valueOf(intp.nextArgument()).booleanValue();
/* 339 */         appDesc.schedule(null, null, "org/osgi/application/timer", filter, recure);
/* 340 */         intp.println("Scheduled application: " + appDesc.getApplicationId());
/*     */       } finally {
/* 342 */         this.context.ungetService(application);
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void _unschedApp(CommandInterpreter intp) throws Exception {
/* 349 */     String appId = intp.nextArgument();
/* 350 */     ServiceReference application = getApplication(this.scheduledApplications.getServiceReferences(), appId, "service.pid", false);
/* 351 */     if (application == null) {
/* 352 */       intp.println("\"" + appId + "\" does not exist or is ambigous.");
/*     */     } else {
/*     */       try {
/* 355 */         ScheduledApplication schedApp = (ScheduledApplication)this.context.getService(application);
/* 356 */         schedApp.remove();
/* 357 */         intp.println("Unscheduled application: " + application.getProperty("service.pid"));
/*     */       } finally {
/* 359 */         this.context.ungetService(application);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object _help(CommandInterpreter intp) {
/* 371 */     String commandName = intp.nextArgument();
/* 372 */     if (commandName == null) {
/* 373 */       return Boolean.FALSE;
/*     */     }
/* 375 */     String help = getHelp(commandName);
/*     */     
/* 377 */     if (help.length() > 0) {
/* 378 */       return help;
/*     */     }
/* 380 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\AppCommands.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */