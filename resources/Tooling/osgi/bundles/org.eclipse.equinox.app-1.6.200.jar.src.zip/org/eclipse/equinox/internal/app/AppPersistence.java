/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.storagemanager.StorageManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.application.ApplicationDescriptor;
/*     */ import org.osgi.service.application.ApplicationException;
/*     */ import org.osgi.service.application.ScheduledApplication;
/*     */ import org.osgi.service.event.Event;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppPersistence
/*     */   implements ServiceTrackerCustomizer
/*     */ {
/*     */   private static final String PROP_CONFIG_AREA = "osgi.configuration.area";
/*     */   private static final String FILTER_PREFIX = "(&(objectClass=org.eclipse.osgi.service.datalocation.Location)(type=";
/*     */   private static final String FILE_APPLOCKS = ".locks";
/*     */   private static final String FILE_APPSCHEDULED = ".scheduled";
/*     */   private static final String EVENT_HANDLER = "org.osgi.service.event.EventHandler";
/*     */   private static final int DATA_VERSION = 2;
/*     */   private static final byte NULL = 0;
/*     */   private static final int OBJECT = 1;
/*     */   private static BundleContext context;
/*     */   private static ServiceTracker configTracker;
/*     */   private static Location configLocation;
/*  49 */   private static Collection<String> locks = new ArrayList<>();
/*  50 */   private static Map<String, EclipseScheduledApplication> scheduledApps = new HashMap<>();
/*  51 */   static ArrayList<EclipseScheduledApplication> timerApps = new ArrayList<>();
/*     */   private static StorageManager storageManager;
/*     */   private static boolean scheduling = false;
/*     */   static boolean shutdown = false;
/*  55 */   private static int nextScheduledID = 1;
/*     */   private static Thread timerThread;
/*     */   
/*     */   static void start(BundleContext bc) {
/*  59 */     context = bc;
/*  60 */     shutdown = false;
/*  61 */     initConfiguration();
/*     */   }
/*     */   
/*     */   static void stop() {
/*  65 */     shutdown = true;
/*  66 */     stopTimer();
/*  67 */     if (storageManager != null) {
/*  68 */       storageManager.close();
/*  69 */       storageManager = null;
/*     */     } 
/*  71 */     closeConfiguration();
/*  72 */     context = null;
/*     */   }
/*     */   
/*     */   private static void initConfiguration() {
/*  76 */     closeConfiguration();
/*  77 */     Filter filter = null;
/*     */     try {
/*  79 */       filter = context.createFilter("(&(objectClass=org.eclipse.osgi.service.datalocation.Location)(type=osgi.configuration.area))");
/*  80 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/*  83 */     configTracker = new ServiceTracker(context, filter, new AppPersistence());
/*  84 */     configTracker.open();
/*     */   }
/*     */   
/*     */   private static void closeConfiguration() {
/*  88 */     if (configTracker != null)
/*  89 */       configTracker.close(); 
/*  90 */     configTracker = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLocked(ApplicationDescriptor desc) {
/*  99 */     synchronized (locks) {
/* 100 */       return locks.contains(desc.getApplicationId());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveLock(ApplicationDescriptor desc, boolean locked) {
/* 110 */     synchronized (locks) {
/* 111 */       if (locked) {
/* 112 */         if (!locks.contains(desc.getApplicationId())) {
/* 113 */           locks.add(desc.getApplicationId());
/* 114 */           saveData(".locks");
/*     */         } 
/* 116 */       } else if (locks.remove(desc.getApplicationId())) {
/* 117 */         saveData(".locks");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void removeScheduledApp(EclipseScheduledApplication scheduledApp) {
/*     */     boolean removed;
/* 124 */     synchronized (scheduledApps) {
/* 125 */       removed = (scheduledApps.remove(scheduledApp.getScheduleId()) != null);
/* 126 */       if (removed) {
/* 127 */         saveData(".scheduled");
/*     */       }
/*     */     } 
/* 130 */     if (removed) {
/* 131 */       synchronized (timerApps) {
/* 132 */         timerApps.remove(scheduledApp);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScheduledApplication addScheduledApp(ApplicationDescriptor descriptor, String scheduleId, Map<String, Object> arguments, String topic, String eventFilter, boolean recurring) throws InvalidSyntaxException, ApplicationException {
/*     */     EclipseScheduledApplication result;
/* 148 */     if (!scheduling && !checkSchedulingSupport()) {
/* 149 */       throw new ApplicationException(4, "Cannot support scheduling without org.osgi.service.event package");
/*     */     }
/* 151 */     context.createFilter(eventFilter);
/*     */     
/* 153 */     synchronized (scheduledApps) {
/* 154 */       result = new EclipseScheduledApplication(context, getNextScheduledID(scheduleId), descriptor.getApplicationId(), arguments, topic, eventFilter, recurring);
/* 155 */       addScheduledApp(result);
/* 156 */       saveData(".scheduled");
/*     */     } 
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addScheduledApp(EclipseScheduledApplication scheduledApp) {
/* 163 */     if ("org/osgi/application/timer".equals(scheduledApp.getTopic()))
/* 164 */       synchronized (timerApps) {
/* 165 */         timerApps.add(scheduledApp);
/* 166 */         if (timerThread == null) {
/* 167 */           startTimer();
/*     */         }
/*     */       }  
/* 170 */     scheduledApps.put(scheduledApp.getScheduleId(), scheduledApp);
/* 171 */     Hashtable<String, Object> serviceProps = new Hashtable<>();
/* 172 */     if (scheduledApp.getTopic() != null)
/* 173 */       serviceProps.put("event.topics", new String[] { scheduledApp.getTopic() }); 
/* 174 */     if (scheduledApp.getEventFilter() != null)
/* 175 */       serviceProps.put("event.filter", scheduledApp.getEventFilter()); 
/* 176 */     serviceProps.put("schedule.id", scheduledApp.getScheduleId());
/* 177 */     serviceProps.put("service.pid", scheduledApp.getAppPid());
/* 178 */     ServiceRegistration sr = context.registerService(new String[] { ScheduledApplication.class.getName(), "org.osgi.service.event.EventHandler" }, scheduledApp, serviceProps);
/* 179 */     scheduledApp.setServiceRegistration(sr);
/*     */   }
/*     */   
/*     */   private static String getNextScheduledID(String scheduledId) throws ApplicationException {
/* 183 */     if (scheduledId != null) {
/* 184 */       if (scheduledApps.get(scheduledId) != null)
/* 185 */         throw new ApplicationException(5, "Duplicate scheduled ID: " + scheduledId); 
/* 186 */       return scheduledId;
/*     */     } 
/* 188 */     if (nextScheduledID == Integer.MAX_VALUE)
/* 189 */       nextScheduledID = 0; 
/* 190 */     String result = Integer.valueOf(nextScheduledID++).toString();
/* 191 */     while (scheduledApps.get(result) != null && nextScheduledID < Integer.MAX_VALUE)
/* 192 */       result = Integer.valueOf(nextScheduledID++).toString(); 
/* 193 */     if (nextScheduledID == Integer.MAX_VALUE)
/* 194 */       throw new ApplicationException(5, "Maximum number of scheduled applications reached"); 
/* 195 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean checkSchedulingSupport() {
/*     */     try {
/* 201 */       Class.forName("org.osgi.service.event.EventHandler");
/* 202 */       scheduling = true;
/* 203 */       return true;
/* 204 */     } catch (ClassNotFoundException classNotFoundException) {
/* 205 */       scheduling = false;
/* 206 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static synchronized boolean loadData(String fileName) {
/*     */     try {
/* 212 */       Location location = configLocation;
/* 213 */       if (location == null)
/* 214 */         return false; 
/* 215 */       File theStorageDir = new File(String.valueOf(location.getURL().getPath()) + '/' + "org.eclipse.equinox.app");
/* 216 */       if (storageManager == null) {
/* 217 */         boolean readOnly = location.isReadOnly();
/* 218 */         storageManager = new StorageManager(theStorageDir, readOnly ? "none" : null, readOnly);
/* 219 */         storageManager.open(!readOnly);
/*     */       } 
/* 221 */       File dataFile = storageManager.lookup(fileName, false);
/* 222 */       if (dataFile == null || !dataFile.isFile()) {
/* 223 */         Location parent = location.getParentLocation();
/* 224 */         if (parent != null) {
/* 225 */           theStorageDir = new File(String.valueOf(parent.getURL().getPath()) + '/' + "org.eclipse.equinox.app");
/* 226 */           StorageManager tmp = new StorageManager(theStorageDir, "none", true);
/* 227 */           tmp.open(false);
/* 228 */           dataFile = tmp.lookup(fileName, false);
/* 229 */           tmp.close();
/*     */         } 
/*     */       } 
/* 232 */       if (dataFile == null || !dataFile.isFile())
/* 233 */         return true; 
/* 234 */       if (".locks".equals(fileName))
/* 235 */       { loadLocks(dataFile); }
/* 236 */       else if (".scheduled".equals(fileName))
/* 237 */       { loadSchedules(dataFile); } 
/* 238 */     } catch (IOException iOException) {
/* 239 */       return false;
/*     */     } 
/* 241 */     return true;
/*     */   }
/*     */   
/*     */   private static void loadLocks(File locksData) throws IOException {
/* 245 */     Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/*     */     } finally {
/* 255 */       exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */     
/*     */     }  } private static void loadSchedules(File schedulesData) throws IOException {
/*     */     
/* 259 */     try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 274 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (InvalidSyntaxException|NoClassDefFoundError|ClassNotFoundException e)
/* 275 */     { throw new IOException(e.getMessage()); }
/*     */   
/*     */   }
/*     */   
/*     */   private static synchronized void saveData(String fileName) {
/* 280 */     if (storageManager == null || storageManager.isReadOnly())
/*     */       return; 
/*     */     try {
/* 283 */       File data = storageManager.createTempFile(fileName);
/* 284 */       if (".locks".equals(fileName)) {
/* 285 */         saveLocks(data);
/* 286 */       } else if (".scheduled".equals(fileName)) {
/* 287 */         saveSchedules(data);
/* 288 */       }  storageManager.lookup(fileName, true);
/* 289 */       storageManager.update(new String[] { fileName }, new String[] { data.getName() });
/* 290 */     } catch (IOException e) {
/* 291 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 4, 0, NLS.bind(Messages.persistence_error_saving, fileName), 0, e, null));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveLocks(File locksData) throws IOException {
/* 297 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void saveSchedules(File schedulesData) throws IOException {
/* 307 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void startTimer() {
/* 322 */     timerThread = new Thread(new AppTimer(), "app schedule timer");
/* 323 */     timerThread.start();
/*     */   }
/*     */   
/*     */   private static void stopTimer() {
/* 327 */     if (timerThread != null)
/* 328 */       timerThread.interrupt(); 
/* 329 */     timerThread = null;
/*     */   }
/*     */   
/*     */   static class AppTimer
/*     */     implements Runnable {
/*     */     public void run() {
/* 335 */       int lastMin = -1;
/* 336 */       while (!AppPersistence.shutdown) {
/*     */         try {
/* 338 */           Thread.sleep(30000L);
/* 339 */           Calendar cal = Calendar.getInstance();
/* 340 */           int minute = cal.get(12);
/* 341 */           if (minute == lastMin)
/*     */             continue; 
/* 343 */           lastMin = minute;
/* 344 */           Hashtable<String, Object> props = new Hashtable<>();
/* 345 */           props.put("year", Integer.valueOf(cal.get(1)));
/* 346 */           props.put("month", Integer.valueOf(cal.get(2)));
/* 347 */           props.put("day_of_month", Integer.valueOf(cal.get(5)));
/* 348 */           props.put("day_of_week", Integer.valueOf(cal.get(7)));
/* 349 */           props.put("hour_of_day", Integer.valueOf(cal.get(11)));
/* 350 */           props.put("minute", Integer.valueOf(minute));
/* 351 */           Event timerEvent = new Event("org/osgi/application/timer", props);
/* 352 */           EclipseScheduledApplication[] apps = null;
/*     */           
/* 354 */           synchronized (AppPersistence.timerApps) {
/* 355 */             if (AppPersistence.timerApps.size() == 0)
/*     */               continue; 
/* 357 */             apps = AppPersistence.timerApps.<EclipseScheduledApplication>toArray(new EclipseScheduledApplication[AppPersistence.timerApps.size()]);
/*     */           }  byte b; int i; EclipseScheduledApplication[] arrayOfEclipseScheduledApplication1;
/* 359 */           for (i = (arrayOfEclipseScheduledApplication1 = apps).length, b = 0; b < i; ) { EclipseScheduledApplication app = arrayOfEclipseScheduledApplication1[b];
/*     */             try {
/* 361 */               String filterString = app.getEventFilter();
/* 362 */               Filter filter = (filterString == null) ? null : FrameworkUtil.createFilter(filterString);
/* 363 */               if (filter == null || filter.match(props)) {
/* 364 */                 app.handleEvent(timerEvent);
/*     */               }
/* 366 */             } catch (Throwable t) {
/* 367 */               String message = NLS.bind(Messages.scheduled_app_launch_error, app.getAppPid());
/* 368 */               Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 2, 0, message, 0, t, null));
/*     */             }  b++; }
/*     */         
/* 371 */         } catch (InterruptedException interruptedException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String readString(ObjectInputStream in, boolean intern) throws IOException {
/* 379 */     byte type = in.readByte();
/* 380 */     if (type == 0)
/* 381 */       return null; 
/* 382 */     return intern ? in.readUTF().intern() : in.readUTF();
/*     */   }
/*     */   
/*     */   private static void writeStringOrNull(ObjectOutputStream out, String string) throws IOException {
/* 386 */     if (string == null) {
/* 387 */       out.writeByte(0);
/*     */     } else {
/* 389 */       out.writeByte(1);
/* 390 */       out.writeUTF(string);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object addingService(ServiceReference reference) {
/* 396 */     if (configLocation != null)
/* 397 */       return null; 
/* 398 */     configLocation = (Location)context.getService(reference);
/* 399 */     loadData(".locks");
/* 400 */     loadData(".scheduled");
/* 401 */     return configLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference reference, Object service) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference reference, Object service) {
/* 411 */     if (service == configLocation)
/* 412 */       configLocation = null; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\AppPersistence.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */