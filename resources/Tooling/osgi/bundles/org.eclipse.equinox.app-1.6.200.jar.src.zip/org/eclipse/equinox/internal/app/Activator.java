/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.eclipse.core.runtime.IContributor;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.spi.RegistryContributor;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   implements BundleActivator, ServiceTrackerCustomizer
/*     */ {
/*     */   public static final String PI_APP = "org.eclipse.equinox.app";
/*     */   public static boolean DEBUG = false;
/*     */   private static volatile BundleContext _context;
/*     */   private static volatile PackageAdmin _packageAdmin;
/*     */   private static volatile EclipseAppContainer container;
/*     */   private static volatile ServiceTracker _frameworkLogTracker;
/*     */   private ServiceTracker registryTracker;
/*     */   private IExtensionRegistry registry;
/*     */   
/*     */   public void start(BundleContext bc) {
/*  47 */     _context = bc;
/*     */     
/*  49 */     ServiceReference ref = bc.getServiceReference(PackageAdmin.class.getName());
/*  50 */     if (ref != null)
/*  51 */       _packageAdmin = (PackageAdmin)bc.getService(ref); 
/*  52 */     _frameworkLogTracker = new ServiceTracker(bc, FrameworkLog.class.getName(), null);
/*  53 */     _frameworkLogTracker.open();
/*  54 */     getDebugOptions(bc);
/*  55 */     processCommandLineArgs(bc);
/*     */     
/*  57 */     AppPersistence.start(bc);
/*     */     
/*  59 */     this.registryTracker = new ServiceTracker(bc, IExtensionRegistry.class.getName(), this);
/*  60 */     this.registryTracker.open();
/*     */     
/*     */     try {
/*  63 */       AppCommands.create(bc);
/*  64 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext bc) {
/*     */     try {
/*  73 */       AppCommands.destroy(bc);
/*  74 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.registryTracker.close();
/*  79 */     this.registryTracker = null;
/*     */     
/*  81 */     AppPersistence.stop();
/*  82 */     if (_frameworkLogTracker != null) {
/*  83 */       _frameworkLogTracker.close();
/*  84 */       _frameworkLogTracker = null;
/*     */     } 
/*  86 */     _packageAdmin = null;
/*  87 */     _context = null;
/*     */   }
/*     */   
/*     */   private void getDebugOptions(BundleContext context) {
/*  91 */     ServiceReference debugRef = context.getServiceReference(DebugOptions.class.getName());
/*  92 */     if (debugRef == null)
/*     */       return; 
/*  94 */     DebugOptions debugOptions = (DebugOptions)context.getService(debugRef);
/*  95 */     DEBUG = debugOptions.getBooleanOption("org.eclipse.equinox.app/debug", false);
/*  96 */     context.ungetService(debugRef);
/*     */   }
/*     */   
/*     */   private static EnvironmentInfo getEnvironmentInfo() {
/* 100 */     BundleContext bc = getContext();
/* 101 */     if (bc == null)
/* 102 */       return null; 
/* 103 */     ServiceReference infoRef = bc.getServiceReference(EnvironmentInfo.class.getName());
/* 104 */     if (infoRef == null)
/* 105 */       return null; 
/* 106 */     EnvironmentInfo envInfo = (EnvironmentInfo)bc.getService(infoRef);
/* 107 */     if (envInfo == null)
/* 108 */       return null; 
/* 109 */     bc.ungetService(infoRef);
/* 110 */     return envInfo;
/*     */   }
/*     */   
/*     */   private void processCommandLineArgs(BundleContext bc) {
/* 114 */     EnvironmentInfo envInfo = getEnvironmentInfo();
/* 115 */     if (envInfo != null) {
/* 116 */       CommandLineArgs.processCommandLine(envInfo);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object addingService(ServiceReference reference) {
/* 121 */     BundleContext context = _context;
/* 122 */     if (context == null)
/* 123 */       return null; 
/* 124 */     Object service = null;
/* 125 */     EclipseAppContainer startContainer = null;
/* 126 */     synchronized (this) {
/* 127 */       if (container != null) {
/* 128 */         return null;
/*     */       }
/* 130 */       service = context.getService(reference);
/* 131 */       if (this.registry == null && service instanceof IExtensionRegistry) {
/* 132 */         this.registry = (IExtensionRegistry)service;
/*     */         
/* 134 */         container = new EclipseAppContainer(context, this.registry);
/* 135 */         startContainer = container;
/*     */       } 
/*     */     } 
/*     */     
/* 139 */     if (startContainer != null) {
/* 140 */       startContainer.start();
/* 141 */       return service;
/*     */     } 
/*     */     
/* 144 */     if (service != null)
/* 145 */       context.ungetService(reference); 
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference reference, Object service) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference reference, Object service) {
/* 156 */     EclipseAppContainer currentContainer = null;
/* 157 */     synchronized (this) {
/*     */       
/* 159 */       if (service == this.registry)
/* 160 */         this.registry = null; 
/* 161 */       if (container == null)
/*     */         return; 
/* 163 */       currentContainer = container;
/* 164 */       container = null;
/*     */     } 
/*     */     
/* 167 */     if (currentContainer != null) {
/* 168 */       currentContainer.stop();
/*     */     }
/*     */   }
/*     */   
/*     */   static void openTracker(final ServiceTracker tracker, final boolean allServices) {
/* 173 */     if (System.getSecurityManager() == null) {
/* 174 */       tracker.open(allServices);
/*     */     } else {
/* 176 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/* 179 */               tracker.open(allServices);
/* 180 */               return null;
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object getService(final ServiceTracker tracker) {
/* 187 */     if (System.getSecurityManager() == null)
/* 188 */       return tracker.getService(); 
/* 189 */     return AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 192 */             return tracker.getService();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   static String getLocation(final Bundle bundle) {
/* 199 */     if (System.getSecurityManager() == null)
/* 200 */       return bundle.getLocation(); 
/* 201 */     return AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public Object run() {
/* 204 */             return bundle.getLocation();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   static Bundle getBundle(IContributor contributor) {
/* 211 */     if (contributor instanceof RegistryContributor) {
/*     */       try {
/* 213 */         long id = Long.parseLong(((RegistryContributor)contributor).getActualId());
/* 214 */         BundleContext context = _context;
/* 215 */         if (context != null)
/* 216 */           return context.getBundle(id); 
/* 217 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */     
/* 221 */     PackageAdmin packageAdmin = _packageAdmin;
/* 222 */     if (packageAdmin == null)
/* 223 */       return null; 
/* 224 */     Bundle[] bundles = packageAdmin.getBundles(contributor.getName(), null);
/* 225 */     if (bundles == null)
/* 226 */       return null;  byte b; int i;
/*     */     Bundle[] arrayOfBundle1;
/* 228 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 229 */       if ((bundle.getState() & 0x3) == 0)
/* 230 */         return bundle; 
/*     */       b++; }
/*     */     
/* 233 */     return null;
/*     */   }
/*     */   
/*     */   static BundleContext getContext() {
/* 237 */     return _context;
/*     */   }
/*     */   
/*     */   public static EclipseAppContainer getContainer() {
/* 241 */     return container;
/*     */   }
/*     */   
/*     */   static void log(FrameworkLogEntry entry) {
/* 245 */     ServiceTracker frameworkLogTracker = _frameworkLogTracker;
/* 246 */     FrameworkLog log = (frameworkLogTracker == null) ? null : (FrameworkLog)frameworkLogTracker.getService();
/* 247 */     if (log != null)
/* 248 */       log.log(entry); 
/*     */   }
/*     */   
/*     */   static void setProperty(String key, String value) {
/* 252 */     EnvironmentInfo envInfo = getEnvironmentInfo();
/* 253 */     if (envInfo != null) {
/* 254 */       envInfo.setProperty(key, value);
/*     */     } else {
/* 256 */       System.getProperties().setProperty(key, value);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\Activator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */