/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryEventListener;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.service.runnable.ApplicationLauncher;
/*     */ import org.eclipse.osgi.service.runnable.ParameterizedRunnable;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.service.application.ApplicationDescriptor;
/*     */ import org.osgi.service.application.ApplicationException;
/*     */ import org.osgi.service.application.ApplicationHandle;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseAppContainer
/*     */   implements IRegistryEventListener, SynchronousBundleListener, ServiceTrackerCustomizer
/*     */ {
/*     */   private static final String PI_RUNTIME = "org.eclipse.core.runtime";
/*     */   private static final String PT_APPLICATIONS = "applications";
/*     */   private static final String PT_APP_VISIBLE = "visible";
/*     */   private static final String PT_APP_THREAD = "thread";
/*     */   private static final String PT_APP_THREAD_ANY = "any";
/*     */   private static final String PT_APP_CARDINALITY = "cardinality";
/*     */   private static final String PT_APP_CARDINALITY_SINGLETON_GLOBAL = "singleton-global";
/*     */   private static final String PT_APP_CARDINALITY_SINGLETON_SCOPED = "singleton-scoped";
/*     */   private static final String PT_APP_CARDINALITY_UNLIMITED = "*";
/*     */   private static final String PT_APP_ICON = "icon";
/*     */   private static final String PT_PRODUCTS = "products";
/*     */   private static final String EXT_ERROR_APP = "org.eclipse.equinox.app.error";
/*     */   static final String PROP_PRODUCT = "eclipse.product";
/*     */   static final String PROP_ECLIPSE_APPLICATION = "eclipse.application";
/*     */   private static final String PROP_ECLIPSE_APPLICATION_LAUNCH_DEFAULT = "eclipse.application.launchDefault";
/*     */   static final int NOT_LOCKED = 0;
/*     */   static final int LOCKED_SINGLETON_GLOBAL_RUNNING = 1;
/*     */   static final int LOCKED_SINGLETON_GLOBAL_APPS_RUNNING = 2;
/*     */   static final int LOCKED_SINGLETON_SCOPED_RUNNING = 3;
/*     */   static final int LOCKED_SINGLETON_LIMITED_RUNNING = 4;
/*     */   static final int LOCKED_MAIN_THREAD_RUNNING = 5;
/*     */   final BundleContext context;
/*  64 */   private final Object lock = new Object();
/*     */ 
/*     */   
/*  67 */   private final HashMap<String, EclipseAppDescriptor> apps = new HashMap<>();
/*     */   
/*     */   private final IExtensionRegistry extensionRegistry;
/*     */   
/*     */   private final ServiceTracker launcherTracker;
/*     */   
/*     */   private IBranding branding;
/*     */   private boolean missingProductReported;
/*  75 */   private final Collection<EclipseAppHandle> activeHandles = new ArrayList<>();
/*     */   
/*     */   private EclipseAppHandle activeMain;
/*     */   
/*     */   private EclipseAppHandle activeGlobalSingleton;
/*     */   
/*     */   private EclipseAppHandle activeScopedSingleton;
/*     */   
/*     */   private HashMap<String, ArrayList<EclipseAppHandle>> activeLimited;
/*     */   private String defaultAppId;
/*     */   private DefaultApplicationListener defaultAppListener;
/*     */   private ParameterizedRunnable defaultMainThreadAppHandle;
/*     */   private volatile boolean missingApp = false;
/*     */   private MainApplicationLauncher missingAppLauncher;
/*     */   
/*     */   public EclipseAppContainer(BundleContext context, IExtensionRegistry extensionRegistry) {
/*  91 */     this.context = context;
/*  92 */     this.extensionRegistry = extensionRegistry;
/*  93 */     this.launcherTracker = new ServiceTracker(context, ApplicationLauncher.class.getName(), this);
/*     */   }
/*     */   
/*     */   void start() {
/*  97 */     this.launcherTracker.open();
/*  98 */     this.extensionRegistry.addListener(this, "org.eclipse.core.runtime.applications");
/*     */     
/* 100 */     this.context.addBundleListener((BundleListener)this);
/*     */     
/* 102 */     registerAppDescriptors();
/* 103 */     String startDefaultProp = this.context.getProperty("eclipse.application.launchDefault");
/* 104 */     if (startDefaultProp == null || "true".equalsIgnoreCase(startDefaultProp)) {
/*     */       
/*     */       try {
/* 107 */         startDefaultApp(true);
/* 108 */       } catch (ApplicationException e) {
/* 109 */         Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 4, 0, Messages.application_errorStartDefault, 0, (Throwable)e, null));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void stop() {
/* 116 */     stopAllApps();
/* 117 */     this.context.removeBundleListener((BundleListener)this);
/* 118 */     this.extensionRegistry.removeListener(this);
/*     */     
/* 120 */     this.apps.clear();
/* 121 */     this.branding = null;
/* 122 */     this.missingProductReported = false;
/* 123 */     this.launcherTracker.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EclipseAppDescriptor getAppDescriptor(String applicationId) {
/* 130 */     EclipseAppDescriptor result = null;
/* 131 */     synchronized (this.lock) {
/* 132 */       result = this.apps.get(applicationId);
/*     */     } 
/* 134 */     if (result == null) {
/* 135 */       registerAppDescriptor(applicationId);
/* 136 */       synchronized (this.lock) {
/* 137 */         result = this.apps.get(applicationId);
/*     */       } 
/*     */     } 
/* 140 */     return result;
/*     */   }
/*     */   
/*     */   private EclipseAppDescriptor createAppDescriptor(IExtension appExtension) {
/* 144 */     if (Activator.DEBUG)
/* 145 */       System.out.println("Creating application descriptor: " + appExtension.getUniqueIdentifier()); 
/* 146 */     String iconPath = null;
/* 147 */     synchronized (this.lock) {
/* 148 */       EclipseAppDescriptor appDescriptor = this.apps.get(appExtension.getUniqueIdentifier());
/* 149 */       if (appDescriptor != null) {
/* 150 */         return appDescriptor;
/*     */       }
/* 152 */       IConfigurationElement[] configs = appExtension.getConfigurationElements();
/* 153 */       int flags = 35;
/* 154 */       int cardinality = 0;
/* 155 */       if (configs.length > 0) {
/* 156 */         String sVisible = configs[0].getAttribute("visible");
/* 157 */         if (sVisible != null && !Boolean.valueOf(sVisible).booleanValue())
/* 158 */           flags &= 0xFFFFFFFE; 
/* 159 */         String sThread = configs[0].getAttribute("thread");
/* 160 */         if ("any".equals(sThread)) {
/* 161 */           flags |= 0x40;
/* 162 */           flags &= 0xFFFFFFDF;
/*     */         } 
/* 164 */         String sCardinality = configs[0].getAttribute("cardinality");
/* 165 */         if (sCardinality != null) {
/* 166 */           flags &= 0xFFFFFFFD;
/* 167 */           if ("singleton-scoped".equals(sCardinality)) {
/* 168 */             flags |= 0x4;
/* 169 */           } else if ("*".equals(sCardinality)) {
/* 170 */             flags |= 0x8;
/* 171 */           } else if ("singleton-global".equals(sCardinality)) {
/* 172 */             flags |= 0x2;
/*     */           } else {
/*     */             try {
/* 175 */               cardinality = Integer.parseInt(sCardinality);
/* 176 */               flags |= 0x10;
/* 177 */             } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */               
/* 180 */               flags |= 0x2;
/*     */             } 
/*     */           } 
/*     */         } 
/* 184 */         String defaultApp = getDefaultAppId();
/* 185 */         if (defaultApp != null && defaultApp.equals(appExtension.getUniqueIdentifier()))
/* 186 */           flags |= 0x80; 
/* 187 */         iconPath = configs[0].getAttribute("icon");
/*     */       } 
/* 189 */       appDescriptor = new EclipseAppDescriptor(Activator.getBundle(appExtension.getContributor()), appExtension.getUniqueIdentifier(), appExtension.getLabel(), iconPath, flags, cardinality, this);
/*     */       
/* 191 */       ServiceRegistration sr = AccessController.<ServiceRegistration>doPrivileged(new RegisterService(new String[] { ApplicationDescriptor.class.getName() }, appDescriptor, appDescriptor.getServiceProperties()));
/* 192 */       appDescriptor.setServiceRegistration(sr);
/*     */       
/* 194 */       this.apps.put(appExtension.getUniqueIdentifier(), appDescriptor);
/* 195 */       return appDescriptor;
/*     */     } 
/*     */   }
/*     */   
/*     */   private EclipseAppDescriptor removeAppDescriptor(String applicationId) {
/* 200 */     if (Activator.DEBUG)
/* 201 */       System.out.println("Removing application descriptor: " + applicationId); 
/* 202 */     synchronized (this.lock) {
/* 203 */       EclipseAppDescriptor appDescriptor = this.apps.remove(applicationId);
/* 204 */       if (appDescriptor == null)
/* 205 */         return null; 
/* 206 */       appDescriptor.unregister();
/* 207 */       return appDescriptor;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrivilegedAction getRegServiceAction(String[] serviceClasses, Object serviceObject, Dictionary<String, ?> serviceProps) {
/* 215 */     return new RegisterService(serviceClasses, serviceObject, serviceProps);
/*     */   }
/*     */ 
/*     */   
/*     */   private class RegisterService
/*     */     implements PrivilegedAction
/*     */   {
/*     */     String[] serviceClasses;
/*     */     Object serviceObject;
/*     */     Dictionary<String, ?> serviceProps;
/*     */     
/*     */     RegisterService(String[] serviceClasses, Object serviceObject, Dictionary<String, ?> serviceProps) {
/* 227 */       this.serviceClasses = serviceClasses;
/* 228 */       this.serviceObject = serviceObject;
/* 229 */       this.serviceProps = serviceProps;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object run() {
/* 234 */       return EclipseAppContainer.this.context.registerService(this.serviceClasses, this.serviceObject, this.serviceProps);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void startDefaultApp(boolean delayError) throws ApplicationException {
/* 240 */     String applicationId = getDefaultAppId();
/* 241 */     EclipseAppDescriptor defaultDesc = null;
/* 242 */     Map<String, Object> args = new HashMap<>(2);
/* 243 */     args.put("eclipse.application.default", Boolean.TRUE);
/* 244 */     if (applicationId == null && !delayError) {
/*     */       
/* 246 */       args.put("error.exception", new RuntimeException(Messages.application_noIdFound));
/* 247 */       defaultDesc = getAppDescriptor("org.eclipse.equinox.app.error");
/*     */     } else {
/* 249 */       defaultDesc = getAppDescriptor(applicationId);
/* 250 */       if (defaultDesc == null && !delayError) {
/*     */         
/* 252 */         args.put("error.exception", new RuntimeException(NLS.bind(Messages.application_notFound, applicationId, getAvailableAppsMsg())));
/* 253 */         defaultDesc = getAppDescriptor("org.eclipse.equinox.app.error");
/*     */       } 
/*     */     } 
/* 256 */     if (delayError && defaultDesc == null) {
/*     */ 
/*     */ 
/*     */       
/* 260 */       this.missingApp = true;
/*     */       return;
/*     */     } 
/* 263 */     if (defaultDesc != null) {
/* 264 */       defaultDesc.launch(args);
/*     */     } else {
/* 266 */       throw new ApplicationException(3, Messages.application_noIdFound);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerAppDescriptors() {
/* 274 */     IExtension[] availableApps = getAvailableAppExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 275 */     for (i = (arrayOfIExtension1 = availableApps).length, b = 0; b < i; ) { IExtension availableApp = arrayOfIExtension1[b];
/* 276 */       createAppDescriptor(availableApp);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void registerAppDescriptor(String applicationId) {
/* 281 */     IExtension appExtension = getAppExtension(applicationId);
/* 282 */     if (appExtension != null) {
/* 283 */       createAppDescriptor(appExtension);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IExtension[] getAvailableAppExtensions() {
/* 291 */     IExtensionPoint point = this.extensionRegistry.getExtensionPoint("org.eclipse.core.runtime.applications");
/* 292 */     if (point == null)
/* 293 */       return new IExtension[0]; 
/* 294 */     return point.getExtensions();
/*     */   }
/*     */   
/*     */   String getAvailableAppsMsg() {
/* 298 */     IExtension[] availableApps = getAvailableAppExtensions();
/* 299 */     String availableAppsMsg = "<NONE>";
/* 300 */     if (availableApps.length != 0) {
/* 301 */       availableAppsMsg = availableApps[0].getUniqueIdentifier();
/* 302 */       for (int i = 1; i < availableApps.length; i++)
/* 303 */         availableAppsMsg = String.valueOf(availableAppsMsg) + ", " + availableApps[i].getUniqueIdentifier(); 
/*     */     } 
/* 305 */     return availableAppsMsg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IExtension getAppExtension(String applicationId) {
/* 314 */     return this.extensionRegistry.getExtension("org.eclipse.core.runtime", "applications", applicationId);
/*     */   }
/*     */   
/*     */   void launch(EclipseAppHandle appHandle) throws Exception {
/* 318 */     boolean isDefault = appHandle.isDefault();
/* 319 */     if (((EclipseAppDescriptor)appHandle.getApplicationDescriptor()).getThreadType() == 32)
/*     */     
/* 321 */     { DefaultApplicationListener curDefaultApplicationListener = null;
/* 322 */       MainApplicationLauncher curMissingAppLauncher = null;
/* 323 */       ApplicationLauncher appLauncher = null;
/* 324 */       synchronized (this) {
/* 325 */         appLauncher = (ApplicationLauncher)this.launcherTracker.getService();
/* 326 */         if (appLauncher == null) {
/* 327 */           if (isDefault) {
/*     */ 
/*     */             
/* 330 */             this.defaultMainThreadAppHandle = (ParameterizedRunnable)appHandle;
/*     */             return;
/*     */           } 
/* 333 */           throw new ApplicationException(3, NLS.bind(Messages.application_error_noMainThread, appHandle.getInstanceId()));
/*     */         } 
/* 335 */         curDefaultApplicationListener = this.defaultAppListener;
/* 336 */         curMissingAppLauncher = this.missingAppLauncher;
/*     */       } 
/* 338 */       if (curDefaultApplicationListener != null) {
/* 339 */         curDefaultApplicationListener.launch(appHandle);
/* 340 */       } else if (curMissingAppLauncher != null) {
/* 341 */         curMissingAppLauncher.launch(appHandle);
/*     */       } else {
/* 343 */         appLauncher.launch((ParameterizedRunnable)appHandle, appHandle.getArguments().get("application.args"));
/*     */       }  }
/* 345 */     else if (isDefault)
/* 346 */     { DefaultApplicationListener curDefaultApplicationListener = null;
/* 347 */       MainApplicationLauncher curMissingAppLauncher = null;
/* 348 */       ApplicationLauncher appLauncher = null;
/* 349 */       synchronized (this) {
/* 350 */         appLauncher = (ApplicationLauncher)this.launcherTracker.getService();
/* 351 */         if (this.defaultAppListener == null)
/* 352 */           this.defaultAppListener = new DefaultApplicationListener(appHandle); 
/* 353 */         curDefaultApplicationListener = this.defaultAppListener;
/* 354 */         if (appLauncher == null) {
/*     */ 
/*     */           
/* 357 */           this.defaultMainThreadAppHandle = (ParameterizedRunnable)curDefaultApplicationListener;
/*     */           return;
/*     */         } 
/* 360 */         curMissingAppLauncher = this.missingAppLauncher;
/*     */       } 
/* 362 */       if (curMissingAppLauncher != null) {
/* 363 */         curMissingAppLauncher.launch(curDefaultApplicationListener);
/*     */       } else {
/* 365 */         appLauncher.launch((ParameterizedRunnable)curDefaultApplicationListener, null);
/*     */       }  }
/* 367 */     else { AnyThreadAppLauncher.launchEclipseApplication(appHandle); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 375 */     if ((0x100 & event.getType()) == 0 || event.getBundle().getBundleId() != 0L) {
/*     */       return;
/*     */     }
/* 378 */     stopAllApps();
/*     */   }
/*     */ 
/*     */   
/*     */   private void stopAllApps() {
/*     */     try {
/* 384 */       ServiceReference[] runningRefs = this.context.getServiceReferences(ApplicationHandle.class.getName(), "(!(application.state=STOPPING))");
/* 385 */       if (runningRefs != null) {
/* 386 */         byte b; int i; ServiceReference[] arrayOfServiceReference; for (i = (arrayOfServiceReference = runningRefs).length, b = 0; b < i; ) { ServiceReference runningRef = arrayOfServiceReference[b];
/* 387 */           ApplicationHandle handle = (ApplicationHandle)this.context.getService(runningRef);
/*     */           try {
/* 389 */             if (handle != null)
/* 390 */               handle.destroy(); 
/* 391 */           } catch (Throwable t) {
/* 392 */             String message = NLS.bind(Messages.application_error_stopping, handle.getInstanceId());
/* 393 */             Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 2, 0, message, 0, t, null));
/*     */           } finally {
/* 395 */             if (handle != null)
/* 396 */               this.context.ungetService(runningRef); 
/*     */           }  b++; }
/*     */       
/*     */       } 
/* 400 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDefaultAppId() {
/* 406 */     if (this.defaultAppId != null) {
/* 407 */       return this.defaultAppId;
/*     */     }
/* 409 */     this.defaultAppId = CommandLineArgs.getApplication();
/* 410 */     if (this.defaultAppId != null) {
/* 411 */       return this.defaultAppId;
/*     */     }
/*     */     
/* 414 */     this.defaultAppId = this.context.getProperty("eclipse.application");
/* 415 */     if (this.defaultAppId != null) {
/* 416 */       return this.defaultAppId;
/*     */     }
/*     */     
/* 419 */     this.defaultAppId = (getBranding() == null) ? null : getBranding().getApplication();
/* 420 */     return this.defaultAppId;
/*     */   }
/*     */   
/*     */   public IBranding getBranding() {
/* 424 */     if (this.branding != null) {
/* 425 */       return this.branding;
/*     */     }
/* 427 */     String productId = CommandLineArgs.getProduct();
/* 428 */     if (productId == null) {
/*     */       
/* 430 */       if (this.context == null)
/* 431 */         return null; 
/* 432 */       productId = this.context.getProperty("eclipse.product");
/* 433 */       if (productId == null)
/* 434 */         return null; 
/*     */     } 
/* 436 */     IConfigurationElement[] entries = this.extensionRegistry.getConfigurationElementsFor("org.eclipse.core.runtime", "products", productId);
/* 437 */     if (entries.length > 0) {
/*     */       
/* 439 */       this.branding = new ProductExtensionBranding(productId, entries[0]);
/* 440 */       return this.branding;
/*     */     } 
/* 442 */     IConfigurationElement[] elements = this.extensionRegistry.getConfigurationElementsFor("org.eclipse.core.runtime", "products");
/* 443 */     List<FrameworkLogEntry> logEntries = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 444 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 445 */       if (element.getName().equalsIgnoreCase("provider"))
/*     */         try {
/* 447 */           Object provider = element.createExecutableExtension("run");
/* 448 */           Object[] products = (Object[])callMethod(provider, "getProducts", null, null);
/* 449 */           if (products != null) {
/* 450 */             byte b1; int j; Object[] arrayOfObject; for (j = (arrayOfObject = products).length, b1 = 0; b1 < j; ) { Object product = arrayOfObject[b1];
/* 451 */               if (productId.equalsIgnoreCase((String)callMethod(product, "getId", null, null)))
/* 452 */               { this.branding = new ProviderExtensionBranding(product);
/* 453 */                 return this.branding; }  b1++; }
/*     */           
/*     */           } 
/* 456 */         } catch (CoreException e) {
/* 457 */           if (logEntries == null)
/* 458 */             logEntries = new ArrayList<>(3); 
/* 459 */           logEntries.add(new FrameworkLogEntry("org.eclipse.equinox.app", NLS.bind(Messages.provider_invalid, element.getParent().toString()), 0, (Throwable)e, null));
/*     */         }  
/*     */       b++; }
/*     */     
/* 463 */     if (logEntries != null) {
/* 464 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", Messages.provider_invalid_general, 0, null, logEntries.<FrameworkLogEntry>toArray(new FrameworkLogEntry[logEntries.size()])));
/*     */     }
/* 466 */     if (!this.missingProductReported) {
/* 467 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", NLS.bind(Messages.product_notFound, productId), 0, null, null));
/* 468 */       this.missingProductReported = true;
/*     */     } 
/* 470 */     return null;
/*     */   }
/*     */   
/*     */   private void refreshAppDescriptors() {
/* 474 */     synchronized (this.lock) {
/* 475 */       for (EclipseAppDescriptor eclipseAppDescriptor : this.apps.values())
/* 476 */         eclipseAppDescriptor.refreshProperties(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   void lock(EclipseAppHandle appHandle) throws ApplicationException {
/* 481 */     EclipseAppDescriptor eclipseApp = (EclipseAppDescriptor)appHandle.getApplicationDescriptor();
/* 482 */     synchronized (this.lock) {
/* 483 */       ArrayList<EclipseAppHandle> limited; switch (isLocked(eclipseApp)) {
/*     */ 
/*     */         
/*     */         case 1:
/* 487 */           throw new ApplicationException(2, NLS.bind(Messages.singleton_running, this.activeGlobalSingleton.getInstanceId()));
/*     */         case 2:
/* 489 */           throw new ApplicationException(2, Messages.apps_running);
/*     */         case 3:
/* 491 */           throw new ApplicationException(2, NLS.bind(Messages.singleton_running, this.activeScopedSingleton.getInstanceId()));
/*     */         case 4:
/* 493 */           throw new ApplicationException(2, NLS.bind(Messages.max_running, eclipseApp.getApplicationId()));
/*     */         case 5:
/* 495 */           throw new ApplicationException(2, NLS.bind(Messages.main_running, this.activeMain.getInstanceId()));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 501 */       switch (eclipseApp.getCardinalityType()) {
/*     */         case 2:
/* 503 */           this.activeGlobalSingleton = appHandle;
/*     */           break;
/*     */         case 4:
/* 506 */           this.activeScopedSingleton = appHandle;
/*     */           break;
/*     */         case 16:
/* 509 */           if (this.activeLimited == null)
/* 510 */             this.activeLimited = new HashMap<>(3); 
/* 511 */           limited = this.activeLimited.get(eclipseApp.getApplicationId());
/* 512 */           if (limited == null) {
/* 513 */             limited = new ArrayList<>(eclipseApp.getCardinality());
/* 514 */             this.activeLimited.put(eclipseApp.getApplicationId(), limited);
/*     */           } 
/* 516 */           limited.add(appHandle);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 523 */       if (eclipseApp.getThreadType() == 32)
/* 524 */         this.activeMain = appHandle; 
/* 525 */       this.activeHandles.add(appHandle);
/* 526 */       refreshAppDescriptors();
/*     */     } 
/*     */   }
/*     */   
/*     */   void unlock(EclipseAppHandle appHandle) {
/* 531 */     synchronized (this.lock) {
/* 532 */       if (this.activeGlobalSingleton == appHandle) {
/* 533 */         this.activeGlobalSingleton = null;
/* 534 */       } else if (this.activeScopedSingleton == appHandle) {
/* 535 */         this.activeScopedSingleton = null;
/* 536 */       } else if (((EclipseAppDescriptor)appHandle.getApplicationDescriptor()).getCardinalityType() == 16 && 
/* 537 */         this.activeLimited != null) {
/* 538 */         ArrayList<EclipseAppHandle> limited = this.activeLimited.get(((EclipseAppDescriptor)appHandle.getApplicationDescriptor()).getApplicationId());
/* 539 */         if (limited != null) {
/* 540 */           limited.remove(appHandle);
/*     */         }
/*     */       } 
/* 543 */       if (this.activeMain == appHandle)
/* 544 */         this.activeMain = null; 
/* 545 */       if (this.activeHandles.remove(appHandle))
/* 546 */         refreshAppDescriptors(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   int isLocked(EclipseAppDescriptor eclipseApp) {
/* 551 */     synchronized (this.lock) {
/* 552 */       if (this.activeGlobalSingleton != null)
/* 553 */         return 1; 
/* 554 */       switch (eclipseApp.getCardinalityType()) {
/*     */         case 2:
/* 556 */           if (this.activeHandles.size() > 0)
/* 557 */             return 2; 
/*     */           break;
/*     */         case 4:
/* 560 */           if (this.activeScopedSingleton != null)
/* 561 */             return 3; 
/*     */           break;
/*     */         case 16:
/* 564 */           if (this.activeLimited != null) {
/* 565 */             ArrayList<EclipseAppHandle> limited = this.activeLimited.get(eclipseApp.getApplicationId());
/* 566 */             if (limited != null && limited.size() >= eclipseApp.getCardinality()) {
/* 567 */               return 4;
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 575 */       if (eclipseApp.getThreadType() == 32 && this.activeMain != null)
/* 576 */         return 5; 
/* 577 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object callMethod(Object obj, String methodName, Class[] argTypes, Object[] args) {
/*     */     try {
/* 583 */       return callMethodWithException(obj, methodName, argTypes, args);
/* 584 */     } catch (Throwable t) {
/* 585 */       Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 4, 0, "Error in invoking method.", 0, t, null));
/*     */       
/* 587 */       return null;
/*     */     } 
/*     */   }
/*     */   static Object callMethodWithException(Object obj, String methodName, Class[] argTypes, Object[] args) throws Exception {
/*     */     try {
/* 592 */       Method method = obj.getClass().getMethod(methodName, argTypes);
/* 593 */       return method.invoke(obj, args);
/* 594 */     } catch (InvocationTargetException e) {
/* 595 */       if (e.getTargetException() instanceof Error)
/* 596 */         throw (Error)e.getTargetException(); 
/* 597 */       if (e.getTargetException() instanceof Exception)
/* 598 */         throw (Exception)e.getTargetException(); 
/* 599 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object addingService(ServiceReference reference) {
/*     */     ApplicationLauncher appLauncher;
/*     */     MainApplicationLauncher mainApplicationLauncher;
/* 607 */     synchronized (this) {
/* 608 */       appLauncher = (ApplicationLauncher)this.context.getService(reference);
/*     */       
/* 610 */       ParameterizedRunnable appRunnable = this.defaultMainThreadAppHandle;
/*     */       
/* 612 */       this.defaultMainThreadAppHandle = null;
/* 613 */       if (appRunnable == null && this.missingApp) {
/* 614 */         this.missingAppLauncher = new MainApplicationLauncher(this);
/* 615 */         mainApplicationLauncher = this.missingAppLauncher;
/* 616 */         this.missingApp = false;
/*     */       } 
/*     */     } 
/* 619 */     if (mainApplicationLauncher != null)
/*     */     {
/* 621 */       appLauncher.launch((ParameterizedRunnable)mainApplicationLauncher, (mainApplicationLauncher instanceof EclipseAppHandle) ? ((EclipseAppHandle)mainApplicationLauncher).getArguments().get("application.args") : null); } 
/* 622 */     return appLauncher;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference reference, Object service) {}
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference reference, Object service) {}
/*     */ 
/*     */   
/*     */   public void added(IExtension[] extensions) {
/*     */     byte b;
/*     */     int i;
/*     */     IExtension[] arrayOfIExtension;
/* 637 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 638 */       createAppDescriptor(extension);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void added(IExtensionPoint[] extensionPoints) {}
/*     */   
/*     */   public void removed(IExtension[] extensions) {
/*     */     byte b;
/*     */     int i;
/*     */     IExtension[] arrayOfIExtension;
/* 649 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 650 */       removeAppDescriptor(extension.getUniqueIdentifier());
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void removed(IExtensionPoint[] extensionPoints) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\EclipseAppContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */