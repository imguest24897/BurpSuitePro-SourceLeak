/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.eclipse.equinox.app.IApplicationContext;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.application.ApplicationDescriptor;
/*     */ import org.osgi.service.application.ApplicationException;
/*     */ import org.osgi.service.application.ApplicationHandle;
/*     */ import org.osgi.service.condpermadmin.BundleSignerCondition;
/*     */ import org.osgi.service.condpermadmin.ConditionInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseAppDescriptor
/*     */   extends ApplicationDescriptor
/*     */ {
/*     */   static final String APP_TYPE = "eclipse.application.type";
/*     */   static final String APP_DEFAULT = "eclipse.application.default";
/*     */   static final String APP_TYPE_MAIN_THREAD = "main.thread";
/*     */   static final String APP_TYPE_ANY_THREAD = "any.thread";
/*     */   static final int FLAG_VISIBLE = 1;
/*     */   static final int FLAG_CARD_SINGLETON_GLOGAL = 2;
/*     */   static final int FLAG_CARD_SINGLETON_SCOPED = 4;
/*     */   static final int FLAG_CARD_UNLIMITED = 8;
/*     */   static final int FLAG_CARD_LIMITED = 16;
/*     */   static final int FLAG_TYPE_MAIN_THREAD = 32;
/*     */   static final int FLAG_TYPE_ANY_THREAD = 64;
/*     */   static final int FLAG_DEFAULT_APP = 128;
/*  43 */   private long instanceID = 0L;
/*     */   private ServiceRegistration sr;
/*  45 */   private Boolean locked = Boolean.FALSE;
/*     */   private final EclipseAppContainer appContainer;
/*     */   private final Bundle contributor;
/*     */   private final int flags;
/*     */   private final int cardinality;
/*     */   private final String name;
/*     */   private final URL iconURL;
/*  52 */   private final boolean[] registrationLock = new boolean[] { true };
/*     */   
/*     */   protected EclipseAppDescriptor(Bundle contributor, String pid, String name, String iconPath, int flags, int cardinality, EclipseAppContainer appContainer) {
/*  55 */     super(pid);
/*  56 */     this.name = name;
/*  57 */     this.contributor = contributor;
/*  58 */     this.appContainer = appContainer;
/*  59 */     this.locked = AppPersistence.isLocked(this) ? Boolean.TRUE : Boolean.FALSE;
/*  60 */     this.flags = flags;
/*  61 */     this.cardinality = cardinality;
/*  62 */     URL iconResult = null;
/*     */ 
/*     */ 
/*     */     
/*  66 */     if (iconPath != null && iconPath.length() > 0) {
/*  67 */       if (iconPath.charAt(0) == '/')
/*  68 */         iconPath = iconPath.substring(1); 
/*  69 */       String baseIconDir = "/";
/*  70 */       String iconFile = iconPath;
/*  71 */       int lastSlash = iconPath.lastIndexOf('/');
/*  72 */       if (lastSlash > 0 && lastSlash < iconPath.length() - 1) {
/*  73 */         baseIconDir = iconPath.substring(0, lastSlash);
/*  74 */         iconFile = iconPath.substring(lastSlash + 1);
/*     */       } 
/*  76 */       Enumeration<URL> urls = contributor.findEntries(baseIconDir, iconFile, false);
/*  77 */       if (urls != null && urls.hasMoreElements())
/*  78 */         iconResult = urls.nextElement(); 
/*     */     } 
/*  80 */     this.iconURL = iconResult;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map getPropertiesSpecific(String locale) {
/*  86 */     return getServiceProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ApplicationHandle launchSpecific(Map<String, Object> arguments) throws Exception {
/*  92 */     if (getLocked().booleanValue()) {
/*  93 */       throw new IllegalStateException("Cannot launch a locked application.");
/*     */     }
/*  95 */     EclipseAppHandle appHandle = createAppHandle(arguments);
/*     */     
/*     */     try {
/*  98 */       this.appContainer.launch(appHandle);
/*  99 */     } catch (Throwable t) {
/*     */       
/*     */       try {
/* 102 */         appHandle.destroy();
/* 103 */       } catch (Throwable throwable) {}
/*     */ 
/*     */       
/* 106 */       if (t instanceof Exception)
/* 107 */         throw (Exception)t; 
/* 108 */       throw (Error)t;
/*     */     } 
/* 110 */     return appHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void lockSpecific() {
/* 115 */     this.locked = Boolean.TRUE;
/*     */     
/* 117 */     refreshProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void unlockSpecific() {
/* 122 */     this.locked = Boolean.FALSE;
/*     */     
/* 124 */     refreshProperties();
/*     */   }
/*     */   
/*     */   void refreshProperties() {
/* 128 */     ServiceRegistration reg = getServiceRegistration();
/* 129 */     if (reg != null) {
/*     */       try {
/* 131 */         reg.setProperties(getServiceProperties());
/* 132 */       } catch (IllegalStateException illegalStateException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setServiceRegistration(ServiceRegistration sr) {
/* 139 */     synchronized (this.registrationLock) {
/* 140 */       this.sr = sr;
/* 141 */       this.registrationLock[0] = (sr != null);
/* 142 */       this.registrationLock.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ServiceRegistration getServiceRegistration() {
/* 148 */     synchronized (this.registrationLock) {
/* 149 */       if (this.sr == null && this.registrationLock[0]) {
/*     */         try {
/* 151 */           this.registrationLock.wait(1000L);
/* 152 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */       
/* 155 */       return this.sr;
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized Boolean getLocked() {
/* 160 */     return this.locked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Hashtable<String, Object> getServiceProperties() {
/* 167 */     Hashtable<String, Object> props = new Hashtable<>(10);
/* 168 */     props.put("service.pid", getApplicationId());
/* 169 */     if (this.name != null)
/* 170 */       props.put("application.name", this.name); 
/* 171 */     props.put("application.container", "org.eclipse.equinox.app");
/* 172 */     props.put("application.location", getLocation());
/* 173 */     Boolean launchable = (this.appContainer.isLocked(this) == 0) ? Boolean.TRUE : Boolean.FALSE;
/* 174 */     props.put("application.launchable", launchable);
/* 175 */     props.put("application.locked", getLocked());
/* 176 */     Boolean visible = ((this.flags & 0x1) != 0) ? Boolean.TRUE : Boolean.FALSE;
/* 177 */     props.put("application.visible", visible);
/* 178 */     props.put("eclipse.application.type", getThreadTypeString());
/* 179 */     if ((this.flags & 0x80) != 0)
/* 180 */       props.put("eclipse.application.default", Boolean.TRUE); 
/* 181 */     if (this.iconURL != null)
/* 182 */       props.put("application.icon", this.iconURL); 
/* 183 */     return props;
/*     */   }
/*     */   
/*     */   private String getLocation() {
/* 187 */     if (this.contributor == null)
/* 188 */       return ""; 
/* 189 */     return Activator.getLocation(this.contributor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EclipseAppHandle createAppHandle(Map<String, Object> arguments) throws ApplicationException {
/* 196 */     EclipseAppHandle newAppHandle = new EclipseAppHandle(getInstanceID(), arguments, this);
/* 197 */     this.appContainer.lock(newAppHandle);
/* 198 */     ServiceRegistration appHandleReg = AccessController.<ServiceRegistration>doPrivileged(this.appContainer.getRegServiceAction(new String[] { ApplicationHandle.class.getName(), IApplicationContext.class.getName() }, newAppHandle, newAppHandle.getServiceProperties()));
/* 199 */     newAppHandle.setServiceRegistration(appHandleReg);
/* 200 */     return newAppHandle;
/*     */   }
/*     */   
/*     */   EclipseAppContainer getContainerManager() {
/* 204 */     return this.appContainer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matchDNChain(String pattern) {
/* 209 */     if (this.contributor == null)
/* 210 */       return false; 
/* 211 */     return BundleSignerCondition.getCondition(this.contributor, new ConditionInfo(BundleSignerCondition.class.getName(), new String[] { pattern })).isSatisfied();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isLaunchableSpecific() {
/* 216 */     return true;
/*     */   }
/*     */   
/*     */   public void unregister() {
/* 220 */     ServiceRegistration temp = getServiceRegistration();
/* 221 */     if (temp != null) {
/* 222 */       setServiceRegistration(null);
/* 223 */       temp.unregister();
/*     */     } 
/*     */   }
/*     */   
/*     */   String getThreadTypeString() {
/* 228 */     if ((this.flags & 0x40) != 0)
/* 229 */       return "any.thread"; 
/* 230 */     return "main.thread";
/*     */   }
/*     */   
/*     */   int getThreadType() {
/* 234 */     return this.flags & 0x60;
/*     */   }
/*     */   
/*     */   int getCardinalityType() {
/* 238 */     return this.flags & 0x1E;
/*     */   }
/*     */   
/*     */   int getCardinality() {
/* 242 */     return this.cardinality;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized String getInstanceID() {
/* 247 */     if (this.instanceID == Long.MAX_VALUE) {
/* 248 */       this.instanceID = 0L;
/*     */     }
/* 250 */     return String.valueOf(getApplicationId()) + "." + this.instanceID++;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\EclipseAppDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */