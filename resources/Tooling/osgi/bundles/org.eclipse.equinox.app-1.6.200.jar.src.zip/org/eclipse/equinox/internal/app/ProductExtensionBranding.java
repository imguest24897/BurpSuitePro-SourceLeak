/*    */ package org.eclipse.equinox.internal.app;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProductExtensionBranding
/*    */   implements IBranding
/*    */ {
/*    */   private static final String ATTR_DESCRIPTION = "description";
/*    */   private static final String ATTR_NAME = "name";
/*    */   private static final String ATTR_APPLICATION = "application";
/*    */   private static final String ATTR_VALUE = "value";
/* 26 */   String application = null;
/* 27 */   String name = null;
/* 28 */   String id = null;
/* 29 */   String description = null;
/*    */   HashMap<String, String> properties;
/* 31 */   Bundle definingBundle = null;
/*    */   
/*    */   public ProductExtensionBranding(String id, IConfigurationElement element) {
/* 34 */     this.id = id;
/* 35 */     if (element == null)
/*    */       return; 
/* 37 */     this.application = element.getAttribute("application");
/* 38 */     this.name = element.getAttribute("name");
/* 39 */     this.description = element.getAttribute("description");
/* 40 */     loadProperties(element);
/*    */   }
/*    */   
/*    */   private void loadProperties(IConfigurationElement element) {
/* 44 */     IConfigurationElement[] children = element.getChildren();
/* 45 */     this.properties = new HashMap<>(children.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 46 */     for (i = (arrayOfIConfigurationElement1 = children).length, b = 0; b < i; ) { IConfigurationElement child = arrayOfIConfigurationElement1[b];
/* 47 */       String key = child.getAttribute("name");
/* 48 */       String value = child.getAttribute("value");
/* 49 */       if (key != null && value != null)
/* 50 */         this.properties.put(key, value);  b++; }
/*    */     
/* 52 */     this.definingBundle = Activator.getBundle(element.getContributor());
/*    */   }
/*    */ 
/*    */   
/*    */   public Bundle getDefiningBundle() {
/* 57 */     return this.definingBundle;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getApplication() {
/* 62 */     return this.application;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 67 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 72 */     return this.description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 77 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProperty(String key) {
/* 82 */     return this.properties.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProduct() {
/* 87 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\ProductExtensionBranding.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */