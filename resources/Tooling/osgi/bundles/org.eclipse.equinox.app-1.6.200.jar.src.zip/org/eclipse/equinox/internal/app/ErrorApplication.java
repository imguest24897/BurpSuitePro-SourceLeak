/*    */ package org.eclipse.equinox.internal.app;
/*    */ 
/*    */ import org.eclipse.equinox.app.IApplication;
/*    */ import org.eclipse.equinox.app.IApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorApplication
/*    */   implements IApplication
/*    */ {
/*    */   static final String ERROR_EXCEPTION = "error.exception";
/*    */   
/*    */   public Object start(IApplicationContext context) throws Exception {
/* 29 */     Exception error = (Exception)context.getArguments().get("error.exception");
/* 30 */     if (error != null)
/* 31 */       throw error; 
/* 32 */     throw new IllegalStateException();
/*    */   }
/*    */   
/*    */   public void stop() {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\ErrorApplication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */