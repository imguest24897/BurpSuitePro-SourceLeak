/*     */ package org.eclipse.equinox.internal.app;
/*     */ 
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.service.runnable.ApplicationRunnable;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.application.ApplicationHandle;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultApplicationListener
/*     */   implements ApplicationRunnable, ServiceTrackerCustomizer
/*     */ {
/*     */   private boolean running = true;
/*     */   private EclipseAppHandle launchMainApp;
/*     */   private final ServiceTracker handleTracker;
/*     */   private Object result;
/*     */   
/*     */   public DefaultApplicationListener(EclipseAppHandle defaultApp) {
/*  38 */     ServiceReference defaultRef = defaultApp.getServiceReference();
/*  39 */     if (defaultRef == null) {
/*     */ 
/*     */       
/*  42 */       this.result = defaultApp.waitForResult(100);
/*  43 */       this.handleTracker = null;
/*     */       return;
/*     */     } 
/*  46 */     ServiceTracker defaultAppTracker = new ServiceTracker(Activator.getContext(), defaultRef, this);
/*  47 */     defaultAppTracker.open();
/*  48 */     EclipseAppHandle trackedApp = (EclipseAppHandle)defaultAppTracker.getService();
/*  49 */     if (trackedApp == null) {
/*     */       
/*  51 */       defaultAppTracker.close();
/*     */ 
/*     */       
/*  54 */       this.result = defaultApp.waitForResult(100);
/*  55 */       this.handleTracker = null;
/*     */     } else {
/*  57 */       this.handleTracker = defaultAppTracker;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object run(Object context) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield handleTracker : Lorg/osgi/util/tracker/ServiceTracker;
/*     */     //   4: ifnonnull -> 12
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual getResult : ()Ljava/lang/Object;
/*     */     //   11: areturn
/*     */     //   12: aload_0
/*     */     //   13: getfield handleTracker : Lorg/osgi/util/tracker/ServiceTracker;
/*     */     //   16: invokevirtual getService : ()Ljava/lang/Object;
/*     */     //   19: checkcast org/eclipse/equinox/internal/app/EclipseAppHandle
/*     */     //   22: astore_2
/*     */     //   23: aload_2
/*     */     //   24: ifnull -> 91
/*     */     //   27: aload_2
/*     */     //   28: invokestatic launchEclipseApplication : (Lorg/eclipse/equinox/internal/app/EclipseAppHandle;)V
/*     */     //   31: goto -> 91
/*     */     //   34: aload_0
/*     */     //   35: invokevirtual getMainHandle : ()Lorg/eclipse/equinox/internal/app/EclipseAppHandle;
/*     */     //   38: astore_3
/*     */     //   39: aload_3
/*     */     //   40: ifnull -> 91
/*     */     //   43: aload_3
/*     */     //   44: aconst_null
/*     */     //   45: invokevirtual run : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   48: pop
/*     */     //   49: goto -> 86
/*     */     //   52: astore #4
/*     */     //   54: getstatic org/eclipse/equinox/internal/app/Messages.application_error_starting : Ljava/lang/String;
/*     */     //   57: aload_3
/*     */     //   58: invokevirtual getInstanceId : ()Ljava/lang/String;
/*     */     //   61: invokestatic bind : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   64: astore #5
/*     */     //   66: new org/eclipse/osgi/framework/log/FrameworkLogEntry
/*     */     //   69: dup
/*     */     //   70: ldc 'org.eclipse.equinox.app'
/*     */     //   72: iconst_2
/*     */     //   73: iconst_0
/*     */     //   74: aload #5
/*     */     //   76: iconst_0
/*     */     //   77: aload #4
/*     */     //   79: aconst_null
/*     */     //   80: invokespecial <init> : (Ljava/lang/String;IILjava/lang/String;ILjava/lang/Throwable;[Lorg/eclipse/osgi/framework/log/FrameworkLogEntry;)V
/*     */     //   83: invokestatic log : (Lorg/eclipse/osgi/framework/log/FrameworkLogEntry;)V
/*     */     //   86: aload_0
/*     */     //   87: aload_3
/*     */     //   88: invokevirtual unsetMainHandle : (Lorg/eclipse/equinox/internal/app/EclipseAppHandle;)V
/*     */     //   91: aload_0
/*     */     //   92: invokevirtual waitOnRunning : ()Z
/*     */     //   95: ifne -> 34
/*     */     //   98: goto -> 113
/*     */     //   101: astore #6
/*     */     //   103: aload_0
/*     */     //   104: getfield handleTracker : Lorg/osgi/util/tracker/ServiceTracker;
/*     */     //   107: invokevirtual close : ()V
/*     */     //   110: aload #6
/*     */     //   112: athrow
/*     */     //   113: aload_0
/*     */     //   114: getfield handleTracker : Lorg/osgi/util/tracker/ServiceTracker;
/*     */     //   117: invokevirtual close : ()V
/*     */     //   120: aload_0
/*     */     //   121: invokevirtual getResult : ()Ljava/lang/Object;
/*     */     //   124: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #63	-> 0
/*     */     //   #64	-> 7
/*     */     //   #65	-> 12
/*     */     //   #66	-> 23
/*     */     //   #68	-> 27
/*     */     //   #70	-> 31
/*     */     //   #71	-> 34
/*     */     //   #72	-> 39
/*     */     //   #76	-> 43
/*     */     //   #77	-> 49
/*     */     //   #78	-> 54
/*     */     //   #79	-> 66
/*     */     //   #81	-> 86
/*     */     //   #70	-> 91
/*     */     //   #84	-> 98
/*     */     //   #85	-> 103
/*     */     //   #86	-> 110
/*     */     //   #85	-> 113
/*     */     //   #87	-> 120
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	125	0	this	Lorg/eclipse/equinox/internal/app/DefaultApplicationListener;
/*     */     //   0	125	1	context	Ljava/lang/Object;
/*     */     //   23	102	2	anyThreadedDefaultApp	Lorg/eclipse/equinox/internal/app/EclipseAppHandle;
/*     */     //   39	52	3	mainHandle	Lorg/eclipse/equinox/internal/app/EclipseAppHandle;
/*     */     //   54	32	4	e	Ljava/lang/Throwable;
/*     */     //   66	20	5	message	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   31	101	101	finally
/*     */     //   43	49	52	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized EclipseAppHandle getMainHandle() {
/*  91 */     return this.launchMainApp;
/*     */   }
/*     */   
/*     */   private synchronized void unsetMainHandle(EclipseAppHandle mainHandle) {
/*  95 */     if (this.launchMainApp == mainHandle)
/*  96 */       this.launchMainApp = null; 
/*     */   }
/*     */   
/*     */   private synchronized boolean waitOnRunning() {
/* 100 */     if (!this.running)
/* 101 */       return false; 
/*     */     try {
/* 103 */       wait(100L);
/* 104 */     } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */     
/* 107 */     return this.running;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 112 */     if (this.handleTracker == null) {
/*     */       return;
/*     */     }
/* 115 */     ApplicationHandle handle = (ApplicationHandle)this.handleTracker.getService();
/* 116 */     if (handle != null) {
/*     */       try {
/* 118 */         handle.destroy();
/* 119 */       } catch (Throwable t) {
/* 120 */         String message = NLS.bind(Messages.application_error_stopping, handle.getInstanceId());
/* 121 */         Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 2, 0, message, 0, t, null));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object addingService(ServiceReference reference) {
/* 128 */     return Activator.getContext().getService(reference);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference reference, Object service) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removedService(ServiceReference reference, Object service) {
/* 138 */     this.running = false;
/*     */ 
/*     */     
/* 141 */     this.result = ((EclipseAppHandle)service).waitForResult(5000);
/* 142 */     EclipseAppHandle mainHandle = getMainHandle();
/* 143 */     if (mainHandle != null)
/*     */       
/*     */       try {
/* 146 */         mainHandle.destroy();
/* 147 */       } catch (Throwable t) {
/* 148 */         String message = NLS.bind(Messages.application_error_stopping, mainHandle.getInstanceId());
/* 149 */         Activator.log(new FrameworkLogEntry("org.eclipse.equinox.app", 2, 0, message, 0, t, null));
/*     */       }  
/* 151 */     notify();
/*     */   }
/*     */   
/*     */   synchronized void launch(EclipseAppHandle app) {
/* 155 */     this.launchMainApp = app;
/* 156 */     notify();
/*     */   }
/*     */   
/*     */   private synchronized Object getResult() {
/* 160 */     return this.result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\eclipse\equinox\internal\app\DefaultApplicationListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */