/*     */ package org.osgi.service.application;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationAdminPermission
/*     */   extends Permission
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String LIFECYCLE_ACTION = "lifecycle";
/*     */   public static final String SCHEDULE_ACTION = "schedule";
/*     */   public static final String LOCK_ACTION = "lock";
/*     */   private ApplicationDescriptor applicationDescriptor;
/*     */   private String applicationID;
/*     */   
/*     */   public ApplicationAdminPermission(String filter, String actions) throws InvalidSyntaxException {
/* 100 */     super((filter == null) ? "*" : filter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     this.appliedFilter = null; if (filter == null) filter = "*";  if (actions == null) throw new NullPointerException("Action string cannot be null!");  this.applicationDescriptor = null; this.filter = (filter == null) ? "*" : filter; this.actions = actions; if (!filter.equals("*") && !filter.equals("<<SELF>>")) FrameworkUtil.createFilter(this.filter);  init(); } public ApplicationAdminPermission(ApplicationDescriptor application, String actions) { super(application.getApplicationId()); this.appliedFilter = null; if (application == null || actions == null) throw new NullPointerException("ApplicationDescriptor and action string cannot be null!");  this.filter = application.getApplicationId(); this.applicationDescriptor = application; this.actions = actions; init(); }
/*     */   public ApplicationAdminPermission setCurrentApplicationId(String applicationId) { ApplicationAdminPermission newPerm = null; if (this.applicationDescriptor == null) { try { newPerm = new ApplicationAdminPermission(this.filter, this.actions); } catch (InvalidSyntaxException e) { throw new RuntimeException(e); }  } else { newPerm = new ApplicationAdminPermission(this.applicationDescriptor, this.actions); }  newPerm.applicationID = applicationId; return newPerm; }
/*     */   public boolean implies(Permission otherPermission) { if (otherPermission == null) return false;  if (!(otherPermission instanceof ApplicationAdminPermission)) return false;  ApplicationAdminPermission other = (ApplicationAdminPermission)otherPermission; if (!this.filter.equals("*")) { if (other.applicationDescriptor == null) return false;  if (this.filter.equals("<<SELF>>")) { if (other.applicationID == null) return false;  if (!other.applicationID.equals(other.applicationDescriptor.getApplicationId())) return false;  } else { Hashtable<Object, Object> props = new Hashtable<>(); props.put("pid", other.applicationDescriptor.getApplicationId()); props.put("signer", new SignerWrapper(other.applicationDescriptor)); Filter flt = getFilter(); if (flt == null) return false;  if (!flt.match(props)) return false;  }  }  if (!this.actionsVector.containsAll(other.actionsVector)) return false;  return true; }
/* 290 */   public boolean equals(Object with) { if (with == null || !(with instanceof ApplicationAdminPermission)) return false;  ApplicationAdminPermission other = (ApplicationAdminPermission)with; if (other.actionsVector.size() != this.actionsVector.size()) return false;  for (int i = 0; i != this.actionsVector.size(); i++) { if (!other.actionsVector.contains(this.actionsVector.get(i))) return false;  }  return (equal(this.filter, other.filter) && equal(this.applicationDescriptor, other.applicationDescriptor) && equal(this.applicationID, other.applicationID)); } private static boolean equal(Object a, Object b) { if (a == b) return true;  return a.equals(b); } public int hashCode() { int hc = 0; for (int i = 0; i != this.actionsVector.size(); i++) hc ^= ((String)this.actionsVector.get(i)).hashCode();  hc ^= (this.filter == null) ? 0 : this.filter.hashCode(); hc ^= (this.applicationDescriptor == null) ? 0 : this.applicationDescriptor.hashCode(); hc ^= (this.applicationID == null) ? 0 : this.applicationID.hashCode(); return hc; } static { ACTIONS.add("lifecycle");
/* 291 */     ACTIONS.add("schedule");
/* 292 */     ACTIONS.add("lock"); }
/*     */    public String getActions() {
/*     */     return this.actions;
/*     */   } private static final Vector ACTIONS = new Vector(); private Vector actionsVector; private final String filter; private final String actions; private Filter appliedFilter; private static Vector actionsVector(String actions) {
/* 296 */     Vector<String> v = new Vector();
/* 297 */     StringTokenizer t = new StringTokenizer(actions.toUpperCase(), ",");
/* 298 */     while (t.hasMoreTokens()) {
/* 299 */       String action = t.nextToken().trim();
/* 300 */       v.add(action.toLowerCase());
/*     */     } 
/*     */     
/* 303 */     if (v.contains("schedule") && !v.contains("lifecycle")) {
/* 304 */       v.add("lifecycle");
/*     */     }
/* 306 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SignerWrapper
/*     */   {
/*     */     private String pattern;
/*     */     
/*     */     private ApplicationDescriptor appDesc;
/*     */ 
/*     */     
/*     */     public SignerWrapper(String pattern) {
/* 318 */       this.pattern = pattern;
/*     */     }
/*     */     
/*     */     SignerWrapper(ApplicationDescriptor appDesc) {
/* 322 */       this.appDesc = appDesc;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 327 */       if (!(o instanceof SignerWrapper))
/* 328 */         return false; 
/* 329 */       SignerWrapper other = (SignerWrapper)o;
/* 330 */       ApplicationDescriptor matchAppDesc = (this.appDesc != null) ? this.appDesc : other.appDesc;
/* 331 */       String matchPattern = (this.appDesc != null) ? other.pattern : this.pattern;
/* 332 */       return matchAppDesc.matchDNChain(matchPattern);
/*     */     }
/*     */   }
/*     */   
/*     */   private void init() {
/* 337 */     this.actionsVector = actionsVector(this.actions);
/*     */     
/* 339 */     if (this.actions.equals("*")) {
/* 340 */       this.actionsVector = actionsVector("lifecycle,schedule,lock");
/* 341 */     } else if (!ACTIONS.containsAll(this.actionsVector)) {
/* 342 */       throw new IllegalArgumentException("Illegal action!");
/*     */     } 
/* 344 */     this.applicationID = null;
/*     */   }
/*     */   
/*     */   private Filter getFilter() {
/* 348 */     if (this.appliedFilter == null) {
/*     */       try {
/* 350 */         this.appliedFilter = FrameworkUtil.createFilter(this.filter);
/* 351 */       } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */     }
/*     */ 
/*     */     
/* 355 */     return this.appliedFilter;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\osgi\service\application\ApplicationAdminPermission.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */