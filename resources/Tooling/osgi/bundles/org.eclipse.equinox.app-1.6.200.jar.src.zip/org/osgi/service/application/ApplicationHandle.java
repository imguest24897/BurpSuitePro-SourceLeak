/*     */ package org.osgi.service.application;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApplicationHandle
/*     */ {
/*     */   public static final String APPLICATION_PID = "service.pid";
/*     */   public static final String APPLICATION_DESCRIPTOR = "application.descriptor";
/*     */   public static final String APPLICATION_STATE = "application.state";
/*     */   public static final String APPLICATION_SUPPORTS_EXITVALUE = "application.supports.exitvalue";
/*     */   public static final String RUNNING = "RUNNING";
/*     */   public static final String STOPPING = "STOPPING";
/*     */   private final String instanceId;
/*     */   private final ApplicationDescriptor descriptor;
/*     */   
/*     */   protected ApplicationHandle(String instanceId, ApplicationDescriptor descriptor) {
/* 103 */     if (instanceId == null || descriptor == null) {
/* 104 */       throw new NullPointerException("Parameters must not be null!");
/*     */     }
/*     */     
/* 107 */     this.instanceId = instanceId;
/* 108 */     this.descriptor = descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ApplicationDescriptor getApplicationDescriptor() {
/* 118 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getExitValue(long timeout) throws ApplicationException, InterruptedException {
/* 167 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getInstanceId() {
/* 177 */     return this.instanceId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void destroy() {
/* 210 */     if ("STOPPING".equals(getState()))
/*     */       return; 
/* 212 */     SecurityManager sm = System.getSecurityManager();
/* 213 */     if (sm != null)
/* 214 */       sm.checkPermission(new ApplicationAdminPermission(getApplicationDescriptor(), "lifecycle")); 
/* 215 */     destroySpecific();
/*     */   }
/*     */   
/*     */   protected abstract void destroySpecific();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\osgi\service\application\ApplicationHandle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */