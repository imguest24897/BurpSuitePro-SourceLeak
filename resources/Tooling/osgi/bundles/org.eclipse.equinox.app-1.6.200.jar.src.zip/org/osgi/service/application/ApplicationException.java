/*     */ package org.osgi.service.application;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -7173190453622508207L;
/*     */   private final int errorCode;
/*     */   public static final int APPLICATION_LOCKED = 1;
/*     */   public static final int APPLICATION_NOT_LAUNCHABLE = 2;
/*     */   public static final int APPLICATION_INTERNAL_ERROR = 3;
/*     */   public static final int APPLICATION_SCHEDULING_FAILED = 4;
/*     */   public static final int APPLICATION_DUPLICATE_SCHEDULE_ID = 5;
/*     */   public static final int APPLICATION_EXITVALUE_NOT_AVAILABLE = 6;
/*     */   public static final int APPLICATION_INVALID_STARTUP_ARGUMENT = 7;
/*     */   
/*     */   public ApplicationException(int errorCode) {
/* 106 */     this.errorCode = errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationException(int errorCode, Throwable cause) {
/* 116 */     super(cause);
/* 117 */     this.errorCode = errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationException(int errorCode, String message) {
/* 126 */     super(message);
/* 127 */     this.errorCode = errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationException(int errorCode, String message, Throwable cause) {
/* 138 */     super(message, cause);
/* 139 */     this.errorCode = errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getCause() {
/* 151 */     return super.getCause();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorCode() {
/* 160 */     return this.errorCode;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\osgi\service\application\ApplicationException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */