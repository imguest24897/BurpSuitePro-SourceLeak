/*     */ package org.osgi.service.application;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.equinox.internal.app.AppPersistence;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApplicationDescriptor
/*     */ {
/*     */   public static final String APPLICATION_NAME = "application.name";
/*     */   public static final String APPLICATION_ICON = "application.icon";
/*     */   public static final String APPLICATION_PID = "service.pid";
/*     */   public static final String APPLICATION_VERSION = "application.version";
/*     */   public static final String APPLICATION_VENDOR = "service.vendor";
/*     */   public static final String APPLICATION_VISIBLE = "application.visible";
/*     */   public static final String APPLICATION_LAUNCHABLE = "application.launchable";
/*     */   public static final String APPLICATION_LOCKED = "application.locked";
/*     */   public static final String APPLICATION_DESCRIPTION = "application.description";
/*     */   public static final String APPLICATION_DOCUMENTATION = "application.documentation";
/*     */   public static final String APPLICATION_COPYRIGHT = "application.copyright";
/*     */   public static final String APPLICATION_LICENSE = "application.license";
/*     */   public static final String APPLICATION_CONTAINER = "application.container";
/*     */   public static final String APPLICATION_LOCATION = "application.location";
/*     */   private final String pid;
/* 114 */   private final boolean[] locked = new boolean[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ApplicationDescriptor(String applicationId) {
/* 127 */     if (applicationId == null) {
/* 128 */       throw new NullPointerException("Application ID must not be null!");
/*     */     }
/*     */     
/* 131 */     this.pid = applicationId;
/* 132 */     this.locked[0] = isPersistentlyLocked();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getApplicationId() {
/* 141 */     return this.pid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean matchDNChain(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map getProperties(String locale) {
/* 197 */     Map<String, Boolean> props = getPropertiesSpecific(locale);
/* 198 */     Boolean containerLocked = (Boolean)props.remove("application.locked");
/* 199 */     synchronized (this.locked) {
/* 200 */       if (containerLocked != null && containerLocked.booleanValue() != this.locked[0]) {
/* 201 */         if (this.locked[0]) {
/* 202 */           lockSpecific();
/*     */         } else {
/* 204 */           unlockSpecific();
/*     */         } 
/*     */       }
/*     */     } 
/* 208 */     props.put("application.locked", Boolean.valueOf(this.locked[0]));
/* 209 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map getPropertiesSpecific(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ApplicationHandle launch(Map arguments) throws ApplicationException {
/* 300 */     SecurityManager sm = System.getSecurityManager();
/* 301 */     if (sm != null)
/* 302 */       sm.checkPermission(new ApplicationAdminPermission(this, "lifecycle")); 
/* 303 */     synchronized (this.locked) {
/* 304 */       if (this.locked[0])
/* 305 */         throw new ApplicationException(1, "Application is locked, can't launch!"); 
/*     */     } 
/* 307 */     if (!isLaunchableSpecific())
/* 308 */       throw new ApplicationException(2, "Cannot launch the application!"); 
/* 309 */     checkArgs(arguments, false);
/*     */     try {
/* 311 */       return launchSpecific(arguments);
/* 312 */     } catch (IllegalStateException|SecurityException|ApplicationException ise) {
/* 313 */       throw ise;
/* 314 */     } catch (Exception t) {
/* 315 */       throw new ApplicationException(3, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ApplicationHandle launchSpecific(Map paramMap) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isLaunchableSpecific();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ScheduledApplication schedule(String scheduleId, Map arguments, String topic, String eventFilter, boolean recurring) throws InvalidSyntaxException, ApplicationException {
/* 417 */     SecurityManager sm = System.getSecurityManager();
/* 418 */     if (sm != null)
/* 419 */       sm.checkPermission(new ApplicationAdminPermission(this, "schedule")); 
/* 420 */     arguments = checkArgs(arguments, true);
/* 421 */     isLaunchableSpecific();
/* 422 */     return AppPersistence.addScheduledApp(this, scheduleId, arguments, topic, eventFilter, recurring);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void lock() {
/* 437 */     SecurityManager sm = System.getSecurityManager();
/* 438 */     if (sm != null)
/* 439 */       sm.checkPermission(new ApplicationAdminPermission(this, "lock")); 
/* 440 */     synchronized (this.locked) {
/* 441 */       if (this.locked[0])
/*     */         return; 
/* 443 */       this.locked[0] = true;
/* 444 */       lockSpecific();
/* 445 */       saveLock(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void lockSpecific();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void unlock() {
/* 468 */     SecurityManager sm = System.getSecurityManager();
/* 469 */     if (sm != null)
/* 470 */       sm.checkPermission(new ApplicationAdminPermission(this, "lock")); 
/* 471 */     synchronized (this.locked) {
/* 472 */       if (!this.locked[0])
/*     */         return; 
/* 474 */       this.locked[0] = false;
/* 475 */       unlockSpecific();
/* 476 */       saveLock(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void unlockSpecific();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveLock(boolean locked) {
/* 491 */     AppPersistence.saveLock(this, locked);
/*     */   }
/*     */   
/*     */   private boolean isPersistentlyLocked() {
/* 495 */     return AppPersistence.isLocked(this);
/*     */   }
/*     */   
/* 498 */   private static final Collection scalars = Arrays.asList((Class<?>[][])new Class[] { String.class, Integer.class, Long.class, Float.class, Double.class, Byte.class, Short.class, Character.class, Boolean.class });
/* 499 */   private static final Collection scalarsArrays = Arrays.asList((Class<?>[][])new Class[] { String[].class, Integer[].class, Long[].class, Float[].class, Double[].class, Byte[].class, Short[].class, Character[].class, Boolean[].class });
/* 500 */   private static final Collection primitiveArrays = Arrays.asList((Class<?>[][])new Class[] { long[].class, int[].class, short[].class, char[].class, byte[].class, double[].class, float[].class, boolean[].class });
/*     */   
/*     */   private static Map checkArgs(Map arguments, boolean validateValues) throws ApplicationException {
/* 503 */     if (arguments == null)
/* 504 */       return arguments; 
/* 505 */     Map copy = validateValues ? new HashMap<>() : null;
/* 506 */     for (Iterator<Map.Entry> entries = arguments.entrySet().iterator(); entries.hasNext(); ) {
/* 507 */       Map.Entry entry = entries.next();
/* 508 */       if (!(entry.getKey() instanceof String))
/* 509 */         throw new IllegalArgumentException(("Invalid key type: " + entry.getKey() == null) ? "<null>" : entry.getKey().getClass().getName()); 
/* 510 */       if ("".equals(entry.getKey()))
/* 511 */         throw new IllegalArgumentException("Empty string is an invalid key"); 
/* 512 */       if (validateValues)
/* 513 */         validateValue(entry, copy); 
/*     */     } 
/* 515 */     return validateValues ? copy : arguments;
/*     */   }
/*     */   
/*     */   private static void validateValue(Map.Entry entry, Map copy) throws ApplicationException {
/* 519 */     Class<?> clazz = entry.getValue().getClass();
/*     */ 
/*     */     
/* 522 */     if (scalars.contains(clazz)) {
/* 523 */       copy.put(entry.getKey(), entry.getValue());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 528 */     if (scalarsArrays.contains(clazz) || primitiveArrays.contains(clazz)) {
/* 529 */       int arrayLength = Array.getLength(entry.getValue());
/* 530 */       Object copyOfArray = Array.newInstance(entry.getValue().getClass().getComponentType(), arrayLength);
/* 531 */       System.arraycopy(entry.getValue(), 0, copyOfArray, 0, arrayLength);
/* 532 */       copy.put(entry.getKey(), copyOfArray);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 537 */     if (entry.getValue() instanceof Collection) {
/* 538 */       Collection valueCollection = (Collection)entry.getValue();
/* 539 */       for (Iterator<E> it = valueCollection.iterator(); it.hasNext(); ) {
/* 540 */         Class<?> containedClazz = it.next().getClass();
/* 541 */         if (!scalars.contains(containedClazz)) {
/* 542 */           throw new ApplicationException(7, "The value for key \"" + entry.getKey() + "\" is a collection that contains an invalid value of type \"" + containedClazz.getName() + "\"");
/*     */         }
/*     */       } 
/* 545 */       copy.put(entry.getKey(), new ArrayList((Collection)entry.getValue()));
/*     */       return;
/*     */     } 
/* 548 */     throw new ApplicationException(7, "The value for key \"" + entry.getKey() + "\" is an invalid type \"" + clazz.getName() + "\"");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\osgi\service\application\ApplicationDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */