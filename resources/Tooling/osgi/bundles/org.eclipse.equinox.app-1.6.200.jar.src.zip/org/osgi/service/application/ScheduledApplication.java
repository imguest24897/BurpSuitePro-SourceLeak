package org.osgi.service.application;

import java.util.Map;

public interface ScheduledApplication {
  public static final String APPLICATION_PID = "service.pid";
  
  public static final String SCHEDULE_ID = "schedule.id";
  
  public static final String TRIGGERING_EVENT = "org.osgi.triggeringevent";
  
  public static final String TIMER_TOPIC = "org/osgi/application/timer";
  
  public static final String YEAR = "year";
  
  public static final String MONTH = "month";
  
  public static final String DAY_OF_MONTH = "day_of_month";
  
  public static final String DAY_OF_WEEK = "day_of_week";
  
  public static final String HOUR_OF_DAY = "hour_of_day";
  
  public static final String MINUTE = "minute";
  
  String getScheduleId();
  
  String getTopic();
  
  String getEventFilter();
  
  boolean isRecurring();
  
  ApplicationDescriptor getApplicationDescriptor();
  
  Map getArguments();
  
  void remove();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.equinox.app-1.6.200.jar!\org\osgi\service\application\ScheduledApplication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */