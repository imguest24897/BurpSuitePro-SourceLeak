package org.eclipse.equinox.log;

import org.osgi.framework.Bundle;

public interface LogFilter {
  boolean isLoggable(Bundle paramBundle, String paramString, int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\LogFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */