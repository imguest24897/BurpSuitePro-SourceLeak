/*    */ package org.eclipse.equinox.log;
/*    */ 
/*    */ import java.security.Permission;
/*    */ import java.security.PermissionCollection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogPermission
/*    */   extends Permission
/*    */ {
/*    */   private static final long serialVersionUID = -441193976837153362L;
/*    */   private static final String ALL = "*";
/*    */   public static final String LOG = "log";
/*    */   
/*    */   public LogPermission(String name, String actions) {
/* 40 */     super(name);
/* 41 */     if (!name.equals("*")) {
/* 42 */       throw new IllegalArgumentException("name must be *");
/*    */     }
/* 44 */     actions = actions.trim();
/* 45 */     if (!actions.equalsIgnoreCase("log") && !actions.equals("*")) {
/* 46 */       throw new IllegalArgumentException("actions must be * or log");
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 51 */     return obj instanceof LogPermission;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getActions() {
/* 56 */     return "log";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 61 */     return LogPermission.class.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean implies(Permission permission) {
/* 66 */     return permission instanceof LogPermission;
/*    */   }
/*    */ 
/*    */   
/*    */   public PermissionCollection newPermissionCollection() {
/* 71 */     return new LogPermissionCollection();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\LogPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */