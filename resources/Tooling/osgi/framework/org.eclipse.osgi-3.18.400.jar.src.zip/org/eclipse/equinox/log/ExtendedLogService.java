package org.eclipse.equinox.log;

import org.osgi.framework.Bundle;
import org.osgi.service.log.LogService;
import org.osgi.service.log.Logger;

public interface ExtendedLogService extends LogService, Logger {
  Logger getLogger(String paramString);
  
  Logger getLogger(Bundle paramBundle, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\ExtendedLogService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */