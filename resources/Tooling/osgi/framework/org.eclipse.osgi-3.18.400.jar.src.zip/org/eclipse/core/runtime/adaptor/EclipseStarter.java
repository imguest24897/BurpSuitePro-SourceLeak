/*      */ package org.eclipse.core.runtime.adaptor;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.URLStreamHandler;
/*      */ import java.security.CodeSource;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.Semaphore;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.eclipse.core.runtime.internal.adaptor.ConsoleManager;
/*      */ import org.eclipse.core.runtime.internal.adaptor.DefaultStartupMonitor;
/*      */ import org.eclipse.core.runtime.internal.adaptor.EclipseAppLauncher;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleRevision;
/*      */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*      */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*      */ import org.eclipse.osgi.framework.util.FilePath;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*      */ import org.eclipse.osgi.internal.location.LocationHelper;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.launch.Equinox;
/*      */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*      */ import org.eclipse.osgi.service.datalocation.Location;
/*      */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*      */ import org.eclipse.osgi.service.runnable.ApplicationLauncher;
/*      */ import org.eclipse.osgi.service.runnable.StartupMonitor;
/*      */ import org.eclipse.osgi.storage.url.reference.Handler;
/*      */ import org.eclipse.osgi.util.ManifestElement;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleEvent;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.BundleListener;
/*      */ import org.osgi.framework.FrameworkEvent;
/*      */ import org.osgi.framework.FrameworkListener;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.ServiceRegistration;
/*      */ import org.osgi.framework.SynchronousBundleListener;
/*      */ import org.osgi.framework.launch.Framework;
/*      */ import org.osgi.framework.startlevel.BundleStartLevel;
/*      */ import org.osgi.framework.startlevel.FrameworkStartLevel;
/*      */ import org.osgi.framework.wiring.FrameworkWiring;
/*      */ import org.osgi.resource.Resource;
/*      */ import org.osgi.util.tracker.ServiceTracker;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class EclipseStarter
/*      */ {
/*      */   private static BundleContext context;
/*      */   private static boolean initialize = false;
/*      */   public static boolean debug = false;
/*      */   private static boolean running = false;
/*   76 */   private static ServiceRegistration<?> defaultMonitorRegistration = null;
/*   77 */   private static ServiceRegistration<?> appLauncherRegistration = null;
/*   78 */   private static ServiceRegistration<?> splashStreamRegistration = null;
/*      */   
/*      */   private static final String CLEAN = "-clean";
/*      */   
/*      */   private static final String CONSOLE = "-console";
/*      */   
/*      */   private static final String CONSOLE_LOG = "-consoleLog";
/*      */   
/*      */   private static final String DEBUG = "-debug";
/*      */   
/*      */   private static final String INITIALIZE = "-initialize";
/*      */   
/*      */   private static final String DEV = "-dev";
/*      */   
/*      */   private static final String WS = "-ws";
/*      */   
/*      */   private static final String OS = "-os";
/*      */   
/*      */   private static final String ARCH = "-arch";
/*      */   
/*      */   private static final String NL = "-nl";
/*      */   
/*      */   private static final String NL_EXTENSIONS = "-nlExtensions";
/*      */   
/*      */   private static final String CONFIGURATION = "-configuration";
/*      */   private static final String USER = "-user";
/*      */   private static final String NOEXIT = "-noExit";
/*      */   private static final String LAUNCHER = "-launcher";
/*      */   private static final String DATA = "-data";
/*      */   public static final String PROP_BUNDLES = "osgi.bundles";
/*      */   public static final String PROP_BUNDLES_STARTLEVEL = "osgi.bundles.defaultStartLevel";
/*      */   public static final String PROP_EXTENSIONS = "osgi.framework.extensions";
/*      */   public static final String PROP_INITIAL_STARTLEVEL = "osgi.startLevel";
/*      */   public static final String PROP_DEBUG = "osgi.debug";
/*      */   public static final String PROP_DEV = "osgi.dev";
/*      */   public static final String PROP_CLEAN = "osgi.clean";
/*      */   public static final String PROP_CONSOLE = "osgi.console";
/*      */   public static final String PROP_CONSOLE_CLASS = "osgi.consoleClass";
/*      */   public static final String PROP_CHECK_CONFIG = "osgi.checkConfiguration";
/*      */   public static final String PROP_OS = "osgi.os";
/*      */   public static final String PROP_WS = "osgi.ws";
/*      */   public static final String PROP_NL = "osgi.nl";
/*      */   private static final String PROP_NL_EXTENSIONS = "osgi.nl.extensions";
/*      */   public static final String PROP_ARCH = "osgi.arch";
/*      */   public static final String PROP_ADAPTOR = "osgi.adaptor";
/*      */   public static final String PROP_SYSPATH = "osgi.syspath";
/*      */   public static final String PROP_LOGFILE = "osgi.logfile";
/*      */   public static final String PROP_FRAMEWORK = "osgi.framework";
/*      */   public static final String PROP_INSTALL_AREA = "osgi.install.area";
/*      */   public static final String PROP_FRAMEWORK_SHAPE = "osgi.framework.shape";
/*      */   public static final String PROP_NOSHUTDOWN = "osgi.noShutdown";
/*      */   public static final String PROP_EXITCODE = "eclipse.exitcode";
/*      */   public static final String PROP_EXITDATA = "eclipse.exitdata";
/*      */   public static final String PROP_CONSOLE_LOG = "eclipse.consoleLog";
/*      */   public static final String PROP_IGNOREAPP = "eclipse.ignoreApp";
/*      */   public static final String PROP_REFRESH_BUNDLES = "eclipse.refreshBundles";
/*      */   public static final String PROP_ALLOW_APPRELAUNCH = "eclipse.allowAppRelaunch";
/*      */   private static final String PROP_APPLICATION_LAUNCHDEFAULT = "eclipse.application.launchDefault";
/*      */   private static final String FILE_SCHEME = "file:";
/*      */   private static final String REFERENCE_SCHEME = "reference:";
/*      */   private static final String REFERENCE_PROTOCOL = "reference";
/*      */   private static final String INITIAL_LOCATION = "initial@";
/*      */   private static final int DEFAULT_INITIAL_STARTLEVEL = 6;
/*      */   private static final String DEFAULT_BUNDLES_STARTLEVEL = "4";
/*      */   private static FrameworkLog log;
/*  143 */   private static Map<String, String[]> searchCandidates = (Map)new HashMap<>(4);
/*      */   
/*      */   private static EclipseAppLauncher appLauncher;
/*      */   private static List<Runnable> shutdownHandlers;
/*  147 */   private static ConsoleManager consoleMgr = null;
/*      */   
/*  149 */   private static Map<String, String> configuration = null;
/*  150 */   private static Framework framework = null;
/*      */   private static EquinoxConfiguration equinoxConfig;
/*  152 */   private static String[] allArgs = null;
/*  153 */   private static String[] frameworkArgs = null;
/*  154 */   private static String[] appArgs = null;
/*      */   
/*      */   private static synchronized String getProperty(String key) {
/*  157 */     if (equinoxConfig != null) {
/*  158 */       return equinoxConfig.getConfiguration(key);
/*      */     }
/*  160 */     return getConfiguration().get(key);
/*      */   }
/*      */   
/*      */   private static synchronized String getProperty(String key, String dft) {
/*  164 */     if (equinoxConfig != null) {
/*  165 */       return equinoxConfig.getConfiguration(key, dft);
/*      */     }
/*  167 */     String result = getConfiguration().get(key);
/*  168 */     return (result == null) ? dft : result;
/*      */   }
/*      */   
/*      */   private static synchronized Object setProperty(String key, String value) {
/*  172 */     if (equinoxConfig != null) {
/*  173 */       return equinoxConfig.setProperty(key, value);
/*      */     }
/*  175 */     if ("true".equals(getConfiguration().get("osgi.framework.useSystemProperties"))) {
/*  176 */       System.setProperty(key, value);
/*      */     }
/*  178 */     return getConfiguration().put(key, value);
/*      */   }
/*      */   
/*      */   private static synchronized Object clearProperty(String key) {
/*  182 */     if (equinoxConfig != null) {
/*  183 */       return equinoxConfig.clearConfiguration(key);
/*      */     }
/*  185 */     return getConfiguration().remove(key);
/*      */   }
/*      */   
/*      */   private static synchronized Map<String, String> getConfiguration() {
/*  189 */     if (configuration == null) {
/*  190 */       configuration = new HashMap<>();
/*      */ 
/*      */       
/*  193 */       configuration.put("osgi.framework.useSystemProperties", System.getProperty("osgi.framework.useSystemProperties", "true"));
/*      */       
/*  195 */       String systemCompatibilityBoot = System.getProperty("osgi.compatibility.bootdelegation");
/*  196 */       if (systemCompatibilityBoot != null) {
/*      */         
/*  198 */         configuration.put("osgi.compatibility.bootdelegation", systemCompatibilityBoot);
/*      */       } else {
/*      */         
/*  201 */         configuration.put("osgi.compatibility.bootdelegation.default", "true");
/*      */       } 
/*      */       
/*  204 */       String dsDelayedKeepInstances = System.getProperty("ds.delayed.keepInstances");
/*  205 */       if (dsDelayedKeepInstances != null) {
/*      */         
/*  207 */         configuration.put("ds.delayed.keepInstances", dsDelayedKeepInstances);
/*      */       } else {
/*      */         
/*  210 */         configuration.put("ds.delayed.keepInstances.default", "true");
/*      */       } 
/*      */     } 
/*  213 */     return configuration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) throws Exception {
/*  221 */     if (getProperty("eclipse.startTime") == null)
/*  222 */       setProperty("eclipse.startTime", Long.toString(System.currentTimeMillis())); 
/*  223 */     if (getProperty("osgi.noShutdown") == null) {
/*  224 */       setProperty("osgi.noShutdown", "true");
/*      */     }
/*  226 */     if (getProperty("osgi.compatibility.bootdelegation") == null)
/*  227 */       setProperty("osgi.compatibility.bootdelegation", "false"); 
/*  228 */     Object result = run(args, null);
/*  229 */     if (result instanceof Integer && !Boolean.valueOf(getProperty("osgi.noShutdown")).booleanValue()) {
/*  230 */       System.exit(((Integer)result).intValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object run(String[] args, Runnable endSplashHandler) throws Exception {
/*  247 */     if (running)
/*  248 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ALREADY_RUNNING); 
/*  249 */     boolean startupFailed = true;
/*      */     try {
/*  251 */       startup(args, endSplashHandler);
/*  252 */       startupFailed = false;
/*  253 */       if (Boolean.valueOf(getProperty("eclipse.ignoreApp")).booleanValue() || isForcedRestart())
/*  254 */         return null; 
/*  255 */       return run(null);
/*  256 */     } catch (Throwable e) {
/*      */       
/*  258 */       if (endSplashHandler != null) {
/*  259 */         endSplashHandler.run();
/*      */       }
/*  261 */       FrameworkLogEntry logEntry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, startupFailed ? Msg.ECLIPSE_STARTUP_STARTUP_ERROR : Msg.ECLIPSE_STARTUP_APP_ERROR, 1, e, null);
/*  262 */       if (log != null) {
/*  263 */         log.log(logEntry);
/*      */       } else {
/*      */         
/*  266 */         e.printStackTrace();
/*      */       } 
/*      */     } finally {
/*      */       
/*      */       try {
/*  271 */         if (isForcedRestart())
/*  272 */           setProperty("eclipse.exitcode", "23"); 
/*  273 */         if (!Boolean.valueOf(getProperty("osgi.noShutdown")).booleanValue())
/*  274 */           shutdown(); 
/*  275 */       } catch (Throwable e) {
/*  276 */         FrameworkLogEntry logEntry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, Msg.ECLIPSE_STARTUP_SHUTDOWN_ERROR, 1, e, null);
/*  277 */         if (log != null) {
/*  278 */           log.log(logEntry);
/*      */         } else {
/*      */           
/*  281 */           e.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     } 
/*  285 */     if (getProperty("eclipse.exitcode") == null) {
/*  286 */       setProperty("eclipse.exitcode", "13");
/*  287 */       setProperty("eclipse.exitdata", NLS.bind(Msg.ECLIPSE_STARTUP_ERROR_CHECK_LOG, (log == null) ? null : log.getFile().getPath()));
/*      */     } 
/*  289 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isRunning() {
/*  297 */     return running;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BundleContext startup(String[] args, Runnable endSplashHandler) throws Exception {
/*  312 */     if (running)
/*  313 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ALREADY_RUNNING); 
/*  314 */     processCommandLine(args);
/*  315 */     framework = (Framework)new Equinox(getConfiguration());
/*  316 */     framework.init();
/*  317 */     context = framework.getBundleContext();
/*  318 */     ServiceReference<FrameworkLog> logRef = context.getServiceReference(FrameworkLog.class);
/*  319 */     log = (FrameworkLog)context.getService(logRef);
/*  320 */     ServiceReference<EnvironmentInfo> configRef = context.getServiceReference(EnvironmentInfo.class);
/*  321 */     equinoxConfig = (EquinoxConfiguration)context.getService(configRef);
/*      */     
/*  323 */     equinoxConfig.setAllArgs(allArgs);
/*  324 */     equinoxConfig.setFrameworkArgs(frameworkArgs);
/*  325 */     equinoxConfig.setAppArgs(appArgs);
/*      */     
/*  327 */     registerFrameworkShutdownHandlers();
/*  328 */     publishSplashScreen(endSplashHandler);
/*  329 */     consoleMgr = ConsoleManager.startConsole(context, equinoxConfig);
/*      */     
/*  331 */     Bundle[] startBundles = loadBasicBundles();
/*      */     
/*  333 */     if (startBundles == null || ("true".equals(getProperty("eclipse.refreshBundles")) && refreshPackages(getCurrentBundles(false)))) {
/*  334 */       waitForShutdown();
/*  335 */       return context;
/*      */     } 
/*      */     
/*  338 */     framework.start();
/*      */     
/*  340 */     if (isForcedRestart()) {
/*  341 */       waitForShutdown();
/*  342 */       return context;
/*      */     } 
/*      */ 
/*      */     
/*  346 */     setStartLevel(getStartLevel());
/*      */     
/*  348 */     ensureBundlesActive(startBundles);
/*      */ 
/*      */     
/*      */     try {
/*  352 */       consoleMgr.checkForConsoleBundle();
/*  353 */     } catch (BundleException e) {
/*  354 */       FrameworkLogEntry entry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, e.getMessage(), 0, (Throwable)e, null);
/*  355 */       log.log(entry);
/*      */     } 
/*      */     
/*  358 */     running = true;
/*  359 */     return context;
/*      */   }
/*      */   
/*      */   private static int getStartLevel() {
/*  363 */     String level = getProperty("osgi.startLevel");
/*  364 */     if (level != null)
/*      */       try {
/*  366 */         return Integer.parseInt(level);
/*  367 */       } catch (NumberFormatException numberFormatException) {
/*  368 */         if (debug)
/*  369 */           Debug.println("Start level = " + level + "  parsed. Using hardcoded default: 6"); 
/*      */       }  
/*  371 */     return 6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object run(Object argument) throws Exception {
/*  387 */     if (!running) {
/*  388 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_NOT_RUNNING);
/*      */     }
/*  390 */     if (initialize)
/*  391 */       return Integer.valueOf(0); 
/*      */     try {
/*  393 */       if (appLauncher == null) {
/*      */         
/*  395 */         boolean launchDefault = Boolean.parseBoolean(getProperty("eclipse.application.launchDefault", "true"));
/*      */         
/*  397 */         appLauncher = new EclipseAppLauncher(context, Boolean.parseBoolean(getProperty("eclipse.allowAppRelaunch")), launchDefault, log, equinoxConfig);
/*  398 */         appLauncherRegistration = context.registerService(ApplicationLauncher.class.getName(), appLauncher, null);
/*      */ 
/*      */ 
/*      */         
/*  402 */         return appLauncher.start(argument);
/*      */       } 
/*  404 */       return appLauncher.reStart(argument);
/*  405 */     } catch (Exception e) {
/*  406 */       if (log != null && context != null) {
/*  407 */         ResolutionReport report = ((Module)context.getBundle().adapt(Module.class)).getContainer().resolve(null, false);
/*  408 */         for (Resource unresolved : report.getEntries().keySet()) {
/*  409 */           String bsn = ((ModuleRevision)unresolved).getSymbolicName();
/*  410 */           FrameworkLogEntry logEntry = new FrameworkLogEntry((bsn != null) ? bsn : "org.eclipse.osgi", 2, 0, String.valueOf(Msg.Module_ResolveError) + report.getResolutionReportMessage(unresolved), 1, null, null);
/*  411 */           log.log(logEntry);
/*      */         } 
/*      */       } 
/*  414 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shutdown() throws Exception {
/*  436 */     if (!running || framework == null)
/*      */       return; 
/*  438 */     if (framework.getState() == 32) {
/*  439 */       if (appLauncherRegistration != null)
/*  440 */         appLauncherRegistration.unregister(); 
/*  441 */       if (splashStreamRegistration != null)
/*  442 */         splashStreamRegistration.unregister(); 
/*  443 */       if (defaultMonitorRegistration != null)
/*  444 */         defaultMonitorRegistration.unregister(); 
/*      */     } 
/*  446 */     if (appLauncher != null)
/*  447 */       appLauncher.shutdown(); 
/*  448 */     appLauncherRegistration = null;
/*  449 */     appLauncher = null;
/*  450 */     splashStreamRegistration = null;
/*  451 */     defaultMonitorRegistration = null;
/*  452 */     if (consoleMgr != null) {
/*  453 */       consoleMgr.stopConsole();
/*  454 */       consoleMgr = null;
/*      */     } 
/*  456 */     if (framework.getState() == 32) {
/*  457 */       framework.stop();
/*  458 */       framework.waitForStop(0L);
/*  459 */       framework = null;
/*      */     } 
/*  461 */     configuration = null;
/*  462 */     equinoxConfig = null;
/*  463 */     context = null;
/*  464 */     running = false; } private static void ensureBundlesActive(Bundle[] bundles) {
/*      */     byte b;
/*      */     int i;
/*      */     Bundle[] arrayOfBundle;
/*  468 */     for (i = (arrayOfBundle = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle[b];
/*  469 */       if (bundle.getState() != 32)
/*  470 */         if (bundle.getState() == 2) {
/*      */           
/*  472 */           log.log(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_ERROR_BUNDLE_NOT_RESOLVED, bundle.getLocation()), 0, null, null));
/*      */         }
/*      */         else {
/*      */           
/*  476 */           FrameworkStartLevel fwStartLevel = (FrameworkStartLevel)context.getBundle().adapt(FrameworkStartLevel.class);
/*  477 */           BundleStartLevel bundleStartLevel = (BundleStartLevel)bundle.adapt(BundleStartLevel.class);
/*  478 */           if (fwStartLevel != null && bundleStartLevel.getStartLevel() <= fwStartLevel.getStartLevel())
/*  479 */             log.log(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_ERROR_BUNDLE_NOT_ACTIVE, bundle), 0, null, null)); 
/*      */         }  
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   private static void publishSplashScreen(Runnable endSplashHandler) {
/*  486 */     if (endSplashHandler == null) {
/*      */       return;
/*      */     }
/*      */     try {
/*  490 */       Method method = endSplashHandler.getClass().getMethod("getOutputStream", new Class[0]);
/*  491 */       Object outputStream = method.invoke(endSplashHandler, new Object[0]);
/*  492 */       if (outputStream instanceof OutputStream) {
/*  493 */         Dictionary<String, Object> osProperties = new Hashtable<>();
/*  494 */         osProperties.put("name", "splashstream");
/*  495 */         splashStreamRegistration = context.registerService(OutputStream.class.getName(), outputStream, osProperties);
/*      */       } 
/*  497 */     } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  502 */       Dictionary<String, Object> monitorProps = new Hashtable<>();
/*  503 */       monitorProps.put("service.ranking", Integer.valueOf(-2147483648));
/*  504 */       defaultMonitorRegistration = context.registerService(StartupMonitor.class.getName(), new DefaultStartupMonitor(endSplashHandler, equinoxConfig), monitorProps);
/*  505 */     } catch (IllegalStateException illegalStateException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static URL searchForBundle(String name, String parent) throws MalformedURLException {
/*  512 */     URL url = null;
/*  513 */     File fileLocation = null;
/*  514 */     boolean reference = false;
/*      */     try {
/*  516 */       createURL(name);
/*  517 */       url = createURL((new File(parent)).toURL(), name);
/*  518 */     } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  523 */       File child = new File(name);
/*  524 */       fileLocation = child.isAbsolute() ? child : new File(parent, name);
/*  525 */       url = createURL("reference", null, fileLocation.toURL().toExternalForm());
/*  526 */       reference = true;
/*      */     } 
/*      */     
/*  529 */     if (!reference) {
/*  530 */       URL baseURL = url;
/*      */       
/*  532 */       if (url.getProtocol().equals("reference")) {
/*  533 */         reference = true;
/*  534 */         String baseSpec = url.getPath();
/*  535 */         if (baseSpec.startsWith("file:")) {
/*  536 */           File child = new File(baseSpec.substring(5));
/*  537 */           baseURL = child.isAbsolute() ? child.toURL() : (new File(parent, child.getPath())).toURL();
/*      */         } else {
/*  539 */           baseURL = createURL(baseSpec);
/*      */         } 
/*      */       } 
/*  542 */       fileLocation = new File(baseURL.getPath());
/*      */       
/*  544 */       if (!fileLocation.isAbsolute()) {
/*  545 */         fileLocation = new File(parent, fileLocation.toString());
/*      */       }
/*      */     } 
/*      */     
/*  549 */     if (reference) {
/*  550 */       String result = searchFor(fileLocation.getName(), (new File(fileLocation.getParent())).getAbsolutePath());
/*  551 */       if (result != null) {
/*  552 */         url = createURL("reference", null, "file:" + result);
/*      */       } else {
/*  554 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/*  559 */       URLConnection result = LocationHelper.getConnection(url);
/*  560 */       result.connect();
/*  561 */       return url;
/*  562 */     } catch (IOException iOException) {
/*      */ 
/*      */       
/*  565 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Bundle[] loadBasicBundles() throws InterruptedException {
/*  575 */     long startTime = System.currentTimeMillis();
/*  576 */     String osgiBundles = getProperty("osgi.bundles");
/*  577 */     String osgiExtensions = getProperty("osgi.framework.extensions");
/*  578 */     if (osgiExtensions != null && osgiExtensions.length() > 0) {
/*  579 */       osgiBundles = String.valueOf(osgiExtensions) + ',' + osgiBundles;
/*  580 */       setProperty("osgi.bundles", osgiBundles);
/*      */     } 
/*  582 */     String[] installEntries = getArrayFromList(osgiBundles, ",");
/*      */     
/*  584 */     InitialBundle[] initialBundles = getInitialBundles(installEntries);
/*      */     
/*  586 */     Bundle[] curInitBundles = getCurrentBundles(true);
/*      */ 
/*      */     
/*  589 */     List<Bundle> toRefresh = new ArrayList<>(curInitBundles.length);
/*      */ 
/*      */     
/*  592 */     uninstallBundles(curInitBundles, initialBundles, toRefresh);
/*      */ 
/*      */     
/*  595 */     List<Bundle> startBundles = new ArrayList<>(installEntries.length);
/*  596 */     List<Bundle> lazyActivationBundles = new ArrayList<>(installEntries.length);
/*  597 */     installBundles(initialBundles, curInitBundles, startBundles, lazyActivationBundles, toRefresh);
/*      */ 
/*      */     
/*  600 */     if (!toRefresh.isEmpty() && refreshPackages(toRefresh.<Bundle>toArray(new Bundle[toRefresh.size()]))) {
/*  601 */       return null;
/*      */     }
/*      */     
/*  604 */     Bundle[] startInitBundles = startBundles.<Bundle>toArray(new Bundle[startBundles.size()]);
/*  605 */     Bundle[] lazyInitBundles = lazyActivationBundles.<Bundle>toArray(new Bundle[lazyActivationBundles.size()]);
/*  606 */     startBundles(startInitBundles, lazyInitBundles);
/*      */     
/*  608 */     if (debug)
/*  609 */       Debug.println("Time to load bundles: " + (System.currentTimeMillis() - startTime)); 
/*  610 */     return startInitBundles;
/*      */   }
/*      */   private static InitialBundle[] getInitialBundles(String[] installEntries) {
/*      */     Collection<ServiceReference<Location>> installLocRef;
/*  614 */     searchCandidates.clear();
/*  615 */     List<InitialBundle> result = new ArrayList<>(installEntries.length);
/*  616 */     int defaultStartLevel = Integer.parseInt(getProperty("osgi.bundles.defaultStartLevel", "4"));
/*  617 */     String syspath = getSysPath();
/*      */     
/*      */     try {
/*  620 */       syspath = (new File(syspath)).getCanonicalPath();
/*  621 */     } catch (IOException iOException) {}
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  626 */       installLocRef = context.getServiceReferences(Location.class, Location.INSTALL_FILTER);
/*  627 */     } catch (InvalidSyntaxException e) {
/*  628 */       throw new RuntimeException(e);
/*      */     } 
/*  630 */     Location installLocation = (installLocRef == null) ? null : (Location)context.getService(installLocRef.iterator().next());
/*  631 */     if (installLocation == null)
/*  632 */       throw new IllegalStateException(Msg.EclipseStarter_InstallLocation);  byte b; int i;
/*      */     String[] arrayOfString;
/*  634 */     for (i = (arrayOfString = installEntries).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*  635 */       int level = defaultStartLevel;
/*  636 */       boolean start = false;
/*  637 */       int index = name.lastIndexOf('@');
/*  638 */       if (index >= 0) {
/*  639 */         String[] attributes = getArrayFromList(name.substring(index + 1, name.length()), ":"); byte b1; int j; String[] arrayOfString1;
/*  640 */         for (j = (arrayOfString1 = attributes).length, b1 = 0; b1 < j; ) { String attribute = arrayOfString1[b1];
/*  641 */           if (attribute.equals("start")) {
/*  642 */             start = true;
/*      */           } else {
/*      */             try {
/*  645 */               level = Integer.parseInt(attribute);
/*  646 */             } catch (NumberFormatException numberFormatException) {
/*  647 */               index = name.length();
/*      */             } 
/*      */           } 
/*      */           b1++; }
/*      */         
/*  652 */         name = name.substring(0, index);
/*      */       } 
/*      */       try {
/*  655 */         URL location = searchForBundle(name, syspath);
/*  656 */         if (location == null)
/*  657 */         { FrameworkLogEntry entry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_BUNDLE_NOT_FOUND, name), 0, null, null);
/*  658 */           log.log(entry); }
/*      */         
/*      */         else
/*      */         
/*  662 */         { location = makeRelative(installLocation.getURL(), location);
/*  663 */           String locationString = "initial@" + location.toExternalForm();
/*  664 */           result.add(new InitialBundle(locationString, location, level, start)); } 
/*  665 */       } catch (IOException e) {
/*  666 */         log.log(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, e.getMessage(), 0, e, null));
/*      */       }  b++; }
/*      */     
/*  669 */     return result.<InitialBundle>toArray(new InitialBundle[result.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean refreshPackages(Bundle[] bundles) throws InterruptedException {
/*  674 */     FrameworkWiring frameworkWiring = (FrameworkWiring)context.getBundle().adapt(FrameworkWiring.class);
/*  675 */     if (frameworkWiring == null)
/*  676 */       return false; 
/*  677 */     Semaphore semaphore = new Semaphore(0);
/*  678 */     StartupEventListener listener = new StartupEventListener(semaphore, 4);
/*  679 */     context.addBundleListener((BundleListener)listener);
/*  680 */     frameworkWiring.refreshBundles(Arrays.asList(bundles), new FrameworkListener[] { listener });
/*  681 */     updateSplash(semaphore, listener);
/*  682 */     return isForcedRestart();
/*      */   }
/*      */ 
/*      */   
/*      */   private static void waitForShutdown() {
/*      */     try {
/*  688 */       framework.waitForStop(0L);
/*  689 */     } catch (InterruptedException e) {
/*  690 */       Thread.interrupted();
/*  691 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void processCommandLine(String[] args) throws Exception {
/*  696 */     allArgs = args;
/*  697 */     if (args.length == 0) {
/*  698 */       frameworkArgs = args;
/*      */       return;
/*      */     } 
/*  701 */     int[] configArgs = new int[args.length];
/*  702 */     configArgs[0] = -1;
/*  703 */     int configArgIndex = 0;
/*  704 */     for (int i = 0; i < args.length; i++) {
/*  705 */       boolean found = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  712 */       if (args[i].equalsIgnoreCase("-debug") && (i + 1 == args.length || (i + 1 < args.length && args[i + 1].startsWith("-")))) {
/*  713 */         setProperty("osgi.debug", "");
/*  714 */         debug = true;
/*  715 */         found = true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  722 */       if (args[i].equalsIgnoreCase("-dev") && (i + 1 == args.length || (i + 1 < args.length && args[i + 1].startsWith("-")))) {
/*  723 */         setProperty("osgi.dev", "");
/*  724 */         found = true;
/*      */       } 
/*      */ 
/*      */       
/*  728 */       if (args[i].equalsIgnoreCase("-initialize")) {
/*  729 */         initialize = true;
/*  730 */         found = true;
/*      */       } 
/*      */ 
/*      */       
/*  734 */       if (args[i].equalsIgnoreCase("-clean")) {
/*  735 */         setProperty("osgi.clean", "true");
/*  736 */         found = true;
/*      */       } 
/*      */ 
/*      */       
/*  740 */       if (args[i].equalsIgnoreCase("-consoleLog")) {
/*  741 */         setProperty("eclipse.consoleLog", "true");
/*  742 */         found = true;
/*      */       } 
/*      */ 
/*      */       
/*  746 */       if (args[i].equalsIgnoreCase("-console") && (i + 1 == args.length || (i + 1 < args.length && args[i + 1].startsWith("-")))) {
/*  747 */         setProperty("osgi.console", "");
/*  748 */         found = true;
/*      */       } 
/*      */       
/*  751 */       if (args[i].equalsIgnoreCase("-noExit")) {
/*  752 */         setProperty("osgi.noShutdown", "true");
/*  753 */         found = true;
/*      */       } 
/*      */       
/*  756 */       if (found) {
/*  757 */         configArgs[configArgIndex++] = i;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  762 */       else if (i != args.length - 1 && !args[i + 1].startsWith("-")) {
/*      */ 
/*      */         
/*  765 */         String arg = args[++i];
/*      */ 
/*      */         
/*  768 */         if (args[i - 1].equalsIgnoreCase("-console")) {
/*  769 */           setProperty("osgi.console", arg);
/*  770 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  774 */         if (args[i - 1].equalsIgnoreCase("-configuration")) {
/*  775 */           setProperty("osgi.configuration.area", arg);
/*  776 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  780 */         if (args[i - 1].equalsIgnoreCase("-data")) {
/*  781 */           setProperty("osgi.instance.area", arg);
/*  782 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  786 */         if (args[i - 1].equalsIgnoreCase("-user")) {
/*  787 */           setProperty("osgi.user.area", arg);
/*  788 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  792 */         if (args[i - 1].equalsIgnoreCase("-launcher")) {
/*  793 */           setProperty("eclipse.launcher", arg);
/*  794 */           found = true;
/*      */         } 
/*      */         
/*  797 */         if (args[i - 1].equalsIgnoreCase("-dev")) {
/*  798 */           setProperty("osgi.dev", arg);
/*  799 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  803 */         if (args[i - 1].equalsIgnoreCase("-debug")) {
/*  804 */           setProperty("osgi.debug", arg);
/*  805 */           debug = true;
/*  806 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  810 */         if (args[i - 1].equalsIgnoreCase("-ws")) {
/*  811 */           setProperty("osgi.ws", arg);
/*  812 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  816 */         if (args[i - 1].equalsIgnoreCase("-os")) {
/*  817 */           setProperty("osgi.os", arg);
/*  818 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  822 */         if (args[i - 1].equalsIgnoreCase("-arch")) {
/*  823 */           setProperty("osgi.arch", arg);
/*  824 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  828 */         if (args[i - 1].equalsIgnoreCase("-nl")) {
/*  829 */           setProperty("osgi.nl", arg);
/*  830 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  834 */         if (args[i - 1].equalsIgnoreCase("-nlExtensions")) {
/*  835 */           setProperty("osgi.nl.extensions", arg);
/*  836 */           found = true;
/*      */         } 
/*      */ 
/*      */         
/*  840 */         if (found) {
/*  841 */           configArgs[configArgIndex++] = i - 1;
/*  842 */           configArgs[configArgIndex++] = i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  847 */     if (configArgIndex == 0) {
/*  848 */       frameworkArgs = new String[0];
/*  849 */       appArgs = args;
/*      */       return;
/*      */     } 
/*  852 */     appArgs = new String[args.length - configArgIndex];
/*  853 */     frameworkArgs = new String[configArgIndex];
/*  854 */     configArgIndex = 0;
/*  855 */     int j = 0;
/*  856 */     int k = 0;
/*  857 */     for (int m = 0; m < args.length; m++) {
/*  858 */       if (m == configArgs[configArgIndex]) {
/*  859 */         frameworkArgs[k++] = args[m];
/*  860 */         configArgIndex++;
/*      */       } else {
/*  862 */         appArgs[j++] = args[m];
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] getArrayFromList(String prop, String separator) {
/*  874 */     return ManifestElement.getArrayFromList(prop, separator);
/*      */   }
/*      */   
/*      */   protected static String getSysPath() {
/*  878 */     String result = getProperty("osgi.syspath");
/*  879 */     if (result != null)
/*  880 */       return result; 
/*  881 */     result = getSysPathFromURL(getProperty("osgi.framework"));
/*  882 */     if (result == null)
/*  883 */       result = getSysPathFromCodeSource(); 
/*  884 */     if (result == null)
/*  885 */       throw new IllegalStateException("Can not find the system path."); 
/*  886 */     if (Character.isUpperCase(result.charAt(0))) {
/*  887 */       char[] chars = result.toCharArray();
/*  888 */       chars[0] = Character.toLowerCase(chars[0]);
/*  889 */       result = new String(chars);
/*      */     } 
/*  891 */     setProperty("osgi.syspath", result);
/*  892 */     return result;
/*      */   }
/*      */   
/*      */   private static String getSysPathFromURL(String urlSpec) {
/*  896 */     if (urlSpec == null)
/*  897 */       return null; 
/*  898 */     URL url = LocationHelper.buildURL(urlSpec, false);
/*  899 */     if (url == null)
/*  900 */       return null; 
/*  901 */     File fwkFile = LocationHelper.decodePath(new File(url.getPath()));
/*  902 */     fwkFile = new File(fwkFile.getAbsolutePath());
/*  903 */     fwkFile = new File(fwkFile.getParent());
/*  904 */     return fwkFile.getAbsolutePath();
/*      */   }
/*      */   
/*      */   private static String getSysPathFromCodeSource() {
/*  908 */     ProtectionDomain pd = EclipseStarter.class.getProtectionDomain();
/*  909 */     if (pd == null)
/*  910 */       return null; 
/*  911 */     CodeSource cs = pd.getCodeSource();
/*  912 */     if (cs == null)
/*  913 */       return null; 
/*  914 */     URL url = cs.getLocation();
/*  915 */     if (url == null)
/*  916 */       return null; 
/*  917 */     String result = url.getPath();
/*  918 */     if (File.separatorChar == '\\')
/*      */     {
/*  920 */       result = result.replace('\\', '/');
/*      */     }
/*  922 */     if (result.endsWith(".jar")) {
/*  923 */       result = result.substring(0, result.lastIndexOf('/'));
/*  924 */       if ("folder".equals(getProperty("osgi.framework.shape")))
/*  925 */         result = result.substring(0, result.lastIndexOf('/')); 
/*      */     } else {
/*  927 */       if (result.endsWith("/"))
/*  928 */         result = result.substring(0, result.length() - 1); 
/*  929 */       result = result.substring(0, result.lastIndexOf('/'));
/*  930 */       result = result.substring(0, result.lastIndexOf('/'));
/*      */     } 
/*  932 */     return result;
/*      */   }
/*      */   
/*      */   private static Bundle[] getCurrentBundles(boolean includeInitial) {
/*  936 */     Bundle[] installed = context.getBundles();
/*  937 */     List<Bundle> initial = new ArrayList<>(); byte b; int i; Bundle[] arrayOfBundle1;
/*  938 */     for (i = (arrayOfBundle1 = installed).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/*  939 */       if (bundle.getLocation().startsWith("initial@")) {
/*  940 */         if (includeInitial)
/*  941 */           initial.add(bundle); 
/*  942 */       } else if (!includeInitial && bundle.getBundleId() != 0L) {
/*  943 */         initial.add(bundle);
/*      */       }  b++; }
/*  945 */      return initial.<Bundle>toArray(new Bundle[initial.size()]);
/*      */   } private static Bundle getBundleByLocation(String location, Bundle[] bundles) { byte b;
/*      */     int i;
/*      */     Bundle[] arrayOfBundle;
/*  949 */     for (i = (arrayOfBundle = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle[b];
/*  950 */       if (location.equalsIgnoreCase(bundle.getLocation()))
/*  951 */         return bundle;  b++; }
/*      */     
/*  953 */     return null; }
/*      */   private static void uninstallBundles(Bundle[] curInitBundles, InitialBundle[] newInitBundles, List<Bundle> toRefresh) { byte b;
/*      */     int i;
/*      */     Bundle[] arrayOfBundle;
/*  957 */     for (i = (arrayOfBundle = curInitBundles).length, b = 0; b < i; ) { Bundle curInitBundle = arrayOfBundle[b];
/*  958 */       boolean found = false; byte b1; int j; InitialBundle[] arrayOfInitialBundle;
/*  959 */       for (j = (arrayOfInitialBundle = newInitBundles).length, b1 = 0; b1 < j; ) { InitialBundle newInitBundle = arrayOfInitialBundle[b1];
/*  960 */         if (curInitBundle.getLocation().equalsIgnoreCase(newInitBundle.locationString)) {
/*  961 */           found = true; break;
/*      */         } 
/*      */         b1++; }
/*      */       
/*  965 */       if (!found)
/*      */         try {
/*  967 */           curInitBundle.uninstall();
/*  968 */           toRefresh.add(curInitBundle);
/*  969 */         } catch (BundleException e) {
/*  970 */           FrameworkLogEntry entry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_FAILED_UNINSTALL, curInitBundle.getLocation()), 0, (Throwable)e, null);
/*  971 */           log.log(entry);
/*      */         }  
/*      */       b++; }
/*      */      } private static void installBundles(InitialBundle[] initialBundles, Bundle[] curInitBundles, List<Bundle> startBundles, List<Bundle> lazyActivationBundles, List<Bundle> toRefresh) {
/*      */     byte b;
/*      */     int i;
/*      */     InitialBundle[] arrayOfInitialBundle;
/*  978 */     for (i = (arrayOfInitialBundle = initialBundles).length, b = 0; b < i; ) { InitialBundle initialBundle = arrayOfInitialBundle[b];
/*  979 */       Bundle osgiBundle = getBundleByLocation(initialBundle.locationString, curInitBundles);
/*      */       
/*      */       try {
/*  982 */         if (osgiBundle == null) {
/*  983 */           InputStream in = LocationHelper.getStream(initialBundle.location);
/*      */           try {
/*  985 */             osgiBundle = context.installBundle(initialBundle.locationString, in);
/*  986 */           } catch (BundleException e) {
/*  987 */             if (e.getType() != 9)
/*      */             {
/*      */ 
/*      */               
/*  991 */               throw e;
/*      */             }
/*      */           } 
/*  994 */           if (!initialBundle.start && hasLazyActivationPolicy(osgiBundle)) {
/*  995 */             lazyActivationBundles.add(osgiBundle);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1000 */         if ((osgiBundle.getState() & 0x1) == 0 && initialBundle.level >= 0) {
/* 1001 */           ((BundleStartLevel)osgiBundle.adapt(BundleStartLevel.class)).setStartLevel(initialBundle.level);
/*      */         }
/*      */         
/* 1004 */         if (initialBundle.start) {
/* 1005 */           startBundles.add(osgiBundle);
/*      */         }
/*      */         
/* 1008 */         if ((osgiBundle.getState() & 0x2) != 0)
/* 1009 */           toRefresh.add(osgiBundle); 
/* 1010 */       } catch (BundleException|IOException e) {
/* 1011 */         FrameworkLogEntry entry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_FAILED_INSTALL, initialBundle.location), 0, e, null);
/* 1012 */         log.log(entry);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean hasLazyActivationPolicy(Bundle target) {
/* 1020 */     Dictionary<String, String> headers = target.getHeaders("");
/*      */     
/* 1022 */     String fragmentHost = headers.get("Fragment-Host");
/* 1023 */     if (fragmentHost != null) {
/* 1024 */       return false;
/*      */     }
/* 1026 */     String activationPolicy = headers.get("Bundle-ActivationPolicy");
/*      */     try {
/* 1028 */       if (activationPolicy != null) {
/* 1029 */         ManifestElement[] elements = ManifestElement.parseHeader("Bundle-ActivationPolicy", activationPolicy);
/* 1030 */         if (elements != null && elements.length > 0)
/*      */         {
/* 1032 */           if ("lazy".equals(elements[0].getValue())) {
/* 1033 */             return true;
/*      */           }
/*      */         }
/*      */       } else {
/* 1037 */         String eclipseLazyStart = headers.get("Eclipse-LazyStart");
/* 1038 */         if (eclipseLazyStart == null)
/* 1039 */           eclipseLazyStart = headers.get("Eclipse-AutoStart"); 
/* 1040 */         ManifestElement[] elements = ManifestElement.parseHeader("Eclipse-AutoStart", eclipseLazyStart);
/* 1041 */         if (elements != null && elements.length > 0) {
/*      */           
/* 1043 */           if ("true".equals(elements[0].getValue())) {
/* 1044 */             return true;
/*      */           }
/* 1046 */           if (elements[0].getDirective("exceptions") != null)
/* 1047 */             return true; 
/*      */         } 
/*      */       } 
/* 1050 */     } catch (BundleException bundleException) {}
/*      */ 
/*      */     
/* 1053 */     return false; } private static void startBundles(Bundle[] startBundles, Bundle[] lazyBundles) {
/*      */     byte b;
/*      */     int i;
/*      */     Bundle[] arrayOfBundle;
/* 1057 */     for (i = (arrayOfBundle = startBundles).length, b = 0; b < i; ) { Bundle startBundle = arrayOfBundle[b];
/* 1058 */       startBundle(startBundle, 0); b++; }
/*      */     
/* 1060 */     for (i = (arrayOfBundle = lazyBundles).length, b = 0; b < i; ) { Bundle lazyBundle = arrayOfBundle[b];
/* 1061 */       startBundle(lazyBundle, 2);
/*      */       b++; }
/*      */   
/*      */   }
/*      */   private static void startBundle(Bundle bundle, int options) {
/*      */     try {
/* 1067 */       bundle.start(options);
/* 1068 */     } catch (BundleException e) {
/* 1069 */       if ((bundle.getState() & 0x4) != 0) {
/*      */         
/* 1071 */         FrameworkLogEntry entry = new FrameworkLogEntry("org.eclipse.osgi", 4, 0, NLS.bind(Msg.ECLIPSE_STARTUP_FAILED_START, bundle.getLocation()), 0, (Throwable)e, null);
/* 1072 */         log.log(entry);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static URL makeRelative(URL base, URL location) throws MalformedURLException {
/* 1083 */     if (base == null)
/* 1084 */       return location; 
/* 1085 */     if (!"file".equals(base.getProtocol()))
/* 1086 */       return location; 
/* 1087 */     if (!location.getProtocol().equals("reference"))
/* 1088 */       return location; 
/* 1089 */     URL nonReferenceLocation = createURL(location.getPath());
/*      */     
/* 1091 */     if (!base.getProtocol().equals(nonReferenceLocation.getProtocol()))
/* 1092 */       return location; 
/* 1093 */     File locationPath = new File(nonReferenceLocation.getPath());
/*      */     
/* 1095 */     if (!locationPath.isAbsolute())
/* 1096 */       return location; 
/* 1097 */     File relativePath = makeRelative(new File(base.getPath()), locationPath);
/* 1098 */     String urlPath = relativePath.getPath();
/* 1099 */     if (File.separatorChar != '/')
/* 1100 */       urlPath = urlPath.replace(File.separatorChar, '/'); 
/* 1101 */     if (nonReferenceLocation.getPath().endsWith("/"))
/*      */     {
/* 1103 */       urlPath = String.valueOf(urlPath) + '/';
/*      */     }
/* 1105 */     URL relativeURL = createURL(base.getProtocol(), base.getHost(), base.getPort(), urlPath);
/*      */     
/* 1107 */     relativeURL = createURL("reference:" + relativeURL.toExternalForm());
/* 1108 */     return relativeURL;
/*      */   }
/*      */   
/*      */   private static URL createURL(String spec) throws MalformedURLException {
/* 1112 */     return createURL(null, spec);
/*      */   }
/*      */   
/*      */   private static URL createURL(URL urlContext, String spec) throws MalformedURLException {
/* 1116 */     if (context != null && spec.startsWith("reference:")) {
/* 1117 */       return new URL(urlContext, spec, (URLStreamHandler)new Handler(context.getProperty("osgi.install.area")));
/*      */     }
/* 1119 */     return new URL(urlContext, spec);
/*      */   }
/*      */   
/*      */   private static URL createURL(String protocol, String host, String file) throws MalformedURLException {
/* 1123 */     return createURL(protocol, host, -1, file);
/*      */   }
/*      */   
/*      */   private static URL createURL(String protocol, String host, int port, String file) throws MalformedURLException {
/* 1127 */     if (context != null && "reference".equalsIgnoreCase(protocol)) {
/* 1128 */       return new URL(protocol, host, port, file, (URLStreamHandler)new Handler(context.getProperty("osgi.install.area")));
/*      */     }
/* 1130 */     return new URL(protocol, host, port, file);
/*      */   }
/*      */   
/*      */   private static File makeRelative(File base, File location) {
/* 1134 */     if (!location.isAbsolute())
/* 1135 */       return location; 
/* 1136 */     File relative = new File((new FilePath(base)).makeRelative(new FilePath(location)));
/* 1137 */     return relative;
/*      */   }
/*      */   
/*      */   private static void setStartLevel(int value) throws InterruptedException {
/* 1141 */     FrameworkStartLevel fwkStartLevel = (FrameworkStartLevel)context.getBundle().adapt(FrameworkStartLevel.class);
/* 1142 */     Semaphore semaphore = new Semaphore(0);
/* 1143 */     StartupEventListener listener = new StartupEventListener(semaphore, 8);
/* 1144 */     context.addBundleListener((BundleListener)listener);
/* 1145 */     fwkStartLevel.setStartLevel(value, new FrameworkListener[] { listener });
/* 1146 */     updateSplash(semaphore, listener);
/*      */   }
/*      */   
/*      */   static class StartupEventListener implements SynchronousBundleListener, FrameworkListener {
/*      */     private final Semaphore semaphore;
/*      */     private final int frameworkEventType;
/*      */     
/*      */     public StartupEventListener(Semaphore semaphore, int frameworkEventType) {
/* 1154 */       this.semaphore = semaphore;
/* 1155 */       this.frameworkEventType = frameworkEventType;
/*      */     }
/*      */ 
/*      */     
/*      */     public void bundleChanged(BundleEvent event) {
/* 1160 */       if (event.getBundle().getBundleId() == 0L && event.getType() == 256) {
/* 1161 */         this.semaphore.release();
/*      */       }
/*      */     }
/*      */     
/*      */     public void frameworkEvent(FrameworkEvent event) {
/* 1166 */       if (event.getType() == this.frameworkEventType) {
/* 1167 */         this.semaphore.release();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static void updateSplash(Semaphore semaphore, StartupEventListener listener) throws InterruptedException {
/* 1173 */     ServiceTracker<StartupMonitor, StartupMonitor> monitorTracker = new ServiceTracker(context, StartupMonitor.class.getName(), null);
/*      */     try {
/* 1175 */       monitorTracker.open();
/* 1176 */     } catch (IllegalStateException illegalStateException) {
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/*      */       do {
/* 1182 */         StartupMonitor monitor = (StartupMonitor)monitorTracker.getService();
/* 1183 */         if (monitor == null)
/*      */           continue;  try {
/* 1185 */           monitor.update();
/* 1186 */         } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1191 */       while (!semaphore.tryAcquire(50L, TimeUnit.MILLISECONDS));
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1196 */       if (listener != null) {
/*      */         try {
/* 1198 */           context.removeBundleListener((BundleListener)listener);
/* 1199 */           monitorTracker.close();
/* 1200 */         } catch (IllegalStateException illegalStateException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String searchFor(String target, String start) {
/* 1216 */     String[] candidates = searchCandidates.get(start);
/* 1217 */     if (candidates == null) {
/* 1218 */       File startFile = new File(start);
/* 1219 */       startFile = LocationHelper.decodePath(startFile);
/* 1220 */       candidates = startFile.list();
/* 1221 */       if (candidates != null)
/* 1222 */         searchCandidates.put(start, candidates); 
/*      */     } 
/* 1224 */     if (candidates == null)
/* 1225 */       return null; 
/* 1226 */     String result = null;
/* 1227 */     Object[] maxVersion = null;
/* 1228 */     boolean resultIsFile = false; byte b; int i; String[] arrayOfString1;
/* 1229 */     for (i = (arrayOfString1 = candidates).length, b = 0; b < i; ) { String candidateName = arrayOfString1[b];
/* 1230 */       if (!candidateName.startsWith(target))
/*      */         continue; 
/* 1232 */       boolean simpleJar = false;
/* 1233 */       char versionSep = (candidateName.length() > target.length()) ? candidateName.charAt(target.length()) : Character.MIN_VALUE;
/* 1234 */       if (candidateName.length() > target.length() && versionSep != '_' && versionSep != '-')
/*      */       {
/* 1236 */         if (candidateName.length() == 4 + target.length() && candidateName.endsWith(".jar")) {
/* 1237 */           simpleJar = true;
/*      */         } else {
/*      */           continue;
/*      */         } 
/*      */       }
/*      */       
/* 1243 */       String version = (candidateName.length() > target.length() + 1 && (versionSep == '_' || versionSep == '-')) ? candidateName.substring(target.length() + 1) : "";
/* 1244 */       Object[] currentVersion = getVersionElements(version);
/* 1245 */       if (currentVersion != null && compareVersion(maxVersion, currentVersion) < 0) {
/* 1246 */         File candidate = new File(start, candidateName);
/* 1247 */         boolean candidateIsFile = candidate.isFile();
/*      */         
/* 1249 */         if (!simpleJar || candidateIsFile) {
/* 1250 */           result = candidate.getAbsolutePath();
/* 1251 */           resultIsFile = candidateIsFile;
/* 1252 */           maxVersion = currentVersion;
/*      */         } 
/*      */       }  continue; b++; }
/*      */     
/* 1256 */     if (result == null)
/* 1257 */       return null; 
/* 1258 */     return String.valueOf(result.replace(File.separatorChar, '/')) + (resultIsFile ? "" : "/");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object[] getVersionElements(String version) {
/* 1271 */     Object[] result = { Integer.valueOf(-1), Integer.valueOf(-1), Integer.valueOf(-1), "" };
/* 1272 */     StringTokenizer t = new StringTokenizer(version, ".");
/*      */     
/* 1274 */     for (int i = 0; t.hasMoreTokens() && i < 4; i++) {
/* 1275 */       String token = t.nextToken();
/* 1276 */       if (i < 3) {
/*      */         
/*      */         try {
/* 1279 */           result[i] = Integer.valueOf(token);
/* 1280 */         } catch (Exception exception) {
/* 1281 */           if (i == 0) {
/* 1282 */             return null;
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/*      */       } else {
/* 1288 */         result[i] = token;
/*      */       } 
/*      */     } 
/* 1291 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int compareVersion(Object[] left, Object[] right) {
/* 1302 */     if (left == null)
/* 1303 */       return -1; 
/* 1304 */     int result = ((Integer)left[0]).compareTo((Integer)right[0]);
/* 1305 */     if (result != 0) {
/* 1306 */       return result;
/*      */     }
/* 1308 */     result = ((Integer)left[1]).compareTo((Integer)right[1]);
/* 1309 */     if (result != 0) {
/* 1310 */       return result;
/*      */     }
/* 1312 */     result = ((Integer)left[2]).compareTo((Integer)right[2]);
/* 1313 */     if (result != 0) {
/* 1314 */       return result;
/*      */     }
/* 1316 */     return ((String)left[3]).compareTo((String)right[3]);
/*      */   }
/*      */   
/*      */   private static class InitialBundle {
/*      */     public final String locationString;
/*      */     public final URL location;
/*      */     public final int level;
/*      */     public final boolean start;
/*      */     
/*      */     InitialBundle(String locationString, URL location, int level, boolean start) {
/* 1326 */       this.locationString = locationString;
/* 1327 */       this.location = location;
/* 1328 */       this.level = level;
/* 1329 */       this.start = start;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setInitialProperties(Map<String, String> initialProperties) {
/* 1346 */     if (initialProperties == null || initialProperties.isEmpty())
/*      */       return; 
/* 1348 */     for (Map.Entry<String, String> entry : initialProperties.entrySet()) {
/* 1349 */       if (entry.getValue() != null) {
/* 1350 */         setProperty(entry.getKey(), entry.getValue()); continue;
/*      */       } 
/* 1352 */       clearProperty(entry.getKey());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BundleContext getSystemBundleContext() {
/* 1365 */     if (context == null || !running)
/* 1366 */       return null; 
/* 1367 */     return context.getBundle().getBundleContext();
/*      */   }
/*      */   
/*      */   private static boolean isForcedRestart() {
/* 1371 */     return Boolean.valueOf(getProperty("osgi.forcedRestart")).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void internalAddFrameworkShutdownHandler(Runnable handler) {
/* 1391 */     if (running) {
/* 1392 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ALREADY_RUNNING);
/*      */     }
/* 1394 */     if (shutdownHandlers == null) {
/* 1395 */       shutdownHandlers = new ArrayList<>();
/*      */     }
/* 1397 */     shutdownHandlers.add(handler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void internalRemoveFrameworkShutdownHandler(Runnable handler) {
/* 1409 */     if (running) {
/* 1410 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ALREADY_RUNNING);
/*      */     }
/* 1412 */     if (shutdownHandlers != null)
/* 1413 */       shutdownHandlers.remove(handler); 
/*      */   }
/*      */   
/*      */   private static void registerFrameworkShutdownHandlers() {
/* 1417 */     if (shutdownHandlers == null) {
/*      */       return;
/*      */     }
/* 1420 */     Bundle systemBundle = context.getBundle();
/* 1421 */     for (Iterator<Runnable> iterator = shutdownHandlers.iterator(); iterator.hasNext(); ) { Runnable handler = iterator.next();
/* 1422 */       BundleListener listener = event -> {
/*      */           if (event.getBundle() == paramBundle && event.getType() == 4) {
/*      */             paramRunnable.run();
/*      */           }
/*      */         };
/* 1427 */       context.addBundleListener(listener); }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\core\runtime\adaptor\EclipseStarter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */