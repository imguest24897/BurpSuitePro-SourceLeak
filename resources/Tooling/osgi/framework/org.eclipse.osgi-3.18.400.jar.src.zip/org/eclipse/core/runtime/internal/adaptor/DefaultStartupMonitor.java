/*    */ package org.eclipse.core.runtime.internal.adaptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.eclipse.core.runtime.adaptor.EclipseStarter;
/*    */ import org.eclipse.osgi.internal.debug.Debug;
/*    */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*    */ import org.eclipse.osgi.service.runnable.StartupMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultStartupMonitor
/*    */   implements StartupMonitor
/*    */ {
/*    */   private final Method updateMethod;
/*    */   private final Runnable splashHandler;
/*    */   private final EquinoxConfiguration equinoxConfig;
/*    */   
/*    */   public DefaultStartupMonitor(Runnable splashHandler, EquinoxConfiguration equinoxConfig) throws IllegalStateException {
/* 36 */     this.splashHandler = splashHandler;
/* 37 */     this.equinoxConfig = equinoxConfig;
/*    */     
/*    */     try {
/* 40 */       this.updateMethod = splashHandler.getClass().getMethod("updateSplash", null);
/* 41 */     } catch (SecurityException|NoSuchMethodException e) {
/*    */       
/* 43 */       throw new IllegalStateException(e.getMessage(), e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void update() {
/* 53 */     if (this.updateMethod != null) {
/*    */       try {
/* 55 */         this.updateMethod.invoke(this.splashHandler, null);
/* 56 */       } catch (Throwable throwable) {}
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void applicationRunning() {
/* 66 */     if (EclipseStarter.debug) {
/* 67 */       String timeString = this.equinoxConfig.getConfiguration("eclipse.startTime");
/* 68 */       long time = (timeString == null) ? 0L : Long.parseLong(timeString);
/* 69 */       Debug.println("Application started in : " + (System.currentTimeMillis() - time) + "ms");
/*    */     } 
/* 71 */     this.splashHandler.run();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\core\runtime\internal\adaptor\DefaultStartupMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */