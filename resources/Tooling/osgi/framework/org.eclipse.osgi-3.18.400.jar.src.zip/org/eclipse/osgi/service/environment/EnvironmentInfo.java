package org.eclipse.osgi.service.environment;

public interface EnvironmentInfo {
  String[] getCommandLineArgs();
  
  String[] getFrameworkArgs();
  
  String[] getNonFrameworkArgs();
  
  String getOSArch();
  
  String getNL();
  
  String getOS();
  
  String getWS();
  
  boolean inDebugMode();
  
  boolean inDevelopmentMode();
  
  String getProperty(String paramString);
  
  String setProperty(String paramString1, String paramString2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\environment\EnvironmentInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */