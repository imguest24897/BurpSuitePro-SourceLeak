/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeCodeFinder
/*     */ {
/*     */   public static final String REQUIREMENT_NATIVE_PATHS_ATTRIBUTE = "native.paths";
/*  39 */   private static final String[] EMPTY_STRINGS = new String[0];
/*     */   
/*     */   public static final String EXTERNAL_LIB_PREFIX = "external:";
/*     */   private final BundleInfo.Generation generation;
/*     */   private final Debug debug;
/*  44 */   private final Collection<String> loadedNativeCode = new ArrayList<>(1);
/*     */   
/*     */   public NativeCodeFinder(BundleInfo.Generation generation) {
/*  47 */     this.generation = generation;
/*  48 */     this.debug = generation.getBundleInfo().getStorage().getConfiguration().getDebug();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] mapLibraryNames(String mappedLibName) {
/*  57 */     int extIndex = mappedLibName.lastIndexOf('.');
/*  58 */     List<String> LIB_EXTENSIONS = (this.generation.getBundleInfo().getStorage().getConfiguration()).LIB_EXTENSIONS;
/*  59 */     if (LIB_EXTENSIONS.isEmpty() || extIndex < 0)
/*  60 */       return EMPTY_STRINGS; 
/*  61 */     String libNameBase = mappedLibName.substring(0, extIndex);
/*  62 */     String[] results = new String[LIB_EXTENSIONS.size()];
/*  63 */     for (int i = 0; i < results.length; i++)
/*  64 */       results[i] = String.valueOf(libNameBase) + (String)LIB_EXTENSIONS.get(i); 
/*  65 */     return results;
/*     */   }
/*     */   
/*     */   String findLibrary(String libname) {
/*  69 */     String path = findLibrary0(libname);
/*  70 */     if (path != null) {
/*  71 */       synchronized (this.loadedNativeCode) {
/*  72 */         if (this.loadedNativeCode.contains(path) || (this.generation.getBundleInfo().getStorage().getConfiguration()).COPY_NATIVES) {
/*     */           
/*  74 */           String temp = this.generation.getBundleInfo().getStorage().copyToTempLibrary(this.generation, path);
/*  75 */           if (temp != null)
/*  76 */             path = temp; 
/*     */         } else {
/*  78 */           this.loadedNativeCode.add(path);
/*     */         } 
/*     */       } 
/*     */     }
/*  82 */     return path;
/*     */   }
/*     */   
/*     */   private String findLibrary0(String libname) {
/*  86 */     String path = null;
/*  87 */     List<ClassLoaderHook> hooks = this.generation.getBundleInfo().getStorage().getConfiguration().getHookRegistry().getClassLoaderHooks();
/*  88 */     for (ClassLoaderHook hook : hooks) {
/*  89 */       path = hook.findLocalLibrary(this.generation, libname);
/*  90 */       if (path != null) {
/*  91 */         return path;
/*     */       }
/*     */     } 
/*  94 */     String mappedName = System.mapLibraryName(libname);
/*  95 */     String[] altMappedNames = mapLibraryNames(mappedName);
/*     */ 
/*     */     
/*  98 */     path = findBundleNativeCode(libname, mappedName, altMappedNames);
/*     */     
/* 100 */     return (path != null) ? path : findEclipseNativeCode(libname, mappedName, altMappedNames);
/*     */   }
/*     */   
/*     */   private String findEclipseNativeCode(String libname, String mappedName, String[] altMappedNames) {
/* 104 */     if (libname.length() == 0)
/* 105 */       return null; 
/* 106 */     if (libname.charAt(0) == '/' || libname.charAt(0) == '\\')
/* 107 */       libname = libname.substring(1); 
/* 108 */     String result = searchEclipseVariants(mappedName);
/* 109 */     if (result != null)
/* 110 */       return result; 
/* 111 */     for (int i = 0; i < altMappedNames.length && result == null; i++)
/* 112 */       result = searchEclipseVariants(altMappedNames[i]); 
/* 113 */     return result;
/*     */   }
/*     */   
/*     */   private String searchEclipseVariants(String path) {
/* 117 */     List<String> ECLIPSE_LIB_VARIANTS = (this.generation.getBundleInfo().getStorage().getConfiguration()).ECLIPSE_LIB_VARIANTS;
/* 118 */     for (String variant : ECLIPSE_LIB_VARIANTS) {
/* 119 */       BundleFile baseBundleFile = this.generation.getBundleFile();
/* 120 */       BundleEntry libEntry = baseBundleFile.getEntry(String.valueOf(variant) + path);
/* 121 */       if (libEntry != null) {
/* 122 */         File libFile = baseBundleFile.getFile(String.valueOf(variant) + path, true);
/* 123 */         if (libFile == null) {
/* 124 */           return null;
/*     */         }
/* 126 */         if ("hpux".equals(this.generation.getBundleInfo().getStorage().getConfiguration().getOS())) {
/*     */           
/*     */           try {
/* 129 */             Runtime.getRuntime().exec(new String[] { "chmod", "755", libFile.getAbsolutePath() }).waitFor();
/* 130 */           } catch (Exception e) {
/* 131 */             e.printStackTrace();
/*     */           } 
/*     */         }
/* 134 */         return libFile.getAbsolutePath();
/*     */       } 
/*     */     } 
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   private String findBundleNativeCode(String libname, String mappedName, String[] altMappedNames) {
/* 141 */     String path = null;
/* 142 */     if (this.debug.DEBUG_LOADER)
/* 143 */       Debug.println("  mapped library name: " + mappedName); 
/* 144 */     List<String> nativePaths = getNativePaths();
/* 145 */     if (nativePaths.isEmpty()) {
/* 146 */       return null;
/*     */     }
/* 148 */     path = findNativePath(nativePaths, mappedName);
/* 149 */     if (path == null)
/* 150 */       for (int i = 0; i < altMappedNames.length && path == null; i++) {
/* 151 */         path = findNativePath(nativePaths, altMappedNames[i]);
/*     */       } 
/* 153 */     if (path == null) {
/* 154 */       if (this.debug.DEBUG_LOADER)
/* 155 */         Debug.println("  library does not exist: " + mappedName); 
/* 156 */       path = findNativePath(nativePaths, libname);
/*     */     } 
/* 158 */     if (this.debug.DEBUG_LOADER)
/* 159 */       Debug.println("  returning library: " + path); 
/* 160 */     return path;
/*     */   }
/*     */   
/*     */   private List<String> getNativePaths() {
/* 164 */     ModuleRevision revision = this.generation.getRevision();
/* 165 */     ModuleWiring wiring = revision.getWiring();
/* 166 */     if (wiring == null)
/*     */     {
/* 168 */       return Collections.emptyList();
/*     */     }
/* 170 */     if ((revision.getTypes() & 0x1) != 0) {
/* 171 */       List<ModuleWire> hosts = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 172 */       if (hosts == null)
/*     */       {
/* 174 */         return Collections.emptyList();
/*     */       }
/* 176 */       if (!hosts.isEmpty())
/*     */       {
/* 178 */         wiring = ((ModuleWire)hosts.get(0)).getProviderWiring();
/*     */       }
/*     */     } 
/*     */     
/* 182 */     List<ModuleWire> nativeCode = wiring.getRequiredModuleWires("osgi.native");
/* 183 */     if (nativeCode == null || nativeCode.isEmpty()) {
/* 184 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     
/* 188 */     for (ModuleWire moduleWire : nativeCode) {
/* 189 */       if (moduleWire.getRequirement().getRevision().equals(revision)) {
/*     */         
/* 191 */         List<String> result = (List<String>)moduleWire.getRequirement().getAttributes()
/* 192 */           .get("native.paths");
/* 193 */         if (result != null) {
/* 194 */           return result;
/*     */         }
/*     */         try {
/* 197 */           FilterImpl filter = FilterImpl.newInstance((String)moduleWire.getRequirement().getDirectives().get("filter"));
/* 198 */           int index = -1;
/* 199 */           Map<String, Object> capabilityAttrs = moduleWire.getCapability().getAttributes();
/* 200 */           for (FilterImpl child : filter.getChildren()) {
/* 201 */             index++;
/* 202 */             if (child.matches(capabilityAttrs)) {
/*     */               break;
/*     */             }
/*     */           } 
/* 206 */           if (index != -1) {
/*     */             
/* 208 */             List<String> indexResult = (List<String>)moduleWire.getRequirement().getAttributes()
/* 209 */               .get("native.paths." + index);
/* 210 */             if (indexResult != null)
/* 211 */               return indexResult; 
/*     */           } 
/* 213 */         } catch (InvalidSyntaxException e) {
/* 214 */           throw new RuntimeException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/* 218 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private String findNativePath(List<String> nativePaths, String libname) {
/* 222 */     int slash = libname.lastIndexOf('/');
/* 223 */     if (slash >= 0)
/* 224 */       libname = libname.substring(slash + 1); 
/* 225 */     for (String nativePath : nativePaths) {
/* 226 */       slash = nativePath.lastIndexOf('/');
/* 227 */       String path = (slash < 0) ? nativePath : nativePath.substring(slash + 1);
/* 228 */       if (path.equals(libname)) {
/* 229 */         if (nativePath.startsWith("external:")) {
/*     */           
/* 231 */           String externalPath = this.generation.getBundleInfo().getStorage().getConfiguration().substituteVars(nativePath.substring("external:".length()));
/* 232 */           File file = new File(externalPath);
/* 233 */           return file.getAbsolutePath();
/*     */         } 
/*     */         
/* 236 */         File nativeFile = this.generation.getBundleFile().getFile(nativePath, true);
/* 237 */         if (nativeFile != null)
/* 238 */           return nativeFile.getAbsolutePath(); 
/*     */       } 
/*     */     } 
/* 241 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\NativeCodeFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */