/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.framework.util.ArrayMap;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.hookregistry.ActivatorHookFactory;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.internal.url.MultiplexingFactory;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.resource.Capability;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkExtensionInstaller
/*     */ {
/*  54 */   private static final ClassLoader CL = FrameworkExtensionInstaller.class.getClassLoader();
/*  55 */   private static final Method ADD_FWK_URL_METHOD = findAddURLMethod(CL, "addURL");
/*  56 */   private static final Method ADD_FWK_FILE_PATH_METHOD = (ADD_FWK_URL_METHOD == null) ? findAddFilePathMethod(CL, "appendToClassPathForInstrumentation") : null;
/*  57 */   private final ArrayMap<BundleActivator, Bundle> hookActivators = new ArrayMap(5); private final EquinoxConfiguration configuration;
/*     */   
/*     */   private static Method findAddURLMethod(ClassLoader cl, String name) {
/*  60 */     if (cl == null)
/*  61 */       return null; 
/*  62 */     return findMethod(cl.getClass(), name, new Class[] { URL.class }, MultiplexingFactory.setAccessible);
/*     */   }
/*     */   
/*     */   private static Method findAddFilePathMethod(ClassLoader cl, String name) {
/*  66 */     if (cl == null)
/*  67 */       return null; 
/*  68 */     return findMethod(cl.getClass(), name, new Class[] { String.class }, MultiplexingFactory.setAccessible);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Method findMethod(Class<?> clazz, String name, Class[] args, Collection<AccessibleObject> setAccessible) {
/*  73 */     if (clazz == null)
/*  74 */       return null; 
/*     */     try {
/*  76 */       Method result = clazz.getDeclaredMethod(name, args);
/*  77 */       if (setAccessible != null) {
/*  78 */         setAccessible.add(result);
/*     */       } else {
/*  80 */         result.setAccessible(true);
/*     */       } 
/*  82 */       return result;
/*  83 */     } catch (NoSuchMethodException|RuntimeException noSuchMethodException) {
/*     */ 
/*     */ 
/*     */       
/*  87 */       return findMethod(clazz.getSuperclass(), name, args, setAccessible);
/*     */     } 
/*     */   }
/*     */   private static void callAddURLMethod(URL arg) throws InvocationTargetException {
/*     */     try {
/*  92 */       ADD_FWK_URL_METHOD.invoke(CL, new Object[] { arg });
/*  93 */     } catch (Throwable t) {
/*  94 */       throw new InvocationTargetException(t);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void callAddFilePathMethod(File file) throws InvocationTargetException {
/*     */     try {
/* 100 */       ADD_FWK_FILE_PATH_METHOD.invoke(CL, new Object[] { file.getCanonicalPath() });
/* 101 */     } catch (Throwable t) {
/* 102 */       throw new InvocationTargetException(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameworkExtensionInstaller(EquinoxConfiguration configuraiton) {
/* 109 */     this.configuration = configuraiton;
/*     */   }
/*     */   
/*     */   public void addExtensionContent(Collection<ModuleRevision> revisions, Module systemModule) throws BundleException {
/* 113 */     if (System.getSecurityManager() == null) {
/* 114 */       addExtensionContent0(revisions, systemModule);
/*     */     } else {
/*     */       try {
/* 117 */         AccessController.doPrivileged(() -> {
/*     */               addExtensionContent0(paramCollection, paramModule);
/*     */               return null;
/*     */             });
/* 121 */       } catch (PrivilegedActionException e) {
/* 122 */         throw (BundleException)e.getCause();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void addExtensionContent0(Collection<ModuleRevision> revisions, Module systemModule) throws BundleException {
/* 128 */     if (revisions.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 134 */     for (ModuleRevision revision : revisions) {
/* 135 */       if (CL == null || (ADD_FWK_URL_METHOD == null && ADD_FWK_FILE_PATH_METHOD == null))
/*     */       {
/* 137 */         throw new BundleException("Cannot support framework extension bundles without a public addURL(URL) or appendToClassPathForInstrumentation(String) method on the framework class loader: " + revision.getBundle());
/*     */       }
/* 139 */       File[] files = getExtensionFiles(revision); byte b; int i; File[] arrayOfFile1;
/* 140 */       for (i = (arrayOfFile1 = files).length, b = 0; b < i; ) { File file = arrayOfFile1[b];
/* 141 */         if (file != null)
/*     */           
/*     */           try {
/*     */             
/* 145 */             if (ADD_FWK_URL_METHOD != null) {
/* 146 */               callAddURLMethod(StorageUtil.encodeFileURL(file));
/* 147 */             } else if (ADD_FWK_FILE_PATH_METHOD != null) {
/* 148 */               callAddFilePathMethod(file);
/*     */             } 
/* 150 */           } catch (InvocationTargetException|java.net.MalformedURLException e) {
/* 151 */             throw new BundleException("Error adding extension content. " + revision, e);
/*     */           }  
/*     */         b++; }
/*     */     
/*     */     } 
/* 156 */     if (CL != null) {
/*     */       
/*     */       try {
/* 159 */         CL.loadClass("thisIsNotAClass");
/* 160 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     }
/*     */ 
/*     */     
/* 164 */     if (systemModule != null) {
/* 165 */       BundleContext systemContext = systemModule.getBundle().getBundleContext();
/* 166 */       for (ModuleRevision revision : revisions) {
/* 167 */         if (systemContext != null) {
/* 168 */           startExtensionActivator(revision, systemContext);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File[] getExtensionFiles(ModuleRevision revision) {
/* 180 */     BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/* 181 */     if (generation.getContentType() == ContentProvider.Type.CONNECT)
/*     */     {
/* 183 */       return new File[0];
/*     */     }
/* 185 */     List<ModuleCapability> metaDatas = revision.getModuleCapabilities("equinox.module.data");
/*     */     
/* 187 */     List<String> paths = metaDatas.isEmpty() ? null : (List<String>)((ModuleCapability)metaDatas.get(0)).getAttributes().get("classpath");
/* 188 */     if (paths == null) {
/* 189 */       paths = new ArrayList<>(1);
/* 190 */       paths.add(".");
/*     */     } 
/* 192 */     if (this.configuration.inDevelopmentMode()) {
/*     */       
/* 194 */       paths = new ArrayList<>(paths);
/* 195 */       String[] devPaths = this.configuration.getDevClassPath((BundleRevision)revision);
/* 196 */       Collections.addAll(paths, devPaths);
/*     */     } 
/* 198 */     List<File> results = new ArrayList<>(paths.size());
/* 199 */     for (String path : paths) {
/* 200 */       if (".".equals(path)) {
/* 201 */         results.add(((BundleInfo.Generation)revision.getRevisionInfo()).getBundleFile().getBaseFile()); continue;
/*     */       } 
/* 203 */       File result = ((BundleInfo.Generation)revision.getRevisionInfo()).getBundleFile().getFile(path, false);
/* 204 */       if (result != null) {
/* 205 */         results.add(result);
/*     */       }
/*     */     } 
/* 208 */     return results.<File>toArray(new File[results.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExtensionActivators(BundleContext context) {
/* 214 */     HookRegistry hookRegistry = this.configuration.getHookRegistry();
/* 215 */     List<ActivatorHookFactory> activatorHookFactories = hookRegistry.getActivatorHookFactories();
/* 216 */     for (ActivatorHookFactory activatorFactory : activatorHookFactories) {
/* 217 */       BundleActivator activator = activatorFactory.createActivator();
/*     */       try {
/* 219 */         startActivator(activator, context, null);
/* 220 */       } catch (Exception e) {
/* 221 */         this.configuration.getHookRegistry().getContainer().getEventPublisher().publishFrameworkEvent(2, null, e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 226 */     ModuleWiring systemWiring = (ModuleWiring)context.getBundle().adapt(BundleWiring.class);
/* 227 */     if (systemWiring != null) {
/* 228 */       List<ModuleWire> extensionWires = systemWiring.getProvidedModuleWires("osgi.wiring.host");
/* 229 */       for (ModuleWire extensionWire : extensionWires) {
/* 230 */         ModuleRevision extensionRevision = extensionWire.getRequirer();
/* 231 */         startExtensionActivator(extensionRevision, context);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stopExtensionActivators(BundleContext context) {
/*     */     ArrayMap<BundleActivator, Bundle> current;
/* 238 */     synchronized (this.hookActivators) {
/* 239 */       current = new ArrayMap(this.hookActivators.getKeys(), this.hookActivators.getValues());
/* 240 */       this.hookActivators.clear();
/*     */     } 
/*     */     
/* 243 */     for (int i = current.getKeys().size() - 1; i >= 0; i--) {
/* 244 */       BundleActivator activator = (BundleActivator)current.getKey(i);
/*     */       try {
/* 246 */         activator.stop(context);
/* 247 */       } catch (Exception e) {
/* 248 */         Bundle b = (Bundle)current.get(activator);
/* 249 */         BundleException eventException = new BundleException(NLS.bind(Msg.BUNDLE_ACTIVATOR_EXCEPTION, new Object[] { activator.getClass(), "stop", (b == null) ? "" : b.getSymbolicName() }), 5, e);
/* 250 */         this.configuration.getHookRegistry().getContainer().getEventPublisher().publishFrameworkEvent(2, b, (Throwable)eventException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startExtensionActivator(ModuleRevision extensionRevision, BundleContext context) {
/* 256 */     List<Capability> metadata = extensionRevision.getCapabilities("equinox.module.data");
/* 257 */     if (metadata.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 261 */     String activatorName = (String)((Capability)metadata.get(0)).getAttributes().get("activator");
/* 262 */     if (activatorName == null) {
/*     */       return;
/*     */     }
/*     */     
/* 266 */     BundleActivator activator = null;
/*     */     try {
/* 268 */       Class<?> activatorClass = Class.forName(activatorName);
/* 269 */       activator = activatorClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 270 */       startActivator(activator, context, extensionRevision.getBundle());
/* 271 */     } catch (Throwable e) {
/*     */       BundleException eventException;
/* 273 */       if (activator == null) {
/* 274 */         eventException = new BundleException(String.valueOf(Msg.BundleContextImpl_LoadActivatorError) + ' ' + extensionRevision, 
/* 275 */             5, e);
/*     */       } else {
/* 277 */         eventException = new BundleException(NLS.bind(Msg.BUNDLE_ACTIVATOR_EXCEPTION, new Object[] { activator.getClass(), "start", extensionRevision.getSymbolicName() }), 5, e);
/*     */       } 
/* 279 */       this.configuration.getHookRegistry().getContainer().getEventPublisher().publishFrameworkEvent(2, extensionRevision.getBundle(), (Throwable)eventException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void startActivator(BundleActivator activator, BundleContext context, Bundle b) throws Exception {
/* 285 */     activator.start(context);
/* 286 */     synchronized (this.hookActivators) {
/* 287 */       this.hookActivators.put(activator, b);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\FrameworkExtensionInstaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */