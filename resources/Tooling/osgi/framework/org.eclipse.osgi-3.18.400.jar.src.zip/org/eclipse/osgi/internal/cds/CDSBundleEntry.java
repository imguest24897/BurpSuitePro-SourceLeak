/*     */ package org.eclipse.osgi.internal.cds;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CDSBundleEntry
/*     */   extends BundleEntry
/*     */ {
/*     */   final String path;
/*     */   final byte[] classbytes;
/*     */   final CDSBundleFile bundleFile;
/*     */   
/*     */   public CDSBundleEntry(String path, byte[] classbytes, CDSBundleFile bundleFile) {
/*  46 */     this.path = path;
/*  47 */     this.classbytes = classbytes;
/*  48 */     this.bundleFile = bundleFile;
/*     */   }
/*     */   
/*     */   private BundleEntry getWrappedEntry() {
/*  52 */     BundleEntry entry = this.bundleFile.getWrappedEntry(this.path);
/*  53 */     if (entry == null) {
/*  54 */       throw new IllegalStateException("Could not find original entry for the class: " + this.path);
/*     */     }
/*  56 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getFileURL() {
/*  69 */     return getWrappedEntry().getFileURL();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  82 */     return getWrappedEntry().getInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() throws IOException {
/*  94 */     return this.classbytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getLocalURL() {
/* 107 */     return getWrappedEntry().getLocalURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 112 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 117 */     return getWrappedEntry().getSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTime() {
/* 122 */     return getWrappedEntry().getTime();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\cds\CDSBundleEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */