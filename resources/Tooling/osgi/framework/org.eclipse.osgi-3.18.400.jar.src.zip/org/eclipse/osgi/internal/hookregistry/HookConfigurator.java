package org.eclipse.osgi.internal.hookregistry;

public interface HookConfigurator {
  void addHooks(HookRegistry paramHookRegistry);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hookregistry\HookConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */