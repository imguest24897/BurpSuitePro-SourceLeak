/*    */ package org.eclipse.osgi.storage.url.reference;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   private final String installPath;
/*    */   
/*    */   public Handler(String installURL) {
/* 38 */     if (installURL != null && installURL.startsWith("file:")) {
/*    */       
/* 40 */       this.installPath = installURL.substring(5);
/*    */     } else {
/* 42 */       this.installPath = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL url) throws IOException {
/* 51 */     return new ReferenceURLConnection(url, this.installPath);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void parseURL(URL url, String str, int start, int end) {
/* 56 */     if (end < start) {
/*    */       return;
/*    */     }
/* 59 */     String reference = (start < end) ? str.substring(start, end) : url.getPath();
/*    */     
/* 61 */     setURL(url, url.getProtocol(), null, -1, null, null, reference, null, null);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\reference\Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */