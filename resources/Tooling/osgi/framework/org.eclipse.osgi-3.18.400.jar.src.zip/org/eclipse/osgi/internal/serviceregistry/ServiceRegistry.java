/*      */ package org.eclipse.osgi.internal.serviceregistry;
/*      */ 
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleRevision;
/*      */ import org.eclipse.osgi.framework.eventmgr.CopyOnWriteIdentityMap;
/*      */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*      */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*      */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.storage.BundleInfo;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.Filter;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceEvent;
/*      */ import org.osgi.framework.ServiceException;
/*      */ import org.osgi.framework.ServiceListener;
/*      */ import org.osgi.framework.ServicePermission;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.ServiceRegistration;
/*      */ import org.osgi.framework.hooks.bundle.CollisionHook;
/*      */ import org.osgi.framework.hooks.bundle.EventHook;
/*      */ import org.osgi.framework.hooks.bundle.FindHook;
/*      */ import org.osgi.framework.hooks.service.EventHook;
/*      */ import org.osgi.framework.hooks.service.EventListenerHook;
/*      */ import org.osgi.framework.hooks.service.FindHook;
/*      */ import org.osgi.framework.hooks.service.ListenerHook;
/*      */ import org.osgi.framework.hooks.weaving.WeavingHook;
/*      */ import org.osgi.framework.hooks.weaving.WovenClassListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ServiceRegistry
/*      */ {
/*      */   public static final int SERVICEEVENT = 3;
/*   74 */   static final String listenerHookName = ListenerHook.class.getName();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<String, List<ServiceRegistrationImpl<?>>> publishedServicesByClass;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final List<ServiceRegistrationImpl<?>> allPublishedServices;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<BundleContextImpl, List<ServiceRegistrationImpl<?>>> publishedServicesByContext;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long serviceid;
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<BundleContextImpl, CopyOnWriteIdentityMap<ServiceListener, FilteredServiceListener>> serviceEventListeners;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int initialCapacity = 50;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int initialSubCapacity = 10;
/*      */ 
/*      */ 
/*      */   
/*      */   private final EquinoxContainer container;
/*      */ 
/*      */ 
/*      */   
/*      */   private final BundleContextImpl systemBundleContext;
/*      */ 
/*      */ 
/*      */   
/*      */   final Debug debug;
/*      */ 
/*      */ 
/*      */   
/*  122 */   private final ConcurrentMap<Thread, ServiceUse.ServiceUseLock> awaitedUseLocks = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceRegistry(EquinoxContainer container) {
/*  129 */     this.container = container;
/*  130 */     this.debug = container.getConfiguration().getDebug();
/*  131 */     this.serviceid = 1L;
/*  132 */     this.publishedServicesByClass = new HashMap<>(50);
/*  133 */     this.publishedServicesByContext = new HashMap<>(50);
/*  134 */     this.allPublishedServices = new ArrayList<>(50);
/*  135 */     this.serviceEventListeners = new LinkedHashMap<>(50);
/*  136 */     Module systemModule = container.getStorage().getModuleContainer().getModule(0L);
/*  137 */     this.systemBundleContext = (BundleContextImpl)systemModule.getBundle().getBundleContext();
/*  138 */     this.systemBundleContext.provisionServicesInUseMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceRegistrationImpl<?> registerService(BundleContextImpl context, String[] clazzes, Object service, Dictionary<String, ?> properties) {
/*  219 */     if (service == null) {
/*  220 */       if (this.debug.DEBUG_SERVICES) {
/*  221 */         Debug.println("Service object is null");
/*      */       }
/*      */       
/*  224 */       throw new IllegalArgumentException(Msg.SERVICE_ARGUMENT_NULL_EXCEPTION);
/*      */     } 
/*      */     
/*  227 */     int size = clazzes.length;
/*      */     
/*  229 */     if (size == 0) {
/*  230 */       if (this.debug.DEBUG_SERVICES) {
/*  231 */         Debug.println("Classes array is empty");
/*      */       }
/*      */       
/*  234 */       throw new IllegalArgumentException(Msg.SERVICE_EMPTY_CLASS_LIST_EXCEPTION);
/*      */     } 
/*      */     
/*  237 */     boolean isListenerHook = false;
/*      */     
/*  239 */     List<String> copy = new ArrayList<>(size);
/*  240 */     List<Class<?>> hookTypes = null;
/*      */     
/*  242 */     for (int i = 0; i < size; i++) {
/*  243 */       String clazz = clazzes[i].intern();
/*  244 */       if (!copy.contains(clazz)) {
/*  245 */         isListenerHook = !(!isListenerHook && !listenerHookName.equals(clazz));
/*  246 */         hookTypes = getHookClass(clazz, hookTypes);
/*  247 */         copy.add(clazz);
/*      */       } 
/*      */     } 
/*  250 */     size = copy.size();
/*  251 */     clazzes = copy.<String>toArray(new String[size]);
/*      */ 
/*      */     
/*  254 */     checkRegisterServicePermission(clazzes);
/*      */     
/*  256 */     if (!(service instanceof org.osgi.framework.ServiceFactory)) {
/*  257 */       String invalidService = checkServiceClass(clazzes, service);
/*  258 */       if (invalidService != null) {
/*  259 */         if (this.debug.DEBUG_SERVICES) {
/*  260 */           Debug.println("Service object is not an instanceof " + invalidService);
/*      */         }
/*  262 */         throw new IllegalArgumentException(NLS.bind(Msg.SERVICE_NOT_INSTANCEOF_CLASS_EXCEPTION, invalidService));
/*      */       } 
/*      */     } 
/*      */     
/*  266 */     if (hookTypes != null) {  } else {  }  ServiceRegistrationImpl<?> registration = 
/*      */ 
/*      */       
/*  269 */       new ServiceRegistrationImpl(this, context, clazzes, service);
/*  270 */     registration.register(properties);
/*  271 */     registration.initHookInstance();
/*      */     
/*  273 */     if (isListenerHook) {
/*  274 */       notifyNewListenerHook(registration);
/*      */     }
/*  276 */     return registration;
/*      */   }
/*      */   
/*      */   private List<Class<?>> getHookClass(String className, List<Class<?>> hookTypes) {
/*      */     String str;
/*  281 */     switch ((str = className).hashCode()) { case -1908680255: if (!str.equals("org.osgi.framework.hooks.service.FindHook")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  293 */         return addHook(FindHook.class, hookTypes);
/*      */       case -1554834339:
/*      */         if (!str.equals("org.osgi.framework.hooks.bundle.EventHook"))
/*      */           break;  return addHook(EventHook.class, hookTypes);
/*      */       case -1512590912:
/*      */         if (!str.equals("org.osgi.framework.hooks.weaving.WovenClassListener"))
/*  299 */           break;  return addHook(WovenClassListener.class, hookTypes);case -1405646660: if (!str.equals("org.osgi.framework.hooks.service.ListenerHook")) break;  return addHook(ListenerHook.class, hookTypes);case -1146352388: if (!str.equals("org.osgi.framework.hooks.bundle.FindHook")) break;  return addHook(FindHook.class, hookTypes);case -72338009: if (!str.equals("org.osgi.framework.hooks.weaving.WeavingHook")) break;  return addHook(WeavingHook.class, hookTypes);case 582805560: if (!str.equals("org.osgi.framework.hooks.service.EventHook")) break;  return addHook(EventHook.class, hookTypes);case 751550988: if (!str.equals("org.osgi.framework.hooks.service.EventListenerHook"))
/*      */           break;  return addHook(EventListenerHook.class, hookTypes);case 1058612469: if (!str.equals("org.osgi.framework.hooks.bundle.CollisionHook"))
/*  301 */           break;  return addHook(CollisionHook.class, hookTypes); }  return hookTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   private List<Class<?>> addHook(Class<?> hookType, List<Class<?>> hookTypes) {
/*  306 */     if (hookTypes == null) {
/*  307 */       hookTypes = new ArrayList<>(1);
/*      */     }
/*  309 */     hookTypes.add(hookType);
/*  310 */     return hookTypes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReferenceImpl<?>[] getServiceReferences(BundleContextImpl context, String clazz, String filterstring, boolean allservices) throws InvalidSyntaxException {
/*  386 */     if (this.debug.DEBUG_SERVICES) {
/*  387 */       Debug.println(String.valueOf(allservices ? "getAllServiceReferences(" : "getServiceReferences(") + clazz + ", \"" + filterstring + "\")");
/*      */     }
/*  389 */     Filter filter = (filterstring == null) ? null : context.createFilter(filterstring);
/*  390 */     List<ServiceRegistrationImpl<?>> registrations = lookupServiceRegistrations(clazz, filter);
/*  391 */     List<ServiceReferenceImpl<?>> references = new ArrayList<>(registrations.size());
/*  392 */     for (ServiceRegistrationImpl<?> registration : registrations) {
/*      */       ServiceReferenceImpl<?> reference;
/*      */       try {
/*  395 */         reference = registration.getReferenceImpl();
/*  396 */       } catch (IllegalStateException illegalStateException) {
/*      */         continue;
/*      */       } 
/*  399 */       if (allservices || isAssignableTo(context, clazz, reference)) {
/*      */         try {
/*  401 */           checkGetServicePermission(reference);
/*  402 */         } catch (SecurityException securityException) {
/*      */           continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  408 */         references.add(reference);
/*      */       } 
/*      */     } 
/*  411 */     Collection<ServiceReferenceImpl<?>> copyReferences = references;
/*  412 */     if (context.getBundleImpl().getBundleId() == 0L)
/*      */     {
/*      */       
/*  415 */       copyReferences = new ArrayList<>(references);
/*      */     }
/*  417 */     Collection<ServiceReference<?>> shrinkable = new ShrinkableCollection<>((Collection)copyReferences);
/*  418 */     notifyFindHooks(context, clazz, filterstring, allservices, shrinkable);
/*      */     
/*  420 */     int size = references.size();
/*  421 */     if (size == 0) {
/*  422 */       return null;
/*      */     }
/*  424 */     return (ServiceReferenceImpl<?>[])references.<ServiceReferenceImpl>toArray(new ServiceReferenceImpl[size]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReferenceImpl<?> getServiceReference(BundleContextImpl context, String clazz) {
/*  458 */     if (this.debug.DEBUG_SERVICES) {
/*  459 */       Debug.println("getServiceReference(" + clazz + ")");
/*      */     }
/*      */     
/*      */     try {
/*  463 */       ServiceReferenceImpl[] references = (ServiceReferenceImpl[])getServiceReferences(context, clazz, null, false);
/*      */       
/*  465 */       if (references != null)
/*      */       {
/*      */         
/*  468 */         return references[0];
/*      */       }
/*  470 */     } catch (InvalidSyntaxException e) {
/*  471 */       if (this.debug.DEBUG_GENERAL) {
/*  472 */         Debug.println("InvalidSyntaxException w/ null filter" + e.getMessage());
/*  473 */         Debug.printStackTrace((Throwable)e);
/*      */       } 
/*      */     } 
/*      */     
/*  477 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> S getService(BundleContextImpl context, ServiceReferenceImpl<S> reference) {
/*  541 */     checkGetServicePermission(reference);
/*  542 */     return reference.getRegistration().getService(context, ServiceConsumer.singletonConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> ServiceObjectsImpl<S> getServiceObjects(BundleContextImpl context, ServiceReferenceImpl<S> reference) {
/*  577 */     checkGetServicePermission(reference);
/*  578 */     return reference.getRegistration().getServiceObjects(context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ungetService(BundleContextImpl context, ServiceReferenceImpl<?> reference) {
/*  619 */     ServiceRegistrationImpl<?> registration = reference.getRegistration();
/*      */     
/*  621 */     return registration.ungetService(context, ServiceConsumer.singletonConsumer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReferenceImpl<?>[] getRegisteredServices(BundleContextImpl context) {
/*  650 */     List<ServiceRegistrationImpl<?>> registrations = lookupServiceRegistrations(context);
/*  651 */     List<ServiceReferenceImpl<?>> references = new ArrayList<>(registrations.size());
/*  652 */     for (ServiceRegistrationImpl<?> registration : registrations) {
/*      */       ServiceReferenceImpl<?> reference;
/*      */       try {
/*  655 */         reference = registration.getReferenceImpl();
/*  656 */       } catch (IllegalStateException illegalStateException) {
/*      */         continue;
/*      */       } 
/*      */       
/*      */       try {
/*  661 */         checkGetServicePermission(reference);
/*  662 */       } catch (SecurityException securityException) {
/*      */         continue;
/*      */       } 
/*  665 */       references.add(reference);
/*      */     } 
/*      */     
/*  668 */     int size = references.size();
/*  669 */     if (size == 0) {
/*  670 */       return null;
/*      */     }
/*  672 */     return (ServiceReferenceImpl<?>[])references.<ServiceReferenceImpl>toArray(new ServiceReferenceImpl[size]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReferenceImpl<?>[] getServicesInUse(BundleContextImpl context) {
/*      */     List<ServiceRegistrationImpl<?>> registrations;
/*  701 */     Map<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse = context.getServicesInUseMap();
/*  702 */     if (servicesInUse == null) {
/*  703 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  707 */     synchronized (servicesInUse) {
/*  708 */       if (servicesInUse.isEmpty()) {
/*  709 */         return null;
/*      */       }
/*  711 */       registrations = new ArrayList<>(servicesInUse.keySet());
/*      */     } 
/*  713 */     List<ServiceReferenceImpl<?>> references = new ArrayList<>(registrations.size());
/*  714 */     for (ServiceRegistrationImpl<?> registration : registrations) {
/*      */       ServiceReferenceImpl<?> reference;
/*      */       try {
/*  717 */         reference = registration.getReferenceImpl();
/*  718 */       } catch (IllegalStateException illegalStateException) {
/*      */         continue;
/*      */       } 
/*      */       
/*      */       try {
/*  723 */         checkGetServicePermission(reference);
/*  724 */       } catch (SecurityException securityException) {
/*      */         continue;
/*      */       } 
/*  727 */       references.add(reference);
/*      */     } 
/*      */     
/*  730 */     int size = references.size();
/*  731 */     if (size == 0) {
/*  732 */       return null;
/*      */     }
/*  734 */     return (ServiceReferenceImpl<?>[])references.<ServiceReferenceImpl>toArray(new ServiceReferenceImpl[size]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterServices(BundleContextImpl context) {
/*  744 */     for (ServiceRegistrationImpl<?> registration : lookupServiceRegistrations(context)) {
/*      */       try {
/*  746 */         registration.unregister();
/*  747 */       } catch (IllegalStateException illegalStateException) {}
/*      */     } 
/*      */ 
/*      */     
/*  751 */     removeServiceRegistrations(context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseServicesInUse(BundleContextImpl context) {
/*      */     List<ServiceRegistrationImpl<?>> registrations;
/*  761 */     Map<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse = context.getServicesInUseMap();
/*  762 */     if (servicesInUse == null) {
/*      */       return;
/*      */     }
/*      */     
/*  766 */     synchronized (servicesInUse) {
/*  767 */       if (servicesInUse.isEmpty()) {
/*      */         return;
/*      */       }
/*  770 */       registrations = new ArrayList<>(servicesInUse.keySet());
/*      */     } 
/*  772 */     if (this.debug.DEBUG_SERVICES) {
/*  773 */       Debug.println("Releasing services");
/*      */     }
/*  775 */     for (ServiceRegistrationImpl<?> registration : registrations) {
/*  776 */       registration.releaseService(context);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addServiceListener(BundleContextImpl context, ServiceListener listener, String filter) throws InvalidSyntaxException {
/*      */     FilteredServiceListener oldFilteredListener;
/*  789 */     if (this.debug.DEBUG_EVENTS) {
/*  790 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  791 */       Debug.println("addServiceListener[" + context.getBundleImpl() + "](" + listenerName + ", \"" + filter + "\")");
/*      */     } 
/*      */     
/*  794 */     FilteredServiceListener filteredListener = new FilteredServiceListener(context, listener, filter);
/*      */     
/*  796 */     synchronized (this.serviceEventListeners) {
/*  797 */       CopyOnWriteIdentityMap<ServiceListener, FilteredServiceListener> listeners = this.serviceEventListeners.get(context);
/*  798 */       if (listeners == null) {
/*  799 */         listeners = new CopyOnWriteIdentityMap();
/*  800 */         this.serviceEventListeners.put(context, listeners);
/*      */       } 
/*  802 */       oldFilteredListener = (FilteredServiceListener)listeners.put(listener, filteredListener);
/*      */     } 
/*      */     
/*  805 */     if (oldFilteredListener != null) {
/*  806 */       oldFilteredListener.markRemoved();
/*  807 */       Collection<ListenerHook.ListenerInfo> removedListeners = Collections.singletonList(oldFilteredListener);
/*  808 */       notifyListenerHooks(removedListeners, false);
/*      */     } 
/*      */     
/*  811 */     Collection<ListenerHook.ListenerInfo> addedListeners = Collections.singletonList(filteredListener);
/*  812 */     notifyListenerHooks(addedListeners, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeServiceListener(BundleContextImpl context, ServiceListener listener) {
/*      */     FilteredServiceListener oldFilteredListener;
/*  822 */     if (this.debug.DEBUG_EVENTS) {
/*  823 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  824 */       Debug.println("removeServiceListener[" + context.getBundleImpl() + "](" + listenerName + ")");
/*      */     } 
/*      */ 
/*      */     
/*  828 */     synchronized (this.serviceEventListeners) {
/*  829 */       Map<ServiceListener, FilteredServiceListener> listeners = (Map<ServiceListener, FilteredServiceListener>)this.serviceEventListeners.get(context);
/*  830 */       if (listeners == null) {
/*      */         return;
/*      */       }
/*  833 */       oldFilteredListener = listeners.remove(listener);
/*      */     } 
/*      */     
/*  836 */     if (oldFilteredListener == null) {
/*      */       return;
/*      */     }
/*  839 */     oldFilteredListener.markRemoved();
/*  840 */     Collection<ListenerHook.ListenerInfo> removedListeners = Collections.singletonList(oldFilteredListener);
/*  841 */     notifyListenerHooks(removedListeners, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllServiceListeners(BundleContextImpl context) {
/*      */     Map<ServiceListener, FilteredServiceListener> removedListenersMap;
/*  851 */     synchronized (this.serviceEventListeners) {
/*  852 */       removedListenersMap = (Map<ServiceListener, FilteredServiceListener>)this.serviceEventListeners.remove(context);
/*      */     } 
/*  854 */     if (removedListenersMap == null || removedListenersMap.isEmpty()) {
/*      */       return;
/*      */     }
/*  857 */     Collection<FilteredServiceListener> removedListeners = removedListenersMap.values();
/*  858 */     for (FilteredServiceListener oldFilteredListener : removedListeners) {
/*  859 */       oldFilteredListener.markRemoved();
/*      */     }
/*  861 */     notifyListenerHooks(asListenerInfos((Collection)removedListeners), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Collection<ListenerHook.ListenerInfo> asListenerInfos(Collection<? extends ListenerHook.ListenerInfo> c) {
/*  872 */     return (Collection)c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void publishServiceEvent(final ServiceEvent event) {
/*  881 */     if (System.getSecurityManager() == null) {
/*  882 */       publishServiceEventPrivileged(event);
/*      */     } else {
/*  884 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*      */           {
/*      */             public Void run() {
/*  887 */               ServiceRegistry.this.publishServiceEventPrivileged(event);
/*  888 */               return null;
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void publishServiceEventPrivileged(ServiceEvent event) {
/*      */     Map<BundleContextImpl, Set<Map.Entry<ServiceListener, FilteredServiceListener>>> listenerSnapshot;
/*  897 */     Set<Map.Entry<ServiceListener, FilteredServiceListener>> systemServiceListenersOrig = null;
/*  898 */     BundleContextImpl systemContext = null;
/*  899 */     synchronized (this.serviceEventListeners) {
/*  900 */       listenerSnapshot = new LinkedHashMap<>(this.serviceEventListeners.size());
/*  901 */       for (Map.Entry<BundleContextImpl, CopyOnWriteIdentityMap<ServiceListener, FilteredServiceListener>> entry : this.serviceEventListeners.entrySet()) {
/*  902 */         Map<ServiceListener, FilteredServiceListener> listeners = (Map<ServiceListener, FilteredServiceListener>)entry.getValue();
/*  903 */         if (!listeners.isEmpty()) {
/*  904 */           if (((BundleContextImpl)entry.getKey()).getBundleImpl().getBundleId() == 0L) {
/*  905 */             systemContext = entry.getKey();
/*      */             
/*  907 */             systemServiceListenersOrig = listeners.entrySet();
/*      */           } 
/*  909 */           listenerSnapshot.put(entry.getKey(), listeners.entrySet());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  919 */     Collection<BundleContext> contexts = asBundleContexts((Collection)listenerSnapshot.keySet());
/*  920 */     notifyEventHooksPrivileged(event, contexts);
/*  921 */     if (!listenerSnapshot.isEmpty()) {
/*  922 */       Map<BundleContext, Collection<ListenerHook.ListenerInfo>> listeners = (Map)new ShrinkableValueCollectionMap<>(
/*  923 */           (Map)listenerSnapshot);
/*  924 */       notifyEventListenerHooksPrivileged(event, listeners);
/*      */     } 
/*      */     
/*  927 */     if (systemServiceListenersOrig != null)
/*      */     {
/*      */ 
/*      */       
/*  931 */       listenerSnapshot.put(systemContext, systemServiceListenersOrig);
/*      */     }
/*  933 */     if (listenerSnapshot.isEmpty()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  938 */     ListenerQueue<ServiceListener, FilteredServiceListener, ServiceEvent> queue = this.container.newListenerQueue();
/*  939 */     for (Map.Entry<BundleContextImpl, Set<Map.Entry<ServiceListener, FilteredServiceListener>>> entry : listenerSnapshot.entrySet()) {
/*      */       
/*  941 */       EventDispatcher<ServiceListener, FilteredServiceListener, ServiceEvent> dispatcher = (EventDispatcher<ServiceListener, FilteredServiceListener, ServiceEvent>)entry.getKey();
/*  942 */       Set<Map.Entry<ServiceListener, FilteredServiceListener>> listenerSet = entry.getValue();
/*  943 */       queue.queueListeners(listenerSet, dispatcher);
/*      */     } 
/*  945 */     queue.dispatchEventSynchronous(3, event);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Collection<BundleContext> asBundleContexts(Collection<? extends BundleContext> c) {
/*  956 */     return (Collection)c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized long getNextServiceId() {
/*  965 */     long id = this.serviceid;
/*  966 */     this.serviceid = id + 1L;
/*  967 */     return id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addServiceRegistration(BundleContextImpl context, ServiceRegistrationImpl<?> registration) {
/*  978 */     assert Thread.holdsLock(this);
/*      */     
/*  980 */     List<ServiceRegistrationImpl<?>> contextServices = this.publishedServicesByContext.get(context);
/*  981 */     if (contextServices == null) {
/*  982 */       contextServices = new ArrayList<>(10);
/*  983 */       this.publishedServicesByContext.put(context, contextServices);
/*      */     } 
/*      */     
/*  986 */     contextServices.add(registration);
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  990 */     for (i = (arrayOfString = registration.getClasses()).length, b = 0; b < i; ) { String clazz = arrayOfString[b];
/*  991 */       List<ServiceRegistrationImpl<?>> services = this.publishedServicesByClass.get(clazz);
/*      */       
/*  993 */       if (services == null) {
/*  994 */         services = new ArrayList<>(10);
/*  995 */         this.publishedServicesByClass.put(clazz, services);
/*      */       } 
/*      */ 
/*      */       
/*  999 */       int j = -Collections.binarySearch((List)services, (T)registration) - 1;
/* 1000 */       services.add(j, registration);
/*      */       
/*      */       b++; }
/*      */ 
/*      */     
/* 1005 */     int insertIndex = -Collections.binarySearch((List)this.allPublishedServices, (T)registration) - 1;
/* 1006 */     this.allPublishedServices.add(insertIndex, registration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void modifyServiceRegistration(BundleContextImpl context, ServiceRegistrationImpl<?> registration, int previousRanking) {
/* 1018 */     assert Thread.holdsLock(this);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1023 */     if (registration.compareTo(previousRanking, registration.getId()) != 0) {
/*      */       byte b;
/*      */       
/*      */       int i;
/*      */       String[] arrayOfString;
/* 1028 */       for (i = (arrayOfString = registration.getClasses()).length, b = 0; b < i; ) { String clazz = arrayOfString[b];
/* 1029 */         List<ServiceRegistrationImpl<?>> services = this.publishedServicesByClass.get(clazz);
/* 1030 */         services.remove(registration);
/*      */         
/* 1032 */         int j = -1 - Collections.binarySearch((List)services, registration);
/* 1033 */         services.add(j, registration);
/*      */         
/*      */         b++; }
/*      */ 
/*      */       
/* 1038 */       this.allPublishedServices.remove(registration);
/*      */       
/* 1040 */       int insertIndex = -1 - Collections.binarySearch((List)this.allPublishedServices, registration);
/* 1041 */       this.allPublishedServices.add(insertIndex, registration);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeServiceRegistration(BundleContextImpl context, ServiceRegistrationImpl<?> registration) {
/* 1053 */     assert Thread.holdsLock(this);
/*      */     
/* 1055 */     List<ServiceRegistrationImpl<?>> contextServices = this.publishedServicesByContext.get(context);
/* 1056 */     if (contextServices != null)
/* 1057 */       contextServices.remove(registration); 
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1061 */     for (i = (arrayOfString = registration.getClasses()).length, b = 0; b < i; ) { String clazz = arrayOfString[b];
/* 1062 */       List<ServiceRegistrationImpl<?>> services = this.publishedServicesByClass.get(clazz);
/* 1063 */       services.remove(registration);
/* 1064 */       if (services.isEmpty()) {
/* 1065 */         this.publishedServicesByClass.remove(clazz);
/*      */       }
/*      */       
/*      */       b++; }
/*      */     
/* 1070 */     this.allPublishedServices.remove(registration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ServiceRegistrationImpl<?>> lookupServiceRegistrations(String clazz, Filter filter) {
/*      */     List<ServiceRegistrationImpl<?>> result;
/* 1083 */     synchronized (this) {
/* 1084 */       if (clazz == null) {
/* 1085 */         if (filter instanceof FilterImpl) {
/*      */           
/* 1087 */           String filterObjectClazz = ((FilterImpl)filter).getRequiredObjectClass();
/* 1088 */           if (filterObjectClazz != null) {
/* 1089 */             result = this.publishedServicesByClass.get(filterObjectClazz);
/* 1090 */             if (((FilterImpl)filter).getChildren().isEmpty())
/*      */             {
/*      */               
/* 1093 */               filter = null;
/*      */             }
/*      */           } else {
/* 1096 */             result = this.allPublishedServices;
/*      */           } 
/*      */         } else {
/*      */           
/* 1100 */           result = this.allPublishedServices;
/*      */         } 
/*      */       } else {
/*      */         
/* 1104 */         result = this.publishedServicesByClass.get(clazz);
/*      */       } 
/*      */       
/* 1107 */       if (result == null || result.isEmpty()) {
/* 1108 */         return Collections.emptyList();
/*      */       }
/*      */       
/* 1111 */       result = new LinkedList<>(result);
/*      */     } 
/*      */     
/* 1114 */     if (filter == null) {
/* 1115 */       return result;
/*      */     }
/*      */     
/* 1118 */     for (Iterator<ServiceRegistrationImpl<?>> iter = result.iterator(); iter.hasNext(); ) {
/* 1119 */       ServiceReferenceImpl<?> reference; ServiceRegistrationImpl<?> registration = iter.next();
/*      */       
/*      */       try {
/* 1122 */         reference = registration.getReferenceImpl();
/* 1123 */       } catch (IllegalStateException illegalStateException) {
/* 1124 */         iter.remove();
/*      */         continue;
/*      */       } 
/* 1127 */       if (!filter.match(reference)) {
/* 1128 */         iter.remove();
/*      */       }
/*      */     } 
/* 1131 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized List<ServiceRegistrationImpl<?>> lookupServiceRegistrations(BundleContextImpl context) {
/* 1141 */     List<ServiceRegistrationImpl<?>> result = this.publishedServicesByContext.get(context);
/*      */     
/* 1143 */     if (result == null || result.isEmpty()) {
/* 1144 */       return Collections.emptyList();
/*      */     }
/*      */     
/* 1147 */     return new ArrayList<>(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void removeServiceRegistrations(BundleContextImpl context) {
/* 1156 */     this.publishedServicesByContext.remove(context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkRegisterServicePermission(String[] names) {
/* 1165 */     SecurityManager sm = System.getSecurityManager();
/* 1166 */     if (sm == null)
/*      */       return;  byte b; int i;
/*      */     String[] arrayOfString;
/* 1169 */     for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 1170 */       sm.checkPermission((Permission)new ServicePermission(name, "register"));
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkGetServicePermission(ServiceReference<?> reference) {
/* 1178 */     SecurityManager sm = System.getSecurityManager();
/* 1179 */     if (sm == null) {
/*      */       return;
/*      */     }
/* 1182 */     sm.checkPermission((Permission)new ServicePermission(reference, "get"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean hasListenServicePermission(ServiceEvent event, BundleContextImpl context) {
/* 1189 */     ModuleRevision revision = context.getBundleImpl().getModule().getCurrentRevision();
/* 1190 */     if (revision == null) {
/* 1191 */       return false;
/*      */     }
/* 1193 */     ProtectionDomain domain = ((BundleInfo.Generation)revision.getRevisionInfo()).getDomain();
/* 1194 */     if (domain == null) {
/* 1195 */       return true;
/*      */     }
/*      */     
/* 1198 */     return domain.implies((Permission)new ServicePermission(event.getServiceReference(), "get"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String checkServiceClass(String[] clazzes, final Object serviceObject) {
/* 1208 */     ClassLoader cl = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/* 1211 */             return serviceObject.getClass().getClassLoader(); } }); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1214 */     for (i = (arrayOfString = clazzes).length, b = 0; b < i; ) { String element = arrayOfString[b];
/*      */       try {
/* 1216 */         Class<?> serviceClazz = (cl == null) ? Class.forName(element) : cl.loadClass(element);
/* 1217 */         if (!serviceClazz.isInstance(serviceObject))
/* 1218 */           return element; 
/* 1219 */       } catch (ClassNotFoundException classNotFoundException) {
/*      */         
/* 1221 */         if (extensiveCheckServiceClass(element, serviceObject.getClass()))
/* 1222 */           return element; 
/*      */       }  b++; }
/*      */     
/* 1225 */     return null;
/*      */   }
/*      */   
/*      */   private static boolean extensiveCheckServiceClass(String clazz, Class<?> serviceClazz) {
/* 1229 */     if (clazz.equals(serviceClazz.getName()))
/* 1230 */       return false; 
/* 1231 */     Class[] interfaces = serviceClazz.getInterfaces(); byte b; int i; Class[] arrayOfClass1;
/* 1232 */     for (i = (arrayOfClass1 = interfaces).length, b = 0; b < i; ) { Class<?> element = arrayOfClass1[b];
/* 1233 */       if (!extensiveCheckServiceClass(clazz, element))
/* 1234 */         return false;  b++; }
/* 1235 */      Class<?> superClazz = serviceClazz.getSuperclass();
/* 1236 */     if (superClazz != null && 
/* 1237 */       !extensiveCheckServiceClass(clazz, superClazz))
/* 1238 */       return false; 
/* 1239 */     return true;
/*      */   }
/*      */   
/*      */   static boolean isAssignableTo(BundleContextImpl context, String clazz, ServiceReferenceImpl<?> reference) {
/* 1243 */     EquinoxBundle equinoxBundle = context.getBundleImpl();
/* 1244 */     String[] clazzes = reference.getClasses(); byte b; int i; String[] arrayOfString1;
/* 1245 */     for (i = (arrayOfString1 = clazzes).length, b = 0; b < i; ) { String element = arrayOfString1[b];
/* 1246 */       if (!reference.getRegistration().isAssignableTo((Bundle)equinoxBundle, element, (element == clazz)))
/* 1247 */         return false;  b++; }
/* 1248 */      return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyFindHooks(final BundleContextImpl context, final String clazz, final String filterstring, final boolean allservices, final Collection<ServiceReference<?>> result) {
/* 1263 */     if (System.getSecurityManager() == null) {
/* 1264 */       notifyFindHooksPrivileged(context, clazz, filterstring, allservices, result);
/*      */     } else {
/* 1266 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*      */           {
/*      */             public Void run() {
/* 1269 */               ServiceRegistry.this.notifyFindHooksPrivileged(context, clazz, filterstring, allservices, result);
/* 1270 */               return null;
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   void notifyFindHooksPrivileged(BundleContextImpl context, String clazz, String filterstring, boolean allservices, Collection<ServiceReference<?>> result) {
/* 1277 */     if (this.debug.DEBUG_HOOKS) {
/* 1278 */       Debug.println("notifyServiceFindHooks(" + context.getBundleImpl() + "," + clazz + "," + filterstring + "," + allservices + "," + result + ")");
/*      */     }
/* 1280 */     notifyHooksPrivileged(FindHook.class, "find", (hook, hookRegistration) -> hook.find((BundleContext)paramBundleContextImpl, paramString1, paramString2, paramBoolean, paramCollection));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyEventHooksPrivileged(ServiceEvent event, Collection<BundleContext> result) {
/* 1294 */     if (this.debug.DEBUG_HOOKS) {
/* 1295 */       Debug.println("notifyServiceEventHooks(" + event.getType() + ":" + event.getServiceReference() + "," + result + ")");
/*      */     }
/* 1297 */     notifyHooksPrivileged(EventHook.class, "event", (hook, hookRegistration) -> hook.event(paramServiceEvent, paramCollection));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyEventListenerHooksPrivileged(ServiceEvent event, Map<BundleContext, Collection<ListenerHook.ListenerInfo>> result) {
/* 1310 */     if (this.debug.DEBUG_HOOKS) {
/* 1311 */       Debug.println("notifyServiceEventListenerHooks(" + event.getType() + ":" + event.getServiceReference() + "," + result + ")");
/*      */     }
/* 1313 */     notifyHooksPrivileged(EventListenerHook.class, "event", (hook, r) -> hook.event(paramServiceEvent, paramMap));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> void notifyHooksPrivileged(Class<T> hookType, String serviceMethod, HookContext<T> hookContext) {
/* 1325 */     List<ServiceRegistrationImpl<?>> hooks = lookupServiceRegistrations(hookType.getName(), null);
/*      */ 
/*      */ 
/*      */     
/* 1329 */     for (ServiceRegistrationImpl<?> registration : hooks) {
/* 1330 */       notifyHookPrivileged(this.systemBundleContext, registration, serviceMethod, 
/* 1331 */           hookContext);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> void notifyHookPrivileged(BundleContextImpl context, ServiceRegistrationImpl<T> registration, String serviceMethod, HookContext<T> hookContext) {
/* 1346 */     if (hookContext.skipRegistration(registration)) {
/*      */       return;
/*      */     }
/* 1349 */     T hook = registration.getHookInstance();
/* 1350 */     if (hook == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1357 */       hookContext.call(hook, registration);
/* 1358 */     } catch (Throwable t) {
/* 1359 */       if (this.debug.DEBUG_HOOKS) {
/* 1360 */         Debug.println(String.valueOf(hook.getClass().getName()) + "." + serviceMethod + "() exception: " + t.getMessage());
/* 1361 */         Debug.printStackTrace(t);
/*      */       } 
/*      */       
/* 1364 */       this.container.handleRuntimeError(t);
/* 1365 */       ServiceException se = new ServiceException(
/* 1366 */           NLS.bind(Msg.SERVICE_FACTORY_EXCEPTION, hook.getClass().getName(), serviceMethod), t);
/* 1367 */       this.container.getEventPublisher().publishFrameworkEvent(2, registration.getBundle(), (Throwable)se);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyNewListenerHook(final ServiceRegistrationImpl<?> registration) {
/* 1378 */     if (System.getSecurityManager() == null) {
/* 1379 */       notifyNewListenerHookPrivileged(registration);
/*      */     } else {
/* 1381 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*      */           {
/*      */             public Void run() {
/* 1384 */               ServiceRegistry.this.notifyNewListenerHookPrivileged(registration);
/* 1385 */               return null;
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void notifyNewListenerHookPrivileged(ServiceRegistrationImpl<?> registration) {
/* 1393 */     if (this.debug.DEBUG_HOOKS) {
/* 1394 */       Debug.println("notifyServiceNewListenerHook(" + registration + ")");
/*      */     }
/*      */ 
/*      */     
/* 1398 */     Collection<ListenerHook.ListenerInfo> addedListeners = new ArrayList<>(50);
/* 1399 */     synchronized (this.serviceEventListeners) {
/* 1400 */       for (CopyOnWriteIdentityMap<ServiceListener, FilteredServiceListener> copyOnWriteIdentityMap : this.serviceEventListeners.values()) {
/* 1401 */         if (!copyOnWriteIdentityMap.isEmpty()) {
/* 1402 */           addedListeners.addAll(copyOnWriteIdentityMap.values());
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1407 */     Collection<ListenerHook.ListenerInfo> listeners = Collections.unmodifiableCollection(addedListeners);
/* 1408 */     notifyHookPrivileged(this.systemBundleContext, registration, "added", (hook, hookRegistration) -> {
/*      */           if (hook instanceof ListenerHook) {
/*      */             ((ListenerHook)hook).added(paramCollection);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyListenerHooks(final Collection<ListenerHook.ListenerInfo> listeners, final boolean added) {
/* 1426 */     if (System.getSecurityManager() == null) {
/* 1427 */       notifyListenerHooksPrivileged(listeners, added);
/*      */     } else {
/* 1429 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*      */           {
/*      */             public Void run() {
/* 1432 */               ServiceRegistry.this.notifyListenerHooksPrivileged(listeners, added);
/* 1433 */               return null;
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void notifyListenerHooksPrivileged(Collection<ListenerHook.ListenerInfo> listeners, boolean added) {
/* 1441 */     assert !listeners.isEmpty();
/* 1442 */     if (this.debug.DEBUG_HOOKS) {
/* 1443 */       Debug.println("notifyServiceListenerHooks(" + listeners + "," + (added ? "added" : "removed") + ")");
/*      */     }
/*      */     
/* 1446 */     notifyHooksPrivileged(ListenerHook.class, added ? "added" : "removed", (hook, hookRegistration) -> {
/*      */           if (paramBoolean) {
/*      */             hook.added(paramCollection);
/*      */           } else {
/*      */             hook.removed(paramCollection);
/*      */           } 
/*      */         });
/*      */   }
/*      */   
/*      */   final EquinoxContainer getContainer() {
/* 1456 */     return this.container;
/*      */   }
/*      */   
/*      */   ConcurrentMap<Thread, ServiceUse.ServiceUseLock> getAwaitedUseLocks() {
/* 1460 */     return this.awaitedUseLocks;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */