/*     */ package org.eclipse.osgi.internal.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tokenizer
/*     */ {
/*     */   protected char[] value;
/*     */   protected int max;
/*     */   protected int cursor;
/*     */   
/*     */   public Tokenizer(String value) {
/*  29 */     this.value = value.toCharArray();
/*  30 */     this.max = this.value.length;
/*  31 */     this.cursor = 0;
/*     */   }
/*     */   
/*     */   private void skipWhiteSpace() {
/*  35 */     char[] val = this.value;
/*  36 */     int cur = this.cursor;
/*     */     
/*  38 */     while (cur < this.max) {
/*  39 */       char c = val[cur];
/*  40 */       if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
/*     */         cur++; continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*  45 */     this.cursor = cur;
/*     */   }
/*     */   
/*     */   public String getToken(String terminals) {
/*  49 */     skipWhiteSpace();
/*  50 */     char[] val = this.value;
/*  51 */     int cur = this.cursor;
/*     */     
/*  53 */     int begin = cur;
/*  54 */     for (; cur < this.max; cur++) {
/*  55 */       char c = val[cur];
/*  56 */       if (terminals.indexOf(c) != -1) {
/*     */         break;
/*     */       }
/*     */     } 
/*  60 */     this.cursor = cur;
/*  61 */     int count = cur - begin;
/*  62 */     if (count > 0) {
/*  63 */       skipWhiteSpace();
/*  64 */       while (count > 0 && (val[begin + count - 1] == ' ' || val[begin + count - 1] == '\t'))
/*  65 */         count--; 
/*  66 */       return new String(val, begin, count);
/*     */     } 
/*  68 */     return null;
/*     */   }
/*     */   
/*     */   public String getEscapedToken(String terminals) {
/*  72 */     char[] val = this.value;
/*  73 */     int cur = this.cursor;
/*  74 */     if (cur >= this.max)
/*  75 */       return null; 
/*  76 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  78 */     for (; cur < this.max; cur++) {
/*  79 */       char c = val[cur];
/*     */       
/*  81 */       if (c == '\\') {
/*  82 */         cur++;
/*  83 */         if (cur == this.max)
/*     */           break; 
/*  85 */         c = val[cur];
/*  86 */       } else if (terminals.indexOf(c) != -1) {
/*     */         break;
/*     */       } 
/*  89 */       sb.append(c);
/*     */     } 
/*     */     
/*  92 */     this.cursor = cur;
/*  93 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public List<String> getEscapedTokens(String terminals) {
/*  97 */     List<String> result = new ArrayList<>();
/*  98 */     for (String token = getEscapedToken(terminals); token != null; token = getEscapedToken(terminals)) {
/*  99 */       result.add(token);
/* 100 */       getChar();
/*     */     } 
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public String getString(String terminals, String preserveEscapes) {
/* 106 */     skipWhiteSpace();
/* 107 */     char[] val = this.value;
/* 108 */     int cur = this.cursor;
/*     */     
/* 110 */     if (cur < this.max) {
/* 111 */       if (val[cur] == '"') {
/*     */         
/* 113 */         StringBuilder sb = new StringBuilder();
/* 114 */         cur++;
/* 115 */         char c = Character.MIN_VALUE;
/* 116 */         for (; cur < this.max; cur++) {
/* 117 */           c = val[cur];
/*     */           
/* 119 */           if (c == '\\') {
/* 120 */             cur++;
/* 121 */             if (cur == this.max)
/*     */               break; 
/* 123 */             c = val[cur];
/* 124 */             if (preserveEscapes != null && preserveEscapes.indexOf(c) != -1)
/* 125 */               sb.append('\\'); 
/* 126 */           } else if (c == '"') {
/*     */             break;
/*     */           } 
/* 129 */           sb.append(c);
/*     */         } 
/*     */         
/* 132 */         if (c == '"') {
/* 133 */           cur++;
/*     */         }
/*     */         
/* 136 */         this.cursor = cur;
/* 137 */         skipWhiteSpace();
/* 138 */         return sb.toString();
/*     */       } 
/*     */ 
/*     */       
/* 142 */       return getToken(terminals);
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   public String getString(String terminals) {
/* 148 */     return getString(terminals, null);
/*     */   }
/*     */   
/*     */   public char getChar() {
/* 152 */     int cur = this.cursor;
/* 153 */     if (cur < this.max) {
/* 154 */       this.cursor = cur + 1;
/* 155 */       return this.value[cur];
/*     */     } 
/* 157 */     return Character.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 161 */     if (this.cursor < this.max) {
/* 162 */       return true;
/*     */     }
/* 164 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\util\Tokenizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */