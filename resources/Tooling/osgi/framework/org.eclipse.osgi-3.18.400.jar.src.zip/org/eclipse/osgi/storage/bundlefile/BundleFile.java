/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.AccessController;
/*     */ import java.util.Enumeration;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.storage.url.BundleResourceHandler;
/*     */ import org.eclipse.osgi.storage.url.bundleresource.Handler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BundleFile
/*     */ {
/*  40 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */ 
/*     */   
/*     */   protected File basefile;
/*     */   
/*  45 */   private int mruIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BundleFile(File basefile) {
/*  53 */     this.basefile = basefile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract File getFile(String paramString, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BundleEntry getEntry(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path) {
/*  84 */     return getEntryPaths(path, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Enumeration<String> getEntryPaths(String paramString, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void open() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean containsDir(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResourceURL(String path, Module hostModule, int index) {
/* 142 */     BundleEntry bundleEntry = getEntry(path);
/* 143 */     if (bundleEntry == null)
/* 144 */       return null; 
/* 145 */     return createResourceURL(bundleEntry, hostModule, index, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URL createResourceURL(BundleEntry bundleEntry, Module hostModule, int index, String path) {
/* 158 */     String protocol = "bundleresource";
/* 159 */     long bundleId = hostModule.getId().longValue();
/* 160 */     ModuleContainer container = hostModule.getContainer();
/* 161 */     Handler handler = new Handler(container, bundleEntry);
/* 162 */     return createURL(protocol, bundleId, container, bundleEntry, index, path, (URLStreamHandler)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getBaseFile() {
/* 170 */     return this.basefile;
/*     */   }
/*     */   
/*     */   void setMruIndex(int index) {
/* 174 */     this.mruIndex = index;
/*     */   }
/*     */   
/*     */   int getMruIndex() {
/* 178 */     return this.mruIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 183 */     return String.valueOf(this.basefile);
/*     */   }
/*     */ 
/*     */   
/*     */   public static URL createURL(String protocol, long bundleId, ModuleContainer container, BundleEntry entry, int index, String path, URLStreamHandler handler) {
/* 188 */     path = fixTrailingSlash(path, entry);
/*     */     try {
/* 190 */       String host = BundleResourceHandler.createURLHostForBundleID(container, bundleId);
/* 191 */       return secureAction.getURL(protocol, host, index, path, handler);
/* 192 */     } catch (MalformedURLException malformedURLException) {
/* 193 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String fixTrailingSlash(String path, BundleEntry entry) {
/* 198 */     if (path.length() == 0)
/* 199 */       return "/"; 
/* 200 */     if (path.charAt(0) != '/')
/* 201 */       path = String.valueOf('/') + path; 
/* 202 */     String name = entry.getName();
/* 203 */     if (name.length() == 0)
/* 204 */       return path; 
/* 205 */     boolean pathSlash = (path.charAt(path.length() - 1) == '/');
/* 206 */     boolean entrySlash = (name.length() > 0 && name.charAt(name.length() - 1) == '/');
/* 207 */     if (entrySlash != pathSlash)
/* 208 */       if (entrySlash) {
/* 209 */         path = String.valueOf(path) + '/';
/*     */       } else {
/* 211 */         path = path.substring(0, path.length() - 1);
/*     */       }  
/* 213 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\BundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */