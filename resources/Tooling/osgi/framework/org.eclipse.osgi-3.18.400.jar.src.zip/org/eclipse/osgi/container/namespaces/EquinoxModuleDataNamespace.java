package org.eclipse.osgi.container.namespaces;

import org.osgi.resource.Namespace;

public class EquinoxModuleDataNamespace extends Namespace {
  public static final String BUDDY_POLICY_HEADER = "Eclipse-BuddyPolicy";
  
  public static final String REGISTERED_BUDDY_HEADER = "Eclipse-RegisterBuddy";
  
  public static final String LAZYSTART_HEADER = "Eclipse-LazyStart";
  
  public static final String LAZYSTART_EXCEPTIONS_ATTRIBUTE = "exceptions";
  
  public static final String AUTOSTART_HEADER = "Eclipse-AutoStart";
  
  public static final String MODULE_DATA_NAMESPACE = "equinox.module.data";
  
  public static final String EFFECTIVE_INFORMATION = "information";
  
  public static final String CAPABILITY_ACTIVATION_POLICY = "activation.policy";
  
  public static final String CAPABILITY_ACTIVATION_POLICY_LAZY = "lazy";
  
  public static final String CAPABILITY_LAZY_INCLUDE_ATTRIBUTE = "lazy.include";
  
  public static final String CAPABILITY_LAZY_EXCLUDE_ATTRIBUTE = "lazy.exclude";
  
  public static final String CAPABILITY_ACTIVATOR = "activator";
  
  public static final String CAPABILITY_CLASSPATH = "classpath";
  
  public static final String CAPABILITY_BUDDY_POLICY = "buddy.policy";
  
  public static final String CAPABILITY_BUDDY_REGISTERED = "buddy.registered";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\namespaces\EquinoxModuleDataNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */