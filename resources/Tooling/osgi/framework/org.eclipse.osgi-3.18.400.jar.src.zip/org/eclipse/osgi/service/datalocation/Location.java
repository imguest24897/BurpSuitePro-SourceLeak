/*     */ package org.eclipse.osgi.service.datalocation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Location
/*     */ {
/*     */   public static final String ECLIPSE_HOME_LOCATION_TYPE = "eclipse.home.location";
/*     */   public static final String USER_AREA_TYPE = "osgi.user.area";
/*     */   public static final String CONFIGURATION_AREA_TYPE = "osgi.configuration.area";
/*     */   public static final String INSTALL_AREA_TYPE = "osgi.install.area";
/*     */   public static final String INSTANCE_AREA_TYPE = "osgi.instance.area";
/*     */   public static final String SERVICE_PROPERTY_TYPE = "type";
/*     */   public static final String SERVICE_PROPERTY_URL = "url";
/*     */   public static final String SERVICE_PROPERTY_DEFAULT_URL = "defaultUrl";
/* 110 */   public static final String INSTANCE_FILTER = "(&(objectClass=" + Location.class.getName() + ")(" + "type" + "=" + "osgi.instance.area" + "))";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final String INSTALL_FILTER = "(&(objectClass=" + Location.class.getName() + ")(" + "type" + "=" + "osgi.install.area" + "))";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public static final String CONFIGURATION_FILTER = "(&(objectClass=" + Location.class.getName() + ")(" + "type" + "=" + "osgi.configuration.area" + "))";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public static final String USER_FILTER = "(&(objectClass=" + Location.class.getName() + ")(" + "type" + "=" + "osgi.user.area" + "))";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public static final String ECLIPSE_HOME_FILTER = "(&(objectClass=" + Location.class.getName() + ")(" + "type" + "=" + "eclipse.home.location" + "))";
/*     */   
/*     */   boolean allowsDefault();
/*     */   
/*     */   URL getDefault();
/*     */   
/*     */   Location getParentLocation();
/*     */   
/*     */   URL getURL();
/*     */   
/*     */   boolean isSet();
/*     */   
/*     */   boolean isReadOnly();
/*     */   
/*     */   boolean setURL(URL paramURL, boolean paramBoolean) throws IllegalStateException;
/*     */   
/*     */   boolean set(URL paramURL, boolean paramBoolean) throws IllegalStateException, IOException;
/*     */   
/*     */   boolean set(URL paramURL, boolean paramBoolean, String paramString) throws IllegalStateException, IOException;
/*     */   
/*     */   boolean lock() throws IOException;
/*     */   
/*     */   void release();
/*     */   
/*     */   boolean isLocked() throws IOException;
/*     */   
/*     */   Location createLocation(Location paramLocation, URL paramURL, boolean paramBoolean);
/*     */   
/*     */   URL getDataArea(String paramString) throws IOException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\datalocation\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */