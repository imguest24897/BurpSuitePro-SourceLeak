/*    */ package org.eclipse.osgi.internal.permadmin;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.osgi.service.condpermadmin.ConditionalPermissionInfo;
/*    */ import org.osgi.service.condpermadmin.ConditionalPermissionUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityTableUpdate
/*    */   implements ConditionalPermissionUpdate
/*    */ {
/*    */   private final SecurityAdmin securityAdmin;
/*    */   private final List<ConditionalPermissionInfo> rows;
/*    */   private final long timeStamp;
/*    */   
/*    */   public SecurityTableUpdate(SecurityAdmin securityAdmin, SecurityRow[] rows, long timeStamp) {
/* 28 */     this.securityAdmin = securityAdmin;
/* 29 */     this.timeStamp = timeStamp;
/*    */     
/* 31 */     this.rows = new ArrayList<>(rows.length); byte b; int i; SecurityRow[] arrayOfSecurityRow;
/* 32 */     for (i = (arrayOfSecurityRow = rows).length, b = 0; b < i; ) { SecurityRow row = arrayOfSecurityRow[b];
/*    */ 
/*    */       
/* 35 */       this.rows.add(new SecurityRowSnapShot(row.getName(), row.internalGetConditionInfos(), row.internalGetPermissionInfos(), row.getAccessDecision()));
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   public boolean commit() {
/* 41 */     return this.securityAdmin.commit(this.rows, this.timeStamp);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<ConditionalPermissionInfo> getConditionalPermissionInfos() {
/* 47 */     return this.rows;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\SecurityTableUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */