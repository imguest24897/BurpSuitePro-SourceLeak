/*    */ package org.eclipse.osgi.storage.bundlefile;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Enumeration;
/*    */ import org.eclipse.osgi.container.Module;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleFileWrapper
/*    */   extends BundleFile
/*    */ {
/*    */   private final BundleFile bundleFile;
/*    */   
/*    */   public BundleFileWrapper(BundleFile bundleFile) {
/* 44 */     super(bundleFile.getBaseFile());
/* 45 */     this.bundleFile = bundleFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public File getFile(String path, boolean nativeCode) {
/* 50 */     return this.bundleFile.getFile(path, nativeCode);
/*    */   }
/*    */ 
/*    */   
/*    */   public BundleEntry getEntry(String path) {
/* 55 */     return this.bundleFile.getEntry(path);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<String> getEntryPaths(String path) {
/* 60 */     return this.bundleFile.getEntryPaths(path);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<String> getEntryPaths(String path, boolean recurse) {
/* 65 */     return this.bundleFile.getEntryPaths(path, recurse);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleFile getBundleFile() {
/* 74 */     return this.bundleFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 79 */     this.bundleFile.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public void open() throws IOException {
/* 84 */     this.bundleFile.open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsDir(String dir) {
/* 89 */     return this.bundleFile.containsDir(dir);
/*    */   }
/*    */ 
/*    */   
/*    */   protected URL createResourceURL(BundleEntry bundleEntry, Module hostModule, int index, String path) {
/* 94 */     return this.bundleFile.createResourceURL(bundleEntry, hostModule, index, path);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\BundleFileWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */