/*     */ package org.eclipse.osgi.internal.loader.sources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PackageSource
/*     */ {
/*     */   protected final String id;
/*     */   
/*     */   public PackageSource(String id) {
/*  33 */     this.id = id.intern();
/*     */   }
/*     */   
/*     */   public String getId() {
/*  37 */     return this.id;
/*     */   }
/*     */   
/*     */   public abstract SingleSourcePackage[] getSuppliers();
/*     */   
/*     */   public boolean compare(PackageSource other) {
/*  43 */     return this.id.equals(other.getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  48 */     return this.id.hashCode();
/*     */   }
/*     */   
/*     */   public boolean isNullSource() {
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract Class<?> loadClass(String paramString) throws ClassNotFoundException;
/*     */ 
/*     */   
/*     */   public abstract URL getResource(String paramString);
/*     */   
/*     */   public abstract Enumeration<URL> getResources(String paramString) throws IOException;
/*     */   
/*     */   public boolean hasCommonSource(PackageSource other) {
/*  64 */     if (other == null)
/*  65 */       return false; 
/*  66 */     if (this == other)
/*  67 */       return true; 
/*  68 */     SingleSourcePackage[] suppliers1 = getSuppliers();
/*  69 */     SingleSourcePackage[] suppliers2 = other.getSuppliers();
/*  70 */     if (suppliers1 == null || suppliers2 == null)
/*  71 */       return false;  byte b;
/*     */     int i;
/*     */     SingleSourcePackage[] arrayOfSingleSourcePackage1;
/*  74 */     for (i = (arrayOfSingleSourcePackage1 = suppliers1).length, b = 0; b < i; ) { SingleSourcePackage supplier1 = arrayOfSingleSourcePackage1[b]; byte b1; int j; SingleSourcePackage[] arrayOfSingleSourcePackage;
/*  75 */       for (j = (arrayOfSingleSourcePackage = suppliers2).length, b1 = 0; b1 < j; ) { SingleSourcePackage supplier2 = arrayOfSingleSourcePackage[b1];
/*  76 */         if (supplier2.equals(supplier1))
/*  77 */           return true;  b1++; }
/*     */       
/*     */       b++; }
/*     */     
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     StringBuilder builder = new StringBuilder();
/*  87 */     builder.append(this.id).append(" -> ");
/*  88 */     SingleSourcePackage[] suppliers = getSuppliers();
/*  89 */     if (suppliers == null) {
/*  90 */       return builder.append("null").toString();
/*     */     }
/*  92 */     builder.append('[');
/*  93 */     for (int i = 0; i < suppliers.length; i++) {
/*  94 */       if (i > 0) {
/*  95 */         builder.append(',');
/*     */       }
/*  97 */       builder.append(suppliers[i].getLoader());
/*     */     } 
/*  99 */     builder.append(']');
/* 100 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Collection<String> listResources(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isServiceAssignableTo(Bundle registrant, Bundle client, String className, Class<?> serviceClass, boolean checkInternal, EquinoxContainer container) {
/* 117 */     if (registrant == client) {
/* 118 */       return true;
/*     */     }
/*     */     
/* 121 */     String pkgName = BundleLoader.getPackageName(className);
/* 122 */     if (pkgName.startsWith("java.")) {
/* 123 */       return true;
/*     */     }
/*     */     
/* 126 */     BundleLoader producerBL = getBundleLoader(registrant);
/* 127 */     if (producerBL == null) {
/* 128 */       return false;
/*     */     }
/* 130 */     BundleLoader consumerBL = getBundleLoader(client);
/* 131 */     if (consumerBL == null) {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     PackageSource consumerSource = getSourceFromLoader(consumerBL, pkgName, className, checkInternal, 
/* 136 */         container);
/* 137 */     if (consumerSource == null)
/*     */     {
/* 139 */       return true;
/*     */     }
/*     */     
/* 142 */     if (container.isBootDelegationPackage(pkgName)) {
/* 143 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 147 */     PackageSource producerSource = getSourceFromLoader(producerBL, pkgName, className, checkInternal, 
/* 148 */         container);
/* 149 */     if (producerSource == null) {
/*     */       
/* 151 */       if (serviceClass != null && ServiceFactory.class.isAssignableFrom(serviceClass)) {
/* 152 */         Bundle bundle = container.getBundle(serviceClass);
/* 153 */         if (bundle != null && bundle != registrant)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 158 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 163 */       producerSource = getPackageSource(serviceClass, pkgName, className, checkInternal, 
/* 164 */           container);
/* 165 */       if (producerSource == null) {
/* 166 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 170 */     return producerSource.hasCommonSource(consumerSource);
/*     */   }
/*     */ 
/*     */   
/*     */   private static PackageSource getSourceFromLoader(BundleLoader loader, String pkgName, String className, boolean checkInternal, EquinoxContainer container) {
/* 175 */     PackageSource source = loader.getPackageSource(pkgName);
/* 176 */     if (source != null || !checkInternal) {
/* 177 */       return source;
/*     */     }
/*     */     try {
/* 180 */       Class<?> clazz = loader.findLocalClass(className);
/* 181 */       if (clazz != null) {
/*     */         
/* 183 */         Bundle b = container.getBundle(clazz);
/* 184 */         if (b != null) {
/* 185 */           if (loader.getWiring().getBundle() == b)
/*     */           {
/* 187 */             return new SingleSourcePackage(pkgName, loader);
/*     */           }
/*     */           
/* 190 */           BundleLoader classBundleLoader = getBundleLoader(b);
/* 191 */           if (classBundleLoader != null) {
/* 192 */             return new SingleSourcePackage(pkgName, classBundleLoader);
/*     */           }
/*     */         } 
/*     */       } 
/* 196 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static PackageSource getPackageSource(Class<?> serviceClass, String pkgName, String className, boolean checkInternal, EquinoxContainer container) {
/* 204 */     if (serviceClass == null) {
/* 205 */       return null;
/*     */     }
/* 207 */     Bundle serviceBundle = container.getBundle(serviceClass);
/* 208 */     if (serviceBundle == null) {
/* 209 */       return null;
/*     */     }
/* 211 */     BundleLoader producerBL = getBundleLoader(serviceBundle);
/* 212 */     if (producerBL == null) {
/* 213 */       return null;
/*     */     }
/* 215 */     PackageSource producerSource = getSourceFromLoader(producerBL, pkgName, className, checkInternal, container);
/* 216 */     if (producerSource != null) {
/* 217 */       return producerSource;
/*     */     }
/*     */     
/* 220 */     Class[] interfaces = serviceClass.getInterfaces(); byte b; int i;
/*     */     Class[] arrayOfClass1;
/* 222 */     for (i = (arrayOfClass1 = interfaces).length, b = 0; b < i; ) { Class<?> intf = arrayOfClass1[b];
/* 223 */       producerSource = getPackageSource(intf, pkgName, className, checkInternal, container);
/* 224 */       if (producerSource != null) {
/* 225 */         return producerSource;
/*     */       }
/*     */       b++; }
/*     */     
/* 229 */     return getPackageSource(serviceClass.getSuperclass(), pkgName, className, checkInternal, container);
/*     */   }
/*     */   
/*     */   private static BundleLoader getBundleLoader(Bundle bundle) {
/* 233 */     ModuleRevision producer = ((EquinoxBundle)bundle).getModule().getCurrentRevision();
/* 234 */     ModuleWiring producerWiring = producer.getWiring();
/* 235 */     return (producerWiring == null) ? null : (BundleLoader)producerWiring.getModuleLoader();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\sources\PackageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */