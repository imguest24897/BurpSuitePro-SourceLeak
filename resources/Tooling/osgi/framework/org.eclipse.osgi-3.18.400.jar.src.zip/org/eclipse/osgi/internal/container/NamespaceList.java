/*     */ package org.eclipse.osgi.internal.container;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleRequirement;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamespaceList<E>
/*     */ {
/*  49 */   public static final Function<ModuleWire, String> WIRE = new Function<ModuleWire, String>() {
/*     */       public String apply(ModuleWire wire) {
/*  51 */         return wire.getCapability().getNamespace();
/*     */       }
/*     */     };
/*  54 */   public static final Function<ModuleCapability, String> CAPABILITY = new Function<ModuleCapability, String>() {
/*     */       public String apply(ModuleCapability capability) {
/*  56 */         return capability.getNamespace();
/*     */       }
/*     */     };
/*  59 */   public static final Function<ModuleRequirement, String> REQUIREMENT = new Function<ModuleRequirement, String>() {
/*     */       public String apply(ModuleRequirement requirement) {
/*  61 */         return requirement.getNamespace();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<E> elements;
/*     */ 
/*     */   
/*     */   private final Map<String, List<E>> namespaces;
/*     */ 
/*     */   
/*     */   private final Function<E, String> getNamespace;
/*     */ 
/*     */   
/*     */   public static <E> NamespaceList<E> empty(Function<E, String> getNamespace) {
/*  77 */     return new NamespaceList<>(getNamespace, Collections.emptyMap(), Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamespaceList(Function<E, String> getNamespace, Map<String, List<E>> namespaces, List<E> fullList) {
/*  85 */     this.getNamespace = getNamespace;
/*  86 */     this.namespaces = namespaces;
/*  87 */     this.elements = fullList;
/*     */   }
/*     */   
/*     */   Map<String, List<E>> namespaces() {
/*  91 */     return this.namespaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 100 */     return this.elements.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<E> getList(String namespace) {
/* 115 */     if (namespace == null) {
/* 116 */       return this.elements;
/*     */     }
/* 118 */     return this.namespaces.getOrDefault(namespace, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder<E> createBuilder() {
/* 132 */     Builder<E> builder = Builder.create(this.getNamespace);
/* 133 */     builder.addAll(this);
/* 134 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder<E>
/*     */     extends AbstractCollection<E>
/*     */   {
/*     */     private final Function<E, String> getNamespace;
/*     */ 
/*     */ 
/*     */     
/*     */     private LinkedHashMap<String, List<E>> namespaceElements;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <E> Builder<E> create(Function<E, String> getNamespace) {
/* 154 */       return new Builder<>(getNamespace, 3);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 159 */     private int size = 0;
/*     */     
/*     */     private List<E> lastBuildElements;
/*     */     
/*     */     private Builder(Function<E, String> getNamespace, int expectedNamespaces) {
/* 164 */       this.getNamespace = getNamespace;
/* 165 */       this.namespaceElements = new LinkedHashMap<>(expectedNamespaces * 4 / 3 + 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 170 */       return this.size;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<E> iterator() {
/* 175 */       prepareModification();
/*     */       
/* 177 */       final Iterator<? extends List<E>> outer = this.namespaceElements.values().iterator();
/* 178 */       return new Iterator<E>() {
/* 179 */           Iterator<E> inner = Collections.emptyIterator();
/* 180 */           List<E> lastInnerList = null;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 184 */             while (!this.inner.hasNext() && outer.hasNext()) {
/* 185 */               this.lastInnerList = outer.next();
/* 186 */               this.inner = this.lastInnerList.iterator();
/*     */             } 
/* 188 */             return this.inner.hasNext();
/*     */           }
/*     */           
/*     */           public E next() {
/* 192 */             if (!hasNext()) {
/* 193 */               throw new NoSuchElementException();
/*     */             }
/* 195 */             return this.inner.next();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void remove() {
/* 201 */             this.inner.remove();
/* 202 */             NamespaceList.Builder.this.size = NamespaceList.Builder.this.size - 1;
/* 203 */             if (this.lastInnerList.isEmpty()) {
/* 204 */               outer.remove();
/*     */             }
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 212 */       this.namespaceElements = new LinkedHashMap<>();
/* 213 */       this.lastBuildElements = null;
/* 214 */       this.size = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<E> getNamespaceElements(String namespace) {
/* 230 */       if (namespace == null) {
/* 231 */         List<E> list = new ArrayList<>(this.size);
/* 232 */         for (List<E> es : this.namespaceElements.values()) {
/* 233 */           list.addAll(es);
/*     */         }
/* 235 */         return Collections.unmodifiableList(list);
/*     */       } 
/* 237 */       List<E> namespaceList = this.namespaceElements.get(namespace);
/* 238 */       return (namespaceList != null) ? Collections.<E>unmodifiableList(new ArrayList<>(namespaceList)) : 
/* 239 */         Collections.<E>emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> Builder<R> transformIntoCopy(Function<E, R> transformation, Function<R, String> newGetNamespace) {
/* 259 */       Builder<R> transformedBuilder = new Builder(newGetNamespace, this.namespaceElements.size());
/* 260 */       transformedBuilder.size = this.size;
/* 261 */       for (Map.Entry<String, List<E>> entry : this.namespaceElements.entrySet()) {
/* 262 */         List<E> es = entry.getValue();
/* 263 */         List<R> transformedElements = new ArrayList<>(es.size());
/* 264 */         for (E e : es) {
/* 265 */           transformedElements.add(transformation.apply(e));
/*     */         }
/* 267 */         transformedBuilder.namespaceElements.put(entry.getKey(), transformedElements);
/*     */       } 
/* 269 */       return transformedBuilder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean add(E e) {
/* 276 */       prepareModification();
/*     */       
/* 278 */       String namespace = this.getNamespace.apply(e);
/* 279 */       getNamespaceList(namespace).add(e);
/* 280 */       this.size++;
/* 281 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends E> c) {
/* 286 */       if (c.isEmpty()) {
/* 287 */         return false;
/*     */       }
/* 289 */       prepareModification();
/*     */       
/* 291 */       if (c instanceof Builder) {
/*     */         
/* 293 */         Builder<E> builder = (Builder)c;
/* 294 */         return addAll(builder.namespaceElements);
/*     */       } 
/* 296 */       String currentNamespace = null;
/* 297 */       List<E> currentNamespaceList = null;
/* 298 */       for (E e : c) {
/* 299 */         String namespace = this.getNamespace.apply(e);
/*     */         
/* 301 */         if (currentNamespace == null || !currentNamespace.equals(namespace)) {
/* 302 */           currentNamespace = namespace;
/* 303 */           currentNamespaceList = getNamespaceList(namespace);
/*     */         } 
/* 305 */         currentNamespaceList.add(e);
/*     */       } 
/* 307 */       this.size += c.size();
/* 308 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean addAll(NamespaceList<E> list) {
/* 318 */       if (list.isEmpty()) {
/* 319 */         return false;
/*     */       }
/* 321 */       prepareModification();
/*     */       
/* 323 */       return addAll(list.namespaces());
/*     */     }
/*     */     
/*     */     private boolean addAll(Map<String, List<E>> perNamespaceElements) {
/* 327 */       for (Map.Entry<String, List<E>> entry : perNamespaceElements.entrySet()) {
/* 328 */         List<E> es = entry.getValue();
/* 329 */         getNamespaceList(entry.getKey()).addAll(es);
/* 330 */         this.size += es.size();
/*     */       } 
/* 332 */       return true;
/*     */     }
/*     */     
/*     */     private List<E> getNamespaceList(String namespace) {
/* 336 */       return this.namespaceElements.computeIfAbsent(namespace, new Function<String, List<E>>() {
/*     */             public List<E> apply(String n) {
/* 338 */               return new ArrayList<>();
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addAllFiltered(NamespaceList<E> list, Predicate<? super String> namespaceFilter, Predicate<? super E> elementFilter) {
/* 361 */       addAllFilteredAfterLastMatch(list, namespaceFilter, elementFilter, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addAllFilteredAfterLastMatch(NamespaceList<E> list, Predicate<? super String> namespaceFilter, Predicate<? super E> elementFilter, final BiPredicate<E, E> insertionMatcher) {
/* 391 */       if (list.isEmpty()) {
/*     */         return;
/*     */       }
/* 394 */       prepareModification();
/*     */       
/* 396 */       for (Map.Entry<String, List<E>> entry : (Iterable<Map.Entry<String, List<E>>>)list.namespaces().entrySet()) {
/* 397 */         String namespace = entry.getKey();
/* 398 */         if (namespaceFilter.test(namespace)) {
/* 399 */           List<E> targetList = getNamespaceList(namespace);
/* 400 */           List<E> elementsToAdd = entry.getValue();
/* 401 */           for (E toAdd : elementsToAdd) {
/* 402 */             if (elementFilter.test(toAdd)) {
/* 403 */               if (insertionMatcher == null) {
/* 404 */                 targetList.add(toAdd);
/*     */               } else {
/* 406 */                 addAfterLastMatch(toAdd, targetList, new Predicate<E>() {
/*     */                       public boolean test(E e) {
/* 408 */                         return insertionMatcher.test(toAdd, e);
/*     */                       }
/*     */                     });
/*     */               } 
/* 412 */               this.size++;
/*     */             } 
/*     */           } 
/* 415 */           if (targetList.isEmpty()) {
/* 416 */             this.namespaceElements.remove(namespace);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void addAfterLastMatch(E e, List<E> list, Predicate<E> matcher) {
/* 423 */       for (int i = list.size() - 1; i >= 0; i--) {
/* 424 */         if (matcher.test(list.get(i))) {
/* 425 */           list.add(i + 1, e);
/*     */           return;
/*     */         } 
/*     */       } 
/* 429 */       list.add(0, e);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean remove(Object o) {
/*     */       String namespace;
/* 437 */       E e = (E)o;
/*     */       
/*     */       try {
/* 440 */         namespace = this.getNamespace.apply(e);
/* 441 */       } catch (ClassCastException classCastException) {
/* 442 */         return false;
/*     */       } 
/* 444 */       prepareModification();
/*     */       
/* 446 */       int sizeBefore = this.size;
/* 447 */       removeNamespaceElement(namespace, e);
/* 448 */       return (this.size < sizeBefore);
/*     */     }
/*     */     
/*     */     private void removeNamespaceElement(String namespace, final E element) {
/* 452 */       this.namespaceElements.computeIfPresent(namespace, new BiFunction<String, List<E>, List<E>>() {
/*     */             public List<E> apply(String n, List<E> es) {
/* 454 */               if (es.remove(element)) {
/* 455 */                 NamespaceList.Builder.this.size = NamespaceList.Builder.this.size - 1;
/*     */               }
/* 457 */               return es.isEmpty() ? null : es;
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> c) {
/* 464 */       if (c.isEmpty()) {
/* 465 */         return false;
/*     */       }
/* 467 */       prepareModification();
/*     */ 
/*     */       
/* 470 */       boolean removed = false;
/* 471 */       for (Object e : c) {
/* 472 */         removed |= remove(e);
/*     */       }
/* 474 */       return removed;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeNamespaceIf(final Predicate<String> filter) {
/* 484 */       prepareModification();
/*     */       
/* 486 */       this.namespaceElements.entrySet().removeIf(new Predicate<Map.Entry<String, List<E>>>() {
/*     */             public boolean test(Map.Entry<String, List<E>> e) {
/* 488 */               if (filter.test(e.getKey())) {
/* 489 */                 NamespaceList.Builder.this.size = NamespaceList.Builder.this.size - ((List)e.getValue()).size();
/* 490 */                 return true;
/*     */               } 
/* 492 */               return false;
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeIf(final Predicate<? super E> filter) {
/* 499 */       prepareModification();
/*     */       
/* 501 */       int s = this.size;
/* 502 */       this.namespaceElements.values().removeIf(new Predicate<List<E>>() {
/*     */             public boolean test(List<E> es) {
/* 504 */               return (NamespaceList.Builder.this.removeElementsIf(es, filter) == null);
/*     */             }
/*     */           });
/* 507 */       return (this.size < s);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeElementsOfNamespaceIf(String namespace, final Predicate<? super E> filter) {
/* 518 */       prepareModification();
/*     */       
/* 520 */       this.namespaceElements.computeIfPresent(namespace, new BiFunction<String, List<E>, List<E>>() {
/*     */             public List<E> apply(String n, List<E> es) {
/* 522 */               return NamespaceList.Builder.this.removeElementsIf(es, filter);
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*     */     private List<E> removeElementsIf(List<E> list, Predicate<? super E> filter) {
/* 528 */       int sizeBefore = list.size();
/* 529 */       list.removeIf(filter);
/* 530 */       this.size -= sizeBefore - list.size();
/* 531 */       return list.isEmpty() ? null : list;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NamespaceList<E> build() {
/* 548 */       if (this.size == 0) {
/* 549 */         return NamespaceList.empty(this.getNamespace);
/*     */       }
/* 551 */       if (this.lastBuildElements == null) {
/* 552 */         this.lastBuildElements = new ArrayList<>(this.size);
/* 553 */         for (List<E> es : this.namespaceElements.values()) {
/* 554 */           this.lastBuildElements.addAll(es);
/*     */         }
/* 556 */         this.lastBuildElements = Collections.unmodifiableList(this.lastBuildElements);
/*     */         
/* 558 */         final int[] start = new int[1];
/* 559 */         this.namespaceElements.replaceAll(new BiFunction<String, List<E>, List<E>>() {
/*     */               public List<E> apply(String n, List<E> es) {
/* 561 */                 int from = start[0];
/* 562 */                 int to = start[0] = start[0] + es.size();
/* 563 */                 return NamespaceList.Builder.this.lastBuildElements.subList(from, to);
/*     */               }
/*     */             });
/*     */       } 
/* 567 */       return new NamespaceList<>(this.getNamespace, this.namespaceElements, this.lastBuildElements);
/*     */     }
/*     */     
/*     */     private void prepareModification() {
/* 571 */       if (this.lastBuildElements != null) {
/*     */ 
/*     */         
/* 574 */         this.namespaceElements = new LinkedHashMap<>(this.namespaceElements);
/* 575 */         this.namespaceElements.replaceAll(new BiFunction<String, List<E>, List<E>>() {
/*     */               public List<E> apply(String n, List<E> es) {
/* 577 */                 return new ArrayList<>(es);
/*     */               }
/*     */             });
/* 580 */         this.lastBuildElements = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\NamespaceList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */