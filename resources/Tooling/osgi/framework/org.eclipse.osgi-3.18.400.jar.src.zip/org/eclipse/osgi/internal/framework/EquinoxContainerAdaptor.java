/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleCollisionHook;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleLoader;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.container.SystemModule;
/*     */ import org.eclipse.osgi.internal.container.AtomicLazyInitializer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.eclipse.osgi.internal.loader.FragmentLoader;
/*     */ import org.eclipse.osgi.internal.loader.SystemBundleLoader;
/*     */ import org.eclipse.osgi.internal.permadmin.BundlePermissions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.Storage;
/*     */ import org.osgi.framework.FrameworkListener;
/*     */ import org.osgi.framework.hooks.resolver.ResolverHookFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxContainerAdaptor
/*     */   extends ModuleContainerAdaptor
/*     */ {
/*     */   private final EquinoxContainer container;
/*     */   private final Storage storage;
/*     */   private final OSGiFrameworkHooks hooks;
/*     */   private final Map<Long, BundleInfo.Generation> initial;
/*     */   private final ClassLoader moduleClassLoaderParent;
/*     */   private final AtomicLong lastSecurityAdminFlush;
/*     */   final AtomicLazyInitializer<Executor> resolverExecutor;
/*     */   final Callable<Executor> lazyResolverExecutorCreator;
/*     */   final AtomicLazyInitializer<Executor> startLevelExecutor;
/*     */   final Callable<Executor> lazyStartLevelExecutorCreator;
/*     */   
/*     */   public EquinoxContainerAdaptor(EquinoxContainer container, Storage storage, Map<Long, BundleInfo.Generation> initial) {
/*     */     int resolverThreadCnt, startLevelThreadCnt;
/*  73 */     this.container = container;
/*  74 */     this.storage = storage;
/*  75 */     this.hooks = new OSGiFrameworkHooks(container, storage);
/*  76 */     this.initial = initial;
/*  77 */     this.moduleClassLoaderParent = getModuleClassLoaderParent(container.getConfiguration(), container.getBootLoader());
/*  78 */     this.lastSecurityAdminFlush = new AtomicLong();
/*     */     
/*  80 */     EquinoxConfiguration config = container.getConfiguration();
/*     */     
/*  82 */     String resolverThreadCntProp = config.getConfiguration("equinox.resolver.thread.count", 
/*  83 */         config.getConfiguration("equinox.resolver.thead.count"));
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  88 */       resolverThreadCnt = (resolverThreadCntProp == null) ? -1 : Integer.parseInt(resolverThreadCntProp);
/*  89 */     } catch (NumberFormatException numberFormatException) {
/*  90 */       resolverThreadCnt = -1;
/*     */     } 
/*  92 */     String startLevelThreadCntProp = config.getConfiguration("equinox.start.level.thread.count");
/*     */ 
/*     */     
/*     */     try {
/*  96 */       startLevelThreadCnt = (startLevelThreadCntProp == null) ? 1 : Integer.parseInt(startLevelThreadCntProp);
/*  97 */     } catch (NumberFormatException numberFormatException) {
/*  98 */       startLevelThreadCnt = 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.resolverExecutor = new AtomicLazyInitializer();
/* 111 */     this.lazyResolverExecutorCreator = createLazyExecutorCreator(
/* 112 */         "Equinox resolver thread - " + toString(), 
/* 113 */         resolverThreadCnt, new SynchronousQueue<>());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.startLevelExecutor = new AtomicLazyInitializer();
/* 119 */     this.lazyStartLevelExecutorCreator = createLazyExecutorCreator(
/* 120 */         "Equinox start level thread - " + toString(), 
/* 121 */         startLevelThreadCnt, new LinkedBlockingQueue<>(1000));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Callable<Executor> createLazyExecutorCreator(final String threadName, int threadCnt, final BlockingQueue<Runnable> queue) {
/* 127 */     final int maxThreads = (threadCnt <= 0) ? Runtime.getRuntime().availableProcessors() : threadCnt;
/* 128 */     return new Callable<Executor>()
/*     */       {
/*     */         public Executor call() throws Exception {
/* 131 */           if (maxThreads == 1)
/*     */           {
/* 133 */             return new Executor()
/*     */               {
/*     */                 public void execute(Runnable command) {
/* 136 */                   command.run();
/*     */                 }
/*     */               };
/*     */           }
/*     */           
/* 141 */           int coreThreads = maxThreads;
/*     */           
/* 143 */           int idleTimeout = 10;
/*     */           
/* 145 */           ThreadFactory threadFactory = new ThreadFactory()
/*     */             {
/*     */               public Thread newThread(Runnable r) {
/* 148 */                 Thread t = new Thread(r, threadName);
/* 149 */                 t.setDaemon(true);
/* 150 */                 return t;
/*     */               }
/*     */             };
/*     */           
/* 154 */           RejectedExecutionHandler rejectHandler = new ThreadPoolExecutor.CallerRunsPolicy();
/*     */           
/* 156 */           ThreadPoolExecutor executor = new ThreadPoolExecutor(coreThreads, maxThreads, idleTimeout, TimeUnit.SECONDS, queue, threadFactory, rejectHandler);
/* 157 */           executor.allowCoreThreadTimeOut(true);
/* 158 */           return executor;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClassLoader getModuleClassLoaderParent(EquinoxConfiguration configuration, ClassLoader bootLoader) {
/* 165 */     for (ClassLoaderHook hook : configuration.getHookRegistry().getClassLoaderHooks()) {
/* 166 */       ClassLoader parent = hook.getModuleClassLoaderParent(configuration);
/* 167 */       if (parent != null)
/*     */       {
/* 169 */         return parent;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 175 */     String type = configuration.getConfiguration("org.osgi.framework.bundle.parent");
/* 176 */     if (type == null) {
/* 177 */       type = configuration.getConfiguration("osgi.parentClassloader", "boot");
/*     */     }
/*     */     
/* 180 */     if ("framework".equalsIgnoreCase(type) || "fwk".equalsIgnoreCase(type)) {
/* 181 */       ClassLoader cl = EquinoxContainer.class.getClassLoader();
/* 182 */       return (cl == null) ? bootLoader : cl;
/*     */     } 
/* 184 */     if ("app".equalsIgnoreCase(type))
/* 185 */       return ClassLoader.getSystemClassLoader(); 
/* 186 */     if ("ext".equalsIgnoreCase(type)) {
/* 187 */       ClassLoader appCL = ClassLoader.getSystemClassLoader();
/* 188 */       if (appCL != null)
/* 189 */         return appCL.getParent(); 
/*     */     } 
/* 191 */     return bootLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleCollisionHook getModuleCollisionHook() {
/* 197 */     return this.hooks.getModuleCollisionHook();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolverHookFactory getResolverHookFactory() {
/* 202 */     return this.hooks.getResolverHookFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public void publishContainerEvent(ModuleContainerAdaptor.ContainerEvent type, Module module, Throwable error, FrameworkListener... listeners) {
/* 207 */     EquinoxEventPublisher publisher = this.container.getEventPublisher();
/* 208 */     if (publisher != null) {
/* 209 */       publisher.publishFrameworkEvent(getType(type), module.getBundle(), error, listeners);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void publishModuleEvent(ModuleContainerAdaptor.ModuleEvent type, Module module, Module origin) {
/* 215 */     EquinoxEventPublisher publisher = this.container.getEventPublisher();
/* 216 */     if (publisher != null) {
/* 217 */       publisher.publishBundleEvent(getType(type), module.getBundle(), origin.getBundle());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Module createModule(String location, long id, EnumSet<Module.Settings> settings, int startlevel) {
/* 223 */     EquinoxBundle bundle = new EquinoxBundle(Long.valueOf(id), location, this.storage.getModuleContainer(), settings, startlevel, this.container);
/* 224 */     return bundle.getModule();
/*     */   }
/*     */ 
/*     */   
/*     */   public SystemModule createSystemModule() {
/* 229 */     return (SystemModule)(new EquinoxBundle.SystemBundle(this.storage.getModuleContainer(), this.container)).getModule();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 234 */     return this.storage.getConfiguration().getConfiguration(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleLoader createModuleLoader(ModuleWiring wiring) {
/* 239 */     if (wiring.getBundle().getBundleId() == 0L) {
/* 240 */       ClassLoader cl = EquinoxContainer.class.getClassLoader();
/* 241 */       cl = (cl == null) ? this.container.getBootLoader() : cl;
/* 242 */       return (ModuleLoader)new SystemBundleLoader(wiring, this.container, cl);
/*     */     } 
/* 244 */     if ((wiring.getRevision().getTypes() & 0x1) != 0) {
/* 245 */       return (ModuleLoader)new FragmentLoader();
/*     */     }
/* 247 */     return (ModuleLoader)new BundleLoader(wiring, this.container, this.moduleClassLoaderParent);
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleInfo.Generation getRevisionInfo(String location, long id) {
/* 252 */     return this.initial.remove(Long.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   public void associateRevision(ModuleRevision revision, Object revisionInfo) {
/* 257 */     ((BundleInfo.Generation)revisionInfo).setRevision(revision);
/*     */   }
/*     */ 
/*     */   
/*     */   public void invalidateWiring(ModuleWiring moduleWiring, ModuleLoader current) {
/* 262 */     if (current instanceof BundleLoader) {
/* 263 */       BundleLoader bundleLoader = (BundleLoader)current;
/* 264 */       bundleLoader.close();
/*     */     } 
/* 266 */     long updatedTimestamp = this.storage.getModuleDatabase().getRevisionsTimestamp();
/* 267 */     if (System.getSecurityManager() != null && updatedTimestamp != this.lastSecurityAdminFlush.getAndSet(updatedTimestamp)) {
/* 268 */       this.storage.getSecurityAdmin().clearCaches();
/* 269 */       List<Module> modules = this.storage.getModuleContainer().getModules();
/* 270 */       for (Module module : modules) {
/* 271 */         for (ModuleRevision revision : module.getRevisions().getModuleRevisions()) {
/* 272 */           BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/* 273 */           if (generation != null) {
/* 274 */             ProtectionDomain domain = generation.getDomain(false);
/* 275 */             if (domain != null) {
/* 276 */               ((BundlePermissions)domain.getPermissions()).clearPermissionCache();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 282 */     clearManifestCache(moduleWiring);
/*     */   }
/*     */   
/*     */   private void clearManifestCache(ModuleWiring moduleWiring) {
/* 286 */     boolean frameworkActive = Module.ACTIVE_SET.contains(this.storage.getModuleContainer().getModule(0L).getState());
/* 287 */     ModuleRevision revision = moduleWiring.getRevision();
/* 288 */     Module module = revision.getRevisions().getModule();
/* 289 */     int i = Module.State.UNINSTALLED.equals(module.getState()) ^ module.holdsTransitionEventLock(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/* 290 */     if (!frameworkActive || i == 0) {
/*     */       
/* 292 */       BundleInfo.Generation generation = (BundleInfo.Generation)moduleWiring.getRevision().getRevisionInfo();
/* 293 */       generation.clearManifestCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   static int getType(ModuleContainerAdaptor.ContainerEvent type) {
/* 298 */     switch (type) {
/*     */       case null:
/* 300 */         return 2;
/*     */       case INFO:
/* 302 */         return 32;
/*     */       case WARNING:
/* 304 */         return 16;
/*     */       case REFRESH:
/* 306 */         return 4;
/*     */       case START_LEVEL:
/* 308 */         return 8;
/*     */       case STARTED:
/* 310 */         return 1;
/*     */       case STOPPED:
/* 312 */         return 64;
/*     */       case STOPPED_REFRESH:
/* 314 */         return 1024;
/*     */       case STOPPED_UPDATE:
/* 316 */         return 128;
/*     */       case STOPPED_TIMEOUT:
/* 318 */         return 512;
/*     */     } 
/*     */     
/* 321 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getType(ModuleContainerAdaptor.ModuleEvent type) {
/* 326 */     switch (type) {
/*     */       case null:
/* 328 */         return 1;
/*     */       case LAZY_ACTIVATION:
/* 330 */         return 512;
/*     */       case RESOLVED:
/* 332 */         return 32;
/*     */       case STARTED:
/* 334 */         return 2;
/*     */       case STARTING:
/* 336 */         return 128;
/*     */       case STOPPING:
/* 338 */         return 256;
/*     */       case STOPPED:
/* 340 */         return 4;
/*     */       case UNINSTALLED:
/* 342 */         return 16;
/*     */       case UNRESOLVED:
/* 344 */         return 64;
/*     */       case UPDATED:
/* 346 */         return 8;
/*     */     } 
/*     */     
/* 349 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshedSystemModule() {
/* 355 */     this.storage.getConfiguration().setConfiguration("osgi.forcedRestart", "true");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 360 */     return this.container.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatedDatabase() {
/* 365 */     StorageSaver saver = this.container.getStorageSaver();
/* 366 */     if (saver == null)
/*     */       return; 
/* 368 */     saver.save();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initBegin() {
/* 373 */     this.hooks.initBegin();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initEnd() {
/* 378 */     this.hooks.initEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   public DebugOptions getDebugOptions() {
/* 383 */     return this.container.getConfiguration().getDebugOptions();
/*     */   }
/*     */ 
/*     */   
/*     */   public Executor getResolverExecutor() {
/* 388 */     return (Executor)this.resolverExecutor.getInitialized(this.lazyResolverExecutorCreator);
/*     */   }
/*     */ 
/*     */   
/*     */   public Executor getStartLevelExecutor() {
/* 393 */     return (Executor)this.startLevelExecutor.getInitialized(this.lazyStartLevelExecutorCreator);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService getScheduledExecutor() {
/* 398 */     return this.container.getScheduledExecutor();
/*     */   }
/*     */   
/*     */   public void shutdownExecutors() {
/* 402 */     Executor current = (Executor)this.resolverExecutor.getAndClear();
/* 403 */     if (current instanceof ExecutorService) {
/* 404 */       ((ExecutorService)current).shutdown();
/*     */     }
/* 406 */     current = (Executor)this.startLevelExecutor.getAndClear();
/* 407 */     if (current instanceof ExecutorService) {
/* 408 */       ((ExecutorService)current).shutdown();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleRevisionBuilder adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent operation, Module origin, ModuleRevisionBuilder builder, Object revisionInfo) {
/* 414 */     BundleInfo.Generation generation = (BundleInfo.Generation)revisionInfo;
/* 415 */     return generation.adaptModuleRevisionBuilder(operation, origin, builder);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\EquinoxContainerAdaptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */