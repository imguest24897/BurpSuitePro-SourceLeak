/*     */ package org.eclipse.osgi.internal.hookregistry;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.internal.cds.CDSHookConfigurator;
/*     */ import org.eclipse.osgi.internal.connect.ConnectHookConfigurator;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hooks.DevClassLoadingHook;
/*     */ import org.eclipse.osgi.internal.hooks.EclipseLazyStarter;
/*     */ import org.eclipse.osgi.internal.signedcontent.SignedBundleHook;
/*     */ import org.eclipse.osgi.internal.weaving.WeavingHookConfigurator;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HookRegistry
/*     */ {
/*     */   public static final String HOOK_CONFIGURATORS_FILE = "hookconfigurators.properties";
/*     */   public static final String HOOK_CONFIGURATORS = "hook.configurators";
/*     */   public static final String PROP_HOOK_CONFIGURATORS_INCLUDE = "osgi.hook.configurators.include";
/*     */   public static final String PROP_HOOK_CONFIGURATORS_EXCLUDE = "osgi.hook.configurators.exclude";
/*     */   public static final String PROP_HOOK_CONFIGURATORS = "osgi.hook.configurators";
/*     */   private static final String BUILTIN_HOOKS = "builtin.hooks";
/*     */   private final EquinoxContainer container;
/*     */   private volatile boolean initialized = false;
/*  81 */   private final List<ClassLoaderHook> classLoaderHooks = new ArrayList<>();
/*  82 */   private final List<ClassLoaderHook> classLoaderHooksRO = Collections.unmodifiableList(this.classLoaderHooks);
/*  83 */   private final List<StorageHookFactory<?, ?, ?>> storageHookFactories = new ArrayList<>();
/*  84 */   private final List<StorageHookFactory<?, ?, ?>> storageHookFactoriesRO = Collections.unmodifiableList(this.storageHookFactories);
/*  85 */   private final List<BundleFileWrapperFactoryHook> bundleFileWrapperFactoryHooks = new ArrayList<>();
/*  86 */   private final List<BundleFileWrapperFactoryHook> bundleFileWrapperFactoryHooksRO = Collections.unmodifiableList(this.bundleFileWrapperFactoryHooks);
/*  87 */   private final List<ActivatorHookFactory> activatorHookFactories = new ArrayList<>();
/*  88 */   private final List<ActivatorHookFactory> activatorHookFactoriesRO = Collections.unmodifiableList(this.activatorHookFactories);
/*     */   
/*     */   public HookRegistry(EquinoxContainer container) {
/*  91 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/* 106 */     List<String> configurators = new ArrayList<>(5);
/* 107 */     List<FrameworkLogEntry> errors = new ArrayList<>(0);
/* 108 */     mergeFileHookConfigurators(configurators, errors);
/* 109 */     mergePropertyHookConfigurators(configurators);
/*     */     
/* 111 */     configurators.add(0, ConnectHookConfigurator.class.getName());
/* 112 */     synchronized (this) {
/* 113 */       addClassLoaderHook((ClassLoaderHook)new DevClassLoadingHook(this.container.getConfiguration()));
/* 114 */       addClassLoaderHook((ClassLoaderHook)new EclipseLazyStarter(this.container));
/* 115 */       addClassLoaderHook((ClassLoaderHook)new WeavingHookConfigurator(this.container));
/* 116 */       configurators.add(SignedBundleHook.class.getName());
/* 117 */       configurators.add(CDSHookConfigurator.class.getName());
/* 118 */       loadConfigurators(configurators, errors);
/*     */       
/* 120 */       this.initialized = true;
/*     */     } 
/* 122 */     for (FrameworkLogEntry error : errors)
/* 123 */       this.container.getLogServices().getFrameworkLog().log(error); 
/*     */   }
/*     */   
/*     */   private void mergeFileHookConfigurators(List<String> configuratorList, List<FrameworkLogEntry> errors) {
/*     */     Enumeration<URL> hookConfigurators;
/* 128 */     ClassLoader cl = getClass().getClassLoader();
/*     */ 
/*     */     
/*     */     try {
/* 132 */       hookConfigurators = (cl != null) ? cl.getResources("hookconfigurators.properties") : ClassLoader.getSystemResources("hookconfigurators.properties");
/* 133 */     } catch (IOException e) {
/* 134 */       errors.add(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, "getResources error on hookconfigurators.properties", 0, e, null));
/*     */       return;
/*     */     } 
/* 137 */     int curBuiltin = 0;
/* 138 */     while (hookConfigurators.hasMoreElements()) {
/* 139 */       URL url = hookConfigurators.nextElement();
/* 140 */       InputStream input = null;
/*     */ 
/*     */       
/* 143 */       try { Properties configuratorProps = new Properties();
/* 144 */         input = url.openStream();
/* 145 */         configuratorProps.load(input);
/* 146 */         String hooksValue = configuratorProps.getProperty("hook.configurators");
/* 147 */         if (hooksValue == null)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 164 */           if (input != null)
/*     */             try {
/* 166 */               input.close();
/* 167 */             } catch (IOException iOException) {}  continue; }  boolean builtin = Boolean.valueOf(configuratorProps.getProperty("builtin.hooks")).booleanValue(); String[] configurators = ManifestElement.getArrayFromList(hooksValue, ","); } catch (IOException e) { errors.add(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, "error loading: " + url.toExternalForm(), 0, e, null)); continue; } finally { if (input != null) try { input.close(); } catch (IOException iOException) {}  }  if (input != null) try { input.close(); } catch (IOException iOException) {}
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergePropertyHookConfigurators(List<String> configuratorList) {
/* 176 */     String[] configurators = ManifestElement.getArrayFromList(this.container.getConfiguration().getConfiguration("osgi.hook.configurators"), ",");
/* 177 */     if (configurators.length > 0) {
/* 178 */       configuratorList.clear(); byte b1; int k; String[] arrayOfString;
/* 179 */       for (k = (arrayOfString = configurators).length, b1 = 0; b1 < k; ) { String configurator = arrayOfString[b1];
/* 180 */         if (!configuratorList.contains(configurator)) {
/* 181 */           configuratorList.add(configurator);
/*     */         }
/*     */         b1++; }
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     String[] includeConfigurators = ManifestElement.getArrayFromList(this.container.getConfiguration().getConfiguration("osgi.hook.configurators.include"), ","); byte b; int i; String[] arrayOfString1;
/* 188 */     for (i = (arrayOfString1 = includeConfigurators).length, b = 0; b < i; ) { String includeConfigurator = arrayOfString1[b];
/* 189 */       if (!configuratorList.contains(includeConfigurator)) {
/* 190 */         configuratorList.add(includeConfigurator);
/*     */       }
/*     */       b++; }
/*     */     
/* 194 */     String[] excludeHooks = ManifestElement.getArrayFromList(this.container.getConfiguration().getConfiguration("osgi.hook.configurators.exclude"), ","); String[] arrayOfString2;
/* 195 */     for (int j = (arrayOfString2 = excludeHooks).length; i < j; ) { String excludeHook = arrayOfString2[i];
/* 196 */       configuratorList.remove(excludeHook);
/*     */       i++; }
/*     */   
/*     */   }
/*     */   private void loadConfigurators(List<String> configurators, List<FrameworkLogEntry> errors) {
/* 201 */     for (String hookName : configurators) {
/*     */       try {
/* 203 */         Class<?> clazz = Class.forName(hookName);
/* 204 */         HookConfigurator configurator = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 205 */         configurator.addHooks(this);
/* 206 */       } catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 212 */         errors.add(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, "error loading hook: " + hookName, 0, t, null));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClassLoaderHook> getClassLoaderHooks() {
/* 222 */     return this.classLoaderHooksRO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<StorageHookFactory<?, ?, ?>> getStorageHookFactories() {
/* 230 */     return this.storageHookFactoriesRO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BundleFileWrapperFactoryHook> getBundleFileWrapperFactoryHooks() {
/* 238 */     return this.bundleFileWrapperFactoryHooksRO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ActivatorHookFactory> getActivatorHookFactories() {
/* 246 */     return this.activatorHookFactoriesRO;
/*     */   }
/*     */   
/*     */   private <H> void add(H hook, List<H> hooks) {
/* 250 */     if (this.initialized)
/* 251 */       throw new IllegalStateException("Cannot add hooks dynamically."); 
/* 252 */     hooks.add(hook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addClassLoaderHook(ClassLoaderHook classLoaderHook) {
/* 260 */     add(classLoaderHook, this.classLoaderHooks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStorageHookFactory(StorageHookFactory<?, ?, ?> storageHookFactory) {
/* 268 */     add(storageHookFactory, this.storageHookFactories);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBundleFileWrapperFactoryHook(BundleFileWrapperFactoryHook factory) {
/* 276 */     add(factory, this.bundleFileWrapperFactoryHooks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addActivatorHookFactory(ActivatorHookFactory activatorHookFactory) {
/* 285 */     add(activatorHookFactory, this.activatorHookFactories);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquinoxConfiguration getConfiguration() {
/* 293 */     return this.container.getConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquinoxContainer getContainer() {
/* 301 */     return this.container;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hookregistry\HookRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */