/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.osgi.framework.ServiceObjects;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceObjectsImpl<S>
/*     */   implements ServiceObjects<S>
/*     */ {
/*     */   private final ServiceRegistrationImpl<S> registration;
/*     */   private final ServiceReference<S> reference;
/*     */   private final BundleContextImpl user;
/*     */   
/*     */   ServiceObjectsImpl(BundleContextImpl user, ServiceRegistrationImpl<S> registration) {
/*  39 */     this.registration = registration;
/*  40 */     this.reference = registration.getReference();
/*  41 */     this.user = user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public S getService() {
/*  91 */     this.user.checkValid();
/*  92 */     return this.registration.getService(this.user, ServiceConsumer.prototypeConsumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetService(S service) {
/* 134 */     this.user.checkValid();
/* 135 */     boolean removed = this.registration.ungetService(this.user, ServiceConsumer.prototypeConsumer, service);
/* 136 */     if (!removed) {
/* 137 */       if (this.registration.isUnregistered()) {
/*     */         return;
/*     */       }
/* 140 */       throw new IllegalArgumentException(Msg.SERVICE_OBJECTS_UNGET_ARGUMENT_EXCEPTION);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<S> getServiceReference() {
/* 153 */     return this.reference;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceObjectsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */