package org.eclipse.osgi.internal.provisional.service.security;

public class AuthorizationStatus {
  public static final int OK = 0;
  
  public static final int ERROR = 1;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\service\security\AuthorizationStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */