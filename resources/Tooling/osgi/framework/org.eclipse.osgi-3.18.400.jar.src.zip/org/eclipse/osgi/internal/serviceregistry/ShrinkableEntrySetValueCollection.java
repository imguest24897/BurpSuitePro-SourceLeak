/*    */ package org.eclipse.osgi.internal.serviceregistry;
/*    */ 
/*    */ import java.util.AbstractCollection;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShrinkableEntrySetValueCollection<E>
/*    */   extends AbstractCollection<E>
/*    */   implements Collection<E>
/*    */ {
/*    */   private final Set<? extends Map.Entry<?, ? extends E>> entrySet;
/*    */   
/*    */   public ShrinkableEntrySetValueCollection(Set<? extends Map.Entry<?, ? extends E>> e) {
/* 23 */     if (e == null) {
/* 24 */       throw new NullPointerException();
/*    */     }
/* 26 */     this.entrySet = e;
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 31 */     this.entrySet.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 36 */     return this.entrySet.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<E> iterator() {
/* 41 */     return new ValueIterator<>(this.entrySet.iterator());
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 46 */     return this.entrySet.size();
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class ValueIterator<E>
/*    */     implements Iterator<E>
/*    */   {
/*    */     private final Iterator<? extends Map.Entry<?, ? extends E>> iter;
/*    */     
/*    */     ValueIterator(Iterator<? extends Map.Entry<?, ? extends E>> i) {
/* 56 */       this.iter = i;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean hasNext() {
/* 61 */       return this.iter.hasNext();
/*    */     }
/*    */ 
/*    */     
/*    */     public E next() {
/* 66 */       Map.Entry<?, ? extends E> entry = this.iter.next();
/* 67 */       return entry.getValue();
/*    */     }
/*    */ 
/*    */     
/*    */     public void remove() {
/* 72 */       this.iter.remove();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ShrinkableEntrySetValueCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */