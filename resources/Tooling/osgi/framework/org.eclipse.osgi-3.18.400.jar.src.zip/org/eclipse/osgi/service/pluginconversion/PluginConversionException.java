/*    */ package org.eclipse.osgi.service.pluginconversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginConversionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3258130258472284472L;
/*    */   private transient Throwable cause;
/*    */   
/*    */   public PluginConversionException() {}
/*    */   
/*    */   public PluginConversionException(String message) {
/* 42 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PluginConversionException(String message, Throwable cause) {
/* 52 */     super(message);
/* 53 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PluginConversionException(Throwable cause) {
/* 62 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable getCause() {
/* 73 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\pluginconversion\PluginConversionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */