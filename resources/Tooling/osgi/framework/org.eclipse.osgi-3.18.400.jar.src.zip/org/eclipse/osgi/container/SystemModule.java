/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.service.resolver.ResolutionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SystemModule
/*     */   extends Module
/*     */ {
/*  38 */   private volatile AtomicReference<ModuleContainerAdaptor.ContainerEvent> forStop = new AtomicReference<>();
/*     */   
/*     */   public SystemModule(ModuleContainer container) {
/*  41 */     super(Long.valueOf(0L), "System Bundle", container, EnumSet.of(Module.Settings.AUTO_START, Module.Settings.USE_ACTIVATION_POLICY), Integer.valueOf(0).intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void init() throws BundleException {
/*  49 */     getRevisions().getContainer().checkAdminPermission(getBundle(), "execute");
/*     */     
/*  51 */     boolean lockedStarted = false;
/*     */ 
/*     */     
/*  54 */     this.inStart.incrementAndGet();
/*     */     
/*  56 */     try { lockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*  57 */       lockedStarted = true;
/*  58 */       getContainer().getAdaptor().initBegin();
/*  59 */       checkValid();
/*  60 */       if (ACTIVE_SET.contains(getState()))
/*     */         return; 
/*  62 */       getRevisions().getContainer().open();
/*  63 */       if (getState().equals(Module.State.INSTALLED)) {
/*     */         ResolutionReport report;
/*     */         
/*  66 */         unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*  67 */         lockedStarted = false;
/*     */         
/*     */         try {
/*  70 */           report = getRevisions().getContainer().resolve(Collections.singletonList(this), true);
/*     */         } finally {
/*  72 */           lockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*  73 */           lockedStarted = true;
/*     */         } 
/*     */         
/*  76 */         checkValid();
/*  77 */         ResolutionException e = report.getResolutionException();
/*  78 */         if (e != null && 
/*  79 */           e.getCause() instanceof BundleException) {
/*  80 */           throw (BundleException)e.getCause();
/*     */         }
/*     */         
/*  83 */         if (ACTIVE_SET.contains(getState()))
/*     */           return; 
/*  85 */         if (getState().equals(Module.State.INSTALLED)) {
/*  86 */           String reportMessage = report.getResolutionReportMessage((Resource)getCurrentRevision());
/*  87 */           throw new BundleException(String.valueOf(Msg.Module_ResolveError) + reportMessage, 4);
/*     */         } 
/*     */       } 
/*     */       
/*  91 */       setState(Module.State.STARTING);
/*  92 */       AtomicReference<ModuleContainerAdaptor.ContainerEvent> existingForStop = this.forStop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       getContainer().getAdaptor().initEnd();
/* 113 */       if (lockedStarted) {
/* 114 */         unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*     */       }
/* 116 */       this.inStart.decrementAndGet(); }  getContainer().getAdaptor().initEnd(); if (lockedStarted) unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);  this.inStart.decrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleContainerAdaptor.ContainerEvent waitForStop(long timeout) throws InterruptedException {
/* 129 */     boolean waitForever = (timeout == 0L);
/* 130 */     long start = System.currentTimeMillis();
/* 131 */     long timeLeft = timeout;
/* 132 */     AtomicReference<ModuleContainerAdaptor.ContainerEvent> stopEvent = null;
/* 133 */     Module.State currentState = null;
/* 134 */     boolean stateLocked = false;
/*     */     try {
/* 136 */       if (timeout == 0L) {
/* 137 */         this.stateChangeLock.lockInterruptibly();
/* 138 */         stateLocked = true;
/*     */       } else {
/* 140 */         stateLocked = this.stateChangeLock.tryLock(timeLeft, TimeUnit.MILLISECONDS);
/*     */       } 
/* 142 */       if (stateLocked) {
/* 143 */         stopEvent = this.forStop;
/* 144 */         currentState = getState();
/*     */       } 
/*     */     } finally {
/* 147 */       if (stateLocked) {
/* 148 */         this.stateChangeLock.unlock();
/*     */       }
/*     */     } 
/*     */     
/* 152 */     if (stopEvent == null || currentState == null)
/*     */     {
/* 154 */       return ModuleContainerAdaptor.ContainerEvent.STOPPED_TIMEOUT;
/*     */     }
/* 156 */     if (!ACTIVE_SET.contains(currentState)) {
/*     */       
/* 158 */       ModuleContainerAdaptor.ContainerEvent result = stopEvent.get();
/* 159 */       if (result != null) {
/* 160 */         return result;
/*     */       }
/*     */       
/* 163 */       return ModuleContainerAdaptor.ContainerEvent.STOPPED;
/*     */     } 
/* 165 */     synchronized (stopEvent) {
/*     */       while (true) {
/* 167 */         ModuleContainerAdaptor.ContainerEvent result = stopEvent.get();
/* 168 */         if (result != null) {
/* 169 */           return result;
/*     */         }
/* 171 */         timeLeft = waitForever ? 0L : (start + timeout - System.currentTimeMillis());
/* 172 */         if (waitForever || timeLeft > 0L) {
/* 173 */           stopEvent.wait(timeLeft); continue;
/*     */         }  break;
/* 175 */       }  return ModuleContainerAdaptor.ContainerEvent.STOPPED_TIMEOUT;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initWorker() throws BundleException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(Module.StartOptions... options) throws BundleException {
/* 191 */     init();
/*     */     
/* 193 */     super.start(new Module.StartOptions[] { Module.StartOptions.TRANSIENT, Module.StartOptions.USE_ACTIVATION_POLICY });
/* 194 */     (getRevisions().getContainer()).adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.STARTED, this, null, new org.osgi.framework.FrameworkListener[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(Module.StopOptions... options) throws BundleException {
/* 199 */     ModuleContainerAdaptor.ContainerEvent containerEvent = ModuleContainerAdaptor.ContainerEvent.STOPPED_TIMEOUT;
/*     */ 
/*     */     
/*     */     try {
/* 203 */       if (this.stateChangeLock.tryLock(10L, TimeUnit.SECONDS)) {
/*     */         AtomicReference<ModuleContainerAdaptor.ContainerEvent> eventReference;
/*     */         try {
/*     */           try {
/* 207 */             super.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/* 208 */           } catch (BundleException e) {
/* 209 */             (getRevisions().getContainer()).adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, this, (Throwable)e, new org.osgi.framework.FrameworkListener[0]);
/*     */           } 
/*     */           
/* 212 */           if (holdsTransitionEventLock(ModuleContainerAdaptor.ModuleEvent.UPDATED)) {
/* 213 */             containerEvent = ModuleContainerAdaptor.ContainerEvent.STOPPED_UPDATE;
/* 214 */           } else if (holdsTransitionEventLock(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED)) {
/* 215 */             containerEvent = ModuleContainerAdaptor.ContainerEvent.STOPPED_REFRESH;
/*     */           } else {
/* 217 */             containerEvent = ModuleContainerAdaptor.ContainerEvent.STOPPED;
/*     */           } 
/* 219 */           (getRevisions().getContainer()).adaptor.publishContainerEvent(containerEvent, this, null, new org.osgi.framework.FrameworkListener[0]);
/* 220 */           getRevisions().getContainer().close();
/*     */         } finally {
/* 222 */           AtomicReference<ModuleContainerAdaptor.ContainerEvent> atomicReference = this.forStop;
/* 223 */           atomicReference.compareAndSet(null, containerEvent);
/* 224 */           this.stateChangeLock.unlock();
/* 225 */           synchronized (atomicReference) {
/* 226 */             atomicReference.notifyAll();
/*     */           } 
/*     */         } 
/*     */       } else {
/* 230 */         throw new BundleException(Msg.SystemModule_LockError);
/*     */       } 
/* 232 */     } catch (InterruptedException e) {
/* 233 */       (getRevisions().getContainer()).adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, this, e, new org.osgi.framework.FrameworkListener[0]);
/* 234 */       throw new BundleException(String.valueOf(Msg.Module_LockError) + toString(), 7, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() throws BundleException {
/*     */     Module.State previousState;
/* 245 */     getContainer().checkAdminPermission(getBundle(), "lifecycle");
/*     */     
/* 247 */     lockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*     */     try {
/* 249 */       previousState = getState();
/* 250 */       stop(new Module.StopOptions[0]);
/*     */     } finally {
/* 252 */       unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*     */     } 
/*     */     
/* 255 */     switch (previousState) {
/*     */       case STARTING:
/* 257 */         init();
/*     */         break;
/*     */       case null:
/* 260 */         start(new Module.StartOptions[0]);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startWorker() throws BundleException {
/* 268 */     super.startWorker();
/* 269 */     ((ModuleContainer.ContainerStartLevel)getRevisions().getContainer().getFrameworkStartLevel()).doContainerStartLevel(this, -2147483648, new org.osgi.framework.FrameworkListener[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stopWorker() throws BundleException {
/* 274 */     super.stopWorker();
/* 275 */     ((ModuleContainer.ContainerStartLevel)getRevisions().getContainer().getFrameworkStartLevel()).doContainerStartLevel(this, 0, new org.osgi.framework.FrameworkListener[0]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\SystemModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */