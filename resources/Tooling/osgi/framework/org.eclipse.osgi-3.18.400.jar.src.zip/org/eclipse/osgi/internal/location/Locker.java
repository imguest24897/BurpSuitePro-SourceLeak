/*    */ package org.eclipse.osgi.internal.location;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Locker
/*    */ {
/*    */   boolean lock() throws IOException;
/*    */   
/*    */   boolean isLocked() throws IOException;
/*    */   
/*    */   void release();
/*    */   
/*    */   public static class MockLocker
/*    */     implements Locker
/*    */   {
/*    */     public boolean lock() throws IOException {
/* 35 */       return true;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean isLocked() {
/* 41 */       return false;
/*    */     }
/*    */     
/*    */     public void release() {}
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\Locker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */