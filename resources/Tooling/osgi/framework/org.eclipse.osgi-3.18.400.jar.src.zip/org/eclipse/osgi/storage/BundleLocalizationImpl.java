/*    */ package org.eclipse.osgi.storage;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ import org.eclipse.osgi.container.Module;
/*    */ import org.eclipse.osgi.container.ModuleRevision;
/*    */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*    */ import org.eclipse.osgi.service.localization.BundleLocalization;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleLocalizationImpl
/*    */   implements BundleLocalization
/*    */ {
/*    */   public ResourceBundle getLocalization(Bundle bundle, String locale) {
/* 41 */     Module m = ((EquinoxBundle)bundle).getModule();
/* 42 */     ModuleRevision r = m.getCurrentRevision();
/* 43 */     BundleInfo.Generation g = (BundleInfo.Generation)r.getRevisionInfo();
/* 44 */     return g.getResourceBundle(locale);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\BundleLocalizationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */