/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.resource.Wire;
/*     */ import org.osgi.service.resolver.ResolutionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ModuleResolutionReport
/*     */   implements ResolutionReport
/*     */ {
/*     */   private final Map<Resource, List<ResolutionReport.Entry>> entries;
/*     */   private final ResolutionException resolutionException;
/*     */   private final Map<Resource, List<Wire>> resolutionResult;
/*     */   
/*     */   static class Builder
/*     */   {
/*  46 */     private final Map<Resource, List<ResolutionReport.Entry>> resourceToEntries = new HashMap<>();
/*     */     
/*     */     public void addEntry(Resource resource, ResolutionReport.Entry.Type type, Object data) {
/*  49 */       List<ResolutionReport.Entry> entries = this.resourceToEntries.get(resource);
/*  50 */       if (entries == null) {
/*  51 */         entries = new ArrayList<>();
/*  52 */         this.resourceToEntries.put(resource, entries);
/*     */       } 
/*  54 */       entries.add(new ModuleResolutionReport.EntryImpl(type, data));
/*     */     }
/*     */     
/*     */     public ModuleResolutionReport build(Map<Resource, List<Wire>> resolutionResult, ResolutionException cause) {
/*  58 */       return new ModuleResolutionReport(resolutionResult, this.resourceToEntries, cause);
/*     */     }
/*     */   }
/*     */   
/*     */   static class EntryImpl implements ResolutionReport.Entry {
/*     */     private final Object data;
/*     */     private final ResolutionReport.Entry.Type type;
/*     */     
/*     */     EntryImpl(ResolutionReport.Entry.Type type, Object data) {
/*  67 */       this.type = type;
/*  68 */       this.data = data;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getData() {
/*  73 */       return this.data;
/*     */     }
/*     */ 
/*     */     
/*     */     public ResolutionReport.Entry.Type getType() {
/*  78 */       return this.type;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleResolutionReport(Map<Resource, List<Wire>> resolutionResult, Map<Resource, List<ResolutionReport.Entry>> entries, ResolutionException cause) {
/*  87 */     this.entries = (entries == null) ? Collections.<Resource, List<ResolutionReport.Entry>>emptyMap() : Collections.<Resource, List<ResolutionReport.Entry>>unmodifiableMap(new HashMap<>(entries));
/*  88 */     this.resolutionResult = (resolutionResult == null) ? Collections.<Resource, List<Wire>>emptyMap() : Collections.<Resource, List<Wire>>unmodifiableMap(resolutionResult);
/*  89 */     this.resolutionException = cause;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Resource, List<ResolutionReport.Entry>> getEntries() {
/*  94 */     return this.entries;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolutionException getResolutionException() {
/*  99 */     return this.resolutionException;
/*     */   }
/*     */   
/*     */   Map<Resource, List<Wire>> getResolutionResult() {
/* 103 */     return this.resolutionResult;
/*     */   }
/*     */   
/*     */   private static String getResolutionReport0(String prepend, ModuleRevision revision, Map<Resource, List<ResolutionReport.Entry>> reportEntries, Set<BundleRevision> visited) {
/* 107 */     if (prepend == null) {
/* 108 */       prepend = "";
/*     */     }
/* 110 */     if (visited == null) {
/* 111 */       visited = new HashSet<>();
/*     */     }
/* 113 */     if (visited.contains(revision)) {
/* 114 */       return "";
/*     */     }
/* 116 */     visited.add(revision);
/* 117 */     StringBuilder result = new StringBuilder();
/* 118 */     String id = revision.getRevisions().getModule().getId().toString();
/* 119 */     result.append(prepend).append(revision.getSymbolicName()).append(" [").append(id).append("]").append('\n');
/*     */     
/* 121 */     List<ResolutionReport.Entry> revisionEntries = reportEntries.get(revision);
/* 122 */     if (revisionEntries == null) {
/* 123 */       result.append(prepend).append("  ").append(Msg.ModuleResolutionReport_NoReport);
/*     */     } else {
/* 125 */       for (ResolutionReport.Entry entry : revisionEntries) {
/* 126 */         printResolutionEntry(result, String.valueOf(prepend) + "  ", entry, reportEntries, visited);
/*     */       }
/*     */     } 
/* 129 */     return result.toString();
/*     */   }
/*     */   private static void printResolutionEntry(StringBuilder result, String prepend, ResolutionReport.Entry entry, Map<Resource, List<ResolutionReport.Entry>> reportEntries, Set<BundleRevision> visited) {
/*     */     Map<Requirement, Set<Capability>> unresolvedProviders;
/* 133 */     switch (entry.getType()) {
/*     */       case MISSING_CAPABILITY:
/* 135 */         result.append(prepend).append(Msg.ModuleResolutionReport_UnresolvedReq).append(printRequirement(entry.getData())).append('\n');
/*     */         return;
/*     */       case SINGLETON_SELECTION:
/* 138 */         result.append(prepend).append(Msg.ModuleResolutionReport_AnotherSingleton).append(entry.getData()).append('\n');
/*     */         return;
/*     */       
/*     */       case UNRESOLVED_PROVIDER:
/* 142 */         unresolvedProviders = (Map<Requirement, Set<Capability>>)entry.getData();
/* 143 */         for (Map.Entry<Requirement, Set<Capability>> unresolvedRequirement : unresolvedProviders.entrySet()) {
/*     */           
/* 145 */           Set<Capability> unresolvedCapabilities = unresolvedRequirement.getValue();
/* 146 */           if (!unresolvedCapabilities.isEmpty()) {
/* 147 */             Capability unresolvedCapability = unresolvedCapabilities.iterator().next();
/*     */             
/* 149 */             if (!((Requirement)unresolvedRequirement.getKey()).getResource().equals(unresolvedCapability.getResource())) {
/* 150 */               result.append(prepend).append(Msg.ModuleResolutionReport_UnresolvedReq).append(printRequirement(unresolvedRequirement.getKey())).append('\n');
/* 151 */               result.append(prepend).append("  -> ").append(printCapability(unresolvedCapability)).append('\n');
/* 152 */               result.append(getResolutionReport0(String.valueOf(prepend) + "     ", (ModuleRevision)unresolvedCapability.getResource(), reportEntries, visited));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       case null:
/* 158 */         result.append(Msg.ModuleResolutionReport_FilteredByHook).append('\n');
/*     */         return;
/*     */       case USES_CONSTRAINT_VIOLATION:
/* 161 */         result.append(prepend).append(Msg.ModuleResolutionReport_UsesConstraintError).append('\n');
/* 162 */         result.append("  ").append(entry.getData());
/*     */         return;
/*     */     } 
/* 165 */     result.append(Msg.ModuleResolutionReport_Unknown).append("type=").append(entry.getType()).append(" data=").append(entry.getData()).append('\n');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object printCapability(Capability cap) {
/* 171 */     if ("osgi.wiring.package".equals(cap.getNamespace()))
/* 172 */       return "Export-Package: " + createOSGiCapability(cap); 
/* 173 */     if ("osgi.wiring.bundle".equals(cap.getNamespace()))
/* 174 */       return "Bundle-SymbolicName: " + createOSGiCapability(cap); 
/* 175 */     if ("osgi.wiring.host".equals(cap.getNamespace())) {
/* 176 */       return "Bundle-SymbolicName: " + createOSGiCapability(cap);
/*     */     }
/* 178 */     return "Provide-Capability: " + cap.toString();
/*     */   }
/*     */   
/*     */   private static String createOSGiCapability(Capability cap) {
/* 182 */     Map<String, Object> attributes = new HashMap<>(cap.getAttributes());
/* 183 */     Map<String, String> directives = cap.getDirectives();
/* 184 */     String name = String.valueOf(attributes.remove(cap.getNamespace()));
/* 185 */     return String.valueOf(name) + ModuleRevision.<Object>toString(attributes, false, true) + ModuleRevision.<String>toString(directives, true, true);
/*     */   }
/*     */   
/*     */   private static String printRequirement(Object data) {
/* 189 */     if (!(data instanceof Requirement)) {
/* 190 */       return String.valueOf(data);
/*     */     }
/* 192 */     Requirement req = (Requirement)data;
/* 193 */     if ("osgi.wiring.package".equals(req.getNamespace()))
/* 194 */       return "Import-Package: " + createOSGiRequirement(req, new String[] { "version", "bundle-version" }); 
/* 195 */     if ("osgi.wiring.bundle".equals(req.getNamespace()))
/* 196 */       return "Require-Bundle: " + createOSGiRequirement(req, new String[] { "bundle-version" }); 
/* 197 */     if ("osgi.wiring.host".equals(req.getNamespace())) {
/* 198 */       return "Fragment-Host: " + createOSGiRequirement(req, new String[] { "bundle-version" });
/*     */     }
/* 200 */     return "Require-Capability: " + req.toString();
/*     */   }
/*     */   private static String createOSGiRequirement(Requirement requirement, String... versions) {
/*     */     FilterImpl filterImpl;
/* 204 */     Map<String, String> directives = new HashMap<>(requirement.getDirectives());
/* 205 */     String filter = directives.remove("filter");
/* 206 */     if (filter == null) {
/* 207 */       throw new IllegalArgumentException("No filter directive found:" + requirement);
/*     */     }
/*     */     try {
/* 210 */       filterImpl = FilterImpl.newInstance(filter);
/* 211 */     } catch (InvalidSyntaxException e) {
/* 212 */       throw new IllegalArgumentException("Invalid filter directive", e);
/*     */     } 
/* 214 */     Map<String, String> matchingAttributes = filterImpl.getStandardOSGiAttributes(versions);
/* 215 */     String name = matchingAttributes.remove(requirement.getNamespace());
/* 216 */     if (name == null)
/* 217 */       throw new IllegalArgumentException("Invalid requirement: " + requirement); 
/* 218 */     return String.valueOf(name) + ModuleRevision.<String>toString(matchingAttributes, false, true) + ModuleRevision.<String>toString(directives, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getResolutionReportMessage(Resource resource) {
/* 223 */     return getResolutionReport0(null, (ModuleRevision)resource, getEntries(), null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleResolutionReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */