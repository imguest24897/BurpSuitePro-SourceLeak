/*     */ package org.eclipse.osgi.internal.loader;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AllPermission;
/*     */ import java.security.CodeSource;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathEntry;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*     */ import org.eclipse.osgi.signedcontent.SignedContent;
/*     */ import org.eclipse.osgi.signedcontent.SignerInfo;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModuleClassLoader
/*     */   extends ClassLoader
/*     */   implements BundleReference
/*     */ {
/*     */   protected static final PermissionCollection ALLPERMISSIONS;
/*     */   protected static final boolean REGISTERED_AS_PARALLEL;
/*     */   
/*     */   public static class GenerationProtectionDomain
/*     */     extends ProtectionDomain
/*     */     implements BundleReference
/*     */   {
/*     */     private final BundleInfo.Generation generation;
/*     */     
/*     */     public GenerationProtectionDomain(CodeSource codesource, PermissionCollection permissions, BundleInfo.Generation generation) {
/*  48 */       super(codesource, permissions);
/*  49 */       this.generation = generation;
/*     */     }
/*     */ 
/*     */     
/*     */     public Bundle getBundle() {
/*  54 */       return this.generation.getRevision().getBundle();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     boolean registered;
/*     */     try {
/*  66 */       registered = ClassLoader.registerAsParallelCapable();
/*  67 */     } catch (Throwable throwable) {
/*  68 */       registered = false;
/*     */     } 
/*  70 */     REGISTERED_AS_PARALLEL = registered;
/*     */ 
/*     */ 
/*     */     
/*  74 */     AllPermission allPerm = new AllPermission();
/*  75 */     ALLPERMISSIONS = allPerm.newPermissionCollection();
/*  76 */     if (ALLPERMISSIONS != null) {
/*  77 */       ALLPERMISSIONS.add(allPerm);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DefineClassResult
/*     */   {
/*     */     public final Class<?> clazz;
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean defined;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefineClassResult(Class<?> clazz, boolean defined) {
/*  97 */       this.clazz = clazz;
/*  98 */       this.defined = defined;
/*     */     }
/*     */   }
/*     */   
/* 102 */   private final Map<String, Thread> classNameLocks = new HashMap<>(5);
/* 103 */   private final Object pkgLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleClassLoader(ClassLoader parent) {
/* 110 */     super(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract BundleInfo.Generation getGeneration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Debug getDebug();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ClasspathManager getClasspathManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract EquinoxConfiguration getConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BundleLoader getBundleLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isRegisteredAsParallel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 168 */     Class<?> clazz = getBundleLoader().findClass(name);
/*     */     
/* 170 */     if (resolve) {
/* 171 */       resolveClass(clazz);
/*     */     }
/* 173 */     return clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> findClass(String moduleName, String name) {
/*     */     try {
/* 179 */       return findLocalClass(name);
/* 180 */     } catch (ClassNotFoundException classNotFoundException) {
/* 181 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> findClass(String name) throws ClassNotFoundException {
/* 187 */     return findLocalClass(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/* 201 */     if ((getDebug()).DEBUG_LOADER) {
/* 202 */       Debug.println("ModuleClassLoader[" + getBundleLoader() + "].getResource(" + name + ")");
/*     */     }
/*     */     
/* 205 */     URL url = getBundleLoader().findResource(name);
/* 206 */     if (url != null) {
/* 207 */       return url;
/*     */     }
/* 209 */     if ((getDebug()).DEBUG_LOADER) {
/* 210 */       Debug.println("ModuleClassLoader[" + getBundleLoader() + "].getResource(" + name + ") failed.");
/*     */     }
/*     */     
/* 213 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL findResource(String moduleName, String name) {
/* 218 */     return findLocalResource(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL findResource(String name) {
/* 223 */     return findLocalResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException {
/* 237 */     if ((getDebug()).DEBUG_LOADER) {
/* 238 */       Debug.println("ModuleClassLoader[" + getBundleLoader() + "].getResources(" + name + ")");
/*     */     }
/* 240 */     Enumeration<URL> result = getBundleLoader().findResources(name);
/* 241 */     if ((getDebug()).DEBUG_LOADER && (
/* 242 */       result == null || !result.hasMoreElements())) {
/* 243 */       Debug.println("ModuleClassLoader[" + getBundleLoader() + "].getResources(" + name + ") failed.");
/*     */     }
/*     */     
/* 246 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Enumeration<URL> findResources(String name) throws IOException {
/* 251 */     return findLocalResources(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String findLibrary(String libname) {
/* 263 */     return getClasspathManager().findLibrary(libname);
/*     */   }
/*     */   
/*     */   public ClasspathEntry createClassPathEntry(BundleFile bundlefile, BundleInfo.Generation entryGeneration) {
/* 267 */     return new ClasspathEntry(bundlefile, createProtectionDomain(bundlefile, entryGeneration), entryGeneration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefineClassResult defineClass(String name, byte[] classbytes, ClasspathEntry classpathEntry) {
/* 275 */     boolean defined = false;
/* 276 */     Class<?> result = null;
/* 277 */     if (isRegisteredAsParallel()) {
/*     */       
/* 279 */       boolean initialLock = lockClassName(name);
/*     */       try {
/* 281 */         result = findLoadedClass(name);
/* 282 */         if (result == null) {
/* 283 */           result = defineClass(name, classbytes, 0, classbytes.length, classpathEntry.getDomain());
/* 284 */           defined = true;
/*     */         } 
/*     */       } finally {
/* 287 */         if (initialLock) {
/* 288 */           unlockClassName(name);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 293 */       synchronized (this) {
/* 294 */         result = findLoadedClass(name);
/* 295 */         if (result == null) {
/* 296 */           result = defineClass(name, classbytes, 0, classbytes.length, classpathEntry.getDomain());
/* 297 */           defined = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 301 */     return new DefineClassResult(result, defined);
/*     */   }
/*     */   
/*     */   public Class<?> publicFindLoaded(String classname) {
/* 305 */     if (isRegisteredAsParallel()) {
/* 306 */       return findLoadedClass(classname);
/*     */     }
/* 308 */     synchronized (this) {
/* 309 */       return findLoadedClass(classname);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Package publicGetPackage(String pkgname) {
/* 314 */     synchronized (this.pkgLock) {
/* 315 */       return getPackage(pkgname);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Package publicDefinePackage(String name, String specTitle, String specVersion, String specVendor, String implTitle, String implVersion, String implVendor, URL sealBase) {
/* 320 */     synchronized (this.pkgLock) {
/* 321 */       Package pkg = getPackage(name);
/* 322 */       return (pkg != null) ? pkg : definePackage(name, specTitle, specVersion, specVendor, implTitle, implVersion, implVendor, sealBase);
/*     */     } 
/*     */   }
/*     */   
/*     */   public URL findLocalResource(String resource) {
/* 327 */     return getClasspathManager().findLocalResource(resource);
/*     */   }
/*     */   
/*     */   public Enumeration<URL> findLocalResources(String resource) {
/* 331 */     return getClasspathManager().findLocalResources(resource);
/*     */   }
/*     */   
/*     */   public Class<?> findLocalClass(String classname) throws ClassNotFoundException {
/* 335 */     return getClasspathManager().findLocalClass(classname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProtectionDomain createProtectionDomain(BundleFile bundlefile, BundleInfo.Generation domainGeneration) {
/* 347 */     ProtectionDomain baseDomain = domainGeneration.getDomain();
/*     */     
/*     */     try {
/*     */       PermissionCollection permissions;
/* 351 */       if (baseDomain != null) {
/* 352 */         permissions = baseDomain.getPermissions();
/*     */       }
/*     */       else {
/*     */         
/* 356 */         permissions = ALLPERMISSIONS;
/*     */       } 
/* 358 */       Certificate[] certs = null;
/* 359 */       if ((getConfiguration()).CLASS_CERTIFICATE) {
/* 360 */         Bundle b = getBundle();
/* 361 */         SignedContent signedContent = (b == null) ? null : (SignedContent)b.adapt(SignedContent.class);
/* 362 */         if (signedContent != null && signedContent.isSigned()) {
/* 363 */           SignerInfo[] signers = signedContent.getSignerInfos();
/* 364 */           if (signers.length > 0) {
/* 365 */             certs = signers[0].getCertificateChain();
/*     */           }
/*     */         } 
/*     */       } 
/* 369 */       File file = bundlefile.getBaseFile();
/*     */       
/* 371 */       return new GenerationProtectionDomain((file == null) ? null : new CodeSource(file.toURL(), certs), permissions, getGeneration());
/*     */     }
/* 373 */     catch (MalformedURLException malformedURLException) {
/*     */       
/* 375 */       return baseDomain;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/* 381 */     return getGeneration().getRevision().getBundle();
/*     */   }
/*     */   
/*     */   public List<URL> findEntries(String path, String filePattern, int options) {
/* 385 */     return getClasspathManager().findEntries(path, filePattern, options);
/*     */   }
/*     */   
/*     */   public Collection<String> listResources(String path, String filePattern, int options) {
/* 389 */     return getBundleLoader().listResources(path, filePattern, options);
/*     */   }
/*     */   
/*     */   public Collection<String> listLocalResources(String path, String filePattern, int options) {
/* 393 */     return getClasspathManager().listLocalResources(path, filePattern, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 398 */     Bundle b = getBundle();
/* 399 */     StringBuilder result = new StringBuilder(super.toString());
/* 400 */     if (b == null)
/* 401 */       return result.toString(); 
/* 402 */     return result.append('[').append(b.getSymbolicName()).append(':').append(b.getVersion()).append("(id=").append(b.getBundleId()).append(")]").toString();
/*     */   }
/*     */   
/*     */   public void loadFragments(Collection<ModuleRevision> fragments) {
/* 406 */     getClasspathManager().loadFragments(fragments);
/*     */   }
/*     */   
/*     */   private boolean lockClassName(String classname) {
/* 410 */     synchronized (this.classNameLocks) {
/* 411 */       Object lockingThread = this.classNameLocks.get(classname);
/* 412 */       Thread current = Thread.currentThread();
/* 413 */       if (lockingThread == current)
/* 414 */         return false; 
/* 415 */       boolean previousInterruption = Thread.interrupted();
/*     */       try {
/*     */         while (true) {
/* 418 */           if (lockingThread == null) {
/* 419 */             this.classNameLocks.put(classname, current);
/* 420 */             return true;
/*     */           } 
/*     */           
/* 423 */           this.classNameLocks.wait();
/* 424 */           lockingThread = this.classNameLocks.get(classname);
/*     */         } 
/* 426 */       } catch (InterruptedException e) {
/* 427 */         previousInterruption = true;
/*     */ 
/*     */         
/* 430 */         throw new Error("Interrupted while waiting for classname lock: " + classname, e);
/*     */       } finally {
/* 432 */         if (previousInterruption) {
/* 433 */           current.interrupt();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void unlockClassName(String classname) {
/* 440 */     synchronized (this.classNameLocks) {
/* 441 */       this.classNameLocks.remove(classname);
/* 442 */       this.classNameLocks.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() {
/* 447 */     getClasspathManager().close();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\ModuleClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */