/*     */ package org.eclipse.osgi.internal.location;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.nio.channels.OverlappingFileLockException;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Locker_JavaNio
/*     */   implements Locker
/*     */ {
/*     */   private final File lockFile;
/*     */   private final boolean debug;
/*     */   private FileLock fileLock;
/*     */   private RandomAccessFile raFile;
/*     */   
/*     */   public Locker_JavaNio(File lockFile, boolean debug) {
/*  34 */     this.lockFile = lockFile;
/*  35 */     this.debug = debug;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean lock() throws IOException {
/*  40 */     this.raFile = new RandomAccessFile(this.lockFile, "rw");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  46 */       this.fileLock = this.raFile.getChannel().tryLock(0L, 1L, false);
/*  47 */     } catch (IOException ioe) {
/*     */       
/*  49 */       if (this.debug) {
/*  50 */         System.out.println(NLS.bind(Msg.location_cannotLock, this.lockFile));
/*     */       }
/*  52 */       String specificMessage = NLS.bind(Msg.location_cannotLockNIO, new Object[] { this.lockFile, ioe.getMessage(), "\"-Dosgi.locking=none\"" });
/*  53 */       throw new IOException(specificMessage);
/*  54 */     } catch (OverlappingFileLockException overlappingFileLockException) {
/*     */       
/*  56 */       this.fileLock = null;
/*     */     } finally {
/*  58 */       if (this.fileLock != null)
/*  59 */         return true; 
/*  60 */       this.raFile.close();
/*  61 */       this.raFile = null;
/*     */     } 
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void release() {
/*  68 */     if (this.fileLock != null) {
/*     */       try {
/*  70 */         this.fileLock.release();
/*  71 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/*  74 */       this.fileLock = null;
/*     */     } 
/*  76 */     if (this.raFile != null) {
/*     */       try {
/*  78 */         this.raFile.close();
/*  79 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/*  82 */       this.raFile = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isLocked() throws IOException {
/*  88 */     if (this.fileLock != null)
/*  89 */       return true; 
/*     */     try {
/*  91 */       RandomAccessFile temp = new RandomAccessFile(this.lockFile, "rw");
/*  92 */       FileLock tempLock = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */         try {
/*  99 */           tempLock = temp.getChannel().tryLock(0L, 1L, false);
/* 100 */         } catch (IOException ioe) {
/* 101 */           if (this.debug) {
/* 102 */             System.out.println(NLS.bind(Msg.location_cannotLock, this.lockFile));
/*     */           }
/* 104 */           String specificMessage = NLS.bind(Msg.location_cannotLockNIO, new Object[] { this.lockFile, ioe.getMessage(), "\"-Dosgi.locking=none\"" });
/* 105 */           throw new IOException(specificMessage);
/*     */         } 
/* 107 */         if (tempLock != null) {
/* 108 */           tempLock.release();
/* 109 */           return false;
/*     */         } 
/* 111 */         return true;
/* 112 */       } catch (OverlappingFileLockException overlappingFileLockException) {
/* 113 */         return true;
/*     */       } finally {
/* 115 */         temp.close();
/*     */       } 
/* 117 */     } catch (FileNotFoundException fileNotFoundException) {
/* 118 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\Locker_JavaNio.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */