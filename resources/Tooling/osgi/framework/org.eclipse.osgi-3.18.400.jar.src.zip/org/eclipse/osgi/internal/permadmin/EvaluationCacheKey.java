/*    */ package org.eclipse.osgi.internal.permadmin;
/*    */ 
/*    */ import java.security.Permission;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EvaluationCacheKey
/*    */ {
/*    */   private final Permission permission;
/*    */   private final BundlePermissions bundlePermissions;
/*    */   
/*    */   EvaluationCacheKey(BundlePermissions bundlePermissions, Permission permission) {
/* 26 */     this.permission = permission;
/* 27 */     this.bundlePermissions = bundlePermissions;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 32 */     if (this == o) {
/* 33 */       return true;
/*    */     }
/* 35 */     if (o == null || getClass() != o.getClass()) {
/* 36 */       return false;
/*    */     }
/* 38 */     EvaluationCacheKey that = (EvaluationCacheKey)o;
/* 39 */     return (this.bundlePermissions == that.bundlePermissions && Objects.equals(this.permission, that.permission));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 44 */     return Objects.hash(new Object[] { this.bundlePermissions, this.permission });
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\EvaluationCacheKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */