/*     */ package org.eclipse.osgi.internal.framework.legacy;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.container.InternalUtils;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.framework.VersionRange;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleRevisions;
/*     */ import org.osgi.framework.wiring.FrameworkWiring;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.service.packageadmin.ExportedPackage;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.service.packageadmin.RequiredBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageAdminImpl
/*     */   implements PackageAdmin
/*     */ {
/*     */   private final FrameworkWiring frameworkWiring;
/*     */   private final EquinoxContainer equinoxContainer;
/*     */   
/*     */   public PackageAdminImpl(EquinoxContainer equinoxContainer, FrameworkWiring frameworkWiring) {
/*  58 */     this.equinoxContainer = equinoxContainer;
/*  59 */     this.frameworkWiring = frameworkWiring;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExportedPackage[] getExportedPackages(Bundle bundle) {
/*  64 */     if (bundle == null) {
/*  65 */       return getExportedPackages((String)null);
/*     */     }
/*     */     
/*  68 */     Collection<BundleRevision> revisions = ((BundleRevisions)bundle.adapt(BundleRevisions.class)).getRevisions();
/*     */     
/*  70 */     Collection<ExportedPackage> allExports = new ArrayList<>();
/*  71 */     for (BundleRevision revision : revisions) {
/*  72 */       ModuleWiring wiring = (ModuleWiring)revision.getWiring();
/*  73 */       if (wiring != null) {
/*  74 */         List<ModuleCapability> providedPackages = wiring
/*  75 */           .getModuleCapabilities("osgi.wiring.package");
/*  76 */         if (providedPackages != null) {
/*  77 */           for (ModuleCapability providedPackage : providedPackages) {
/*  78 */             allExports.add(new ExportedPackageImpl(providedPackage, wiring));
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/*  83 */     return allExports.isEmpty() ? null : allExports.<ExportedPackage>toArray(new ExportedPackage[allExports.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public ExportedPackage getExportedPackage(String name) {
/*  88 */     ExportedPackage[] allExports = getExportedPackages(name);
/*  89 */     if (allExports == null)
/*  90 */       return null; 
/*  91 */     ExportedPackage result = null; byte b; int i; ExportedPackage[] arrayOfExportedPackage1;
/*  92 */     for (i = (arrayOfExportedPackage1 = allExports).length, b = 0; b < i; ) { ExportedPackage allExport = arrayOfExportedPackage1[b];
/*  93 */       if (name.equals(allExport.getName()))
/*  94 */         if (result == null) {
/*  95 */           result = allExport;
/*     */         } else {
/*  97 */           Version curVersion = result.getVersion();
/*  98 */           Version newVersion = allExport.getVersion();
/*  99 */           if (newVersion.compareTo(curVersion) >= 0) {
/* 100 */             result = allExport;
/*     */           }
/*     */         }  
/*     */       b++; }
/*     */     
/* 105 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExportedPackage[] getExportedPackages(String name) {
/* 110 */     String filter = "(osgi.wiring.package=" + ((name == null) ? "*" : name) + ")";
/* 111 */     Map<String, String> directives = Collections.singletonMap("filter", filter);
/* 112 */     Map<String, Boolean> attributes = Collections.singletonMap("org.eclipse.osgi.container.synthetic", Boolean.TRUE);
/* 113 */     Requirement packageReq = ModuleContainer.createRequirement("osgi.wiring.package", directives, attributes);
/* 114 */     Collection<BundleCapability> packageCaps = this.frameworkWiring.findProviders(packageReq);
/* 115 */     InternalUtils.filterCapabilityPermissions(packageCaps);
/* 116 */     List<ExportedPackage> result = new ArrayList<>();
/* 117 */     for (BundleCapability capability : packageCaps) {
/* 118 */       ModuleWiring wiring = (ModuleWiring)capability.getRevision().getWiring();
/* 119 */       if (wiring != null) {
/* 120 */         Collection<ModuleWiring> wirings = Collections.emptyList();
/* 121 */         if ((capability.getRevision().getTypes() & 0x1) != 0) {
/*     */           
/* 123 */           List<ModuleWire> hostWires = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 124 */           if (hostWires != null && !hostWires.isEmpty()) {
/* 125 */             wirings = new ArrayList<>(hostWires.size());
/* 126 */             for (ModuleWire hostWire : hostWires) {
/* 127 */               ModuleWiring hostWiring = hostWire.getProviderWiring();
/* 128 */               if (hostWiring != null) {
/* 129 */                 wirings.add(hostWiring);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 135 */           wirings = Collections.singletonList(wiring);
/*     */         } 
/* 137 */         for (ModuleWiring moduleWiring : wirings) {
/* 138 */           Object pkgName = capability.getAttributes().get("osgi.wiring.package");
/* 139 */           if (pkgName instanceof String && 
/* 140 */             !moduleWiring.isSubstitutedPackage((String)pkgName)) {
/* 141 */             result.add(new ExportedPackageImpl((ModuleCapability)capability, moduleWiring));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 146 */     return (result.size() == 0) ? null : result.<ExportedPackage>toArray(new ExportedPackage[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void refreshPackages(Bundle[] input) {
/* 151 */     this.frameworkWiring.refreshBundles((input == null) ? null : Arrays.<Bundle>asList(input), new org.osgi.framework.FrameworkListener[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean resolveBundles(Bundle[] input) {
/* 156 */     return this.frameworkWiring.resolveBundles((input == null) ? null : Arrays.<Bundle>asList(input));
/*     */   }
/*     */ 
/*     */   
/*     */   public RequiredBundle[] getRequiredBundles(String symbolicName) {
/* 161 */     String filter = "(osgi.wiring.bundle=" + ((symbolicName == null) ? "*" : symbolicName) + ")";
/* 162 */     Map<String, String> directives = Collections.singletonMap("filter", filter);
/* 163 */     Map<String, Boolean> attributes = Collections.singletonMap("org.eclipse.osgi.container.synthetic", Boolean.TRUE);
/* 164 */     Requirement bundleReq = ModuleContainer.createRequirement("osgi.wiring.bundle", directives, attributes);
/* 165 */     Collection<BundleCapability> bundleCaps = this.frameworkWiring.findProviders(bundleReq);
/* 166 */     InternalUtils.filterCapabilityPermissions(bundleCaps);
/* 167 */     Collection<RequiredBundle> result = new ArrayList<>();
/* 168 */     for (BundleCapability capability : bundleCaps) {
/* 169 */       ModuleWiring wiring = (ModuleWiring)capability.getRevision().getWiring();
/* 170 */       if (wiring != null) {
/* 171 */         result.add(new RequiredBundleImpl((ModuleCapability)capability, wiring));
/*     */       }
/*     */     } 
/* 174 */     return result.isEmpty() ? null : result.<RequiredBundle>toArray(new RequiredBundle[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle[] getBundles(String symbolicName, String versionRange) {
/* 179 */     if (symbolicName == null) {
/* 180 */       throw new IllegalArgumentException();
/*     */     }
/* 182 */     if ("system.bundle".equals(symbolicName))
/*     */     {
/* 184 */       symbolicName = "org.eclipse.osgi";
/*     */     }
/* 186 */     VersionRange range = (versionRange == null) ? null : new VersionRange(versionRange);
/* 187 */     String filter = String.valueOf((range != null) ? "(&" : "") + "(" + "osgi.identity" + "=" + symbolicName + ")" + ((range != null) ? (String.valueOf(range.toFilterString("version")) + ")") : "");
/* 188 */     Requirement identityReq = ModuleContainer.createRequirement("osgi.identity", Collections.singletonMap("filter", filter), Collections.emptyMap());
/* 189 */     Collection<BundleCapability> identityCaps = this.frameworkWiring.findProviders(identityReq);
/*     */     
/* 191 */     if (identityCaps.isEmpty()) {
/* 192 */       return null;
/*     */     }
/* 194 */     List<Bundle> sorted = new ArrayList<>(identityCaps.size());
/* 195 */     for (BundleCapability capability : identityCaps) {
/* 196 */       Bundle b = capability.getRevision().getBundle();
/*     */       
/* 198 */       if (symbolicName.equals(b.getSymbolicName()) && !sorted.contains(b)) {
/* 199 */         sorted.add(b);
/*     */       }
/*     */     } 
/* 202 */     Collections.sort(sorted, Comparator.<Bundle, Comparable>comparing(Bundle::getVersion).reversed());
/*     */     
/* 204 */     if (sorted.isEmpty()) {
/* 205 */       return null;
/*     */     }
/*     */     
/* 208 */     return sorted.<Bundle>toArray(new Bundle[sorted.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle[] getFragments(Bundle bundle) {
/* 213 */     ModuleWiring wiring = getWiring(bundle);
/* 214 */     if (wiring == null) {
/* 215 */       return null;
/*     */     }
/* 217 */     List<ModuleWire> hostWires = wiring.getProvidedModuleWires("osgi.wiring.host");
/* 218 */     if (hostWires == null)
/*     */     {
/* 220 */       return null;
/*     */     }
/* 222 */     Collection<Bundle> fragments = new ArrayList<>(hostWires.size());
/* 223 */     for (ModuleWire wire : hostWires) {
/* 224 */       Bundle fragment = wire.getRequirer().getBundle();
/* 225 */       if (fragment != null) {
/* 226 */         fragments.add(fragment);
/*     */       }
/*     */     } 
/* 229 */     return fragments.isEmpty() ? null : fragments.<Bundle>toArray(new Bundle[fragments.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle[] getHosts(Bundle bundle) {
/* 234 */     ModuleWiring wiring = getWiring(bundle);
/* 235 */     if (wiring == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     List<ModuleWire> hostWires = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 239 */     if (hostWires == null)
/*     */     {
/* 241 */       return null;
/*     */     }
/* 243 */     Collection<Bundle> hosts = new ArrayList<>(hostWires.size());
/* 244 */     for (ModuleWire wire : hostWires) {
/* 245 */       Bundle host = wire.getProvider().getBundle();
/* 246 */       if (host != null) {
/* 247 */         hosts.add(host);
/*     */       }
/*     */     } 
/* 250 */     return hosts.isEmpty() ? null : hosts.<Bundle>toArray(new Bundle[hosts.size()]);
/*     */   }
/*     */   
/*     */   private ModuleWiring getWiring(Bundle bundle) {
/* 254 */     BundleRevision current = (BundleRevision)bundle.adapt(BundleRevision.class);
/* 255 */     if (current == null) {
/* 256 */       return null;
/*     */     }
/* 258 */     return (ModuleWiring)current.getWiring();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle(Class<?> clazz) {
/* 263 */     return this.equinoxContainer.getBundle(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBundleType(Bundle bundle) {
/* 268 */     BundleRevision current = (BundleRevision)bundle.adapt(BundleRevision.class);
/* 269 */     if (current == null) {
/* 270 */       return 0;
/*     */     }
/* 272 */     return ((current.getTypes() & 0x1) != 0) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public Collection<Bundle> getRemovalPendingBundles() {
/* 276 */     return this.frameworkWiring.getRemovalPendingBundles();
/*     */   }
/*     */   
/*     */   public Collection<Bundle> getDependencyClosure(Collection<Bundle> bundles) {
/* 280 */     return this.frameworkWiring.getDependencyClosure(bundles);
/*     */   }
/*     */   
/*     */   static class ExportedPackageImpl
/*     */     implements ExportedPackage {
/*     */     private final ModuleCapability packageCapability;
/*     */     private final ModuleWiring providerWiring;
/*     */     
/*     */     public ExportedPackageImpl(ModuleCapability packageCapability, ModuleWiring providerWiring) {
/* 289 */       this.packageCapability = packageCapability;
/* 290 */       this.providerWiring = providerWiring;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 295 */       return (String)this.packageCapability.getAttributes().get("osgi.wiring.package");
/*     */     }
/*     */ 
/*     */     
/*     */     public Bundle getExportingBundle() {
/* 300 */       if (!this.providerWiring.isInUse())
/* 301 */         return null; 
/* 302 */       return this.providerWiring.getBundle();
/*     */     }
/*     */ 
/*     */     
/*     */     public Bundle[] getImportingBundles() {
/* 307 */       if (!this.providerWiring.isInUse()) {
/* 308 */         return null;
/*     */       }
/* 310 */       Set<Bundle> importing = new HashSet<>();
/*     */       
/* 312 */       String packageName = getName();
/* 313 */       addRequirers(importing, this.providerWiring, packageName);
/*     */       
/* 315 */       List<ModuleWire> providedPackages = this.providerWiring
/* 316 */         .getProvidedModuleWires("osgi.wiring.package");
/* 317 */       if (providedPackages == null)
/*     */       {
/* 319 */         return null;
/*     */       }
/* 321 */       for (ModuleWire packageWire : providedPackages) {
/* 322 */         if (this.packageCapability.equals(packageWire.getCapability())) {
/* 323 */           importing.add(packageWire.getRequirer().getBundle());
/* 324 */           if (packageWire.getRequirerWiring().isSubstitutedPackage(packageName)) {
/* 325 */             addRequirers(importing, packageWire.getRequirerWiring(), packageName);
/*     */           }
/*     */         } 
/*     */       } 
/* 329 */       return importing.<Bundle>toArray(new Bundle[importing.size()]);
/*     */     }
/*     */     
/*     */     private static void addRequirers(Set<Bundle> importing, ModuleWiring wiring, String packageName) {
/* 333 */       List<ModuleWire> requirerWires = wiring.getProvidedModuleWires("osgi.wiring.bundle");
/* 334 */       if (requirerWires == null) {
/*     */         return;
/*     */       }
/*     */       
/* 338 */       for (ModuleWire requireBundleWire : requirerWires) {
/* 339 */         Bundle requirer = requireBundleWire.getRequirer().getBundle();
/* 340 */         if (importing.contains(requirer)) {
/*     */           continue;
/*     */         }
/* 343 */         importing.add(requirer);
/*     */ 
/*     */         
/* 346 */         String reExport = (String)requireBundleWire.getRequirement().getDirectives().get("visibility");
/* 347 */         ModuleWiring requirerWiring = requireBundleWire.getRequirerWiring();
/* 348 */         if ("reexport".equals(reExport)) {
/* 349 */           addRequirers(importing, requirerWiring, packageName);
/*     */         }
/*     */         
/* 352 */         if (!requirerWiring.equals(wiring)) {
/* 353 */           List<ModuleWire> providedPackages = requirerWiring
/* 354 */             .getProvidedModuleWires("osgi.wiring.package");
/* 355 */           if (providedPackages != null) {
/* 356 */             for (ModuleWire packageWire : providedPackages) {
/* 357 */               if (packageName.equals(packageWire.getCapability().getAttributes().get("osgi.wiring.package"))) {
/* 358 */                 importing.add(packageWire.getRequirer().getBundle());
/* 359 */                 if (packageWire.getRequirerWiring().isSubstitutedPackage(packageName)) {
/* 360 */                   addRequirers(importing, packageWire.getRequirerWiring(), packageName);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSpecificationVersion() {
/* 375 */       return getVersion().toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Version getVersion() {
/* 380 */       Version version = (Version)this.packageCapability.getAttributes().get("version");
/* 381 */       return (version == null) ? Version.emptyVersion : version;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRemovalPending() {
/* 386 */       return !this.providerWiring.isCurrent();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 391 */       return this.packageCapability.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class RequiredBundleImpl implements RequiredBundle {
/*     */     private final ModuleCapability bundleCapability;
/*     */     private final ModuleWiring providerWiring;
/*     */     
/*     */     public RequiredBundleImpl(ModuleCapability bundleCapability, ModuleWiring providerWiring) {
/* 400 */       this.bundleCapability = bundleCapability;
/* 401 */       this.providerWiring = providerWiring;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSymbolicName() {
/* 406 */       return (String)this.bundleCapability.getAttributes().get("osgi.wiring.bundle");
/*     */     }
/*     */ 
/*     */     
/*     */     public Bundle getBundle() {
/* 411 */       if (!this.providerWiring.isInUse())
/* 412 */         return null; 
/* 413 */       return this.providerWiring.getBundle();
/*     */     }
/*     */ 
/*     */     
/*     */     public Bundle[] getRequiringBundles() {
/* 418 */       if (!this.providerWiring.isInUse()) {
/* 419 */         return null;
/*     */       }
/* 421 */       Set<Bundle> requiring = new HashSet<>();
/*     */       
/* 423 */       addRequirers(requiring, this.providerWiring);
/*     */       
/* 425 */       return requiring.<Bundle>toArray(new Bundle[requiring.size()]);
/*     */     }
/*     */     
/*     */     private static void addRequirers(Set<Bundle> requiring, ModuleWiring providerWiring) {
/* 429 */       List<ModuleWire> requirerWires = providerWiring.getProvidedModuleWires("osgi.wiring.bundle");
/* 430 */       if (requirerWires == null) {
/*     */         return;
/*     */       }
/*     */       
/* 434 */       for (ModuleWire requireBundleWire : requirerWires) {
/* 435 */         Bundle requirer = requireBundleWire.getRequirer().getBundle();
/* 436 */         if (requiring.contains(requirer)) {
/*     */           continue;
/*     */         }
/* 439 */         requiring.add(requirer);
/* 440 */         String reExport = (String)requireBundleWire.getRequirement().getDirectives().get("visibility");
/* 441 */         if ("reexport".equals(reExport)) {
/* 442 */           addRequirers(requiring, requireBundleWire.getRequirerWiring());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Version getVersion() {
/* 449 */       Version version = (Version)this.bundleCapability.getAttributes().get("version");
/* 450 */       return (version == null) ? Version.emptyVersion : version;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRemovalPending() {
/* 455 */       return !this.providerWiring.isCurrent();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 460 */       return this.bundleCapability.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\legacy\PackageAdminImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */