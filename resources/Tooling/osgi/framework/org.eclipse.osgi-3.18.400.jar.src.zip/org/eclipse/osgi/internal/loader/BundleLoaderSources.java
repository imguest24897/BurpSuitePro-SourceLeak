/*    */ package org.eclipse.osgi.internal.loader;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.eclipse.osgi.container.ModuleCapability;
/*    */ import org.eclipse.osgi.framework.util.SecureAction;
/*    */ import org.eclipse.osgi.internal.loader.sources.FilteredSourcePackage;
/*    */ import org.eclipse.osgi.internal.loader.sources.PackageSource;
/*    */ import org.eclipse.osgi.internal.loader.sources.SingleSourcePackage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleLoaderSources
/*    */ {
/* 28 */   static SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*    */   private final ConcurrentMap<String, PackageSource> pkgSources;
/*    */   private final BundleLoader loader;
/*    */   
/*    */   public BundleLoaderSources(BundleLoader loader) {
/* 33 */     this.pkgSources = new ConcurrentHashMap<>();
/* 34 */     this.loader = loader;
/*    */   }
/*    */   
/*    */   PackageSource getPackageSource(String pkgName) {
/* 38 */     PackageSource pkgSource = this.pkgSources.get(pkgName);
/* 39 */     if (pkgSource != null) {
/* 40 */       return pkgSource;
/*    */     }
/* 42 */     SingleSourcePackage singleSourcePackage = new SingleSourcePackage(pkgName, this.loader);
/* 43 */     PackageSource existingSource = (PackageSource)this.pkgSources.putIfAbsent(singleSourcePackage.getId(), singleSourcePackage);
/* 44 */     return (existingSource != null) ? existingSource : (PackageSource)singleSourcePackage;
/*    */   }
/*    */   
/*    */   boolean forceSourceCreation(ModuleCapability packageCapability) {
/* 48 */     Map<String, String> directives = packageCapability.getDirectives();
/* 49 */     return !(directives.get("include") == null && directives.get("exclude") == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PackageSource createPackageSource(ModuleCapability packageCapability, boolean storeSource) {
/*    */     FilteredSourcePackage filteredSourcePackage;
/* 59 */     PackageSource packageSource1, pkgSource = null;
/*    */     
/* 61 */     String name = (String)packageCapability.getAttributes().get("osgi.wiring.package");
/*    */     
/* 63 */     String includes = (String)packageCapability.getDirectives().get("include");
/* 64 */     String excludes = (String)packageCapability.getDirectives().get("exclude");
/* 65 */     if (includes != null || excludes != null) {
/* 66 */       filteredSourcePackage = new FilteredSourcePackage(name, this.loader, includes, excludes);
/*    */     }
/*    */     
/* 69 */     if (storeSource) {
/* 70 */       if (filteredSourcePackage != null) {
/* 71 */         PackageSource existingSource = (PackageSource)this.pkgSources.putIfAbsent(filteredSourcePackage.getId(), filteredSourcePackage);
/* 72 */         if (existingSource != null) {
/* 73 */           packageSource1 = existingSource;
/*    */         
/*    */         }
/*    */       }
/*    */     
/*    */     }
/* 79 */     else if (packageSource1 == null) {
/* 80 */       packageSource1 = getPackageSource(name);
/*    */       
/* 82 */       if (packageSource1.getClass() != SingleSourcePackage.class) {
/* 83 */         return (PackageSource)new SingleSourcePackage(name, this.loader);
/*    */       }
/*    */     } 
/*    */     
/* 87 */     return packageSource1;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\BundleLoaderSources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */