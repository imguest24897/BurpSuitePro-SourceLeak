/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.security.AllPermission;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.osgi.internal.container.NamespaceList;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleRevisionBuilder
/*     */ {
/*  47 */   private static final Class<?> SINGLETON_MAP_CLASS = Collections.singletonMap(null, null).getClass();
/*  48 */   private static final Class<?> UNMODIFIABLE_MAP_CLASS = Collections.unmodifiableMap(Collections.emptyMap()).getClass();
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GenericInfo
/*     */   {
/*  54 */     static final Function<GenericInfo, String> GETNAMESPACE = new Function<GenericInfo, String>() {
/*     */         public String apply(ModuleRevisionBuilder.GenericInfo info) {
/*  56 */           return info.getNamespace();
/*     */         }
/*     */       };
/*     */     final String namespace;
/*     */     final Map<String, String> directives;
/*     */     final Map<String, Object> attributes;
/*     */     final boolean mutable;
/*     */     
/*     */     GenericInfo(String namespace, Map<String, String> directives, Map<String, Object> attributes, boolean mutable) {
/*  65 */       this.namespace = namespace;
/*  66 */       this.directives = directives;
/*  67 */       this.attributes = attributes;
/*  68 */       this.mutable = mutable;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getNamespace() {
/*  76 */       return this.namespace;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, String> getDirectives() {
/*  84 */       return this.directives;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, Object> getAttributes() {
/*  92 */       return this.attributes;
/*     */     }
/*     */   }
/*     */   
/*  96 */   private String symbolicName = null;
/*  97 */   private Version version = Version.emptyVersion;
/*  98 */   private int types = 0;
/*  99 */   private final NamespaceList.Builder<GenericInfo> capabilityInfos = NamespaceList.Builder.create(GenericInfo.GETNAMESPACE);
/* 100 */   private final NamespaceList.Builder<GenericInfo> requirementInfos = NamespaceList.Builder.create(GenericInfo.GETNAMESPACE);
/* 101 */   private long id = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSymbolicName(String symbolicName) {
/* 115 */     this.symbolicName = symbolicName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(Version version) {
/* 123 */     this.version = version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypes(int types) {
/* 131 */     this.types = types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(long id) {
/* 151 */     if (id < 1L) {
/* 152 */       throw new IllegalArgumentException("ID must be >=1.");
/*     */     }
/* 154 */     this.id = id;
/*     */   }
/*     */   
/*     */   void setInternalId(long id) {
/* 158 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCapability(String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 168 */     addGenericInfo(this.capabilityInfos, namespace, directives, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GenericInfo> getCapabilities() {
/* 176 */     return getCapabilities(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GenericInfo> getCapabilities(String namespace) {
/* 189 */     return this.capabilityInfos.getNamespaceElements(namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRequirement(String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 199 */     addGenericInfo(this.requirementInfos, namespace, directives, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GenericInfo> getRequirements() {
/* 207 */     return getRequirements(null);
/*     */   }
/*     */   
/*     */   NamespaceList.Builder<GenericInfo> getRequirementsBuilder() {
/* 211 */     return this.requirementInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GenericInfo> getRequirements(String namespace) {
/* 224 */     return this.requirementInfos.getNamespaceElements(namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSymbolicName() {
/* 232 */     return this.symbolicName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getVersion() {
/* 240 */     return this.version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypes() {
/* 248 */     return this.types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getId() {
/* 260 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleRevision addRevision(Module module, Object revisionInfo) {
/* 272 */     ModuleRevisions revisions = module.getRevisions();
/* 273 */     ModuleRevision revision = new ModuleRevision(this.symbolicName, this.version, this.types, this.capabilityInfos, this.requirementInfos, revisions, revisionInfo);
/*     */     
/* 275 */     revisions.addRevision(revision);
/* 276 */     module.getContainer().getAdaptor().associateRevision(revision, revisionInfo);
/*     */     
/*     */     try {
/* 279 */       checkFrameworkExtensionPermission(module, revision);
/* 280 */       module.getContainer().checkAdminPermission(module.getBundle(), "lifecycle");
/* 281 */     } catch (SecurityException e) {
/* 282 */       revisions.removeRevision(revision);
/* 283 */       throw e;
/*     */     } 
/* 285 */     return revision;
/*     */   }
/*     */   
/*     */   private void checkFrameworkExtensionPermission(Module module, ModuleRevision revision) {
/* 289 */     if (System.getSecurityManager() == null) {
/*     */       return;
/*     */     }
/* 292 */     if ((revision.getTypes() & 0x1) != 0) {
/* 293 */       Collection<?> systemNames = Collections.emptyList();
/* 294 */       Module systemModule = module.getContainer().getModule(0L);
/* 295 */       if (systemModule != null) {
/* 296 */         ModuleRevision systemRevision = systemModule.getCurrentRevision();
/* 297 */         List<ModuleCapability> hostCapabilities = systemRevision.getModuleCapabilities("osgi.wiring.host");
/* 298 */         for (ModuleCapability hostCapability : hostCapabilities) {
/* 299 */           Object hostNames = hostCapability.getAttributes().get("osgi.wiring.host");
/* 300 */           if (hostNames instanceof Collection) {
/* 301 */             systemNames = (Collection)hostNames; continue;
/* 302 */           }  if (hostNames instanceof String) {
/* 303 */             systemNames = Arrays.asList(new Object[] { hostNames });
/*     */           }
/*     */         } 
/*     */       } 
/* 307 */       List<ModuleRequirement> hostRequirements = revision.getModuleRequirements("osgi.wiring.host");
/* 308 */       for (ModuleRequirement hostRequirement : hostRequirements) {
/* 309 */         FilterImpl f = null;
/* 310 */         String filterSpec = hostRequirement.getDirectives().get("filter");
/* 311 */         if (filterSpec != null) {
/*     */           try {
/* 313 */             f = FilterImpl.newInstance(filterSpec);
/* 314 */             String hostName = f.getPrimaryKeyValue("osgi.wiring.host");
/* 315 */             if (hostName != null && 
/* 316 */               systemNames.contains(hostName)) {
/* 317 */               Bundle b = module.getBundle();
/* 318 */               if (b != null && !b.hasPermission(new AllPermission())) {
/* 319 */                 SecurityException se = new SecurityException(
/* 320 */                     "Must have AllPermission granted to install an extension bundle: " + b);
/*     */                 
/* 322 */                 BundleException be = new BundleException(se.getMessage(), 6, se);
/* 323 */                 se.initCause((Throwable)be);
/* 324 */                 throw se;
/*     */               } 
/* 326 */               module.getContainer().checkAdminPermission(module.getBundle(), "extensionLifecycle");
/*     */             }
/*     */           
/* 329 */           } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addGenericInfo(NamespaceList.Builder<GenericInfo> infos, String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 337 */     infos.add(new GenericInfo(namespace, directives, attributes, true));
/*     */   }
/*     */   
/*     */   void basicAddCapability(String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 341 */     basicAddGenericInfo(this.capabilityInfos, namespace, directives, attributes);
/*     */   }
/*     */   
/*     */   void basicAddRequirement(String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 345 */     basicAddGenericInfo(this.requirementInfos, namespace, directives, attributes);
/*     */   }
/*     */   
/*     */   private static void basicAddGenericInfo(NamespaceList.Builder<GenericInfo> infos, String namespace, Map<String, String> directives, Map<String, Object> attributes) {
/* 349 */     infos.add(new GenericInfo(namespace, unmodifiableMap(directives), unmodifiableMap(attributes), false));
/*     */   }
/*     */ 
/*     */   
/*     */   static <K, V> Map<K, V> unmodifiableMap(Map<? extends K, ? extends V> map) {
/* 354 */     int size = map.size();
/* 355 */     if (size == 0) {
/* 356 */       return Collections.emptyMap();
/*     */     }
/* 358 */     if (size == 1) {
/* 359 */       if (map.getClass() != SINGLETON_MAP_CLASS) {
/* 360 */         Map.Entry<? extends K, ? extends V> entry = map.entrySet().iterator().next();
/* 361 */         map = Collections.singletonMap(entry.getKey(), entry.getValue());
/*     */       }
/*     */     
/* 364 */     } else if (map.getClass() != UNMODIFIABLE_MAP_CLASS) {
/* 365 */       map = Collections.unmodifiableMap(map);
/*     */     } 
/*     */     
/* 368 */     return (Map)map;
/*     */   }
/*     */   
/*     */   void clear() {
/* 372 */     this.capabilityInfos.clear();
/* 373 */     this.requirementInfos.clear();
/* 374 */     this.id = -1L;
/* 375 */     this.symbolicName = null;
/* 376 */     this.version = Version.emptyVersion;
/* 377 */     this.types = 0;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleRevisionBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */