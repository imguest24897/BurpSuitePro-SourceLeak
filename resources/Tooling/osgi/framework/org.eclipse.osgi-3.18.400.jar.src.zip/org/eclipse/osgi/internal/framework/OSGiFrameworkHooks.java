/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleCollisionHook;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.framework.util.ArrayMap;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceReferenceImpl;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ShrinkableCollection;
/*     */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*     */ import org.eclipse.osgi.storage.Storage;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.hooks.bundle.CollisionHook;
/*     */ import org.osgi.framework.hooks.resolver.ResolverHook;
/*     */ import org.osgi.framework.hooks.resolver.ResolverHookFactory;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRequirement;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OSGiFrameworkHooks
/*     */ {
/*     */   private final CoreResolverHookFactory resolverHookFactory;
/*     */   private final ModuleCollisionHook collisionHook;
/*     */   
/*     */   OSGiFrameworkHooks(EquinoxContainer container, Storage storage) {
/*  51 */     this.resolverHookFactory = new CoreResolverHookFactory(container, storage);
/*  52 */     this.collisionHook = new BundleCollisionHook(container);
/*     */   }
/*     */   
/*     */   public ResolverHookFactory getResolverHookFactory() {
/*  56 */     return this.resolverHookFactory;
/*     */   }
/*     */   
/*     */   public ModuleCollisionHook getModuleCollisionHook() {
/*  60 */     return this.collisionHook;
/*     */   }
/*     */   
/*     */   static class BundleCollisionHook implements ModuleCollisionHook {
/*     */     final Debug debug;
/*     */     final EquinoxContainer container;
/*     */     
/*     */     public BundleCollisionHook(EquinoxContainer container) {
/*  68 */       this.container = container;
/*  69 */       this.debug = container.getConfiguration().getDebug();
/*     */     }
/*     */     public void filterCollisions(int operationType, Module target, Collection<Module> collisionCandidates) {
/*     */       Bundle targetBundle;
/*     */       ArrayMap<Bundle, Module> candidateBundles;
/*  74 */       switch ((this.container.getConfiguration()).BSN_VERSION) {
/*     */         case 1:
/*     */           return;
/*     */         
/*     */         case 2:
/*  79 */           collisionCandidates.clear();
/*     */           return;
/*     */         
/*     */         case 3:
/*  83 */           targetBundle = target.getBundle();
/*  84 */           candidateBundles = new ArrayMap(collisionCandidates.size());
/*  85 */           for (Module module : collisionCandidates) {
/*  86 */             candidateBundles.put(module.getBundle(), module);
/*     */           }
/*  88 */           notifyCollisionHooks(operationType, targetBundle, (Collection)candidateBundles);
/*  89 */           collisionCandidates.retainAll(candidateBundles.getValues());
/*     */           return;
/*     */       } 
/*     */       
/*  93 */       throw new IllegalStateException("Bad configuration: " + (this.container.getConfiguration()).BSN_VERSION);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void notifyCollisionHooks(int operationType, Bundle target, Collection<Bundle> collisionCandidates) {
/*  99 */       ShrinkableCollection shrinkableCollection = new ShrinkableCollection(collisionCandidates);
/* 100 */       if (System.getSecurityManager() == null) {
/* 101 */         notifyCollisionHooksPriviledged(operationType, target, (Collection<Bundle>)shrinkableCollection);
/*     */       } else {
/* 103 */         AccessController.doPrivileged(() -> {
/*     */               notifyCollisionHooksPriviledged(param1Int, param1Bundle, param1Collection);
/*     */               return null;
/*     */             });
/*     */       } 
/*     */     }
/*     */     
/*     */     void notifyCollisionHooksPriviledged(int operationType, Bundle target, Collection<Bundle> collisionCandidates) {
/* 111 */       if (this.debug.DEBUG_HOOKS) {
/* 112 */         Debug.println("notifyCollisionHooks(" + operationType + ", " + target + ", " + collisionCandidates + ")");
/*     */       }
/* 114 */       ServiceRegistry registry = this.container.getServiceRegistry();
/* 115 */       if (registry != null) {
/* 116 */         registry.notifyHooksPrivileged(CollisionHook.class, "filterCollisions", (hook, hookRegistration) -> hook.filterCollisions(param1Int, param1Bundle, param1Collection));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static class CoreResolverHookFactory
/*     */     implements ResolverHookFactory
/*     */   {
/*     */     final Debug debug;
/*     */     final EquinoxContainer container;
/*     */     final Storage storage;
/*     */     
/*     */     static class HookReference
/*     */     {
/*     */       final ServiceReferenceImpl<ResolverHookFactory> reference;
/*     */       final ResolverHook hook;
/*     */       final BundleContextImpl context;
/*     */       
/*     */       public HookReference(ServiceReferenceImpl<ResolverHookFactory> reference, ResolverHook hook, BundleContextImpl context) {
/* 135 */         this.reference = reference;
/* 136 */         this.hook = hook;
/* 137 */         this.context = context;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean inInit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CoreResolverHookFactory(EquinoxContainer container, Storage storage) {
/* 151 */       this.container = container;
/* 152 */       this.debug = container.getConfiguration().getDebug();
/* 153 */       this.storage = storage;
/*     */     }
/*     */     
/*     */     void handleHookException(Throwable t, Object hook, String method) {
/* 157 */       if (this.debug.DEBUG_HOOKS) {
/* 158 */         Debug.println(String.valueOf(hook.getClass().getName()) + "." + method + "() exception:");
/* 159 */         if (t != null)
/* 160 */           Debug.printStackTrace(t); 
/*     */       } 
/* 162 */       String message = NLS.bind(Msg.SERVICE_FACTORY_EXCEPTION, hook.getClass().getName(), method);
/* 163 */       throw new RuntimeException(message, new BundleException(message, 12, t));
/*     */     }
/*     */     
/*     */     private ServiceReferenceImpl<ResolverHookFactory>[] getHookReferences(ServiceRegistry registry, BundleContextImpl context) {
/* 167 */       return AccessController.<ServiceReferenceImpl<ResolverHookFactory>[]>doPrivileged(() -> {
/*     */ 
/*     */             
/*     */             try {
/*     */               return param1ServiceRegistry.getServiceReferences(param1BundleContextImpl, ResolverHookFactory.class.getName(), null, false);
/* 172 */             } catch (InvalidSyntaxException invalidSyntaxException) {
/*     */               return null;
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ResolverHook begin(Collection<BundleRevision> triggers) {
/* 182 */       if (this.debug.DEBUG_HOOKS) {
/* 183 */         Debug.println("ResolverHook.begin");
/*     */       }
/* 185 */       ModuleContainer mContainer = this.storage.getModuleContainer();
/* 186 */       Module systemModule = (mContainer == null) ? null : mContainer.getModule(0L);
/* 187 */       ServiceRegistry registry = this.container.getServiceRegistry();
/* 188 */       if (registry == null || systemModule == null) {
/* 189 */         return new CoreResolverHook(Collections.emptyList(), systemModule);
/*     */       }
/*     */       
/* 192 */       BundleContextImpl context = (BundleContextImpl)EquinoxContainer.secureAction.getContext(systemModule.getBundle());
/*     */       
/* 194 */       ServiceReferenceImpl[] refs = (ServiceReferenceImpl[])getHookReferences(registry, context);
/* 195 */       List<HookReference> hookRefs = (refs == null) ? Collections.<HookReference>emptyList() : 
/* 196 */         new ArrayList<>(refs.length);
/* 197 */       if (refs != null) {
/* 198 */         byte b; int i; ServiceReferenceImpl[] arrayOfServiceReferenceImpl; for (i = (arrayOfServiceReferenceImpl = refs).length, b = 0; b < i; ) { ServiceReferenceImpl<ResolverHookFactory> hookRef = arrayOfServiceReferenceImpl[b];
/* 199 */           ResolverHookFactory factory = (ResolverHookFactory)EquinoxContainer.secureAction.getService((ServiceReference)hookRef, context);
/* 200 */           if (factory != null)
/*     */             try {
/* 202 */               ResolverHook hook = factory.begin(triggers);
/* 203 */               if (hook != null)
/* 204 */                 hookRefs.add(new HookReference(hookRef, hook, context)); 
/* 205 */             } catch (Throwable t) {
/*     */               
/*     */               try {
/* 208 */                 (new CoreResolverHook(hookRefs, systemModule)).end();
/* 209 */               } catch (Throwable throwable) {}
/*     */ 
/*     */               
/* 212 */               handleHookException(t, factory, "begin");
/*     */             }  
/*     */           b++; }
/*     */       
/*     */       } 
/* 217 */       return new CoreResolverHook(hookRefs, systemModule);
/*     */     }
/*     */     
/*     */     class CoreResolverHook
/*     */       implements ResolutionReport.Listener, ResolverHook {
/*     */       private final List<OSGiFrameworkHooks.CoreResolverHookFactory.HookReference> hooks;
/*     */       private final Module systemModule;
/*     */       private volatile ResolutionReport resolutionReport;
/*     */       
/*     */       CoreResolverHook(List<OSGiFrameworkHooks.CoreResolverHookFactory.HookReference> hooks, Module systemModule) {
/* 227 */         this.hooks = hooks;
/* 228 */         this.systemModule = systemModule;
/*     */       }
/*     */ 
/*     */       
/*     */       public void filterResolvable(Collection<BundleRevision> candidates) {
/* 233 */         if (OSGiFrameworkHooks.CoreResolverHookFactory.this.debug.DEBUG_HOOKS) {
/* 234 */           Debug.println("ResolverHook.filterResolvable(" + candidates + ")");
/*     */         }
/* 236 */         if (isBootInit())
/*     */         {
/* 238 */           for (Iterator<BundleRevision> iCandidates = candidates.iterator(); iCandidates.hasNext(); ) {
/* 239 */             BundleRevision revision = iCandidates.next();
/* 240 */             if ((revision.getTypes() & 0x1) == 0)
/*     */             {
/* 242 */               if (revision.getBundle().getBundleId() != 0L) {
/* 243 */                 iCandidates.remove();
/*     */               }
/*     */             }
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 250 */         if (this.hooks.isEmpty())
/*     */           return; 
/* 252 */         ShrinkableCollection shrinkableCollection = new ShrinkableCollection(candidates);
/* 253 */         for (OSGiFrameworkHooks.CoreResolverHookFactory.HookReference hookRef : this.hooks) {
/* 254 */           if (hookRef.reference.getBundle() == null) {
/* 255 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(null, hookRef.hook, "filterResolvable"); continue;
/*     */           } 
/*     */           try {
/* 258 */             hookRef.hook.filterResolvable((Collection)shrinkableCollection);
/* 259 */           } catch (Throwable t) {
/* 260 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(t, hookRef.hook, "filterResolvable");
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       private boolean isBootInit() {
/* 267 */         Module.State systemModuleState = (this.systemModule == null) ? Module.State.UNINSTALLED : this.systemModule.getState();
/* 268 */         return !(Module.RESOLVED_SET.contains(systemModuleState) && !systemModuleState.equals(Module.State.RESOLVED) && (
/* 269 */           !systemModuleState.equals(Module.State.STARTING) || !OSGiFrameworkHooks.CoreResolverHookFactory.this.inInit));
/*     */       }
/*     */ 
/*     */       
/*     */       public void filterSingletonCollisions(BundleCapability singleton, Collection<BundleCapability> collisionCandidates) {
/* 274 */         if (OSGiFrameworkHooks.CoreResolverHookFactory.this.debug.DEBUG_HOOKS) {
/* 275 */           Debug.println("ResolverHook.filterSingletonCollisions(" + singleton + ", " + collisionCandidates + ")");
/*     */         }
/* 277 */         if (this.hooks.isEmpty())
/*     */           return; 
/* 279 */         ShrinkableCollection shrinkableCollection = new ShrinkableCollection(collisionCandidates);
/* 280 */         for (OSGiFrameworkHooks.CoreResolverHookFactory.HookReference hookRef : this.hooks) {
/* 281 */           if (hookRef.reference.getBundle() == null) {
/* 282 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(null, hookRef.hook, "filterSingletonCollisions"); continue;
/*     */           } 
/*     */           try {
/* 285 */             hookRef.hook.filterSingletonCollisions(singleton, (Collection)shrinkableCollection);
/* 286 */           } catch (Throwable t) {
/* 287 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(t, hookRef.hook, "filterSingletonCollisions");
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void filterMatches(BundleRequirement requirement, Collection<BundleCapability> candidates) {
/* 295 */         if (OSGiFrameworkHooks.CoreResolverHookFactory.this.debug.DEBUG_HOOKS) {
/* 296 */           Debug.println("ResolverHook.filterMatches(" + requirement + ", " + candidates + ")");
/*     */         }
/* 298 */         if (this.hooks.isEmpty())
/*     */           return; 
/* 300 */         ShrinkableCollection shrinkableCollection = new ShrinkableCollection(candidates);
/* 301 */         for (OSGiFrameworkHooks.CoreResolverHookFactory.HookReference hookRef : this.hooks) {
/* 302 */           if (hookRef.reference.getBundle() == null) {
/* 303 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(null, hookRef.hook, "filterMatches"); continue;
/*     */           } 
/*     */           try {
/* 306 */             hookRef.hook.filterMatches(requirement, (Collection)shrinkableCollection);
/* 307 */           } catch (Throwable t) {
/* 308 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(t, hookRef.hook, "filterMatches");
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void end() {
/* 316 */         if (OSGiFrameworkHooks.CoreResolverHookFactory.this.debug.DEBUG_HOOKS) {
/* 317 */           Debug.println("ResolverHook.end");
/*     */         }
/* 319 */         if (this.hooks.isEmpty())
/*     */           return; 
/*     */         try {
/* 322 */           OSGiFrameworkHooks.CoreResolverHookFactory.HookReference missingHook = null;
/* 323 */           Throwable endError = null;
/* 324 */           OSGiFrameworkHooks.CoreResolverHookFactory.HookReference endBadHook = null;
/* 325 */           for (OSGiFrameworkHooks.CoreResolverHookFactory.HookReference hookRef : this.hooks) {
/*     */             
/* 327 */             if (hookRef.reference.getBundle() == null) {
/* 328 */               if (missingHook == null)
/* 329 */                 missingHook = hookRef;  continue;
/*     */             } 
/*     */             try {
/* 332 */               if (hookRef.hook instanceof ResolutionReport.Listener)
/* 333 */                 ((ResolutionReport.Listener)hookRef.hook).handleResolutionReport(this.resolutionReport); 
/* 334 */               hookRef.hook.end();
/* 335 */             } catch (Throwable t) {
/*     */ 
/*     */               
/* 338 */               if (endError == null) {
/* 339 */                 endError = t;
/* 340 */                 endBadHook = hookRef;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 345 */           if (missingHook != null)
/* 346 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(null, missingHook.hook, "end"); 
/* 347 */           if (endError != null)
/* 348 */             OSGiFrameworkHooks.CoreResolverHookFactory.this.handleHookException(endError, endBadHook.hook, "end"); 
/*     */         } finally {
/* 350 */           for (OSGiFrameworkHooks.CoreResolverHookFactory.HookReference hookRef : this.hooks) {
/* 351 */             hookRef.context.ungetService((ServiceReference<?>)hookRef.reference);
/*     */           }
/* 353 */           this.hooks.clear();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public void handleResolutionReport(ResolutionReport report) {
/* 359 */         this.resolutionReport = report;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void initBegin() {
/* 365 */     this.resolverHookFactory.inInit = true;
/*     */   }
/*     */   
/*     */   public void initEnd() {
/* 369 */     this.resolverHookFactory.inInit = false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\OSGiFrameworkHooks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */