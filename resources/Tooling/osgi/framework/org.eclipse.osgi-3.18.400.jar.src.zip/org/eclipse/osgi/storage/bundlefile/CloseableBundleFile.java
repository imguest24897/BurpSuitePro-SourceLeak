/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CloseableBundleFile<E>
/*     */   extends BundleFile
/*     */ {
/*  47 */   private final ReentrantLock openLock = new ReentrantLock();
/*  48 */   private final Condition refCondition = this.openLock.newCondition();
/*     */ 
/*     */   
/*     */   private final MRUBundleFileList mruList;
/*     */ 
/*     */   
/*     */   protected final BundleInfo.Generation generation;
/*     */ 
/*     */   
/*     */   protected final Debug debug;
/*     */   
/*     */   private volatile boolean closed = true;
/*     */   
/*  61 */   private int referenceCount = 0;
/*     */   
/*     */   public CloseableBundleFile(File basefile, BundleInfo.Generation generation, MRUBundleFileList mruList, Debug debug) {
/*  64 */     super(basefile);
/*  65 */     this.debug = debug;
/*  66 */     this.generation = generation;
/*  67 */     this.closed = true;
/*  68 */     this.mruList = mruList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean lockOpen() {
/*  76 */     this.openLock.lock();
/*     */     try {
/*  78 */       internalOpen();
/*  79 */       return true;
/*  80 */     } catch (Throwable e) {
/*     */       
/*  82 */       this.openLock.unlock();
/*  83 */       if (this.generation != null) {
/*  84 */         ModuleRevision r = this.generation.getRevision();
/*  85 */         if (r != null) {
/*  86 */           ModuleContainerAdaptor.ContainerEvent eventType = ModuleContainerAdaptor.ContainerEvent.ERROR;
/*     */ 
/*     */           
/*  89 */           if (e instanceof IOException && !r.getRevisions().getModuleRevisions().contains(r))
/*     */           {
/*     */             
/*  92 */             eventType = ModuleContainerAdaptor.ContainerEvent.INFO;
/*     */           }
/*  94 */           this.generation.getBundleInfo().getStorage().getAdaptor().publishContainerEvent(eventType, r.getRevisions().getModule(), e, new org.osgi.framework.FrameworkListener[0]);
/*     */         } 
/*     */       } 
/*  97 */       if (!(e instanceof IOException))
/*     */       {
/*  99 */         EquinoxContainer.sneakyThrow(e);
/*     */       }
/*     */ 
/*     */       
/* 103 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void releaseOpen() {
/* 111 */     this.openLock.unlock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalOpen() throws IOException {
/* 120 */     if (this.closed) {
/* 121 */       boolean needBackPressure = mruListAdd();
/* 122 */       if (needBackPressure) {
/*     */         
/* 124 */         this.openLock.unlock();
/*     */         try {
/* 126 */           mruListApplyBackPressure();
/*     */         } finally {
/*     */           
/* 129 */           this.openLock.lock();
/*     */         } 
/*     */       } 
/*     */       
/* 133 */       if (this.closed) {
/*     */ 
/*     */         
/* 136 */         if (needBackPressure) {
/* 137 */           mruListAdd();
/*     */         }
/*     */         
/* 140 */         doOpen();
/* 141 */         this.closed = false;
/* 142 */         if (this.debug.DEBUG_BUNDLE_FILE_OPEN) {
/* 143 */           Debug.println("OPENED bundle file - " + toString());
/*     */         }
/*     */       } 
/*     */     } else {
/* 147 */       mruListUse();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doOpen() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File extractDirectory(String dirName) {
/* 165 */     if (!lockOpen()) {
/* 166 */       return null;
/*     */     }
/*     */     try {
/* 169 */       for (String path : getPaths()) {
/* 170 */         if (path.startsWith(dirName) && !path.endsWith("/"))
/* 171 */           getFile(path, false); 
/*     */       } 
/* 173 */       return getExtractFile(dirName);
/*     */     } finally {
/* 175 */       releaseOpen();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract Iterable<String> getPaths();
/*     */   
/*     */   private File getExtractFile(String entryName) {
/* 182 */     if (this.generation == null)
/* 183 */       return null; 
/* 184 */     return this.generation.getExtractFile(".cp", entryName);
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile(String entry, boolean nativeCode) {
/* 189 */     if (this.generation == null) {
/* 190 */       return null;
/*     */     }
/* 192 */     if (!lockOpen()) {
/* 193 */       return null;
/*     */     }
/*     */     
/* 196 */     try { BundleEntry bEntry = getEntry(entry);
/* 197 */       if (bEntry == null) {
/* 198 */         return null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       releaseOpen(); }  releaseOpen();
/*     */     
/* 237 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsDir(String dir) {
/* 242 */     if (!lockOpen()) {
/* 243 */       return false;
/*     */     }
/*     */     
/* 246 */     try { if (dir == null) {
/* 247 */         return false;
/*     */       }
/* 249 */       if (dir.length() == 0) {
/* 250 */         return true;
/*     */       }
/* 252 */       if (dir.charAt(0) == '/') {
/* 253 */         if (dir.length() == 1)
/* 254 */           return true; 
/* 255 */         dir = dir.substring(1);
/*     */       } 
/*     */       
/* 258 */       if (dir.length() > 0 && dir.charAt(dir.length() - 1) != '/') {
/* 259 */         dir = String.valueOf(dir) + '/';
/*     */       
/*     */       }
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/* 267 */       releaseOpen(); }  releaseOpen();
/*     */     
/* 269 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleEntry getEntry(String path) {
/* 274 */     if (!lockOpen()) {
/* 275 */       return null;
/*     */     }
/*     */     try {
/* 278 */       return findEntry(path);
/*     */     } finally {
/* 280 */       releaseOpen();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract BundleEntry findEntry(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path, boolean recurse) {
/* 293 */     if (!lockOpen()) {
/* 294 */       return null;
/*     */     }
/*     */     try {
/* 297 */       if (path == null) {
/* 298 */         throw new NullPointerException();
/*     */       }
/*     */       
/* 301 */       if (path.length() > 0 && path.charAt(0) == '/') {
/* 302 */         path = path.substring(1);
/*     */       }
/* 304 */       if (path.length() > 0 && path.charAt(path.length() - 1) != '/') {
/* 305 */         path = path + "/";
/*     */       }
/* 307 */       LinkedHashSet<String> result = new LinkedHashSet<>();
/*     */       
/* 309 */       for (String entryPath : getPaths()) {
/*     */ 
/*     */         
/* 312 */         if (entryPath.startsWith(path))
/*     */         {
/*     */           
/* 315 */           if (path.length() < entryPath.length())
/*     */           {
/* 317 */             getEntryPaths(path, entryPath.substring(path.length()), recurse, result);
/*     */           }
/*     */         }
/*     */       } 
/* 321 */       return (Enumeration)((result.size() == 0) ? null : Collections.<T>enumeration((Collection)result));
/*     */     } finally {
/* 323 */       releaseOpen();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void getEntryPaths(String path, String entry, boolean recurse, LinkedHashSet<String> entries) {
/* 328 */     if (entry.length() == 0)
/*     */       return; 
/* 330 */     int slash = entry.indexOf('/');
/* 331 */     if (slash == -1) {
/* 332 */       entries.add(String.valueOf(path) + entry);
/*     */     } else {
/* 334 */       path = String.valueOf(path) + entry.substring(0, slash + 1);
/* 335 */       entries.add(path);
/* 336 */       if (recurse) {
/* 337 */         getEntryPaths(path, entry.substring(slash + 1), true, entries);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 343 */     this.openLock.lock();
/*     */     try {
/* 345 */       if (!this.closed) {
/* 346 */         if (this.referenceCount > 0 && isMruListClosing()) {
/*     */ 
/*     */           
/*     */           try {
/* 350 */             this.refCondition.await(1000L, TimeUnit.MICROSECONDS);
/* 351 */           } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */           
/* 354 */           if (this.referenceCount != 0 || this.closed) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 361 */         this.closed = true;
/* 362 */         doClose();
/* 363 */         mruListRemove();
/* 364 */         postClose();
/* 365 */         if (this.debug.DEBUG_BUNDLE_FILE_CLOSE) {
/* 366 */           Debug.println("CLOSED bundle file - " + toString());
/*     */         }
/*     */       } 
/*     */     } finally {
/* 370 */       this.openLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doClose() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void postClose();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMruListClosing() {
/* 386 */     return (this.mruList != null && this.mruList.isClosing(this));
/*     */   }
/*     */   
/*     */   private boolean isMruEnabled() {
/* 390 */     return (this.mruList != null && this.mruList.isEnabled());
/*     */   }
/*     */   
/*     */   private void mruListRemove() {
/* 394 */     if (this.mruList != null) {
/* 395 */       this.mruList.remove(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void mruListUse() {
/* 400 */     if (this.mruList != null) {
/* 401 */       this.mruList.use(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void mruListApplyBackPressure() {
/* 406 */     if (this.mruList != null) {
/* 407 */       this.mruList.applyBackpressure();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean mruListAdd() {
/* 412 */     if (this.mruList != null) {
/* 413 */       return this.mruList.add(this);
/*     */     }
/* 415 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws IOException {
/* 420 */     this.openLock.lock();
/*     */     try {
/* 422 */       internalOpen();
/*     */     } finally {
/* 424 */       this.openLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void incrementReference() {
/* 429 */     this.openLock.lock();
/*     */     try {
/* 431 */       this.referenceCount++;
/*     */     } finally {
/* 433 */       this.openLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void decrementReference() {
/* 438 */     this.openLock.lock();
/*     */     try {
/* 440 */       this.referenceCount = Math.max(0, this.referenceCount - 1);
/*     */       
/* 442 */       if (this.referenceCount == 0)
/* 443 */         this.refCondition.signal(); 
/*     */     } finally {
/* 445 */       this.openLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream(E entry) throws IOException {
/* 463 */     if (!lockOpen()) {
/* 464 */       throw new IOException("Failed to lock bundle file.");
/*     */     }
/*     */     try {
/* 467 */       InputStream in = doGetInputStream(entry);
/* 468 */       if (isMruEnabled()) {
/* 469 */         in = new BundleEntryInputStream(in);
/*     */       }
/* 471 */       return in;
/*     */     } finally {
/* 473 */       releaseOpen();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract InputStream doGetInputStream(E paramE) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   private class BundleEntryInputStream
/*     */     extends FilterInputStream
/*     */   {
/*     */     private boolean streamClosed = false;
/*     */ 
/*     */ 
/*     */     
/*     */     public BundleEntryInputStream(InputStream stream) {
/* 491 */       super(stream);
/* 492 */       CloseableBundleFile.this.incrementReference();
/*     */     }
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/*     */       try {
/* 498 */         return super.available();
/* 499 */       } catch (IOException e) {
/* 500 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/*     */       try {
/* 507 */         super.close();
/* 508 */       } catch (IOException e) {
/* 509 */         throw enrichExceptionWithBaseFile(e);
/*     */       } finally {
/* 511 */         synchronized (this) {
/* 512 */           if (this.streamClosed)
/*     */             return; 
/* 514 */           this.streamClosed = true;
/*     */         } 
/* 516 */         CloseableBundleFile.this.decrementReference();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/*     */       try {
/* 523 */         return super.read();
/* 524 */       } catch (IOException e) {
/* 525 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] var0, int var1, int var2) throws IOException {
/*     */       try {
/* 532 */         return super.read(var0, var1, var2);
/* 533 */       } catch (IOException e) {
/* 534 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] var0) throws IOException {
/*     */       try {
/* 541 */         return super.read(var0);
/* 542 */       } catch (IOException e) {
/* 543 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset() throws IOException {
/*     */       try {
/* 550 */         super.reset();
/* 551 */       } catch (IOException e) {
/* 552 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long var0) throws IOException {
/*     */       try {
/* 559 */         return super.skip(var0);
/* 560 */       } catch (IOException e) {
/* 561 */         throw enrichExceptionWithBaseFile(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     private IOException enrichExceptionWithBaseFile(IOException e) {
/* 566 */       File baseFile = CloseableBundleFile.this.getBaseFile();
/* 567 */       String extraInfo = (baseFile == null) ? (
/* 568 */         (CloseableBundleFile.this.generation == null) ? null : CloseableBundleFile.this.generation.getBundleInfo().getLocation()) : 
/* 569 */         baseFile.toString();
/* 570 */       return new IOException(extraInfo, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\CloseableBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */