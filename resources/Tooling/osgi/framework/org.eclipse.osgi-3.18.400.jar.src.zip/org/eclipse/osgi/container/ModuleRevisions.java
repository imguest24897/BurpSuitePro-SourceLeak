/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleRevisions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleRevisions
/*     */   implements BundleRevisions
/*     */ {
/*  32 */   private final Object monitor = new Object();
/*     */   
/*     */   private final Module module;
/*     */   private final ModuleContainer container;
/*  36 */   private final List<ModuleRevision> revisions = new ArrayList<>(1);
/*     */   
/*     */   private boolean uninstalled = false;
/*     */   
/*     */   private ModuleRevision uninstalledCurrent;
/*     */   
/*     */   ModuleRevisions(Module module, ModuleContainer container) {
/*  43 */     this.module = module;
/*  44 */     this.container = container;
/*     */   }
/*     */   
/*     */   public Module getModule() {
/*  48 */     return this.module;
/*     */   }
/*     */   
/*     */   ModuleContainer getContainer() {
/*  52 */     return this.container;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/*  57 */     return this.module.getBundle();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleRevision> getRevisions() {
/*  62 */     synchronized (this.monitor) {
/*  63 */       return new ArrayList<>((Collection)this.revisions);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleRevision> getModuleRevisions() {
/*  73 */     synchronized (this.monitor) {
/*  74 */       return new ArrayList<>(this.revisions);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleRevision getCurrentRevision() {
/*  85 */     synchronized (this.monitor) {
/*  86 */       if (this.uninstalled) {
/*  87 */         return this.uninstalledCurrent;
/*     */       }
/*  89 */       if (this.revisions.isEmpty()) {
/*  90 */         return null;
/*     */       }
/*  92 */       return this.revisions.get(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   ModuleRevision addRevision(ModuleRevision revision) {
/*  97 */     synchronized (this.monitor) {
/*  98 */       this.revisions.add(0, revision);
/*     */     } 
/* 100 */     return revision;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean removeRevision(ModuleRevision revision) {
/*     */     try {
/*     */     
/*     */     } finally {
/* 109 */       this.module.cleanup(revision);
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isUninstalled() {
/* 114 */     synchronized (this.monitor) {
/* 115 */       return this.uninstalled;
/*     */     } 
/*     */   }
/*     */   
/*     */   void uninstall() {
/* 120 */     synchronized (this.monitor) {
/* 121 */       this.uninstalled = true;
/*     */       
/* 123 */       if (this.revisions.isEmpty()) {
/* 124 */         throw new IllegalStateException("Revisions is empty on uninstall! " + this.module);
/*     */       }
/* 126 */       this.uninstalledCurrent = this.revisions.get(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return "moduleID=" + this.module.getId();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleRevisions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */