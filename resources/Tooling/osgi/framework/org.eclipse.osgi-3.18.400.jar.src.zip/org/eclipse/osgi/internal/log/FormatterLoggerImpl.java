/*    */ package org.eclipse.osgi.internal.log;
/*    */ 
/*    */ import org.osgi.service.log.FormatterLogger;
/*    */ import org.osgi.service.log.admin.LoggerContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatterLoggerImpl
/*    */   extends LoggerImpl
/*    */   implements FormatterLogger
/*    */ {
/*    */   public FormatterLoggerImpl(ExtendedLogServiceImpl logServiceImpl, String name, LoggerContext loggerContext) {
/* 18 */     super(logServiceImpl, name, loggerContext);
/*    */   }
/*    */ 
/*    */   
/*    */   String formatMessage(String format, Arguments processedArguments) {
/* 23 */     return String.format(format, processedArguments.arguments());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\FormatterLoggerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */