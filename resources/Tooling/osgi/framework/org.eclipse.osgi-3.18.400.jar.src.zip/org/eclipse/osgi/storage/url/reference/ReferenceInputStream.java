/*    */ package org.eclipse.osgi.storage.url.reference;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.eclipse.osgi.storage.ContentProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferenceInputStream
/*    */   extends InputStream
/*    */   implements ContentProvider
/*    */ {
/*    */   private final File reference;
/*    */   
/*    */   public ReferenceInputStream(File reference) {
/* 30 */     this.reference = reference;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 37 */     throw new IOException();
/*    */   }
/*    */   
/*    */   public File getReference() {
/* 41 */     return getContent();
/*    */   }
/*    */ 
/*    */   
/*    */   public File getContent() {
/* 46 */     return this.reference;
/*    */   }
/*    */ 
/*    */   
/*    */   public ContentProvider.Type getType() {
/* 51 */     return ContentProvider.Type.REFERENCE;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\reference\ReferenceInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */