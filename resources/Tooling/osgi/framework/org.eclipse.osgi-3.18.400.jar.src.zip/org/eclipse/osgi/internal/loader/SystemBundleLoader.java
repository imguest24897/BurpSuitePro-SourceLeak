/*     */ package org.eclipse.osgi.internal.loader;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemBundleLoader
/*     */   extends BundleLoader
/*     */ {
/*     */   public static final String EQUINOX_EE = "x-equinox-ee";
/*     */   final ClassLoader classLoader;
/*     */   final ModuleClassLoader moduleClassLoader;
/*     */   
/*     */   public SystemBundleLoader(ModuleWiring wiring, EquinoxContainer container, ClassLoader frameworkLoader) {
/*  40 */     super(wiring, container, frameworkLoader.getParent());
/*  41 */     this.classLoader = frameworkLoader;
/*  42 */     this.moduleClassLoader = new SystemModuleClassLoader(this.classLoader.getParent(), container.getConfiguration(), this, (BundleInfo.Generation)wiring.getRevision().getRevisionInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findClass(String name) throws ClassNotFoundException {
/*  51 */     Class<?> result = findLocalClass(name);
/*  52 */     if (result == null)
/*  53 */       throw new ClassNotFoundException(name); 
/*  54 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findLocalClass(String name) {
/*     */     try {
/*  63 */       return this.classLoader.loadClass(name);
/*  64 */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       
/*  66 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findLocalResource(String name) {
/*  75 */     return this.classLoader.getResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> findLocalResources(String name) {
/*     */     try {
/*  84 */       return this.classLoader.getResources(name);
/*  85 */     } catch (IOException iOException) {
/*     */       
/*  87 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findResource(String name) {
/*  97 */     return findLocalResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> findResources(String name) throws IOException {
/* 107 */     return findLocalResources(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 112 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleClassLoader getModuleClassLoader() {
/* 117 */     return this.moduleClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   void loadClassLoaderFragments(Collection<ModuleRevision> fragments) {
/* 122 */     this.moduleClassLoader.loadFragments(fragments);
/*     */   }
/*     */   
/*     */   class SystemModuleClassLoader
/*     */     extends EquinoxClassLoader {
/*     */     public SystemModuleClassLoader(ClassLoader parent, EquinoxConfiguration configuration, BundleLoader delegate, BundleInfo.Generation generation) {
/* 128 */       super(parent, configuration, delegate, generation);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 133 */       return SystemBundleLoader.this.findClass(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public void loadFragments(Collection<ModuleRevision> fragments) {
/* 138 */       Module systemModule = SystemBundleLoader.this.getWiring().getRevision().getRevisions().getModule();
/*     */       try {
/* 140 */         getGeneration().getBundleInfo().getStorage().getExtensionInstaller().addExtensionContent(fragments, systemModule);
/* 141 */       } catch (BundleException e) {
/* 142 */         systemModule.getContainer().getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, systemModule, (Throwable)e, new org.osgi.framework.FrameworkListener[0]);
/*     */       } 
/* 144 */       getClasspathManager().loadFragments(fragments);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\SystemBundleLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */