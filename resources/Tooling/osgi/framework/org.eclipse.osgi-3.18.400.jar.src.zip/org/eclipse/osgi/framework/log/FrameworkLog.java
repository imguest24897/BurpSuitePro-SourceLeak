package org.eclipse.osgi.framework.log;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import org.osgi.framework.FrameworkEvent;

public interface FrameworkLog {
  public static final String SERVICE_PERFORMANCE = "performance";
  
  void log(FrameworkEvent paramFrameworkEvent);
  
  void log(FrameworkLogEntry paramFrameworkLogEntry);
  
  void setWriter(Writer paramWriter, boolean paramBoolean);
  
  void setFile(File paramFile, boolean paramBoolean) throws IOException;
  
  File getFile();
  
  void setConsoleLog(boolean paramBoolean);
  
  void close();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\log\FrameworkLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */