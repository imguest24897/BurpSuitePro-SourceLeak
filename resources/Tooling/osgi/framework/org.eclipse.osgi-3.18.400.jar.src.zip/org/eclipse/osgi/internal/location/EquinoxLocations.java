/*     */ package org.eclipse.osgi.internal.location;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.storage.StorageUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxLocations
/*     */ {
/*     */   public static final String READ_ONLY_AREA_SUFFIX = ".readOnly";
/*     */   public static final String PROP_INSTALL_AREA = "osgi.install.area";
/*     */   public static final String PROP_CONFIG_AREA = "osgi.configuration.area";
/*     */   public static final String PROP_CONFIG_AREA_DEFAULT = "osgi.configuration.area.default";
/*     */   public static final String PROP_SHARED_CONFIG_AREA = "osgi.sharedConfiguration.area";
/*     */   public static final String PROP_INSTANCE_AREA = "osgi.instance.area";
/*     */   public static final String PROP_INSTANCE_AREA_DEFAULT = "osgi.instance.area.default";
/*     */   public static final String PROP_USER_AREA = "osgi.user.area";
/*     */   public static final String PROP_USER_AREA_DEFAULT = "osgi.user.area.default";
/*     */   public static final String PROP_USER_HOME = "user.home";
/*     */   public static final String PROP_USER_DIR = "user.dir";
/*     */   public static final String PROP_HOME_LOCATION_AREA = "eclipse.home.location";
/*     */   public static final String PROP_LAUNCHER = "eclipse.launcher";
/*     */   private static final String ECLIPSE = "eclipse";
/*     */   private static final String PRODUCT_SITE_MARKER = ".eclipseproduct";
/*     */   private static final String PRODUCT_SITE_ID = "id";
/*     */   private static final String PRODUCT_SITE_VERSION = "version";
/*     */   private static final String CONFIG_DIR = "configuration";
/*     */   private static final String NONE = "@none";
/*     */   private static final String NO_DEFAULT = "@noDefault";
/*     */   private static final String USER_HOME = "@user.home";
/*     */   private static final String USER_DIR = "@user.dir";
/*     */   private static final String INSTALL_HASH_PLACEHOLDER = "@install.hash";
/*     */   private static final String INSTANCE_DATA_AREA_PREFIX = ".metadata/.plugins/";
/*     */   private final EquinoxConfiguration.ConfigValues equinoxConfig;
/*     */   private final EquinoxContainer container;
/*     */   private final AtomicBoolean debugLocations;
/*     */   private final BasicLocation installLocation;
/*     */   private final BasicLocation configurationLocation;
/*     */   private final BasicLocation userLocation;
/*     */   private final BasicLocation instanceLocation;
/*     */   private final BasicLocation eclipseHomeLocation;
/*     */   
/*     */   public EquinoxLocations(EquinoxConfiguration.ConfigValues equinoxConfig, EquinoxContainer container, AtomicBoolean debugLocations, Map<Throwable, Integer> exceptions) {
/*  81 */     this.equinoxConfig = equinoxConfig;
/*  82 */     this.container = container;
/*  83 */     this.debugLocations = debugLocations;
/*     */ 
/*     */ 
/*     */     
/*  87 */     String osgiStorage = equinoxConfig.getConfiguration("org.osgi.framework.storage");
/*  88 */     if (osgiStorage != null) {
/*  89 */       if (equinoxConfig.getConfiguration("osgi.configuration.area") != null) {
/*  90 */         exceptions.put(new IllegalArgumentException(String.format(
/*  91 */                 "The property '%s' with the value '%s' is being overriden by the OSGi standard configuration property '%s' with the value '%s'.", new Object[] {
/*  92 */                   "osgi.configuration.area", equinoxConfig.getConfiguration("osgi.configuration.area"), "org.osgi.framework.storage", osgiStorage })), Integer.valueOf(2));
/*     */       }
/*  94 */       equinoxConfig.setConfiguration("osgi.configuration.area", osgiStorage);
/*     */     } 
/*     */ 
/*     */     
/*  98 */     this.installLocation = buildLocation("osgi.install.area", null, "", true, false, null);
/*     */ 
/*     */     
/* 101 */     Location temp = buildLocation("osgi.user.area.default", null, "", false, false, null);
/* 102 */     URL defaultLocation = (temp == null) ? null : temp.getURL();
/* 103 */     if (defaultLocation == null)
/* 104 */       defaultLocation = buildURL((new File(System.getProperty("user.home"), "user")).getAbsolutePath(), true); 
/* 105 */     this.userLocation = buildLocation("osgi.user.area", defaultLocation, "", false, false, null);
/*     */     
/* 107 */     temp = buildLocation("osgi.instance.area.default", null, "", false, false, ".metadata/.plugins/");
/* 108 */     defaultLocation = (temp == null) ? null : temp.getURL();
/* 109 */     if (defaultLocation == null)
/* 110 */       defaultLocation = buildURL((new File(System.getProperty("user.dir"), "workspace")).getAbsolutePath(), true); 
/* 111 */     this.instanceLocation = buildLocation("osgi.instance.area", defaultLocation, "", false, false, ".metadata/.plugins/");
/*     */     
/* 113 */     mungeConfigurationLocation();
/*     */     
/* 115 */     temp = buildLocation("osgi.configuration.area.default", null, "", false, false, null);
/* 116 */     defaultLocation = (temp == null) ? null : temp.getURL();
/* 117 */     if (defaultLocation == null && equinoxConfig.getConfiguration("osgi.configuration.area") == null)
/*     */     {
/* 119 */       defaultLocation = buildURL(computeDefaultConfigurationLocation(), true); } 
/* 120 */     this.configurationLocation = buildLocation("osgi.configuration.area", defaultLocation, "", false, false, null);
/*     */ 
/*     */ 
/*     */     
/* 124 */     URL parentLocation = computeSharedConfigurationLocation();
/* 125 */     if (parentLocation != null && !parentLocation.equals(this.configurationLocation.getURL())) {
/* 126 */       Location parent = new BasicLocation(null, parentLocation, true, null, equinoxConfig, container, debugLocations);
/* 127 */       this.configurationLocation.setParent(parent);
/*     */     } 
/*     */     
/* 130 */     if (equinoxConfig.getConfiguration("eclipse.home.location") == null) {
/* 131 */       String eclipseLauncher = equinoxConfig.getConfiguration("eclipse.launcher");
/* 132 */       String eclipseHomeLocationPath = getEclipseHomeLocation(eclipseLauncher, equinoxConfig);
/* 133 */       if (eclipseHomeLocationPath != null) {
/* 134 */         equinoxConfig.setConfiguration("eclipse.home.location", eclipseHomeLocationPath);
/*     */       }
/*     */     } 
/* 137 */     if (equinoxConfig.getConfiguration("eclipse.home.location") == null && equinoxConfig.getConfiguration("osgi.install.area") != null)
/* 138 */       equinoxConfig.setConfiguration("eclipse.home.location", equinoxConfig.getConfiguration("osgi.install.area")); 
/* 139 */     this.eclipseHomeLocation = buildLocation("eclipse.home.location", null, "", true, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL buildURL(String spec, boolean trailingSlash) {
/* 149 */     return LocationHelper.buildURL(spec, trailingSlash);
/*     */   }
/*     */ 
/*     */   
/*     */   private void mungeConfigurationLocation() {
/* 154 */     String location = this.equinoxConfig.getConfiguration("osgi.configuration.area");
/* 155 */     if (location != null && 
/* 156 */       location.endsWith(".cfg")) {
/* 157 */       int index = location.lastIndexOf('/');
/* 158 */       if (index < 0)
/* 159 */         index = location.lastIndexOf('\\'); 
/* 160 */       location = location.substring(0, index + 1);
/* 161 */       this.equinoxConfig.setConfiguration("osgi.configuration.area", location);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getEclipseHomeLocation(String launcher, EquinoxConfiguration.ConfigValues configValues) {
/* 167 */     if (launcher == null)
/* 168 */       return null; 
/* 169 */     File launcherFile = new File(launcher);
/* 170 */     if (launcherFile.getParent() == null)
/* 171 */       return null; 
/* 172 */     File launcherDir = new File(launcherFile.getParent());
/*     */     
/* 174 */     String macosx = "macosx";
/* 175 */     if (macosx.equals(configValues.getConfiguration("osgi.os")))
/* 176 */       launcherDir = getMacOSEclipseHomeLocation(launcherDir); 
/* 177 */     return (launcherDir.exists() && launcherDir.isDirectory()) ? launcherDir.getAbsolutePath() : null;
/*     */   }
/*     */   
/*     */   private static File getMacOSEclipseHomeLocation(File launcherDir) {
/* 181 */     if (!launcherDir.getName().equalsIgnoreCase("macos"))
/* 182 */       return launcherDir; 
/* 183 */     return new File(launcherDir.getParent(), "Eclipse");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BasicLocation buildLocation(String property, URL defaultLocation, String userDefaultAppendage, boolean readOnlyDefault, boolean computeReadOnly, String dataAreaPrefix) {
/* 189 */     String location = this.equinoxConfig.clearConfiguration(property);
/*     */     
/* 191 */     String userReadOnlySetting = this.equinoxConfig.getConfiguration(String.valueOf(property) + ".readOnly");
/* 192 */     boolean readOnly = (userReadOnlySetting == null) ? readOnlyDefault : Boolean.valueOf(userReadOnlySetting).booleanValue();
/*     */ 
/*     */     
/* 195 */     if (location == null)
/* 196 */       return new BasicLocation(property, defaultLocation, (userReadOnlySetting != null || !computeReadOnly) ? readOnly : (!canWrite(defaultLocation)), dataAreaPrefix, this.equinoxConfig, this.container, this.debugLocations); 
/* 197 */     String trimmedLocation = location.trim();
/* 198 */     if (trimmedLocation.equalsIgnoreCase("@none"))
/* 199 */       return null; 
/* 200 */     if (trimmedLocation.equalsIgnoreCase("@noDefault"))
/* 201 */       return new BasicLocation(property, null, readOnly, dataAreaPrefix, this.equinoxConfig, this.container, this.debugLocations); 
/* 202 */     if (trimmedLocation.startsWith("@user.home")) {
/* 203 */       String base = substituteVar(location, "@user.home", "user.home");
/* 204 */       location = (new File(base, userDefaultAppendage)).getAbsolutePath();
/* 205 */     } else if (trimmedLocation.startsWith("@user.dir")) {
/* 206 */       String base = substituteVar(location, "@user.dir", "user.dir");
/* 207 */       location = (new File(base, userDefaultAppendage)).getAbsolutePath();
/*     */     } 
/* 209 */     int idx = location.indexOf("@install.hash");
/* 210 */     if (idx == 0)
/* 211 */       throw new RuntimeException("The location cannot start with '@install.hash': " + location); 
/* 212 */     if (idx > 0) {
/* 213 */       location = String.valueOf(location.substring(0, idx)) + getInstallDirHash() + location.substring(idx + "@install.hash".length());
/*     */     }
/* 215 */     URL url = buildURL(location, true);
/* 216 */     BasicLocation result = null;
/* 217 */     if (url != null) {
/* 218 */       result = new BasicLocation(property, null, (userReadOnlySetting != null || !computeReadOnly) ? readOnly : (!canWrite(url)), dataAreaPrefix, this.equinoxConfig, this.container, this.debugLocations);
/* 219 */       result.setURL(url, false);
/*     */     } 
/* 221 */     return result;
/*     */   }
/*     */   
/*     */   private String substituteVar(String source, String var, String prop) {
/* 225 */     String value = this.equinoxConfig.getConfiguration(prop, "");
/* 226 */     return String.valueOf(value) + source.substring(var.length());
/*     */   }
/*     */   
/*     */   private URL computeInstallConfigurationLocation() {
/* 230 */     String property = this.equinoxConfig.getConfiguration("osgi.install.area");
/* 231 */     if (property != null)
/* 232 */       return LocationHelper.buildURL(property, true); 
/* 233 */     return null;
/*     */   }
/*     */   
/*     */   private URL computeSharedConfigurationLocation() {
/* 237 */     String property = this.equinoxConfig.getConfiguration("osgi.sharedConfiguration.area");
/* 238 */     if (property == null)
/* 239 */       return null; 
/*     */     try {
/* 241 */       URL sharedConfigurationURL = LocationHelper.buildURL(property, true);
/* 242 */       if (sharedConfigurationURL == null)
/* 243 */         return null; 
/* 244 */       if (sharedConfigurationURL.getPath().startsWith("/"))
/*     */       {
/* 246 */         return sharedConfigurationURL; } 
/* 247 */       URL installURL = this.installLocation.getURL();
/* 248 */       if (!sharedConfigurationURL.getProtocol().equals(installURL.getProtocol()))
/*     */       {
/* 250 */         return sharedConfigurationURL; } 
/* 251 */       sharedConfigurationURL = new URL(installURL, sharedConfigurationURL.getPath());
/* 252 */       this.equinoxConfig.setConfiguration("osgi.sharedConfiguration.area", sharedConfigurationURL.toExternalForm());
/* 253 */     } catch (MalformedURLException malformedURLException) {}
/*     */ 
/*     */     
/* 256 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String computeDefaultConfigurationLocation() {
/* 267 */     URL installURL = computeInstallConfigurationLocation();
/* 268 */     if (installURL != null && "file".equals(installURL.getProtocol())) {
/* 269 */       File installDir = new File(installURL.getPath());
/* 270 */       File defaultConfigDir = new File(installDir, "configuration");
/* 271 */       if (!defaultConfigDir.exists())
/* 272 */         defaultConfigDir.mkdirs(); 
/* 273 */       if (defaultConfigDir.exists() && StorageUtil.canWrite(defaultConfigDir)) {
/* 274 */         return defaultConfigDir.getAbsolutePath();
/*     */       }
/*     */     } 
/* 277 */     return computeDefaultUserAreaLocation("configuration");
/*     */   }
/*     */   
/*     */   private static boolean canWrite(URL location) {
/* 281 */     if (location != null && "file".equals(location.getProtocol())) {
/* 282 */       File locationDir = new File(location.getPath());
/* 283 */       if (!locationDir.exists())
/* 284 */         locationDir.mkdirs(); 
/* 285 */       if (locationDir.exists() && StorageUtil.canWrite(locationDir))
/* 286 */         return true; 
/*     */     } 
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String computeDefaultUserAreaLocation(String pathAppendage) {
/* 296 */     String installProperty = this.equinoxConfig.getConfiguration("osgi.install.area");
/* 297 */     URL installURL = buildURL(installProperty, true);
/* 298 */     if (installURL == null)
/* 299 */       return null; 
/* 300 */     File installDir = new File(installURL.getPath());
/* 301 */     String installDirHash = getInstallDirHash();
/*     */     
/* 303 */     String appName = ".eclipse";
/* 304 */     File eclipseProduct = new File(installDir, ".eclipseproduct");
/* 305 */     if (eclipseProduct.exists()) {
/* 306 */       Properties props = new Properties();
/*     */       try {
/* 308 */         props.load(new FileInputStream(eclipseProduct));
/* 309 */         String appId = props.getProperty("id");
/* 310 */         if (appId == null || appId.trim().length() == 0)
/* 311 */           appId = "eclipse"; 
/* 312 */         String appVersion = props.getProperty("version");
/* 313 */         if (appVersion == null || appVersion.trim().length() == 0)
/* 314 */           appVersion = ""; 
/* 315 */         appName = String.valueOf(appName) + File.separator + appId + "_" + appVersion + "_" + installDirHash;
/* 316 */       } catch (IOException iOException) {
/*     */ 
/*     */ 
/*     */         
/* 320 */         appName = String.valueOf(appName) + File.separator + installDirHash;
/*     */       } 
/*     */     } else {
/*     */       
/* 324 */       appName = String.valueOf(appName) + File.separator + installDirHash;
/*     */     } 
/* 326 */     String userHome = System.getProperty("user.home");
/* 327 */     return (new File(userHome, String.valueOf(appName) + "/" + pathAppendage)).getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getInstallDirHash() {
/*     */     int hashCode;
/* 336 */     String installProperty = this.equinoxConfig.getConfiguration("osgi.install.area");
/* 337 */     URL installURL = buildURL(installProperty, true);
/* 338 */     if (installURL == null)
/* 339 */       return ""; 
/* 340 */     File installDir = new File(installURL.getPath());
/*     */     
/*     */     try {
/* 343 */       hashCode = installDir.getCanonicalPath().hashCode();
/* 344 */     } catch (IOException iOException) {
/*     */       
/* 346 */       hashCode = installDir.getAbsolutePath().hashCode();
/*     */     } 
/* 348 */     if (hashCode < 0)
/* 349 */       hashCode = -hashCode; 
/* 350 */     String installDirHash = String.valueOf(hashCode);
/* 351 */     return installDirHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicLocation getUserLocation() {
/* 359 */     return this.userLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicLocation getConfigurationLocation() {
/* 367 */     return this.configurationLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicLocation getInstallLocation() {
/* 375 */     return this.installLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicLocation getInstanceLocation() {
/* 383 */     return this.instanceLocation;
/*     */   }
/*     */   
/*     */   public BasicLocation getEclipseHomeLocation() {
/* 387 */     return this.eclipseHomeLocation;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\EquinoxLocations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */