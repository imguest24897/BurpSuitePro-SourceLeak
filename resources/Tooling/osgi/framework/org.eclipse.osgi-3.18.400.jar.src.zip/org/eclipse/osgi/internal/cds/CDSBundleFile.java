/*     */ package org.eclipse.osgi.internal.cds;
/*     */ 
/*     */ import com.ibm.oti.shared.SharedClassURLHelper;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CDSBundleFile
/*     */   extends BundleFileWrapper
/*     */ {
/*     */   private static final String classFileExt = ".class";
/*     */   private final URL url;
/*     */   private SharedClassURLHelper urlHelper;
/*     */   private boolean primed = false;
/*     */   
/*     */   public CDSBundleFile(BundleFile wrapped) {
/*  47 */     super(wrapped);
/*     */     
/*  49 */     URL content = null;
/*     */     try {
/*  51 */       content = new URL("file", "", wrapped.getBaseFile().getAbsolutePath());
/*  52 */     } catch (MalformedURLException malformedURLException) {}
/*     */ 
/*     */     
/*  55 */     this.url = content;
/*     */   }
/*     */   
/*     */   public CDSBundleFile(BundleFile bundleFile, SharedClassURLHelper urlHelper) {
/*  59 */     this(bundleFile);
/*  60 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleEntry getEntry(String path) {
/*  74 */     if (!this.primed || !path.endsWith(".class")) {
/*  75 */       return super.getEntry(path);
/*     */     }
/*  77 */     byte[] classbytes = getClassBytes(path.substring(0, path.length() - ".class".length()));
/*  78 */     if (classbytes == null) {
/*  79 */       return super.getEntry(path);
/*     */     }
/*     */     
/*  82 */     BundleEntry be = new CDSBundleEntry(path, classbytes, this);
/*  83 */     return be;
/*     */   }
/*     */   
/*     */   BundleEntry getWrappedEntry(String path) {
/*  87 */     return super.getEntry(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   URL getURL() {
/*  95 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SharedClassURLHelper getURLHelper() {
/* 104 */     return this.urlHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setURLHelper(SharedClassURLHelper urlHelper) {
/* 113 */     this.urlHelper = urlHelper;
/* 114 */     this.primed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPrimed(boolean primed) {
/* 124 */     this.primed = primed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getClassBytes(String name) {
/* 133 */     if (this.urlHelper == null || this.url == null)
/* 134 */       return null; 
/* 135 */     return this.urlHelper.findSharedClass(null, this.url, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPrimed() {
/* 143 */     return this.primed;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\cds\CDSBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */