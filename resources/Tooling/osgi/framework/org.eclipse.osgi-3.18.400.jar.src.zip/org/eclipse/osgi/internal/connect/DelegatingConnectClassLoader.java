/*    */ package org.eclipse.osgi.internal.connect;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*    */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*    */ import org.eclipse.osgi.internal.loader.EquinoxClassLoader;
/*    */ import org.eclipse.osgi.storage.BundleInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingConnectClassLoader
/*    */   extends EquinoxClassLoader
/*    */ {
/*    */   private final ClassLoader connectClassLoader;
/*    */   
/*    */   static {
/*    */     try {
/* 28 */       ClassLoader.registerAsParallelCapable();
/* 29 */     } catch (Throwable throwable) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingConnectClassLoader(ClassLoader parent, EquinoxConfiguration configuration, BundleLoader delegate, BundleInfo.Generation generation, ClassLoader connectClassLoader) {
/* 36 */     super(parent, configuration, delegate, generation);
/* 37 */     this.connectClassLoader = connectClassLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> findLocalClass(String classname) throws ClassNotFoundException {
/* 42 */     if (this.connectClassLoader == null) {
/* 43 */       return null;
/*    */     }
/* 45 */     return this.connectClassLoader.loadClass(classname);
/*    */   }
/*    */ 
/*    */   
/*    */   public URL findLocalResource(String resource) {
/* 50 */     if (this.connectClassLoader == null) {
/* 51 */       return null;
/*    */     }
/* 53 */     return this.connectClassLoader.getResource(resource);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> findLocalResources(String resource) {
/* 58 */     if (this.connectClassLoader == null) {
/* 59 */       return Collections.emptyEnumeration();
/*    */     }
/*    */     try {
/* 62 */       return this.connectClassLoader.getResources(resource);
/* 63 */     } catch (IOException iOException) {
/* 64 */       return Collections.emptyEnumeration();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\connect\DelegatingConnectClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */