package org.eclipse.osgi.service.resolver;

import org.osgi.framework.BundleException;

public interface PlatformAdmin {
  State getState();
  
  State getState(boolean paramBoolean);
  
  StateHelper getStateHelper();
  
  void commit(State paramState) throws BundleException;
  
  Resolver getResolver();
  
  Resolver createResolver();
  
  StateObjectFactory getFactory();
  
  void addDisabledInfo(DisabledInfo paramDisabledInfo);
  
  void removeDisabledInfo(DisabledInfo paramDisabledInfo);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\PlatformAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */