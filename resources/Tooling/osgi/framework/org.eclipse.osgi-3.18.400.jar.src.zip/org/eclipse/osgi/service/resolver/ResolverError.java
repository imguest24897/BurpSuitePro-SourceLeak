package org.eclipse.osgi.service.resolver;

public interface ResolverError {
  public static final int MISSING_IMPORT_PACKAGE = 1;
  
  public static final int MISSING_REQUIRE_BUNDLE = 2;
  
  public static final int MISSING_FRAGMENT_HOST = 4;
  
  public static final int SINGLETON_SELECTION = 8;
  
  public static final int FRAGMENT_CONFLICT = 16;
  
  public static final int IMPORT_PACKAGE_USES_CONFLICT = 32;
  
  public static final int REQUIRE_BUNDLE_USES_CONFLICT = 64;
  
  public static final int IMPORT_PACKAGE_PERMISSION = 128;
  
  public static final int EXPORT_PACKAGE_PERMISSION = 256;
  
  public static final int REQUIRE_BUNDLE_PERMISSION = 512;
  
  public static final int PROVIDE_BUNDLE_PERMISSION = 1024;
  
  public static final int HOST_BUNDLE_PERMISSION = 2048;
  
  public static final int FRAGMENT_BUNDLE_PERMISSION = 4096;
  
  public static final int PLATFORM_FILTER = 8192;
  
  public static final int MISSING_EXECUTION_ENVIRONMENT = 16384;
  
  public static final int MISSING_GENERIC_CAPABILITY = 32768;
  
  public static final int NO_NATIVECODE_MATCH = 65536;
  
  public static final int INVALID_NATIVECODE_PATHS = 131072;
  
  public static final int DISABLED_BUNDLE = 262144;
  
  public static final int REQUIRE_CAPABILITY_PERMISSION = 524288;
  
  public static final int PROVIDE_CAPABILITY_PERMISSION = 1048576;
  
  BundleDescription getBundle();
  
  int getType();
  
  String getData();
  
  VersionConstraint getUnsatisfiedConstraint();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\ResolverError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */