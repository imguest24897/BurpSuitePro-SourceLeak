/*     */ package org.eclipse.osgi.internal.signedcontent;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.zip.CRC32;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BundleToJarInputStream
/*     */   extends InputStream
/*     */ {
/*  57 */   static final ByteArrayInputStream directoryInputStream = new ByteArrayInputStream(new byte[0]);
/*     */   private final BundleFile bundlefile;
/*     */   private final Iterator<String> entryPaths;
/*     */   private final JarOutputStream jarOutput;
/*  61 */   private final NextEntryOutputStream nextEntryOutput = new NextEntryOutputStream();
/*     */   
/*  63 */   private InputStream nextEntryInput = null;
/*     */   
/*     */   public BundleToJarInputStream(BundleFile bundleFile) throws IOException {
/*  66 */     this.bundlefile = bundleFile;
/*  67 */     List<String> entries = new ArrayList<>();
/*  68 */     int signatureFileCnt = 0;
/*  69 */     for (Enumeration<String> ePaths = bundleFile.getEntryPaths("", true); ePaths.hasMoreElements(); ) {
/*  70 */       String entry = ePaths.nextElement();
/*  71 */       if (entry.equals("META-INF/MANIFEST.MF")) {
/*     */         
/*  73 */         entries.add(0, entry);
/*  74 */         signatureFileCnt++; continue;
/*     */       } 
/*  76 */       if (isSignatureFile(entry)) {
/*     */         
/*  78 */         entries.add(signatureFileCnt++, entry);
/*     */         continue;
/*     */       } 
/*  81 */       entries.add(entry);
/*     */     } 
/*     */ 
/*     */     
/*  85 */     this.entryPaths = entries.iterator();
/*     */     
/*  87 */     this.jarOutput = new JarOutputStream(this.nextEntryOutput);
/*  88 */     this.jarOutput.setLevel(0);
/*     */   }
/*     */   
/*     */   private boolean isSignatureFile(String entry) {
/*  92 */     entry = entry.toUpperCase();
/*  93 */     if (entry.startsWith("META-INF/") && entry.indexOf('/', "META-INF/".length()) == -1) {
/*  94 */       return !(!entry.endsWith(".SF") && 
/*  95 */         !entry.endsWith(".DSA") && 
/*  96 */         !entry.endsWith(".RSA") && 
/*  97 */         !entry.endsWith(".EC"));
/*     */     }
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 103 */     if (this.nextEntryInput != null) {
/* 104 */       int result = this.nextEntryInput.read();
/* 105 */       if (result != -1) {
/* 106 */         return result;
/*     */       }
/*     */ 
/*     */       
/* 110 */       this.nextEntryInput.close();
/* 111 */       this.nextEntryInput = null;
/* 112 */       return read();
/*     */     } 
/*     */     
/* 115 */     if (this.entryPaths.hasNext()) {
/* 116 */       readNext(this.entryPaths.next());
/*     */       
/* 118 */       if (!this.entryPaths.hasNext()) {
/* 119 */         this.jarOutput.close();
/*     */       }
/*     */     } else {
/* 122 */       this.jarOutput.close();
/* 123 */       return -1;
/*     */     } 
/*     */     
/* 126 */     return read();
/*     */   }
/*     */   
/*     */   private void readNext(String path) throws IOException {
/* 130 */     BundleEntry found = this.bundlefile.getEntry(path);
/* 131 */     if (found == null) {
/* 132 */       throw new IOException("No entry found: " + path);
/*     */     }
/* 134 */     this.nextEntryOutput.setCurrent(found);
/*     */ 
/*     */ 
/*     */     
/* 138 */     JarEntry entry = getJarEntry(path, found);
/* 139 */     this.nextEntryOutput.setCurrentLen(entry.getSize());
/*     */     
/* 141 */     this.jarOutput.putNextEntry(entry);
/* 142 */     this.nextEntryOutput.prefixWritten();
/*     */     
/* 144 */     if (!entry.isDirectory()) {
/*     */ 
/*     */       
/* 147 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 155 */       this.nextEntryOutput.setCurrentLen(0L);
/*     */     } 
/*     */     
/* 158 */     this.jarOutput.closeEntry();
/* 159 */     this.jarOutput.flush();
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.nextEntryInput = this.nextEntryOutput.getNextInputStream();
/*     */   }
/*     */   
/*     */   private JarEntry getJarEntry(String path, BundleEntry found) throws IOException {
/* 167 */     JarEntry entry = new JarEntry(path);
/* 168 */     if (!entry.isDirectory()) {
/* 169 */       entry.setMethod(0);
/* 170 */       entry.setCompressedSize(-1L);
/*     */       
/* 172 */       CRC32 crc = new CRC32();
/* 173 */       long entryLen = 0L;
/* 174 */       Exception exception1 = null, exception2 = null; try { InputStream source = new BufferedInputStream(found.getInputStream()); 
/* 175 */         try { byte[] buf = new byte[8192];
/*     */           int length;
/* 177 */           while ((length = source.read(buf)) > 0) {
/* 178 */             entryLen += length;
/* 179 */             crc.update(buf, 0, length);
/*     */           }  }
/* 181 */         finally { if (source != null) source.close();  }  } finally { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */          }
/*     */     
/*     */     } 
/* 185 */     return entry;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 190 */     this.nextEntryOutput.close();
/*     */   }
/*     */   
/*     */   static class NextEntryOutputStream extends OutputStream {
/* 194 */     private BundleEntry current = null;
/* 195 */     private long currentLen = -1L;
/* 196 */     private long currentWritten = 0L;
/*     */     private boolean writingPrefix = true;
/* 198 */     final ByteArrayOutputStream currentPrefix = new ByteArrayOutputStream();
/* 199 */     final ByteArrayOutputStream currentPostfix = new ByteArrayOutputStream();
/*     */     
/*     */     void setCurrent(BundleEntry entry) {
/* 202 */       this.current = entry;
/* 203 */       this.currentWritten = 0L;
/* 204 */       this.currentPrefix.reset();
/* 205 */       this.currentPostfix.reset();
/* 206 */       this.writingPrefix = true;
/*     */     }
/*     */     
/*     */     void prefixWritten() {
/* 210 */       this.writingPrefix = false;
/*     */     }
/*     */     
/*     */     void setCurrentLen(long currentLen) {
/* 214 */       this.currentLen = currentLen;
/*     */     }
/*     */     
/*     */     InputStream getCurrentInputStream() throws IOException {
/* 218 */       if (this.current.getName().endsWith("/")) {
/* 219 */         return BundleToJarInputStream.directoryInputStream;
/*     */       }
/* 221 */       return new BufferedInputStream(this.current.getInputStream());
/*     */     }
/*     */     
/*     */     InputStream getNextInputStream() throws IOException {
/* 225 */       return new FilterInputStream(getCurrentInputStream()) {
/* 226 */           ByteArrayInputStream prefix = new ByteArrayInputStream(BundleToJarInputStream.NextEntryOutputStream.this.currentPrefix.toByteArray());
/* 227 */           ByteArrayInputStream postfix = new ByteArrayInputStream(BundleToJarInputStream.NextEntryOutputStream.this.currentPostfix.toByteArray());
/*     */ 
/*     */           
/*     */           public int read() throws IOException {
/* 231 */             int read = this.prefix.read();
/* 232 */             if (read != -1) {
/* 233 */               return read;
/*     */             }
/* 235 */             read = super.read();
/* 236 */             if (read != -1) {
/* 237 */               return read;
/*     */             }
/* 239 */             return this.postfix.read();
/*     */           }
/*     */ 
/*     */           
/*     */           public int read(byte[] b) throws IOException {
/* 244 */             int read = this.prefix.read(b);
/* 245 */             if (read != -1) {
/* 246 */               return read;
/*     */             }
/* 248 */             read = super.read(b);
/* 249 */             if (read != -1) {
/* 250 */               return read;
/*     */             }
/* 252 */             return this.postfix.read(b);
/*     */           }
/*     */ 
/*     */           
/*     */           public int read(byte[] b, int off, int len) throws IOException {
/* 257 */             int read = this.prefix.read(b, off, len);
/* 258 */             if (read != -1) {
/* 259 */               return read;
/*     */             }
/* 261 */             read = super.read(b, off, len);
/* 262 */             if (read != -1) {
/* 263 */               return read;
/*     */             }
/* 265 */             return this.postfix.read(b, off, len);
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {
/* 272 */       if (this.writingPrefix) {
/* 273 */         this.currentPrefix.write(b);
/*     */         return;
/*     */       } 
/* 276 */       if (this.currentWritten < this.currentLen) {
/* 277 */         this.currentWritten++;
/*     */         return;
/*     */       } 
/* 280 */       this.currentPostfix.write(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 285 */       if (this.writingPrefix) {
/* 286 */         this.currentPrefix.write(b);
/*     */         return;
/*     */       } 
/* 289 */       if (this.currentWritten < this.currentLen) {
/* 290 */         this.currentWritten += b.length;
/*     */         return;
/*     */       } 
/* 293 */       this.currentPostfix.write(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/* 298 */       if (this.writingPrefix) {
/* 299 */         this.currentPrefix.write(b, off, len);
/*     */         return;
/*     */       } 
/* 302 */       if (this.currentWritten < this.currentLen) {
/* 303 */         this.currentWritten += len;
/*     */         return;
/*     */       } 
/* 306 */       this.currentPostfix.write(b, off, len);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\BundleToJarInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */