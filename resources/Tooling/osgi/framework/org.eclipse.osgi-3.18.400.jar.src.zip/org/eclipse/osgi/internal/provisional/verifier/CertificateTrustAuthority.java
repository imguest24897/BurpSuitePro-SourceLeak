package org.eclipse.osgi.internal.provisional.verifier;

import java.security.cert.Certificate;
import java.security.cert.CertificateException;

public interface CertificateTrustAuthority {
  void checkTrust(Certificate[] paramArrayOfCertificate) throws CertificateException;
  
  void addTrusted(Certificate[] paramArrayOfCertificate) throws CertificateException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\verifier\CertificateTrustAuthority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */