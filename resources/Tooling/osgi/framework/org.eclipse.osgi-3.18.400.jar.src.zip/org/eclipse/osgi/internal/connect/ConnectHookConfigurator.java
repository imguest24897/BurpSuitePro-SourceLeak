/*     */ package org.eclipse.osgi.internal.connect;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookConfigurator;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.hookregistry.StorageHookFactory;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapperChain;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.connect.ConnectModule;
/*     */ import org.osgi.framework.connect.ModuleConnector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectHookConfigurator
/*     */   implements HookConfigurator
/*     */ {
/*  54 */   static final Collection<String> CONNECT_TAG_NAMESPACES = new ArrayList<>(Arrays.asList(new String[] {
/*  55 */           "osgi.wiring.bundle", "osgi.wiring.host", "osgi.identity"
/*     */         }));
/*     */   
/*     */   public void addHooks(HookRegistry hookRegistry) {
/*  59 */     final EquinoxContainer.ConnectModules connectModules = hookRegistry.getContainer().getConnectModules();
/*  60 */     ModuleConnector moduleConnector = connectModules.getModuleConnector();
/*     */     
/*  62 */     hookRegistry.addStorageHookFactory(new StorageHookFactory<Object, Object, StorageHookFactory.StorageHook<Object, Object>>()
/*     */         {
/*     */           protected StorageHookFactory.StorageHook<Object, Object> createStorageHook(final BundleInfo.Generation generation) {
/*  65 */             final ConnectModule m = connectModules.getConnectModule(generation.getBundleInfo().getLocation());
/*     */             
/*  67 */             return new StorageHookFactory.StorageHook<Object, Object>(generation, getClass())
/*     */               {
/*     */                 boolean hasModule = false;
/*     */                 
/*     */                 public void save(Object saveContext, DataOutputStream os) throws IOException {
/*  72 */                   os.writeBoolean((m != null));
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public void load(Object loadContext, DataInputStream is) throws IOException {
/*  77 */                   this.hasModule = is.readBoolean();
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/*     */                 public void validate() throws IllegalStateException {
/*  83 */                   if (this.hasModule && m == null) {
/*  84 */                     throw new IllegalStateException("Connect Factory no longer has the module at locataion: " + generation.getBundleInfo().getLocation());
/*     */                   }
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public ModuleRevisionBuilder adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent operation, Module origin, ModuleRevisionBuilder builder) {
/*  90 */                   if (m != null) {
/*  91 */                     ConnectHookConfigurator.CONNECT_TAG_NAMESPACES.stream().map(builder::getCapabilities).flatMap(Collection::stream)
/*  92 */                       .forEach(c -> {
/*     */                         
/*     */                         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/* 106 */                     return builder;
/*     */                   } 
/* 108 */                   return null;
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public URLConnection handleContentConnection(Module module, String location, InputStream in) {
/* 115 */             if (in != null)
/*     */             {
/* 117 */               return null;
/*     */             }
/* 119 */             if (location == null) {
/* 120 */               location = module.getLocation();
/*     */             }
/*     */             try {
/* 123 */               ConnectModule m = connectModules.connect(location);
/* 124 */               if (m != null) {
/* 125 */                 return ConnectInputStream.URL_CONNECTION_INSTANCE;
/*     */               }
/* 127 */             } catch (IllegalStateException e) {
/* 128 */               if (e.getCause() instanceof org.osgi.framework.BundleException) {
/* 129 */                 EquinoxContainer.sneakyThrow(e.getCause());
/*     */               }
/*     */             } 
/* 132 */             return null;
/*     */           }
/*     */         });
/*     */     
/* 136 */     if (moduleConnector == null) {
/*     */       return;
/*     */     }
/*     */     
/* 140 */     hookRegistry.addClassLoaderHook(new ClassLoaderHook()
/*     */         {
/*     */           public ModuleClassLoader createClassLoader(ClassLoader parent, EquinoxConfiguration configuration, BundleLoader delegate, BundleInfo.Generation generation) {
/* 143 */             ConnectModule m = connectModules.getConnectModule(generation.getBundleInfo().getLocation());
/* 144 */             if (m != null) {
/* 145 */               BundleFile bundlefile = generation.getBundleFile();
/* 146 */               if (bundlefile instanceof BundleFileWrapperChain) {
/* 147 */                 BundleFileWrapperChain chain = (BundleFileWrapperChain)bundlefile;
/* 148 */                 while (chain.getNext() != null) {
/* 149 */                   chain = chain.getNext();
/*     */                 }
/* 151 */                 bundlefile = chain.getBundleFile();
/*     */               } 
/* 153 */               if (bundlefile instanceof ConnectBundleFile) {
/* 154 */                 return ((ConnectBundleFile)bundlefile).getClassLoader().<ModuleClassLoader>map(l -> new DelegatingConnectClassLoader(param1ClassLoader1, param1EquinoxConfiguration, param1BundleLoader, param1Generation, l))
/* 155 */                   .orElse(null);
/*     */               }
/*     */             } 
/* 158 */             return null;
/*     */           }
/*     */         });
/*     */     
/* 162 */     hookRegistry.addActivatorHookFactory(() -> {
/*     */           final List<BundleActivator> activators = new ArrayList<>();
/*     */           paramModuleConnector.newBundleActivator().ifPresent(activators::add);
/*     */           return new BundleActivator()
/*     */             {
/*     */               public void start(BundleContext context) throws Exception {
/* 168 */                 for (BundleActivator activator : activators) {
/* 169 */                   activator.start(context);
/*     */                 }
/*     */               }
/*     */ 
/*     */               
/*     */               public void stop(BundleContext context) throws Exception {
/* 175 */                 for (BundleActivator activator : activators)
/* 176 */                   activator.stop(context); 
/*     */               }
/*     */             };
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\connect\ConnectHookConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */