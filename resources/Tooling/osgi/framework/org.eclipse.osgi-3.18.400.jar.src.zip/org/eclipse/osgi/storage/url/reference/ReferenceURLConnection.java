/*     */ package org.eclipse.osgi.storage.url.reference;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.file.Files;
/*     */ import org.eclipse.osgi.framework.util.FilePath;
/*     */ import org.eclipse.osgi.internal.location.LocationHelper;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceURLConnection
/*     */   extends URLConnection
/*     */ {
/*     */   private final String installPath;
/*     */   private volatile File reference;
/*     */   
/*     */   protected ReferenceURLConnection(URL url, String installPath) {
/*  39 */     super(url);
/*  40 */     this.installPath = installPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void connect() throws IOException {
/*  45 */     if (!this.connected) {
/*     */ 
/*     */ 
/*     */       
/*  49 */       String path = getURL().getPath();
/*  50 */       if (!path.startsWith("file:")) {
/*  51 */         throw new IOException(NLS.bind(Msg.ADAPTOR_URL_CREATE_EXCEPTION, path));
/*     */       }
/*  53 */       path = path.substring(5);
/*  54 */       File file = new File(path);
/*     */       
/*  56 */       if (!file.isAbsolute() && 
/*  57 */         this.installPath != null) {
/*  58 */         file = makeAbsolute(this.installPath, file);
/*     */       }
/*     */       
/*  61 */       file = LocationHelper.decodePath(file);
/*     */       
/*  63 */       checkRead(file);
/*     */       
/*  65 */       this.reference = file;
/*  66 */       this.connected = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkRead(File file) throws IOException {
/*  71 */     if (!file.exists())
/*  72 */       throw new FileNotFoundException(file.toString()); 
/*  73 */     if (!Files.isReadable(file.toPath())) {
/*  74 */       if (file.isFile()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  80 */         InputStream is = new FileInputStream(file);
/*  81 */         is.close();
/*  82 */       } else if (file.isDirectory()) {
/*     */ 
/*     */ 
/*     */         
/*  86 */         File[] files = file.listFiles();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  92 */         if (files == null) {
/*  93 */           throw new FileNotFoundException(String.valueOf(file.toString()) + " (probably access denied)");
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDoInput() {
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDoOutput() {
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 112 */     if (!this.connected) {
/* 113 */       connect();
/*     */     }
/*     */     
/* 116 */     return new ReferenceInputStream(this.reference);
/*     */   }
/*     */   
/*     */   private static File makeAbsolute(String base, File relative) {
/* 120 */     if (relative.isAbsolute())
/* 121 */       return relative; 
/* 122 */     return new File((new FilePath(String.valueOf(base) + relative.getPath())).toString());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\reference\ReferenceURLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */