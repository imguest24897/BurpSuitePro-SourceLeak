/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OrderedExecutor
/*     */   implements ThreadFactory
/*     */ {
/* 337 */   private final int nThreads = Math.min(Runtime.getRuntime().availableProcessors(), 10);
/*     */   private final String logThreadName;
/*     */   private final ThreadPoolExecutor delegate;
/* 340 */   private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
/* 341 */   private int coreSize = 0;
/*     */   
/*     */   public OrderedExecutor(EquinoxContainer equinoxContainer) {
/* 344 */     this.logThreadName = "Equinox Log Thread - " + equinoxContainer.toString();
/* 345 */     this.delegate = new ThreadPoolExecutor(0, this.nThreads, 10L, TimeUnit.SECONDS, this.queue, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Thread newThread(Runnable r) {
/* 350 */     Thread t = new Thread(r, this.logThreadName);
/* 351 */     t.setDaemon(true);
/* 352 */     return t;
/*     */   }
/*     */   
/*     */   void executeOrderedTask(Runnable task, OrderedTaskQueue dependencyQueue, int numListeners) {
/*     */     OrderedTaskQueue.OrderedTask firstOrderedTask;
/* 357 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/* 361 */       firstOrderedTask = dependencyQueue.addTaskAndReturnIfFirst(task);
/* 362 */       if (firstOrderedTask != null) {
/*     */         
/* 364 */         int targetSize = Math.min(this.nThreads, numListeners);
/* 365 */         if (this.coreSize < targetSize) {
/* 366 */           this.coreSize = targetSize;
/* 367 */           this.delegate.setCorePoolSize(this.coreSize);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 373 */     if (firstOrderedTask != null) {
/* 374 */       this.delegate.execute(firstOrderedTask);
/*     */     }
/*     */   }
/*     */   
/*     */   OrderedTaskQueue createQueue() {
/* 379 */     return new OrderedTaskQueue();
/*     */   }
/*     */   
/*     */   void shutdown() {
/* 383 */     this.delegate.shutdown();
/*     */   }
/*     */   
/*     */   void executeNextTask(OrderedTaskQueue taskQueue) {
/*     */     OrderedTaskQueue.OrderedTask nextTask;
/* 388 */     synchronized (this) {
/* 389 */       nextTask = taskQueue.getNextTask();
/* 390 */       if (nextTask == null && this.queue.isEmpty()) {
/*     */         
/* 392 */         this.delegate.setCorePoolSize(0);
/* 393 */         this.coreSize = 0;
/*     */       } 
/*     */     } 
/* 396 */     if (nextTask != null) {
/* 397 */       this.delegate.execute(nextTask);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class OrderedTaskQueue
/*     */   {
/* 412 */     private final Queue<OrderedTask> dependencyQueue = new LinkedList<>();
/* 413 */     private AtomicReference<OrderedTask> firstTask = new AtomicReference<>();
/*     */     
/*     */     void execute(Runnable task, int numListeners) {
/* 416 */       OrderedExecutor.this.executeOrderedTask(task, this, numListeners);
/*     */     }
/*     */     
/*     */     OrderedTask addTaskAndReturnIfFirst(Runnable task) {
/* 420 */       OrderedTask orderedTask = new OrderedTask(task);
/* 421 */       if (this.firstTask.compareAndSet(null, orderedTask)) {
/* 422 */         return orderedTask;
/*     */       }
/* 424 */       this.dependencyQueue.add(orderedTask);
/* 425 */       return null;
/*     */     }
/*     */     
/*     */     OrderedTask getNextTask() {
/* 429 */       OrderedTask nextTask = this.dependencyQueue.poll();
/* 430 */       if (nextTask == null)
/*     */       {
/*     */         
/* 433 */         this.firstTask.set(null);
/*     */       }
/* 435 */       return nextTask;
/*     */     }
/*     */     
/*     */     class OrderedTask implements Runnable {
/*     */       private final Runnable task;
/*     */       
/*     */       public OrderedTask(Runnable task) {
/* 442 */         this.task = task;
/*     */       }
/*     */       
/*     */       public void run()
/*     */       {
/*     */         
/* 448 */         try { this.task.run(); }
/*     */         finally
/* 450 */         { OrderedExecutor.OrderedTaskQueue.access$0(OrderedExecutor.OrderedTaskQueue.this).executeNextTask(OrderedExecutor.OrderedTaskQueue.this); }  } } } class OrderedTask implements Runnable { public void run() { try { this.task.run(); } finally { OrderedExecutor.OrderedTaskQueue.access$0(this.this$1).executeNextTask(this.this$1); }
/*     */        }
/*     */ 
/*     */     
/*     */     private final Runnable task;
/*     */     
/*     */     public OrderedTask(Runnable task) {
/*     */       this.task = task;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\OrderedExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */