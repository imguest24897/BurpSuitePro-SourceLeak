/*    */ package org.eclipse.osgi.internal.url;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.osgi.service.url.URLStreamHandlerSetter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLStreamHandlerSetter
/*    */   implements URLStreamHandlerSetter
/*    */ {
/*    */   protected URLStreamHandlerProxy handlerProxy;
/*    */   
/*    */   public URLStreamHandlerSetter(URLStreamHandlerProxy handler) {
/* 24 */     this.handlerProxy = handler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setURL(URL url, String protocol, String host, int port, String file, String ref) {
/* 33 */     this.handlerProxy.setURL(url, protocol, host, port, file, ref);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setURL(URL url, String protocol, String host, int port, String authority, String userInfo, String path, String query, String ref) {
/* 41 */     this.handlerProxy.setURL(url, protocol, host, port, authority, userInfo, path, query, ref);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\URLStreamHandlerSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */