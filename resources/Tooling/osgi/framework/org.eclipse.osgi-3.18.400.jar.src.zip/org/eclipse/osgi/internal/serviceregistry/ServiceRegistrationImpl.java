/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.loader.sources.PackageSource;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceRegistrationImpl<S>
/*     */   implements ServiceRegistration<S>, Comparable<ServiceRegistrationImpl<?>>
/*     */ {
/*     */   private final ServiceRegistry registry;
/*     */   private final BundleContextImpl context;
/*     */   private final Bundle bundle;
/*     */   private final String[] clazzes;
/*     */   private final S service;
/*     */   private ServiceReferenceImpl<S> reference;
/*     */   private final List<BundleContextImpl> contextsUsing;
/*     */   private Map<String, Object> properties;
/*     */   private final long serviceid;
/*     */   private int serviceranking;
/*  92 */   private final Object registrationLock = new Object();
/*     */ 
/*     */   
/*     */   private int state;
/*     */   
/*     */   private static final int REGISTERED = 0;
/*     */   
/*     */   private static final int UNREGISTERING = 1;
/*     */   
/*     */   private static final int UNREGISTERED = 2;
/*     */   
/*     */   private static final int FRAMEWORK_SET_SERVICE_PROPERTIES_COUNT = 4;
/*     */ 
/*     */   
/*     */   ServiceRegistrationImpl(ServiceRegistry registry, BundleContextImpl context, String[] clazzes, S service) {
/* 107 */     this.registry = registry;
/* 108 */     this.context = context;
/* 109 */     this.bundle = (Bundle)context.getBundleImpl();
/* 110 */     this.clazzes = clazzes;
/* 111 */     this.service = service;
/* 112 */     this.serviceid = registry.getNextServiceId();
/* 113 */     this.contextsUsing = new ArrayList<>(10);
/*     */     
/* 115 */     synchronized (this.registrationLock) {
/* 116 */       this.state = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 122 */       this.reference = new ServiceReferenceImpl<>(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void register(Dictionary<String, ?> props) {
/*     */     ServiceReferenceImpl<S> ref;
/* 131 */     synchronized (this.registry) {
/* 132 */       this.context.checkValid();
/* 133 */       synchronized (this.registrationLock) {
/* 134 */         ref = this.reference;
/* 135 */         this.properties = createProperties(props);
/*     */       } 
/* 137 */       if (this.registry.debug.DEBUG_SERVICES) {
/* 138 */         Debug.println("registerService[" + this.bundle + "](" + this + ")");
/*     */       }
/* 140 */       this.registry.addServiceRegistration(this.context, this);
/*     */     } 
/*     */ 
/*     */     
/* 144 */     this.registry.publishServiceEvent(new ServiceEvent(1, ref));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Dictionary<String, ?> props) {
/*     */     ServiceReferenceImpl<S> ref;
/*     */     Map<String, Object> previousProperties;
/* 173 */     synchronized (this.registry) {
/*     */       int previousRanking;
/* 175 */       synchronized (this.registrationLock) {
/* 176 */         if (this.state != 0) {
/* 177 */           throw new IllegalStateException(String.valueOf(Msg.SERVICE_ALREADY_UNREGISTERED_EXCEPTION) + ' ' + this);
/*     */         }
/*     */         
/* 180 */         ref = this.reference;
/* 181 */         previousProperties = this.properties;
/* 182 */         previousRanking = this.serviceranking;
/* 183 */         this.properties = createProperties(props);
/*     */       } 
/* 185 */       this.registry.modifyServiceRegistration(this.context, this, previousRanking);
/*     */     } 
/*     */     
/* 188 */     this.registry.publishServiceEvent(new ModifiedServiceEvent(ref, previousProperties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregister() {
/*     */     ServiceReferenceImpl<S> ref;
/* 224 */     synchronized (this.registry) {
/* 225 */       synchronized (this.registrationLock) {
/* 226 */         if (this.state != 0) {
/* 227 */           throw new IllegalStateException(String.valueOf(Msg.SERVICE_ALREADY_UNREGISTERED_EXCEPTION) + ' ' + this);
/*     */         }
/*     */ 
/*     */         
/* 231 */         if (this.registry.debug.DEBUG_SERVICES) {
/* 232 */           Debug.println("unregisterService[" + this.bundle + "](" + this + ")");
/*     */         }
/*     */         
/* 235 */         this.registry.removeServiceRegistration(this.context, this);
/*     */         
/* 237 */         this.state = 1;
/* 238 */         ref = this.reference;
/*     */       } 
/*     */     } 
/*     */     
/* 242 */     ungetHookInstance();
/*     */     
/* 244 */     this.registry.publishServiceEvent(new ServiceEvent(4, ref));
/*     */     
/* 246 */     int size = 0;
/* 247 */     BundleContextImpl[] users = null;
/*     */     
/* 249 */     synchronized (this.registrationLock) {
/*     */       
/* 251 */       this.state = 2;
/*     */       
/* 253 */       size = this.contextsUsing.size();
/* 254 */       if (size > 0) {
/* 255 */         if (this.registry.debug.DEBUG_SERVICES) {
/* 256 */           Debug.println("unregisterService: releasing users");
/*     */         }
/* 258 */         users = this.contextsUsing.<BundleContextImpl>toArray(new BundleContextImpl[size]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 263 */     for (int i = 0; i < size; i++) {
/* 264 */       releaseService(users[i]);
/*     */     }
/*     */     
/* 267 */     synchronized (this.registrationLock) {
/* 268 */       this.contextsUsing.clear();
/*     */       
/* 270 */       this.reference = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isUnregistered() {
/* 282 */     synchronized (this.registrationLock) {
/* 283 */       return (this.state == 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<S> getReference() {
/* 297 */     return getReferenceImpl();
/*     */   }
/*     */   
/*     */   S getHookInstance() {
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initHookInstance() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ungetHookInstance() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceReferenceImpl<S> getReferenceImpl() {
/* 318 */     synchronized (this.registrationLock) {
/* 319 */       if (this.reference == null) {
/* 320 */         throw new IllegalStateException(String.valueOf(Msg.SERVICE_ALREADY_UNREGISTERED_EXCEPTION) + ' ' + this);
/*     */       }
/*     */       
/* 323 */       return this.reference;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> createProperties(Dictionary<String, ?> p) {
/*     */     String scope;
/* 349 */     assert Thread.holdsLock(this.registrationLock);
/* 350 */     ServiceProperties props = new ServiceProperties(p, 4);
/*     */     
/* 352 */     props.put("objectClass", this.clazzes);
/* 353 */     props.put("service.id", Long.valueOf(this.serviceid));
/* 354 */     props.put("service.bundleid", Long.valueOf(this.bundle.getBundleId()));
/*     */     
/* 356 */     if (this.service instanceof org.osgi.framework.ServiceFactory) {
/* 357 */       if (this.service instanceof org.osgi.framework.PrototypeServiceFactory) {
/* 358 */         scope = "prototype";
/*     */       } else {
/* 360 */         scope = "bundle";
/*     */       } 
/*     */     } else {
/* 363 */       scope = "singleton";
/*     */     } 
/* 365 */     props.put("service.scope", scope);
/*     */     
/* 367 */     Object ranking = props.get("service.ranking");
/* 368 */     if (ranking instanceof Integer) {
/* 369 */       this.serviceranking = ((Integer)ranking).intValue();
/*     */     } else {
/* 371 */       this.serviceranking = 0;
/* 372 */       if (ranking != null) {
/* 373 */         this.registry.getContainer().getEventPublisher().publishFrameworkEvent(16, getBundle(), (Throwable)new ServiceException("Invalid ranking type: " + ranking.getClass(), 0));
/*     */       }
/*     */     } 
/*     */     
/* 377 */     return props.asUnmodifiableMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getProperties() {
/* 385 */     synchronized (this.registrationLock) {
/* 386 */       return this.properties;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getProperty(String key) {
/* 403 */     synchronized (this.registrationLock) {
/* 404 */       return ServiceProperties.cloneValue(this.properties.get(key));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getPropertyKeys() {
/* 419 */     synchronized (this.registrationLock) {
/* 420 */       return (String[])this.properties.keySet().toArray((Object[])new String[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Dictionary<String, Object> getPropertiesCopy() {
/* 435 */     synchronized (this.registrationLock) {
/* 436 */       return (Dictionary<String, Object>)new ServiceProperties(this.properties);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getId() {
/* 445 */     return this.serviceid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getRanking() {
/* 453 */     synchronized (this.registrationLock) {
/* 454 */       return this.serviceranking;
/*     */     } 
/*     */   }
/*     */   
/*     */   String[] getClasses() {
/* 459 */     return this.clazzes;
/*     */   }
/*     */   
/*     */   S getServiceObject() {
/* 463 */     return this.service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Bundle getBundle() {
/* 476 */     synchronized (this.registrationLock) {
/* 477 */       if (this.reference == null) {
/* 478 */         return null;
/*     */       }
/*     */       
/* 481 */       return this.bundle;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle getRegisteringBundle() {
/* 493 */     return this.bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getService(BundleContextImpl user, ServiceConsumer consumer) {
/* 504 */     if (isUnregistered()) {
/* 505 */       return null;
/*     */     }
/* 507 */     Map<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse = user.getServicesInUseMap();
/* 508 */     if (servicesInUse == null) {
/* 509 */       user.checkValid();
/*     */     }
/*     */     
/* 512 */     if (this.registry.debug.DEBUG_SERVICES) {
/* 513 */       Debug.println("[" + Thread.currentThread().getName() + "] getService[" + user.getBundleImpl() + "](" + this + 
/* 514 */           ")");
/*     */     }
/*     */     
/*     */     while (true) {
/*     */       ServiceUse<S> use;
/*     */       
/*     */       boolean added;
/* 521 */       synchronized (servicesInUse) {
/* 522 */         user.checkValid();
/*     */         
/* 524 */         ServiceUse<S> u = (ServiceUse<S>)servicesInUse.get(this);
/* 525 */         if (u == null) {
/*     */ 
/*     */           
/* 528 */           use = newServiceUse(user);
/* 529 */           added = true;
/* 530 */           synchronized (this.registrationLock) {
/* 531 */             if (this.state == 2) {
/* 532 */               return null;
/*     */             }
/* 534 */             servicesInUse.put(this, use);
/* 535 */             this.contextsUsing.add(user);
/*     */           } 
/*     */         } else {
/* 538 */           use = u;
/* 539 */           added = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 544 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */       
/*     */       } finally {
/* 582 */         exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceObjectsImpl<S> getServiceObjects(BundleContextImpl user) {
/* 594 */     if (isUnregistered()) {
/* 595 */       return null;
/*     */     }
/* 597 */     if (this.registry.debug.DEBUG_SERVICES) {
/* 598 */       Debug.println("[" + Thread.currentThread().getName() + "] getServiceObjects[" + user.getBundleImpl() + "](" + 
/* 599 */           this + ")");
/*     */     }
/*     */     
/* 602 */     return new ServiceObjectsImpl<>(user, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceUse<S> newServiceUse(BundleContextImpl user) {
/* 612 */     if (this.service instanceof org.osgi.framework.ServiceFactory) {
/* 613 */       if (this.service instanceof org.osgi.framework.PrototypeServiceFactory) {
/* 614 */         return new PrototypeServiceFactoryUse<>(user, this);
/*     */       }
/* 616 */       return new ServiceFactoryUse<>(user, this);
/*     */     } 
/* 618 */     return new ServiceUse<>(user, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean ungetService(BundleContextImpl user, ServiceConsumer consumer, S serviceObject) {
/*     */     ServiceUse<S> use;
/* 632 */     if (isUnregistered()) {
/* 633 */       return false;
/*     */     }
/* 635 */     Map<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse = user.getServicesInUseMap();
/* 636 */     if (servicesInUse == null) {
/* 637 */       return false;
/*     */     }
/*     */     
/* 640 */     if (this.registry.debug.DEBUG_SERVICES) {
/* 641 */       Debug.println("[" + Thread.currentThread().getName() + "] ungetService[" + user.getBundleImpl() + "](" + 
/* 642 */           this + ")");
/*     */     }
/*     */ 
/*     */     
/* 646 */     synchronized (servicesInUse) {
/*     */       
/* 648 */       ServiceUse<S> u = (ServiceUse<S>)servicesInUse.get(this);
/* 649 */       use = u;
/* 650 */       if (use == null) {
/* 651 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 655 */     Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/*     */     } finally {
/* 673 */       exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void releaseService(BundleContextImpl user) {
/*     */     ServiceUse<S> use;
/* 682 */     synchronized (this.registrationLock) {
/* 683 */       if (this.reference == null) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 688 */     if (this.registry.debug.DEBUG_SERVICES) {
/* 689 */       Debug.println("releaseService[" + user.getBundleImpl() + "](" + this + ")");
/*     */     }
/*     */     
/* 692 */     Map<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse = user.getServicesInUseMap();
/* 693 */     if (servicesInUse == null) {
/*     */       return;
/*     */     }
/*     */     
/* 697 */     synchronized (servicesInUse) {
/* 698 */       synchronized (this.registrationLock) {
/*     */         
/* 700 */         ServiceUse<S> u = (ServiceUse<S>)servicesInUse.remove(this);
/* 701 */         use = u;
/* 702 */         if (use == null) {
/*     */           return;
/*     */         }
/* 705 */         this.contextsUsing.remove(user);
/*     */       } 
/*     */     } 
/* 708 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Bundle[] getUsingBundles() {
/* 719 */     synchronized (this.registrationLock) {
/* 720 */       if (this.state == 2) {
/* 721 */         return null;
/*     */       }
/* 723 */       int size = this.contextsUsing.size();
/* 724 */       if (size == 0) {
/* 725 */         return null;
/*     */       }
/*     */       
/* 728 */       Bundle[] bundles = new Bundle[size];
/* 729 */       for (int i = 0; i < size; i++) {
/* 730 */         bundles[i] = (Bundle)((BundleContextImpl)this.contextsUsing.get(i)).getBundleImpl();
/*     */       }
/* 732 */       return bundles;
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isAssignableTo(Bundle client, String className, boolean checkInternal) {
/* 737 */     return PackageSource.isServiceAssignableTo(this.bundle, client, className, this.service.getClass(), checkInternal, 
/* 738 */         this.context.getContainer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 748 */     int size = this.clazzes.length;
/* 749 */     StringBuilder sb = new StringBuilder(50 * size);
/*     */     
/* 751 */     sb.append('{');
/*     */     
/* 753 */     for (int i = 0; i < size; i++) {
/* 754 */       if (i > 0) {
/* 755 */         sb.append(", ");
/*     */       }
/* 757 */       sb.append(this.clazzes[i]);
/*     */     } 
/*     */     
/* 760 */     sb.append("}=");
/* 761 */     sb.append(getProperties().toString());
/*     */     
/* 763 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ServiceRegistrationImpl<?> other) {
/* 782 */     return compareTo(other.getRanking(), other.getId());
/*     */   }
/*     */   
/*     */   int compareTo(int otherRanking, long otherId) {
/* 786 */     int compared = Integer.compare(otherRanking, getRanking());
/* 787 */     if (compared != 0) {
/* 788 */       return compared;
/*     */     }
/* 790 */     return Long.compare(getId(), otherId);
/*     */   }
/*     */   
/*     */   static class FrameworkHookRegistration<S> extends ServiceRegistrationImpl<S> {
/*     */     private volatile boolean hookInitialized = false;
/*     */     private volatile S hookInstance;
/*     */     private final BundleContextImpl systemContext;
/* 797 */     private final Object hookLock = new Object();
/*     */     
/*     */     private final List<Class<?>> hookTypes;
/*     */     
/*     */     FrameworkHookRegistration(ServiceRegistry registry, BundleContextImpl context, String[] clazzes, S service, BundleContextImpl systemContext, List<Class<?>> hookTypes) {
/* 802 */       super(registry, context, clazzes, service);
/* 803 */       this.systemContext = systemContext;
/* 804 */       this.hookTypes = hookTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     S getHookInstance() {
/* 809 */       if (this.hookInstance != null || !this.hookInitialized) {
/* 810 */         return this.hookInstance;
/*     */       }
/* 812 */       synchronized (this.hookLock) {
/* 813 */         if (this.hookInstance == null) {
/* 814 */           this.hookInstance = getSafeService(this.systemContext, ServiceConsumer.singletonConsumer);
/*     */         }
/*     */       } 
/* 817 */       return this.hookInstance;
/*     */     }
/*     */ 
/*     */     
/*     */     void initHookInstance() {
/* 822 */       ServiceReference<S> ref = getReference();
/* 823 */       if (ref != null) {
/* 824 */         this.hookInstance = getSafeService(this.systemContext, ServiceConsumer.singletonConsumer);
/* 825 */         this.hookInitialized = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void ungetHookInstance() {
/* 831 */       if (this.hookInstance != null) {
/* 832 */         this.systemContext.ungetService(getReferenceImpl());
/*     */       }
/*     */     }
/*     */     
/*     */     S getSafeService(BundleContextImpl user, ServiceConsumer consumer) {
/*     */       try {
/* 838 */         S hook = getService(user, consumer);
/* 839 */         if (this.hookTypes.stream().filter(hookType -> !hookType.isInstance(param1Object)).findFirst().isPresent()) {
/*     */           
/* 841 */           if (hook != null) {
/* 842 */             this.systemContext.ungetService(getReference());
/*     */           }
/* 844 */           return null;
/*     */         } 
/* 846 */         return hook;
/* 847 */       } catch (IllegalStateException illegalStateException) {
/*     */         
/* 849 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   ConcurrentMap<Thread, ServiceUse.ServiceUseLock> getAwaitedUseLocks() {
/* 855 */     return this.registry.getAwaitedUseLocks();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceRegistrationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */