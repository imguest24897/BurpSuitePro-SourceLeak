/*    */ package org.eclipse.osgi.internal.loader;
/*    */ 
/*    */ import org.eclipse.osgi.internal.debug.Debug;
/*    */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*    */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*    */ import org.eclipse.osgi.storage.BundleInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EquinoxClassLoader
/*    */   extends ModuleClassLoader
/*    */ {
/*    */   protected static final boolean EQUINOX_REGISTERED_AS_PARALLEL;
/*    */   private final EquinoxConfiguration configuration;
/*    */   private final Debug debug;
/*    */   private final BundleLoader delegate;
/*    */   private final BundleInfo.Generation generation;
/*    */   private final ClasspathManager manager;
/*    */   private final boolean isRegisteredAsParallel;
/*    */   
/*    */   static {
/*    */     boolean registered;
/*    */     try {
/* 27 */       registered = ClassLoader.registerAsParallelCapable();
/* 28 */     } catch (Throwable throwable) {
/* 29 */       registered = false;
/*    */     } 
/* 31 */     EQUINOX_REGISTERED_AS_PARALLEL = registered;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EquinoxClassLoader(ClassLoader parent, EquinoxConfiguration configuration, BundleLoader delegate, BundleInfo.Generation generation) {
/* 49 */     super(parent);
/* 50 */     this.configuration = configuration;
/* 51 */     this.debug = configuration.getDebug();
/* 52 */     this.delegate = delegate;
/* 53 */     this.generation = generation;
/* 54 */     this.manager = new ClasspathManager(generation, this);
/* 55 */     this.isRegisteredAsParallel = !((!ModuleClassLoader.REGISTERED_AS_PARALLEL || !EQUINOX_REGISTERED_AS_PARALLEL) && !this.configuration.PARALLEL_CAPABLE);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final BundleInfo.Generation getGeneration() {
/* 60 */     return this.generation;
/*    */   }
/*    */ 
/*    */   
/*    */   public final ClasspathManager getClasspathManager() {
/* 65 */     return this.manager;
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean isRegisteredAsParallel() {
/* 70 */     return this.isRegisteredAsParallel;
/*    */   }
/*    */ 
/*    */   
/*    */   public final BundleLoader getBundleLoader() {
/* 75 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   protected final Debug getDebug() {
/* 80 */     return this.debug;
/*    */   }
/*    */ 
/*    */   
/*    */   protected final EquinoxConfiguration getConfiguration() {
/* 85 */     return this.configuration;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\EquinoxClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */