/*     */ package org.eclipse.osgi.framework.internal.reliablefile;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReliableFile
/*     */ {
/*     */   public static final int OPEN_BEST_AVAILABLE = 0;
/*     */   public static final int OPEN_FAIL_ON_PRIMARY = 1;
/*     */   public static final int GENERATION_LATEST = 0;
/*     */   public static final int GENERATIONS_INFINITE = 0;
/*     */   public static final String tmpExt = ".tmp";
/*     */   public static final String PROP_MAX_BUFFER = "osgi.reliableFile.maxInputStreamBuffer";
/*     */   public static final String PROP_MAX_GENERATIONS = "osgi.ReliableFile.maxGenerations";
/*     */   public static final String PROP_OSGI_LOCKING = "osgi.locking";
/*     */   private static final int FILETYPE_VALID = 0;
/*     */   private static final int FILETYPE_CORRUPT = 1;
/*     */   private static final int FILETYPE_NOSIGNATURE = 2;
/*  98 */   private static final byte[] identifier1 = new byte[] { 46, 99, 114, 99 };
/*  99 */   private static final byte[] identifier2 = new byte[] { 46, 118, 49, 10 };
/*     */   
/*     */   private static final int BUF_SIZE = 4096;
/*     */   
/*     */   private static final int maxInputStreamBuffer;
/*     */   private static final int defaultMaxGenerations;
/*     */   private static final boolean fileSharing;
/* 106 */   private static File lastGenerationFile = null;
/* 107 */   private static int[] lastGenerations = null;
/* 108 */   private static final Object lastGenerationLock = new Object();
/*     */   private static final int MAX_TEMP_NUM = 100000;
/* 110 */   private static final AtomicInteger nextTemp = new AtomicInteger(1); private File referenceFile; private static Hashtable<File, CacheInfo> cacheFiles;
/*     */   
/*     */   static {
/* 113 */     String prop = System.getProperty("osgi.reliableFile.maxInputStreamBuffer");
/* 114 */     int tmpMaxInput = 131072;
/* 115 */     if (prop != null) {
/*     */       try {
/* 117 */         tmpMaxInput = Integer.parseInt(prop);
/* 118 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/* 121 */     maxInputStreamBuffer = tmpMaxInput;
/*     */     
/* 123 */     int tmpDefaultMax = 2;
/* 124 */     prop = System.getProperty("osgi.ReliableFile.maxGenerations");
/* 125 */     if (prop != null) {
/*     */       try {
/* 127 */         tmpDefaultMax = Integer.parseInt(prop);
/* 128 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/* 131 */     defaultMaxGenerations = tmpDefaultMax;
/*     */     
/* 133 */     prop = System.getProperty("osgi.locking");
/* 134 */     boolean tmpFileSharing = true;
/* 135 */     if (prop != null && 
/* 136 */       prop.equals("none")) {
/* 137 */       tmpFileSharing = false;
/*     */     }
/*     */     
/* 140 */     fileSharing = tmpFileSharing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     cacheFiles = new Hashtable<>(20);
/*     */   }
/* 149 */   private File inputFile = null;
/* 150 */   private File outputFile = null;
/* 151 */   private Checksum appendChecksum = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ReliableFile getReliableFile(String name) throws IOException {
/* 165 */     return getReliableFile(new File(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ReliableFile getReliableFile(File file) throws IOException {
/* 180 */     if (file.isDirectory()) {
/* 181 */       throw new FileNotFoundException("file is a directory");
/*     */     }
/* 183 */     return new ReliableFile(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReliableFile(File file) {
/* 192 */     this.referenceFile = file;
/*     */   }
/*     */   
/*     */   private static int[] getFileGenerations(File file) {
/* 196 */     if (!fileSharing)
/* 197 */       synchronized (lastGenerationLock) {
/* 198 */         if (lastGenerationFile != null)
/*     */         {
/* 200 */           if (file.equals(lastGenerationFile)) {
/* 201 */             return lastGenerations;
/*     */           }
/*     */         }
/*     */       }  
/* 205 */     int[] generations = null;
/*     */     try {
/* 207 */       String name = file.getName();
/* 208 */       String prefix = String.valueOf(name) + '.';
/* 209 */       int prefixLen = prefix.length();
/* 210 */       File parent = new File(file.getParent());
/* 211 */       String[] files = parent.list();
/* 212 */       if (files == null)
/* 213 */         return null; 
/* 214 */       List<Integer> list = new ArrayList<>(defaultMaxGenerations);
/* 215 */       if (file.exists())
/* 216 */         list.add(Integer.valueOf(0));  byte b; int k; String[] arrayOfString1;
/* 217 */       for (k = (arrayOfString1 = files).length, b = 0; b < k; ) { String candidateFile = arrayOfString1[b];
/* 218 */         if (candidateFile.startsWith(prefix)) {
/*     */           try {
/* 220 */             int id = Integer.parseInt(candidateFile.substring(prefixLen));
/* 221 */             list.add(Integer.valueOf(id));
/* 222 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }
/*     */         b++; }
/*     */       
/* 226 */       if (list.size() == 0)
/* 227 */         return null; 
/* 228 */       Object[] array = list.toArray();
/* 229 */       Arrays.sort(array);
/* 230 */       generations = new int[array.length];
/* 231 */       for (int i = 0, j = array.length - 1; i < array.length; i++, j--) {
/* 232 */         generations[i] = ((Integer)array[j]).intValue();
/*     */       }
/* 234 */       return generations;
/*     */     } finally {
/* 236 */       if (!fileSharing) {
/* 237 */         synchronized (lastGenerationLock) {
/* 238 */           lastGenerationFile = file;
/* 239 */           lastGenerations = generations;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getInputStream(int generation, int openMask) throws IOException {
/* 255 */     if (this.inputFile != null) {
/* 256 */       throw new IOException("Input stream already open");
/*     */     }
/* 258 */     int[] generations = getFileGenerations(this.referenceFile);
/* 259 */     if (generations == null) {
/* 260 */       throw new FileNotFoundException("File not found");
/*     */     }
/* 262 */     String name = this.referenceFile.getName();
/* 263 */     File parent = new File(this.referenceFile.getParent());
/*     */     
/* 265 */     boolean failOnPrimary = ((openMask & 0x1) != 0);
/* 266 */     if (failOnPrimary && generation == 0) {
/* 267 */       generation = generations[0];
/*     */     }
/* 269 */     File textFile = null;
/* 270 */     InputStream textIS = null; byte b; int i, arrayOfInt1[];
/* 271 */     for (i = (arrayOfInt1 = generations).length, b = 0; b < i; ) { int generation2 = arrayOfInt1[b];
/* 272 */       if (generation == 0 || (
/* 273 */         generation2 <= generation && (!failOnPrimary || generation2 == generation))) {
/*     */         File file;
/*     */         
/*     */         CacheInfo info;
/* 277 */         if (generation2 != 0) {
/* 278 */           file = new File(parent, String.valueOf(name) + '.' + generation2);
/*     */         } else {
/* 280 */           file = this.referenceFile;
/* 281 */         }  InputStream is = null;
/*     */         
/* 283 */         synchronized (cacheFiles) {
/* 284 */           info = cacheFiles.get(file);
/* 285 */           long timeStamp = file.lastModified();
/* 286 */           if (info == null || timeStamp != info.timeStamp) {
/* 287 */             InputStream tempIS = new FileInputStream(file);
/*     */             
/* 289 */             try { long fileSize = file.length();
/* 290 */               if (fileSize > 0L && fileSize < maxInputStreamBuffer) {
/* 291 */                 tempIS = new BufferedInputStream(tempIS, (int)fileSize);
/*     */                 
/* 293 */                 is = tempIS;
/*     */               } 
/* 295 */               Checksum cksum = getChecksumCalculator();
/* 296 */               int filetype = getStreamType(tempIS, cksum, fileSize);
/* 297 */               info = new CacheInfo(filetype, cksum, timeStamp, fileSize);
/* 298 */               cacheFiles.put(file, info); }
/* 299 */             catch (IOException iOException) {  }
/*     */             finally
/* 301 */             { if (is == null) {
/*     */                 
/*     */                 try {
/* 304 */                   tempIS.close();
/* 305 */                 } catch (IOException iOException) {}
/*     */               } }
/*     */           
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 314 */         if (failOnPrimary) {
/* 315 */           if (info != null && info.filetype == 0) {
/* 316 */             this.inputFile = file;
/* 317 */             if (is != null)
/* 318 */               return is; 
/* 319 */             return new FileInputStream(file);
/*     */           } 
/* 321 */           throw new IOException("ReliableFile is corrupt");
/*     */         } 
/*     */ 
/*     */         
/* 325 */         if (info != null)
/*     */         {
/*     */ 
/*     */           
/* 329 */           switch (info.filetype) {
/*     */             case 0:
/* 331 */               this.inputFile = file;
/* 332 */               if (is != null)
/* 333 */                 return is; 
/* 334 */               return new FileInputStream(file);
/*     */             
/*     */             case 2:
/* 337 */               if (textFile == null) {
/* 338 */                 textFile = file;
/* 339 */                 textIS = is;
/*     */               } 
/*     */               break;
/*     */           } 
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */     
/* 347 */     if (textFile != null) {
/* 348 */       this.inputFile = textFile;
/* 349 */       if (textIS != null)
/* 350 */         return textIS; 
/* 351 */       return new FileInputStream(textFile);
/*     */     } 
/* 353 */     throw new IOException("ReliableFile is corrupt");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OutputStream getOutputStream(boolean append, int appendGeneration) throws IOException {
/*     */     InputStream is;
/* 365 */     if (this.outputFile != null)
/* 366 */       throw new IOException("Output stream is already open"); 
/* 367 */     String name = this.referenceFile.getName();
/* 368 */     File parent = new File(this.referenceFile.getParent());
/* 369 */     File tmpFile = createTempFile(name, ".tmp", parent);
/*     */     
/* 371 */     if (!append) {
/* 372 */       OutputStream os = new FileOutputStream(tmpFile);
/* 373 */       this.outputFile = tmpFile;
/* 374 */       return os;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 379 */       is = getInputStream(appendGeneration, 0);
/* 380 */     } catch (FileNotFoundException fileNotFoundException) {
/* 381 */       OutputStream os = new FileOutputStream(tmpFile);
/* 382 */       this.outputFile = tmpFile;
/* 383 */       return os;
/*     */     } 
/*     */     
/*     */     try {
/* 387 */       CacheInfo info = cacheFiles.get(this.inputFile);
/* 388 */       this.appendChecksum = info.checksum;
/* 389 */       OutputStream os = new FileOutputStream(tmpFile);
/* 390 */       if (info.filetype == 2) {
/* 391 */         cp(is, os, 0, info.length);
/*     */       } else {
/* 393 */         cp(is, os, 16, info.length);
/*     */       } 
/* 395 */       this.outputFile = tmpFile;
/* 396 */       return os;
/*     */     } finally {
/* 398 */       closeInputFile();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeOutputFile(Checksum checksum) throws IOException {
/*     */     File newFile;
/* 409 */     if (this.outputFile == null)
/* 410 */       throw new IOException("Output stream is not open"); 
/* 411 */     int[] generations = getFileGenerations(this.referenceFile);
/* 412 */     String name = this.referenceFile.getName();
/* 413 */     File parent = new File(this.referenceFile.getParent());
/*     */     
/* 415 */     if (generations == null) {
/* 416 */       newFile = new File(parent, String.valueOf(name) + ".1");
/*     */     } else {
/* 418 */       newFile = new File(parent, String.valueOf(name) + '.' + (generations[0] + 1));
/*     */     } 
/* 420 */     mv(this.outputFile, newFile);
/* 421 */     this.outputFile = null;
/* 422 */     this.appendChecksum = null;
/* 423 */     CacheInfo info = new CacheInfo(0, checksum, newFile.lastModified(), newFile.length());
/* 424 */     cacheFiles.put(newFile, info);
/* 425 */     cleanup(generations, true);
/* 426 */     if (!fileSharing) {
/* 427 */       synchronized (lastGenerationLock) {
/* 428 */         lastGenerationFile = null;
/* 429 */         lastGenerations = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void abortOutputFile() {
/* 439 */     if (this.outputFile == null)
/*     */       return; 
/* 441 */     this.outputFile.delete();
/* 442 */     this.outputFile = null;
/* 443 */     this.appendChecksum = null;
/*     */   }
/*     */   
/*     */   File getOutputFile() {
/* 447 */     return this.outputFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeInputFile() {
/* 454 */     this.inputFile = null;
/*     */   }
/*     */   
/*     */   private void cleanup(int[] generations, boolean generationAdded) {
/* 458 */     if (generations == null)
/*     */       return; 
/* 460 */     String name = this.referenceFile.getName();
/* 461 */     File parent = new File(this.referenceFile.getParent());
/* 462 */     int generationCount = generations.length;
/*     */ 
/*     */ 
/*     */     
/* 466 */     if (generations[generationCount - 1] == 0) {
/* 467 */       generationCount--;
/*     */     }
/* 469 */     int rmCount = generationCount - defaultMaxGenerations;
/* 470 */     if (generationAdded)
/* 471 */       rmCount++; 
/* 472 */     if (rmCount < 1)
/*     */       return; 
/* 474 */     synchronized (cacheFiles) {
/*     */       int idx;
/*     */       
/*     */       int count;
/* 478 */       for (idx = 0, count = generationCount - rmCount; idx < count; idx++) {
/* 479 */         File file = new File(parent, String.valueOf(name) + '.' + generations[idx]);
/* 480 */         CacheInfo info = cacheFiles.get(file);
/* 481 */         if (info != null && 
/* 482 */           info.filetype == 1) {
/* 483 */           rmCount--;
/*     */         }
/*     */       } 
/* 486 */       for (idx = generationCount - 1; rmCount > 0; idx--, rmCount--) {
/* 487 */         File rmFile = new File(parent, String.valueOf(name) + '.' + generations[idx]);
/* 488 */         rmFile.delete();
/* 489 */         cacheFiles.remove(rmFile);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mv(File from, File to) throws IOException {
/* 502 */     if (!from.renameTo(to)) {
/* 503 */       throw new IOException("rename failed");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cp(InputStream in, OutputStream out, int truncateSize, long length) throws IOException {
/*     */     try {
/* 514 */       if (truncateSize > length) {
/* 515 */         length = 0L;
/*     */       } else {
/* 517 */         length -= truncateSize;
/* 518 */       }  if (length > 0L) {
/*     */         int bufferSize;
/* 520 */         if (length > 4096L) {
/* 521 */           bufferSize = 4096;
/*     */         } else {
/* 523 */           bufferSize = (int)length;
/*     */         } 
/*     */         
/* 526 */         byte[] buffer = new byte[bufferSize];
/* 527 */         long size = 0L;
/*     */         int count;
/* 529 */         while ((count = in.read(buffer, 0, bufferSize)) > 0) {
/* 530 */           if (size + count >= length)
/* 531 */             count = (int)(length - size); 
/* 532 */           out.write(buffer, 0, count);
/* 533 */           size += count;
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       try {
/* 538 */         in.close();
/* 539 */       } catch (IOException iOException) {}
/*     */       
/* 541 */       out.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean exists(File file) {
/* 555 */     String prefix = String.valueOf(file.getName()) + '.';
/* 556 */     File parent = new File(file.getParent());
/* 557 */     int prefixLen = prefix.length();
/* 558 */     String[] files = parent.list();
/* 559 */     if (files == null)
/* 560 */       return false;  byte b; int i; String[] arrayOfString1;
/* 561 */     for (i = (arrayOfString1 = files).length, b = 0; b < i; ) { String candidateFile = arrayOfString1[b];
/* 562 */       if (candidateFile.startsWith(prefix)) {
/*     */         try {
/* 564 */           Integer.parseInt(candidateFile.substring(prefixLen));
/* 565 */           return true;
/* 566 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */       b++; }
/*     */     
/* 570 */     return file.exists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long lastModified(File file) {
/* 580 */     int[] generations = getFileGenerations(file);
/* 581 */     if (generations == null)
/* 582 */       return 0L; 
/* 583 */     if (generations[0] == 0)
/* 584 */       return file.lastModified(); 
/* 585 */     String name = file.getName();
/* 586 */     File parent = new File(file.getParent());
/* 587 */     File newFile = new File(parent, String.valueOf(name) + '.' + generations[0]);
/* 588 */     return newFile.lastModified();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long lastModified() {
/* 599 */     if (this.inputFile != null) {
/* 600 */       return this.inputFile.lastModified();
/*     */     }
/* 602 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int lastModifiedVersion(File file) {
/* 614 */     int[] generations = getFileGenerations(file);
/* 615 */     if (generations == null)
/* 616 */       return -1; 
/* 617 */     return generations[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean delete(File deleteFile) {
/* 628 */     int[] generations = getFileGenerations(deleteFile);
/* 629 */     if (generations == null)
/* 630 */       return false; 
/* 631 */     String name = deleteFile.getName();
/* 632 */     File parent = new File(deleteFile.getParent());
/* 633 */     synchronized (cacheFiles) {
/* 634 */       byte b; int i; int[] arrayOfInt; for (i = (arrayOfInt = generations).length, b = 0; b < i; ) { int generation = arrayOfInt[b];
/*     */         
/* 636 */         if (generation != 0) {
/*     */           
/* 638 */           File file = new File(parent, String.valueOf(name) + '.' + generation);
/* 639 */           if (file.exists()) {
/* 640 */             file.delete();
/*     */           }
/* 642 */           cacheFiles.remove(file);
/*     */         }  b++; }
/*     */     
/* 645 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getBaseFiles(File directory) throws IOException {
/* 656 */     if (!directory.isDirectory())
/* 657 */       throw new IOException("Not a valid directory"); 
/* 658 */     String[] files = directory.list();
/* 659 */     Set<String> list = new HashSet<>(files.length / 2); byte b; int i; String[] arrayOfString1;
/* 660 */     for (i = (arrayOfString1 = files).length, b = 0; b < i; ) { String file = arrayOfString1[b];
/* 661 */       int pos = file.lastIndexOf('.');
/* 662 */       if (pos != -1) {
/*     */         
/* 664 */         String ext = file.substring(pos + 1);
/* 665 */         int generation = 0;
/*     */         try {
/* 667 */           generation = Integer.parseInt(ext);
/* 668 */         } catch (NumberFormatException numberFormatException) {}
/*     */         
/* 670 */         if (generation != 0)
/*     */         
/* 672 */         { String base = file.substring(0, pos);
/* 673 */           list.add(base); } 
/*     */       }  b++; }
/* 675 */      files = new String[list.size()];
/* 676 */     int idx = 0;
/* 677 */     for (String string : list) {
/* 678 */       files[idx++] = string;
/*     */     }
/* 680 */     return files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cleanupGenerations(File base) {
/* 688 */     ReliableFile rf = new ReliableFile(base);
/* 689 */     int[] generations = getFileGenerations(base);
/* 690 */     rf.cleanup(generations, false);
/* 691 */     if (!fileSharing) {
/* 692 */       synchronized (lastGenerationLock) {
/* 693 */         lastGenerationFile = null;
/* 694 */         lastGenerations = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File createTempFile(String prefix, String suffix, File directory) throws IOException {
/* 707 */     if (directory == null) {
/* 708 */       throw new IllegalArgumentException("No directory specified.");
/*     */     }
/* 710 */     if (prefix == null) {
/* 711 */       throw new IllegalArgumentException("No prefix specified.");
/*     */     }
/* 713 */     if (suffix == null) {
/* 714 */       suffix = ".tmp";
/*     */     }
/* 716 */     for (int i = 0; i < 100000; i++) {
/* 717 */       File f = new File(directory, String.valueOf(prefix) + nextTemp.getAndUpdate(n -> {
/*     */               int next = n + 1;
/*     */               return (next > 100000) ? 1 : next;
/* 720 */             }) + suffix);
/* 721 */       if (f.createNewFile()) {
/* 722 */         return f;
/*     */       }
/*     */     } 
/* 725 */     throw new IOException("Maximum number of attempts reached to create a temporary file.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fileUpdated(File file) {
/* 734 */     if (!fileSharing) {
/* 735 */       synchronized (lastGenerationLock) {
/* 736 */         lastGenerationFile = null;
/* 737 */         lastGenerations = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeChecksumSignature(OutputStream out, Checksum checksum) throws IOException {
/* 750 */     out.write(identifier1);
/* 751 */     out.write(intToHex((int)checksum.getValue()));
/* 752 */     out.write(identifier2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getSignatureSize() throws IOException {
/* 766 */     if (this.inputFile != null) {
/* 767 */       CacheInfo info = cacheFiles.get(this.inputFile);
/* 768 */       if (info != null) {
/* 769 */         switch (info.filetype) {
/*     */           case 0:
/*     */           case 1:
/* 772 */             return 16;
/*     */           case 2:
/* 774 */             return 0;
/*     */         } 
/*     */       }
/*     */     } 
/* 778 */     throw new IOException("ReliableFile signature size is unknown");
/*     */   }
/*     */   
/*     */   long getInputLength() throws IOException {
/* 782 */     if (this.inputFile != null) {
/* 783 */       CacheInfo info = cacheFiles.get(this.inputFile);
/* 784 */       if (info != null) {
/* 785 */         return info.length;
/*     */       }
/*     */     } 
/* 788 */     throw new IOException("ReliableFile length is unknown");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Checksum getFileChecksum() throws IOException {
/* 801 */     if (this.appendChecksum == null)
/* 802 */       throw new IOException("Checksum is invalid!"); 
/* 803 */     return this.appendChecksum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Checksum getChecksumCalculator() {
/* 814 */     return new CRC32();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getStreamType(InputStream is, Checksum crc, long len) throws IOException {
/* 824 */     boolean markSupported = (len < 2147483647L && is.markSupported());
/* 825 */     if (markSupported)
/* 826 */       is.mark((int)len); 
/*     */     try {
/* 828 */       if (len < 16L) {
/* 829 */         if (crc != null) {
/* 830 */           byte[] arrayOfByte = new byte[16];
/* 831 */           int k = is.read(arrayOfByte);
/* 832 */           if (k > 0)
/* 833 */             crc.update(arrayOfByte, 0, k); 
/*     */         } 
/* 835 */         return 2;
/*     */       } 
/* 837 */       len -= 16L;
/*     */       
/* 839 */       int pos = 0;
/* 840 */       byte[] data = new byte[4096];
/*     */       
/* 842 */       while (pos < len) {
/* 843 */         int read = data.length;
/* 844 */         if ((pos + read) > len) {
/* 845 */           read = (int)(len - pos);
/*     */         }
/* 847 */         int k = is.read(data, 0, read);
/* 848 */         if (k == -1) {
/* 849 */           throw new IOException("Unable to read entire file.");
/*     */         }
/*     */         
/* 852 */         crc.update(data, 0, k);
/* 853 */         pos += k;
/*     */       } 
/*     */       
/* 856 */       int num = is.read(data);
/* 857 */       if (num != 16) {
/* 858 */         throw new IOException("Unable to read entire file.");
/*     */       }
/*     */       
/*     */       int i;
/* 862 */       for (i = 0; i < 4; i++) {
/* 863 */         if (identifier1[i] != data[i]) {
/* 864 */           crc.update(data, 0, 16);
/* 865 */           return 2;
/*     */         } 
/* 867 */       }  int j; for (i = 0, j = 12; i < 4; i++, j++) {
/* 868 */         if (identifier2[i] != data[j]) {
/* 869 */           crc.update(data, 0, 16);
/* 870 */           return 2;
/*     */         } 
/* 872 */       }  long crccmp = Long.valueOf(new String(data, 4, 8, StandardCharsets.UTF_8), 16).longValue();
/* 873 */       if (crccmp == crc.getValue()) {
/* 874 */         return 0;
/*     */       }
/*     */       
/* 877 */       return 1;
/*     */     } finally {
/* 879 */       if (markSupported)
/* 880 */         is.reset(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] intToHex(int l) {
/* 885 */     byte[] buffer = new byte[8];
/* 886 */     int count = 8;
/*     */     
/*     */     do {
/* 889 */       int ch = l & 0xF;
/* 890 */       if (ch > 9) {
/* 891 */         ch = ch - 10 + 97;
/*     */       } else {
/* 893 */         ch += 48;
/* 894 */       }  buffer[--count] = (byte)ch;
/* 895 */       l >>= 4;
/* 896 */     } while (count > 0);
/* 897 */     return buffer;
/*     */   }
/*     */   
/*     */   private class CacheInfo {
/*     */     int filetype;
/*     */     Checksum checksum;
/*     */     long timeStamp;
/*     */     long length;
/*     */     
/*     */     CacheInfo(int filetype, Checksum checksum, long timeStamp, long length) {
/* 907 */       this.filetype = filetype;
/* 908 */       this.checksum = checksum;
/* 909 */       this.timeStamp = timeStamp;
/* 910 */       this.length = length;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\internal\reliablefile\ReliableFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */