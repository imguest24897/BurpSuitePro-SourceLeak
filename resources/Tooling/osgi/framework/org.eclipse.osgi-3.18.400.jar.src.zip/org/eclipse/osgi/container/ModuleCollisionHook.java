package org.eclipse.osgi.container;

import java.util.Collection;

public interface ModuleCollisionHook {
  public static final int INSTALLING = 1;
  
  public static final int UPDATING = 2;
  
  void filterCollisions(int paramInt, Module paramModule, Collection<Module> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleCollisionHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */