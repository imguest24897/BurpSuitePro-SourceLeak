/*     */ package org.eclipse.osgi.internal.debug;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.AccessController;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.service.debug.DebugTrace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EclipseDebugTrace
/*     */   implements DebugTrace
/*     */ {
/*     */   private static final String PROP_TRACE_SIZE_MAX = "eclipse.trace.size.max";
/*     */   private static final String PROP_TRACE_FILE_MAX = "eclipse.trace.backup.max";
/*     */   private static final String MESSAGE_THREAD_DUMP = "Thread Stack dump: ";
/*     */   private static final String MESSAGE_EXIT_METHOD_WITH_RESULTS = "Exiting method {0}with result: ";
/*     */   private static final String MESSAGE_EXIT_METHOD_NO_RESULTS = "Exiting method {0}with a void return";
/*     */   private static final String MESSAGE_ENTER_METHOD_WITH_PARAMS = "Entering method {0}with parameters: (";
/*     */   private static final String MESSAGE_ENTER_METHOD_NO_PARAMS = "Entering method {0}with no parameters";
/*     */   private static final String TRACE_FILE_VERSION_COMMENT = "version: ";
/*     */   private static final String TRACE_FILE_VERBOSE_COMMENT = "verbose: ";
/*     */   private static final String TRACE_FILE_VERSION = "1.1";
/*     */   private static final String TRACE_NEW_SESSION = "!SESSION ";
/*     */   private static final String TRACE_FILE_DATE = "Time of creation: ";
/*  64 */   private static final SimpleDateFormat TRACE_FILE_DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
/*     */   
/*     */   private static final String TRACE_COMMENT = "#";
/*     */   
/*     */   private static final String TRACE_ELEMENT_DELIMITER = "|";
/*     */   private static final String TRACE_ELEMENT_DELIMITER_ENCODED = "&#124;";
/*     */   private static final String LINE_SEPARATOR;
/*     */   private static final String NULL_VALUE = "<null>";
/*     */   
/*     */   static {
/*  74 */     String s = System.lineSeparator();
/*  75 */     LINE_SEPARATOR = (s == null) ? "\n" : s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_TRACE_FILE_SIZE = 1000;
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_TRACE_FILES = 10;
/*     */   
/*     */   private static final int DEFAULT_TRACE_FILE_MIN_SIZE = 10;
/*     */   
/*     */   private static final String TRACE_FILE_EXTENSION = ".trace";
/*     */   
/*     */   private static final String BACKUP_MARK = ".bak_";
/*     */   
/*  94 */   private int maxTraceFileSize = 1000;
/*     */   
/*  96 */   private int maxTraceFiles = 10;
/*     */   
/*  98 */   private int backupTraceFileIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private String traceClass = null;
/*     */   
/* 105 */   private String bundleSymbolicName = null;
/*     */   
/* 107 */   private FrameworkDebugOptions debugOptions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean consoleLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EclipseDebugTrace(String bundleSymbolicName, FrameworkDebugOptions debugOptions, Class<?> traceClass) {
/* 120 */     this.consoleLog = "true".equals(debugOptions.getConfiguration().getConfiguration("eclipse.consoleLog"));
/* 121 */     this.traceClass = (traceClass != null) ? traceClass.getName() : null;
/* 122 */     this.debugOptions = debugOptions;
/* 123 */     this.bundleSymbolicName = bundleSymbolicName;
/* 124 */     readLogProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isDebuggingEnabled(String optionPath) {
/* 134 */     if (optionPath == null)
/* 135 */       return true; 
/* 136 */     boolean debugEnabled = false;
/* 137 */     if (this.debugOptions.isDebugEnabled()) {
/* 138 */       String option = String.valueOf(this.bundleSymbolicName) + optionPath;
/* 139 */       debugEnabled = this.debugOptions.getBooleanOption(option, false);
/*     */     } 
/* 141 */     return debugEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String optionPath, String message) {
/* 151 */     if (isDebuggingEnabled(optionPath)) {
/* 152 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, message, this.traceClass);
/* 153 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String optionPath, String message, Throwable error) {
/* 164 */     if (isDebuggingEnabled(optionPath)) {
/* 165 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, message, error, this.traceClass);
/* 166 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceEntry(String optionPath) {
/* 177 */     if (isDebuggingEnabled(optionPath)) {
/* 178 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, null, this.traceClass);
/* 179 */       record.setMessage(createMessage(record, "Entering method {0}with no parameters"));
/* 180 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceEntry(String optionPath, Object methodArgument) {
/* 191 */     if (isDebuggingEnabled(optionPath)) {
/* 192 */       traceEntry(optionPath, new Object[] { methodArgument });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceEntry(String optionPath, Object[] methodArguments) {
/* 203 */     if (isDebuggingEnabled(optionPath)) {
/* 204 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, null, 
/* 205 */           this.traceClass);
/* 206 */       StringBuilder messageBuffer = new StringBuilder(
/* 207 */           createMessage(record, "Entering method {0}with parameters: ("));
/* 208 */       if (methodArguments != null) {
/* 209 */         int i = 0;
/* 210 */         while (i < methodArguments.length) {
/* 211 */           if (methodArguments[i] != null) {
/* 212 */             messageBuffer.append(methodArguments[i].toString());
/*     */           } else {
/* 214 */             messageBuffer.append("<null>");
/*     */           } 
/* 216 */           i++;
/* 217 */           if (i < methodArguments.length) {
/* 218 */             messageBuffer.append(" ");
/*     */           }
/*     */         } 
/* 221 */         messageBuffer.append(")");
/*     */       } 
/*     */       
/* 224 */       record.setMessage(messageBuffer.toString());
/* 225 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceExit(String optionPath) {
/* 236 */     if (isDebuggingEnabled(optionPath)) {
/* 237 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, null, this.traceClass);
/* 238 */       record.setMessage(createMessage(record, "Exiting method {0}with a void return"));
/* 239 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceExit(String optionPath, Object result) {
/* 250 */     if (isDebuggingEnabled(optionPath)) {
/* 251 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, null, 
/* 252 */           this.traceClass);
/* 253 */       StringBuilder messageBuffer = new StringBuilder(
/* 254 */           createMessage(record, "Exiting method {0}with result: "));
/* 255 */       if (result == null) {
/* 256 */         messageBuffer.append("<null>");
/*     */       } else {
/* 258 */         messageBuffer.append(result.toString());
/*     */       } 
/*     */       
/* 261 */       record.setMessage(messageBuffer.toString());
/* 262 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traceDumpStack(String optionPath) {
/* 273 */     if (isDebuggingEnabled(optionPath)) {
/* 274 */       StringBuilder messageBuffer = new StringBuilder("Thread Stack dump: ");
/* 275 */       StackTraceElement[] elements = (new Exception()).getStackTrace();
/*     */ 
/*     */ 
/*     */       
/* 279 */       int firstIndex = (this.traceClass == null) ? 1 : 2;
/* 280 */       int endIndex = elements.length - firstIndex;
/* 281 */       StackTraceElement[] newElements = new StackTraceElement[endIndex];
/* 282 */       int i = 0;
/* 283 */       while (i < endIndex) {
/* 284 */         newElements[i] = elements[firstIndex];
/* 285 */         i++;
/* 286 */         firstIndex++;
/*     */       } 
/* 288 */       messageBuffer.append(convertStackTraceElementsToString(newElements));
/* 289 */       FrameworkDebugTraceEntry record = new FrameworkDebugTraceEntry(this.bundleSymbolicName, optionPath, messageBuffer.toString(), this.traceClass);
/* 290 */       writeRecord(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String createMessage(FrameworkDebugTraceEntry record, String originalMessage) {
/* 303 */     String argument = null;
/* 304 */     if (!this.debugOptions.isVerbose()) {
/* 305 */       StringBuilder classMethodName = new StringBuilder(record.getClassName());
/* 306 */       classMethodName.append("#");
/* 307 */       classMethodName.append(record.getMethodName());
/* 308 */       classMethodName.append(" ");
/* 309 */       argument = classMethodName.toString();
/*     */     } else {
/* 311 */       argument = "";
/*     */     } 
/* 313 */     return MessageFormat.format(originalMessage, new Object[] { argument });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String convertStackTraceElementsToString(StackTraceElement[] elements) {
/* 326 */     StringBuilder buffer = new StringBuilder();
/* 327 */     if (elements != null) {
/* 328 */       buffer.append("java.lang.Throwable: ");
/* 329 */       buffer.append(LINE_SEPARATOR);
/* 330 */       int i = 0;
/* 331 */       while (i < elements.length) {
/* 332 */         if (elements[i] != null) {
/* 333 */           buffer.append("\tat ");
/* 334 */           buffer.append(elements[i].toString());
/* 335 */           buffer.append(LINE_SEPARATOR);
/*     */         } 
/* 337 */         i++;
/*     */       } 
/*     */     } 
/* 340 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeRecord(FrameworkDebugTraceEntry entry) {
/* 350 */     if (entry != null) {
/* 351 */       synchronized (this.debugOptions.getWriteLock()) {
/* 352 */         File tracingFile = this.debugOptions.getFile();
/* 353 */         Writer traceWriter = null;
/*     */         
/*     */         try {
/* 356 */           checkTraceFileSize(tracingFile, entry.getTimestamp());
/*     */           
/* 358 */           traceWriter = openWriter(tracingFile);
/* 359 */           if (this.debugOptions.newSession()) {
/* 360 */             writeSession(traceWriter, entry.getTimestamp());
/*     */           }
/* 362 */           writeMessage(traceWriter, entry);
/*     */           
/* 364 */           traceWriter.flush();
/* 365 */         } catch (Exception ex) {
/*     */           
/* 367 */           System.err.println("An exception occurred while writing to the platform trace file: ");
/* 368 */           ex.printStackTrace(System.err);
/*     */         } finally {
/*     */           
/* 371 */           closeWriter(traceWriter);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readLogProperties() {
/* 382 */     String newMaxTraceFileSize = this.debugOptions.getConfiguration().getConfiguration("eclipse.trace.size.max");
/* 383 */     if (newMaxTraceFileSize != null) {
/* 384 */       this.maxTraceFileSize = Integer.parseInt(newMaxTraceFileSize);
/* 385 */       if (this.maxTraceFileSize != 0 && this.maxTraceFileSize < 10)
/*     */       {
/*     */         
/* 388 */         this.maxTraceFileSize = 10;
/*     */       }
/*     */     } 
/*     */     
/* 392 */     String newMaxLogFiles = this.debugOptions.getConfiguration().getConfiguration("eclipse.trace.backup.max");
/* 393 */     if (newMaxLogFiles != null) {
/* 394 */       this.maxTraceFiles = Integer.parseInt(newMaxLogFiles);
/* 395 */       if (this.maxTraceFiles < 1)
/*     */       {
/* 397 */         this.maxTraceFiles = 10;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkTraceFileSize(File traceFile, long timestamp) {
/* 412 */     boolean isBackupOK = true;
/* 413 */     if (this.maxTraceFileSize > 0 && 
/* 414 */       traceFile != null && traceFile.exists() && 
/* 415 */       traceFile.length() >> 10L > this.maxTraceFileSize) {
/* 416 */       String traceFileName = traceFile.getAbsolutePath();
/*     */ 
/*     */       
/* 419 */       String backupFilename = "";
/* 420 */       if (traceFileName.toLowerCase().endsWith(".trace")) {
/* 421 */         backupFilename = String.valueOf(traceFileName.substring(0, traceFileName.length() - ".trace".length())) + ".bak_" + this.backupTraceFileIndex + ".trace";
/*     */       } else {
/* 423 */         backupFilename = String.valueOf(traceFileName) + ".bak_" + this.backupTraceFileIndex;
/*     */       } 
/* 425 */       File backupFile = new File(backupFilename);
/* 426 */       if (backupFile.exists() && 
/* 427 */         !backupFile.delete()) {
/* 428 */         System.err.println("Error when trying to delete old trace file: " + backupFile.getName());
/* 429 */         if (backupFile.renameTo(new File(String.valueOf(backupFile.getAbsolutePath()) + System.currentTimeMillis()))) {
/* 430 */           System.err.println("So we rename it to filename: " + backupFile.getName());
/*     */         } else {
/* 432 */           System.err.println("And we also cannot rename it!");
/* 433 */           isBackupOK = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 439 */       boolean isRenameOK = traceFile.renameTo(backupFile);
/* 440 */       if (!isRenameOK) {
/* 441 */         System.err.println("Error when trying to rename trace file to backup one.");
/* 442 */         isBackupOK = false;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 449 */       Writer traceWriter = null;
/*     */       try {
/* 451 */         traceWriter = openWriter(traceFile);
/* 452 */         writeComment(traceWriter, "This is a continuation of trace file " + backupFile.getAbsolutePath());
/* 453 */         writeComment(traceWriter, "version: 1.1");
/* 454 */         writeComment(traceWriter, "verbose: " + this.debugOptions.isVerbose());
/* 455 */         writeComment(traceWriter, "Time of creation: " + getFormattedDate(timestamp));
/* 456 */         traceWriter.flush();
/* 457 */       } catch (IOException ioEx) {
/* 458 */         ioEx.printStackTrace();
/*     */       } finally {
/* 460 */         closeWriter(traceWriter);
/*     */       } 
/* 462 */       this.backupTraceFileIndex = ++this.backupTraceFileIndex % this.maxTraceFiles;
/*     */     } 
/*     */ 
/*     */     
/* 466 */     return isBackupOK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeComment(Writer traceWriter, String comment) throws IOException {
/* 478 */     StringBuilder commentText = new StringBuilder("#");
/* 479 */     commentText.append(" ");
/* 480 */     commentText.append(comment);
/* 481 */     commentText.append(LINE_SEPARATOR);
/* 482 */     traceWriter.write(commentText.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getFormattedDate(long timestamp) {
/* 492 */     return TRACE_FILE_DATE_FORMATTER.format(new Date(timestamp));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getFormattedThrowable(Throwable error) {
/* 504 */     String result = null;
/* 505 */     if (error != null) {
/* 506 */       PrintStream throwableStream = null;
/*     */       try {
/* 508 */         ByteArrayOutputStream throwableByteOutputStream = new ByteArrayOutputStream();
/* 509 */         throwableStream = new PrintStream(throwableByteOutputStream, false);
/* 510 */         error.printStackTrace(throwableStream);
/* 511 */         result = encodeText(throwableByteOutputStream.toString());
/*     */       } finally {
/* 513 */         if (throwableStream != null) {
/* 514 */           throwableStream.close();
/*     */         }
/*     */       } 
/*     */     } 
/* 518 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSession(Writer traceWriter, long timestamp) throws IOException {
/* 530 */     writeComment(traceWriter, "!SESSION " + getFormattedDate(timestamp));
/* 531 */     writeComment(traceWriter, "version: 1.1");
/* 532 */     writeComment(traceWriter, "verbose: " + this.debugOptions.isVerbose());
/* 533 */     writeComment(traceWriter, "The following option strings are specified for this debug session:");
/* 534 */     String[] allOptions = this.debugOptions.getAllOptions(); byte b; int i; String[] arrayOfString1;
/* 535 */     for (i = (arrayOfString1 = allOptions).length, b = 0; b < i; ) { String allOption = arrayOfString1[b];
/* 536 */       writeComment(traceWriter, "\t" + allOption);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMessage(Writer traceWriter, FrameworkDebugTraceEntry entry) throws IOException {
/* 551 */     StringBuilder message = new StringBuilder("|");
/* 552 */     message.append(" ");
/* 553 */     message.append(encodeText(entry.getThreadName()));
/* 554 */     message.append(" ");
/* 555 */     message.append("|");
/* 556 */     message.append(" ");
/* 557 */     message.append(getFormattedDate(entry.getTimestamp()));
/* 558 */     message.append(" ");
/* 559 */     message.append("|");
/* 560 */     message.append(" ");
/* 561 */     if (!this.debugOptions.isVerbose()) {
/*     */       
/* 563 */       message.append(encodeText(entry.getMessage()));
/*     */     } else {
/*     */       
/* 566 */       message.append(entry.getBundleSymbolicName());
/* 567 */       message.append(" ");
/* 568 */       message.append("|");
/* 569 */       message.append(" ");
/* 570 */       message.append(encodeText(entry.getOptionPath()));
/* 571 */       message.append(" ");
/* 572 */       message.append("|");
/* 573 */       message.append(" ");
/* 574 */       message.append(entry.getClassName());
/* 575 */       message.append(" ");
/* 576 */       message.append("|");
/* 577 */       message.append(" ");
/* 578 */       message.append(entry.getMethodName());
/* 579 */       message.append(" ");
/* 580 */       message.append("|");
/* 581 */       message.append(" ");
/* 582 */       message.append(entry.getLineNumber());
/* 583 */       message.append(" ");
/* 584 */       message.append("|");
/* 585 */       message.append(" ");
/* 586 */       message.append(encodeText(entry.getMessage()));
/*     */     } 
/* 588 */     if (entry.getThrowable() != null) {
/* 589 */       message.append(" ");
/* 590 */       message.append("|");
/* 591 */       message.append(" ");
/* 592 */       message.append(getFormattedThrowable(entry.getThrowable()));
/*     */     } 
/* 594 */     message.append(" ");
/* 595 */     message.append("|");
/* 596 */     message.append(LINE_SEPARATOR);
/*     */     
/* 598 */     if (traceWriter != null && message != null) {
/* 599 */       traceWriter.write(message.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encodeText(String inputString) {
/* 616 */     return (inputString == null) ? null : 
/* 617 */       inputString.replace("|", "&#124;");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer logForStream(OutputStream output) {
/* 626 */     return new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer openWriter(File traceFile) {
/* 637 */     OutputStream out = null;
/* 638 */     if (traceFile != null) {
/*     */       try {
/* 640 */         out = secureAction.getFileOutputStream(traceFile, true);
/* 641 */       } catch (IOException ioEx) {
/*     */         
/* 643 */         System.err.println("Unable to open trace file: " + traceFile + ": " + ioEx.getMessage());
/*     */       } 
/*     */     }
/* 646 */     if (out == null) {
/* 647 */       out = new FilterOutputStream(System.out)
/*     */         {
/*     */           public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void write(byte[] var0, int var1, int var2) throws IOException {
/* 658 */             this.out.write(var0, var1, var2);
/*     */           }
/*     */         };
/* 661 */     } else if (this.consoleLog) {
/* 662 */       out = new FilterOutputStream(out)
/*     */         {
/*     */           public void write(int b) throws IOException {
/* 665 */             System.out.write(b);
/* 666 */             this.out.write(b);
/*     */           }
/*     */ 
/*     */           
/*     */           public void write(byte[] b) throws IOException {
/* 671 */             System.out.write(b);
/* 672 */             this.out.write(b);
/*     */           }
/*     */ 
/*     */           
/*     */           public void write(byte[] b, int off, int len) throws IOException {
/* 677 */             System.out.write(b, off, len);
/* 678 */             this.out.write(b, off, len);
/*     */           }
/*     */         };
/*     */     } 
/* 682 */     return logForStream(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeWriter(Writer traceWriter) {
/* 692 */     if (traceWriter != null) {
/*     */       try {
/* 694 */         traceWriter.close();
/* 695 */       } catch (IOException ioEx) {
/*     */         
/* 697 */         ioEx.printStackTrace();
/*     */       } 
/* 699 */       traceWriter = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\debug\EclipseDebugTrace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */