/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleRequirement;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.osgi.dto.DTO;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.dto.BundleDTO;
/*     */ import org.osgi.framework.dto.FrameworkDTO;
/*     */ import org.osgi.framework.dto.ServiceReferenceDTO;
/*     */ import org.osgi.framework.startlevel.BundleStartLevel;
/*     */ import org.osgi.framework.startlevel.FrameworkStartLevel;
/*     */ import org.osgi.framework.startlevel.dto.BundleStartLevelDTO;
/*     */ import org.osgi.framework.startlevel.dto.FrameworkStartLevelDTO;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRequirement;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleRevisions;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.framework.wiring.dto.BundleRevisionDTO;
/*     */ import org.osgi.framework.wiring.dto.BundleWireDTO;
/*     */ import org.osgi.framework.wiring.dto.BundleWiringDTO;
/*     */ import org.osgi.framework.wiring.dto.FrameworkWiringDTO;
/*     */ import org.osgi.resource.dto.CapabilityDTO;
/*     */ import org.osgi.resource.dto.CapabilityRefDTO;
/*     */ import org.osgi.resource.dto.RequirementDTO;
/*     */ import org.osgi.resource.dto.RequirementRefDTO;
/*     */ import org.osgi.resource.dto.WireDTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTOBuilder
/*     */ {
/*  65 */   private final Map<BundleRevision, BundleRevisionDTO> resources = new IdentityHashMap<>();
/*  66 */   private final Map<BundleWiring, BundleWiringDTO.NodeDTO> wiringnodes = new IdentityHashMap<>();
/*     */ 
/*     */   
/*     */   public static BundleDTO newBundleDTO(Bundle bundle) {
/*  70 */     if (bundle == null) {
/*  71 */       return null;
/*     */     }
/*  73 */     BundleDTO dto = new BundleDTO();
/*  74 */     dto.id = bundle.getBundleId();
/*  75 */     dto.lastModified = bundle.getLastModified();
/*  76 */     dto.state = bundle.getState();
/*  77 */     dto.symbolicName = bundle.getSymbolicName();
/*  78 */     dto.version = bundle.getVersion().toString();
/*  79 */     return dto;
/*     */   }
/*     */   
/*     */   public static BundleStartLevelDTO newBundleStartLevelDTO(Bundle b, BundleStartLevel bsl) {
/*  83 */     if (bsl == null) {
/*  84 */       return null;
/*     */     }
/*  86 */     BundleStartLevelDTO dto = new BundleStartLevelDTO();
/*  87 */     dto.bundle = b.getBundleId();
/*  88 */     dto.activationPolicyUsed = bsl.isActivationPolicyUsed();
/*  89 */     dto.persistentlyStarted = bsl.isPersistentlyStarted();
/*  90 */     dto.startLevel = bsl.getStartLevel();
/*  91 */     return dto;
/*     */   }
/*     */   
/*     */   public static BundleRevisionDTO newBundleRevisionDTO(BundleRevision revision) {
/*  95 */     BundleRevisionDTO dto = (new DTOBuilder()).getBundleRevisionDTO(revision);
/*  96 */     return dto;
/*     */   }
/*     */   
/*     */   private int getResourceId(BundleRevision revision) {
/* 100 */     BundleRevisionDTO dto = getBundleRevisionDTO(revision);
/* 101 */     if (dto == null) {
/* 102 */       return 0;
/*     */     }
/* 104 */     return dto.id;
/*     */   }
/*     */   
/*     */   private BundleRevisionDTO getBundleRevisionDTO(BundleRevision revision) {
/* 108 */     if (revision == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     BundleRevisionDTO dto = this.resources.get(revision);
/* 112 */     if (dto != null) {
/* 113 */       return dto;
/*     */     }
/* 115 */     dto = new BundleRevisionDTO();
/* 116 */     dto.id = identifier(revision);
/* 117 */     this.resources.put(revision, dto);
/* 118 */     dto.bundle = revision.getBundle().getBundleId();
/* 119 */     dto.symbolicName = revision.getSymbolicName();
/* 120 */     dto.type = revision.getTypes();
/* 121 */     dto.version = revision.getVersion().toString();
/* 122 */     dto.capabilities = getListCapabilityDTO(revision.getDeclaredCapabilities(null));
/* 123 */     dto.requirements = getListRequirementDTO(revision.getDeclaredRequirements(null));
/* 124 */     return dto;
/*     */   }
/*     */   
/*     */   private List<CapabilityDTO> getListCapabilityDTO(List<BundleCapability> caps) {
/* 128 */     if (caps == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     List<CapabilityDTO> dtos = newList(caps.size());
/* 132 */     for (BundleCapability cap : caps) {
/* 133 */       dtos.add(getCapabilityDTO(cap));
/*     */     }
/* 135 */     return dtos;
/*     */   }
/*     */   
/*     */   private CapabilityDTO getCapabilityDTO(BundleCapability cap) {
/* 139 */     if (cap == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     CapabilityDTO dto = new CapabilityDTO();
/* 143 */     dto.id = identifier(cap);
/* 144 */     dto.namespace = cap.getNamespace();
/* 145 */     dto.resource = getResourceId(cap.getRevision());
/* 146 */     dto.attributes = newAttributesMapDTO(cap.getAttributes());
/* 147 */     dto.directives = newDirectivesMapDTO(cap.getDirectives());
/* 148 */     return dto;
/*     */   }
/*     */   
/*     */   private List<CapabilityRefDTO> getListCapabilityRefDTO(List<ModuleCapability> caps) {
/* 152 */     if (caps == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     List<CapabilityRefDTO> dtos = newList(caps.size());
/* 156 */     for (BundleCapability cap : caps) {
/* 157 */       dtos.add(getCapabilityRefDTO(cap));
/*     */     }
/* 159 */     return dtos;
/*     */   }
/*     */   
/*     */   private CapabilityRefDTO getCapabilityRefDTO(BundleCapability cap) {
/* 163 */     if (cap == null) {
/* 164 */       return null;
/*     */     }
/* 166 */     CapabilityRefDTO dto = new CapabilityRefDTO();
/* 167 */     dto.capability = identifier(cap);
/* 168 */     dto.resource = getResourceId(cap.getRevision());
/* 169 */     return dto;
/*     */   }
/*     */   
/*     */   private List<RequirementDTO> getListRequirementDTO(List<BundleRequirement> reqs) {
/* 173 */     if (reqs == null) {
/* 174 */       return null;
/*     */     }
/* 176 */     List<RequirementDTO> dtos = newList(reqs.size());
/* 177 */     for (BundleRequirement req : reqs) {
/* 178 */       dtos.add(getRequirementDTO(req));
/*     */     }
/* 180 */     return dtos;
/*     */   }
/*     */   
/*     */   private RequirementDTO getRequirementDTO(BundleRequirement req) {
/* 184 */     if (req == null) {
/* 185 */       return null;
/*     */     }
/* 187 */     RequirementDTO dto = new RequirementDTO();
/* 188 */     dto.id = identifier(req);
/* 189 */     dto.namespace = req.getNamespace();
/* 190 */     dto.resource = getResourceId(req.getRevision());
/* 191 */     dto.attributes = newAttributesMapDTO(req.getAttributes());
/* 192 */     dto.directives = newDirectivesMapDTO(req.getDirectives());
/* 193 */     return dto;
/*     */   }
/*     */   
/*     */   private List<RequirementRefDTO> getListRequirementRefDTO(List<ModuleRequirement> reqs) {
/* 197 */     if (reqs == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     List<RequirementRefDTO> dtos = newList(reqs.size());
/* 201 */     for (ModuleRequirement req : reqs) {
/* 202 */       dtos.add(getRequirementRefDTO(req));
/*     */     }
/* 204 */     return dtos;
/*     */   }
/*     */   
/*     */   private RequirementRefDTO getRequirementRefDTO(ModuleRequirement req) {
/* 208 */     if (req == null) {
/* 209 */       return null;
/*     */     }
/* 211 */     RequirementRefDTO dto = new RequirementRefDTO();
/* 212 */     dto.requirement = identifier(req);
/* 213 */     dto.resource = getResourceId((BundleRevision)req.getRevision());
/* 214 */     return dto;
/*     */   }
/*     */   
/*     */   public static BundleRevisionDTO[] newArrayBundleRevisionDTO(BundleRevisions revisions) {
/* 218 */     if (revisions == null) {
/* 219 */       return null;
/*     */     }
/* 221 */     List<BundleRevision> revs = revisions.getRevisions();
/* 222 */     int size = revs.size();
/* 223 */     BundleRevisionDTO[] dtos = new BundleRevisionDTO[size];
/* 224 */     for (int i = 0; i < size; i++) {
/* 225 */       dtos[i] = (new DTOBuilder()).getBundleRevisionDTO(revs.get(i));
/*     */     }
/* 227 */     return dtos;
/*     */   }
/*     */   
/*     */   public static BundleWiringDTO newBundleWiringDTO(BundleRevision revision) {
/* 231 */     if (revision == null) {
/* 232 */       return null;
/*     */     }
/* 234 */     BundleWiringDTO dto = (new DTOBuilder()).getBundleWiringDTO((ModuleWiring)revision.getWiring());
/* 235 */     return dto;
/*     */   }
/*     */   
/*     */   public static FrameworkWiringDTO newFrameworkWiringDTO(Collection<ModuleWiring> allWirings) {
/* 239 */     DTOBuilder builder = new DTOBuilder();
/* 240 */     for (ModuleWiring wiring : allWirings) {
/* 241 */       builder.getBundleWiringNodeDTO(wiring);
/*     */     }
/* 243 */     FrameworkWiringDTO dto = new FrameworkWiringDTO();
/* 244 */     dto.wirings = new HashSet(builder.wiringnodes.values());
/* 245 */     dto.resources = new HashSet(builder.resources.values());
/* 246 */     return dto;
/*     */   }
/*     */   
/*     */   private BundleWiringDTO getBundleWiringDTO(ModuleWiring wiring) {
/* 250 */     if (wiring == null) {
/* 251 */       return null;
/*     */     }
/* 253 */     BundleWiringDTO dto = new BundleWiringDTO();
/* 254 */     dto.bundle = wiring.getBundle().getBundleId();
/* 255 */     dto.root = getWiringId(wiring);
/* 256 */     dto.nodes = new HashSet(this.wiringnodes.values());
/* 257 */     dto.resources = new HashSet(this.resources.values());
/* 258 */     return dto;
/*     */   }
/*     */   
/*     */   private int getWiringId(ModuleWiring wiring) {
/* 262 */     BundleWiringDTO.NodeDTO dto = getBundleWiringNodeDTO(wiring);
/* 263 */     if (dto == null) {
/* 264 */       return 0;
/*     */     }
/* 266 */     return dto.id;
/*     */   }
/*     */   
/*     */   private BundleWiringDTO.NodeDTO getBundleWiringNodeDTO(ModuleWiring wiring) {
/* 270 */     if (wiring == null) {
/* 271 */       return null;
/*     */     }
/* 273 */     BundleWiringDTO.NodeDTO dto = this.wiringnodes.get(wiring);
/* 274 */     if (dto != null) {
/* 275 */       return dto;
/*     */     }
/* 277 */     dto = new BundleWiringDTO.NodeDTO();
/* 278 */     dto.id = identifier(wiring);
/* 279 */     this.wiringnodes.put(wiring, dto);
/* 280 */     dto.current = wiring.isCurrent();
/* 281 */     dto.inUse = wiring.isInUse();
/* 282 */     dto.resource = getResourceId((BundleRevision)wiring.getRevision());
/* 283 */     dto.capabilities = getListCapabilityRefDTO(wiring.getModuleCapabilities(null));
/* 284 */     dto.requirements = getListRequirementRefDTO(wiring.getModuleRequirements(null));
/* 285 */     dto.providedWires = getListBundleWireDTO(wiring.getProvidedModuleWires(null));
/* 286 */     dto.requiredWires = getListBundleWireDTO(wiring.getRequiredModuleWires(null));
/* 287 */     return dto;
/*     */   }
/*     */   
/*     */   private List<WireDTO> getListBundleWireDTO(List<ModuleWire> wires) {
/* 291 */     if (wires == null) {
/* 292 */       return null;
/*     */     }
/* 294 */     List<WireDTO> dtos = newList(wires.size());
/* 295 */     for (ModuleWire wire : wires) {
/* 296 */       dtos.add(getBundleWireDTO(wire));
/*     */     }
/* 298 */     return dtos;
/*     */   }
/*     */   
/*     */   private BundleWireDTO getBundleWireDTO(ModuleWire wire) {
/* 302 */     if (wire == null) {
/* 303 */       return null;
/*     */     }
/* 305 */     BundleWireDTO dto = new BundleWireDTO();
/* 306 */     dto.capability = getCapabilityRefDTO((BundleCapability)wire.getCapability());
/* 307 */     dto.requirement = getRequirementRefDTO(wire.getRequirement());
/* 308 */     dto.provider = getResourceId((BundleRevision)wire.getProvider());
/* 309 */     dto.requirer = getResourceId((BundleRevision)wire.getRequirer());
/* 310 */     dto.providerWiring = getWiringId(wire.getProviderWiring());
/* 311 */     dto.requirerWiring = getWiringId(wire.getRequirerWiring());
/* 312 */     return dto;
/*     */   }
/*     */   
/*     */   public static BundleWiringDTO[] newArrayBundleWiringDTO(BundleRevisions revisions) {
/* 316 */     if (revisions == null) {
/* 317 */       return null;
/*     */     }
/* 319 */     List<BundleRevision> revs = revisions.getRevisions();
/* 320 */     int size = revs.size();
/* 321 */     List<BundleWiringDTO> dtos = new ArrayList<>(size);
/* 322 */     for (int i = 0; i < size; i++) {
/* 323 */       ModuleWiring wiring = (ModuleWiring)((BundleRevision)revs.get(i)).getWiring();
/* 324 */       if (wiring != null) {
/* 325 */         dtos.add((new DTOBuilder()).getBundleWiringDTO(wiring));
/*     */       }
/*     */     } 
/* 328 */     return dtos.<BundleWiringDTO>toArray(new BundleWiringDTO[dtos.size()]);
/*     */   }
/*     */   
/*     */   public static FrameworkDTO newFrameworkDTO(BundleContext systemBundleContext, Map<String, String> configuration) {
/* 332 */     FrameworkDTO dto = new FrameworkDTO();
/* 333 */     dto.properties = asProperties(configuration);
/* 334 */     if (systemBundleContext == null) {
/* 335 */       dto.bundles = newList(0);
/* 336 */       dto.services = newList(0);
/* 337 */       return dto;
/*     */     } 
/* 339 */     Bundle[] bundles = systemBundleContext.getBundles();
/* 340 */     int size = (bundles == null) ? 0 : bundles.length;
/* 341 */     List<BundleDTO> bundleDTOs = newList(size);
/* 342 */     for (int i = 0; i < size; i++) {
/* 343 */       bundleDTOs.add(newBundleDTO(bundles[i]));
/*     */     }
/* 345 */     dto.bundles = bundleDTOs;
/*     */     try {
/* 347 */       ServiceReference[] references = systemBundleContext.getAllServiceReferences(null, null);
/* 348 */       size = (references == null) ? 0 : references.length;
/* 349 */       List<ServiceReferenceDTO> refDTOs = newList(size);
/* 350 */       for (int j = 0; j < size; j++) {
/* 351 */         ServiceReferenceDTO serviceRefDTO = newServiceReferenceDTO(references[j]);
/* 352 */         if (serviceRefDTO != null) {
/* 353 */           refDTOs.add(serviceRefDTO);
/*     */         }
/*     */       } 
/* 356 */       dto.services = refDTOs;
/* 357 */     } catch (InvalidSyntaxException invalidSyntaxException) {
/* 358 */       dto.services = newList(0);
/*     */     } 
/* 360 */     return dto;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<String, Object> asProperties(Map<String, ?> m) {
/* 365 */     return (Map)m;
/*     */   }
/*     */   
/*     */   public static ServiceReferenceDTO newServiceReferenceDTO(ServiceReference<?> ref) {
/* 369 */     if (ref == null) {
/* 370 */       return null;
/*     */     }
/*     */     
/* 373 */     ServiceReferenceDTO dto = new ServiceReferenceDTO();
/* 374 */     String[] keys = ref.getPropertyKeys();
/* 375 */     Map<String, Object> properties = newMap(keys.length); byte b; int j; String[] arrayOfString1;
/* 376 */     for (j = (arrayOfString1 = keys).length, b = 0; b < j; ) { String k = arrayOfString1[b];
/* 377 */       Object v = ref.getProperty(k);
/* 378 */       if ("service.id".equals(k)) {
/* 379 */         dto.id = ((Long)v).longValue();
/*     */       }
/* 381 */       if ("service.bundleid".equals(k)) {
/* 382 */         dto.bundle = ((Long)v).longValue();
/*     */       }
/* 384 */       properties.put(k, mapValue(v)); b++; }
/*     */     
/* 386 */     dto.properties = properties;
/* 387 */     Bundle[] using = ref.getUsingBundles();
/* 388 */     int length = (using == null) ? 0 : using.length;
/* 389 */     long[] usingBundles = new long[length];
/* 390 */     for (int i = 0; i < length; i++) {
/* 391 */       usingBundles[i] = using[i].getBundleId();
/*     */     }
/* 393 */     dto.usingBundles = usingBundles;
/* 394 */     return dto;
/*     */   }
/*     */   
/*     */   public static FrameworkStartLevelDTO newFrameworkStartLevelDTO(FrameworkStartLevel fsl) {
/* 398 */     if (fsl == null) {
/* 399 */       return null;
/*     */     }
/* 401 */     FrameworkStartLevelDTO dto = new FrameworkStartLevelDTO();
/* 402 */     dto.initialBundleStartLevel = fsl.getInitialBundleStartLevel();
/* 403 */     dto.startLevel = fsl.getStartLevel();
/* 404 */     return dto;
/*     */   }
/*     */   
/*     */   public static ServiceReferenceDTO[] newArrayServiceReferenceDTO(ServiceReference[] references) {
/* 408 */     if (references == null) {
/* 409 */       return null;
/*     */     }
/* 411 */     int length = references.length;
/* 412 */     List<ServiceReferenceDTO> refDTOs = new ArrayList<>(length);
/* 413 */     for (int i = 0; i < length; i++) {
/* 414 */       ServiceReferenceDTO dto = newServiceReferenceDTO(references[i]);
/* 415 */       if (dto != null) {
/* 416 */         refDTOs.add(dto);
/*     */       }
/*     */     } 
/* 419 */     return refDTOs.<ServiceReferenceDTO>toArray(new ServiceReferenceDTO[refDTOs.size()]);
/*     */   }
/*     */   
/*     */   private static Object mapValue(Object v) {
/* 423 */     if (v == null || v instanceof Number || v instanceof Boolean || v instanceof Character || v instanceof String || v instanceof DTO) {
/* 424 */       return v;
/*     */     }
/* 426 */     if (v instanceof Map) {
/* 427 */       Map<?, ?> m = (Map<?, ?>)v;
/* 428 */       Map<Object, Object> map = newMap(m.size());
/* 429 */       for (Map.Entry<?, ?> e : m.entrySet()) {
/* 430 */         map.put(mapValue(e.getKey()), mapValue(e.getValue()));
/*     */       }
/* 432 */       return map;
/*     */     } 
/* 434 */     if (v instanceof List) {
/* 435 */       List<?> c = (List)v;
/* 436 */       List<Object> list = newList(c.size());
/* 437 */       for (Object o : c) {
/* 438 */         list.add(mapValue(o));
/*     */       }
/* 440 */       return list;
/*     */     } 
/* 442 */     if (v instanceof Set) {
/* 443 */       Set<?> c = (Set)v;
/* 444 */       Set<Object> set = newSet(c.size());
/* 445 */       for (Object o : c) {
/* 446 */         set.add(mapValue(o));
/*     */       }
/* 448 */       return set;
/*     */     } 
/* 450 */     if (v.getClass().isArray()) {
/* 451 */       int length = Array.getLength(v);
/* 452 */       Class<?> componentType = mapComponentType(v.getClass().getComponentType());
/* 453 */       Object array = Array.newInstance(componentType, length);
/* 454 */       for (int i = 0; i < length; i++) {
/* 455 */         Array.set(array, i, mapValue(Array.get(v, i)));
/*     */       }
/* 457 */       return array;
/*     */     } 
/* 459 */     return String.valueOf(v);
/*     */   }
/*     */   
/*     */   private static Class<?> mapComponentType(Class<?> componentType) {
/* 463 */     if (componentType.isPrimitive() || componentType.isArray() || Object.class.equals(componentType) || Number.class.isAssignableFrom(componentType) || Boolean.class.isAssignableFrom(componentType) || Character.class.isAssignableFrom(componentType) || String.class.isAssignableFrom(componentType) || DTO.class.isAssignableFrom(componentType)) {
/* 464 */       return componentType;
/*     */     }
/* 466 */     if (Map.class.isAssignableFrom(componentType)) {
/* 467 */       return Map.class;
/*     */     }
/* 469 */     if (List.class.isAssignableFrom(componentType)) {
/* 470 */       return List.class;
/*     */     }
/* 472 */     if (Set.class.isAssignableFrom(componentType)) {
/* 473 */       return Set.class;
/*     */     }
/* 475 */     return String.class;
/*     */   }
/*     */   
/*     */   private static <E> List<E> newList(int size) {
/* 479 */     return new ArrayList<>(size);
/*     */   }
/*     */   
/*     */   private static <E> Set<E> newSet(int size) {
/* 483 */     return new HashSet<>(size);
/*     */   }
/*     */   
/*     */   private static <K, V> Map<K, V> newMap(int size) {
/* 487 */     return new HashMap<>(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, String> newDirectivesMapDTO(Map<String, String> map) {
/* 494 */     Map<String, String> dto = new HashMap<>(map);
/* 495 */     return dto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Object> newAttributesMapDTO(Map<String, Object> map) {
/* 504 */     Map<String, Object> dto = new HashMap<>(map);
/*     */     
/* 506 */     for (Map.Entry<String, Object> entry : dto.entrySet()) {
/* 507 */       Object value = entry.getValue();
/* 508 */       if (value instanceof org.osgi.framework.Version) {
/* 509 */         entry.setValue(String.valueOf(value));
/*     */         continue;
/*     */       } 
/* 512 */       if (value instanceof List) {
/* 513 */         List<Object> newList = new ArrayList((List)value);
/* 514 */         for (ListIterator<Object> iter = newList.listIterator(); iter.hasNext(); ) {
/* 515 */           Object element = iter.next();
/* 516 */           if (element instanceof org.osgi.framework.Version) {
/* 517 */             iter.set(String.valueOf(element));
/*     */           }
/*     */         } 
/* 520 */         entry.setValue(newList);
/*     */       } 
/*     */     } 
/*     */     
/* 524 */     return dto;
/*     */   }
/*     */   
/*     */   private static int identifier(Object o) {
/* 528 */     return System.identityHashCode(o);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\DTOBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */