/*     */ package org.eclipse.osgi.internal.location;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.log.EquinoxLogServices;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicLocation
/*     */   implements Location
/*     */ {
/*  37 */   private static String DEFAULT_LOCK_FILENAME = ".metadata/.lock";
/*     */   
/*     */   private final boolean isReadOnly;
/*     */   
/*     */   private final URL defaultValue;
/*     */   
/*     */   private final String property;
/*     */   
/*     */   private final String dataAreaPrefix;
/*     */   
/*     */   private final EquinoxConfiguration.ConfigValues configValues;
/*     */   private final AtomicBoolean debug;
/*     */   private final EquinoxContainer container;
/*     */   private URL location;
/*     */   private Location parent;
/*     */   private File lockFile;
/*     */   private Locker locker;
/*     */   private ServiceRegistration<?> serviceRegistration;
/*     */   
/*     */   public BasicLocation(String property, URL defaultValue, boolean isReadOnly, String dataAreaPrefix, EquinoxConfiguration.ConfigValues configValues, EquinoxContainer container, AtomicBoolean debug) {
/*  57 */     this.property = property;
/*  58 */     this.defaultValue = defaultValue;
/*  59 */     this.isReadOnly = isReadOnly;
/*     */     
/*  61 */     String tempDataAreaPrefix = (dataAreaPrefix == null) ? "" : dataAreaPrefix;
/*  62 */     tempDataAreaPrefix = tempDataAreaPrefix.replace('\\', '/');
/*  63 */     if (tempDataAreaPrefix.length() > 0 && tempDataAreaPrefix.charAt(tempDataAreaPrefix.length() - 1) != '/') {
/*  64 */       tempDataAreaPrefix = String.valueOf(tempDataAreaPrefix) + '/';
/*     */     }
/*  66 */     this.dataAreaPrefix = tempDataAreaPrefix;
/*  67 */     this.configValues = configValues;
/*  68 */     this.container = container;
/*  69 */     this.debug = debug;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean allowsDefault() {
/*  74 */     return (this.defaultValue != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getDefault() {
/*  79 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Location getParentLocation() {
/*  84 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized URL getURL() {
/*  89 */     if (this.location == null && this.defaultValue != null) {
/*  90 */       if (this.debug.get()) {
/*  91 */         EquinoxLogServices logServices = this.container.getLogServices();
/*     */         
/*  93 */         if (logServices != null) {
/*  94 */           logServices.log("org.eclipse.osgi", 1, "Called Location.getURL() when it has not been set for: \"" + this.property + "\"", new RuntimeException("Call stack for Location.getURL()"));
/*     */         }
/*     */       } 
/*  97 */       setURL(this.defaultValue, false);
/*     */     } 
/*  99 */     return this.location;
/*     */   }
/*     */   
/*     */   private synchronized URL getLocation() {
/* 103 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isSet() {
/* 108 */     return (this.location != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 113 */     return this.isReadOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setURL(URL value, boolean lock) throws IllegalStateException {
/*     */     try {
/* 122 */       return set(value, lock);
/* 123 */     } catch (IOException iOException) {
/* 124 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean set(URL value, boolean lock) throws IllegalStateException, IOException {
/* 130 */     return set(value, lock, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean set(URL value, boolean lock, String lockFilePath) throws IllegalStateException, IOException {
/* 135 */     synchronized (this) {
/* 136 */       if (this.location != null)
/* 137 */         throw new IllegalStateException(Msg.ECLIPSE_CANNOT_CHANGE_LOCATION); 
/* 138 */       File file = null;
/* 139 */       if (value.getProtocol().equalsIgnoreCase("file")) {
/*     */         try {
/* 141 */           File f = LocationHelper.decodePath(new File(value.getPath()));
/* 142 */           String basePath = f.getCanonicalPath();
/* 143 */           value = LocationHelper.buildURL("file:" + basePath, true);
/* 144 */         } catch (IOException iOException) {}
/*     */ 
/*     */         
/* 147 */         if (lockFilePath != null && lockFilePath.length() > 0) {
/* 148 */           File givenLockFile = new File(lockFilePath);
/* 149 */           if (givenLockFile.isAbsolute()) {
/* 150 */             file = givenLockFile;
/*     */           } else {
/* 152 */             file = new File(value.getPath(), lockFilePath);
/*     */           } 
/*     */         } else {
/* 155 */           file = new File(value.getPath(), DEFAULT_LOCK_FILENAME);
/*     */         } 
/*     */       } 
/* 158 */       lock = (lock && !this.isReadOnly);
/* 159 */       if (lock && 
/* 160 */         !lock(file, value)) {
/* 161 */         return false;
/*     */       }
/* 163 */       this.lockFile = file;
/* 164 */       this.location = value;
/* 165 */       if (this.property != null) {
/* 166 */         this.configValues.setConfiguration(this.property, this.location.toExternalForm());
/*     */       }
/*     */     } 
/* 169 */     updateUrl(this.serviceRegistration);
/* 170 */     return true;
/*     */   }
/*     */   
/*     */   private void updateUrl(ServiceRegistration<?> registration) {
/* 174 */     if (registration != null) {
/* 175 */       Dictionary<String, Object> properties = registration.getReference().getProperties();
/* 176 */       properties.put("url", getLocation().toExternalForm());
/*     */       try {
/* 178 */         registration.setProperties(properties);
/* 179 */       } catch (IllegalStateException illegalStateException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setParent(Location value) {
/* 186 */     this.parent = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean lock() throws IOException {
/* 191 */     if (!isSet())
/* 192 */       throw new IOException(Msg.location_notSet); 
/* 193 */     return lock(this.lockFile, this.location);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isLocked() throws IOException {
/* 198 */     if (!isSet())
/* 199 */       return false; 
/* 200 */     return isLocked(this.lockFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lock(File lock, URL locationValue) throws IOException {
/* 207 */     if (this.isReadOnly)
/* 208 */       throw new IOException(NLS.bind(Msg.location_folderReadOnly, lock)); 
/* 209 */     if (lock == null) {
/* 210 */       if (locationValue != null && !"file".equalsIgnoreCase(locationValue.getProtocol()))
/* 211 */         throw new IOException(NLS.bind(Msg.location_notFileProtocol, locationValue)); 
/* 212 */       throw new IllegalStateException(Msg.location_noLockFile);
/*     */     } 
/* 214 */     if (isLocked())
/* 215 */       return false; 
/* 216 */     File parentFile = new File(lock.getParent());
/* 217 */     if (!parentFile.isDirectory()) {
/* 218 */       parentFile.mkdirs();
/* 219 */       if (!parentFile.isDirectory())
/* 220 */         throw new IOException(NLS.bind(Msg.location_folderReadOnly, parentFile)); 
/*     */     } 
/* 222 */     setLocker(lock);
/* 223 */     if (this.locker == null)
/* 224 */       return true; 
/* 225 */     boolean locked = false;
/*     */     try {
/* 227 */       locked = this.locker.lock();
/* 228 */       return locked;
/*     */     } finally {
/* 230 */       if (!locked) {
/* 231 */         this.locker = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLocked(File lock) throws IOException {
/* 239 */     if (lock == null || this.isReadOnly)
/* 240 */       return true; 
/* 241 */     if (!lock.exists())
/* 242 */       return false; 
/* 243 */     setLocker(lock);
/* 244 */     return this.locker.isLocked();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLocker(File lock) {
/* 251 */     if (this.locker != null)
/*     */       return; 
/* 253 */     String lockMode = this.configValues.getConfiguration("osgi.locking", "java.nio");
/* 254 */     this.locker = LocationHelper.createLocker(lock, lockMode, this.debug.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void release() {
/* 259 */     if (this.locker != null) {
/* 260 */       this.locker.release();
/*     */     }
/*     */   }
/*     */   
/*     */   public Location createLocation(Location parentLocation, URL defaultLocation, boolean readonly) {
/* 265 */     BasicLocation result = new BasicLocation(null, defaultLocation, readonly, this.dataAreaPrefix, this.configValues, this.container, this.debug);
/* 266 */     result.setParent(parentLocation);
/* 267 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getDataArea(String filename) throws IOException {
/* 272 */     URL base = getURL();
/* 273 */     if (base == null)
/* 274 */       throw new IOException(Msg.location_notSet); 
/* 275 */     String prefix = base.toExternalForm();
/* 276 */     if (prefix.length() > 0 && prefix.charAt(prefix.length() - 1) != '/')
/* 277 */       prefix = String.valueOf(prefix) + '/'; 
/* 278 */     filename = filename.replace('\\', '/');
/* 279 */     if (filename.length() > 0 && filename.charAt(0) == '/')
/* 280 */       filename = filename.substring(1); 
/* 281 */     String spec = String.valueOf(prefix) + this.dataAreaPrefix + filename;
/* 282 */     boolean trailingSlash = (spec.length() > 0 && spec.charAt(spec.length() - 1) == '/');
/* 283 */     return LocationHelper.buildURL(spec, trailingSlash);
/*     */   }
/*     */   
/*     */   public void register(BundleContext bundleContext) {
/* 287 */     Dictionary<String, Object> locationProperties = new Hashtable<>(3);
/* 288 */     locationProperties.put("type", this.property);
/* 289 */     URL url = getLocation();
/* 290 */     URL defaultUrl = getDefault();
/* 291 */     if (url != null) {
/* 292 */       locationProperties.put("url", url.toExternalForm());
/*     */     }
/* 294 */     if (defaultUrl != null) {
/* 295 */       locationProperties.put("defaultUrl", defaultUrl.toExternalForm());
/*     */     }
/* 297 */     ServiceRegistration<?> register = bundleContext.registerService(Location.class, this, locationProperties);
/* 298 */     synchronized (this) {
/* 299 */       this.serviceRegistration = register;
/*     */     } 
/*     */ 
/*     */     
/* 303 */     if (url != getLocation())
/* 304 */       updateUrl(register); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\BasicLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */