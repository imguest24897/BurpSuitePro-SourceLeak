/*     */ package org.eclipse.osgi.storagemanager;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ManagedOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   static final int ST_OPEN = 0;
/*     */   static final int ST_CLOSED = 1;
/*     */   private String target;
/*     */   private StorageManager manager;
/*     */   private File outputFile;
/*     */   private int state;
/*  36 */   private ManagedOutputStream[] streamSet = null;
/*     */   
/*     */   ManagedOutputStream(OutputStream out, StorageManager manager, String target, File outputFile) {
/*  39 */     super(out);
/*  40 */     this.manager = manager;
/*  41 */     this.target = target;
/*  42 */     this.outputFile = outputFile;
/*  43 */     this.state = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  56 */     this.manager.closeOutputStream(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort() {
/*  66 */     this.manager.abortOutputStream(this);
/*     */   }
/*     */   
/*     */   OutputStream getOutputStream() {
/*  70 */     return this.out;
/*     */   }
/*     */   
/*     */   String getTarget() {
/*  74 */     return this.target;
/*     */   }
/*     */   
/*     */   File getOutputFile() {
/*  78 */     return this.outputFile;
/*     */   }
/*     */   
/*     */   int getState() {
/*  82 */     return this.state;
/*     */   }
/*     */   
/*     */   void setState(int state) {
/*  86 */     this.state = state;
/*     */   }
/*     */   
/*     */   void setStreamSet(ManagedOutputStream[] set) {
/*  90 */     this.streamSet = set;
/*     */   }
/*     */   
/*     */   ManagedOutputStream[] getStreamSet() {
/*  94 */     return this.streamSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] bytes, int off, int len) throws IOException {
/* 105 */     this.out.write(bytes, off, len);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storagemanager\ManagedOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */