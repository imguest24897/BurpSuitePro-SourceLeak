package org.eclipse.osgi.service.localization;

import java.util.ResourceBundle;
import org.osgi.framework.Bundle;

public interface BundleLocalization {
  ResourceBundle getLocalization(Bundle paramBundle, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\localization\BundleLocalization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */