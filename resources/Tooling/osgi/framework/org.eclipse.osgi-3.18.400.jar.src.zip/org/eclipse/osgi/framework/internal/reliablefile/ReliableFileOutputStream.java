/*     */ package org.eclipse.osgi.framework.internal.reliablefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReliableFileOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private ReliableFile reliable;
/*     */   private Checksum crc;
/*     */   private boolean outputOpen = false;
/*     */   
/*     */   public ReliableFileOutputStream(File file) throws IOException {
/*  50 */     this(ReliableFile.getReliableFile(file), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReliableFileOutputStream(File file, boolean append) throws IOException {
/*  61 */     this(ReliableFile.getReliableFile(file), append);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReliableFileOutputStream(String name) throws IOException {
/*  75 */     this(ReliableFile.getReliableFile(name), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReliableFileOutputStream(String name, boolean append) throws IOException {
/*  88 */     this(ReliableFile.getReliableFile(name), append);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReliableFileOutputStream(ReliableFile reliable, boolean append) throws IOException {
/*  99 */     super(reliable.getOutputStream(append, 0));
/*     */     
/* 101 */     this.reliable = reliable;
/* 102 */     this.outputOpen = true;
/* 103 */     if (append) {
/* 104 */       this.crc = reliable.getFileChecksum();
/*     */     } else {
/* 106 */       this.crc = reliable.getChecksumCalculator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 119 */     closeIntermediateFile();
/* 120 */     this.reliable.closeOutputFile(this.crc);
/*     */ 
/*     */ 
/*     */     
/* 124 */     this.reliable = null;
/*     */   }
/*     */   
/*     */   public File closeIntermediateFile() throws IOException {
/* 128 */     if (this.reliable == null)
/* 129 */       throw new IOException("ReliableFile stream not open"); 
/* 130 */     if (this.outputOpen) {
/*     */       
/* 132 */       this.reliable.writeChecksumSignature(this.out, this.crc);
/* 133 */       this.out.flush();
/*     */       try {
/* 135 */         ((FileOutputStream)this.out).getFD().sync();
/* 136 */       } catch (IOException e) {
/*     */ 
/*     */         
/* 139 */         e.printStackTrace();
/*     */       } 
/* 141 */       this.out.close();
/* 142 */       this.outputOpen = false;
/*     */     } 
/* 144 */     return this.reliable.getOutputFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 153 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 162 */     this.out.write(b, off, len);
/* 163 */     this.crc.update(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 172 */     this.out.write(b);
/* 173 */     this.crc.update((byte)b);
/*     */   }
/*     */   
/*     */   public void abort() {
/* 177 */     if (this.reliable == null)
/*     */       return; 
/* 179 */     if (this.outputOpen) {
/*     */       try {
/* 181 */         this.out.close();
/* 182 */       } catch (IOException iOException) {}
/*     */       
/* 184 */       this.outputOpen = false;
/*     */     } 
/* 186 */     this.reliable.abortOutputFile();
/* 187 */     this.reliable = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\internal\reliablefile\ReliableFileOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */