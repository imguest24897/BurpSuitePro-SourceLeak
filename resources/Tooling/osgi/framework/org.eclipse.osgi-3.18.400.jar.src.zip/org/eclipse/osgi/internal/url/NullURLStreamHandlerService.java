/*    */ package org.eclipse.osgi.internal.url;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.osgi.service.url.URLStreamHandlerService;
/*    */ import org.osgi.service.url.URLStreamHandlerSetter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullURLStreamHandlerService
/*    */   implements URLStreamHandlerService
/*    */ {
/*    */   public URLConnection openConnection(URL u) throws IOException {
/* 35 */     throw new MalformedURLException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(URL url1, URL url2) {
/* 40 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDefaultPort() {
/* 45 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public InetAddress getHostAddress(URL url) {
/* 50 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode(URL url) {
/* 55 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hostsEqual(URL url1, URL url2) {
/* 60 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean sameFile(URL url1, URL url2) {
/* 65 */     throw new IllegalStateException();
/*    */   }
/*    */   
/*    */   public void setURL(URL u, String protocol, String host, int port, String authority, String userInfo, String file, String query, String ref) {
/* 69 */     throw new IllegalStateException();
/*    */   }
/*    */   
/*    */   public void setURL(URL u, String protocol, String host, int port, String file, String ref) {
/* 73 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toExternalForm(URL url) {
/* 78 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void parseURL(URLStreamHandlerSetter realHandler, URL u, String spec, int start, int limit) {
/* 83 */     throw new IllegalStateException();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\NullURLStreamHandlerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */