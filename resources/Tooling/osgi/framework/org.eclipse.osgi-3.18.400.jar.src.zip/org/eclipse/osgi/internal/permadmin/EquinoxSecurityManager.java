/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.osgi.service.condpermadmin.Condition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxSecurityManager
/*     */   extends SecurityManager
/*     */ {
/*     */   private final ThreadLocal<CheckContext> localCheckContext;
/*     */   
/*     */   public EquinoxSecurityManager() {
/*  69 */     this.localCheckContext = new ThreadLocal<>();
/*     */   } static { Class<?> c = CheckPermissionAction.class;
/*     */     c = CheckContext.class;
/*  72 */     c.getName(); } boolean addConditionsForDomain(SecurityRow.Decision[] results) { CheckContext cc = this.localCheckContext.get();
/*  73 */     if (cc == null)
/*     */     {
/*     */       
/*  76 */       return false;
/*     */     }
/*  78 */     List<SecurityRow.Decision[]> condSets = cc.depthCondSets.get(cc.getDepth());
/*  79 */     if (condSets == null) {
/*  80 */       condSets = (List)new ArrayList<>(1);
/*  81 */       cc.depthCondSets.set(cc.getDepth(), condSets);
/*     */     } 
/*  83 */     condSets.add(results);
/*  84 */     return true; }
/*     */   static class CheckContext {
/*     */     List<List<SecurityRow.Decision[]>> depthCondSets = new ArrayList<>(2);
/*     */     List<AccessControlContext> accs = new ArrayList<>(2); List<Class<?>> CondClassSet; public int getDepth() { return this.depthCondSets.size() - 1; } } static class CheckPermissionAction implements PrivilegedAction<Void> {
/*  88 */     Permission perm; Object context; EquinoxSecurityManager fsm; CheckPermissionAction(EquinoxSecurityManager fsm, Permission perm, Object context) { this.fsm = fsm; this.perm = perm; this.context = context; } public Void run() { this.fsm.internalCheckPermission(this.perm, this.context); return null; } } boolean inCheckPermission() { return (this.localCheckContext.get() != null); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkPermission(Permission perm, Object context) {
/*  93 */     AccessController.doPrivileged(new CheckPermissionAction(this, perm, context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessControlContext getContextToBeChecked() {
/* 106 */     CheckContext cc = this.localCheckContext.get();
/* 107 */     if (cc != null && cc.accs != null && !cc.accs.isEmpty())
/* 108 */       return cc.accs.get(cc.accs.size() - 1); 
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   void internalCheckPermission(Permission perm, Object context) {
/* 113 */     AccessControlContext acc = (AccessControlContext)context;
/* 114 */     CheckContext cc = this.localCheckContext.get();
/* 115 */     if (cc == null) {
/* 116 */       cc = new CheckContext();
/* 117 */       this.localCheckContext.set(cc);
/*     */     } 
/* 119 */     cc.depthCondSets.add(null);
/* 120 */     cc.accs.add(acc);
/*     */     try {
/* 122 */       acc.checkPermission(perm);
/*     */       
/* 124 */       List<SecurityRow.Decision[]> conditionSets = cc.depthCondSets.get(cc.getDepth());
/* 125 */       if (conditionSets == null) {
/*     */         return;
/*     */       }
/* 128 */       Map<Class<? extends Condition>, Dictionary<Object, Object>> conditionDictionaries = new HashMap<>();
/* 129 */       for (SecurityRow.Decision[] domainDecisions : conditionSets) {
/* 130 */         boolean grant = false; byte b; int i; SecurityRow.Decision[] arrayOfDecision1;
/* 131 */         for (i = (arrayOfDecision1 = domainDecisions).length, b = 0; b < i; ) { SecurityRow.Decision domainDecision = arrayOfDecision1[b];
/* 132 */           if (domainDecision == null) {
/*     */             break;
/*     */           }
/* 135 */           if ((domainDecision.decision & 0x4) == 0) {
/*     */ 
/*     */             
/* 138 */             if ((domainDecision.decision & 0x8) == 0) {
/*     */               
/* 140 */               if ((domainDecision.decision & 0x1) != 0) {
/* 141 */                 grant = true;
/*     */               }
/*     */               break;
/*     */             } 
/* 145 */             int decision = getPostponedDecision(domainDecision, conditionDictionaries, cc);
/* 146 */             if ((decision & 0x4) == 0) {
/*     */               
/* 148 */               if ((decision & 0x1) != 0)
/* 149 */                 grant = true;  break;
/*     */             } 
/*     */           }  b++; }
/* 152 */          if (!grant)
/*     */         {
/* 154 */           throw new SecurityException("Conditions not satisfied");
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 159 */       cc.depthCondSets.remove(cc.getDepth());
/* 160 */       cc.accs.remove(cc.accs.size() - 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getPostponedDecision(SecurityRow.Decision decision, Map<Class<? extends Condition>, Dictionary<Object, Object>> conditionDictionaries, CheckContext cc) {
/* 165 */     Condition[] postponed = decision.postponed; byte b; int i; Condition[] arrayOfCondition1;
/* 166 */     for (i = (arrayOfCondition1 = postponed).length, b = 0; b < i; ) { Condition postponedCond = arrayOfCondition1[b];
/* 167 */       Dictionary<Object, Object> condContext = conditionDictionaries.get(postponedCond.getClass());
/* 168 */       if (condContext == null) {
/* 169 */         condContext = new Hashtable<>();
/* 170 */         conditionDictionaries.put(postponedCond.getClass(), condContext);
/*     */       } 
/*     */       
/* 173 */       if (cc.CondClassSet == null)
/* 174 */         cc.CondClassSet = new ArrayList<>(2); 
/* 175 */       if (cc.CondClassSet.contains(postponedCond.getClass())) {
/* 176 */         return 4;
/*     */       }
/* 178 */       cc.CondClassSet.add(postponedCond.getClass());
/*     */       
/*     */       try {
/* 181 */         boolean mutable = postponedCond.isMutable();
/* 182 */         boolean isSatisfied = postponedCond.isSatisfied(new Condition[] { postponedCond }, condContext);
/* 183 */         decision.handleImmutable(postponedCond, isSatisfied, mutable);
/* 184 */         if (!isSatisfied)
/* 185 */           return 4; 
/*     */       } finally {
/* 187 */         cc.CondClassSet.remove(postponedCond.getClass());
/*     */       } 
/*     */       b++; }
/*     */     
/* 191 */     return decision.decision;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkPermission(Permission perm) {
/* 196 */     checkPermission(perm, getSecurityContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSecurityContext() {
/* 201 */     return AccessController.getContext();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\EquinoxSecurityManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */