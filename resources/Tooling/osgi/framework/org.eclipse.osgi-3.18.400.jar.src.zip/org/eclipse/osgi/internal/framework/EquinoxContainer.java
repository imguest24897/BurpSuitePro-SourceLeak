/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.internal.connect.ConnectBundleFile;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.location.EquinoxLocations;
/*     */ import org.eclipse.osgi.internal.log.EquinoxLogServices;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*     */ import org.eclipse.osgi.signedcontent.SignedContentFactory;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.Storage;
/*     */ import org.eclipse.osgi.storage.bundlefile.MRUBundleFileList;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.connect.ConnectContent;
/*     */ import org.osgi.framework.connect.ConnectModule;
/*     */ import org.osgi.framework.connect.ModuleConnector;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxContainer
/*     */   implements ThreadFactory, Runnable
/*     */ {
/*     */   public static final String NAME = "org.eclipse.osgi";
/*  65 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */   
/*     */   private final ConnectModules connectModules;
/*     */   
/*     */   private final EquinoxConfiguration equinoxConfig;
/*     */   private final EquinoxLogServices logServices;
/*     */   private final Storage storage;
/*     */   private final Set<String> bootDelegation;
/*     */   private final String[] bootDelegationStems;
/*     */   private final boolean bootDelegateAll;
/*     */   private final boolean isProcessClassRecursionSupportedByAll;
/*     */   private final EquinoxEventPublisher eventPublisher;
/*  77 */   private final Object monitor = new Object();
/*     */   
/*     */   private final ClassLoader bootLoader;
/*     */   
/*     */   private ServiceRegistry serviceRegistry;
/*     */   
/*     */   private ContextFinder contextFinder;
/*     */   private ServiceTracker<SignedContentFactory, SignedContentFactory> signedContentFactory;
/*     */   private ScheduledExecutorService executor;
/*     */   private StorageSaver storageSaver;
/*     */   
/*     */   public EquinoxContainer(Map<String, ?> configuration, ModuleConnector moduleConnector) {
/*  89 */     ClassLoader platformClassLoader = null;
/*     */     try {
/*  91 */       Method getPlatformClassLoader = ClassLoader.class.getMethod("getPlatformClassLoader", new Class[0]);
/*  92 */       platformClassLoader = (ClassLoader)getPlatformClassLoader.invoke(null, new Object[0]);
/*  93 */     } catch (Throwable throwable) {
/*     */       
/*  95 */       platformClassLoader = new ClassLoader(Object.class.getClassLoader()) {  }
/*     */         ;
/*     */     } 
/*  98 */     this.bootLoader = platformClassLoader;
/*  99 */     this.equinoxConfig = new EquinoxConfiguration(configuration, new HookRegistry(this));
/* 100 */     this.logServices = new EquinoxLogServices(this.equinoxConfig);
/* 101 */     this.equinoxConfig.logMessages(this.logServices);
/* 102 */     this.connectModules = new ConnectModules(moduleConnector);
/*     */     
/* 104 */     initConnectFramework(moduleConnector, this.equinoxConfig);
/*     */     
/* 106 */     this.equinoxConfig.getHookRegistry().initialize();
/*     */     try {
/* 108 */       this.storage = Storage.createStorage(this);
/* 109 */     } catch (Exception e) {
/* 110 */       throw new IllegalStateException("Error initializing storage for Equinox container.", e);
/*     */     } 
/*     */     
/* 113 */     this.eventPublisher = new EquinoxEventPublisher(this);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     String bootDelegationProp = this.equinoxConfig.getConfiguration("org.osgi.framework.bootdelegation");
/* 119 */     String[] bootPackages = ManifestElement.getArrayFromList(bootDelegationProp, ",");
/* 120 */     HashSet<String> exactMatch = new HashSet<>(bootPackages.length);
/* 121 */     List<String> stemMatch = new ArrayList<>(bootPackages.length);
/* 122 */     boolean delegateAllValue = false; byte b; int i; String[] arrayOfString1;
/* 123 */     for (i = (arrayOfString1 = bootPackages).length, b = 0; b < i; ) { String bootPackage = arrayOfString1[b];
/* 124 */       if (bootPackage.equals("*")) {
/* 125 */         delegateAllValue = true;
/* 126 */         exactMatch.clear();
/* 127 */         stemMatch.clear(); break;
/*     */       } 
/* 129 */       if (bootPackage.endsWith("*")) {
/* 130 */         if (bootPackage.length() > 2 && bootPackage.endsWith(".*")) {
/* 131 */           stemMatch.add(bootPackage.substring(0, bootPackage.length() - 1));
/*     */         }
/*     */       } else {
/* 134 */         exactMatch.add(bootPackage);
/*     */       }  b++; }
/*     */     
/* 137 */     this.bootDelegateAll = delegateAllValue;
/* 138 */     this.bootDelegation = exactMatch;
/* 139 */     this.bootDelegationStems = stemMatch.isEmpty() ? null : stemMatch.<String>toArray(new String[stemMatch.size()]);
/*     */ 
/*     */     
/* 142 */     boolean supportRecursion = true;
/* 143 */     for (ClassLoaderHook hook : this.equinoxConfig.getHookRegistry().getClassLoaderHooks()) {
/* 144 */       supportRecursion &= hook.isProcessClassRecursionSupported();
/*     */     }
/* 146 */     this.isProcessClassRecursionSupportedByAll = supportRecursion;
/*     */   }
/*     */   
/*     */   private static void initConnectFramework(ModuleConnector moduleConnector, EquinoxConfiguration equinoxConfig) {
/* 150 */     if (moduleConnector == null) {
/*     */       return;
/*     */     }
/* 153 */     URL configUrl = equinoxConfig.getEquinoxLocations().getConfigurationLocation().getURL();
/* 154 */     File fwkStore = new File(configUrl.getPath());
/*     */     
/* 156 */     Map<String, String> config = (Map)equinoxConfig.getInitialConfig();
/* 157 */     moduleConnector.initialize(fwkStore, Collections.unmodifiableMap(config));
/*     */   }
/*     */   
/*     */   public Storage getStorage() {
/* 161 */     return this.storage;
/*     */   }
/*     */   
/*     */   public EquinoxConfiguration getConfiguration() {
/* 165 */     return this.equinoxConfig;
/*     */   }
/*     */   
/*     */   public EquinoxLocations getLocations() {
/* 169 */     return this.equinoxConfig.getEquinoxLocations();
/*     */   }
/*     */   
/*     */   public EquinoxLogServices getLogServices() {
/* 173 */     return this.logServices;
/*     */   }
/*     */   
/*     */   public Bundle getBundle(Class<?> clazz) {
/* 177 */     Bundle b = FrameworkUtil.getBundle(clazz);
/* 178 */     if (b != null) {
/* 179 */       return b;
/*     */     }
/*     */     
/* 182 */     return AccessController.<Bundle>doPrivileged(() -> (paramClass.getClassLoader() == EquinoxContainer.class.getClassLoader()) ? getStorage().getModuleContainer().getModule(0L).getBundle() : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SignedContentFactory getSignedContentFactory() {
/*     */     ServiceTracker<SignedContentFactory, SignedContentFactory> current;
/* 192 */     synchronized (this.monitor) {
/* 193 */       current = this.signedContentFactory;
/*     */     } 
/* 195 */     return (current == null) ? null : (SignedContentFactory)current.getService();
/*     */   }
/*     */   
/*     */   public boolean isBootDelegationPackage(String name) {
/* 199 */     if (this.bootDelegateAll)
/* 200 */       return true; 
/* 201 */     if (this.bootDelegation.contains(name))
/* 202 */       return true; 
/* 203 */     if (this.bootDelegationStems != null) {
/* 204 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.bootDelegationStems).length, b = 0; b < i; ) { String bootDelegationStem = arrayOfString[b];
/* 205 */         if (name.startsWith(bootDelegationStem))
/* 206 */           return true;  b++; }
/*     */     
/*     */     } 
/* 209 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isProcessClassRecursionSupportedByAll() {
/* 213 */     return this.isProcessClassRecursionSupportedByAll;
/*     */   }
/*     */   
/*     */   void init() {
/* 217 */     this.eventPublisher.init();
/* 218 */     synchronized (this.monitor) {
/* 219 */       this.serviceRegistry = new ServiceRegistry(this);
/* 220 */       initializeContextFinder();
/* 221 */       this.executor = Executors.newScheduledThreadPool(1, this);
/*     */       
/* 223 */       this.executor.execute(this);
/* 224 */       this.storageSaver = new StorageSaver(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   void close() {
/*     */     StorageSaver currentSaver;
/*     */     Storage currentStorage;
/*     */     ScheduledExecutorService currentExecutor;
/* 232 */     synchronized (this.monitor) {
/* 233 */       this.serviceRegistry = null;
/* 234 */       currentSaver = this.storageSaver;
/* 235 */       currentStorage = this.storage;
/* 236 */       currentExecutor = this.executor;
/*     */     } 
/*     */     
/* 239 */     currentSaver.close();
/* 240 */     currentStorage.close();
/*     */ 
/*     */     
/* 243 */     currentExecutor.shutdown();
/*     */   }
/*     */   
/*     */   private void initializeContextFinder() {
/* 247 */     Thread current = Thread.currentThread();
/*     */     try {
/* 249 */       ClassLoader parent = null;
/*     */       
/* 251 */       String type = this.equinoxConfig.getConfiguration("osgi.contextClassLoaderParent");
/* 252 */       if ("app".equals(type)) {
/* 253 */         parent = ClassLoader.getSystemClassLoader();
/* 254 */       } else if ("boot".equals(type)) {
/* 255 */         parent = this.bootLoader;
/* 256 */       } else if ("fwk".equals(type)) {
/* 257 */         parent = EquinoxContainer.class.getClassLoader();
/* 258 */       } else if ("ext".equals(type)) {
/* 259 */         ClassLoader appCL = ClassLoader.getSystemClassLoader();
/* 260 */         if (appCL != null)
/* 261 */           parent = appCL.getParent(); 
/*     */       } else {
/* 263 */         parent = current.getContextClassLoader();
/*     */       } 
/* 265 */       this.contextFinder = new ContextFinder(parent, this.bootLoader);
/* 266 */       current.setContextClassLoader(this.contextFinder);
/*     */       return;
/* 268 */     } catch (Exception e) {
/* 269 */       this.logServices.log("org.eclipse.osgi", 1, NLS.bind(Msg.CANNOT_SET_CONTEXTFINDER, null), e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public EquinoxEventPublisher getEventPublisher() {
/* 275 */     synchronized (this.monitor) {
/* 276 */       return this.eventPublisher;
/*     */     } 
/*     */   }
/*     */   
/*     */   ScheduledExecutorService getScheduledExecutor() {
/* 281 */     synchronized (this.monitor) {
/* 282 */       return this.executor;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ServiceRegistry getServiceRegistry() {
/* 287 */     synchronized (this.monitor) {
/* 288 */       return this.serviceRegistry;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ContextFinder getContextFinder() {
/* 293 */     synchronized (this.monitor) {
/* 294 */       return this.contextFinder;
/*     */     } 
/*     */   }
/*     */   
/*     */   public <K, V, E> ListenerQueue<K, V, E> newListenerQueue() {
/* 299 */     return this.eventPublisher.newListenerQueue();
/*     */   }
/*     */   
/*     */   void checkAdminPermission(Bundle bundle, String action) {
/* 303 */     if (bundle == null)
/*     */       return; 
/* 305 */     SecurityManager sm = System.getSecurityManager();
/* 306 */     if (sm != null) {
/* 307 */       sm.checkPermission((Permission)new AdminPermission(bundle, action));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleRuntimeError(Throwable t) {}
/*     */   
/*     */   void systemStart(BundleContext bc) {
/* 315 */     synchronized (this.monitor) {
/* 316 */       this.signedContentFactory = new ServiceTracker(bc, SignedContentFactory.class, null);
/*     */     } 
/* 318 */     this.signedContentFactory.open();
/*     */   }
/*     */   
/*     */   void systemStop(BundleContext bc) {
/*     */     ServiceTracker<SignedContentFactory, SignedContentFactory> current;
/* 323 */     synchronized (this.monitor) {
/* 324 */       current = this.signedContentFactory;
/*     */     } 
/* 326 */     if (current != null) {
/* 327 */       current.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 333 */     String UUID = (this.equinoxConfig == null) ? null : this.equinoxConfig.getConfiguration("org.osgi.framework.uuid");
/* 334 */     return "Equinox Container: " + UUID;
/*     */   }
/*     */   
/*     */   StorageSaver getStorageSaver() {
/* 338 */     synchronized (this.monitor) {
/* 339 */       return this.storageSaver;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Thread newThread(Runnable r) {
/* 345 */     String type = this.equinoxConfig.getConfiguration("osgi.framework.activeThreadType", "normal");
/* 346 */     Thread t = new Thread(r, "Active Thread: " + toString());
/* 347 */     if ("normal".equals(type)) {
/* 348 */       t.setDaemon(false);
/*     */     } else {
/* 350 */       t.setDaemon(true);
/*     */     } 
/* 352 */     t.setPriority(5);
/* 353 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {}
/*     */ 
/*     */   
/*     */   public ClassLoader getBootLoader() {
/* 362 */     return this.bootLoader;
/*     */   }
/*     */   
/*     */   public ConnectModules getConnectModules() {
/* 366 */     return this.connectModules;
/*     */   }
/*     */   
/*     */   public static class ConnectModules {
/*     */     final ModuleConnector moduleConnector;
/* 371 */     private final ConcurrentMap<String, ConnectModule> connectModules = new ConcurrentHashMap<>();
/* 372 */     private final WeakHashMap<ConnectContent, WeakReference<ConnectBundleFile>> contents = new WeakHashMap<>();
/*     */     
/*     */     public ConnectModules(ModuleConnector moduleConnector) {
/* 375 */       this.moduleConnector = moduleConnector;
/*     */     }
/*     */     
/*     */     public ConnectModule connect(String location) {
/* 379 */       if (this.moduleConnector == null) {
/* 380 */         return null;
/*     */       }
/* 382 */       ConnectModule result = this.connectModules.compute(location, (k, v) -> {
/*     */             try {
/*     */               return this.moduleConnector.connect(param1String1).orElse(null);
/* 385 */             } catch (BundleException e) {
/*     */               throw new IllegalStateException(e);
/*     */             } 
/*     */           });
/* 389 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConnectBundleFile getConnectBundleFile(ConnectModule module, File basefile, BundleInfo.Generation generation, MRUBundleFileList mruList, Debug debug) throws IOException {
/* 394 */       ConnectContent content = module.getContent();
/* 395 */       synchronized (this.contents) {
/* 396 */         WeakReference<ConnectBundleFile> ref = this.contents.get(content);
/* 397 */         if (ref != null) {
/* 398 */           ConnectBundleFile connectBundleFile = ref.get();
/* 399 */           if (connectBundleFile != null) {
/* 400 */             return connectBundleFile;
/*     */           }
/*     */         } 
/* 403 */         ConnectBundleFile bundleFile = new ConnectBundleFile(module, basefile, generation, mruList, debug);
/* 404 */         this.contents.put(content, new WeakReference<>(bundleFile));
/* 405 */         return bundleFile;
/*     */       } 
/*     */     }
/*     */     
/*     */     public ModuleConnector getModuleConnector() {
/* 410 */       return this.moduleConnector;
/*     */     }
/*     */     
/*     */     public ConnectModule getConnectModule(String location) {
/* 414 */       return this.connectModules.get(location);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static <E extends Throwable> void sneakyThrow(Throwable e) throws E {
/* 420 */     throw (E)e;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\EquinoxContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */