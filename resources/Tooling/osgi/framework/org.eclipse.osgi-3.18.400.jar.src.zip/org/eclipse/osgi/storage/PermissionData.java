/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissionData
/*     */ {
/*     */   private static final int PERMDATA_VERSION = 1;
/*  29 */   private final Map<String, String[]> locations = (Map)new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] defaultInfos;
/*     */ 
/*     */   
/*     */   private String[] condPermInfos;
/*     */ 
/*     */   
/*     */   private boolean dirty;
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLocations() {
/*  44 */     synchronized (this.locations) {
/*  45 */       String[] result = new String[this.locations.size()];
/*  46 */       int i = 0;
/*  47 */       for (Iterator<String> iLocs = this.locations.keySet().iterator(); iLocs.hasNext(); i++)
/*  48 */         result[i] = iLocs.next(); 
/*  49 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPermissionData(String location) {
/*  66 */     if (location == null)
/*  67 */       return this.defaultInfos; 
/*  68 */     synchronized (this.locations) {
/*  69 */       if (this.locations.size() == 0)
/*  70 */         return null; 
/*  71 */       return this.locations.get(location);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPermissionData(String location, String[] data) {
/*  86 */     if (location == null) {
/*  87 */       this.defaultInfos = data;
/*     */       return;
/*     */     } 
/*  90 */     synchronized (this.locations) {
/*  91 */       if (data == null) {
/*  92 */         this.locations.remove(location);
/*     */       } else {
/*  94 */         this.locations.put(location, data);
/*     */       } 
/*  96 */     }  setDirty(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveConditionalPermissionInfos(String[] infos) {
/* 104 */     this.condPermInfos = infos;
/* 105 */     setDirty(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getConditionalPermissionInfos() {
/* 114 */     return this.condPermInfos;
/*     */   }
/*     */   
/*     */   boolean isDirty() {
/* 118 */     return this.dirty;
/*     */   }
/*     */   
/*     */   private void setDirty(boolean dirty) {
/* 122 */     this.dirty = dirty;
/*     */   }
/*     */   
/*     */   void readPermissionData(DataInputStream in) throws IOException {
/* 126 */     int version = in.readInt();
/* 127 */     int dataSize = in.readInt();
/* 128 */     byte[] bytes = new byte[dataSize];
/* 129 */     in.readFully(bytes);
/* 130 */     if (1 == version) {
/* 131 */       DataInputStream temp = new DataInputStream(new ByteArrayInputStream(bytes));
/*     */       
/*     */       try {
/* 134 */         int numPerms = temp.readInt();
/* 135 */         if (numPerms > 0) {
/* 136 */           String[] perms = new String[numPerms];
/* 137 */           for (int i = 0; i < numPerms; i++)
/* 138 */             perms[i] = temp.readUTF(); 
/* 139 */           setPermissionData(null, perms);
/*     */         } 
/* 141 */         int numLocs = temp.readInt();
/* 142 */         if (numLocs > 0) {
/* 143 */           for (int i = 0; i < numLocs; i++) {
/* 144 */             String loc = temp.readUTF();
/* 145 */             numPerms = temp.readInt();
/* 146 */             String[] perms = new String[numPerms];
/* 147 */             for (int j = 0; j < numPerms; j++)
/* 148 */               perms[j] = temp.readUTF(); 
/* 149 */             setPermissionData(loc, perms);
/*     */           } 
/*     */         }
/* 152 */         int numCondPerms = temp.readInt();
/* 153 */         if (numCondPerms > 0) {
/* 154 */           String[] condPerms = new String[numCondPerms];
/* 155 */           for (int i = 0; i < numCondPerms; i++) {
/* 156 */             condPerms[i] = temp.readUTF();
/*     */           }
/* 158 */           saveConditionalPermissionInfos(condPerms);
/*     */         } 
/*     */       } finally {
/*     */         
/* 162 */         setDirty(false);
/* 163 */         temp.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void savePermissionData(DataOutputStream out) throws IOException {
/* 169 */     out.writeInt(1);
/*     */     
/* 171 */     ByteArrayOutputStream tempBytes = new ByteArrayOutputStream();
/* 172 */     DataOutputStream temp = new DataOutputStream(tempBytes);
/*     */     
/* 174 */     String[] defaultPerms = getPermissionData(null);
/* 175 */     temp.writeInt((defaultPerms == null) ? 0 : defaultPerms.length);
/* 176 */     if (defaultPerms != null) {
/* 177 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = defaultPerms).length, b = 0; b < i; ) { String defaultPerm = arrayOfString[b];
/* 178 */         temp.writeUTF(defaultPerm); b++; }
/*     */     
/* 180 */     }  String[] locs = getLocations();
/* 181 */     temp.writeInt((locs == null) ? 0 : locs.length);
/* 182 */     if (locs != null) {
/* 183 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = locs).length, b = 0; b < i; ) { String loc = arrayOfString[b];
/* 184 */         temp.writeUTF(loc);
/* 185 */         String[] perms = getPermissionData(loc);
/* 186 */         temp.writeInt((perms == null) ? 0 : perms.length);
/* 187 */         if (perms != null) {
/* 188 */           byte b1; int j; String[] arrayOfString1; for (j = (arrayOfString1 = perms).length, b1 = 0; b1 < j; ) { String perm = arrayOfString1[b1];
/* 189 */             temp.writeUTF(perm); b1++; }
/*     */         
/*     */         }  b++; }
/*     */     
/* 193 */     }  String[] condPerms = getConditionalPermissionInfos();
/* 194 */     temp.writeInt((condPerms == null) ? 0 : condPerms.length);
/* 195 */     if (condPerms != null) {
/* 196 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = condPerms).length, b = 0; b < i; ) { String condPerm = arrayOfString[b];
/* 197 */         temp.writeUTF(condPerm); b++; }
/*     */     
/* 199 */     }  temp.close();
/*     */     
/* 201 */     out.writeInt(tempBytes.size());
/* 202 */     out.write(tempBytes.toByteArray());
/* 203 */     setDirty(false);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\PermissionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */