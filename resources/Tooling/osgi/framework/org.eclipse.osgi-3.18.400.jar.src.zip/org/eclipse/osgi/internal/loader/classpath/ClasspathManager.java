/*     */ package org.eclipse.osgi.internal.loader.classpath;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.framework.util.ArrayMap;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.Storage;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathManager
/*     */ {
/*  64 */   private static final FragmentClasspath[] emptyFragments = new FragmentClasspath[0];
/*  65 */   private static final String[] DEFAULT_CLASSPATH = new String[] { "." };
/*     */   
/*     */   private final BundleInfo.Generation generation;
/*     */   
/*     */   private final ModuleClassLoader classloader;
/*     */   
/*     */   private final HookRegistry hookRegistry;
/*     */   
/*     */   private final Debug debug;
/*     */   
/*     */   private final ClasspathEntry[] entries;
/*     */   private volatile FragmentClasspath[] fragments;
/*  77 */   private ArrayMap<String, String> loadedLibraries = null;
/*     */   
/*  79 */   private ThreadLocal<DefineContext> currentDefineContext = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathManager(BundleInfo.Generation generation, ModuleClassLoader classloader) {
/*  87 */     EquinoxConfiguration configuration = generation.getBundleInfo().getStorage().getConfiguration();
/*  88 */     this.debug = configuration.getDebug();
/*  89 */     this.hookRegistry = configuration.getHookRegistry();
/*  90 */     this.generation = generation;
/*  91 */     this.classloader = classloader;
/*  92 */     String[] cp = getClassPath(generation.getRevision());
/*  93 */     this.fragments = buildFragmentClasspaths(this.classloader, this);
/*  94 */     this.entries = buildClasspath(cp, this, this.generation);
/*     */   }
/*     */   
/*     */   private static String[] getClassPath(ModuleRevision revision) {
/*  98 */     List<ModuleCapability> moduleDatas = revision.getModuleCapabilities("equinox.module.data");
/*     */     
/* 100 */     List<String> cp = moduleDatas.isEmpty() ? null : (List<String>)((ModuleCapability)moduleDatas.get(0)).getAttributes().get("classpath");
/* 101 */     return (cp == null) ? DEFAULT_CLASSPATH : cp.<String>toArray(new String[cp.size()]);
/*     */   }
/*     */   
/*     */   private FragmentClasspath[] buildFragmentClasspaths(ModuleClassLoader hostloader, ClasspathManager manager) {
/* 105 */     if (hostloader == null) {
/* 106 */       return emptyFragments;
/*     */     }
/* 108 */     List<ModuleWire> fragmentWires = hostloader.getBundleLoader().getWiring().getProvidedModuleWires("osgi.wiring.host");
/* 109 */     if (fragmentWires == null || fragmentWires.isEmpty())
/*     */     {
/* 111 */       return emptyFragments;
/*     */     }
/* 113 */     List<FragmentClasspath> result = new ArrayList<>(fragmentWires.size());
/* 114 */     for (ModuleWire fragmentWire : fragmentWires) {
/* 115 */       ModuleRevision revision = fragmentWire.getRequirer();
/* 116 */       BundleInfo.Generation fragGeneration = (BundleInfo.Generation)revision.getRevisionInfo();
/*     */       
/* 118 */       String[] cp = getClassPath(revision);
/* 119 */       ClasspathEntry[] fragEntries = buildClasspath(cp, manager, fragGeneration);
/* 120 */       FragmentClasspath fragClasspath = new FragmentClasspath(fragGeneration, fragEntries);
/* 121 */       insertFragment(fragClasspath, result);
/*     */     } 
/*     */     
/* 124 */     return result.<FragmentClasspath>toArray(new FragmentClasspath[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void insertFragment(FragmentClasspath fragClasspath, List<FragmentClasspath> existing) {
/* 129 */     long fragID = fragClasspath.getGeneration().getRevision().getRevisions().getModule().getId().longValue();
/*     */     
/* 131 */     for (ListIterator<FragmentClasspath> iExisting = existing.listIterator(); iExisting.hasNext(); ) {
/* 132 */       long otherID = ((FragmentClasspath)iExisting.next()).getGeneration().getRevision().getRevisions().getModule().getId().longValue();
/* 133 */       if (fragID < otherID) {
/* 134 */         iExisting.previous();
/* 135 */         iExisting.add(fragClasspath);
/*     */         return;
/*     */       } 
/*     */     } 
/* 139 */     existing.add(fragClasspath);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     byte b;
/*     */     int i;
/*     */     ClasspathEntry[] arrayOfClasspathEntry;
/* 147 */     for (i = (arrayOfClasspathEntry = this.entries).length, b = 0; b < i; ) { ClasspathEntry entry = arrayOfClasspathEntry[b];
/* 148 */       if (entry != null)
/*     */         try {
/* 150 */           entry.close();
/* 151 */         } catch (IOException e) {
/* 152 */           this.generation.getBundleInfo().getStorage().getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, this.generation.getRevision().getRevisions().getModule(), e, new org.osgi.framework.FrameworkListener[0]);
/*     */         }  
/*     */       b++; }
/*     */     
/* 156 */     FragmentClasspath[] currentFragments = getFragmentClasspaths(); FragmentClasspath[] arrayOfFragmentClasspath1;
/* 157 */     for (int j = (arrayOfFragmentClasspath1 = currentFragments).length; i < j; ) { FragmentClasspath currentFragment = arrayOfFragmentClasspath1[i];
/* 158 */       currentFragment.close();
/*     */       i++; }
/*     */   
/*     */   }
/*     */   private ClasspathEntry[] buildClasspath(String[] cp, ClasspathManager hostloader, BundleInfo.Generation source) {
/* 163 */     ArrayList<ClasspathEntry> result = new ArrayList<>(cp.length); byte b; int i;
/*     */     String[] arrayOfString;
/* 165 */     for (i = (arrayOfString = cp).length, b = 0; b < i; ) { String cpEntry = arrayOfString[b];
/* 166 */       findClassPathEntry(result, cpEntry, hostloader, source); b++; }
/*     */     
/* 168 */     return result.<ClasspathEntry>toArray(new ClasspathEntry[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findClassPathEntry(ArrayList<ClasspathEntry> result, String cp, ClasspathManager hostloader, BundleInfo.Generation sourceGeneration) {
/* 183 */     List<ClassLoaderHook> loaderHooks = this.hookRegistry.getClassLoaderHooks();
/* 184 */     boolean hookAdded = false;
/* 185 */     for (ClassLoaderHook hook : loaderHooks) {
/* 186 */       hookAdded |= hook.addClassPathEntry(result, cp, hostloader, sourceGeneration);
/*     */     }
/* 188 */     if (!addClassPathEntry(result, cp, hostloader, sourceGeneration) && !hookAdded) {
/* 189 */       BundleException be = new BundleException(NLS.bind(Msg.BUNDLE_CLASSPATH_ENTRY_NOT_FOUND_EXCEPTION, cp, sourceGeneration.getRevision().toString()), 3);
/* 190 */       sourceGeneration.getBundleInfo().getStorage().getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.INFO, sourceGeneration.getRevision().getRevisions().getModule(), (Throwable)be, new org.osgi.framework.FrameworkListener[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addClassPathEntry(ArrayList<ClasspathEntry> result, String cp, ClasspathManager hostManager, BundleInfo.Generation source) {
/* 205 */     return !(!addStandardClassPathEntry(result, cp, hostManager, source) && !addEclipseClassPathEntry(result, cp, hostManager, source));
/*     */   }
/*     */   
/*     */   public static boolean addStandardClassPathEntry(ArrayList<ClasspathEntry> result, String cp, ClasspathManager hostManager, BundleInfo.Generation generation) {
/* 209 */     if (cp.equals(".")) {
/* 210 */       result.add(hostManager.createClassPathEntry(generation.getBundleFile(), generation));
/* 211 */       return true;
/*     */     } 
/* 213 */     ClasspathEntry element = hostManager.getClasspath(cp, generation);
/* 214 */     if (element != null) {
/* 215 */       result.add(element);
/* 216 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 220 */     if (hostManager.generation == generation) {
/* 221 */       FragmentClasspath[] hostFrags = hostManager.getFragmentClasspaths(); byte b; int i; FragmentClasspath[] arrayOfFragmentClasspath1;
/* 222 */       for (i = (arrayOfFragmentClasspath1 = hostFrags).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath1[b];
/* 223 */         element = hostManager.getClasspath(cp, fragCP.getGeneration());
/* 224 */         if (element != null) {
/* 225 */           result.add(element);
/* 226 */           return true;
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 230 */     return false;
/*     */   }
/*     */   
/*     */   private boolean addEclipseClassPathEntry(ArrayList<ClasspathEntry> result, String cp, ClasspathManager hostManager, BundleInfo.Generation source) {
/* 234 */     String var = hasPrefix(cp);
/* 235 */     if (var != null)
/*     */     {
/* 237 */       return addInternalClassPath(var, result, cp, hostManager, source); } 
/* 238 */     if (cp.startsWith("external:")) {
/* 239 */       cp = cp.substring("external:".length());
/*     */       
/* 241 */       ClasspathEntry cpEntry = hostManager.getExternalClassPath(source.getBundleInfo().getStorage().getConfiguration().substituteVars(cp), source);
/* 242 */       if (cpEntry != null) {
/* 243 */         result.add(cpEntry);
/* 244 */         return true;
/*     */       } 
/*     */     } 
/* 247 */     return false;
/*     */   }
/*     */   
/*     */   private boolean addInternalClassPath(String var, ArrayList<ClasspathEntry> cpEntries, String cp, ClasspathManager hostManager, BundleInfo.Generation source) {
/* 251 */     EquinoxConfiguration configuration = source.getBundleInfo().getStorage().getConfiguration();
/* 252 */     if (var.equals("ws"))
/* 253 */       return addStandardClassPathEntry(cpEntries, "ws/" + configuration.getWS() + cp.substring(4), hostManager, source); 
/* 254 */     if (var.equals("os"))
/* 255 */       return addStandardClassPathEntry(cpEntries, "os/" + configuration.getOS() + cp.substring(4), hostManager, source); 
/* 256 */     if (var.equals("nl")) {
/* 257 */       cp = cp.substring(4);
/* 258 */       List<String> NL_JAR_VARIANTS = (source.getBundleInfo().getStorage().getConfiguration()).ECLIPSE_NL_JAR_VARIANTS;
/* 259 */       for (String nlVariant : NL_JAR_VARIANTS) {
/* 260 */         if (addStandardClassPathEntry(cpEntries, "nl/" + nlVariant + cp, hostManager, source))
/* 261 */           return true; 
/*     */       } 
/*     */     } 
/* 264 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String hasPrefix(String libPath) {
/* 269 */     if (libPath.startsWith("$ws$"))
/* 270 */       return "ws"; 
/* 271 */     if (libPath.startsWith("$os$"))
/* 272 */       return "os"; 
/* 273 */     if (libPath.startsWith("$nl$"))
/* 274 */       return "nl"; 
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathEntry getClasspath(String cp, BundleInfo.Generation cpGeneration) {
/* 285 */     BundleFile bundlefile = null;
/*     */     
/* 287 */     BundleEntry cpEntry = cpGeneration.getBundleFile().getEntry(cp);
/*     */     
/* 289 */     if (cpEntry != null && cpEntry.getName().endsWith("/")) {
/* 290 */       bundlefile = createBundleFile(cp, cpGeneration);
/*     */     } else {
/* 292 */       File file; if ((file = cpGeneration.getBundleFile().getFile(cp, false)) != null)
/* 293 */         bundlefile = createBundleFile(file, cpGeneration); 
/* 294 */     }  if (bundlefile != null)
/* 295 */       return createClassPathEntry(bundlefile, cpGeneration); 
/* 296 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathEntry getExternalClassPath(String cp, BundleInfo.Generation cpGeneration) {
/* 306 */     File file = new File(cp);
/* 307 */     if (!file.isAbsolute())
/* 308 */       return null; 
/* 309 */     BundleFile bundlefile = createBundleFile(file, cpGeneration);
/* 310 */     if (bundlefile != null)
/* 311 */       return createClassPathEntry(bundlefile, cpGeneration); 
/* 312 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized void loadFragments(Collection<ModuleRevision> addedFragments) {
/* 316 */     List<FragmentClasspath> result = new ArrayList<>(Arrays.asList(this.fragments));
/*     */     
/* 318 */     for (ModuleRevision addedFragment : addedFragments) {
/* 319 */       BundleInfo.Generation fragGeneration = (BundleInfo.Generation)addedFragment.getRevisionInfo();
/* 320 */       String[] cp = getClassPath(addedFragment);
/* 321 */       ClasspathEntry[] fragEntries = buildClasspath(cp, this, fragGeneration);
/* 322 */       FragmentClasspath fragClasspath = new FragmentClasspath(fragGeneration, fragEntries);
/* 323 */       insertFragment(fragClasspath, result);
/*     */     } 
/*     */     
/* 326 */     this.fragments = result.<FragmentClasspath>toArray(new FragmentClasspath[result.size()]);
/*     */   }
/*     */   
/*     */   private static BundleFile createBundleFile(File content, BundleInfo.Generation generation) {
/* 330 */     if (!content.exists()) {
/* 331 */       return null;
/*     */     }
/* 333 */     return generation.getBundleInfo().getStorage().createBundleFile(content, generation, content.isDirectory(), false);
/*     */   }
/*     */   
/*     */   private static BundleFile createBundleFile(String nestedDir, BundleInfo.Generation generation) {
/* 337 */     return generation.getBundleInfo().getStorage().createNestedBundleFile(nestedDir, generation.getBundleFile(), generation);
/*     */   }
/*     */   
/*     */   private ClasspathEntry createClassPathEntry(BundleFile bundlefile, BundleInfo.Generation source) {
/*     */     ClasspathEntry entry;
/* 342 */     if (this.classloader != null) {
/* 343 */       entry = this.classloader.createClassPathEntry(bundlefile, source);
/*     */     } else {
/* 345 */       entry = new ClasspathEntry(bundlefile, source.getDomain(), source);
/* 346 */     }  return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findLocalResource(String resource) {
/* 359 */     List<ClassLoaderHook> hooks = this.hookRegistry.getClassLoaderHooks();
/* 360 */     boolean hookFailed = false;
/* 361 */     for (ClassLoaderHook hook : hooks) {
/*     */       try {
/* 363 */         hook.preFindLocalResource(resource, this);
/* 364 */       } catch (NoSuchElementException noSuchElementException) {
/*     */         
/* 366 */         hookFailed = true;
/*     */       } 
/*     */     } 
/* 369 */     URL result = null;
/*     */     try {
/* 371 */       if (!hookFailed) {
/* 372 */         result = findLocalResourceImpl(resource, -1);
/*     */       }
/*     */     } finally {
/* 375 */       for (ClassLoaderHook hook : hooks) {
/*     */         try {
/* 377 */           hook.postFindLocalResource(resource, result, this);
/* 378 */         } catch (NoSuchElementException noSuchElementException) {
/* 379 */           result = null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 383 */     return result;
/*     */   }
/*     */   
/*     */   private URL findLocalResourceImpl(String resource, int classPathIndex) {
/* 387 */     Module m = this.generation.getRevision().getRevisions().getModule();
/* 388 */     URL result = null;
/* 389 */     int[] curIndex = new int[1];
/*     */ 
/*     */     
/* 392 */     for (ClassLoaderHook hook : this.hookRegistry.getClassLoaderHooks()) {
/* 393 */       ClasspathEntry[] hookEntries = hook.getClassPathEntries(resource, this);
/* 394 */       if (hookEntries != null) {
/* 395 */         return findLocalResourceImpl(resource, hookEntries, m, classPathIndex, curIndex);
/*     */       }
/*     */     } 
/*     */     
/* 399 */     curIndex[0] = 0;
/*     */     
/* 401 */     result = findLocalResourceImpl(resource, this.entries, m, classPathIndex, curIndex);
/* 402 */     if (result != null)
/* 403 */       return result; 
/*     */     byte b;
/*     */     int i;
/*     */     FragmentClasspath[] arrayOfFragmentClasspath;
/* 407 */     for (i = (arrayOfFragmentClasspath = getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath[b];
/* 408 */       result = findLocalResourceImpl(resource, fragCP.getEntries(), m, classPathIndex, curIndex);
/* 409 */       if (result != null) {
/* 410 */         return result;
/*     */       }
/*     */       b++; }
/*     */     
/* 414 */     return null;
/*     */   } private URL findLocalResourceImpl(String resource, ClasspathEntry[] cpEntries, Module m, int classPathIndex, int[] curIndex) {
/*     */     byte b;
/*     */     int i;
/*     */     ClasspathEntry[] arrayOfClasspathEntry;
/* 419 */     for (i = (arrayOfClasspathEntry = cpEntries).length, b = 0; b < i; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b];
/* 420 */       if (cpEntry != null) {
/* 421 */         URL result = cpEntry.findResource(resource, m, curIndex[0]);
/* 422 */         if (result != null && (classPathIndex == -1 || classPathIndex == curIndex[0])) {
/* 423 */           return result;
/*     */         }
/*     */       } 
/* 426 */       curIndex[0] = curIndex[0] + 1; b++; }
/*     */     
/* 428 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> findLocalResources(String resource) {
/* 437 */     Module m = this.generation.getRevision().getRevisions().getModule();
/* 438 */     List<URL> resources = new ArrayList<>(6);
/* 439 */     int[] classPathIndex = new int[1];
/*     */ 
/*     */     
/* 442 */     for (ClassLoaderHook hook : this.hookRegistry.getClassLoaderHooks()) {
/* 443 */       ClasspathEntry[] hookEntries = hook.getClassPathEntries(resource, this);
/* 444 */       if (hookEntries != null) {
/* 445 */         findLocalResources(resource, hookEntries, m, classPathIndex, resources);
/* 446 */         return (resources.size() > 0) ? Collections.<URL>enumeration(resources) : Collections.<URL>emptyEnumeration();
/*     */       } 
/*     */     } 
/*     */     
/* 450 */     classPathIndex[0] = 0;
/*     */     
/* 452 */     findLocalResources(resource, this.entries, m, classPathIndex, resources); byte b; int i;
/*     */     FragmentClasspath[] arrayOfFragmentClasspath;
/* 454 */     for (i = (arrayOfFragmentClasspath = getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath[b];
/* 455 */       findLocalResources(resource, fragCP.getEntries(), m, classPathIndex, resources);
/*     */       b++; }
/*     */     
/* 458 */     if (resources.size() > 0)
/* 459 */       return Collections.enumeration(resources); 
/* 460 */     return Collections.emptyEnumeration(); } private void findLocalResources(String resource, ClasspathEntry[] cpEntries, Module m, int[] classPathIndex, List<URL> resources) {
/*     */     byte b;
/*     */     int i;
/*     */     ClasspathEntry[] arrayOfClasspathEntry;
/* 464 */     for (i = (arrayOfClasspathEntry = cpEntries).length, b = 0; b < i; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b];
/* 465 */       if (cpEntry != null) {
/* 466 */         URL url = cpEntry.findResource(resource, m, classPathIndex[0]);
/* 467 */         if (url != null) {
/* 468 */           resources.add(url);
/*     */         }
/*     */       } 
/* 471 */       classPathIndex[0] = classPathIndex[0] + 1;
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleEntry findLocalEntry(String path) {
/* 481 */     return findLocalEntry(path, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleEntry findLocalEntry(String path, int classPathIndex) {
/* 492 */     BundleEntry result = null;
/* 493 */     int[] curIndex = new int[1];
/*     */ 
/*     */     
/* 496 */     for (ClassLoaderHook hook : this.hookRegistry.getClassLoaderHooks()) {
/* 497 */       ClasspathEntry[] hookEntries = hook.getClassPathEntries(path, this);
/* 498 */       if (hookEntries != null) {
/* 499 */         return findLocalEntry(path, hookEntries, classPathIndex, curIndex);
/*     */       }
/*     */     } 
/*     */     
/* 503 */     curIndex[0] = 0;
/*     */     
/* 505 */     result = findLocalEntry(path, this.entries, classPathIndex, curIndex);
/* 506 */     if (result != null)
/* 507 */       return result; 
/*     */     byte b;
/*     */     int i;
/*     */     FragmentClasspath[] arrayOfFragmentClasspath;
/* 511 */     for (i = (arrayOfFragmentClasspath = getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath[b];
/* 512 */       result = findLocalEntry(path, fragCP.getEntries(), classPathIndex, curIndex);
/* 513 */       if (result != null) {
/* 514 */         return result;
/*     */       }
/*     */       b++; }
/*     */     
/* 518 */     return null; } private BundleEntry findLocalEntry(String path, ClasspathEntry[] cpEntries, int classPathIndex, int[] curIndex) {
/*     */     byte b;
/*     */     int i;
/*     */     ClasspathEntry[] arrayOfClasspathEntry;
/* 522 */     for (i = (arrayOfClasspathEntry = cpEntries).length, b = 0; b < i; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b];
/* 523 */       if (cpEntry != null && (
/* 524 */         classPathIndex == -1 || classPathIndex == curIndex[0])) {
/* 525 */         BundleEntry result = cpEntry.findEntry(path);
/* 526 */         if (result != null) {
/* 527 */           return result;
/*     */         }
/*     */       } 
/*     */       
/* 531 */       curIndex[0] = curIndex[0] + 1; b++; }
/*     */     
/* 533 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findLocalClass(String classname) throws ClassNotFoundException {
/* 557 */     Class<?> result = null;
/* 558 */     List<ClassLoaderHook> hooks = this.hookRegistry.getClassLoaderHooks();
/*     */     try {
/* 560 */       for (ClassLoaderHook hook : hooks) {
/* 561 */         hook.preFindLocalClass(classname, this);
/*     */       }
/* 563 */       result = this.classloader.publicFindLoaded(classname);
/* 564 */       if (result != null)
/* 565 */         return result; 
/* 566 */       result = findLocalClassImpl(classname, hooks);
/* 567 */       return result;
/*     */     } finally {
/* 569 */       for (ClassLoaderHook hook : hooks) {
/* 570 */         hook.postFindLocalClass(classname, result, this);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> findLocalClassImpl(String classname, List<ClassLoaderHook> hooks) {
/* 579 */     for (ClassLoaderHook hook : this.hookRegistry.getClassLoaderHooks()) {
/* 580 */       ClasspathEntry[] hookEntries = hook.getClassPathEntries(classname, this);
/* 581 */       if (hookEntries != null) {
/* 582 */         return findLocalClassImpl(classname, hookEntries, hooks);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 587 */     Class<?> result = findLocalClassImpl(classname, this.entries, hooks);
/* 588 */     if (result != null)
/* 589 */       return result; 
/*     */     byte b;
/*     */     int i;
/*     */     FragmentClasspath[] arrayOfFragmentClasspath;
/* 593 */     for (i = (arrayOfFragmentClasspath = getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath[b];
/* 594 */       result = findLocalClassImpl(classname, fragCP.getEntries(), hooks);
/* 595 */       if (result != null) {
/* 596 */         return result;
/*     */       }
/*     */       b++; }
/*     */     
/* 600 */     return null;
/*     */   } private Class<?> findLocalClassImpl(String classname, ClasspathEntry[] cpEntries, List<ClassLoaderHook> hooks) {
/*     */     byte b;
/*     */     int i;
/*     */     ClasspathEntry[] arrayOfClasspathEntry;
/* 605 */     for (i = (arrayOfClasspathEntry = cpEntries).length, b = 0; b < i; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b];
/* 606 */       if (cpEntry != null) {
/* 607 */         Class<?> result = findClassImpl(classname, cpEntry, hooks);
/* 608 */         if (result != null)
/* 609 */           return result; 
/*     */       } 
/*     */       b++; }
/*     */     
/* 613 */     return null;
/*     */   }
/*     */   private Class<?> findClassImpl(String name, ClasspathEntry classpathEntry, List<ClassLoaderHook> hooks) {
/*     */     byte[] classbytes;
/* 617 */     if (this.debug.DEBUG_LOADER)
/* 618 */       Debug.println("ModuleClassLoader[" + this.classloader.getBundleLoader() + " - " + classpathEntry.getBundleFile() + "].findClassImpl(" + name + ")"); 
/* 619 */     String filename = name.replace('.', '/').concat(".class");
/*     */     
/* 621 */     BundleEntry entry = classpathEntry.findEntry(filename);
/* 622 */     if (entry == null) {
/* 623 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 627 */       classbytes = entry.getBytes();
/* 628 */     } catch (IOException e) {
/* 629 */       if (this.debug.DEBUG_LOADER)
/* 630 */         Debug.println("  IOException reading " + filename + " from " + classpathEntry.getBundleFile()); 
/* 631 */       throw (LinkageError)(new LinkageError("Error reading class bytes: " + name)).initCause(e);
/*     */     } 
/* 633 */     if (this.debug.DEBUG_LOADER) {
/* 634 */       Debug.println("  read " + classbytes.length + " bytes from " + classpathEntry.getBundleFile() + "!/" + filename);
/* 635 */       Debug.println("  defining class " + name);
/*     */     } 
/*     */     
/*     */     try {
/* 639 */       return defineClass(name, classbytes, classpathEntry, entry, hooks);
/* 640 */     } catch (Error e) {
/* 641 */       if (this.debug.DEBUG_LOADER)
/* 642 */         Debug.println("  error defining class " + name); 
/* 643 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   static class DefineContext {
/* 648 */     Collection<String> currentlyProcessing = new ArrayList<>(5);
/* 649 */     Collection<String> currentlyDefining = new ArrayList<>(5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> defineClass(String name, byte[] classbytes, ClasspathEntry classpathEntry, BundleEntry entry, List<ClassLoaderHook> hooks) {
/* 668 */     ModuleClassLoader.DefineClassResult result = null;
/* 669 */     boolean recursionDetected = false;
/*     */     
/* 671 */     try { definePackage(name, classpathEntry);
/* 672 */       DefineContext context = this.currentDefineContext.get();
/* 673 */       if (context == null) {
/* 674 */         context = new DefineContext();
/* 675 */         this.currentDefineContext.set(context);
/*     */       } 
/*     */ 
/*     */       
/* 679 */       if (!this.hookRegistry.getContainer().isProcessClassRecursionSupportedByAll()) {
/*     */ 
/*     */         
/* 682 */         if (context.currentlyProcessing.contains(name)) {
/*     */           
/* 684 */           recursionDetected = true;
/*     */           
/* 686 */           return null;
/*     */         } 
/* 688 */         context.currentlyProcessing.add(name);
/*     */         
/*     */         try {
/* 691 */           for (ClassLoaderHook hook : hooks) {
/* 692 */             if (!hook.isProcessClassRecursionSupported()) {
/* 693 */               classbytes = processClass(hook, name, classbytes, classpathEntry, entry, this, hooks);
/*     */             }
/*     */           } 
/*     */         } finally {
/* 697 */           context.currentlyProcessing.remove(name);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 702 */       for (ClassLoaderHook hook : hooks) {
/* 703 */         if (hook.isProcessClassRecursionSupported())
/*     */         {
/*     */           
/* 706 */           classbytes = processClass(hook, name, classbytes, classpathEntry, entry, this, hooks);
/*     */         }
/*     */       } 
/*     */       
/* 710 */       if (context.currentlyDefining.contains(name))
/*     */       {
/* 712 */         return null;
/*     */       }
/* 714 */       context.currentlyDefining.add(name);
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */       
/* 722 */       if (!recursionDetected)
/*     */       
/* 724 */       { Class<?> defined = (result != null && result.defined) ? result.clazz : null;
/* 725 */         for (ClassLoaderHook hook : hooks)
/* 726 */           hook.recordClassDefine(name, defined, classbytes, classpathEntry, entry, this);  }  }  if (!recursionDetected) { Class<?> defined = (result != null && result.defined) ? result.clazz : null; for (ClassLoaderHook hook : hooks) hook.recordClassDefine(name, defined, classbytes, classpathEntry, entry, this);
/*     */        }
/*     */ 
/*     */ 
/*     */     
/* 731 */     return (result == null) ? null : result.clazz;
/*     */   }
/*     */   
/*     */   private byte[] processClass(ClassLoaderHook hook, String name, byte[] classbytes, ClasspathEntry classpathEntry, BundleEntry entry, ClasspathManager classpathManager, List<ClassLoaderHook> hooks) {
/* 735 */     byte[] modifiedBytes = hook.processClass(name, classbytes, classpathEntry, entry, this);
/* 736 */     if (modifiedBytes != null) {
/*     */       
/* 738 */       if (!(hook instanceof org.eclipse.osgi.internal.weaving.WeavingHookConfigurator)) {
/* 739 */         for (ClassLoaderHook rejectHook : hooks) {
/* 740 */           if (rejectHook.rejectTransformation(name, modifiedBytes, classpathEntry, entry, this)) {
/* 741 */             modifiedBytes = null;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 746 */       if (modifiedBytes != null) {
/* 747 */         classbytes = modifiedBytes;
/*     */       }
/*     */     } 
/* 750 */     return classbytes;
/*     */   }
/*     */ 
/*     */   
/*     */   private void definePackage(String name, ClasspathEntry classpathEntry) {
/* 755 */     int lastIndex = name.lastIndexOf('.');
/* 756 */     if (lastIndex < 0) {
/*     */       return;
/*     */     }
/* 759 */     String packageName = name.substring(0, lastIndex);
/* 760 */     Object pkg = this.classloader.publicGetPackage(packageName);
/* 761 */     if (pkg != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 766 */     String specTitle = null, specVersion = null, specVendor = null, implTitle = null, implVersion = null, implVendor = null;
/*     */     
/* 768 */     if ((this.generation.getBundleInfo().getStorage().getConfiguration()).DEFINE_PACKAGE_ATTRIBUTES) {
/* 769 */       ManifestPackageAttributes manifestPackageAttributes = classpathEntry.manifestPackageAttributesFor(packageName);
/* 770 */       TitleVersionVendor specification = manifestPackageAttributes.getSpecification();
/* 771 */       TitleVersionVendor implementation = manifestPackageAttributes.getImplementation();
/* 772 */       specTitle = specification.getTitle();
/* 773 */       specVersion = specification.getVersion();
/* 774 */       specVendor = specification.getVendor();
/* 775 */       implTitle = implementation.getTitle();
/* 776 */       implVersion = implementation.getVersion();
/* 777 */       implVendor = implementation.getVendor();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 782 */     this.classloader.publicDefinePackage(packageName, specTitle, specVersion, specVendor, implTitle, implVersion, implVendor, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FragmentClasspath[] getFragmentClasspaths() {
/* 790 */     return this.fragments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathEntry[] getHostClasspathEntries() {
/* 798 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findLibrary(String libname) {
/* 807 */     synchronized (this) {
/* 808 */       if (this.loadedLibraries == null)
/* 809 */         this.loadedLibraries = new ArrayMap(1); 
/*     */     } 
/* 811 */     synchronized (this.loadedLibraries) {
/*     */ 
/*     */ 
/*     */       
/* 815 */       String libpath = (String)this.loadedLibraries.get(libname);
/* 816 */       if (libpath != null) {
/* 817 */         return libpath;
/*     */       }
/* 819 */       libpath = findLibrary0(libname);
/* 820 */       if (libpath != null)
/* 821 */         this.loadedLibraries.put(libname, libpath); 
/* 822 */       return libpath;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String findLibrary0(String libname) {
/* 827 */     List<ClassLoaderHook> hooks = this.hookRegistry.getClassLoaderHooks();
/* 828 */     String result = null;
/* 829 */     for (ClassLoaderHook hook : hooks) {
/*     */       try {
/* 831 */         result = hook.preFindLibrary(libname, this.classloader);
/* 832 */         if (result != null) {
/* 833 */           return result;
/*     */         }
/* 835 */       } catch (FileNotFoundException fileNotFoundException) {
/* 836 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 840 */     result = this.generation.findLibrary(libname);
/* 841 */     if (result != null) {
/* 842 */       return result;
/*     */     }
/*     */ 
/*     */     
/* 846 */     FragmentClasspath[] currentFragments = getFragmentClasspaths(); byte b; int i; FragmentClasspath[] arrayOfFragmentClasspath1;
/* 847 */     for (i = (arrayOfFragmentClasspath1 = currentFragments).length, b = 0; b < i; ) { FragmentClasspath fragment = arrayOfFragmentClasspath1[b];
/* 848 */       result = fragment.getGeneration().findLibrary(libname);
/* 849 */       if (result != null) {
/* 850 */         return result;
/*     */       }
/*     */       b++; }
/*     */     
/* 854 */     for (ClassLoaderHook hook : hooks) {
/* 855 */       result = hook.postFindLibrary(libname, this.classloader);
/* 856 */       if (result != null) {
/* 857 */         return result;
/*     */       }
/*     */     } 
/* 860 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<URL> findEntries(String path, String filePattern, int options) {
/* 867 */     List<BundleInfo.Generation> generations = new ArrayList<>();
/*     */     
/* 869 */     generations.add(this.generation);
/*     */     
/* 871 */     FragmentClasspath[] currentFragments = getFragmentClasspaths(); byte b; int i; FragmentClasspath[] arrayOfFragmentClasspath1;
/* 872 */     for (i = (arrayOfFragmentClasspath1 = currentFragments).length, b = 0; b < i; ) { FragmentClasspath fragmentClasspath = arrayOfFragmentClasspath1[b];
/* 873 */       generations.add(fragmentClasspath.getGeneration());
/*     */       b++; }
/*     */     
/* 876 */     Enumeration<URL> eURLs = Storage.findEntries(generations, path, filePattern, options);
/* 877 */     if (eURLs == null)
/* 878 */       return Collections.emptyList(); 
/* 879 */     return Collections.unmodifiableList(Collections.list(eURLs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> listLocalResources(String path, String filePattern, int options) {
/* 886 */     List<BundleFile> bundleFiles = new ArrayList<>();
/*     */ 
/*     */     
/* 889 */     for (ClassLoaderHook hook : this.hookRegistry.getClassLoaderHooks()) {
/* 890 */       ClasspathEntry[] hookEntries = hook.getClassPathEntries(path, this);
/* 891 */       if (hookEntries != null) {
/* 892 */         byte b1; int j; ClasspathEntry[] arrayOfClasspathEntry; for (j = (arrayOfClasspathEntry = hookEntries).length, b1 = 0; b1 < j; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b1];
/* 893 */           cpEntry.addBundleFiles(bundleFiles); b1++; }
/*     */         
/* 895 */         return Storage.listEntryPaths(bundleFiles, path, filePattern, options);
/*     */       } 
/*     */     } 
/*     */     
/* 899 */     ClasspathEntry[] cpEntries = getHostClasspathEntries(); byte b; int i; ClasspathEntry[] arrayOfClasspathEntry1;
/* 900 */     for (i = (arrayOfClasspathEntry1 = cpEntries).length, b = 0; b < i; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry1[b];
/* 901 */       cpEntry.addBundleFiles(bundleFiles); b++; }
/*     */     
/*     */     FragmentClasspath[] arrayOfFragmentClasspath;
/* 904 */     for (i = (arrayOfFragmentClasspath = getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragmentClasspath = arrayOfFragmentClasspath[b]; byte b1; int j; ClasspathEntry[] arrayOfClasspathEntry;
/* 905 */       for (j = (arrayOfClasspathEntry = fragmentClasspath.getEntries()).length, b1 = 0; b1 < j; ) { ClasspathEntry cpEntry = arrayOfClasspathEntry[b1];
/* 906 */         cpEntry.addBundleFiles(bundleFiles); b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 910 */     return Storage.listEntryPaths(bundleFiles, path, filePattern, options);
/*     */   }
/*     */   
/*     */   public BundleInfo.Generation getGeneration() {
/* 914 */     return this.generation;
/*     */   }
/*     */   
/*     */   public ModuleClassLoader getClassLoader() {
/* 918 */     return this.classloader;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\classpath\ClasspathManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */