package org.eclipse.osgi.service.resolver;

public interface BundleSpecification extends VersionConstraint {
  boolean isExported();
  
  boolean isOptional();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\BundleSpecification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */