package org.eclipse.osgi.service.resolver;

import java.util.Map;
import org.osgi.framework.wiring.BundleRevision;

public interface BundleDescription extends BaseDescription, BundleRevision {
  String getSymbolicName();
  
  Map<String, Object> getAttributes();
  
  String getLocation();
  
  BundleSpecification[] getRequiredBundles();
  
  ExportPackageDescription[] getExportPackages();
  
  ImportPackageSpecification[] getImportPackages();
  
  ImportPackageSpecification[] getAddedDynamicImportPackages();
  
  GenericSpecification[] getGenericRequires();
  
  GenericDescription[] getGenericCapabilities();
  
  boolean hasDynamicImports();
  
  ExportPackageDescription[] getSelectedExports();
  
  GenericDescription[] getSelectedGenericCapabilities();
  
  BundleDescription[] getResolvedRequires();
  
  ExportPackageDescription[] getResolvedImports();
  
  GenericDescription[] getResolvedGenericRequires();
  
  boolean isResolved();
  
  State getContainingState();
  
  String toString();
  
  HostSpecification getHost();
  
  long getBundleId();
  
  BundleDescription[] getFragments();
  
  boolean isSingleton();
  
  boolean isRemovalPending();
  
  BundleDescription[] getDependents();
  
  String getPlatformFilter();
  
  boolean attachFragments();
  
  boolean dynamicFragments();
  
  String[] getExecutionEnvironments();
  
  NativeCodeSpecification getNativeCodeSpecification();
  
  ExportPackageDescription[] getSubstitutedExports();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\BundleDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */