/*     */ package org.eclipse.osgi.service.resolver;
/*     */ 
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.framework.VersionRange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionRange
/*     */   extends VersionRange
/*     */ {
/*  24 */   private static final Version versionMax = new Version(2147483647, 2147483647, 2147483647);
/*     */   
/*     */   private static final char INCLUDE_MIN = '[';
/*     */   
/*     */   private static final char EXCLUDE_MIN = '(';
/*     */   
/*     */   private static final char INCLUDE_MAX = ']';
/*     */   
/*     */   private static final char EXCLUDE_MAX = ')';
/*     */   
/*  34 */   public static final VersionRange emptyRange = new VersionRange("0.0.0");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionRange(Version minVersion, boolean includeMin, Version maxVersion, boolean includeMax) {
/*  45 */     super(includeMin ? 91 : 40, (minVersion == null) ? Version.emptyVersion : minVersion, versionMax.equals(maxVersion) ? null : maxVersion, includeMax ? 93 : 41);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionRange(String versionRange) {
/*  71 */     super((versionRange == null || versionRange.length() == 0) ? "0.0.0" : versionRange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getMinimum() {
/*  79 */     return getLeft();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIncludeMinimum() {
/*  88 */     return (getLeftType() == '[');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getMaximum() {
/* 102 */     Version right = getRight();
/* 103 */     return (right == null) ? versionMax : right;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIncludeMaximum() {
/* 112 */     return (getRightType() == ']');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(Version version) {
/* 126 */     if (version == null)
/* 127 */       version = Version.emptyVersion; 
/* 128 */     return includes(version);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\VersionRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */