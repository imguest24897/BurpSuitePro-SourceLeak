/*    */ package org.eclipse.osgi.internal.loader.sources;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiSourcePackage
/*    */   extends PackageSource
/*    */ {
/*    */   private final SingleSourcePackage[] suppliers;
/*    */   
/*    */   public MultiSourcePackage(String id, SingleSourcePackage[] suppliers) {
/* 24 */     super(id);
/* 25 */     this.suppliers = suppliers;
/*    */   }
/*    */ 
/*    */   
/*    */   public SingleSourcePackage[] getSuppliers() {
/* 30 */     return this.suppliers;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/* 35 */     Class<?> result = null; byte b; int i; SingleSourcePackage[] arrayOfSingleSourcePackage;
/* 36 */     for (i = (arrayOfSingleSourcePackage = this.suppliers).length, b = 0; b < i; ) { SingleSourcePackage supplier = arrayOfSingleSourcePackage[b];
/* 37 */       result = supplier.loadClass(name);
/* 38 */       if (result != null)
/* 39 */         return result;  b++; }
/*    */     
/* 41 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getResource(String name) {
/* 46 */     URL result = null; byte b; int i; SingleSourcePackage[] arrayOfSingleSourcePackage;
/* 47 */     for (i = (arrayOfSingleSourcePackage = this.suppliers).length, b = 0; b < i; ) { SingleSourcePackage supplier = arrayOfSingleSourcePackage[b];
/* 48 */       result = supplier.getResource(name);
/* 49 */       if (result != null)
/* 50 */         return result;  b++; }
/*    */     
/* 52 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> getResources(String name) {
/* 57 */     Enumeration<URL> results = null; byte b; int i; SingleSourcePackage[] arrayOfSingleSourcePackage;
/* 58 */     for (i = (arrayOfSingleSourcePackage = this.suppliers).length, b = 0; b < i; ) { SingleSourcePackage supplier = arrayOfSingleSourcePackage[b];
/* 59 */       results = BundleLoader.compoundEnumerations(results, supplier.getResources(name)); b++; }
/*    */     
/* 61 */     return results;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<String> listResources(String path, String filePattern) {
/* 66 */     List<String> result = new ArrayList<>(); byte b; int i; SingleSourcePackage[] arrayOfSingleSourcePackage;
/* 67 */     for (i = (arrayOfSingleSourcePackage = this.suppliers).length, b = 0; b < i; ) { SingleSourcePackage source = arrayOfSingleSourcePackage[b];
/* 68 */       Collection<String> sourceResources = source.listResources(path, filePattern);
/* 69 */       for (String resource : sourceResources) {
/* 70 */         if (!result.contains(resource))
/* 71 */           result.add(resource); 
/*    */       }  b++; }
/*    */     
/* 74 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\sources\MultiSourcePackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */