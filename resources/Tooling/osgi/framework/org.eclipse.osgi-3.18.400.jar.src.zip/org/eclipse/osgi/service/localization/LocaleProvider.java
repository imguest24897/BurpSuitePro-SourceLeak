package org.eclipse.osgi.service.localization;

import java.util.Locale;

public interface LocaleProvider {
  Locale getLocale();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\localization\LocaleProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */