/*    */ package org.eclipse.osgi.internal.loader.classpath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ManifestPackageAttributes
/*    */ {
/* 23 */   static final ManifestPackageAttributes NONE = new ManifestPackageAttributes(TitleVersionVendor.NONE, TitleVersionVendor.NONE);
/*    */ 
/*    */   
/*    */   private final TitleVersionVendor implementation;
/*    */ 
/*    */   
/*    */   private final TitleVersionVendor specification;
/*    */ 
/*    */ 
/*    */   
/*    */   private static String or(String first, String second) {
/* 34 */     return (first == null) ? second : first;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ManifestPackageAttributes of(String specificationTitle, String specificationVersion, String specificationVendor, String implementationTitle, String implementationVersion, String implementationVendor, ManifestPackageAttributes defaultAttributes) {
/* 53 */     if (defaultAttributes == null) {
/* 54 */       defaultAttributes = NONE;
/*    */     }
/* 56 */     return of(
/* 57 */         or(specificationTitle, defaultAttributes.getSpecification().getTitle()), 
/* 58 */         or(specificationVersion, defaultAttributes.getSpecification().getVersion()), 
/* 59 */         or(specificationVendor, defaultAttributes.getSpecification().getVendor()), 
/* 60 */         or(implementationTitle, defaultAttributes.getImplementation().getTitle()), 
/* 61 */         or(implementationVersion, defaultAttributes.getImplementation().getVersion()), 
/* 62 */         or(implementationVendor, defaultAttributes.getImplementation().getVendor()));
/*    */   }
/*    */ 
/*    */   
/*    */   private static ManifestPackageAttributes of(String specificationTitle, String specificationVersion, String specificationVendor, String implementationTitle, String implementationVersion, String implementationVendor) {
/* 67 */     TitleVersionVendor specification = TitleVersionVendor.of(specificationTitle, specificationVersion, specificationVendor);
/* 68 */     TitleVersionVendor implementation = TitleVersionVendor.of(implementationTitle, implementationVersion, implementationVendor);
/* 69 */     if (specification == TitleVersionVendor.NONE && implementation == TitleVersionVendor.NONE) {
/* 70 */       return NONE;
/*    */     }
/* 72 */     return new ManifestPackageAttributes(implementation, specification);
/*    */   }
/*    */   
/*    */   private ManifestPackageAttributes(TitleVersionVendor implementation, TitleVersionVendor specification) {
/* 76 */     if (implementation == null || specification == null) {
/* 77 */       throw new IllegalArgumentException();
/*    */     }
/* 79 */     this.implementation = implementation;
/* 80 */     this.specification = specification;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TitleVersionVendor getImplementation() {
/* 88 */     return this.implementation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TitleVersionVendor getSpecification() {
/* 96 */     return this.specification;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\classpath\ManifestPackageAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */