/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.eclipse.osgi.framework.util.ThreadInfoReport;
/*     */ import org.eclipse.osgi.internal.container.EquinoxReentrantLock;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.BundleReference;
/*     */ import org.osgi.framework.startlevel.BundleStartLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Module
/*     */   implements BundleReference, BundleStartLevel, Comparable<Module>
/*     */ {
/*     */   public enum StartOptions
/*     */   {
/*  46 */     TRANSIENT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     USE_ACTIVATION_POLICY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     TRANSIENT_RESUME,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     TRANSIENT_IF_AUTO_START,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     LAZY_TRIGGER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isContained(StartOptions... options) {
/*     */       byte b;
/*     */       int i;
/*     */       StartOptions[] arrayOfStartOptions;
/*  76 */       for (i = (arrayOfStartOptions = options).length, b = 0; b < i; ) { StartOptions option = arrayOfStartOptions[b];
/*  77 */         if (equals(option))
/*  78 */           return true; 
/*     */         b++; }
/*     */       
/*  81 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum StopOptions
/*     */   {
/*  89 */     TRANSIENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isContained(StopOptions... options) {
/*     */       byte b;
/*     */       int i;
/*     */       StopOptions[] arrayOfStopOptions;
/*  99 */       for (i = (arrayOfStopOptions = options).length, b = 0; b < i; ) { StopOptions option = arrayOfStopOptions[b];
/* 100 */         if (equals(option))
/* 101 */           return true; 
/*     */         b++; }
/*     */       
/* 104 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum State
/*     */   {
/* 112 */     INSTALLED,
/*     */ 
/*     */ 
/*     */     
/* 116 */     RESOLVED,
/*     */ 
/*     */ 
/*     */     
/* 120 */     LAZY_STARTING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     STARTING,
/*     */ 
/*     */ 
/*     */     
/* 129 */     ACTIVE,
/*     */ 
/*     */ 
/*     */     
/* 133 */     STOPPING,
/*     */ 
/*     */ 
/*     */     
/* 137 */     UNINSTALLED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Settings
/*     */   {
/* 147 */     AUTO_START,
/*     */ 
/*     */ 
/*     */     
/* 151 */     USE_ACTIVATION_POLICY,
/*     */ 
/*     */ 
/*     */     
/* 155 */     PARALLEL_ACTIVATION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public static final EnumSet<State> ACTIVE_SET = EnumSet.of(State.STARTING, State.LAZY_STARTING, State.ACTIVE, State.STOPPING);
/*     */ 
/*     */ 
/*     */   
/* 169 */   public static final EnumSet<State> RESOLVED_SET = EnumSet.of(State.RESOLVED, State.STARTING, State.LAZY_STARTING, State.ACTIVE, State.STOPPING);
/*     */   
/*     */   private final Long id;
/*     */   private final String location;
/*     */   private final ModuleRevisions revisions;
/* 174 */   final EquinoxReentrantLock stateChangeLock = new EquinoxReentrantLock();
/* 175 */   private final EnumSet<ModuleContainerAdaptor.ModuleEvent> stateTransitionEvents = EnumSet.noneOf(ModuleContainerAdaptor.ModuleEvent.class);
/*     */   private final EnumSet<Settings> settings;
/* 177 */   final AtomicInteger inStart = new AtomicInteger(0);
/* 178 */   private volatile State state = State.INSTALLED;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile int startlevel;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile long lastModified;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module(Long id, String location, ModuleContainer container, EnumSet<Settings> settings, int startlevel) {
/* 192 */     this.id = id;
/* 193 */     this.location = location;
/* 194 */     this.revisions = new ModuleRevisions(this, container);
/* 195 */     this.settings = (settings == null) ? EnumSet.<Settings>noneOf(Settings.class) : EnumSet.<Settings>copyOf(settings);
/* 196 */     this.startlevel = startlevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Long getId() {
/* 204 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLocation() {
/* 211 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ModuleRevisions getRevisions() {
/* 219 */     return this.revisions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ModuleContainer getContainer() {
/* 227 */     return this.revisions.getContainer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ModuleRevision getCurrentRevision() {
/* 236 */     return this.revisions.getCurrentRevision();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final State getState() {
/* 244 */     return this.state;
/*     */   }
/*     */   
/*     */   final void setState(State state) {
/* 248 */     this.state = state;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getStartLevel() {
/* 253 */     checkValid();
/* 254 */     return this.startlevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setStartLevel(int startLevel) {
/* 259 */     this.revisions.getContainer().setStartLevel(this, startLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isPersistentlyStarted() {
/* 264 */     checkValid();
/* 265 */     return this.settings.contains(Settings.AUTO_START);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isActivationPolicyUsed() {
/* 270 */     checkValid();
/* 271 */     return this.settings.contains(Settings.USE_ACTIVATION_POLICY);
/*     */   }
/*     */   
/*     */   final void storeStartLevel(int newStartLevel) {
/* 275 */     this.startlevel = newStartLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getLastModified() {
/* 286 */     return this.lastModified;
/*     */   }
/*     */   
/*     */   final void setlastModified(long lastModified) {
/* 290 */     this.lastModified = lastModified;
/*     */   }
/*     */   
/* 293 */   private static final EnumSet<ModuleContainerAdaptor.ModuleEvent> VALID_RESOLVED_TRANSITION = EnumSet.of(ModuleContainerAdaptor.ModuleEvent.STARTED);
/* 294 */   private static final EnumSet<ModuleContainerAdaptor.ModuleEvent> VALID_STOPPED_TRANSITION = EnumSet.of(ModuleContainerAdaptor.ModuleEvent.UPDATED, ModuleContainerAdaptor.ModuleEvent.UNRESOLVED, ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void lockStateChange(ModuleContainerAdaptor.ModuleEvent transitionEvent) throws BundleException {
/* 306 */     boolean previousInterruption = Thread.interrupted();
/* 307 */     boolean invalid = false; try {
/*     */       Throwable cause;
/* 309 */       boolean acquired = this.stateChangeLock.tryLock(this.revisions.getContainer().getModuleLockTimeout(), TimeUnit.SECONDS);
/* 310 */       Set<ModuleContainerAdaptor.ModuleEvent> currentTransition = Collections.emptySet();
/* 311 */       if (acquired) {
/* 312 */         boolean isValidTransition = true;
/* 313 */         switch (transitionEvent) {
/*     */ 
/*     */           
/*     */           case STARTED:
/*     */           case UNINSTALLED:
/*     */           case UNRESOLVED:
/*     */           case UPDATED:
/* 320 */             isValidTransition = this.stateTransitionEvents.isEmpty();
/*     */             break;
/*     */           case RESOLVED:
/* 323 */             isValidTransition = VALID_RESOLVED_TRANSITION.containsAll(this.stateTransitionEvents);
/*     */             break;
/*     */           case STOPPED:
/* 326 */             isValidTransition = VALID_STOPPED_TRANSITION.containsAll(this.stateTransitionEvents);
/*     */             break;
/*     */           default:
/* 329 */             isValidTransition = false;
/*     */             break;
/*     */         } 
/* 332 */         if (!isValidTransition) {
/* 333 */           currentTransition = EnumSet.copyOf(this.stateTransitionEvents);
/* 334 */           invalid = true;
/* 335 */           this.stateChangeLock.unlock();
/*     */         } else {
/* 337 */           this.stateTransitionEvents.add(transitionEvent);
/*     */           return;
/*     */         } 
/*     */       } else {
/* 341 */         currentTransition = EnumSet.copyOf(this.stateTransitionEvents);
/*     */       } 
/*     */       
/* 344 */       if (invalid) {
/* 345 */         cause = new IllegalStateException(NLS.bind(Msg.Module_LockStateError, transitionEvent, currentTransition));
/*     */       } else {
/* 347 */         cause = (new TimeoutException(NLS.bind(Msg.Module_LockTimeout, Long.valueOf(this.revisions.getContainer().getModuleLockTimeout())))).initCause((Throwable)new ThreadInfoReport(this.stateChangeLock.toString()));
/*     */       } 
/* 349 */       String exceptonInfo = String.valueOf(toString()) + ' ' + transitionEvent + ' ' + currentTransition;
/* 350 */       throw new BundleException(String.valueOf(Msg.Module_LockError) + exceptonInfo, 7, cause);
/* 351 */     } catch (InterruptedException e) {
/* 352 */       Thread.currentThread().interrupt();
/* 353 */       throw new BundleException(String.valueOf(Msg.Module_LockError) + toString() + ' ' + transitionEvent, 7, e);
/*     */     } finally {
/* 355 */       if (previousInterruption) {
/* 356 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unlockStateChange(ModuleContainerAdaptor.ModuleEvent transitionEvent) {
/* 366 */     if (this.stateChangeLock.getHoldCount() == 0 || !this.stateTransitionEvents.contains(transitionEvent))
/* 367 */       throw new IllegalMonitorStateException("Current thread does not hold the state change lock for: " + transitionEvent); 
/* 368 */     this.stateTransitionEvents.remove(transitionEvent);
/* 369 */     this.stateChangeLock.unlock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean holdsTransitionEventLock(ModuleContainerAdaptor.ModuleEvent transitionEvent) {
/* 378 */     return (this.stateChangeLock.getHoldCount() > 0 && this.stateTransitionEvents.contains(transitionEvent));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Thread getStateChangeOwner() {
/* 387 */     return this.stateChangeLock.getOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(StartOptions... options) throws BundleException {
/*     */     ModuleContainerAdaptor.ModuleEvent event;
/*     */     ResolutionReport resolutionReport;
/* 396 */     ModuleContainer container = getContainer();
/* 397 */     long startTime = 0L;
/* 398 */     if (container.DEBUG_BUNDLE_START_TIME) {
/* 399 */       startTime = System.nanoTime();
/*     */     }
/* 401 */     container.checkAdminPermission(getBundle(), "execute");
/* 402 */     if (options == null) {
/* 403 */       options = new StartOptions[0];
/*     */     }
/*     */     
/* 406 */     if (StartOptions.LAZY_TRIGGER.isContained(options)) {
/* 407 */       setTrigger();
/* 408 */       if (this.stateChangeLock.getHoldCount() > 0 && this.stateTransitionEvents.contains(ModuleContainerAdaptor.ModuleEvent.STARTED)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 413 */     BundleException startError = null;
/* 414 */     boolean lockedStarted = false;
/*     */ 
/*     */     
/* 417 */     this.inStart.incrementAndGet();
/*     */     
/* 419 */     try { lockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/* 420 */       lockedStarted = true;
/* 421 */       checkValid();
/* 422 */       if (StartOptions.TRANSIENT_IF_AUTO_START.isContained(options) && !this.settings.contains(Settings.AUTO_START)) {
/*     */         return;
/*     */       }
/*     */       
/* 426 */       checkFragment();
/* 427 */       persistStartOptions(options);
/* 428 */       if (getStartLevel() > container.getStartLevel()) {
/* 429 */         if (StartOptions.TRANSIENT.isContained(options))
/*     */         {
/* 431 */           throw new BundleException(String.valueOf(Msg.Module_Transient_StartError) + ' ' + this, 
/* 432 */               10);
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 437 */       if (State.ACTIVE.equals(getState()))
/*     */       {
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 477 */       if (lockedStarted) {
/* 478 */         unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*     */       }
/* 480 */       this.inStart.decrementAndGet(); }  if (lockedStarted) unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);  this.inStart.decrementAndGet();
/*     */ 
/*     */     
/* 483 */     if (event != null) {
/* 484 */       if (!EnumSet.<ModuleContainerAdaptor.ModuleEvent>of(ModuleContainerAdaptor.ModuleEvent.STARTED, ModuleContainerAdaptor.ModuleEvent.LAZY_ACTIVATION, ModuleContainerAdaptor.ModuleEvent.STOPPED).contains(event))
/* 485 */         throw new IllegalStateException("Wrong event type: " + event); 
/* 486 */       publishEvent(event);
/*     */       
/* 488 */       if (container.DEBUG_BUNDLE_START_TIME) {
/* 489 */         Debug.println(String.valueOf(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime)) + " ms for total start time event " + event + " - " + this);
/*     */       }
/*     */     } 
/*     */     
/* 493 */     if (resolutionReport != null) {
/* 494 */       throw resolutionReport;
/*     */     }
/*     */   }
/*     */   
/*     */   final void publishEvent(ModuleContainerAdaptor.ModuleEvent type) {
/* 499 */     this.revisions.getContainer().getAdaptor().publishModuleEvent(type, this, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(StopOptions... options) throws BundleException {
/*     */     ModuleContainerAdaptor.ModuleEvent event;
/* 508 */     this.revisions.getContainer().checkAdminPermission(getBundle(), "execute");
/* 509 */     if (options == null) {
/* 510 */       options = new StopOptions[0];
/*     */     }
/* 512 */     BundleException stopError = null;
/* 513 */     lockStateChange(ModuleContainerAdaptor.ModuleEvent.STOPPED);
/*     */     try {
/* 515 */       checkValid();
/* 516 */       checkFragment();
/* 517 */       persistStopOptions(options);
/* 518 */       if (!ACTIVE_SET.contains(getState()))
/*     */         return; 
/*     */       try {
/* 521 */         event = doStop();
/* 522 */       } catch (BundleException e) {
/* 523 */         stopError = e;
/*     */         
/* 525 */         event = ModuleContainerAdaptor.ModuleEvent.STOPPED;
/*     */       } 
/*     */     } finally {
/* 528 */       unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STOPPED);
/*     */     } 
/*     */     
/* 531 */     if (event != null) {
/* 532 */       if (!ModuleContainerAdaptor.ModuleEvent.STOPPED.equals(event))
/* 533 */         throw new IllegalStateException("Wrong event type: " + event); 
/* 534 */       publishEvent(event);
/*     */     } 
/* 536 */     if (stopError != null)
/* 537 */       throw stopError; 
/*     */   }
/*     */   
/*     */   private void checkFragment() throws BundleException {
/* 541 */     ModuleRevision current = getCurrentRevision();
/* 542 */     if ((current.getTypes() & 0x1) != 0) {
/* 543 */       throw new BundleException(String.valueOf(Msg.Module_Fragment_InvalidOperation) + ' ' + this, 
/* 544 */           2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final int compareTo(Module o) {
/* 550 */     int slcomp = this.startlevel - o.startlevel;
/* 551 */     if (slcomp != 0) {
/* 552 */       return slcomp;
/*     */     }
/* 554 */     long idcomp = getId().longValue() - o.getId().longValue();
/* 555 */     return (idcomp < 0L) ? -1 : ((idcomp > 0L) ? 1 : 0);
/*     */   }
/*     */   
/*     */   final void checkValid() {
/* 559 */     if (getState().equals(State.UNINSTALLED))
/* 560 */       throw new IllegalStateException(String.valueOf(Msg.Module_UninstalledError) + ' ' + this); 
/*     */   }
/*     */   
/*     */   private ModuleContainerAdaptor.ModuleEvent doStart(StartOptions... options) throws BundleException {
/* 564 */     boolean isLazyTrigger = StartOptions.LAZY_TRIGGER.isContained(options);
/* 565 */     if (isLazyTrigger) {
/* 566 */       if (!State.LAZY_STARTING.equals(getState())) {
/*     */         
/* 568 */         setState(State.LAZY_STARTING);
/*     */         
/* 570 */         unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*     */         try {
/* 572 */           publishEvent(ModuleContainerAdaptor.ModuleEvent.LAZY_ACTIVATION);
/*     */         } finally {
/* 574 */           lockStateChange(ModuleContainerAdaptor.ModuleEvent.STARTED);
/*     */         } 
/* 576 */         if (State.ACTIVE.equals(getState()))
/*     */         {
/* 578 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 582 */       if ((getContainer()).DEBUG_MONITOR_LAZY) {
/* 583 */         Debug.printStackTrace(new Exception("Module is being lazy activated: " + this));
/*     */       }
/*     */     }
/* 586 */     else if (isLazyActivate(options) && !isTriggerSet()) {
/* 587 */       if (State.LAZY_STARTING.equals(getState()))
/*     */       {
/* 589 */         return null;
/*     */       }
/*     */       
/* 592 */       setState(State.LAZY_STARTING);
/* 593 */       return ModuleContainerAdaptor.ModuleEvent.LAZY_ACTIVATION;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 598 */     if (!State.STARTING.equals(getState())) {
/*     */ 
/*     */       
/* 601 */       setState(State.STARTING);
/* 602 */       publishEvent(ModuleContainerAdaptor.ModuleEvent.STARTING);
/*     */     } 
/*     */     try {
/* 605 */       startWorker();
/* 606 */       setState(State.ACTIVE);
/* 607 */       return ModuleContainerAdaptor.ModuleEvent.STARTED;
/* 608 */     } catch (Throwable t) {
/*     */       
/* 610 */       setState(State.STOPPING);
/* 611 */       publishEvent(ModuleContainerAdaptor.ModuleEvent.STOPPING);
/* 612 */       if (t instanceof BundleException)
/* 613 */         throw (BundleException)t; 
/* 614 */       throw new BundleException(String.valueOf(Msg.Module_StartError) + ' ' + this, 5, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setTrigger() {
/* 619 */     ModuleLoader loader = getCurrentLoader();
/* 620 */     if (loader != null) {
/* 621 */       loader.getAndSetTrigger();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isTriggerSet() {
/* 626 */     ModuleLoader loader = getCurrentLoader();
/* 627 */     return (loader == null) ? false : loader.isTriggerSet();
/*     */   }
/*     */   
/*     */   private ModuleLoader getCurrentLoader() {
/* 631 */     ModuleRevision current = getCurrentRevision();
/* 632 */     if (current == null) {
/* 633 */       return null;
/*     */     }
/* 635 */     ModuleWiring wiring = current.getWiring();
/* 636 */     if (wiring == null) {
/* 637 */       return null;
/*     */     }
/*     */     try {
/* 640 */       return wiring.getModuleLoader();
/* 641 */     } catch (UnsupportedOperationException unsupportedOperationException) {
/*     */       
/* 643 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startWorker() throws BundleException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModuleContainerAdaptor.ModuleEvent doStop() throws BundleException {
/* 657 */     setState(State.STOPPING);
/* 658 */     publishEvent(ModuleContainerAdaptor.ModuleEvent.STOPPING);
/*     */     try {
/* 660 */       stopWorker();
/* 661 */       return ModuleContainerAdaptor.ModuleEvent.STOPPED;
/* 662 */     } catch (Throwable t) {
/* 663 */       if (t instanceof BundleException)
/* 664 */         throw (BundleException)t; 
/* 665 */       throw new BundleException(String.valueOf(Msg.Module_StopError) + ' ' + this, 5, t);
/*     */     } finally {
/*     */       
/* 668 */       setState(State.RESOLVED);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopWorker() throws BundleException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 683 */     return getCurrentRevision() + " [id=" + this.id + "]";
/*     */   }
/*     */   
/*     */   private void persistStartOptions(StartOptions... options) {
/* 687 */     if (StartOptions.TRANSIENT.isContained(options) || StartOptions.TRANSIENT_RESUME.isContained(options) || StartOptions.LAZY_TRIGGER.isContained(options)) {
/*     */       return;
/*     */     }
/*     */     
/* 691 */     if (StartOptions.USE_ACTIVATION_POLICY.isContained(options)) {
/* 692 */       this.settings.add(Settings.USE_ACTIVATION_POLICY);
/*     */     } else {
/* 694 */       this.settings.remove(Settings.USE_ACTIVATION_POLICY);
/*     */     } 
/* 696 */     this.settings.add(Settings.AUTO_START);
/* 697 */     (this.revisions.getContainer()).moduleDatabase.persistSettings(this.settings, this);
/*     */   }
/*     */   
/*     */   private void persistStopOptions(StopOptions... options) {
/* 701 */     if (StopOptions.TRANSIENT.isContained(options))
/*     */       return; 
/* 703 */     this.settings.remove(Settings.USE_ACTIVATION_POLICY);
/* 704 */     this.settings.remove(Settings.AUTO_START);
/* 705 */     (this.revisions.getContainer()).moduleDatabase.persistSettings(this.settings, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParallelActivation(boolean parallelActivation) {
/* 715 */     if (parallelActivation) {
/* 716 */       this.settings.add(Settings.PARALLEL_ACTIVATION);
/*     */     } else {
/* 718 */       this.settings.remove(Settings.PARALLEL_ACTIVATION);
/*     */     } 
/* 720 */     (this.revisions.getContainer()).moduleDatabase.persistSettings(this.settings, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParallelActivated() {
/* 730 */     return this.settings.contains(Settings.PARALLEL_ACTIVATION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isLazyActivate(StartOptions... options) {
/* 741 */     if (StartOptions.TRANSIENT.isContained(options)) {
/* 742 */       if (!StartOptions.USE_ACTIVATION_POLICY.isContained(options)) {
/* 743 */         return false;
/*     */       }
/* 745 */     } else if (!this.settings.contains(Settings.USE_ACTIVATION_POLICY)) {
/* 746 */       return false;
/*     */     } 
/* 748 */     return hasLazyActivatePolicy();
/*     */   }
/*     */   
/*     */   final boolean hasLazyActivatePolicy() {
/* 752 */     ModuleRevision current = getCurrentRevision();
/* 753 */     return (current == null) ? false : current.hasLazyActivatePolicy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean inStart() {
/* 762 */     return (this.inStart.get() > 0);
/*     */   }
/*     */   
/*     */   protected abstract void cleanup(ModuleRevision paramModuleRevision);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */