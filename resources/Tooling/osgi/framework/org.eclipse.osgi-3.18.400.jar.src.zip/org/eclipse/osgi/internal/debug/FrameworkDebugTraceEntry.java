/*     */ package org.eclipse.osgi.internal.debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkDebugTraceEntry
/*     */ {
/*     */   public static final String DEFAULT_OPTION_PATH = "/debug";
/*     */   
/*     */   public FrameworkDebugTraceEntry(String bundleSymbolicName, String optionPath, String message, String traceClass) {
/*  82 */     this(bundleSymbolicName, optionPath, message, null, traceClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private final String threadName = Thread.currentThread().getName(); private final long timestamp; public FrameworkDebugTraceEntry(String bundleSymbolicName, String optionPath, String message, Throwable error, String traceClass) {
/* 101 */     if (optionPath == null) {
/* 102 */       this.optionPath = "/debug";
/*     */     } else {
/* 104 */       this.optionPath = optionPath;
/*     */     } 
/* 106 */     this.timestamp = System.currentTimeMillis();
/* 107 */     this.bundleSymbolicName = bundleSymbolicName;
/* 108 */     this.message = message;
/* 109 */     this.throwable = error;
/*     */     
/* 111 */     String determineClassName = null;
/* 112 */     String determineMethodName = null;
/* 113 */     int determineLineNumber = 0;
/*     */     
/* 115 */     StackTraceElement[] stackElements = (new Exception()).getStackTrace();
/* 116 */     int i = 0;
/* 117 */     while (i < stackElements.length) {
/* 118 */       String fullClassName = stackElements[i].getClassName();
/* 119 */       if (!fullClassName.equals(Thread.class.getName()) && !fullClassName.equals(FrameworkDebugTraceEntry.class.getName()) && !fullClassName.equals(EclipseDebugTrace.class.getName()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 128 */         if (traceClass == null || !fullClassName.equals(traceClass)) {
/* 129 */           determineClassName = stackElements[i].getClassName();
/* 130 */           determineMethodName = stackElements[i].getMethodName();
/* 131 */           determineLineNumber = stackElements[i].getLineNumber();
/*     */           break;
/*     */         } 
/*     */       }
/* 135 */       i++;
/*     */     } 
/*     */     
/* 138 */     this.className = determineClassName;
/* 139 */     this.methodName = determineMethodName;
/* 140 */     this.lineNumber = determineLineNumber;
/*     */   }
/*     */   private final String optionPath;
/*     */   private final String bundleSymbolicName;
/*     */   private final String className;
/*     */   private final String methodName;
/*     */   private final int lineNumber;
/*     */   private String message;
/*     */   private final Throwable throwable;
/*     */   
/*     */   public String toString() {
/* 151 */     StringBuilder buffer = new StringBuilder(this.threadName);
/* 152 */     buffer.append(" ");
/* 153 */     buffer.append(this.timestamp);
/* 154 */     buffer.append(" ");
/* 155 */     buffer.append(this.bundleSymbolicName);
/* 156 */     buffer.append(" ");
/* 157 */     buffer.append(this.optionPath);
/* 158 */     buffer.append(" ");
/* 159 */     buffer.append(this.className);
/* 160 */     buffer.append(" ");
/* 161 */     buffer.append(this.methodName);
/* 162 */     buffer.append(" ");
/* 163 */     buffer.append(this.lineNumber);
/* 164 */     if (this.message != null) {
/* 165 */       buffer.append(": ");
/* 166 */       buffer.append(this.message);
/*     */     } 
/* 168 */     if (this.throwable != null) {
/* 169 */       buffer.append(this.throwable);
/*     */     }
/* 171 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getThreadName() {
/* 181 */     return this.threadName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getTimestamp() {
/* 191 */     return this.timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getBundleSymbolicName() {
/* 201 */     return this.bundleSymbolicName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMessage() {
/* 211 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Throwable getThrowable() {
/* 221 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getClassName() {
/* 231 */     return this.className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMethodName() {
/* 241 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getOptionPath() {
/* 259 */     return this.optionPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLineNumber() {
/* 269 */     return this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessage(String newMessage) {
/* 278 */     this.message = newMessage;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\debug\FrameworkDebugTraceEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */