/*     */ package org.eclipse.osgi.internal.debug;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.location.LocationHelper;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.eclipse.osgi.service.debug.DebugTrace;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkDebugOptions
/*     */   implements DebugOptions, ServiceTrackerCustomizer<DebugOptionsListener, DebugOptionsListener>
/*     */ {
/*     */   private static final String OSGI_DEBUG = "osgi.debug";
/*     */   private static final String OSGI_DEBUG_VERBOSE = "osgi.debug.verbose";
/*     */   public static final String PROP_TRACEFILE = "osgi.tracefile";
/*     */   private static final String OPTIONS = ".options";
/*  54 */   private static final Object writeLock = new Object();
/*     */   
/*  56 */   private final Object lock = new Object();
/*     */   
/*  58 */   private Properties options = null;
/*     */   
/*  60 */   private Properties disabledOptions = null;
/*     */   
/*  62 */   protected final Map<String, DebugTrace> debugTraceCache = new HashMap<>();
/*     */   
/*  64 */   protected File outFile = null;
/*     */   
/*     */   protected boolean verboseDebug = true;
/*     */   
/*     */   private boolean newSession = true;
/*     */   private final EquinoxConfiguration environmentInfo;
/*     */   private volatile BundleContext context;
/*     */   private volatile ServiceTracker<DebugOptionsListener, DebugOptionsListener> listenerTracker;
/*     */   
/*     */   public FrameworkDebugOptions(EquinoxConfiguration environmentInfo) {
/*  74 */     this.environmentInfo = environmentInfo;
/*     */     
/*  76 */     this.verboseDebug = Boolean.valueOf(environmentInfo.getConfiguration("osgi.debug.verbose", Boolean.TRUE.toString())).booleanValue();
/*     */ 
/*     */ 
/*     */     
/*  80 */     String debugOptionsFilename = environmentInfo.getConfiguration("osgi.debug");
/*  81 */     if (debugOptionsFilename == null)
/*     */       return; 
/*  83 */     this.options = new Properties();
/*     */     
/*  85 */     if (debugOptionsFilename.length() == 0) {
/*     */ 
/*     */ 
/*     */       
/*  89 */       String userDir = System.getProperty("user.dir").replace(File.separatorChar, '/');
/*  90 */       if (!userDir.endsWith("/"))
/*  91 */         userDir = String.valueOf(userDir) + "/"; 
/*  92 */       debugOptionsFilename = (new File(userDir, ".options")).toString();
/*     */     } 
/*  94 */     URL optionsFile = LocationHelper.buildURL(debugOptionsFilename, false);
/*  95 */     if (optionsFile == null) {
/*  96 */       System.out.println("Unable to construct URL for options file: " + debugOptionsFilename);
/*     */       return;
/*     */     } 
/*  99 */     System.out.print("Debug options:\n    " + optionsFile.toExternalForm());
/*     */     try {
/* 101 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 105 */     catch (FileNotFoundException fileNotFoundException) {
/* 106 */       System.out.println(" not found");
/* 107 */     } catch (IOException e) {
/* 108 */       System.out.println(" did not parse");
/* 109 */       e.printStackTrace(System.out);
/*     */     } 
/*     */     
/* 112 */     for (Object key : this.options.keySet()) {
/* 113 */       this.options.put(key, ((String)this.options.get(key)).trim());
/*     */     }
/*     */   }
/*     */   
/*     */   public void start(BundleContext bc) {
/* 118 */     this.context = bc;
/* 119 */     this.listenerTracker = new ServiceTracker(bc, DebugOptionsListener.class.getName(), this);
/* 120 */     this.listenerTracker.open();
/*     */   }
/*     */   
/*     */   public void stop(BundleContext bc) {
/* 124 */     this.listenerTracker.close();
/* 125 */     this.listenerTracker = null;
/* 126 */     this.context = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanOption(String option, boolean defaultValue) {
/* 134 */     String optionValue = getOption(option);
/* 135 */     return (optionValue != null) ? optionValue.equalsIgnoreCase("true") : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOption(String option) {
/* 143 */     return getOption(option, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOption(String option, String defaultValue) {
/* 151 */     synchronized (this.lock) {
/* 152 */       if (this.options != null) {
/* 153 */         return this.options.getProperty(option, defaultValue);
/*     */       }
/*     */     } 
/* 156 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerOption(String option, int defaultValue) {
/* 164 */     String value = getOption(option);
/*     */     try {
/* 166 */       return (value == null) ? defaultValue : Integer.parseInt(value);
/* 167 */     } catch (NumberFormatException numberFormatException) {
/* 168 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getOptions() {
/* 175 */     Map<String, String> snapShot = new HashMap<>();
/* 176 */     synchronized (this.lock) {
/* 177 */       if (this.options != null) {
/* 178 */         snapShot.putAll(this.options);
/* 179 */       } else if (this.disabledOptions != null) {
/* 180 */         snapShot.putAll(this.disabledOptions);
/*     */       } 
/* 182 */     }  return snapShot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getAllOptions() {
/* 191 */     String[] optionsArray = null;
/* 192 */     synchronized (this.lock) {
/* 193 */       if (this.options != null) {
/* 194 */         optionsArray = new String[this.options.size()];
/* 195 */         int i = 0;
/* 196 */         for (Map.Entry<Object, Object> entry : this.options.entrySet()) {
/* 197 */           optionsArray[i] = String.valueOf(entry.getKey()) + "=" + (String)entry.getValue();
/* 198 */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 202 */     if (optionsArray == null) {
/* 203 */       optionsArray = new String[1];
/*     */     }
/* 205 */     return optionsArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeOption(String option) {
/* 214 */     if (option == null)
/*     */       return; 
/* 216 */     String fireChangedEvent = null;
/* 217 */     synchronized (this.lock) {
/* 218 */       if (this.options != null && this.options.remove(option) != null) {
/* 219 */         fireChangedEvent = getSymbolicName(option);
/*     */       }
/*     */     } 
/*     */     
/* 223 */     if (fireChangedEvent != null) {
/* 224 */       optionsChanged(fireChangedEvent);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOption(String option, String value) {
/* 235 */     if (option == null || value == null) {
/* 236 */       throw new IllegalArgumentException("The option and value must not be null.");
/*     */     }
/* 238 */     String fireChangedEvent = null;
/* 239 */     value = (value != null) ? value.trim() : null;
/* 240 */     synchronized (this.lock) {
/* 241 */       if (this.options != null) {
/*     */         
/* 243 */         String currentValue = this.options.getProperty(option);
/*     */         
/* 245 */         if (currentValue != null) {
/* 246 */           if (!currentValue.equals(value)) {
/* 247 */             fireChangedEvent = getSymbolicName(option);
/*     */           }
/*     */         }
/* 250 */         else if (value != null) {
/* 251 */           fireChangedEvent = getSymbolicName(option);
/*     */         } 
/*     */         
/* 254 */         if (fireChangedEvent != null) {
/* 255 */           this.options.put(option, value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 260 */     if (fireChangedEvent != null) {
/* 261 */       optionsChanged(fireChangedEvent);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getSymbolicName(String option) {
/* 266 */     int firstSlashIndex = option.indexOf('/');
/* 267 */     if (firstSlashIndex > 0)
/* 268 */       return option.substring(0, firstSlashIndex); 
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Map<String, String> ops) {
/* 275 */     if (ops == null)
/* 276 */       throw new IllegalArgumentException("The options must not be null."); 
/* 277 */     Properties newOptions = new Properties();
/* 278 */     for (Map.Entry<String, String> entry : ops.entrySet()) {
/* 279 */       if (!(entry.getKey() instanceof String) || !(entry.getValue() instanceof String))
/* 280 */         throw new IllegalArgumentException("Option keys and values must be of type String: " + (String)entry.getKey() + "=" + (String)entry.getValue()); 
/* 281 */       newOptions.put(entry.getKey(), ((String)entry.getValue()).trim());
/*     */     } 
/* 283 */     Set<String> fireChangesTo = null;
/*     */     
/* 285 */     synchronized (this.lock) {
/* 286 */       if (this.options == null) {
/* 287 */         this.disabledOptions = newOptions;
/*     */         
/*     */         return;
/*     */       } 
/* 291 */       fireChangesTo = new HashSet<>();
/*     */       
/* 293 */       for (Object object : this.options.keySet()) {
/* 294 */         String key = (String)object;
/* 295 */         if (!newOptions.containsKey(key)) {
/* 296 */           String symbolicName = getSymbolicName(key);
/* 297 */           if (symbolicName != null) {
/* 298 */             fireChangesTo.add(symbolicName);
/*     */           }
/*     */         } 
/*     */       } 
/* 302 */       for (Map.Entry<Object, Object> entry : newOptions.entrySet()) {
/* 303 */         String existingValue = (String)this.options.get(entry.getKey());
/* 304 */         if (!entry.getValue().equals(existingValue)) {
/* 305 */           String symbolicName = getSymbolicName((String)entry.getKey());
/* 306 */           if (symbolicName != null) {
/* 307 */             fireChangesTo.add(symbolicName);
/*     */           }
/*     */         } 
/*     */       } 
/* 311 */       this.options = newOptions;
/*     */     } 
/* 313 */     if (fireChangesTo != null) {
/* 314 */       for (String string : fireChangesTo) {
/* 315 */         optionsChanged(string);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 324 */     synchronized (this.lock) {
/* 325 */       return (this.options != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebugEnabled(boolean enabled) {
/* 335 */     boolean fireChangedEvent = false;
/* 336 */     synchronized (this.lock) {
/* 337 */       if (enabled) {
/* 338 */         if (this.options != null) {
/*     */           return;
/*     */         }
/* 341 */         this.newSession = true;
/*     */ 
/*     */         
/* 344 */         this.environmentInfo.setConfiguration("osgi.debug", "");
/* 345 */         if (this.disabledOptions != null) {
/* 346 */           this.options = this.disabledOptions;
/* 347 */           this.disabledOptions = null;
/*     */           
/* 349 */           fireChangedEvent = true;
/*     */         } else {
/* 351 */           this.options = new Properties();
/*     */         } 
/*     */       } else {
/* 354 */         if (this.options == null) {
/*     */           return;
/*     */         }
/* 357 */         this.environmentInfo.clearConfiguration("osgi.debug");
/* 358 */         if (this.options.size() > 0) {
/*     */           
/* 360 */           this.disabledOptions = this.options;
/*     */           
/* 362 */           fireChangedEvent = true;
/*     */         } 
/* 364 */         this.options = null;
/*     */       } 
/*     */     } 
/* 367 */     if (fireChangedEvent)
/*     */     {
/* 369 */       optionsChanged("*");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DebugTrace newDebugTrace(String bundleSymbolicName) {
/* 380 */     return newDebugTrace(bundleSymbolicName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DebugTrace newDebugTrace(String bundleSymbolicName, Class<?> traceEntryClass) {
/* 390 */     DebugTrace debugTrace = null;
/* 391 */     synchronized (this.debugTraceCache) {
/* 392 */       debugTrace = this.debugTraceCache.get(bundleSymbolicName);
/* 393 */       if (debugTrace == null) {
/* 394 */         debugTrace = new EclipseDebugTrace(bundleSymbolicName, this, traceEntryClass);
/* 395 */         this.debugTraceCache.put(bundleSymbolicName, debugTrace);
/*     */       } 
/*     */     } 
/* 398 */     return debugTrace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final File getFile() {
/* 408 */     return this.outFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFile(File traceFile) {
/* 417 */     synchronized (this.lock) {
/* 418 */       this.outFile = traceFile;
/* 419 */       if (this.outFile != null) {
/* 420 */         this.environmentInfo.setConfiguration("osgi.tracefile", this.outFile.getAbsolutePath());
/*     */       } else {
/* 422 */         this.environmentInfo.clearConfiguration("osgi.tracefile");
/*     */       } 
/* 424 */       this.newSession = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean newSession() {
/* 429 */     synchronized (this.lock) {
/* 430 */       if (this.newSession) {
/* 431 */         this.newSession = false;
/* 432 */         return true;
/*     */       } 
/* 434 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   Object getWriteLock() {
/* 439 */     return writeLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isVerbose() {
/* 448 */     return this.verboseDebug;
/*     */   }
/*     */   
/*     */   EquinoxConfiguration getConfiguration() {
/* 452 */     return this.environmentInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 460 */     synchronized (this.lock) {
/* 461 */       this.verboseDebug = verbose;
/*     */       
/* 463 */       this.newSession = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void optionsChanged(String bundleSymbolicName) {
/* 473 */     BundleContext bc = this.context;
/* 474 */     if (bc == null) {
/*     */       return;
/*     */     }
/*     */     
/* 478 */     ServiceReference[] listenerRefs = null;
/*     */     try {
/* 480 */       listenerRefs = bc.getServiceReferences(DebugOptionsListener.class.getName(), "(listener.symbolic.name=" + bundleSymbolicName + ")");
/* 481 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/* 484 */     if (listenerRefs == null)
/*     */       return;  byte b; int i; ServiceReference[] arrayOfServiceReference1;
/* 486 */     for (i = (arrayOfServiceReference1 = listenerRefs).length, b = 0; b < i; ) { ServiceReference<?> listenerRef = arrayOfServiceReference1[b];
/* 487 */       DebugOptionsListener service = (DebugOptionsListener)bc.getService(listenerRef);
/* 488 */       if (service != null)
/*     */         
/*     */         try {
/* 491 */           service.optionsChanged(this);
/* 492 */         } catch (Throwable throwable) {
/*     */         
/*     */         } finally {
/* 495 */           bc.ungetService(listenerRef);
/*     */         }  
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public DebugOptionsListener addingService(ServiceReference<DebugOptionsListener> reference) {
/* 502 */     DebugOptionsListener listener = (DebugOptionsListener)this.context.getService(reference);
/* 503 */     listener.optionsChanged(this);
/* 504 */     return listener;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<DebugOptionsListener> reference, DebugOptionsListener service) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<DebugOptionsListener> reference, DebugOptionsListener service) {
/* 514 */     this.context.ungetService(reference);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\debug\FrameworkDebugOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */