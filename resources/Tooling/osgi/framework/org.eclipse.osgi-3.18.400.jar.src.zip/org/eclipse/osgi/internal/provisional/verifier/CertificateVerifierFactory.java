package org.eclipse.osgi.internal.provisional.verifier;

import java.io.File;
import java.io.IOException;
import org.osgi.framework.Bundle;

public interface CertificateVerifierFactory {
  CertificateVerifier getVerifier(File paramFile) throws IOException;
  
  CertificateVerifier getVerifier(Bundle paramBundle) throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\verifier\CertificateVerifierFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */