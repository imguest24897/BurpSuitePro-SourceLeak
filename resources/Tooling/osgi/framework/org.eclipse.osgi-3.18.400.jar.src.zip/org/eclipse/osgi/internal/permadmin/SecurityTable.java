/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.osgi.service.condpermadmin.Condition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityTable
/*     */   extends PermissionCollection
/*     */ {
/*     */   private static final long serialVersionUID = -1800193310096318060L;
/*     */   static final int GRANTED = 1;
/*     */   static final int DENIED = 2;
/*     */   static final int ABSTAIN = 4;
/*     */   static final int POSTPONED = 8;
/*     */   private static final int MUTABLE = 22;
/*     */   private final SecurityRow[] rows;
/*     */   private final SecurityAdmin securityAdmin;
/*  38 */   private final transient Map<EvaluationCacheKey, Integer> evaluationCache = new ConcurrentHashMap<>(10000);
/*     */   
/*     */   public SecurityTable(SecurityAdmin securityAdmin, SecurityRow[] rows) {
/*  41 */     if (rows == null)
/*  42 */       throw new NullPointerException("rows cannot be null!!"); 
/*  43 */     this.rows = rows;
/*  44 */     this.securityAdmin = securityAdmin;
/*     */   }
/*     */   
/*     */   boolean isEmpty() {
/*  48 */     return (this.rows.length == 0);
/*     */   }
/*     */   
/*     */   int evaluate(BundlePermissions bundlePermissions, Permission permission) {
/*  52 */     if (bundlePermissions == null) {
/*  53 */       return 4;
/*     */     }
/*  55 */     if (this.evaluationCache.size() > 10000) {
/*  56 */       clearEvaluationCache();
/*     */     }
/*  58 */     EvaluationCacheKey evaluationCacheKey = new EvaluationCacheKey(bundlePermissions, permission);
/*  59 */     if (isEmpty()) {
/*  60 */       this.evaluationCache.put(evaluationCacheKey, Integer.valueOf(4));
/*  61 */       return 4;
/*     */     } 
/*     */ 
/*     */     
/*  65 */     Integer result = this.evaluationCache.get(evaluationCacheKey);
/*  66 */     boolean hasMutable = false;
/*  67 */     if (result != null) {
/*  68 */       hasMutable = ((result.intValue() & 0x16) == 22);
/*  69 */       if (!hasMutable) {
/*  70 */         return result.intValue();
/*     */       }
/*     */     } 
/*     */     
/*  74 */     boolean postponed = false;
/*  75 */     SecurityRow.Decision[] results = new SecurityRow.Decision[this.rows.length];
/*  76 */     int immediateDecisionIdx = -1;
/*     */     
/*  78 */     for (int i = 0; i < this.rows.length && immediateDecisionIdx == -1; i++) {
/*  79 */       if (result == null)
/*     */       {
/*  81 */         hasMutable |= checkMutable(bundlePermissions, evaluationCacheKey, this.rows[i]);
/*     */       }
/*     */       try {
/*  84 */         results[i] = this.rows[i].evaluate(bundlePermissions, permission);
/*  85 */       } catch (Exception exception) {
/*     */         
/*  87 */         results[i] = SecurityRow.DECISION_ABSTAIN;
/*     */       } 
/*  89 */       if (((results[i]).decision & 0x4) != 4)
/*     */       {
/*  91 */         if (((results[i]).decision & 0x8) == 8) {
/*     */           
/*  93 */           postponed = true;
/*     */         } else {
/*     */           
/*  96 */           if (!postponed) {
/*     */             
/*  98 */             if (!hasMutable) {
/*  99 */               this.evaluationCache.put(evaluationCacheKey, Integer.valueOf((results[i]).decision));
/*     */             }
/* 101 */             return (results[i]).decision;
/*     */           } 
/*     */ 
/*     */           
/* 105 */           immediateDecisionIdx = i;
/*     */         }  } 
/* 107 */     }  Integer immediateDecision = handlePostponedConditions(evaluationCacheKey, hasMutable, postponed, results, immediateDecisionIdx);
/* 108 */     if (immediateDecision != null)
/* 109 */       return immediateDecision.intValue(); 
/* 110 */     int finalDecision = postponed ? 8 : 4;
/* 111 */     if (!hasMutable && (finalDecision & 0x8) != 8) {
/* 112 */       this.evaluationCache.put(evaluationCacheKey, Integer.valueOf(finalDecision));
/*     */     }
/* 114 */     return finalDecision;
/*     */   }
/*     */   
/*     */   private boolean checkMutable(BundlePermissions bundlePermissions, EvaluationCacheKey evaluationCacheKey, SecurityRow row) {
/* 118 */     Condition[] conditions = row.getConditions(bundlePermissions);
/* 119 */     if (conditions != null) {
/* 120 */       byte b; int i; Condition[] arrayOfCondition; for (i = (arrayOfCondition = conditions).length, b = 0; b < i; ) { Condition condition = arrayOfCondition[b];
/* 121 */         if (condition != null && condition.isMutable()) {
/* 122 */           this.evaluationCache.put(evaluationCacheKey, Integer.valueOf(22));
/* 123 */           return true;
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   private Integer handlePostponedConditions(EvaluationCacheKey evaluationCacheKey, boolean hasMutable, boolean postponed, SecurityRow.Decision[] results, int immediateDecisionIdx) {
/* 131 */     if (postponed) {
/* 132 */       int immediateDecision = (immediateDecisionIdx < 0) ? 2 : (results[immediateDecisionIdx]).decision;
/*     */ 
/*     */       
/* 135 */       boolean allSameDecision = true;
/* 136 */       int i = (immediateDecisionIdx < 0) ? (results.length - 1) : (immediateDecisionIdx - 1);
/* 137 */       for (; i >= 0 && allSameDecision; i--) {
/* 138 */         if (((results[i]).decision & 0x8) == 8)
/* 139 */           if (((results[i]).decision & immediateDecision) == 0) {
/* 140 */             allSameDecision = false;
/*     */           } else {
/* 142 */             results[i] = SecurityRow.DECISION_ABSTAIN;
/*     */           }  
/*     */       } 
/* 145 */       if (allSameDecision) {
/* 146 */         if (!hasMutable) {
/* 147 */           this.evaluationCache.put(evaluationCacheKey, Integer.valueOf(immediateDecision));
/*     */         }
/* 149 */         return Integer.valueOf(immediateDecision);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 154 */       EquinoxSecurityManager equinoxManager = this.securityAdmin.getSupportedSecurityManager();
/* 155 */       if (equinoxManager == null) {
/*     */ 
/*     */         
/* 158 */         if (!hasMutable) {
/* 159 */           this.evaluationCache.put(evaluationCacheKey, Integer.valueOf(4));
/*     */         }
/* 161 */         return Integer.valueOf(4);
/*     */       } 
/* 163 */       equinoxManager.addConditionsForDomain(results);
/*     */     } 
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   void clearEvaluationCache() {
/* 169 */     this.evaluationCache.clear();
/*     */   }
/*     */   
/*     */   SecurityRow getRow(int i) {
/* 173 */     return (this.rows.length <= i || i < 0) ? null : this.rows[i]; } SecurityRow getRow(String name) {
/*     */     byte b;
/*     */     int i;
/*     */     SecurityRow[] arrayOfSecurityRow;
/* 177 */     for (i = (arrayOfSecurityRow = this.rows).length, b = 0; b < i; ) { SecurityRow row = arrayOfSecurityRow[b];
/* 178 */       if (name.equals(row.getName()))
/* 179 */         return row; 
/*     */       b++; }
/*     */     
/* 182 */     return null;
/*     */   }
/*     */   
/*     */   SecurityRow[] getRows() {
/* 186 */     return this.rows;
/*     */   }
/*     */   
/*     */   String[] getEncodedRows() {
/* 190 */     String[] encoded = new String[this.rows.length];
/* 191 */     for (int i = 0; i < this.rows.length; i++)
/* 192 */       encoded[i] = this.rows[i].getEncoded(); 
/* 193 */     return encoded;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Permission permission) {
/* 198 */     throw new SecurityException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<Permission> elements() {
/* 203 */     return Collections.emptyEnumeration();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean implies(Permission permission) {
/* 208 */     return ((evaluate(null, permission) & 0x1) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\SecurityTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */