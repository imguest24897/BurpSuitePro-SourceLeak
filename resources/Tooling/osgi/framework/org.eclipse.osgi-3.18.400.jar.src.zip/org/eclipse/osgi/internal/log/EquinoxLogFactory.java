/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.FrameworkEvent;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EquinoxLogFactory
/*     */   implements ServiceFactory<FrameworkLog>
/*     */ {
/*     */   final EquinoxLogWriter defaultWriter;
/*     */   final LogServiceManager logManager;
/*     */   
/*     */   public EquinoxLogFactory(EquinoxLogWriter defaultWriter, LogServiceManager logManager) {
/*  34 */     this.defaultWriter = defaultWriter;
/*  35 */     this.logManager = logManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public FrameworkLog getService(Bundle bundle, ServiceRegistration<FrameworkLog> registration) {
/*  40 */     return createFrameworkLog(bundle, this.defaultWriter);
/*     */   }
/*     */   
/*     */   FrameworkLog createFrameworkLog(Bundle bundle, EquinoxLogWriter eclipseWriter) {
/*  44 */     final EquinoxLogWriter logWriter = (eclipseWriter == null) ? this.defaultWriter : eclipseWriter;
/*  45 */     final Logger logger = (bundle == null) ? this.logManager.getSystemBundleLog().getLogger(eclipseWriter.getLoggerName()) : this.logManager.getSystemBundleLog().getLogger(bundle, logWriter.getLoggerName());
/*  46 */     return new FrameworkLog()
/*     */       {
/*     */         public void setWriter(Writer newWriter, boolean append)
/*     */         {
/*  50 */           logWriter.setWriter(newWriter, append);
/*     */         }
/*     */ 
/*     */         
/*     */         public void setFile(File newFile, boolean append) throws IOException {
/*  55 */           logWriter.setFile(newFile, append);
/*     */         }
/*     */ 
/*     */         
/*     */         public void setConsoleLog(boolean consoleLog) {
/*  60 */           logWriter.setConsoleLog(consoleLog);
/*     */         }
/*     */ 
/*     */         
/*     */         public void log(FrameworkLogEntry logEntry) {
/*  65 */           logger.log(logEntry, EquinoxLogFactory.convertLevel(logEntry), logEntry.getMessage(), logEntry.getThrowable());
/*     */         }
/*     */         
/*     */         public void log(FrameworkEvent frameworkEvent) {
/*     */           int severity;
/*  70 */           Bundle b = frameworkEvent.getBundle();
/*  71 */           Throwable t = frameworkEvent.getThrowable();
/*  72 */           String entry = (b.getSymbolicName() == null) ? b.getLocation() : b.getSymbolicName();
/*     */           
/*  74 */           switch (frameworkEvent.getType()) {
/*     */             case 32:
/*  76 */               severity = 1;
/*     */               break;
/*     */             case 2:
/*  79 */               severity = 4;
/*     */               break;
/*     */             case 16:
/*  82 */               severity = 2;
/*     */               break;
/*     */             default:
/*  85 */               severity = 0; break;
/*     */           } 
/*  87 */           FrameworkLogEntry logEntry = new FrameworkLogEntry(entry, severity, 0, "", 0, t, null);
/*  88 */           log(logEntry);
/*     */         }
/*     */ 
/*     */         
/*     */         public File getFile() {
/*  93 */           return logWriter.getFile();
/*     */         }
/*     */ 
/*     */         
/*     */         public void close() {
/*  98 */           logWriter.close();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetService(Bundle bundle, ServiceRegistration<FrameworkLog> registration, FrameworkLog service) {}
/*     */ 
/*     */ 
/*     */   
/*     */   static int convertLevel(FrameworkLogEntry logEntry) {
/* 110 */     switch (logEntry.getSeverity()) {
/*     */       case 4:
/* 112 */         return 1;
/*     */       case 2:
/* 114 */         return 2;
/*     */       case 1:
/* 116 */         return 3;
/*     */       case 0:
/* 118 */         return 4;
/*     */     } 
/*     */     
/* 121 */     return 32;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\EquinoxLogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */