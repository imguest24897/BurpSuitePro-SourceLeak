package org.eclipse.osgi.internal.hookregistry;

import org.osgi.framework.BundleActivator;

public interface ActivatorHookFactory {
  BundleActivator createActivator();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hookregistry\ActivatorHookFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */