/*    */ package org.eclipse.osgi.internal.signedcontent;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignedContentMessages
/*    */   extends NLS
/*    */ {
/*    */   public static String Default_Trust_Keystore_Load_Failed;
/*    */   public static String Default_Trust_Read_Only;
/*    */   public static String Default_Trust_Cert_Not_Found;
/*    */   public static String Default_Trust_Existing_Cert;
/*    */   public static String Default_Trust_Existing_Alias;
/*    */   private static final String BUNDLE_NAME = "org.eclipse.osgi.internal.signedcontent.SignedContentMessages";
/*    */   
/*    */   static {
/* 30 */     NLS.initializeMessages("org.eclipse.osgi.internal.signedcontent.SignedContentMessages", SignedContentMessages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\SignedContentMessages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */