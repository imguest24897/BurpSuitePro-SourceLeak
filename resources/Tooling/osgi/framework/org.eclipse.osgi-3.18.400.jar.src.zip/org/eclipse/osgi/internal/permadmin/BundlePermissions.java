/*    */ package org.eclipse.osgi.internal.permadmin;
/*    */ 
/*    */ import java.security.Permission;
/*    */ import java.security.PermissionCollection;
/*    */ import java.security.Permissions;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.PackagePermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BundlePermissions
/*    */   extends PermissionCollection
/*    */ {
/*    */   private static final long serialVersionUID = -5443618108312606612L;
/*    */   private final Bundle bundle;
/*    */   private final SecurityAdmin securityAdmin;
/*    */   private final PermissionInfoCollection impliedPermissions;
/*    */   private final PermissionInfoCollection restrictedPermissions;
/*    */   private final Permissions wovenPermissions;
/*    */   
/*    */   public BundlePermissions(Bundle bundle, SecurityAdmin securityAdmin, PermissionInfoCollection impliedPermissions, PermissionInfoCollection restrictedPermissions) {
/* 34 */     this.bundle = bundle;
/* 35 */     this.securityAdmin = securityAdmin;
/* 36 */     this.impliedPermissions = impliedPermissions;
/* 37 */     this.restrictedPermissions = restrictedPermissions;
/* 38 */     this.wovenPermissions = new Permissions();
/* 39 */     setReadOnly();
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(Permission permission) {
/* 44 */     throw new SecurityException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addWovenPermission(PackagePermission permission) {
/* 58 */     if (!permission.getActions().equals("import"))
/* 59 */       throw new SecurityException(); 
/* 60 */     this.wovenPermissions.add((Permission)permission);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Enumeration<Permission> elements() {
/* 67 */     return Collections.emptyEnumeration();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean implies(Permission permission) {
/* 73 */     if (this.impliedPermissions != null && this.impliedPermissions.implies(permission)) {
/* 74 */       return true;
/*    */     }
/*    */     
/* 77 */     if (this.wovenPermissions.implies(permission)) {
/* 78 */       return true;
/*    */     }
/*    */     
/* 81 */     if (this.restrictedPermissions != null && !this.restrictedPermissions.implies(permission)) {
/* 82 */       return false;
/*    */     }
/* 84 */     return this.securityAdmin.checkPermission(permission, this);
/*    */   }
/*    */   
/*    */   public Bundle getBundle() {
/* 88 */     return this.bundle;
/*    */   }
/*    */   
/*    */   public void clearPermissionCache() {
/* 92 */     if (this.impliedPermissions != null)
/* 93 */       this.impliedPermissions.clearPermissionCache(); 
/* 94 */     if (this.restrictedPermissions != null)
/* 95 */       this.restrictedPermissions.clearPermissionCache(); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\BundlePermissions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */