/*     */ package org.eclipse.osgi.framework.eventmgr;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventManager
/*     */ {
/*     */   static final boolean DEBUG = false;
/*     */   private EventThread<?, ?, ?> thread;
/*     */   private boolean closed;
/*     */   protected final String threadName;
/*     */   protected final ThreadGroup threadGroup;
/*     */   
/*     */   public EventManager() {
/* 135 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventManager(String threadName) {
/* 146 */     this(threadName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventManager(String threadName, ThreadGroup threadGroup) {
/* 160 */     this.thread = null;
/* 161 */     this.closed = false;
/* 162 */     this.threadName = threadName;
/* 163 */     this.threadGroup = threadGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/* 175 */     if (this.closed) {
/*     */       return;
/*     */     }
/* 178 */     if (this.thread != null) {
/* 179 */       this.thread.close();
/* 180 */       this.thread = null;
/*     */     } 
/* 182 */     this.closed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized <K, V, E> EventThread<K, V, E> getEventThread() {
/* 193 */     if (this.closed) {
/* 194 */       throw new IllegalStateException();
/*     */     }
/* 196 */     if (this.thread == null) {
/*     */       
/* 198 */       this.thread = AccessController.<EventThread<?, ?, ?>>doPrivileged(new PrivilegedAction<EventThread<K, V, E>>()
/*     */           {
/*     */             public EventManager.EventThread<K, V, E> run() {
/* 201 */               EventManager.EventThread<K, V, E> t = new EventManager.EventThread<>(EventManager.this.threadGroup, EventManager.this.threadName);
/* 202 */               return t;
/*     */             }
/*     */           });
/*     */       
/* 206 */       this.thread.start();
/*     */     } 
/*     */ 
/*     */     
/* 210 */     return (EventThread)this.thread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <K, V, E> void dispatchEvent(Set<Map.Entry<K, V>> listeners, EventDispatcher<K, V, E> dispatcher, int eventAction, E eventObject) {
/* 229 */     for (Map.Entry<K, V> listener : listeners) {
/* 230 */       K eventListener = listener.getKey();
/* 231 */       V listenerObject = listener.getValue();
/*     */       
/*     */       try {
/* 234 */         dispatcher.dispatchEvent(eventListener, listenerObject, eventAction, eventObject);
/* 235 */       } catch (Throwable throwable) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class EventThread<K, V, E>
/*     */     extends Thread
/*     */   {
/*     */     private static int nextThreadNumber;
/*     */ 
/*     */ 
/*     */     
/*     */     private Queued<K, V, E> head;
/*     */ 
/*     */     
/*     */     private Queued<K, V, E> tail;
/*     */ 
/*     */     
/*     */     private volatile boolean running;
/*     */ 
/*     */ 
/*     */     
/*     */     private static class Queued<K, V, E>
/*     */     {
/*     */       final Set<Map.Entry<K, V>> listeners;
/*     */ 
/*     */       
/*     */       final EventDispatcher<K, V, E> dispatcher;
/*     */ 
/*     */       
/*     */       final int action;
/*     */ 
/*     */       
/*     */       final E object;
/*     */ 
/*     */       
/*     */       Queued<K, V, E> next;
/*     */ 
/*     */ 
/*     */       
/*     */       Queued(Set<Map.Entry<K, V>> l, EventDispatcher<K, V, E> d, int a, E o) {
/* 278 */         this.listeners = l;
/* 279 */         this.dispatcher = d;
/* 280 */         this.action = a;
/* 281 */         this.object = o;
/* 282 */         this.next = null;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EventThread(ThreadGroup threadGroup, String threadName) {
/* 298 */       super(threadGroup, (threadName == null) ? getNextName() : threadName);
/* 299 */       this.running = true;
/* 300 */       this.head = null;
/* 301 */       this.tail = null;
/*     */       
/* 303 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     private static synchronized String getNextName() {
/* 307 */       return "EventManagerThread-" + nextThreadNumber++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EventThread(String threadName) {
/* 315 */       this((ThreadGroup)null, threadName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EventThread() {
/* 322 */       this((ThreadGroup)null, (String)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void close() {
/* 329 */       this.running = false;
/* 330 */       interrupt();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/*     */         while (true) {
/* 341 */           Queued<K, V, E> item = getNextEvent();
/* 342 */           if (item == null) {
/*     */             return;
/*     */           }
/* 345 */           EventManager.dispatchEvent(item.listeners, item.dispatcher, item.action, item.object);
/*     */ 
/*     */ 
/*     */           
/* 349 */           item = null;
/*     */         } 
/* 351 */       } catch (RuntimeException|Error e) {
/*     */ 
/*     */ 
/*     */         
/* 355 */         throw e;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     synchronized void postEvent(Set<Map.Entry<K, V>> l, EventDispatcher<K, V, E> d, int a, E o) {
/* 370 */       if (!isAlive()) {
/* 371 */         throw new IllegalStateException();
/*     */       }
/*     */       
/* 374 */       Queued<K, V, E> item = new Queued<>(l, d, a, o);
/*     */       
/* 376 */       if (this.head == null) {
/*     */         
/* 378 */         this.head = item;
/* 379 */         this.tail = item;
/*     */       } else {
/*     */         
/* 382 */         this.tail.next = item;
/* 383 */         this.tail = item;
/*     */       } 
/*     */       
/* 386 */       notify();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private synchronized Queued<K, V, E> getNextEvent() {
/* 398 */       while (this.running && this.head == null) {
/*     */         try {
/* 400 */           wait();
/* 401 */         } catch (InterruptedException interruptedException) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 406 */       if (!this.running) {
/* 407 */         return null;
/*     */       }
/*     */       
/* 410 */       Queued<K, V, E> item = this.head;
/* 411 */       this.head = item.next;
/* 412 */       if (this.head == null) {
/* 413 */         this.tail = null;
/*     */       }
/*     */       
/* 416 */       return item;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\eventmgr\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */