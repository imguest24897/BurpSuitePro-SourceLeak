package org.eclipse.osgi.service.debug;

public interface DebugTrace {
  void trace(String paramString1, String paramString2);
  
  void trace(String paramString1, String paramString2, Throwable paramThrowable);
  
  void traceDumpStack(String paramString);
  
  void traceEntry(String paramString);
  
  void traceEntry(String paramString, Object paramObject);
  
  void traceEntry(String paramString, Object[] paramArrayOfObject);
  
  void traceExit(String paramString);
  
  void traceExit(String paramString, Object paramObject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\debug\DebugTrace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */