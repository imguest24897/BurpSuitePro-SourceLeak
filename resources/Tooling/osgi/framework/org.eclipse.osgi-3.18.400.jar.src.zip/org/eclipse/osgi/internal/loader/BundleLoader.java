/*      */ package org.eclipse.osgi.internal.loader;
/*      */ 
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleCapability;
/*      */ import org.eclipse.osgi.container.ModuleLoader;
/*      */ import org.eclipse.osgi.container.ModuleRequirement;
/*      */ import org.eclipse.osgi.container.ModuleRevision;
/*      */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*      */ import org.eclipse.osgi.container.ModuleWire;
/*      */ import org.eclipse.osgi.container.ModuleWiring;
/*      */ import org.eclipse.osgi.container.builders.OSGiManifestBuilderFactory;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*      */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*      */ import org.eclipse.osgi.internal.loader.buddy.PolicyHandler;
/*      */ import org.eclipse.osgi.internal.loader.sources.MultiSourcePackage;
/*      */ import org.eclipse.osgi.internal.loader.sources.NullPackageSource;
/*      */ import org.eclipse.osgi.internal.loader.sources.PackageSource;
/*      */ import org.eclipse.osgi.internal.loader.sources.SingleSourcePackage;
/*      */ import org.eclipse.osgi.storage.BundleInfo;
/*      */ import org.eclipse.osgi.util.ManifestElement;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BundleLoader
/*      */   extends ModuleLoader
/*      */ {
/*      */   public static final String DEFAULT_PACKAGE = ".";
/*      */   public static final String JAVA_PACKAGE = "java.";
/*      */   
/*   77 */   public static final ClassContext CLASS_CONTEXT = AccessController.<ClassContext>doPrivileged(new PrivilegedAction<ClassContext>()
/*      */       {
/*      */         public BundleLoader.ClassContext run() {
/*   80 */           return new BundleLoader.ClassContext();
/*      */         }
/*      */       });
/*   83 */   public static final ClassLoader FW_CLASSLOADER = getClassLoader(EquinoxContainer.class);
/*      */   
/*      */   private static final int PRE_CLASS = 1;
/*      */   
/*      */   private static final int POST_CLASS = 2;
/*      */   private static final int PRE_RESOURCE = 3;
/*      */   private static final int POST_RESOURCE = 4;
/*      */   private static final int PRE_RESOURCES = 5;
/*      */   private static final int POST_RESOURCES = 6;
/*   92 */   private static final Pattern PACKAGENAME_FILTER = Pattern.compile("\\(osgi.wiring.package\\s*=\\s*([^)]+)\\)");
/*      */   
/*      */   private final ModuleWiring wiring;
/*      */   
/*      */   private final EquinoxContainer container;
/*      */   
/*      */   private final Debug debug;
/*      */   
/*      */   private final PolicyHandler policy;
/*      */   
/*      */   private final Collection<String> exportedPackages;
/*      */   private final BundleLoaderSources exportSources;
/*  104 */   private final Map<String, PackageSource> requiredSources = new HashMap<>();
/*      */   
/*  106 */   private final Map<String, PackageSource> importedSources = new HashMap<>();
/*      */ 
/*      */   
/*      */   private final List<ModuleWire> requiredBundleWires;
/*      */ 
/*      */   
/*      */   private boolean importsInitialized = false;
/*      */   
/*      */   private boolean dynamicAllPackages;
/*      */   
/*      */   private String[] dynamicImportPackageStems;
/*      */   
/*      */   private String[] dynamicImportPackages;
/*      */   
/*  120 */   private final Object classLoaderCreatedMonitor = new Object();
/*      */   
/*      */   private ModuleClassLoader classLoaderCreated;
/*      */   private volatile ModuleClassLoader classloader;
/*      */   private final ClassLoader parent;
/*  125 */   private final AtomicBoolean triggerClassLoaded = new AtomicBoolean(false);
/*  126 */   private final AtomicBoolean firstUseOfInvalidLoader = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String getPackageName(String name) {
/*  137 */     if (name != null) {
/*  138 */       int index = name.lastIndexOf('.');
/*  139 */       if (index > 0)
/*  140 */         return name.substring(0, index); 
/*      */     } 
/*  142 */     return ".";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String getResourcePackageName(String name) {
/*  154 */     if (name != null) {
/*      */       
/*  156 */       int begin = (name.length() > 1 && name.charAt(0) == '/') ? 1 : 0;
/*  157 */       int end = name.lastIndexOf('/');
/*  158 */       if (end > begin)
/*  159 */         return name.substring(begin, end).replace('/', '.'); 
/*      */     } 
/*  161 */     return ".";
/*      */   }
/*      */   
/*      */   public BundleLoader(ModuleWiring wiring, EquinoxContainer container, ClassLoader parent) {
/*  165 */     this.wiring = wiring;
/*  166 */     this.container = container;
/*  167 */     this.debug = container.getConfiguration().getDebug();
/*  168 */     this.parent = parent;
/*      */ 
/*      */     
/*  171 */     this.exportSources = new BundleLoaderSources(this);
/*  172 */     List<ModuleCapability> exports = wiring.getModuleCapabilities("osgi.wiring.package");
/*  173 */     exports = (exports == null) ? Collections.<ModuleCapability>emptyList() : exports;
/*  174 */     this.exportedPackages = Collections.synchronizedCollection((exports.size() > 10) ? new HashSet<>(exports.size()) : new ArrayList<>(exports.size()));
/*  175 */     initializeExports(exports, this.exportSources, this.exportedPackages);
/*      */ 
/*      */     
/*  178 */     addDynamicImportPackage(wiring.getModuleRequirements("osgi.wiring.package"));
/*      */ 
/*      */     
/*  181 */     List<ModuleWire> currentRequireBundleWires = wiring.getRequiredModuleWires("osgi.wiring.bundle");
/*  182 */     this.requiredBundleWires = (currentRequireBundleWires == null || currentRequireBundleWires.isEmpty()) ? Collections.<ModuleWire>emptyList() : Collections.<ModuleWire>unmodifiableList(currentRequireBundleWires);
/*      */ 
/*      */     
/*  185 */     List<ModuleCapability> moduleDatas = wiring.getRevision().getModuleCapabilities("equinox.module.data");
/*      */     
/*  187 */     List<String> buddyList = moduleDatas.isEmpty() ? null : (List<String>)((ModuleCapability)moduleDatas.get(0)).getAttributes().get("buddy.policy");
/*  188 */     if (buddyList != null) {  } else {  }  this.policy = 
/*      */ 
/*      */       
/*  191 */       null;
/*  192 */     if (this.policy != null) {
/*  193 */       Module systemModule = container.getStorage().getModuleContainer().getModule(0L);
/*  194 */       Bundle systemBundle = systemModule.getBundle();
/*  195 */       this.policy.open(systemBundle.getBundleContext());
/*      */     } 
/*      */   }
/*      */   
/*      */   public ModuleWiring getWiring() {
/*  200 */     return this.wiring;
/*      */   }
/*      */   
/*      */   public void addFragmentExports(List<ModuleCapability> exports) {
/*  204 */     initializeExports(exports, this.exportSources, this.exportedPackages);
/*      */   }
/*      */   
/*      */   private static void initializeExports(List<ModuleCapability> exports, BundleLoaderSources sources, Collection<String> exportNames) {
/*  208 */     if (exports != null) {
/*  209 */       for (ModuleCapability export : exports) {
/*  210 */         String name = (String)export.getAttributes().get("osgi.wiring.package");
/*  211 */         if (sources.forceSourceCreation(export) && 
/*  212 */           !exportNames.contains(name))
/*      */         {
/*      */ 
/*      */           
/*  216 */           sources.createPackageSource(export, true);
/*      */         }
/*      */         
/*  219 */         exportNames.add(name);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   final PackageSource createExportPackageSource(ModuleWire importWire, Collection<BundleLoader> visited) {
/*  225 */     String name = (String)importWire.getCapability().getAttributes().get("osgi.wiring.package");
/*  226 */     BundleLoader providerLoader = getProviderLoader(importWire);
/*  227 */     if (providerLoader == null) {
/*  228 */       return createMultiSource(name, new PackageSource[0]);
/*      */     }
/*  230 */     PackageSource requiredSource = providerLoader.findRequiredSource(name, visited);
/*  231 */     PackageSource exportSource = providerLoader.exportSources.createPackageSource(importWire.getCapability(), false);
/*  232 */     if (requiredSource == null)
/*  233 */       return exportSource; 
/*  234 */     return createMultiSource(name, new PackageSource[] { requiredSource, exportSource });
/*      */   }
/*      */   
/*      */   private static PackageSource createMultiSource(String packageName, PackageSource[] sources) {
/*  238 */     if (sources.length == 1)
/*  239 */       return sources[0]; 
/*  240 */     List<SingleSourcePackage> sourceList = new ArrayList<>(sources.length); byte b; int i; PackageSource[] arrayOfPackageSource;
/*  241 */     for (i = (arrayOfPackageSource = sources).length, b = 0; b < i; ) { PackageSource source = arrayOfPackageSource[b];
/*  242 */       SingleSourcePackage[] innerSources = source.getSuppliers(); byte b1; int j; SingleSourcePackage[] arrayOfSingleSourcePackage1;
/*  243 */       for (j = (arrayOfSingleSourcePackage1 = innerSources).length, b1 = 0; b1 < j; ) { SingleSourcePackage innerSource = arrayOfSingleSourcePackage1[b1];
/*  244 */         if (!sourceList.contains(innerSource))
/*  245 */           sourceList.add(innerSource);  b1++; }
/*      */       
/*      */       b++; }
/*      */     
/*  249 */     return (PackageSource)new MultiSourcePackage(packageName, sourceList.<SingleSourcePackage>toArray(new SingleSourcePackage[sourceList.size()]));
/*      */   }
/*      */   
/*      */   public ModuleClassLoader getModuleClassLoader() {
/*  253 */     ModuleClassLoader result = this.classloader;
/*  254 */     if (result != null) {
/*  255 */       return result;
/*      */     }
/*      */ 
/*      */     
/*  259 */     final List<ClassLoaderHook> hooks = this.container.getConfiguration().getHookRegistry().getClassLoaderHooks();
/*  260 */     final BundleInfo.Generation generation = (BundleInfo.Generation)this.wiring.getRevision().getRevisionInfo();
/*  261 */     if (System.getSecurityManager() == null) {
/*  262 */       result = createClassLoaderPrivledged(this.parent, generation.getBundleInfo().getStorage().getConfiguration(), this, generation, hooks);
/*      */     } else {
/*  264 */       final ClassLoader cl = this.parent;
/*  265 */       result = AccessController.<ModuleClassLoader>doPrivileged(new PrivilegedAction<ModuleClassLoader>()
/*      */           {
/*      */             public ModuleClassLoader run() {
/*  268 */               return BundleLoader.createClassLoaderPrivledged(cl, generation.getBundleInfo().getStorage().getConfiguration(), BundleLoader.this, generation, hooks);
/*      */             }
/*      */           });
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  276 */     synchronized (this.classLoaderCreatedMonitor) {
/*  277 */       if (this.classLoaderCreated == null) {
/*      */ 
/*      */         
/*  280 */         this.classLoaderCreated = result;
/*      */         
/*  282 */         final ModuleClassLoader cl = result;
/*      */         
/*  284 */         AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run() {
/*  287 */                 for (ClassLoaderHook hook : hooks) {
/*  288 */                   hook.classLoaderCreated(cl);
/*      */                 }
/*  290 */                 return null;
/*      */               }
/*      */             });
/*      */ 
/*      */         
/*  295 */         this.classloader = this.classLoaderCreated;
/*      */       }
/*      */       else {
/*      */         
/*  299 */         result = this.classLoaderCreated;
/*  300 */         if (this.debug.DEBUG_LOADER) {
/*  301 */           Debug.println("BundleLoader[" + this + "].getModuleClassLoader() - created duplicate classloader");
/*      */         }
/*      */       } 
/*      */     } 
/*  305 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void loadFragments(Collection<ModuleRevision> fragments) {
/*  310 */     addFragmentExports(this.wiring.getModuleCapabilities("osgi.wiring.package"));
/*  311 */     loadClassLoaderFragments(fragments);
/*  312 */     clearManifestLocalizationCache();
/*      */   }
/*      */   
/*      */   protected void clearManifestLocalizationCache() {
/*  316 */     BundleInfo.Generation hostGen = (BundleInfo.Generation)this.wiring.getRevision().getRevisionInfo();
/*  317 */     hostGen.clearManifestCache();
/*  318 */     List<ModuleWire> hostWires = this.wiring.getProvidedModuleWires("osgi.wiring.host");
/*      */     
/*  320 */     if (hostWires != null) {
/*  321 */       for (ModuleWire fragmentWire : hostWires) {
/*  322 */         BundleInfo.Generation fragGen = (BundleInfo.Generation)fragmentWire.getRequirer().getRevisionInfo();
/*  323 */         fragGen.clearManifestCache();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   void loadClassLoaderFragments(Collection<ModuleRevision> fragments) {
/*  329 */     ModuleClassLoader current = this.classloader;
/*  330 */     if (current != null) {
/*  331 */       current.loadFragments(fragments);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static ModuleClassLoader createClassLoaderPrivledged(ClassLoader parent, EquinoxConfiguration configuration, BundleLoader delegate, BundleInfo.Generation generation, List<ClassLoaderHook> hooks) {
/*  337 */     for (ClassLoaderHook hook : hooks) {
/*  338 */       ModuleClassLoader hookClassLoader = hook.createClassLoader(parent, configuration, delegate, generation);
/*  339 */       if (hookClassLoader != null)
/*      */       {
/*  341 */         return hookClassLoader;
/*      */       }
/*      */     } 
/*      */     
/*  345 */     return new EquinoxClassLoader(parent, configuration, delegate, generation);
/*      */   }
/*      */   
/*      */   public void close() {
/*  349 */     if (this.policy != null) {
/*  350 */       Module systemModule = this.container.getStorage().getModuleContainer().getModule(0L);
/*  351 */       BundleContext context = systemModule.getBundle().getBundleContext();
/*  352 */       if (context != null) {
/*  353 */         this.policy.close(context);
/*      */       }
/*      */     } 
/*  356 */     ModuleClassLoader current = this.classloader;
/*  357 */     if (current != null) {
/*  358 */       current.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected ClassLoader getClassLoader() {
/*  364 */     return getModuleClassLoader();
/*      */   }
/*      */   
/*      */   public ClassLoader getParentClassLoader() {
/*  368 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final URL getResource(String name) {
/*  381 */     return getModuleClassLoader().getResource(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findLocalClass(String name) throws ClassNotFoundException {
/*  391 */     long start = 0L;
/*  392 */     if (this.debug.DEBUG_LOADER) {
/*  393 */       Debug.println("BundleLoader[" + this + "].findLocalClass(" + name + ")");
/*  394 */       start = System.currentTimeMillis();
/*      */     } 
/*      */     try {
/*  397 */       Class<?> clazz = getModuleClassLoader().findLocalClass(name);
/*  398 */       if (this.debug.DEBUG_LOADER && clazz != null) {
/*  399 */         long time = System.currentTimeMillis() - start;
/*  400 */         Debug.println("BundleLoader[" + this + "] found local class " + name + " " + time + "ms");
/*      */       } 
/*  402 */       return clazz;
/*  403 */     } catch (ClassNotFoundException e) {
/*  404 */       if (e.getCause() instanceof BundleException)
/*      */       {
/*  406 */         throw e;
/*      */       }
/*  408 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClass(String name) throws ClassNotFoundException {
/*  416 */     return findClass0(name, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClassNoException(String name) {
/*      */     try {
/*  423 */       return findClass0(name, true, false);
/*  424 */     } catch (ClassNotFoundException classNotFoundException) {
/*      */ 
/*      */       
/*  427 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Class<?> findClassNoParentNoException(String name) {
/*      */     try {
/*  433 */       return findClass0(name, false, false);
/*  434 */     } catch (ClassNotFoundException classNotFoundException) {
/*      */ 
/*      */       
/*  437 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Class<?> findClass0(String name, boolean parentDelegation, boolean generateException) throws ClassNotFoundException {
/*  443 */     if (parentDelegation && this.parent != null && name.startsWith("java."))
/*      */     {
/*      */       
/*  446 */       return this.parent.loadClass(name);
/*      */     }
/*      */     
/*  449 */     if (this.debug.DEBUG_LOADER) {
/*  450 */       Debug.println("BundleLoader[" + this + "].findClass(" + name + ")");
/*      */     }
/*  452 */     String pkgName = getPackageName(name);
/*  453 */     boolean bootDelegation = false;
/*      */     
/*  455 */     if (parentDelegation && this.parent != null && this.container.isBootDelegationPackage(pkgName)) {
/*      */       
/*      */       try {
/*  458 */         return this.parent.loadClass(name);
/*  459 */       } catch (ClassNotFoundException classNotFoundException) {
/*      */         
/*  461 */         bootDelegation = true;
/*      */       } 
/*      */     }
/*  464 */     Class<?> result = null;
/*      */     try {
/*  466 */       result = searchHooks(name, 1);
/*  467 */     } catch (FileNotFoundException fileNotFoundException) {}
/*      */ 
/*      */     
/*  470 */     if (result != null) {
/*  471 */       return result;
/*      */     }
/*  473 */     PackageSource source = findImportedSource(pkgName, null);
/*  474 */     if (source != null) {
/*  475 */       if (this.debug.DEBUG_LOADER) {
/*  476 */         Debug.println("BundleLoader[" + this + "] loading from import package: " + source);
/*      */       }
/*      */       
/*  479 */       result = source.loadClass(name);
/*  480 */       if (result == null)
/*      */       {
/*      */         
/*  483 */         result = getModuleClassLoader().publicFindLoaded(name);
/*      */       }
/*  485 */       if (result != null)
/*  486 */         return result; 
/*  487 */       return generateException(name, generateException);
/*      */     } 
/*      */     
/*  490 */     source = findRequiredSource(pkgName, null);
/*  491 */     if (source != null) {
/*  492 */       if (this.debug.DEBUG_LOADER) {
/*  493 */         Debug.println("BundleLoader[" + this + "] loading from required bundle package: " + source);
/*      */       }
/*      */       
/*  496 */       result = source.loadClass(name);
/*      */     } 
/*      */     
/*  499 */     if (result == null)
/*  500 */       result = findLocalClass(name); 
/*  501 */     if (result != null) {
/*  502 */       return result;
/*      */     }
/*  504 */     if (source == null) {
/*  505 */       source = findDynamicSource(pkgName);
/*  506 */       if (source != null) {
/*  507 */         result = source.loadClass(name);
/*  508 */         if (result != null)
/*  509 */           return result; 
/*  510 */         return generateException(name, generateException);
/*      */       } 
/*      */     } 
/*      */     
/*  514 */     if (result == null) {
/*      */       try {
/*  516 */         result = searchHooks(name, 2);
/*  517 */       } catch (FileNotFoundException fileNotFoundException) {}
/*      */     }
/*      */ 
/*      */     
/*  521 */     if (result == null && this.policy != null)
/*  522 */       result = this.policy.doBuddyClassLoading(name); 
/*  523 */     if (result != null) {
/*  524 */       return result;
/*      */     }
/*      */     
/*  527 */     if (parentDelegation && this.parent != null && !bootDelegation && (
/*  528 */       (this.container.getConfiguration()).compatibilityBootDelegation || isRequestFromVM())) {
/*      */       
/*      */       try {
/*  531 */         return this.parent.loadClass(name);
/*  532 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     }
/*      */ 
/*      */     
/*  536 */     return generateException(name, generateException);
/*      */   }
/*      */   
/*      */   private Class<?> generateException(String name, boolean generate) throws ClassNotFoundException {
/*  540 */     if (generate) {
/*  541 */       ClassNotFoundException e = new ClassNotFoundException(String.valueOf(name) + " cannot be found by " + this);
/*  542 */       if (this.debug.DEBUG_LOADER) {
/*  543 */         Debug.println("BundleLoader[" + this + "].loadClass(" + name + ") failed.");
/*  544 */         Debug.printStackTrace(e);
/*      */       } 
/*  546 */       throw e;
/*      */     } 
/*  548 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private <E> E searchHooks(String name, int type) throws ClassNotFoundException, FileNotFoundException {
/*      */     Enumeration enumeration;
/*  554 */     List<ClassLoaderHook> loaderHooks = this.container.getConfiguration().getHookRegistry().getClassLoaderHooks();
/*  555 */     if (loaderHooks == null)
/*  556 */       return null; 
/*  557 */     E result = null;
/*  558 */     for (ClassLoaderHook hook : loaderHooks) {
/*  559 */       Class clazz; URL uRL; switch (type) {
/*      */         case 1:
/*  561 */           clazz = hook.preFindClass(name, getModuleClassLoader());
/*      */           break;
/*      */         case 2:
/*  564 */           clazz = hook.postFindClass(name, getModuleClassLoader());
/*      */           break;
/*      */         case 3:
/*  567 */           uRL = hook.preFindResource(name, getModuleClassLoader());
/*      */           break;
/*      */         case 4:
/*  570 */           uRL = hook.postFindResource(name, getModuleClassLoader());
/*      */           break;
/*      */         case 5:
/*  573 */           enumeration = hook.preFindResources(name, getModuleClassLoader());
/*      */           break;
/*      */         case 6:
/*  576 */           enumeration = hook.postFindResources(name, getModuleClassLoader());
/*      */           break;
/*      */       } 
/*  579 */       if (enumeration != null) {
/*  580 */         return (E)enumeration;
/*      */       }
/*      */     } 
/*  583 */     return (E)enumeration;
/*      */   }
/*      */   
/*      */   private boolean isRequestFromVM() {
/*  587 */     if (!(this.container.getConfiguration()).contextBootDelegation) {
/*  588 */       return false;
/*      */     }
/*  590 */     Class[] context = CLASS_CONTEXT.getClassContext();
/*  591 */     if (context == null || context.length < 2) {
/*  592 */       return false;
/*      */     }
/*  594 */     for (int i = 1; i < context.length; i++) {
/*  595 */       Class<?> clazz = context[i];
/*      */ 
/*      */ 
/*      */       
/*  599 */       if (clazz != BundleLoader.class && !ModuleClassLoader.class.isAssignableFrom(clazz) && clazz != ClassLoader.class && clazz != Class.class && !clazz.getName().equals("java.lang.J9VMInternals")) {
/*  600 */         if (Bundle.class.isAssignableFrom(clazz))
/*      */         {
/*  602 */           return false;
/*      */         }
/*      */         
/*  605 */         ClassLoader cl = getClassLoader(clazz);
/*      */         
/*  607 */         if (cl != FW_CLASSLOADER) {
/*      */           
/*  609 */           ClassLoader last = null;
/*  610 */           while (cl != null && cl != last) {
/*  611 */             last = cl;
/*  612 */             if (cl instanceof ModuleClassLoader) {
/*  613 */               return false;
/*      */             }
/*  615 */             cl = getClassLoader(cl.getClass());
/*      */           } 
/*      */ 
/*      */           
/*  619 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/*  623 */     return false;
/*      */   }
/*      */   
/*      */   private static ClassLoader getClassLoader(final Class<?> clazz) {
/*  627 */     if (System.getSecurityManager() == null)
/*  628 */       return clazz.getClassLoader(); 
/*  629 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/*  632 */             return clazz.getClassLoader();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL findResource(String name) {
/*  641 */     if (this.debug.DEBUG_LOADER)
/*  642 */       Debug.println("BundleLoader[" + this + "].findResource(" + name + ")"); 
/*  643 */     if (name.length() > 1 && name.charAt(0) == '/')
/*  644 */       name = name.substring(1); 
/*  645 */     String pkgName = getResourcePackageName(name);
/*  646 */     boolean bootDelegation = false;
/*      */ 
/*      */     
/*  649 */     if (this.parent != null) {
/*  650 */       if (pkgName.startsWith("java."))
/*      */       {
/*      */         
/*  653 */         return this.parent.getResource(name); } 
/*  654 */       if (this.container.isBootDelegationPackage(pkgName)) {
/*      */         
/*  656 */         URL uRL = this.parent.getResource(name);
/*  657 */         if (uRL != null)
/*  658 */           return uRL; 
/*  659 */         bootDelegation = true;
/*      */       } 
/*      */     } 
/*      */     
/*  663 */     URL result = null;
/*      */     try {
/*  665 */       result = searchHooks(name, 3);
/*  666 */     } catch (FileNotFoundException fileNotFoundException) {
/*  667 */       return null;
/*  668 */     } catch (ClassNotFoundException classNotFoundException) {}
/*      */ 
/*      */     
/*  671 */     if (result != null) {
/*  672 */       return result;
/*      */     }
/*  674 */     PackageSource source = findImportedSource(pkgName, null);
/*  675 */     if (source != null) {
/*  676 */       if (this.debug.DEBUG_LOADER) {
/*  677 */         Debug.println("BundleLoader[" + this + "] loading from import package: " + source);
/*      */       }
/*      */       
/*  680 */       return source.getResource(name);
/*      */     } 
/*      */     
/*  683 */     source = findRequiredSource(pkgName, null);
/*  684 */     if (source != null) {
/*  685 */       if (this.debug.DEBUG_LOADER) {
/*  686 */         Debug.println("BundleLoader[" + this + "] loading from required bundle package: " + source);
/*      */       }
/*      */       
/*  689 */       result = source.getResource(name);
/*      */     } 
/*      */     
/*  692 */     if (result == null)
/*  693 */       result = findLocalResource(name); 
/*  694 */     if (result != null) {
/*  695 */       return result;
/*      */     }
/*  697 */     if (source == null) {
/*  698 */       source = findDynamicSource(pkgName);
/*  699 */       if (source != null)
/*      */       {
/*  701 */         return source.getResource(name);
/*      */       }
/*      */     } 
/*  704 */     if (result == null) {
/*      */       try {
/*  706 */         result = searchHooks(name, 4);
/*  707 */       } catch (FileNotFoundException fileNotFoundException) {
/*  708 */         return null;
/*  709 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     }
/*      */ 
/*      */     
/*  713 */     if (result == null && this.policy != null)
/*  714 */       result = this.policy.doBuddyResourceLoading(name); 
/*  715 */     if (result != null) {
/*  716 */       return result;
/*      */     }
/*      */     
/*  719 */     if (this.parent != null && !bootDelegation && ((this.container.getConfiguration()).compatibilityBootDelegation || isRequestFromVM()))
/*      */     {
/*  721 */       return this.parent.getResource(name); } 
/*  722 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<URL> findResources(String name) throws IOException {
/*  729 */     if (this.debug.DEBUG_LOADER) {
/*  730 */       Debug.println("BundleLoader[" + this + "].findResources(" + name + ")");
/*      */     }
/*  732 */     if (name.length() > 1 && name.charAt(0) == '/')
/*  733 */       name = name.substring(1); 
/*  734 */     String pkgName = getResourcePackageName(name);
/*  735 */     Enumeration<URL> result = Collections.emptyEnumeration();
/*  736 */     boolean bootDelegation = false;
/*      */ 
/*      */     
/*  739 */     if (this.parent != null) {
/*  740 */       if (pkgName.startsWith("java."))
/*      */       {
/*      */         
/*  743 */         return this.parent.getResources(name); } 
/*  744 */       if (this.container.isBootDelegationPackage(pkgName)) {
/*      */         
/*  746 */         result = compoundEnumerations(result, this.parent.getResources(name));
/*  747 */         bootDelegation = true;
/*      */       } 
/*      */     } 
/*      */     try {
/*  751 */       Enumeration<URL> hookResources = searchHooks(name, 5);
/*  752 */       if (hookResources != null) {
/*  753 */         return compoundEnumerations(result, hookResources);
/*      */       }
/*  755 */     } catch (ClassNotFoundException classNotFoundException) {
/*      */     
/*  757 */     } catch (FileNotFoundException fileNotFoundException) {
/*  758 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  762 */     PackageSource source = findImportedSource(pkgName, null);
/*  763 */     if (source != null) {
/*  764 */       if (this.debug.DEBUG_LOADER) {
/*  765 */         Debug.println("BundleLoader[" + this + "] loading from import package: " + source);
/*      */       }
/*      */       
/*  768 */       return compoundEnumerations(result, source.getResources(name));
/*      */     } 
/*      */     
/*  771 */     source = findRequiredSource(pkgName, null);
/*  772 */     if (source != null) {
/*  773 */       if (this.debug.DEBUG_LOADER) {
/*  774 */         Debug.println("BundleLoader[" + this + "] loading from required bundle package: " + source);
/*      */       }
/*      */       
/*  777 */       result = compoundEnumerations(result, source.getResources(name));
/*      */     } 
/*      */ 
/*      */     
/*  781 */     Enumeration<URL> localResults = findLocalResources(name);
/*  782 */     result = compoundEnumerations(result, localResults);
/*      */     
/*  784 */     if (source == null && !result.hasMoreElements()) {
/*  785 */       source = findDynamicSource(pkgName);
/*  786 */       if (source != null)
/*  787 */         return compoundEnumerations(result, source.getResources(name)); 
/*      */     } 
/*  789 */     if (!result.hasMoreElements())
/*      */       try {
/*  791 */         Enumeration<URL> hookResources = searchHooks(name, 6);
/*  792 */         result = compoundEnumerations(result, hookResources);
/*  793 */       } catch (ClassNotFoundException classNotFoundException) {
/*      */       
/*  795 */       } catch (FileNotFoundException fileNotFoundException) {
/*  796 */         return null;
/*      */       }  
/*  798 */     if (this.policy != null) {
/*  799 */       Enumeration<URL> buddyResult = this.policy.doBuddyResourcesLoading(name);
/*  800 */       result = compoundEnumerations(result, buddyResult);
/*      */     } 
/*      */ 
/*      */     
/*  804 */     if (!result.hasMoreElements() && 
/*  805 */       this.parent != null && !bootDelegation && ((this.container.getConfiguration()).compatibilityBootDelegation || isRequestFromVM()))
/*      */     {
/*  807 */       return this.parent.getResources(name);
/*      */     }
/*  809 */     return result;
/*      */   }
/*      */   
/*      */   private boolean isSubPackage(String parentPackage, String subPackage) {
/*  813 */     String prefix = (parentPackage.length() == 0 || parentPackage.equals(".")) ? "" : (String.valueOf(parentPackage) + '.');
/*  814 */     return subPackage.startsWith(prefix);
/*      */   }
/*      */   
/*      */   protected Collection<String> listResources(String path, String filePattern, int options) {
/*      */     Collection<PackageSource> imports;
/*  819 */     String pkgName = getResourcePackageName(path.endsWith("/") ? path : (String.valueOf(path) + '/'));
/*  820 */     if (path.length() > 1 && path.charAt(0) == '/')
/*  821 */       path = path.substring(1); 
/*  822 */     boolean subPackages = ((options & 0x1) != 0);
/*  823 */     List<String> packages = new ArrayList<>();
/*      */     
/*  825 */     Map<String, PackageSource> importSources = getImportedSources(null);
/*      */     
/*  827 */     synchronized (importSources) {
/*  828 */       imports = new ArrayList<>(importSources.values());
/*      */     } 
/*  830 */     for (PackageSource source : imports) {
/*  831 */       String id = source.getId();
/*  832 */       if (id.equals(pkgName) || (subPackages && isSubPackage(pkgName, id))) {
/*  833 */         packages.add(id);
/*      */       }
/*      */     } 
/*      */     
/*  837 */     Collection<BundleLoader> visited = new ArrayList<>();
/*  838 */     visited.add(this);
/*  839 */     for (ModuleWire bundleWire : this.requiredBundleWires) {
/*  840 */       BundleLoader loader = getProviderLoader(bundleWire);
/*  841 */       if (loader != null) {
/*  842 */         loader.addProvidedPackageNames(pkgName, packages, subPackages, visited);
/*      */       }
/*      */     } 
/*      */     
/*  846 */     boolean localSearch = ((options & 0x2) != 0);
/*      */ 
/*      */     
/*  849 */     LinkedHashSet<String> result = new LinkedHashSet<>();
/*  850 */     Set<String> importedPackages = new HashSet<>(0);
/*  851 */     for (String name : packages) {
/*      */       
/*  853 */       PackageSource externalSource = findImportedSource(name, null);
/*  854 */       if (externalSource != null) {
/*      */         
/*  856 */         importedPackages.add(name);
/*      */       } else {
/*      */         
/*  859 */         externalSource = findRequiredSource(name, null);
/*      */       } 
/*      */       
/*  862 */       if (externalSource != null && !localSearch) {
/*  863 */         String packagePath = name.replace('.', '/');
/*  864 */         Collection<String> externalResources = externalSource.listResources(packagePath, filePattern);
/*  865 */         for (String resource : externalResources) {
/*  866 */           if (!result.contains(resource)) {
/*  867 */             result.add(resource);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  873 */     Collection<String> localResources = getModuleClassLoader().listLocalResources(path, filePattern, options);
/*  874 */     for (String resource : localResources) {
/*  875 */       String resourcePkg = getResourcePackageName(resource);
/*  876 */       if (!importedPackages.contains(resourcePkg) && !result.contains(resource)) {
/*  877 */         result.add(resource);
/*      */       }
/*      */     } 
/*  880 */     if (!localSearch && this.policy != null) {
/*  881 */       this.policy.doBuddyListResourceLoading(result, path, filePattern, options);
/*      */     }
/*  883 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected List<URL> findEntries(String path, String filePattern, int options) {
/*  888 */     return getModuleClassLoader().findEntries(path, filePattern, options);
/*      */   }
/*      */   
/*      */   public static <E> Enumeration<E> compoundEnumerations(Enumeration<E> list1, Enumeration<E> list2) {
/*  892 */     if (list2 == null || !list2.hasMoreElements())
/*  893 */       return (list1 == null) ? Collections.<E>emptyEnumeration() : list1; 
/*  894 */     if (list1 == null || !list1.hasMoreElements())
/*  895 */       return (list2 == null) ? Collections.<E>emptyEnumeration() : list2; 
/*  896 */     List<E> compoundResults = Collections.list(list1);
/*  897 */     while (list2.hasMoreElements()) {
/*  898 */       E item = list2.nextElement();
/*  899 */       if (!compoundResults.contains(item))
/*  900 */         compoundResults.add(item); 
/*      */     } 
/*  902 */     return Collections.enumeration(compoundResults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL findLocalResource(String name) {
/*  911 */     return getModuleClassLoader().findLocalResource(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<URL> findLocalResources(String name) {
/*  922 */     return getModuleClassLoader().findLocalResources(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String toString() {
/*  931 */     ModuleRevision revision = this.wiring.getRevision();
/*  932 */     String name = revision.getSymbolicName();
/*  933 */     if (name == null)
/*  934 */       name = "unknown"; 
/*  935 */     return String.valueOf(name) + '_' + revision.getVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isDynamicallyImported(String pkgname) {
/*  946 */     if (this instanceof SystemBundleLoader) {
/*  947 */       return false;
/*      */     }
/*  949 */     if (pkgname.startsWith("java.")) {
/*  950 */       return true;
/*      */     }
/*  952 */     synchronized (this.importedSources) {
/*      */       
/*  954 */       if (this.dynamicAllPackages) {
/*  955 */         return true;
/*      */       }
/*      */       
/*  958 */       if (this.dynamicImportPackages != null) {
/*  959 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.dynamicImportPackages).length, b = 0; b < i; ) { String dynamicImportPackage = arrayOfString[b];
/*  960 */           if (pkgname.equals(dynamicImportPackage)) {
/*  961 */             return true;
/*      */           }
/*      */           b++; }
/*      */       
/*      */       } 
/*  966 */       if (this.dynamicImportPackageStems != null) {
/*  967 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.dynamicImportPackageStems).length, b = 0; b < i; ) { String dynamicImportPackageStem = arrayOfString[b];
/*  968 */           if (pkgname.startsWith(dynamicImportPackageStem))
/*  969 */             return true;  b++; }
/*      */       
/*      */       } 
/*      */     } 
/*  973 */     return false;
/*      */   }
/*      */   
/*      */   final void addExportedProvidersFor(String packageName, List<PackageSource> result, Collection<BundleLoader> visited) {
/*  977 */     if (visited.contains(this))
/*      */       return; 
/*  979 */     visited.add(this);
/*      */     
/*  981 */     PackageSource local = null;
/*  982 */     if (isExportedPackage(packageName)) {
/*  983 */       local = this.exportSources.getPackageSource(packageName);
/*  984 */     } else if (isSubstitutedExport(packageName)) {
/*  985 */       result.add(findImportedSource(packageName, visited));
/*      */       
/*      */       return;
/*      */     } 
/*  989 */     for (ModuleWire bundleWire : this.requiredBundleWires) {
/*  990 */       if (local != null || "reexport".equals(bundleWire.getRequirement().getDirectives().get("visibility"))) {
/*      */ 
/*      */ 
/*      */         
/*  994 */         BundleLoader loader = getProviderLoader(bundleWire);
/*  995 */         if (loader != null) {
/*  996 */           loader.addExportedProvidersFor(packageName, result, visited);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1001 */     if (local != null)
/* 1002 */       result.add(local); 
/*      */   }
/*      */   
/*      */   private BundleLoader getProviderLoader(ModuleWire wire) {
/* 1006 */     ModuleWiring provider = wire.getProviderWiring();
/* 1007 */     if (provider == null) {
/* 1008 */       if (this.firstUseOfInvalidLoader.getAndSet(true)) {
/*      */         
/* 1010 */         String message = "Invalid class loader from a refreshed bundle is being used: " + toString();
/* 1011 */         this.container.getEventPublisher().publishFrameworkEvent(2, this.wiring.getBundle(), new IllegalStateException(message));
/*      */       } 
/* 1013 */       return null;
/*      */     } 
/* 1015 */     return (BundleLoader)provider.getModuleLoader();
/*      */   }
/*      */   
/*      */   final void addProvidedPackageNames(String packageName, List<String> result, boolean subPackages, Collection<BundleLoader> visited) {
/* 1019 */     if (visited.contains(this))
/*      */       return; 
/* 1021 */     visited.add(this);
/* 1022 */     synchronized (this.exportedPackages) {
/* 1023 */       for (String exported : this.exportedPackages) {
/* 1024 */         if ((exported.equals(packageName) || (subPackages && isSubPackage(packageName, exported))) && 
/* 1025 */           !result.contains(exported)) {
/* 1026 */           result.add(exported);
/*      */         }
/*      */       } 
/*      */     } 
/* 1030 */     for (String substituted : this.wiring.getSubstitutedNames()) {
/* 1031 */       if ((substituted.equals(packageName) || (subPackages && isSubPackage(packageName, substituted))) && 
/* 1032 */         !result.contains(substituted)) {
/* 1033 */         result.add(substituted);
/*      */       }
/*      */     } 
/* 1036 */     for (ModuleWire bundleWire : this.requiredBundleWires) {
/* 1037 */       if ("reexport".equals(bundleWire.getRequirement().getDirectives().get("visibility"))) {
/* 1038 */         BundleLoader loader = getProviderLoader(bundleWire);
/* 1039 */         if (loader != null) {
/* 1040 */           loader.addProvidedPackageNames(packageName, result, subPackages, visited);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public final boolean isExportedPackage(String name) {
/* 1047 */     return this.exportedPackages.contains(name);
/*      */   }
/*      */   
/*      */   final boolean isSubstitutedExport(String name) {
/* 1051 */     return this.wiring.isSubstitutedPackage(name);
/*      */   }
/*      */   
/*      */   private void addDynamicImportPackage(List<ModuleRequirement> packageImports) {
/* 1055 */     if (packageImports == null || packageImports.isEmpty()) {
/*      */       return;
/*      */     }
/* 1058 */     List<String> dynamicImports = new ArrayList<>(packageImports.size());
/* 1059 */     for (ModuleRequirement packageImport : packageImports) {
/* 1060 */       if ("dynamic".equals(packageImport.getDirectives().get("resolution"))) {
/* 1061 */         Matcher matcher = PACKAGENAME_FILTER.matcher((CharSequence)packageImport.getDirectives().get("filter"));
/* 1062 */         if (matcher.find()) {
/* 1063 */           String dynamicName = matcher.group(1);
/* 1064 */           if (dynamicName != null) {
/* 1065 */             dynamicImports.add(dynamicName);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1070 */     if (dynamicImports.size() > 0) {
/* 1071 */       addDynamicImportPackage(dynamicImports.<String>toArray(new String[dynamicImports.size()]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addDynamicImportPackage(String[] packages) {
/* 1082 */     if (packages == null) {
/*      */       return;
/*      */     }
/* 1085 */     synchronized (this.importedSources) {
/* 1086 */       List<String> stems, names; int size = packages.length;
/*      */       
/* 1088 */       if (this.dynamicImportPackageStems == null) {
/* 1089 */         stems = new ArrayList<>(size);
/*      */       } else {
/* 1091 */         stems = new ArrayList<>(size + this.dynamicImportPackageStems.length); byte b; int j; String[] arrayOfString;
/* 1092 */         for (j = (arrayOfString = this.dynamicImportPackageStems).length, b = 0; b < j; ) { String dynamicImportPackageStem = arrayOfString[b];
/* 1093 */           stems.add(dynamicImportPackageStem);
/*      */           
/*      */           b++; }
/*      */       
/*      */       } 
/* 1098 */       if (this.dynamicImportPackages == null) {
/* 1099 */         names = new ArrayList<>(size);
/*      */       } else {
/* 1101 */         names = new ArrayList<>(size + this.dynamicImportPackages.length); byte b; int j; String[] arrayOfString;
/* 1102 */         for (j = (arrayOfString = this.dynamicImportPackages).length, b = 0; b < j; ) { String dynamicImportPackage = arrayOfString[b];
/* 1103 */           names.add(dynamicImportPackage);
/*      */           b++; }
/*      */       
/*      */       } 
/* 1107 */       for (int i = 0; i < size; i++) {
/* 1108 */         String name = packages[i];
/* 1109 */         if (!isDynamicallyImported(name)) {
/*      */           
/* 1111 */           if (name.equals("*")) {
/*      */             
/* 1113 */             this.dynamicAllPackages = true;
/*      */             
/*      */             return;
/*      */           } 
/* 1117 */           if (name.endsWith(".*")) {
/* 1118 */             stems.add(name.substring(0, name.length() - 1));
/*      */           } else {
/* 1120 */             names.add(name);
/*      */           } 
/*      */         } 
/* 1123 */       }  size = stems.size();
/* 1124 */       if (size > 0) {
/* 1125 */         this.dynamicImportPackageStems = stems.<String>toArray(new String[size]);
/*      */       }
/* 1127 */       size = names.size();
/* 1128 */       if (size > 0) {
/* 1129 */         this.dynamicImportPackages = names.<String>toArray(new String[size]);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addDynamicImportPackage(ManifestElement[] packages) {
/* 1140 */     if (packages == null)
/*      */       return; 
/* 1142 */     List<String> dynamicImports = new ArrayList<>(packages.length);
/* 1143 */     StringBuilder importSpec = new StringBuilder(); byte b; int i; ManifestElement[] arrayOfManifestElement;
/* 1144 */     for (i = (arrayOfManifestElement = packages).length, b = 0; b < i; ) { ManifestElement dynamicImportElement = arrayOfManifestElement[b];
/* 1145 */       String[] names = dynamicImportElement.getValueComponents();
/* 1146 */       Collections.addAll(dynamicImports, names);
/* 1147 */       if (importSpec.length() > 0) {
/* 1148 */         importSpec.append(',');
/*      */       }
/* 1150 */       importSpec.append(dynamicImportElement.toString());
/*      */       b++; }
/*      */     
/* 1153 */     if (dynamicImports.size() > 0) {
/* 1154 */       Map<String, String> dynamicImportMap = new HashMap<>();
/* 1155 */       dynamicImportMap.put("DynamicImport-Package", importSpec.toString());
/*      */       
/*      */       try {
/* 1158 */         ModuleRevisionBuilder builder = OSGiManifestBuilderFactory.createBuilder(dynamicImportMap);
/* 1159 */         this.wiring.addDynamicImports(builder);
/* 1160 */       } catch (BundleException e) {
/* 1161 */         throw new RuntimeException(e);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1166 */       addDynamicImportPackage(dynamicImports.<String>toArray(new String[dynamicImports.size()]));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PackageSource findSource(String pkgName) {
/* 1175 */     if (pkgName == null)
/* 1176 */       return null; 
/* 1177 */     PackageSource result = findImportedSource(pkgName, null);
/* 1178 */     if (result != null) {
/* 1179 */       return result;
/*      */     }
/* 1181 */     return findRequiredSource(pkgName, null);
/*      */   }
/*      */   
/*      */   private PackageSource findImportedSource(String pkgName, Collection<BundleLoader> visited) {
/* 1185 */     Map<String, PackageSource> imports = getImportedSources(visited);
/* 1186 */     synchronized (imports) {
/* 1187 */       return imports.get(pkgName);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Map<String, PackageSource> getImportedSources(Collection<BundleLoader> visited) {
/* 1192 */     synchronized (this.importedSources) {
/* 1193 */       if (this.importsInitialized) {
/* 1194 */         return this.importedSources;
/*      */       }
/* 1196 */       List<ModuleWire> importWires = this.wiring.getRequiredModuleWires("osgi.wiring.package");
/* 1197 */       if (importWires != null) {
/* 1198 */         for (ModuleWire importWire : importWires) {
/* 1199 */           PackageSource source = createExportPackageSource(importWire, visited);
/* 1200 */           if (source != null) {
/* 1201 */             this.importedSources.put(source.getId(), source);
/*      */           }
/*      */         } 
/*      */       }
/* 1205 */       this.importsInitialized = true;
/* 1206 */       return this.importedSources;
/*      */     } 
/*      */   }
/*      */   
/*      */   private PackageSource findDynamicSource(String pkgName) {
/* 1211 */     if (!isExportedPackage(pkgName) && isDynamicallyImported(pkgName)) {
/* 1212 */       if (this.debug.DEBUG_LOADER) {
/* 1213 */         Debug.println("BundleLoader[" + this + "] attempting to resolve dynamic package: " + pkgName);
/*      */       }
/* 1215 */       ModuleRevision revision = this.wiring.getRevision();
/* 1216 */       ModuleWire dynamicWire = revision.getRevisions().getModule().getContainer().resolveDynamic(pkgName, revision);
/* 1217 */       if (dynamicWire != null) {
/* 1218 */         PackageSource source = createExportPackageSource(dynamicWire, null);
/* 1219 */         if (this.debug.DEBUG_LOADER) {
/* 1220 */           Debug.println("BundleLoader[" + this + "] using dynamic import source: " + source);
/*      */         }
/* 1222 */         synchronized (this.importedSources) {
/* 1223 */           this.importedSources.put(source.getId(), source);
/*      */         } 
/* 1225 */         return source;
/*      */       } 
/*      */     } 
/* 1228 */     return null;
/*      */   }
/*      */   private PackageSource findRequiredSource(String pkgName, Collection<BundleLoader> visited) {
/*      */     PackageSource source;
/* 1232 */     if (this.requiredBundleWires.isEmpty()) {
/* 1233 */       return null;
/*      */     }
/* 1235 */     synchronized (this.requiredSources) {
/* 1236 */       PackageSource packageSource = this.requiredSources.get(pkgName);
/* 1237 */       if (packageSource != null)
/* 1238 */         return packageSource.isNullSource() ? null : packageSource; 
/*      */     } 
/* 1240 */     if (visited == null)
/* 1241 */       visited = new ArrayList<>(); 
/* 1242 */     if (!visited.contains(this))
/* 1243 */       visited.add(this); 
/* 1244 */     List<PackageSource> result = new ArrayList<>(3);
/* 1245 */     for (ModuleWire bundleWire : this.requiredBundleWires) {
/* 1246 */       BundleLoader loader = getProviderLoader(bundleWire);
/* 1247 */       if (loader != null) {
/* 1248 */         loader.addExportedProvidersFor(pkgName, result, visited);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1253 */     if (result.size() == 0) {
/*      */ 
/*      */       
/* 1256 */       NullPackageSource nullPackageSource = NullPackageSource.getNullPackageSource(pkgName);
/* 1257 */     } else if (result.size() == 1) {
/*      */       
/* 1259 */       source = result.get(0);
/*      */     } else {
/*      */       
/* 1262 */       PackageSource[] srcs = result.<PackageSource>toArray(new PackageSource[result.size()]);
/* 1263 */       source = createMultiSource(pkgName, srcs);
/*      */     } 
/* 1265 */     synchronized (this.requiredSources) {
/* 1266 */       this.requiredSources.put(source.getId(), source);
/*      */     } 
/* 1268 */     return source.isNullSource() ? null : source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PackageSource getPackageSource(String pkgName) {
/* 1277 */     PackageSource result = findSource(pkgName);
/* 1278 */     if (!isExportedPackage(pkgName)) {
/* 1279 */       return result;
/*      */     }
/* 1281 */     PackageSource localSource = this.exportSources.getPackageSource(pkgName);
/* 1282 */     if (result == null)
/* 1283 */       return localSource; 
/* 1284 */     if (localSource == null)
/* 1285 */       return result; 
/* 1286 */     return createMultiSource(pkgName, new PackageSource[] { result, localSource });
/*      */   }
/*      */   
/*      */   static final class ClassContext
/*      */     extends SecurityManager
/*      */   {
/*      */     public Class<?>[] getClassContext() {
/* 1293 */       return super.getClassContext();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean getAndSetTrigger() {
/* 1299 */     return this.triggerClassLoaded.getAndSet(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTriggerSet() {
/* 1304 */     return this.triggerClassLoaded.get();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\BundleLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */