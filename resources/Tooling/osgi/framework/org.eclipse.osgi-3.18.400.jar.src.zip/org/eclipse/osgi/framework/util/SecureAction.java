/*     */ package org.eclipse.osgi.framework.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Properties;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipException;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecureAction
/*     */ {
/*     */   private AccessControlContext controlContext;
/*     */   
/*     */   private static class BootClassLoaderHolder
/*     */   {
/*  52 */     static final ClassLoader bootClassLoader = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*     */         {
/*     */           public ClassLoader run() {
/*  55 */             return new ClassLoader(Object.class.getClassLoader())
/*     */               {
/*     */               
/*     */               };
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SecureAction() {
/*  68 */     this.controlContext = AccessController.getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivilegedAction<SecureAction> createSecureAction() {
/*  80 */     return new PrivilegedAction<SecureAction>()
/*     */       {
/*     */         public SecureAction run() {
/*  83 */           return new SecureAction();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(final String property) {
/*  95 */     if (System.getSecurityManager() == null)
/*  96 */       return System.getProperty(property); 
/*  97 */     return AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/* 100 */             return System.getProperty(property);
/*     */           }
/* 102 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 111 */     if (System.getSecurityManager() == null)
/* 112 */       return System.getProperties(); 
/* 113 */     return AccessController.<Properties>doPrivileged(new PrivilegedAction<Properties>()
/*     */         {
/*     */           public Properties run() {
/* 116 */             return System.getProperties();
/*     */           }
/* 118 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileInputStream getFileInputStream(final File file) throws FileNotFoundException {
/* 129 */     if (System.getSecurityManager() == null)
/* 130 */       return new FileInputStream(file); 
/*     */     try {
/* 132 */       return AccessController.<FileInputStream>doPrivileged(new PrivilegedExceptionAction<FileInputStream>()
/*     */           {
/*     */             public FileInputStream run() throws FileNotFoundException {
/* 135 */               return new FileInputStream(file);
/*     */             }
/* 137 */           },  this.controlContext);
/* 138 */     } catch (PrivilegedActionException e) {
/* 139 */       if (e.getException() instanceof FileNotFoundException)
/* 140 */         throw (FileNotFoundException)e.getException(); 
/* 141 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileOutputStream getFileOutputStream(final File file, final boolean append) throws FileNotFoundException {
/* 154 */     if (System.getSecurityManager() == null)
/* 155 */       return new FileOutputStream(file.getAbsolutePath(), append); 
/*     */     try {
/* 157 */       return AccessController.<FileOutputStream>doPrivileged(new PrivilegedExceptionAction<FileOutputStream>()
/*     */           {
/*     */             public FileOutputStream run() throws FileNotFoundException {
/* 160 */               return new FileOutputStream(file.getAbsolutePath(), append);
/*     */             }
/* 162 */           }this.controlContext);
/* 163 */     } catch (PrivilegedActionException e) {
/* 164 */       if (e.getException() instanceof FileNotFoundException)
/* 165 */         throw (FileNotFoundException)e.getException(); 
/* 166 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length(final File file) {
/* 177 */     if (System.getSecurityManager() == null)
/* 178 */       return file.length(); 
/* 179 */     return ((Long)AccessController.<Long>doPrivileged(new PrivilegedAction<Long>()
/*     */         {
/*     */           public Long run() {
/* 182 */             return Long.valueOf(file.length());
/*     */           }
/* 184 */         },  this.controlContext)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCanonicalPath(final File file) throws IOException {
/* 195 */     if (System.getSecurityManager() == null)
/* 196 */       return file.getCanonicalPath(); 
/*     */     try {
/* 198 */       return AccessController.<String>doPrivileged(new PrivilegedExceptionAction<String>()
/*     */           {
/*     */             public String run() throws IOException {
/* 201 */               return file.getCanonicalPath();
/*     */             }
/* 203 */           },  this.controlContext);
/* 204 */     } catch (PrivilegedActionException e) {
/* 205 */       if (e.getException() instanceof IOException)
/* 206 */         throw (IOException)e.getException(); 
/* 207 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getAbsoluteFile(final File file) {
/* 218 */     if (System.getSecurityManager() == null)
/* 219 */       return file.getAbsoluteFile(); 
/* 220 */     return AccessController.<File>doPrivileged(new PrivilegedAction<File>()
/*     */         {
/*     */           public File run() {
/* 223 */             return file.getAbsoluteFile();
/*     */           }
/* 225 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getCanonicalFile(final File file) throws IOException {
/* 236 */     if (System.getSecurityManager() == null)
/* 237 */       return file.getCanonicalFile(); 
/*     */     try {
/* 239 */       return AccessController.<File>doPrivileged(new PrivilegedExceptionAction<File>()
/*     */           {
/*     */             public File run() throws IOException {
/* 242 */               return file.getCanonicalFile();
/*     */             }
/* 244 */           },  this.controlContext);
/* 245 */     } catch (PrivilegedActionException e) {
/* 246 */       if (e.getException() instanceof IOException)
/* 247 */         throw (IOException)e.getException(); 
/* 248 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists(final File file) {
/* 259 */     if (System.getSecurityManager() == null)
/* 260 */       return file.exists(); 
/* 261 */     return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */         {
/*     */           public Boolean run() {
/* 264 */             return file.exists() ? Boolean.TRUE : Boolean.FALSE;
/*     */           }
/* 266 */         },  this.controlContext)).booleanValue();
/*     */   }
/*     */   
/*     */   public boolean mkdirs(final File file) {
/* 270 */     if (System.getSecurityManager() == null)
/* 271 */       return file.mkdirs(); 
/* 272 */     return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */         {
/*     */           public Boolean run() {
/* 275 */             return file.mkdirs() ? Boolean.TRUE : Boolean.FALSE;
/*     */           }
/* 277 */         },  this.controlContext)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirectory(final File file) {
/* 287 */     if (System.getSecurityManager() == null)
/* 288 */       return file.isDirectory(); 
/* 289 */     return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */         {
/*     */           public Boolean run() {
/* 292 */             return file.isDirectory() ? Boolean.TRUE : Boolean.FALSE;
/*     */           }
/* 294 */         },  this.controlContext)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long lastModified(final File file) {
/* 304 */     if (System.getSecurityManager() == null)
/* 305 */       return file.lastModified(); 
/* 306 */     return ((Long)AccessController.<Long>doPrivileged(new PrivilegedAction<Long>()
/*     */         {
/*     */           public Long run() {
/* 309 */             return Long.valueOf(file.lastModified());
/*     */           }
/* 311 */         },  this.controlContext)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(final File file) {
/* 321 */     if (System.getSecurityManager() == null)
/* 322 */       return file.list(); 
/* 323 */     return AccessController.<String[]>doPrivileged((PrivilegedAction)new PrivilegedAction<String[]>()
/*     */         {
/*     */           public String[] run() {
/* 326 */             return file.list();
/*     */           }
/* 328 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipFile getZipFile(final File file, final boolean verify) throws IOException {
/*     */     try {
/* 341 */       if (System.getSecurityManager() == null)
/* 342 */         return new ZipFile(file); 
/*     */       try {
/* 344 */         return AccessController.<ZipFile>doPrivileged(new PrivilegedExceptionAction<ZipFile>()
/*     */             {
/*     */               public ZipFile run() throws IOException {
/* 347 */                 return verify ? new JarFile(file) : new ZipFile(file);
/*     */               }
/* 349 */             },  this.controlContext);
/* 350 */       } catch (PrivilegedActionException e) {
/* 351 */         if (e.getException() instanceof IOException)
/* 352 */           throw (IOException)e.getException(); 
/* 353 */         throw (RuntimeException)e.getException();
/*     */       } 
/* 355 */     } catch (ZipException e) {
/* 356 */       ZipException zipNameException = new ZipException("Exception in opening zip file: " + file.getPath());
/* 357 */       zipNameException.initCause(e);
/* 358 */       throw zipNameException;
/* 359 */     } catch (IOException e) {
/* 360 */       throw new IOException("Exception in opening zip file: " + file.getPath(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getURL(final String protocol, final String host, final int port, final String file, final URLStreamHandler handler) throws MalformedURLException {
/* 376 */     if (System.getSecurityManager() == null)
/* 377 */       return new URL(protocol, host, port, file, handler); 
/*     */     try {
/* 379 */       return AccessController.<URL>doPrivileged(new PrivilegedExceptionAction<URL>()
/*     */           {
/*     */             public URL run() throws MalformedURLException {
/* 382 */               return new URL(protocol, host, port, file, handler);
/*     */             }
/* 384 */           }this.controlContext);
/* 385 */     } catch (PrivilegedActionException e) {
/* 386 */       if (e.getException() instanceof MalformedURLException)
/* 387 */         throw (MalformedURLException)e.getException(); 
/* 388 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Thread createThread(final Runnable target, final String name, final ClassLoader contextLoader) {
/* 401 */     if (System.getSecurityManager() == null)
/* 402 */       return createThread0(target, name, contextLoader); 
/* 403 */     return AccessController.<Thread>doPrivileged(new PrivilegedAction<Thread>()
/*     */         {
/*     */           public Thread run() {
/* 406 */             return SecureAction.this.createThread0(target, name, contextLoader);
/*     */           }
/* 408 */         }this.controlContext);
/*     */   }
/*     */   
/*     */   Thread createThread0(Runnable target, String name, ClassLoader contextLoader) {
/* 412 */     Thread result = new Thread(target, name);
/* 413 */     if (contextLoader != null)
/* 414 */       result.setContextClassLoader(contextLoader); 
/* 415 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S> S getService(final ServiceReference<S> reference, final BundleContext context) {
/* 426 */     if (System.getSecurityManager() == null)
/* 427 */       return (S)context.getService(reference); 
/* 428 */     return AccessController.doPrivileged(new PrivilegedAction<S>()
/*     */         {
/*     */           public S run() {
/* 431 */             return (S)context.getService(reference);
/*     */           }
/* 433 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> forName(final String name) throws ClassNotFoundException {
/* 444 */     if (System.getSecurityManager() == null)
/* 445 */       return Class.forName(name); 
/*     */     try {
/* 447 */       return AccessController.<Class<?>>doPrivileged(new PrivilegedExceptionAction<Class<?>>()
/*     */           {
/*     */             public Class<?> run() throws Exception {
/* 450 */               return Class.forName(name);
/*     */             }
/* 452 */           },  this.controlContext);
/* 453 */     } catch (PrivilegedActionException e) {
/* 454 */       if (e.getException() instanceof ClassNotFoundException)
/* 455 */         throw (ClassNotFoundException)e.getException(); 
/* 456 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> loadSystemClass(final String name) throws ClassNotFoundException {
/* 468 */     if (System.getSecurityManager() == null) {
/* 469 */       ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
/* 470 */       return (systemClassLoader != null) ? systemClassLoader.loadClass(name) : BootClassLoaderHolder.bootClassLoader.loadClass(name);
/*     */     } 
/*     */     try {
/* 473 */       return AccessController.<Class<?>>doPrivileged(new PrivilegedExceptionAction<Class<?>>()
/*     */           {
/*     */             public Class<?> run() throws Exception {
/* 476 */               ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
/* 477 */               return (systemClassLoader != null) ? systemClassLoader.loadClass(name) : SecureAction.BootClassLoaderHolder.bootClassLoader.loadClass(name);
/*     */             }
/* 479 */           },  this.controlContext);
/* 480 */     } catch (PrivilegedActionException e) {
/* 481 */       if (e.getException() instanceof ClassNotFoundException)
/* 482 */         throw (ClassNotFoundException)e.getException(); 
/* 483 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(final ServiceTracker<?, ?> tracker) {
/* 492 */     if (System.getSecurityManager() == null) {
/* 493 */       tracker.open();
/*     */       return;
/*     */     } 
/* 496 */     AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */         {
/*     */           public Void run() {
/* 499 */             tracker.open();
/* 500 */             return null;
/*     */           }
/* 502 */         },  this.controlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(final Module module, Module.StartOptions... options) throws BundleException {
/* 512 */     if (System.getSecurityManager() == null) {
/* 513 */       module.start(options);
/*     */       return;
/*     */     } 
/*     */     try {
/* 517 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*     */           {
/*     */             public Void run() throws BundleException {
/* 520 */               module.start(options);
/* 521 */               return null;
/*     */             }
/* 523 */           },  this.controlContext);
/* 524 */     } catch (PrivilegedActionException e) {
/* 525 */       if (e.getException() instanceof BundleException)
/* 526 */         throw (BundleException)e.getException(); 
/* 527 */       throw (RuntimeException)e.getException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public BundleContext getContext(final Bundle bundle) {
/* 532 */     if (System.getSecurityManager() == null) {
/* 533 */       return bundle.getBundleContext();
/*     */     }
/* 535 */     return AccessController.<BundleContext>doPrivileged(new PrivilegedAction<BundleContext>()
/*     */         {
/*     */           public BundleContext run() {
/* 538 */             return bundle.getBundleContext();
/*     */           }
/* 540 */         },  this.controlContext);
/*     */   }
/*     */   
/*     */   public String getLocation(final Bundle bundle) {
/* 544 */     if (System.getSecurityManager() == null) {
/* 545 */       return bundle.getLocation();
/*     */     }
/* 547 */     return AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/* 550 */             return bundle.getLocation();
/*     */           }
/* 552 */         },  this.controlContext);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\SecureAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */