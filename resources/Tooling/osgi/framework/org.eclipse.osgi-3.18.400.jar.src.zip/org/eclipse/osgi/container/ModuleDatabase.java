/*      */ package org.eclipse.osgi.container;
/*      */ 
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import java.util.function.BiFunction;
/*      */ import org.eclipse.osgi.framework.util.ObjectPool;
/*      */ import org.eclipse.osgi.internal.container.Capabilities;
/*      */ import org.eclipse.osgi.internal.container.ComputeNodeOrder;
/*      */ import org.eclipse.osgi.internal.container.NamespaceList;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.resource.Requirement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ModuleDatabase
/*      */ {
/*      */   final ModuleContainerAdaptor adaptor;
/*      */   private final Map<String, Module> modulesByLocations;
/*      */   private final Map<Long, Module> modulesById;
/*      */   final Map<ModuleRevision, ModuleWiring> wirings;
/*      */   final AtomicLong nextId;
/*      */   final AtomicLong revisionsTimeStamp;
/*      */   final AtomicLong allTimeStamp;
/*      */   final long constructionTime;
/*      */   private final Capabilities capabilities;
/*      */   final Map<Long, EnumSet<Module.Settings>> moduleSettings;
/*  138 */   private int initialModuleStartLevel = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private final ReentrantReadWriteLock monitor = new ReentrantReadWriteLock(false);
/*      */   
/*      */   enum Sort {
/*  146 */     BY_DEPENDENCY, BY_START_LEVEL, BY_ID;
/*      */     
/*      */     public boolean isContained(Sort... options) {
/*      */       byte b;
/*      */       int i;
/*      */       Sort[] arrayOfSort;
/*  152 */       for (i = (arrayOfSort = options).length, b = 0; b < i; ) { Sort option = arrayOfSort[b];
/*  153 */         if (equals(option))
/*  154 */           return true; 
/*      */         b++; }
/*      */       
/*  157 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleDatabase(ModuleContainerAdaptor adaptor) {
/*  166 */     this.adaptor = adaptor;
/*  167 */     this.modulesByLocations = new HashMap<>();
/*  168 */     this.modulesById = new HashMap<>();
/*  169 */     this.wirings = new HashMap<>();
/*      */     
/*  171 */     this.nextId = new AtomicLong(1L);
/*      */     
/*  173 */     this.constructionTime = System.currentTimeMillis();
/*  174 */     this.revisionsTimeStamp = new AtomicLong(this.constructionTime);
/*  175 */     this.allTimeStamp = new AtomicLong(this.constructionTime);
/*  176 */     this.moduleSettings = new HashMap<>();
/*  177 */     this.capabilities = new Capabilities();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Module getModule(String location) {
/*  189 */     readLock();
/*      */     try {
/*  191 */       return this.modulesByLocations.get(location);
/*      */     } finally {
/*  193 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Module getModule(long id) {
/*  206 */     readLock();
/*      */     try {
/*  208 */       return this.modulesById.get(Long.valueOf(id));
/*      */     } finally {
/*  210 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Module install(String location, ModuleRevisionBuilder builder, Object revisionInfo) {
/*  224 */     writeLock();
/*      */     try {
/*  226 */       int startlevel = "System Bundle".equals(location) ? 0 : getInitialModuleStartLevel();
/*  227 */       long id = "System Bundle".equals(location) ? 0L : builder.getId();
/*  228 */       if (id == -1L)
/*      */       {
/*  230 */         id = getAndIncrementNextId();
/*      */       }
/*  232 */       if (getModule(id) != null) {
/*  233 */         throw new IllegalStateException("Duplicate module id: " + id + " used by module: " + getModule(id));
/*      */       }
/*  235 */       EnumSet<Module.Settings> settings = getActivationPolicySettings(builder);
/*  236 */       Module module = load(location, builder, revisionInfo, id, settings, startlevel);
/*  237 */       long currentTime = System.currentTimeMillis();
/*  238 */       module.setlastModified(currentTime);
/*  239 */       setSystemLastModified(currentTime);
/*  240 */       incrementTimestamps(true);
/*  241 */       return module;
/*      */     } finally {
/*  243 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private EnumSet<Module.Settings> getActivationPolicySettings(ModuleRevisionBuilder builder) {
/*  249 */     if ((builder.getTypes() & 0x1) != 0) {
/*  250 */       return null;
/*      */     }
/*  252 */     Iterator<ModuleRevisionBuilder.GenericInfo> iterator = builder.getCapabilities("equinox.module.data").iterator(); if (iterator.hasNext()) { ModuleRevisionBuilder.GenericInfo info = iterator.next();
/*  253 */       if ("lazy".equals(info.getAttributes().get("activation.policy"))) {
/*  254 */         String compatibilityStartLazy = this.adaptor.getProperty("osgi.compatibility.eagerStart.LazyActivation");
/*  255 */         if (compatibilityStartLazy == null || Boolean.valueOf(compatibilityStartLazy).booleanValue()) {
/*      */           
/*  257 */           EnumSet<Module.Settings> settings = EnumSet.noneOf(Module.Settings.class);
/*  258 */           settings.add(Module.Settings.USE_ACTIVATION_POLICY);
/*  259 */           settings.add(Module.Settings.AUTO_START);
/*  260 */           return settings;
/*      */         } 
/*      */       } 
/*  263 */       return null; }
/*      */     
/*  265 */     return null;
/*      */   }
/*      */   
/*      */   final Module load(String location, ModuleRevisionBuilder builder, Object revisionInfo, long id, EnumSet<Module.Settings> settings, int startlevel) {
/*      */     Module module;
/*  270 */     checkWrite();
/*  271 */     if (this.modulesByLocations.containsKey(location))
/*  272 */       throw new IllegalArgumentException("Location is already used: " + location); 
/*  273 */     if (this.modulesById.containsKey(Long.valueOf(id))) {
/*  274 */       throw new IllegalArgumentException("Id is already used: " + id);
/*      */     }
/*  276 */     if (id == 0L) {
/*  277 */       module = this.adaptor.createSystemModule();
/*      */     } else {
/*  279 */       module = this.adaptor.createModule(location, id, settings, startlevel);
/*      */     } 
/*  281 */     builder.addRevision(module, revisionInfo);
/*  282 */     this.modulesByLocations.put(location, module);
/*  283 */     this.modulesById.put(Long.valueOf(id), module);
/*  284 */     if (settings != null)
/*  285 */       this.moduleSettings.put(Long.valueOf(id), settings); 
/*  286 */     ModuleRevision newRevision = module.getCurrentRevision();
/*  287 */     addCapabilities(newRevision);
/*  288 */     return module;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void uninstall(Module module) {
/*  300 */     writeLock();
/*      */     try {
/*  302 */       ModuleRevisions uninstalling = module.getRevisions();
/*      */       
/*  304 */       uninstalling.uninstall();
/*      */       
/*  306 */       this.modulesByLocations.remove(module.getLocation());
/*  307 */       this.modulesById.remove(module.getId());
/*  308 */       this.moduleSettings.remove(module.getId());
/*      */       
/*  310 */       List<ModuleRevision> revisions = uninstalling.getModuleRevisions();
/*  311 */       for (ModuleRevision revision : revisions) {
/*      */ 
/*      */         
/*  314 */         ModuleWiring oldWiring = this.wirings.get(revision);
/*  315 */         if (oldWiring == null) {
/*  316 */           module.getRevisions().removeRevision(revision);
/*  317 */           removeCapabilities(revision);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  322 */       cleanupRemovalPending();
/*  323 */       long currentTime = System.currentTimeMillis();
/*  324 */       module.setlastModified(currentTime);
/*  325 */       setSystemLastModified(currentTime);
/*  326 */       incrementTimestamps(true);
/*      */     } finally {
/*  328 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void update(Module module, ModuleRevisionBuilder builder, Object revisionInfo) {
/*  341 */     writeLock();
/*      */     try {
/*  343 */       ModuleRevision oldRevision = module.getCurrentRevision();
/*  344 */       ModuleRevision newRevision = builder.addRevision(module, revisionInfo);
/*  345 */       addCapabilities(newRevision);
/*      */ 
/*      */       
/*  348 */       ModuleWiring oldWiring = this.wirings.get(oldRevision);
/*  349 */       if (oldWiring == null) {
/*  350 */         module.getRevisions().removeRevision(oldRevision);
/*  351 */         removeCapabilities(oldRevision);
/*      */       } 
/*      */       
/*  354 */       cleanupRemovalPending();
/*      */       
/*  356 */       long currentTime = System.currentTimeMillis();
/*  357 */       module.setlastModified(currentTime);
/*  358 */       setSystemLastModified(currentTime);
/*  359 */       incrementTimestamps(true);
/*      */     } finally {
/*  361 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanupRemovalPending() {
/*  373 */     checkWrite();
/*  374 */     Collection<ModuleRevision> removalPending = getRemovalPending();
/*  375 */     for (ModuleRevision removed : removalPending) {
/*  376 */       if (this.wirings.get(removed) == null)
/*      */         continue; 
/*  378 */       Collection<ModuleRevision> dependencyClosure = ModuleContainer.getDependencyClosure(removed, this.wirings);
/*  379 */       boolean allPendingRemoval = true;
/*  380 */       for (ModuleRevision pendingRemoval : dependencyClosure) {
/*  381 */         if (pendingRemoval.isCurrent()) {
/*  382 */           allPendingRemoval = false;
/*      */           break;
/*      */         } 
/*      */       } 
/*  386 */       if (allPendingRemoval) {
/*  387 */         Collection<ModuleWiring> toRemoveWirings = new ArrayList<>();
/*  388 */         Map<ModuleWiring, Collection<ModuleWire>> toRemoveWireLists = new HashMap<>();
/*  389 */         for (ModuleRevision pendingRemoval : dependencyClosure) {
/*  390 */           ModuleWiring removedWiring = this.wirings.get(pendingRemoval);
/*  391 */           if (removedWiring == null) {
/*      */             continue;
/*      */           }
/*  394 */           toRemoveWirings.add(removedWiring);
/*  395 */           List<ModuleWire> removedWires = removedWiring.getRequiredModuleWires(null);
/*  396 */           for (ModuleWire wire : removedWires) {
/*  397 */             Collection<ModuleWire> providerWires = toRemoveWireLists.get(wire.getProviderWiring());
/*  398 */             if (providerWires == null) {
/*  399 */               providerWires = new ArrayList<>();
/*  400 */               toRemoveWireLists.put(wire.getProviderWiring(), providerWires);
/*      */             } 
/*  402 */             providerWires.add(wire);
/*      */           } 
/*      */         } 
/*  405 */         for (ModuleRevision pendingRemoval : dependencyClosure) {
/*  406 */           pendingRemoval.getRevisions().removeRevision(pendingRemoval);
/*  407 */           removeCapabilities(pendingRemoval);
/*  408 */           this.wirings.remove(pendingRemoval);
/*      */         } 
/*      */         
/*  411 */         for (Map.Entry<ModuleWiring, Collection<ModuleWire>> entry : toRemoveWireLists.entrySet()) {
/*  412 */           NamespaceList.Builder<ModuleWire> provided = ((ModuleWiring)entry.getKey()).getProvidedWires().createBuilder();
/*  413 */           provided.removeAll(entry.getValue());
/*  414 */           ((ModuleWiring)entry.getKey()).setProvidedWires(provided.build());
/*  415 */           for (ModuleWire removedWire : entry.getValue())
/*      */           {
/*  417 */             removedWire.invalidate();
/*      */           }
/*      */         } 
/*      */         
/*  421 */         for (ModuleWiring moduleWiring : toRemoveWirings) {
/*  422 */           moduleWiring.invalidate();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Collection<ModuleRevision> getRemovalPending() {
/*  435 */     Collection<ModuleRevision> removalPending = new ArrayList<>();
/*  436 */     readLock();
/*      */     try {
/*  438 */       for (ModuleWiring wiring : this.wirings.values()) {
/*  439 */         if (!wiring.isCurrent())
/*  440 */           removalPending.add(wiring.getRevision()); 
/*      */       } 
/*      */     } finally {
/*  443 */       readUnlock();
/*      */     } 
/*  445 */     return removalPending;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ModuleWiring getWiring(ModuleRevision revision) {
/*  457 */     readLock();
/*      */     try {
/*  459 */       return this.wirings.get(revision);
/*      */     } finally {
/*  461 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Map<ModuleRevision, ModuleWiring> getWiringsCopy() {
/*  473 */     readLock();
/*      */     try {
/*  475 */       return new HashMap<>(this.wirings);
/*      */     } finally {
/*  477 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Map<ModuleRevision, ModuleWiring> getWiringsClone() {
/*  501 */     readLock();
/*      */     try {
/*  503 */       Map<ModuleRevision, ModuleWiring> clonedWirings = new HashMap<>(this.wirings);
/*  504 */       clonedWirings.replaceAll(new BiFunction<ModuleRevision, ModuleWiring, ModuleWiring>() {
/*      */             public ModuleWiring apply(ModuleRevision r, ModuleWiring w) {
/*  506 */               return new ModuleWiring(r, w.getCapabilities(), w.getRequirements(), w.getProvidedWires(), 
/*  507 */                   w.getRequiredWires(), w.getSubstitutedNames());
/*      */             }
/*      */           });
/*  510 */       return clonedWirings;
/*      */     } finally {
/*  512 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setWiring(Map<ModuleRevision, ModuleWiring> newWiring) {
/*  524 */     writeLock();
/*      */     try {
/*  526 */       this.wirings.clear();
/*  527 */       this.wirings.putAll(newWiring);
/*  528 */       incrementTimestamps(true);
/*      */     } finally {
/*  530 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void mergeWiring(Map<ModuleRevision, ModuleWiring> deltaWiring) {
/*  543 */     writeLock();
/*      */     try {
/*  545 */       this.wirings.putAll(deltaWiring);
/*  546 */       incrementTimestamps(true);
/*      */     } finally {
/*  548 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void writeLockOperation(boolean incrementRevision, Runnable op) {
/*  563 */     writeLock();
/*      */     try {
/*  565 */       op.run();
/*  566 */       incrementTimestamps(incrementRevision);
/*      */     } finally {
/*  568 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final List<Module> getModules() {
/*  579 */     return getSortedModules(new Sort[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final List<Module> getSortedModules(Sort... sortOptions) {
/*  588 */     readLock();
/*      */     try {
/*  590 */       List<Module> modules = new ArrayList<>(this.modulesByLocations.values());
/*  591 */       sortModules(modules, sortOptions);
/*  592 */       return modules;
/*      */     } finally {
/*  594 */       readUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void sortModules(List<Module> modules, Sort... sortOptions) {
/*  599 */     if (modules.size() < 2)
/*      */       return; 
/*  601 */     if (sortOptions == null || Sort.BY_ID.isContained(sortOptions) || sortOptions.length == 0) {
/*  602 */       Collections.sort(modules, new Comparator<Module>()
/*      */           {
/*      */             public int compare(Module m1, Module m2) {
/*  605 */               return m1.getId().compareTo(m2.getId());
/*      */             }
/*      */           });
/*      */       
/*      */       return;
/*      */     } 
/*  611 */     if (Sort.BY_START_LEVEL.isContained(sortOptions)) {
/*  612 */       Collections.sort(modules);
/*      */     }
/*  614 */     if (Sort.BY_DEPENDENCY.isContained(sortOptions)) {
/*  615 */       if (Sort.BY_START_LEVEL.isContained(sortOptions)) {
/*      */         
/*  617 */         int currentSL = ((Module)modules.get(0)).getStartLevel();
/*  618 */         int currentSLindex = 0;
/*  619 */         boolean lazy = false;
/*  620 */         for (int i = 0; i < modules.size(); i++) {
/*  621 */           Module module = modules.get(i);
/*  622 */           if (currentSL != module.getStartLevel()) {
/*  623 */             if (lazy)
/*  624 */               sortByDependencies(modules.subList(currentSLindex, i)); 
/*  625 */             currentSL = module.getStartLevel();
/*  626 */             currentSLindex = i;
/*  627 */             lazy = false;
/*      */           } 
/*  629 */           lazy |= module.isLazyActivate(new Module.StartOptions[0]);
/*      */         } 
/*      */         
/*  632 */         if (lazy) {
/*  633 */           sortByDependencies(modules.subList(currentSLindex, modules.size()));
/*      */         }
/*      */       } else {
/*  636 */         sortByDependencies(modules);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private Collection<List<Module>> sortByDependencies(List<Module> toSort) {
/*  643 */     List<Module[]> references = (List)new ArrayList<>(toSort.size());
/*  644 */     for (Module module : toSort) {
/*  645 */       ModuleRevision current = module.getCurrentRevision();
/*  646 */       if (current == null) {
/*      */         continue;
/*      */       }
/*  649 */       ModuleWiring wiring = current.getWiring();
/*  650 */       if (wiring == null) {
/*      */         continue;
/*      */       }
/*      */       
/*  654 */       for (ModuleWire wire : wiring.getRequiredModuleWires(null)) {
/*  655 */         ModuleRequirement req = wire.getRequirement();
/*      */ 
/*      */ 
/*      */         
/*  659 */         if (!"osgi.wiring.package".equals(req.getNamespace()) || !"dynamic".equals(req.getDirectives().get("resolution"))) {
/*  660 */           references.add(new Module[] { wire.getRequirer().getRevisions().getModule(), wire.getProvider().getRevisions().getModule() });
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  666 */     Module[] sorted = toSort.<Module>toArray(new Module[toSort.size()]);
/*  667 */     Object[][] cycles = ComputeNodeOrder.computeNodeOrder((Object[])sorted, (Object[][])references.toArray((Object[])new Module[references.size()][]));
/*      */ 
/*      */     
/*  670 */     toSort.clear();
/*  671 */     toSort.addAll(Arrays.asList(sorted));
/*      */     
/*  673 */     if (cycles.length == 0) {
/*  674 */       return Collections.emptyList();
/*      */     }
/*  676 */     Collection<List<Module>> moduleCycles = new ArrayList<>(cycles.length); byte b; int i; Object[][] arrayOfObject1;
/*  677 */     for (i = (arrayOfObject1 = cycles).length, b = 0; b < i; ) { Object[] cycle = arrayOfObject1[b];
/*  678 */       List<Module> moduleCycle = new ArrayList<>(cycle.length); byte b1; int j; Object[] arrayOfObject2;
/*  679 */       for (j = (arrayOfObject2 = cycle).length, b1 = 0; b1 < j; ) { Object module = arrayOfObject2[b1];
/*  680 */         moduleCycle.add((Module)module); b1++; }
/*      */       
/*  682 */       moduleCycles.add(moduleCycle); b++; }
/*      */     
/*  684 */     return moduleCycles;
/*      */   }
/*      */   
/*      */   private void checkWrite() {
/*  688 */     if (this.monitor.getWriteHoldCount() == 0) {
/*  689 */       throw new IllegalMonitorStateException("Must hold the write lock.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getNextId() {
/*  699 */     readLock();
/*      */     try {
/*  701 */       return this.nextId.get();
/*      */     } finally {
/*  703 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getAndIncrementNextId() {
/*  715 */     writeLock();
/*      */     try {
/*  717 */       return this.nextId.getAndIncrement();
/*      */     } finally {
/*  719 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getRevisionsTimestamp() {
/*  738 */     readLock();
/*      */     try {
/*  740 */       return this.revisionsTimeStamp.get();
/*      */     } finally {
/*  742 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getTimestamp() {
/*  762 */     readLock();
/*      */     try {
/*  764 */       return this.allTimeStamp.get();
/*      */     } finally {
/*  766 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void incrementTimestamps(boolean incrementRevision) {
/*  776 */     checkWrite();
/*  777 */     if (incrementRevision) {
/*  778 */       this.revisionsTimeStamp.incrementAndGet();
/*      */     }
/*  780 */     this.allTimeStamp.incrementAndGet();
/*  781 */     this.adaptor.updatedDatabase();
/*      */   }
/*      */ 
/*      */   
/*      */   private void setSystemLastModified(long currentTime) {
/*  786 */     checkWrite();
/*  787 */     Module systemModule = getModule(0L);
/*  788 */     if (systemModule != null) {
/*  789 */       systemModule.setlastModified(currentTime);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void readLock() {
/*  798 */     this.monitor.readLock().lock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeLock() {
/*  811 */     if (this.monitor.getReadHoldCount() > 0)
/*      */     {
/*      */       
/*  814 */       throw new IllegalMonitorStateException("Requesting upgrade to write lock.");
/*      */     }
/*  816 */     this.monitor.writeLock().lock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void readUnlock() {
/*  824 */     this.monitor.readLock().unlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeUnlock() {
/*  832 */     this.monitor.writeLock().unlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addCapabilities(ModuleRevision revision) {
/*  845 */     checkWrite();
/*  846 */     Collection<String> packageNames = this.capabilities.addCapabilities(revision);
/*      */     
/*  848 */     for (ModuleWiring wiring : this.wirings.values()) {
/*  849 */       wiring.removeDynamicPackageMisses(packageNames);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeCapabilities(ModuleRevision revision) {
/*  863 */     checkWrite();
/*  864 */     this.capabilities.removeCapabilities(revision);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final List<ModuleCapability> findCapabilities(Requirement requirement) {
/*  878 */     readLock();
/*      */     try {
/*  880 */       return this.capabilities.findCapabilities(requirement);
/*      */     } finally {
/*  882 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void store(DataOutputStream out, boolean persistWirings) throws IOException {
/*  905 */     readLock();
/*      */     try {
/*  907 */       Persistence.store(this, out, persistWirings);
/*      */     } finally {
/*  909 */       readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void load(DataInputStream in) throws IOException {
/*  929 */     writeLock();
/*      */     try {
/*  931 */       if (this.allTimeStamp.get() != this.constructionTime)
/*  932 */         throw new IllegalStateException("Can only load into a empty database."); 
/*  933 */       Persistence.load(this, in);
/*      */     } finally {
/*  935 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void persistSettings(EnumSet<Module.Settings> settings, Module module) {
/*  940 */     writeLock();
/*      */     try {
/*  942 */       EnumSet<Module.Settings> existing = this.moduleSettings.get(module.getId());
/*  943 */       if (!settings.equals(existing)) {
/*  944 */         this.moduleSettings.put(module.getId(), EnumSet.copyOf(settings));
/*  945 */         incrementTimestamps(false);
/*      */       } 
/*      */     } finally {
/*  948 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void setStartLevel(Module module, int startlevel) {
/*  953 */     writeLock();
/*      */     try {
/*  955 */       module.checkValid();
/*  956 */       module.storeStartLevel(startlevel);
/*  957 */       incrementTimestamps(false);
/*      */     } finally {
/*  959 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final int getInitialModuleStartLevel() {
/*  964 */     readLock();
/*      */     try {
/*  966 */       return this.initialModuleStartLevel;
/*      */     } finally {
/*  968 */       readUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void setInitialModuleStartLevel(int initialStartlevel) {
/*  973 */     writeLock();
/*      */     try {
/*  975 */       this.initialModuleStartLevel = initialStartlevel;
/*  976 */       incrementTimestamps(false);
/*      */     } finally {
/*  978 */       writeUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Persistence
/*      */   {
/*      */     private static final int VERSION = 3;
/*      */     
/*      */     private static final byte NULL = 0;
/*      */     
/*      */     private static final byte OBJECT = 1;
/*      */     
/*      */     private static final byte INDEX = 2;
/*      */     private static final byte LONG_STRING = 3;
/*      */     private static final byte VALUE_STRING = 0;
/*      */     private static final byte VALUE_LONG = 4;
/*      */     private static final byte VALUE_DOUBLE = 5;
/*      */     private static final byte VALUE_VERSION = 6;
/*      */     private static final byte VALUE_LIST = 8;
/*      */     
/*      */     private static int addToWriteTable(Object object, Map<Object, Integer> objectTable) {
/* 1000 */       if (object == null)
/* 1001 */         throw new NullPointerException(); 
/* 1002 */       Integer cur = objectTable.get(object);
/* 1003 */       if (cur != null)
/* 1004 */         throw new IllegalStateException("Object is already in the write table: " + object); 
/* 1005 */       objectTable.put(object, Integer.valueOf(objectTable.size()));
/*      */       
/* 1007 */       return objectTable.size() - 1;
/*      */     }
/*      */     
/*      */     private static void addToReadTable(Object object, int index, List<Object> objectTable) {
/* 1011 */       if (index == objectTable.size()) {
/* 1012 */         objectTable.add(object);
/* 1013 */       } else if (index < objectTable.size()) {
/* 1014 */         objectTable.set(index, object);
/*      */       } else {
/* 1016 */         while (objectTable.size() < index) {
/* 1017 */           objectTable.add(null);
/*      */         }
/* 1019 */         objectTable.add(object);
/*      */       } 
/*      */     }
/*      */     
/*      */     public static void store(ModuleDatabase moduleDatabase, DataOutputStream out, boolean persistWirings) throws IOException {
/* 1024 */       out.writeInt(3);
/* 1025 */       out.writeLong(moduleDatabase.getRevisionsTimestamp());
/* 1026 */       out.writeLong(moduleDatabase.getTimestamp());
/* 1027 */       out.writeLong(moduleDatabase.getNextId());
/* 1028 */       out.writeInt(moduleDatabase.getInitialModuleStartLevel());
/*      */ 
/*      */       
/* 1031 */       Set<String> allStrings = new HashSet<>();
/* 1032 */       Set<Version> allVersions = new HashSet<>();
/* 1033 */       Set<Map<String, ?>> allMaps = new HashSet<>();
/*      */ 
/*      */       
/* 1036 */       List<Module> modules = moduleDatabase.getModules();
/* 1037 */       for (Module module : modules) {
/* 1038 */         getStringsVersionsAndMaps(module, moduleDatabase, allStrings, allVersions, allMaps);
/*      */       }
/*      */       
/* 1041 */       Map<ModuleRevision, ModuleWiring> wirings = moduleDatabase.wirings;
/* 1042 */       for (ModuleWiring wiring : wirings.values()) {
/* 1043 */         Collection<String> substituted = wiring.getSubstitutedNames();
/* 1044 */         allStrings.addAll(substituted);
/*      */       } 
/*      */ 
/*      */       
/* 1048 */       Map<Object, Integer> objectTable = new HashMap<>();
/* 1049 */       allStrings.remove(null);
/* 1050 */       out.writeInt(allStrings.size());
/* 1051 */       for (String string : allStrings) {
/* 1052 */         writeString(string, out, objectTable);
/* 1053 */         out.writeInt(addToWriteTable(string, objectTable));
/*      */       } 
/*      */       
/* 1056 */       out.writeInt(allVersions.size());
/* 1057 */       for (Version version : allVersions) {
/* 1058 */         writeVersion(version, out, objectTable);
/* 1059 */         out.writeInt(addToWriteTable(version, objectTable));
/*      */       } 
/*      */       
/* 1062 */       out.writeInt(allMaps.size());
/* 1063 */       for (Map<String, ?> map : allMaps) {
/* 1064 */         writeMap(map, out, objectTable, moduleDatabase);
/* 1065 */         out.writeInt(addToWriteTable(map, objectTable));
/*      */       } 
/*      */ 
/*      */       
/* 1069 */       out.writeInt(modules.size());
/* 1070 */       for (Module module : modules) {
/* 1071 */         writeModule(module, moduleDatabase, out, objectTable);
/*      */       }
/*      */       
/* 1074 */       Collection<ModuleRevision> removalPendings = moduleDatabase.getRemovalPending();
/*      */       
/* 1076 */       persistWirings &= removalPendings.isEmpty();
/* 1077 */       out.writeBoolean(persistWirings);
/* 1078 */       if (!persistWirings) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1083 */       out.writeInt(wirings.size());
/* 1084 */       for (ModuleWiring wiring : wirings.values()) {
/* 1085 */         List<ModuleWire> requiredWires = wiring.getPersistentRequiredWires();
/* 1086 */         out.writeInt(requiredWires.size());
/* 1087 */         for (ModuleWire wire : requiredWires) {
/* 1088 */           writeWire(wire, out, objectTable);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1093 */       for (ModuleWiring wiring : wirings.values()) {
/* 1094 */         writeWiring(wiring, out, objectTable);
/*      */       }
/*      */       
/* 1097 */       out.flush();
/*      */     }
/*      */     
/*      */     private static void getStringsVersionsAndMaps(Module module, ModuleDatabase moduleDatabase, Set<String> allStrings, Set<Version> allVersions, Set<Map<String, ?>> allMaps) {
/* 1101 */       ModuleRevision current = module.getCurrentRevision();
/* 1102 */       if (current == null) {
/*      */         return;
/*      */       }
/* 1105 */       allStrings.add(module.getLocation());
/* 1106 */       allStrings.add(current.getSymbolicName());
/* 1107 */       allStrings.add(current.getVersion().getQualifier());
/* 1108 */       allVersions.add(current.getVersion());
/* 1109 */       EnumSet<Module.Settings> settings = moduleDatabase.moduleSettings.get(module.getId());
/* 1110 */       if (settings != null) {
/* 1111 */         for (Module.Settings setting : settings) {
/* 1112 */           allStrings.add(setting.toString());
/*      */         }
/*      */       }
/*      */       
/* 1116 */       List<ModuleCapability> capabilities = current.getModuleCapabilities(null);
/* 1117 */       for (ModuleCapability capability : capabilities) {
/* 1118 */         allStrings.add(capability.getNamespace());
/* 1119 */         addMap(capability.getPersistentAttributes(), allStrings, allVersions, allMaps);
/* 1120 */         addMap(capability.getDirectives(), allStrings, allVersions, allMaps);
/*      */       } 
/*      */       
/* 1123 */       List<ModuleRequirement> requirements = current.getModuleRequirements(null);
/* 1124 */       for (ModuleRequirement requirement : requirements) {
/* 1125 */         allStrings.add(requirement.getNamespace());
/* 1126 */         addMap(requirement.getAttributes(), allStrings, allVersions, allMaps);
/* 1127 */         addMap(requirement.getDirectives(), allStrings, allVersions, allMaps);
/*      */       } 
/*      */     }
/*      */     
/*      */     private static void addMap(Map<String, ?> map, Set<String> allStrings, Set<Version> allVersions, Set<Map<String, ?>> allMaps) {
/* 1132 */       if (!allMaps.add(map)) {
/*      */         return;
/*      */       }
/*      */       
/* 1136 */       for (Map.Entry<String, ?> entry : map.entrySet()) {
/* 1137 */         allStrings.add(entry.getKey());
/* 1138 */         Object value = entry.getValue();
/* 1139 */         if (value instanceof String) {
/* 1140 */           allStrings.add((String)value); continue;
/* 1141 */         }  if (value instanceof Version) {
/* 1142 */           allStrings.add(((Version)value).getQualifier());
/* 1143 */           allVersions.add((Version)value); continue;
/* 1144 */         }  if (value instanceof List) {
/* 1145 */           switch (getListType((List)value)) {
/*      */             case 0:
/* 1147 */               for (Object string : value) {
/* 1148 */                 allStrings.add((String)string);
/*      */               }
/*      */             
/*      */             case 6:
/* 1152 */               for (Object version : value) {
/* 1153 */                 allStrings.add(((Version)version).getQualifier());
/* 1154 */                 allVersions.add((Version)version);
/*      */               } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public static void load(ModuleDatabase moduleDatabase, DataInputStream in) throws IOException {
/* 1163 */       int version = in.readInt();
/* 1164 */       if (version > 3 || version / 1000 != 0)
/* 1165 */         throw new IllegalArgumentException("The version of the persistent framework data is not compatible: " + version + " expecting: " + '\003'); 
/* 1166 */       long revisionsTimeStamp = in.readLong();
/* 1167 */       long allTimeStamp = in.readLong();
/* 1168 */       moduleDatabase.nextId.set(in.readLong());
/* 1169 */       moduleDatabase.setInitialModuleStartLevel(in.readInt());
/*      */       
/* 1171 */       List<Object> objectTable = new ArrayList();
/*      */       
/* 1173 */       if (version >= 2) {
/* 1174 */         int numStrings = in.readInt();
/* 1175 */         for (int m = 0; m < numStrings; m++) {
/* 1176 */           readIndexedString(in, objectTable);
/*      */         }
/* 1178 */         int numVersions = in.readInt();
/* 1179 */         for (int n = 0; n < numVersions; n++) {
/* 1180 */           readIndexedVersion(in, objectTable);
/*      */         }
/* 1182 */         int numMaps = in.readInt();
/* 1183 */         for (int i1 = 0; i1 < numMaps; i1++) {
/* 1184 */           readIndexedMap(in, objectTable);
/*      */         }
/*      */       } 
/* 1187 */       int numModules = in.readInt();
/* 1188 */       ModuleRevisionBuilder builder = new ModuleRevisionBuilder();
/* 1189 */       for (int i = 0; i < numModules; i++) {
/* 1190 */         readModule(builder, moduleDatabase, in, objectTable, version);
/*      */       }
/*      */       
/* 1193 */       moduleDatabase.revisionsTimeStamp.set(revisionsTimeStamp);
/* 1194 */       moduleDatabase.allTimeStamp.set(allTimeStamp);
/* 1195 */       if (!in.readBoolean()) {
/*      */         return;
/*      */       }
/* 1198 */       int numWirings = in.readInt();
/*      */       
/* 1200 */       for (int j = 0; j < numWirings; j++) {
/* 1201 */         int numWires = in.readInt();
/* 1202 */         for (int m = 0; m < numWires; m++) {
/* 1203 */           readWire(in, objectTable);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1208 */       Map<ModuleRevision, ModuleWiring> wirings = new HashMap<>();
/* 1209 */       for (int k = 0; k < numWirings; k++) {
/* 1210 */         ModuleWiring wiring = readWiring(in, objectTable);
/* 1211 */         wirings.put(wiring.getRevision(), wiring);
/*      */       } 
/*      */       
/* 1214 */       moduleDatabase.setWiring(wirings);
/*      */ 
/*      */       
/* 1217 */       for (ModuleWiring wiring : wirings.values()) {
/* 1218 */         wiring.getRevision().getRevisions().getModule().setState(Module.State.RESOLVED);
/*      */       }
/*      */ 
/*      */       
/* 1222 */       moduleDatabase.revisionsTimeStamp.set(revisionsTimeStamp);
/* 1223 */       moduleDatabase.allTimeStamp.set(allTimeStamp);
/*      */     }
/*      */     
/*      */     private static void writeModule(Module module, ModuleDatabase moduleDatabase, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1227 */       ModuleRevision current = module.getCurrentRevision();
/* 1228 */       if (current == null)
/*      */         return; 
/* 1230 */       out.writeInt(addToWriteTable(current, objectTable));
/*      */       
/* 1232 */       writeString(module.getLocation(), out, objectTable);
/* 1233 */       out.writeLong(module.getId().longValue());
/*      */       
/* 1235 */       writeString(current.getSymbolicName(), out, objectTable);
/* 1236 */       writeVersion(current.getVersion(), out, objectTable);
/* 1237 */       out.writeInt(current.getTypes());
/*      */       
/* 1239 */       List<ModuleCapability> capabilities = current.getModuleCapabilities(null);
/* 1240 */       out.writeInt(capabilities.size());
/* 1241 */       for (ModuleCapability capability : capabilities) {
/* 1242 */         out.writeInt(addToWriteTable(capability, objectTable));
/* 1243 */         writeGenericInfo(capability.getNamespace(), capability.getPersistentAttributes(), capability.getDirectives(), out, objectTable);
/*      */       } 
/*      */       
/* 1246 */       List<Requirement> requirements = current.getRequirements(null);
/* 1247 */       out.writeInt(requirements.size());
/* 1248 */       for (Requirement requirement : requirements) {
/* 1249 */         out.writeInt(addToWriteTable(requirement, objectTable));
/* 1250 */         writeGenericInfo(requirement.getNamespace(), requirement.getAttributes(), requirement.getDirectives(), out, objectTable);
/*      */       } 
/*      */ 
/*      */       
/* 1254 */       EnumSet<Module.Settings> settings = moduleDatabase.moduleSettings.get(module.getId());
/* 1255 */       out.writeInt((settings == null) ? 0 : settings.size());
/* 1256 */       if (settings != null) {
/* 1257 */         for (Module.Settings setting : settings) {
/* 1258 */           writeString(setting.name(), out, objectTable);
/*      */         }
/*      */       }
/*      */ 
/*      */       
/* 1263 */       out.writeInt(module.getStartLevel());
/*      */ 
/*      */       
/* 1266 */       out.writeLong(module.getLastModified());
/*      */     }
/*      */     
/*      */     private static void readModule(ModuleRevisionBuilder builder, ModuleDatabase moduleDatabase, DataInputStream in, List<Object> objectTable, int version) throws IOException {
/* 1270 */       builder.clear();
/* 1271 */       int moduleIndex = in.readInt();
/* 1272 */       String location = readString(in, objectTable);
/* 1273 */       long id = in.readLong();
/* 1274 */       builder.setSymbolicName(readString(in, objectTable));
/* 1275 */       builder.setVersion(readVersion(in, objectTable));
/* 1276 */       builder.setTypes(in.readInt());
/*      */       
/* 1278 */       int numCapabilities = in.readInt();
/* 1279 */       int[] capabilityIndexes = new int[numCapabilities];
/* 1280 */       for (int i = 0; i < numCapabilities; i++) {
/* 1281 */         capabilityIndexes[i] = in.readInt();
/* 1282 */         readGenericInfo(true, in, builder, objectTable, version);
/*      */       } 
/*      */       
/* 1285 */       int numRequirements = in.readInt();
/* 1286 */       int[] requirementIndexes = new int[numRequirements];
/* 1287 */       for (int j = 0; j < numRequirements; j++) {
/* 1288 */         requirementIndexes[j] = in.readInt();
/* 1289 */         readGenericInfo(false, in, builder, objectTable, version);
/*      */       } 
/*      */ 
/*      */       
/* 1293 */       EnumSet<Module.Settings> settings = null;
/* 1294 */       int numSettings = in.readInt();
/* 1295 */       if (numSettings > 0) {
/* 1296 */         settings = EnumSet.noneOf(Module.Settings.class);
/* 1297 */         for (int n = 0; n < numSettings; n++) {
/* 1298 */           settings.add(Module.Settings.valueOf(readString(in, objectTable)));
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1303 */       int startlevel = in.readInt();
/* 1304 */       Object revisionInfo = moduleDatabase.adaptor.getRevisionInfo(location, id);
/* 1305 */       Module module = moduleDatabase.load(location, builder, revisionInfo, id, settings, startlevel);
/*      */ 
/*      */       
/* 1308 */       module.setlastModified(in.readLong());
/*      */       
/* 1310 */       ModuleRevision current = module.getCurrentRevision();
/* 1311 */       addToReadTable(current, moduleIndex, objectTable);
/*      */       
/* 1313 */       List<ModuleCapability> capabilities = current.getModuleCapabilities(null);
/* 1314 */       for (int k = 0; k < capabilities.size(); k++) {
/* 1315 */         addToReadTable(capabilities.get(k), capabilityIndexes[k], objectTable);
/*      */       }
/*      */       
/* 1318 */       List<ModuleRequirement> requirements = current.getModuleRequirements(null);
/* 1319 */       for (int m = 0; m < requirements.size(); m++) {
/* 1320 */         addToReadTable(requirements.get(m), requirementIndexes[m], objectTable);
/*      */       }
/*      */     }
/*      */     
/*      */     private static void writeWire(ModuleWire wire, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1325 */       ModuleWire moduleWire = wire;
/* 1326 */       Integer capability = objectTable.get(moduleWire.getCapability());
/* 1327 */       Integer provider = objectTable.get(moduleWire.getProvider());
/* 1328 */       Integer requirement = objectTable.get(moduleWire.getRequirement());
/* 1329 */       Integer requirer = objectTable.get(moduleWire.getRequirer());
/*      */       
/* 1331 */       if (capability == null || provider == null || requirement == null || requirer == null) {
/* 1332 */         throw new NullPointerException("Could not find the expected indexes");
/*      */       }
/* 1334 */       out.writeInt(addToWriteTable(wire, objectTable));
/*      */       
/* 1336 */       out.writeInt(capability.intValue());
/* 1337 */       out.writeInt(provider.intValue());
/* 1338 */       out.writeInt(requirement.intValue());
/* 1339 */       out.writeInt(requirer.intValue());
/*      */     }
/*      */     
/*      */     private static void readWire(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1343 */       int wireIndex = in.readInt();
/*      */       
/* 1345 */       ModuleCapability capability = (ModuleCapability)objectTable.get(in.readInt());
/* 1346 */       ModuleRevision provider = (ModuleRevision)objectTable.get(in.readInt());
/* 1347 */       ModuleRequirement requirement = (ModuleRequirement)objectTable.get(in.readInt());
/* 1348 */       ModuleRevision requirer = (ModuleRevision)objectTable.get(in.readInt());
/*      */       
/* 1350 */       if (capability == null || provider == null || requirement == null || requirer == null) {
/* 1351 */         throw new NullPointerException("Could not find the expected indexes");
/*      */       }
/* 1353 */       ModuleWire result = new ModuleWire(capability, provider, requirement, requirer);
/*      */       
/* 1355 */       addToReadTable(result, wireIndex, objectTable);
/*      */     }
/*      */     
/*      */     private static void writeWiring(ModuleWiring wiring, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1359 */       Integer revisionIndex = objectTable.get(wiring.getRevision());
/* 1360 */       if (revisionIndex == null)
/* 1361 */         throw new NullPointerException("Could not find revision for wiring."); 
/* 1362 */       out.writeInt(revisionIndex.intValue());
/*      */       
/* 1364 */       List<ModuleCapability> capabilities = wiring.getModuleCapabilities(null);
/* 1365 */       out.writeInt(capabilities.size());
/* 1366 */       for (ModuleCapability capability : capabilities) {
/* 1367 */         Integer capabilityIndex = objectTable.get(capability);
/* 1368 */         if (capabilityIndex == null)
/* 1369 */           throw new NullPointerException("Could not find capability for wiring."); 
/* 1370 */         out.writeInt(capabilityIndex.intValue());
/*      */       } 
/*      */       
/* 1373 */       List<ModuleRequirement> requirements = wiring.getPersistentRequirements();
/* 1374 */       out.writeInt(requirements.size());
/* 1375 */       for (ModuleRequirement requirement : requirements) {
/* 1376 */         Integer requirementIndex = objectTable.get(requirement);
/* 1377 */         if (requirementIndex == null)
/* 1378 */           throw new NullPointerException("Could not find requirement for wiring."); 
/* 1379 */         out.writeInt(requirementIndex.intValue());
/*      */       } 
/*      */       
/* 1382 */       List<ModuleWire> providedWires = wiring.getPersistentProvidedWires();
/* 1383 */       out.writeInt(providedWires.size());
/* 1384 */       for (ModuleWire wire : providedWires) {
/* 1385 */         Integer wireIndex = objectTable.get(wire);
/* 1386 */         if (wireIndex == null)
/* 1387 */           throw new NullPointerException("Could not find provided wire for wiring."); 
/* 1388 */         out.writeInt(wireIndex.intValue());
/*      */       } 
/*      */       
/* 1391 */       List<ModuleWire> requiredWires = wiring.getPersistentRequiredWires();
/* 1392 */       out.writeInt(requiredWires.size());
/* 1393 */       for (ModuleWire wire : requiredWires) {
/* 1394 */         Integer wireIndex = objectTable.get(wire);
/* 1395 */         if (wireIndex == null)
/* 1396 */           throw new NullPointerException("Could not find required wire for wiring."); 
/* 1397 */         out.writeInt(wireIndex.intValue());
/*      */       } 
/*      */       
/* 1400 */       Collection<String> substituted = wiring.getSubstitutedNames();
/* 1401 */       out.writeInt(substituted.size());
/* 1402 */       for (String pkgName : substituted) {
/* 1403 */         writeString(pkgName, out, objectTable);
/*      */       }
/*      */     }
/*      */     
/*      */     private static ModuleWiring readWiring(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1408 */       ModuleRevision revision = (ModuleRevision)objectTable.get(in.readInt());
/* 1409 */       if (revision == null) {
/* 1410 */         throw new NullPointerException("Could not find revision for wiring.");
/*      */       }
/* 1412 */       int numCapabilities = in.readInt();
/* 1413 */       NamespaceList.Builder<ModuleCapability> capabilities = NamespaceList.Builder.create(NamespaceList.CAPABILITY);
/* 1414 */       for (int i = 0; i < numCapabilities; i++) {
/* 1415 */         capabilities.add(objectTable.get(in.readInt()));
/*      */       }
/*      */       
/* 1418 */       int numRequirements = in.readInt();
/* 1419 */       NamespaceList.Builder<ModuleRequirement> requirements = NamespaceList.Builder.create(NamespaceList.REQUIREMENT);
/* 1420 */       for (int j = 0; j < numRequirements; j++) {
/* 1421 */         requirements.add(objectTable.get(in.readInt()));
/*      */       }
/*      */       
/* 1424 */       int numProvidedWires = in.readInt();
/* 1425 */       NamespaceList.Builder<ModuleWire> providedWires = NamespaceList.Builder.create(NamespaceList.WIRE);
/* 1426 */       for (int k = 0; k < numProvidedWires; k++) {
/* 1427 */         providedWires.add(objectTable.get(in.readInt()));
/*      */       }
/*      */       
/* 1430 */       int numRequiredWires = in.readInt();
/* 1431 */       NamespaceList.Builder<ModuleWire> requiredWires = NamespaceList.Builder.create(NamespaceList.WIRE);
/* 1432 */       for (int m = 0; m < numRequiredWires; m++) {
/* 1433 */         requiredWires.add(objectTable.get(in.readInt()));
/*      */       }
/*      */       
/* 1436 */       int numSubstitutedNames = in.readInt();
/* 1437 */       Collection<String> substituted = new ArrayList<>(numSubstitutedNames);
/* 1438 */       for (int n = 0; n < numSubstitutedNames; n++) {
/* 1439 */         substituted.add(readString(in, objectTable));
/*      */       }
/*      */       
/* 1442 */       return new ModuleWiring(revision, capabilities.build(), requirements.build(), providedWires.build(), 
/* 1443 */           requiredWires.build(), substituted);
/*      */     }
/*      */     
/*      */     private static void writeGenericInfo(String namespace, Map<String, ?> attributes, Map<String, String> directives, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1447 */       writeString(namespace, out, objectTable);
/*      */       
/* 1449 */       Integer attributesIndex = objectTable.get(attributes);
/* 1450 */       Integer directivesIndex = objectTable.get(directives);
/* 1451 */       if (attributesIndex == null || directivesIndex == null)
/* 1452 */         throw new NullPointerException("Could not find the expected indexes"); 
/* 1453 */       out.writeInt(attributesIndex.intValue());
/* 1454 */       out.writeInt(directivesIndex.intValue());
/*      */     }
/*      */ 
/*      */     
/*      */     private static void readGenericInfo(boolean isCapability, DataInputStream in, ModuleRevisionBuilder builder, List<Object> objectTable, int version) throws IOException {
/* 1459 */       String namespace = readString(in, objectTable);
/* 1460 */       Map<String, Object> attributes = (version >= 2) ? (Map<String, Object>)objectTable.get(in.readInt()) : readMap(in, objectTable);
/* 1461 */       Map<String, ?> directives = (version >= 2) ? (Map<String, ?>)objectTable.get(in.readInt()) : readMap(in, objectTable);
/* 1462 */       if (attributes == null || directives == null)
/* 1463 */         throw new NullPointerException("Could not find the expected indexes"); 
/* 1464 */       if (isCapability) {
/* 1465 */         builder.basicAddCapability(namespace, (Map)directives, attributes);
/*      */       } else {
/* 1467 */         builder.basicAddRequirement(namespace, (Map)directives, attributes);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private static void writeMap(Map<String, ?> source, DataOutputStream out, Map<Object, Integer> objectTable, ModuleDatabase moduleDatabase) throws IOException {
/* 1473 */       if (source == null) {
/* 1474 */         out.writeInt(0);
/*      */       } else {
/* 1476 */         out.writeInt(source.size());
/* 1477 */         for (String key : source.keySet()) {
/* 1478 */           Object value = source.get(key);
/* 1479 */           writeString(key, out, objectTable);
/* 1480 */           if (value instanceof String) {
/* 1481 */             out.writeByte(0);
/* 1482 */             writeString((String)value, out, objectTable); continue;
/* 1483 */           }  if (value instanceof Long) {
/* 1484 */             out.writeByte(4);
/* 1485 */             out.writeLong(((Long)value).longValue()); continue;
/* 1486 */           }  if (value instanceof Double) {
/* 1487 */             out.writeByte(5);
/* 1488 */             out.writeDouble(((Double)value).doubleValue()); continue;
/* 1489 */           }  if (value instanceof Version) {
/* 1490 */             out.writeByte(6);
/* 1491 */             writeVersion((Version)value, out, objectTable); continue;
/* 1492 */           }  if (value instanceof List) {
/* 1493 */             out.writeByte(8);
/* 1494 */             writeList(out, key, (List)value, objectTable, moduleDatabase);
/*      */             
/*      */             continue;
/*      */           } 
/* 1498 */           moduleDatabase.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, moduleDatabase.getModule(0L), (Throwable)new BundleException("Invalid map value: " + key + " = " + value.getClass().getName() + '[' + value + ']'), new org.osgi.framework.FrameworkListener[0]);
/* 1499 */           out.writeByte(0);
/* 1500 */           writeString(String.valueOf(value), out, objectTable);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private static void readIndexedMap(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1507 */       Map<String, Object> result = readMap(in, objectTable);
/* 1508 */       addToReadTable(result, in.readInt(), objectTable);
/*      */     }
/*      */     private static Map<String, Object> readMap(DataInputStream in, List<Object> objectTable) throws IOException {
/*      */       Map<String, Object> result;
/* 1512 */       int count = in.readInt();
/*      */       
/* 1514 */       if (count == 0) {
/* 1515 */         result = Collections.emptyMap();
/* 1516 */       } else if (count == 1) {
/* 1517 */         String key = readString(in, objectTable);
/* 1518 */         byte type = in.readByte();
/* 1519 */         Object value = readMapValue(in, type, objectTable);
/* 1520 */         result = Collections.singletonMap(key, value);
/*      */       } else {
/* 1522 */         result = new HashMap<>(count);
/* 1523 */         for (int i = 0; i < count; i++) {
/* 1524 */           String key = readString(in, objectTable);
/* 1525 */           byte type = in.readByte();
/* 1526 */           Object value = readMapValue(in, type, objectTable);
/* 1527 */           result.put(key, value);
/*      */         } 
/* 1529 */         result = Collections.unmodifiableMap(result);
/*      */       } 
/* 1531 */       return result;
/*      */     }
/*      */     
/*      */     private static Object readMapValue(DataInputStream in, int type, List<Object> objectTable) throws IOException {
/* 1535 */       switch (type) {
/*      */         case 0:
/* 1537 */           return readString(in, objectTable);
/*      */         case 4:
/* 1539 */           return Long.valueOf(in.readLong());
/*      */         case 5:
/* 1541 */           return Double.valueOf(in.readDouble());
/*      */         case 6:
/* 1543 */           return readVersion(in, objectTable);
/*      */         case 8:
/* 1545 */           return readList(in, objectTable);
/*      */       } 
/* 1547 */       throw new IllegalArgumentException("Invalid type: " + type);
/*      */     }
/*      */ 
/*      */     
/*      */     private static void writeList(DataOutputStream out, String key, List<?> list, Map<Object, Integer> objectTable, ModuleDatabase moduleDatabase) throws IOException {
/* 1552 */       if (list.isEmpty()) {
/* 1553 */         out.writeInt(0);
/*      */         return;
/*      */       } 
/* 1556 */       byte type = getListType(list);
/* 1557 */       if (type == -1) {
/* 1558 */         out.writeInt(0);
/*      */         return;
/*      */       } 
/* 1561 */       out.writeInt(list.size());
/* 1562 */       out.writeByte((type == -2) ? 0 : type);
/* 1563 */       for (Object value : list) {
/* 1564 */         switch (type) {
/*      */           case 0:
/* 1566 */             writeString((String)value, out, objectTable);
/*      */             continue;
/*      */           case 4:
/* 1569 */             out.writeLong(((Long)value).longValue());
/*      */             continue;
/*      */           case 5:
/* 1572 */             out.writeDouble(((Double)value).doubleValue());
/*      */             continue;
/*      */           case 6:
/* 1575 */             writeVersion((Version)value, out, objectTable);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */         
/* 1580 */         moduleDatabase.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, moduleDatabase.getModule(0L), (Throwable)new BundleException("Invalid list element in map: " + key + " = " + value.getClass().getName() + '[' + value + ']'), new org.osgi.framework.FrameworkListener[0]);
/* 1581 */         writeString(String.valueOf(value), out, objectTable);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static byte getListType(List<?> list) {
/* 1588 */       if (list.size() == 0)
/* 1589 */         return -1; 
/* 1590 */       Object type = list.get(0);
/* 1591 */       if (type instanceof String)
/* 1592 */         return 0; 
/* 1593 */       if (type instanceof Long)
/* 1594 */         return 4; 
/* 1595 */       if (type instanceof Double)
/* 1596 */         return 5; 
/* 1597 */       if (type instanceof Version)
/* 1598 */         return 6; 
/* 1599 */       return -2;
/*      */     }
/*      */     
/*      */     private static List<?> readList(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1603 */       int size = in.readInt();
/* 1604 */       if (size == 0)
/* 1605 */         return Collections.emptyList(); 
/* 1606 */       byte listType = in.readByte();
/* 1607 */       if (size == 1) {
/* 1608 */         return Collections.singletonList(readListValue(listType, in, objectTable));
/*      */       }
/* 1610 */       List<Object> list = new ArrayList(size);
/* 1611 */       for (int i = 0; i < size; i++) {
/* 1612 */         list.add(readListValue(listType, in, objectTable));
/*      */       }
/* 1614 */       return Collections.unmodifiableList(list);
/*      */     }
/*      */     
/*      */     private static Object readListValue(byte listType, DataInputStream in, List<Object> objectTable) throws IOException {
/* 1618 */       switch (listType) {
/*      */         case 0:
/* 1620 */           return readString(in, objectTable);
/*      */         case 4:
/* 1622 */           return Long.valueOf(in.readLong());
/*      */         case 5:
/* 1624 */           return Double.valueOf(in.readDouble());
/*      */         case 6:
/* 1626 */           return readVersion(in, objectTable);
/*      */       } 
/* 1628 */       throw new IllegalArgumentException("Invalid type: " + listType);
/*      */     }
/*      */ 
/*      */     
/*      */     private static void writeVersion(Version version, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1633 */       if (version == null || version.equals(Version.emptyVersion)) {
/* 1634 */         out.writeByte(0);
/*      */         return;
/*      */       } 
/* 1637 */       Integer index = objectTable.get(version);
/* 1638 */       if (index != null) {
/* 1639 */         out.writeByte(2);
/* 1640 */         out.writeInt(index.intValue());
/*      */         return;
/*      */       } 
/* 1643 */       out.writeByte(1);
/* 1644 */       out.writeInt(version.getMajor());
/* 1645 */       out.writeInt(version.getMinor());
/* 1646 */       out.writeInt(version.getMicro());
/* 1647 */       writeQualifier(version.getQualifier(), out, objectTable);
/*      */     }
/*      */     
/*      */     private static void writeQualifier(String string, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1651 */       if (string != null && string.length() == 0)
/* 1652 */         string = null; 
/* 1653 */       writeString(string, out, objectTable);
/*      */     }
/*      */     
/*      */     private static Version readIndexedVersion(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1657 */       Version version = readVersion0(in, objectTable, false);
/* 1658 */       addToReadTable(version, in.readInt(), objectTable);
/* 1659 */       return version;
/*      */     }
/*      */     
/*      */     private static Version readVersion(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1663 */       return readVersion0(in, objectTable, true);
/*      */     }
/*      */     
/*      */     private static Version readVersion0(DataInputStream in, List<Object> objectTable, boolean intern) throws IOException {
/* 1667 */       byte type = in.readByte();
/* 1668 */       if (type == 2) {
/* 1669 */         int index = in.readInt();
/* 1670 */         return (Version)objectTable.get(index);
/*      */       } 
/* 1672 */       if (type == 0)
/* 1673 */         return Version.emptyVersion; 
/* 1674 */       int majorComponent = in.readInt();
/* 1675 */       int minorComponent = in.readInt();
/* 1676 */       int serviceComponent = in.readInt();
/* 1677 */       String qualifierComponent = readString(in, objectTable);
/* 1678 */       Version version = new Version(majorComponent, minorComponent, serviceComponent, qualifierComponent);
/* 1679 */       return intern ? (Version)ObjectPool.intern(version) : version;
/*      */     }
/*      */     
/*      */     private static void writeString(String string, DataOutputStream out, Map<Object, Integer> objectTable) throws IOException {
/* 1683 */       Integer index = (string != null) ? objectTable.get(string) : null;
/* 1684 */       if (index != null) {
/* 1685 */         out.writeByte(2);
/* 1686 */         out.writeInt(index.intValue());
/*      */         
/*      */         return;
/*      */       } 
/* 1690 */       if (string == null) {
/* 1691 */         out.writeByte(0);
/*      */       } else {
/* 1693 */         byte[] data = string.getBytes(StandardCharsets.UTF_8);
/*      */         
/* 1695 */         if (data.length > 65535) {
/* 1696 */           out.writeByte(3);
/* 1697 */           out.writeInt(data.length);
/* 1698 */           out.write(data);
/*      */         } else {
/* 1700 */           out.writeByte(1);
/* 1701 */           out.writeUTF(string);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private static String readIndexedString(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1707 */       String string = readString0(in, objectTable, false);
/* 1708 */       addToReadTable(string, in.readInt(), objectTable);
/* 1709 */       return string;
/*      */     }
/*      */     
/*      */     private static String readString(DataInputStream in, List<Object> objectTable) throws IOException {
/* 1713 */       return readString0(in, objectTable, true);
/*      */     }
/*      */     private static String readString0(DataInputStream in, List<Object> objectTable, boolean intern) throws IOException {
/*      */       String string;
/* 1717 */       byte type = in.readByte();
/* 1718 */       if (type == 2) {
/* 1719 */         int index = in.readInt();
/* 1720 */         return (String)objectTable.get(index);
/*      */       } 
/* 1722 */       if (type == 0) {
/* 1723 */         return null;
/*      */       }
/*      */       
/* 1726 */       if (type == 3) {
/* 1727 */         int length = in.readInt();
/* 1728 */         byte[] data = new byte[length];
/* 1729 */         in.readFully(data);
/* 1730 */         string = new String(data, StandardCharsets.UTF_8);
/*      */       } else {
/* 1732 */         string = in.readUTF();
/*      */       } 
/*      */       
/* 1735 */       return intern ? (String)ObjectPool.intern(string) : string;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */