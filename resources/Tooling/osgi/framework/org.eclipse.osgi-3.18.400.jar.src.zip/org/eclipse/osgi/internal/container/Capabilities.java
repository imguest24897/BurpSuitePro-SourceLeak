/*     */ package org.eclipse.osgi.internal.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Capabilities
/*     */ {
/*     */   static class NamespaceSet
/*     */   {
/*     */     private final String name;
/*  44 */     private final Map<String, Set<ModuleCapability>> indexes = new HashMap<>();
/*  45 */     private final Set<ModuleCapability> all = new HashSet<>();
/*  46 */     private final Set<ModuleCapability> nonStringIndexes = new HashSet<>(0);
/*     */     private final boolean matchMandatory;
/*     */     
/*     */     NamespaceSet(String name) {
/*  50 */       this.name = name;
/*  51 */       this.matchMandatory = !(!"osgi.wiring.package".equals(name) && !"osgi.wiring.bundle".equals(name) && !"osgi.wiring.host".equals(name));
/*     */     }
/*     */     
/*     */     void addCapability(ModuleCapability capability) {
/*  55 */       if (!this.name.equals(capability.getNamespace())) {
/*  56 */         throw new IllegalArgumentException("Invalid namespace: " + capability.getNamespace() + ": expecting: " + this.name);
/*     */       }
/*  58 */       this.all.add(capability);
/*     */       
/*  60 */       Object index = capability.getAttributes().get(this.name);
/*  61 */       if (index == null) {
/*     */         return;
/*     */       }
/*  64 */       Collection<?> indexCollection = null;
/*  65 */       if (index instanceof Collection) {
/*  66 */         indexCollection = (Collection)index;
/*  67 */       } else if (index.getClass().isArray()) {
/*  68 */         indexCollection = Arrays.asList((Object[])index);
/*     */       } 
/*  70 */       if (indexCollection == null) {
/*  71 */         addIndex(index, capability);
/*     */       } else {
/*  73 */         for (Object indexKey : indexCollection) {
/*  74 */           addIndex(indexKey, capability);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void addIndex(Object indexKey, ModuleCapability capability) {
/*  80 */       if (!(indexKey instanceof String)) {
/*  81 */         this.nonStringIndexes.add(capability);
/*     */       } else {
/*  83 */         Set<ModuleCapability> capabilities = this.indexes.get(indexKey);
/*  84 */         if (capabilities == null) {
/*  85 */           capabilities = new HashSet<>(1);
/*  86 */           this.indexes.put((String)indexKey, capabilities);
/*     */         } 
/*  88 */         capabilities.add(capability);
/*     */       } 
/*     */     }
/*     */     
/*     */     void removeCapability(ModuleCapability capability) {
/*  93 */       if (!this.name.equals(capability.getNamespace())) {
/*  94 */         throw new IllegalArgumentException("Invalid namespace: " + capability.getNamespace() + ": expecting: " + this.name);
/*     */       }
/*  96 */       this.all.remove(capability);
/*     */       
/*  98 */       Object index = capability.getAttributes().get(this.name);
/*  99 */       if (index == null) {
/*     */         return;
/*     */       }
/* 102 */       Collection<?> indexCollection = null;
/* 103 */       if (index instanceof Collection) {
/* 104 */         indexCollection = (Collection)index;
/* 105 */       } else if (index.getClass().isArray()) {
/* 106 */         indexCollection = Arrays.asList((Object[])index);
/*     */       } 
/* 108 */       if (indexCollection == null) {
/* 109 */         removeIndex(index, capability);
/*     */       } else {
/* 111 */         for (Object indexKey : indexCollection) {
/* 112 */           removeIndex(indexKey, capability);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void removeIndex(Object indexKey, ModuleCapability capability) {
/* 118 */       if (!(indexKey instanceof String)) {
/* 119 */         this.nonStringIndexes.remove(capability);
/*     */       } else {
/* 121 */         Set<ModuleCapability> capabilities = this.indexes.get(indexKey);
/* 122 */         if (capabilities != null)
/* 123 */           capabilities.remove(capability); 
/*     */       } 
/*     */     }
/*     */     
/*     */     List<ModuleCapability> findCapabilities(Requirement requirement) {
/*     */       List<ModuleCapability> result;
/* 129 */       if (!this.name.equals(requirement.getNamespace())) {
/* 130 */         throw new IllegalArgumentException("Invalid namespace: " + requirement.getNamespace() + ": expecting: " + this.name);
/*     */       }
/* 132 */       FilterImpl f = null;
/* 133 */       String filterSpec = (String)requirement.getDirectives().get("filter");
/* 134 */       if (filterSpec != null) {
/*     */         try {
/* 136 */           f = FilterImpl.newInstance(filterSpec);
/* 137 */         } catch (InvalidSyntaxException invalidSyntaxException) {
/* 138 */           return Collections.emptyList();
/*     */         } 
/*     */       }
/* 141 */       Object syntheticAttr = requirement.getAttributes().get("org.eclipse.osgi.container.synthetic");
/* 142 */       boolean synthetic = (syntheticAttr instanceof Boolean) ? ((Boolean)syntheticAttr).booleanValue() : false;
/*     */ 
/*     */       
/* 145 */       if (filterSpec == null) {
/* 146 */         result = match(null, this.all, synthetic);
/*     */       } else {
/* 148 */         String indexKey = f.getPrimaryKeyValue(this.name);
/* 149 */         if (indexKey == null) {
/* 150 */           result = match((Filter)f, this.all, synthetic);
/*     */         } else {
/* 152 */           Set<ModuleCapability> indexed = this.indexes.get(indexKey);
/* 153 */           if (indexed == null) {
/* 154 */             result = new ArrayList<>(0);
/*     */           } else {
/* 156 */             result = match((Filter)f, indexed, synthetic);
/*     */           } 
/* 158 */           if (!this.nonStringIndexes.isEmpty()) {
/* 159 */             List<ModuleCapability> nonStringResult = match((Filter)f, this.nonStringIndexes, synthetic);
/* 160 */             for (ModuleCapability capability : nonStringResult) {
/* 161 */               if (!result.contains(capability)) {
/* 162 */                 result.add(capability);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 168 */       return result;
/*     */     }
/*     */     
/*     */     private List<ModuleCapability> match(Filter f, Set<ModuleCapability> candidates, boolean synthetic) {
/* 172 */       List<ModuleCapability> result = new ArrayList<>(1);
/* 173 */       for (ModuleCapability candidate : candidates) {
/* 174 */         if (Capabilities.matches(f, (Capability)candidate, (!synthetic && this.matchMandatory))) {
/* 175 */           result.add(candidate);
/*     */         }
/*     */       } 
/* 178 */       return result;
/*     */     }
/*     */   }
/*     */   
/* 182 */   public static final Pattern MANDATORY_ATTR = Pattern.compile("\\(([^(=<>]+)\\s*[=<>]\\s*[^)]+\\)");
/*     */   public static final String SYNTHETIC_REQUIREMENT = "org.eclipse.osgi.container.synthetic";
/*     */   
/*     */   public static boolean matches(Filter f, Capability candidate, boolean matchMandatory) {
/* 186 */     if (f != null && !f.matches(candidate.getAttributes())) {
/* 187 */       return false;
/*     */     }
/* 189 */     if (matchMandatory) {
/*     */       
/* 191 */       String mandatory = (String)candidate.getDirectives().get("mandatory");
/* 192 */       if (mandatory == null) {
/* 193 */         return true;
/*     */       }
/* 195 */       if (f == null) {
/* 196 */         return false;
/*     */       }
/* 198 */       Matcher matcher = MANDATORY_ATTR.matcher(f.toString());
/* 199 */       String[] mandatoryAttrs = ManifestElement.getArrayFromList(mandatory, ",");
/* 200 */       boolean allPresent = true; byte b; int i; String[] arrayOfString1;
/* 201 */       for (i = (arrayOfString1 = mandatoryAttrs).length, b = 0; b < i; ) { String mandatoryAttr = arrayOfString1[b];
/* 202 */         matcher.reset();
/* 203 */         boolean found = false;
/* 204 */         while (matcher.find()) {
/* 205 */           int numGroups = matcher.groupCount();
/* 206 */           for (int j = 1; j <= numGroups; j++) {
/* 207 */             if (mandatoryAttr.equals(matcher.group(j))) {
/* 208 */               found = true;
/*     */             }
/*     */           } 
/*     */         } 
/* 212 */         allPresent &= found; b++; }
/*     */       
/* 214 */       return allPresent;
/*     */     } 
/* 216 */     return true;
/*     */   }
/*     */   
/* 219 */   Map<String, NamespaceSet> namespaceSets = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> addCapabilities(ModuleRevision revision) {
/* 230 */     Collection<String> packageNames = null;
/* 231 */     for (ModuleCapability capability : revision.getModuleCapabilities(null)) {
/* 232 */       NamespaceSet namespaceSet = this.namespaceSets.get(capability.getNamespace());
/* 233 */       if (namespaceSet == null) {
/* 234 */         namespaceSet = new NamespaceSet(capability.getNamespace());
/* 235 */         this.namespaceSets.put(capability.getNamespace(), namespaceSet);
/*     */       } 
/* 237 */       namespaceSet.addCapability(capability);
/*     */ 
/*     */       
/* 240 */       if ("osgi.wiring.package".equals(capability.getNamespace())) {
/* 241 */         Object packageName = capability.getAttributes().get("osgi.wiring.package");
/* 242 */         if (packageName instanceof String) {
/* 243 */           if (packageNames == null) {
/* 244 */             packageNames = new ArrayList<>();
/*     */           }
/* 246 */           packageNames.add((String)packageName);
/*     */         } 
/*     */       } 
/*     */     } 
/* 250 */     return (packageNames == null) ? Collections.<String>emptyList() : packageNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeCapabilities(ModuleRevision revision) {
/* 261 */     for (ModuleCapability capability : revision.getModuleCapabilities(null)) {
/* 262 */       NamespaceSet namespaceSet = this.namespaceSets.get(capability.getNamespace());
/* 263 */       if (namespaceSet != null) {
/* 264 */         namespaceSet.removeCapability(capability);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleCapability> findCapabilities(Requirement requirement) {
/* 276 */     NamespaceSet namespaceSet = this.namespaceSets.get(requirement.getNamespace());
/* 277 */     if (namespaceSet == null) {
/* 278 */       return Collections.emptyList();
/*     */     }
/* 280 */     return namespaceSet.findCapabilities(requirement);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\Capabilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */