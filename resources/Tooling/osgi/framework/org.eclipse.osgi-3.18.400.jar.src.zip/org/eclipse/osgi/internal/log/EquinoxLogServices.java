/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.location.BasicLocation;
/*     */ import org.eclipse.osgi.storage.StorageUtil;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.LogListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxLogServices
/*     */ {
/*     */   static final String EQUINOX_LOGGER_NAME = "org.eclipse.equinox.logger";
/*     */   static final String PERF_LOGGER_NAME = "org.eclipse.performance.logger";
/*     */   private static final String PROP_LOG_ENABLED = "eclipse.log.enabled";
/*     */   private static final String LOG_EXT = ".log";
/*     */   private final LogServiceManager logServiceManager;
/*     */   private final EquinoxLogFactory eclipseLogFactory;
/*     */   private final EquinoxLogWriter logWriter;
/*     */   private final EquinoxLogWriter perfWriter;
/*     */   private final FrameworkLog rootFrameworkLog;
/*     */   private ServiceRegistration<?> frameworkLogReg;
/*     */   private ServiceRegistration<?> perfLogReg;
/*     */   
/*     */   public EquinoxLogServices(EquinoxConfiguration environmentInfo) {
/*  49 */     BasicLocation basicLocation = environmentInfo.getEquinoxLocations().getConfigurationLocation();
/*  50 */     String logFilePath = environmentInfo.getConfiguration("osgi.logfile");
/*  51 */     if (logFilePath == null) {
/*  52 */       logFilePath = String.valueOf(Long.toString(System.currentTimeMillis())) + ".log";
/*     */     }
/*     */     
/*  55 */     File logFile = new File(logFilePath);
/*  56 */     if (!logFile.isAbsolute()) {
/*  57 */       File configAreaDirectory = null;
/*  58 */       if (basicLocation != null)
/*     */       {
/*  60 */         configAreaDirectory = new File(basicLocation.getURL().getPath());
/*     */       }
/*  62 */       if (configAreaDirectory != null) {
/*  63 */         logFile = new File(configAreaDirectory, logFilePath);
/*     */       } else {
/*  65 */         logFile = null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  70 */     boolean enabled = "true".equals(environmentInfo.getConfiguration("eclipse.log.enabled", "true"));
/*  71 */     if (logFile != null) {
/*  72 */       environmentInfo.setConfiguration("osgi.logfile", logFile.getAbsolutePath());
/*  73 */       this.logWriter = new EquinoxLogWriter(logFile, "org.eclipse.equinox.logger", enabled, environmentInfo);
/*     */       
/*  75 */       File perfLogFile = new File(logFile.getParentFile(), "performance.log");
/*  76 */       this.perfWriter = new EquinoxLogWriter(perfLogFile, "org.eclipse.performance.logger", true, environmentInfo);
/*     */     } else {
/*  78 */       this.logWriter = new EquinoxLogWriter(null, "org.eclipse.equinox.logger", enabled, environmentInfo);
/*  79 */       this.perfWriter = new EquinoxLogWriter(null, "org.eclipse.performance.logger", true, environmentInfo);
/*     */     } 
/*     */     
/*  82 */     if ("true".equals(environmentInfo.getConfiguration("eclipse.consoleLog")))
/*  83 */       this.logWriter.setConsoleLog(true); 
/*  84 */     String logHistoryMaxProp = environmentInfo.getConfiguration("equinox.log.history.max");
/*  85 */     int logHistoryMax = 0;
/*  86 */     if (logHistoryMaxProp != null) {
/*     */       try {
/*  88 */         logHistoryMax = Integer.parseInt(logHistoryMaxProp);
/*  89 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  94 */     LogLevel defaultLevel = LogLevel.WARN;
/*     */     try {
/*  96 */       String defaultLevelConfig = environmentInfo.getConfiguration("org.osgi.service.log.admin.loglevel");
/*  97 */       if (defaultLevelConfig != null) {
/*  98 */         defaultLevel = LogLevel.valueOf(defaultLevelConfig);
/*     */       }
/* 100 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */     
/* 104 */     boolean captureLogEntryLocation = "true".equals(environmentInfo.getConfiguration("equinox.log.capture.entry.location", "true"));
/* 105 */     this.logServiceManager = new LogServiceManager(logHistoryMax, defaultLevel, captureLogEntryLocation, new LogListener[] { (LogListener)this.logWriter, (LogListener)this.perfWriter });
/* 106 */     this.eclipseLogFactory = new EquinoxLogFactory(this.logWriter, this.logServiceManager);
/* 107 */     this.rootFrameworkLog = this.eclipseLogFactory.createFrameworkLog(null, this.logWriter);
/*     */     
/* 109 */     this.logWriter.setLoggerAdmin(this.logServiceManager.getLoggerAdmin());
/* 110 */     this.perfWriter.setLoggerAdmin(this.logServiceManager.getLoggerAdmin());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws BundleException {
/* 120 */     this.logServiceManager.start(context);
/* 121 */     this.frameworkLogReg = StorageUtil.register(FrameworkLog.class.getName(), this.eclipseLogFactory, context);
/* 122 */     this.perfLogReg = registerPerformanceLog(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws BundleException {
/* 129 */     this.frameworkLogReg.unregister();
/* 130 */     this.perfLogReg.unregister();
/* 131 */     this.logServiceManager.stop(context);
/*     */   }
/*     */   
/*     */   public FrameworkLog getFrameworkLog() {
/* 135 */     return this.rootFrameworkLog;
/*     */   }
/*     */   
/*     */   private ServiceRegistration<?> registerPerformanceLog(BundleContext context) {
/* 139 */     Object service = createPerformanceLog(context.getBundle());
/* 140 */     String serviceName = FrameworkLog.class.getName();
/* 141 */     Dictionary<String, Object> serviceProperties = new Hashtable<>();
/*     */     
/* 143 */     serviceProperties.put("service.ranking", Integer.valueOf(-2147483648));
/* 144 */     serviceProperties.put("service.pid", String.valueOf(context.getBundle().getBundleId() + 46L) + service.getClass().getName());
/* 145 */     serviceProperties.put("performance", Boolean.TRUE.toString());
/*     */     
/* 147 */     return context.registerService(serviceName, service, serviceProperties);
/*     */   }
/*     */   
/*     */   private FrameworkLog createPerformanceLog(Bundle systemBundle) {
/* 151 */     return this.eclipseLogFactory.createFrameworkLog(systemBundle, this.perfWriter);
/*     */   }
/*     */   
/*     */   public void log(String entry, int severity, String message, Throwable throwable) {
/* 155 */     log(entry, severity, message, throwable, null);
/*     */   }
/*     */   
/*     */   public void log(String entry, int severity, String message, Throwable throwable, FrameworkLogEntry[] children) {
/* 159 */     getFrameworkLog().log(new FrameworkLogEntry(entry, severity, 0, message, 0, throwable, children));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\EquinoxLogServices.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */