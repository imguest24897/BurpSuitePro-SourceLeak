/*    */ package org.eclipse.osgi.internal.loader.sources;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Collection;
/*    */ import java.util.Enumeration;
/*    */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*    */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleSourcePackage
/*    */   extends PackageSource
/*    */ {
/*    */   private final BundleLoader supplier;
/*    */   
/*    */   public SingleSourcePackage(String id, BundleLoader supplier) {
/* 26 */     super(id);
/* 27 */     this.supplier = supplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public SingleSourcePackage[] getSuppliers() {
/* 32 */     return new SingleSourcePackage[] { this };
/*    */   }
/*    */   
/*    */   public BundleLoader getLoader() {
/* 36 */     return this.supplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/* 41 */     return this.supplier.findLocalClass(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getResource(String name) {
/* 46 */     return this.supplier.findLocalResource(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> getResources(String name) {
/* 51 */     return this.supplier.findLocalResources(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object source) {
/* 56 */     if (this == source)
/* 57 */       return true; 
/* 58 */     if (!(source instanceof SingleSourcePackage))
/* 59 */       return false; 
/* 60 */     SingleSourcePackage singleSource = (SingleSourcePackage)source;
/*    */     
/* 62 */     return (this.supplier == singleSource.supplier && this.id == singleSource.getId());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     int result = 1;
/* 69 */     result = 31 * result + this.id.hashCode();
/* 70 */     result = 31 * result + this.supplier.hashCode();
/* 71 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<String> listResources(String path, String filePattern) {
/* 76 */     ModuleClassLoader mcl = this.supplier.getModuleClassLoader();
/* 77 */     return mcl.listLocalResources(path, filePattern, 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\sources\SingleSourcePackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */