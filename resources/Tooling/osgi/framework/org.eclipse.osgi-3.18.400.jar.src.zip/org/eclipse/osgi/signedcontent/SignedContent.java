package org.eclipse.osgi.signedcontent;

import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.util.Date;

public interface SignedContent {
  SignedContentEntry[] getSignedEntries();
  
  SignedContentEntry getSignedEntry(String paramString);
  
  SignerInfo[] getSignerInfos();
  
  boolean isSigned();
  
  Date getSigningTime(SignerInfo paramSignerInfo);
  
  SignerInfo getTSASignerInfo(SignerInfo paramSignerInfo);
  
  void checkValidity(SignerInfo paramSignerInfo) throws CertificateExpiredException, CertificateNotYetValidException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\signedcontent\SignedContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */