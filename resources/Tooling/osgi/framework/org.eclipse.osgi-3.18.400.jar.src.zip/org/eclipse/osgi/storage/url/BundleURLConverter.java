/*    */ package org.eclipse.osgi.storage.url;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.eclipse.osgi.internal.messages.Msg;
/*    */ import org.eclipse.osgi.service.urlconversion.URLConverter;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleURLConverter
/*    */   implements URLConverter
/*    */ {
/*    */   public URL toFileURL(URL url) throws IOException {
/* 36 */     URLConnection connection = url.openConnection();
/* 37 */     if (connection instanceof BundleURLConnection) {
/* 38 */       URL result = ((BundleURLConnection)connection).getFileURL();
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 43 */       if (result == null)
/* 44 */         throw new IOException(NLS.bind(Msg.ECLIPSE_PLUGIN_EXTRACTION_PROBLEM, url)); 
/* 45 */       return result;
/*    */     } 
/* 47 */     return url;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URL resolve(URL url) throws IOException {
/* 55 */     URLConnection connection = url.openConnection();
/* 56 */     if (connection instanceof BundleURLConnection)
/* 57 */       return ((BundleURLConnection)connection).getLocalURL(); 
/* 58 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\BundleURLConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */