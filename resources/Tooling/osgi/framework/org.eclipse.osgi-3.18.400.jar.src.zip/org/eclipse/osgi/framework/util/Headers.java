/*     */ package org.eclipse.osgi.framework.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Headers<K, V>
/*     */   extends Dictionary<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*     */   private boolean readOnly = false;
/*     */   private K[] headers;
/*     */   private V[] values;
/*  42 */   private int size = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers(int initialCapacity) {
/*  52 */     Object[] k = new Object[initialCapacity];
/*  53 */     this.headers = (K[])k;
/*     */     
/*  55 */     Object[] v = new Object[initialCapacity];
/*  56 */     this.values = (V[])v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers(Dictionary<? extends K, ? extends V> values) {
/*  67 */     this(values.size());
/*     */     
/*  69 */     Enumeration<? extends K> keys = values.keys();
/*  70 */     while (keys.hasMoreElements()) {
/*  71 */       K key = keys.nextElement();
/*  72 */       set(key, values.get(key));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<K> keys() {
/*  81 */     return new ArrayEnumeration<>(this.headers, this.size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<V> elements() {
/*  89 */     return new ArrayEnumeration<>(this.values, this.size);
/*     */   }
/*     */   
/*     */   private int getIndex(Object key) {
/*  93 */     boolean stringKey = key instanceof String;
/*  94 */     for (int i = 0; i < this.size; i++) {
/*  95 */       if (stringKey && this.headers[i] instanceof String) {
/*  96 */         if (((String)this.headers[i]).equalsIgnoreCase((String)key)) {
/*  97 */           return i;
/*     */         }
/*  99 */       } else if (this.headers[i].equals(key)) {
/* 100 */         return i;
/*     */       } 
/*     */     } 
/* 103 */     return -1;
/*     */   }
/*     */   
/*     */   private V remove(int remove) {
/* 107 */     V removed = this.values[remove];
/* 108 */     for (int i = remove; i < this.size; i++) {
/* 109 */       if (i == this.headers.length - 1) {
/* 110 */         this.headers[i] = null;
/* 111 */         this.values[i] = null;
/*     */       } else {
/* 113 */         this.headers[i] = this.headers[i + 1];
/* 114 */         this.values[i] = this.values[i + 1];
/*     */       } 
/*     */     } 
/* 117 */     if (remove < this.size)
/* 118 */       this.size--; 
/* 119 */     return removed;
/*     */   }
/*     */   
/*     */   private void add(K header, V value) {
/* 123 */     if (this.size == this.headers.length) {
/*     */ 
/*     */       
/* 126 */       Object[] nh = new Object[this.headers.length + 10];
/* 127 */       Object[] newHeaders = nh;
/*     */       
/* 129 */       Object[] nv = new Object[this.values.length + 10];
/* 130 */       Object[] newValues = nv;
/* 131 */       System.arraycopy(this.headers, 0, newHeaders, 0, this.headers.length);
/* 132 */       System.arraycopy(this.values, 0, newValues, 0, this.values.length);
/* 133 */       this.headers = (K[])newHeaders;
/* 134 */       this.values = (V[])newValues;
/*     */     } 
/* 136 */     this.headers[this.size] = header;
/* 137 */     this.values[this.size] = value;
/* 138 */     this.size++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V get(Object key) {
/* 148 */     int i = -1;
/* 149 */     if ((i = getIndex(key)) != -1)
/* 150 */       return this.values[i]; 
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V set(K key, V value, boolean replace) {
/*     */     String str;
/* 171 */     if (this.readOnly)
/* 172 */       throw new UnsupportedOperationException(); 
/* 173 */     if (key instanceof String) {
/*     */       
/* 175 */       String str1 = ((String)key).intern();
/* 176 */       str = str1;
/*     */     } 
/* 178 */     int i = getIndex(str);
/* 179 */     if (value == null) {
/* 180 */       if (i != -1)
/* 181 */         return remove(i); 
/*     */     } else {
/* 183 */       if (i != -1) {
/* 184 */         if (!replace)
/* 185 */           throw new IllegalArgumentException(NLS.bind(Msg.HEADER_DUPLICATE_KEY_EXCEPTION, str)); 
/* 186 */         V oldVal = this.values[i];
/* 187 */         this.values[i] = value;
/* 188 */         return oldVal;
/*     */       } 
/* 190 */       add((K)str, value);
/*     */     } 
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V set(K key, V value) {
/* 207 */     return set(key, value, false);
/*     */   }
/*     */   
/*     */   public synchronized void setReadOnly() {
/* 211 */     this.readOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int size() {
/* 221 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isEmpty() {
/* 234 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V put(K key, V value) {
/* 246 */     if (this.readOnly)
/* 247 */       throw new UnsupportedOperationException(); 
/* 248 */     return set(key, value, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 259 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 264 */     StringBuilder sb = new StringBuilder();
/* 265 */     sb.append('{');
/*     */     
/* 267 */     for (int i = 0; i < this.size; i++) {
/* 268 */       if (i != 0) {
/* 269 */         sb.append(", ");
/*     */       }
/* 271 */       K header = this.headers[i];
/* 272 */       if (header == this) {
/* 273 */         sb.append("(this Dictionary)");
/*     */       } else {
/* 275 */         sb.append(header);
/*     */       } 
/* 277 */       sb.append('=');
/* 278 */       V value = this.values[i];
/* 279 */       if (value == this) {
/* 280 */         sb.append("(this Dictionary)");
/*     */       } else {
/* 282 */         sb.append(value);
/*     */       } 
/*     */     } 
/*     */     
/* 286 */     sb.append('}');
/* 287 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static Headers<String, String> parseManifest(InputStream in) throws BundleException {
/* 291 */     Headers<String, String> headers = new Headers<>(10);
/*     */     try {
/* 293 */       ManifestElement.parseBundleManifest(in, headers);
/* 294 */     } catch (IOException e) {
/* 295 */       throw new BundleException(Msg.MANIFEST_IOEXCEPTION, 3, e);
/*     */     } 
/* 297 */     headers.setReadOnly();
/* 298 */     return headers;
/*     */   }
/*     */   
/*     */   private static class ArrayEnumeration<E> implements Enumeration<E> {
/*     */     private E[] array;
/* 303 */     int cur = 0;
/*     */ 
/*     */     
/*     */     public ArrayEnumeration(Object[] array, int size) {
/* 307 */       Object[] a = new Object[size];
/* 308 */       this.array = (E[])a;
/* 309 */       System.arraycopy(array, 0, this.array, 0, this.array.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasMoreElements() {
/* 314 */       return (this.cur < this.array.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public E nextElement() {
/* 319 */       return this.array[this.cur++];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 325 */     if (this.readOnly) {
/* 326 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean containsKey(Object key) {
/* 331 */     return (getIndex(key) >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 336 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 341 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 346 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> c) {
/* 351 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 356 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\Headers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */