/*     */ package org.eclipse.osgi.storage.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BundleURLConnection
/*     */   extends URLConnection
/*     */   implements BundleReference
/*     */ {
/*     */   protected final BundleEntry bundleEntry;
/*     */   private final ModuleContainer container;
/*     */   protected InputStream in;
/*     */   protected String contentType;
/*     */   
/*     */   public BundleURLConnection(URL url, ModuleContainer container, BundleEntry bundleEntry) {
/*  52 */     super(url);
/*     */     
/*  54 */     this.container = container;
/*  55 */     this.bundleEntry = bundleEntry;
/*  56 */     this.in = null;
/*  57 */     this.contentType = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void connect() throws IOException {
/*  62 */     if (!this.connected) {
/*  63 */       if (this.bundleEntry != null) {
/*  64 */         this.in = this.bundleEntry.getInputStream();
/*  65 */         this.connected = true;
/*     */       } else {
/*  67 */         throw new IOException(NLS.bind(Msg.RESOURCE_NOT_FOUND_EXCEPTION, getURL()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLengthLong() {
/*  74 */     return this.bundleEntry.getSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  79 */     if (this.contentType == null) {
/*  80 */       this.contentType = guessContentTypeFromName(this.bundleEntry.getName());
/*     */       
/*  82 */       if (this.contentType == null) {
/*  83 */         if (!this.connected) {
/*     */           try {
/*  85 */             connect();
/*  86 */           } catch (IOException iOException) {
/*  87 */             return null;
/*     */           } 
/*     */         }
/*     */         try {
/*  91 */           if (this.in.markSupported())
/*  92 */             this.contentType = guessContentTypeFromStream(this.in); 
/*  93 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  98 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDoInput() {
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDoOutput() {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 113 */     if (!this.connected) {
/* 114 */       connect();
/*     */     }
/* 116 */     return this.in;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastModified() {
/* 121 */     long lastModified = this.bundleEntry.getTime();
/*     */     
/* 123 */     if (lastModified == -1L) {
/* 124 */       return 0L;
/*     */     }
/* 126 */     return lastModified;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getLocalURL() {
/* 134 */     URL local = this.bundleEntry.getLocalURL();
/* 135 */     return (local == null) ? getURL() : local;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getFileURL() {
/* 144 */     return this.bundleEntry.getFileURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/* 149 */     String host = getURL().getHost();
/* 150 */     long bundleId = BundleResourceHandler.parseBundleIDFromURLHost(host);
/* 151 */     Module module = this.container.getModule(bundleId);
/* 152 */     return (module != null) ? module.getBundle() : null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\BundleURLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */