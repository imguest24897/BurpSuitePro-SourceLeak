/*      */ package org.eclipse.osgi.container;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Semaphore;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.eclipse.osgi.framework.eventmgr.CopyOnWriteIdentityMap;
/*      */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*      */ import org.eclipse.osgi.framework.eventmgr.EventManager;
/*      */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*      */ import org.eclipse.osgi.framework.util.SecureAction;
/*      */ import org.eclipse.osgi.framework.util.ThreadInfoReport;
/*      */ import org.eclipse.osgi.internal.container.InternalUtils;
/*      */ import org.eclipse.osgi.internal.container.LockSet;
/*      */ import org.eclipse.osgi.internal.container.NamespaceList;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*      */ import org.eclipse.osgi.service.debug.DebugOptions;
/*      */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.AdminPermission;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.FrameworkListener;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.startlevel.FrameworkStartLevel;
/*      */ import org.osgi.framework.wiring.BundleCapability;
/*      */ import org.osgi.framework.wiring.FrameworkWiring;
/*      */ import org.osgi.resource.Requirement;
/*      */ import org.osgi.resource.Resource;
/*      */ import org.osgi.resource.Wire;
/*      */ import org.osgi.service.resolver.ResolutionException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ModuleContainer
/*      */   implements DebugOptionsListener
/*      */ {
/*   88 */   private static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   private final LockSet<String> locationLocks = new LockSet();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   98 */   private final LockSet<String> nameLocks = new LockSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ContainerWiring frameworkWiring;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ContainerStartLevel frameworkStartLevel;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ModuleDatabase moduleDatabase;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ModuleContainerAdaptor adaptor;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ModuleResolver moduleResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  129 */   private final AtomicReference<SystemModule> refreshingSystemModule = new AtomicReference<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final long moduleLockTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean autoStartOnResolve;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean restrictParallelStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean DEBUG_MONITOR_LAZY = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean DEBUG_BUNDLE_START_TIME = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ResolutionLock _resolutionLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ReentrantLock _bundleStateLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleContainerAdaptor getAdaptor() {
/*  183 */     return this.adaptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Module> getModules() {
/*  191 */     return this.moduleDatabase.getModules();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Module getModule(long id) {
/*  201 */     return this.moduleDatabase.getModule(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Module getModule(String location) {
/*  211 */     return this.moduleDatabase.getModule(location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Requirement createRequirement(String namespace, Map<String, String> directives, Map<String, ?> attributes) {
/*  223 */     return (Requirement)new ModuleRequirement(namespace, directives, attributes, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Module install(Module origin, String location, ModuleRevisionBuilder builder, Object revisionInfo) throws BundleException {
/*  243 */     long id = builder.getId();
/*  244 */     ModuleRevisionBuilder adaptBuilder = getAdaptor().adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent.INSTALLED, origin, builder, revisionInfo);
/*  245 */     if (adaptBuilder != null) {
/*      */       
/*  247 */       adaptBuilder.setInternalId(id);
/*  248 */       builder = adaptBuilder;
/*      */     } 
/*  250 */     String name = builder.getSymbolicName();
/*  251 */     boolean locationLocked = false;
/*  252 */     boolean nameLocked = false;
/*      */     
/*      */     try {
/*      */       try {
/*  256 */         locationLocked = this.locationLocks.tryLock(location, 5L, TimeUnit.SECONDS);
/*  257 */         nameLocked = (name != null && this.nameLocks.tryLock(name, 5L, TimeUnit.SECONDS));
/*  258 */         if (!locationLocked) {
/*  259 */           throw new BundleException("Failed to obtain location lock for installation: " + location, 7, new ThreadInfoReport(this.locationLocks.getLockInfo(location)));
/*      */         }
/*  261 */         if (name != null && !nameLocked) {
/*  262 */           throw new BundleException("Failed to obtain symbolic name lock for installation: " + name, 7, new ThreadInfoReport(this.nameLocks.getLockInfo(name)));
/*      */         }
/*  264 */       } catch (InterruptedException e) {
/*  265 */         Thread.currentThread().interrupt();
/*  266 */         throw new BundleException("Failed to obtain id locks for installation.", 7, e);
/*      */       } 
/*      */       
/*  269 */       Module existingLocation = null;
/*  270 */       Collection<Module> collisionCandidates = Collections.emptyList();
/*  271 */       this.moduleDatabase.readLock();
/*      */       try {
/*  273 */         existingLocation = this.moduleDatabase.getModule(location);
/*  274 */         if (existingLocation == null) {
/*      */ 
/*      */           
/*  277 */           List<ModuleCapability> sameIdentity = this.moduleDatabase.findCapabilities(getIdentityRequirement(name, builder.getVersion()));
/*  278 */           if (!sameIdentity.isEmpty()) {
/*  279 */             collisionCandidates = new ArrayList<>(1);
/*  280 */             for (ModuleCapability identity : sameIdentity) {
/*  281 */               ModuleRevision equinoxRevision = identity.getRevision();
/*  282 */               if (!equinoxRevision.isCurrent()) {
/*      */                 continue;
/*      */               }
/*  285 */               if (!collisionCandidates.contains(equinoxRevision.getRevisions().getModule()))
/*  286 */                 collisionCandidates.add(equinoxRevision.getRevisions().getModule()); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  291 */         this.moduleDatabase.readUnlock();
/*      */       } 
/*      */       
/*  294 */       if (existingLocation != null) {
/*  295 */         if (origin != null) {
/*  296 */           Bundle bundle = origin.getBundle();
/*  297 */           BundleContext context = (bundle == null) ? null : bundle.getBundleContext();
/*  298 */           if (context != null && context.getBundle(existingLocation.getId().longValue()) == null) {
/*  299 */             Bundle b = existingLocation.getBundle();
/*  300 */             throw new BundleException(NLS.bind(Msg.ModuleContainer_NameCollisionWithLocation, new Object[] { b.getSymbolicName(), b.getVersion(), location }), 12);
/*      */           } 
/*      */         } 
/*  303 */         return existingLocation;
/*      */       } 
/*      */ 
/*      */       
/*  307 */       if (origin != null && !collisionCandidates.isEmpty()) {
/*  308 */         this.adaptor.getModuleCollisionHook().filterCollisions(1, origin, collisionCandidates);
/*      */       }
/*  310 */       if (!collisionCandidates.isEmpty()) {
/*  311 */         throw new BundleException(NLS.bind(Msg.ModuleContainer_NameCollision, name, builder.getVersion()), 9);
/*      */       }
/*      */       
/*  314 */       Module result = this.moduleDatabase.install(location, builder, revisionInfo);
/*      */       
/*  316 */       this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.INSTALLED, result, origin);
/*      */       
/*  318 */       return result;
/*      */     } finally {
/*  320 */       if (locationLocked)
/*  321 */         this.locationLocks.unlock(location); 
/*  322 */       if (nameLocked) {
/*  323 */         this.nameLocks.unlock(name);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void update(Module module, ModuleRevisionBuilder builder, Object revisionInfo) throws BundleException {
/*  338 */     long id = builder.getId();
/*  339 */     ModuleRevisionBuilder adaptBuilder = getAdaptor().adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent.UPDATED, module, builder, revisionInfo);
/*  340 */     if (adaptBuilder != null) {
/*      */       
/*  342 */       adaptBuilder.setInternalId(id);
/*  343 */       builder = adaptBuilder;
/*      */     } 
/*  345 */     checkAdminPermission(module.getBundle(), "lifecycle");
/*  346 */     String name = builder.getSymbolicName();
/*  347 */     boolean nameLocked = false;
/*      */     try {
/*      */       Module.State previousState;
/*      */       try {
/*  351 */         if (name != null && !(nameLocked = this.nameLocks.tryLock(name, 5L, TimeUnit.SECONDS))) {
/*  352 */           throw new BundleException("Failed to obtain id locks for installation: " + name, 
/*  353 */               7, new ThreadInfoReport(this.nameLocks.getLockInfo(name)));
/*      */         }
/*  355 */       } catch (InterruptedException e) {
/*  356 */         Thread.currentThread().interrupt();
/*  357 */         throw new BundleException("Failed to obtain id locks for installation.", 7, e);
/*      */       } 
/*      */       
/*  360 */       Collection<Module> collisionCandidates = Collections.emptyList();
/*  361 */       this.moduleDatabase.readLock();
/*      */ 
/*      */       
/*      */       try {
/*  365 */         List<ModuleCapability> sameIdentity = this.moduleDatabase.findCapabilities(getIdentityRequirement(name, builder.getVersion()));
/*  366 */         if (!sameIdentity.isEmpty()) {
/*  367 */           collisionCandidates = new ArrayList<>(1);
/*  368 */           for (ModuleCapability identity : sameIdentity) {
/*  369 */             ModuleRevision equinoxRevision = identity.getRevision();
/*  370 */             if (!equinoxRevision.isCurrent())
/*      */               continue; 
/*  372 */             Module m = equinoxRevision.getRevisions().getModule();
/*  373 */             if (m.equals(module)) {
/*      */               continue;
/*      */             }
/*  376 */             if (!collisionCandidates.contains(m)) {
/*  377 */               collisionCandidates.add(m);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  382 */         this.moduleDatabase.readUnlock();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  387 */       if (module != null && !collisionCandidates.isEmpty()) {
/*  388 */         this.adaptor.getModuleCollisionHook().filterCollisions(2, module, collisionCandidates);
/*      */       }
/*      */       
/*  391 */       if (!collisionCandidates.isEmpty()) {
/*  392 */         throw new BundleException(NLS.bind(Msg.ModuleContainer_NameCollision, name, builder.getVersion()), 9);
/*      */       }
/*      */       
/*  395 */       module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*      */       
/*      */       try {
/*  398 */         module.checkValid();
/*  399 */         previousState = module.getState();
/*  400 */         if (Module.ACTIVE_SET.contains(previousState))
/*      */         {
/*  402 */           module.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/*      */         }
/*  404 */         if (Module.RESOLVED_SET.contains(previousState)) {
/*      */           
/*  406 */           module.setState(Module.State.INSTALLED);
/*  407 */           this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED, module, module);
/*      */         } 
/*  409 */         this.moduleDatabase.update(module, builder, revisionInfo);
/*      */       } finally {
/*  411 */         module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*      */       } 
/*      */       
/*  414 */       this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.UPDATED, module, module);
/*      */       
/*  416 */       if (Module.ACTIVE_SET.contains(previousState)) {
/*      */         
/*      */         try {
/*  419 */           module.start(new Module.StartOptions[] { Module.StartOptions.TRANSIENT_RESUME });
/*  420 */         } catch (BundleException e) {
/*  421 */           getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]);
/*      */         } 
/*      */       }
/*      */     } finally {
/*  425 */       if (nameLocked) {
/*  426 */         this.nameLocks.unlock(name);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void uninstall(Module module) throws BundleException {
/*  436 */     checkAdminPermission(module.getBundle(), "lifecycle");
/*  437 */     module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */     
/*      */     try {
/*  440 */       module.checkValid();
/*  441 */       Module.State previousState = module.getState();
/*  442 */       if (Module.ACTIVE_SET.contains(module.getState())) {
/*      */         try {
/*  444 */           module.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/*  445 */         } catch (BundleException e) {
/*  446 */           this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]);
/*      */         } 
/*      */       }
/*  449 */       if (Module.RESOLVED_SET.contains(previousState)) {
/*      */         
/*  451 */         module.setState(Module.State.INSTALLED);
/*  452 */         this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED, module, module);
/*      */       } 
/*  454 */       this.moduleDatabase.uninstall(module);
/*  455 */       module.setState(Module.State.UNINSTALLED);
/*      */     } finally {
/*  457 */       module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */     } 
/*  459 */     this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED, module, module);
/*      */   }
/*      */   
/*      */   ModuleWiring getWiring(ModuleRevision revision) {
/*  463 */     return this.moduleDatabase.getWiring(revision);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FrameworkWiring getFrameworkWiring() {
/*  471 */     return this.frameworkWiring;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FrameworkStartLevel getFrameworkStartLevel() {
/*  479 */     return this.frameworkStartLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolutionReport resolve(Collection<Module> triggers, boolean triggersMandatory) {
/*  492 */     return resolve(triggers, triggersMandatory, false);
/*      */   }
/*      */   
/*      */   private ResolutionReport resolve(Collection<Module> triggers, boolean triggersMandatory, boolean restartTriggers) {
/*  496 */     if (isRefreshingSystemModule()) {
/*  497 */       return new ModuleResolutionReport(null, Collections.emptyMap(), new ResolutionException("Unable to resolve while shutting down the framework."));
/*      */     }
/*  499 */     ResolutionReport report = null; 
/*  500 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/*  514 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (ResolutionLockException e)
/*  515 */     { return new ModuleResolutionReport(null, Collections.emptyMap(), new ResolutionException("Timeout acquiring lock for resolution", e, Collections.emptyList())); }
/*      */   
/*      */   }
/*      */   private ResolutionReport resolveAndApply(Collection<Module> triggers, boolean triggersMandatory, boolean restartTriggers, ResolutionLock.Permits resolutionPermits) {
/*      */     Map<ModuleRevision, ModuleWiring> wiringClone;
/*      */     long timestamp;
/*  521 */     if (triggers == null) {
/*  522 */       triggers = new ArrayList<>(0);
/*      */     }
/*  524 */     if (triggers.isEmpty())
/*      */     {
/*  526 */       triggersMandatory = false;
/*      */     }
/*  528 */     Collection<ModuleRevision> triggerRevisions = new ArrayList<>(triggers.size());
/*  529 */     Collection<ModuleRevision> unresolved = new ArrayList<>();
/*      */ 
/*      */     
/*  532 */     this.moduleDatabase.readLock();
/*      */     try {
/*  534 */       timestamp = this.moduleDatabase.getRevisionsTimestamp();
/*  535 */       wiringClone = this.moduleDatabase.getWiringsClone();
/*  536 */       for (Module module : triggers) {
/*  537 */         if (!Module.State.UNINSTALLED.equals(module.getState())) {
/*  538 */           ModuleRevision current = module.getCurrentRevision();
/*  539 */           if (current != null)
/*  540 */             triggerRevisions.add(current); 
/*      */         } 
/*      */       } 
/*  543 */       Collection<Module> allModules = this.moduleDatabase.getModules();
/*  544 */       for (Module module : allModules) {
/*  545 */         ModuleRevision revision = module.getCurrentRevision();
/*  546 */         if (revision != null && !wiringClone.containsKey(revision))
/*  547 */           unresolved.add(revision); 
/*      */       } 
/*      */     } finally {
/*  550 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */     
/*  553 */     ModuleResolutionReport report = this.moduleResolver.resolveDelta(triggerRevisions, triggersMandatory, unresolved, wiringClone, this.moduleDatabase);
/*  554 */     Map<Resource, List<Wire>> resolutionResult = report.getResolutionResult();
/*  555 */     Map<ModuleRevision, ModuleWiring> deltaWiring = (resolutionResult == null) ? Collections.<ModuleRevision, ModuleWiring>emptyMap() : this.moduleResolver.generateDelta(resolutionResult, wiringClone);
/*  556 */     if (deltaWiring.isEmpty()) {
/*  557 */       return report;
/*      */     }
/*  559 */     Collection<Module> modulesResolved = new ArrayList<>();
/*  560 */     for (ModuleRevision deltaRevision : deltaWiring.keySet()) {
/*  561 */       if (!wiringClone.containsKey(deltaRevision)) {
/*  562 */         modulesResolved.add(deltaRevision.getRevisions().getModule());
/*      */       }
/*      */     } 
/*  565 */     return applyDelta(deltaWiring, modulesResolved, triggers, timestamp, restartTriggers, resolutionPermits) ? report : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleWire resolveDynamic(String dynamicPkgName, ModuleRevision revision) {
/*      */     
/*  580 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/*  665 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (ResolutionLockException resolutionLockException)
/*  666 */     { return null; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ModuleWire findExistingDynamicWire(ModuleWiring wiring, String dynamicPkgName) {
/*  673 */     if (wiring == null) {
/*  674 */       return null;
/*      */     }
/*  676 */     List<ModuleWire> wires = wiring.getRequiredModuleWires("osgi.wiring.package");
/*      */ 
/*      */     
/*  679 */     for (int i = wires.size() - 1; i >= 0; i--) {
/*  680 */       ModuleWire wire = wires.get(i);
/*  681 */       if (dynamicPkgName.equals(wire.getCapability().getAttributes().get("osgi.wiring.package"))) {
/*  682 */         return wire;
/*      */       }
/*  684 */       if (!"dynamic".equals(wire.getRequirement().getDirectives().get("resolution"))) {
/*  685 */         return null;
/*      */       }
/*      */     } 
/*  688 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleContainer(ModuleContainerAdaptor adaptor, ModuleDatabase moduledataBase)
/*      */   {
/*  701 */     this._resolutionLock = new ResolutionLock();
/*  702 */     this._bundleStateLock = new ReentrantLock(); this.adaptor = adaptor; this.moduleResolver = new ModuleResolver(adaptor); this.moduleDatabase = moduledataBase; this.frameworkWiring = new ContainerWiring(); this.frameworkStartLevel = new ContainerStartLevel(); long tempModuleLockTimeout = 30L; String moduleLockTimeoutProp = adaptor.getProperty("osgi.module.lock.timeout"); if (moduleLockTimeoutProp != null)
/*      */       try {
/*      */         tempModuleLockTimeout = Long.parseLong(moduleLockTimeoutProp); if (tempModuleLockTimeout < 1L)
/*      */           tempModuleLockTimeout = 1L; 
/*      */       } catch (NumberFormatException numberFormatException) {}  this.moduleLockTimeout = tempModuleLockTimeout; DebugOptions debugOptions = adaptor.getDebugOptions(); if (debugOptions != null)
/*      */       this.DEBUG_MONITOR_LAZY = debugOptions.getBooleanOption("org.eclipse.osgi/monitor/lazy", false); 
/*      */     String autoStartOnResolveProp = adaptor.getProperty("osgi.module.auto.start.on.resolve");
/*      */     if (autoStartOnResolveProp == null)
/*      */       autoStartOnResolveProp = Boolean.toString(true); 
/*      */     this.autoStartOnResolve = Boolean.parseBoolean(autoStartOnResolveProp);
/*  712 */     this.restrictParallelStart = Boolean.parseBoolean(adaptor.getProperty("equinox.start.level.restrict.parallel")); } static class ResolutionLockException extends Exception { private static final long serialVersionUID = 1L; public ResolutionLockException() {} public ResolutionLockException(Throwable cause) { super(cause); }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ResolutionLock
/*      */   {
/*      */     static final int MAX_RESOLUTION_PERMITS = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  727 */     final Semaphore permitPool = new Semaphore(10);
/*  728 */     final ReentrantReadWriteLock reenterLock = new ReentrantReadWriteLock();
/*      */     
/*      */     class Permits implements Closeable {
/*      */       private final int aquiredPermits;
/*  732 */       private final AtomicBoolean closed = new AtomicBoolean();
/*      */       
/*      */       Permits(int requestedPermits) throws ModuleContainer.ResolutionLockException {
/*  735 */         if (ModuleContainer.ResolutionLock.this.reenterLock.getReadHoldCount() > 0)
/*      */         {
/*  737 */           requestedPermits = 0;
/*      */         }
/*  739 */         this.aquiredPermits = requestedPermits;
/*  740 */         boolean previousInterruption = Thread.interrupted();
/*      */         try {
/*  742 */           if (!ModuleContainer.ResolutionLock.this.permitPool.tryAcquire(requestedPermits, 30L, TimeUnit.SECONDS)) {
/*  743 */             throw new ModuleContainer.ResolutionLockException();
/*      */           }
/*  745 */         } catch (InterruptedException e) {
/*  746 */           throw new ModuleContainer.ResolutionLockException(e);
/*      */         } finally {
/*  748 */           if (previousInterruption) {
/*  749 */             Thread.currentThread().interrupt();
/*      */           }
/*      */         } 
/*      */         
/*  753 */         ModuleContainer.ResolutionLock.this.reenterLock.readLock().lock();
/*      */       }
/*      */ 
/*      */       
/*      */       public void close() {
/*  758 */         if (this.closed.compareAndSet(false, true)) {
/*  759 */           ModuleContainer.ResolutionLock.this.permitPool.release(this.aquiredPermits);
/*  760 */           ModuleContainer.ResolutionLock.this.reenterLock.readLock().unlock();
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     Permits acquire(int requestedPermits) throws ModuleContainer.ResolutionLockException {
/*  766 */       return new Permits(requestedPermits);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean applyDelta(Map<ModuleRevision, ModuleWiring> deltaWiring, Collection<Module> modulesResolved, Collection<Module> triggers, long timestamp, boolean restartTriggers, ResolutionLock.Permits resolutionPermits) {
/*  771 */     List<Module> modulesLocked = new ArrayList<>(modulesResolved.size());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  780 */     try { this._bundleStateLock.lock();
/*      */       try {
/*  782 */         for (Module module : modulesResolved) {
/*      */           
/*      */           try {
/*  785 */             if (timestamp != this.moduleDatabase.getRevisionsTimestamp()) {
/*  786 */               return false;
/*      */             }
/*  788 */             module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.RESOLVED);
/*  789 */             modulesLocked.add(module);
/*  790 */           } catch (BundleException e) {
/*      */             
/*  792 */             if (timestamp != this.moduleDatabase.getRevisionsTimestamp()) {
/*  793 */               return false;
/*      */             }
/*      */             
/*  796 */             throw new IllegalStateException(Msg.ModuleContainer_StateLockError, e);
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  800 */         this._bundleStateLock.unlock();
/*      */       } 
/*      */       
/*  803 */       Map<ModuleWiring, Collection<ModuleRevision>> hostsWithDynamicFrags = new HashMap<>(0);
/*  804 */       this.moduleDatabase.writeLock();
/*      */       try {
/*  806 */         if (timestamp != this.moduleDatabase.getRevisionsTimestamp()) {
/*  807 */           return false;
/*      */         }
/*  809 */         Map<ModuleRevision, ModuleWiring> wiringCopy = this.moduleDatabase.getWiringsCopy();
/*  810 */         for (Map.Entry<ModuleRevision, ModuleWiring> deltaEntry : deltaWiring.entrySet()) {
/*  811 */           ModuleWiring current = wiringCopy.get(deltaEntry.getKey());
/*  812 */           if (current != null) {
/*      */             
/*  814 */             current.setCapabilities(((ModuleWiring)deltaEntry.getValue()).getCapabilities());
/*  815 */             current.setProvidedWires(((ModuleWiring)deltaEntry.getValue()).getProvidedWires());
/*  816 */             current.setRequirements(((ModuleWiring)deltaEntry.getValue()).getRequirements());
/*  817 */             current.setRequiredWires(((ModuleWiring)deltaEntry.getValue()).getRequiredWires());
/*  818 */             deltaEntry.setValue(current); continue;
/*      */           } 
/*  820 */           ModuleRevision revision = ((ModuleWiring)deltaEntry.getValue()).getRevision();
/*  821 */           modulesResolved.add(revision.getRevisions().getModule());
/*  822 */           if ((revision.getTypes() & 0x1) != 0) {
/*  823 */             for (ModuleWire hostWire : ((ModuleWiring)deltaEntry.getValue()).getRequiredModuleWires("osgi.wiring.host")) {
/*      */               
/*  825 */               ModuleWiring hostWiring = hostWire.getProvider().getWiring();
/*  826 */               if (hostWiring != null) {
/*  827 */                 Collection<ModuleRevision> dynamicFragments = hostsWithDynamicFrags.get(hostWiring);
/*  828 */                 if (dynamicFragments == null) {
/*  829 */                   dynamicFragments = new ArrayList<>();
/*  830 */                   hostsWithDynamicFrags.put(hostWiring, dynamicFragments);
/*      */                 } 
/*  832 */                 dynamicFragments.add(hostWire.getRequirer());
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */         
/*  838 */         this.moduleDatabase.mergeWiring(deltaWiring);
/*  839 */         this.moduleDatabase.sortModules(modulesLocked, new ModuleDatabase.Sort[] { ModuleDatabase.Sort.BY_DEPENDENCY, ModuleDatabase.Sort.BY_START_LEVEL });
/*      */       } finally {
/*  841 */         this.moduleDatabase.writeUnlock();
/*      */       } 
/*      */       
/*  844 */       for (Module module : modulesLocked) {
/*  845 */         module.setState(Module.State.RESOLVED);
/*      */       
/*      */       }
/*      */        }
/*      */     
/*      */     finally
/*      */     
/*      */     { 
/*  853 */       for (Module module : modulesLocked)
/*  854 */         module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.RESOLVED);  }  for (Module module : modulesLocked) module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.RESOLVED);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  859 */     resolutionPermits.close();
/*      */     
/*  861 */     for (Module module : modulesLocked) {
/*  862 */       this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.RESOLVED, module, module);
/*      */     }
/*      */ 
/*      */     
/*  866 */     Set<Module> triggerSet = restartTriggers ? new HashSet<>(triggers) : Collections.<Module>emptySet();
/*  867 */     if (restartTriggers) {
/*  868 */       for (Module module : triggers) {
/*  869 */         if (module.getId().longValue() != 0L && Module.RESOLVED_SET.contains(module.getState())) {
/*  870 */           start(module, new Module.StartOptions[] { Module.StartOptions.TRANSIENT_RESUME });
/*      */         }
/*      */       } 
/*      */     }
/*  874 */     if (this.autoStartOnResolve)
/*      */     {
/*      */       
/*  877 */       for (Module module : modulesLocked) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  883 */         if (!module.inStart() && module.getId().longValue() != 0L && !triggerSet.contains(module)) {
/*  884 */           start(module, new Module.StartOptions[] { Module.StartOptions.TRANSIENT_IF_AUTO_START, Module.StartOptions.TRANSIENT_RESUME });
/*      */         }
/*      */       } 
/*      */     }
/*  888 */     return true;
/*      */   }
/*      */   class Permits implements Closeable {
/*      */     private final int aquiredPermits; private final AtomicBoolean closed = new AtomicBoolean(); Permits(int requestedPermits) throws ModuleContainer.ResolutionLockException { if (((ModuleContainer.ResolutionLock)ModuleContainer.this).reenterLock.getReadHoldCount() > 0) requestedPermits = 0;  this.aquiredPermits = requestedPermits; boolean previousInterruption = Thread.interrupted(); try { if (!((ModuleContainer.ResolutionLock)ModuleContainer.this).permitPool.tryAcquire(requestedPermits, 30L, TimeUnit.SECONDS))
/*      */           throw new ModuleContainer.ResolutionLockException();  } catch (InterruptedException e) { throw new ModuleContainer.ResolutionLockException(e); } finally { if (previousInterruption)
/*  893 */           Thread.currentThread().interrupt();  }  ((ModuleContainer.ResolutionLock)ModuleContainer.this).reenterLock.readLock().lock(); } public void close() { if (this.closed.compareAndSet(false, true)) { this.this$1.permitPool.release(this.aquiredPermits); this.this$1.reenterLock.readLock().unlock(); }  } } private void start(Module module, Module.StartOptions... options) { try { secureAction.start(module, options); }
/*  894 */     catch (BundleException e)
/*  895 */     { if (e.getType() == 7 && 
/*  896 */         Module.ACTIVE_SET.contains(module.getState())) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  902 */       this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]); }
/*  903 */     catch (IllegalStateException illegalStateException)
/*      */     { return; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ModuleRequirement.DynamicModuleRequirement> getDynamicRequirements(String dynamicPkgName, ModuleRevision revision) {
/*  911 */     if ((revision.getTypes() & 0x1) != 0)
/*      */     {
/*  913 */       return Collections.emptyList();
/*      */     }
/*  915 */     ModuleWiring wiring = revision.getWiring();
/*  916 */     if (wiring == null)
/*      */     {
/*  918 */       return Collections.emptyList();
/*      */     }
/*  920 */     List<ModuleRequirement.DynamicModuleRequirement> result = new ArrayList<>(1);
/*      */ 
/*      */     
/*  923 */     for (ModuleRequirement requirement : wiring.getModuleRequirements("osgi.wiring.package")) {
/*  924 */       ModuleRequirement.DynamicModuleRequirement dynamicRequirement = requirement.getDynamicPackageRequirement(revision, dynamicPkgName);
/*  925 */       if (dynamicRequirement != null) {
/*  926 */         result.add(dynamicRequirement);
/*      */       }
/*      */     } 
/*      */     
/*  930 */     if (!result.isEmpty())
/*      */     {
/*  932 */       for (ModuleCapability capability : wiring.getModuleCapabilities("osgi.wiring.package")) {
/*  933 */         if (dynamicPkgName.equals(capability.getAttributes().get("osgi.wiring.package")))
/*      */         {
/*  935 */           return Collections.emptyList();
/*      */         }
/*      */       } 
/*      */     }
/*  939 */     return result;
/*      */   }
/*      */   
/*      */   private Collection<Module> unresolve(Collection<Module> initial) {
/*  943 */     Collection<Module> refreshTriggers = null;
/*  944 */     while (refreshTriggers == null) {
/*  945 */       refreshTriggers = unresolve0(initial);
/*      */     }
/*  947 */     return refreshTriggers;
/*      */   }
/*      */   
/*      */   private Collection<Module> unresolve0(Collection<Module> initial) {
/*      */     Map<ModuleRevision, ModuleWiring> wiringCopy;
/*      */     List<Module> refreshTriggers;
/*      */     Collection<ModuleRevision> toRemoveRevisions;
/*      */     Collection<ModuleWiring> toRemoveWirings;
/*      */     Map<ModuleWiring, Collection<ModuleWire>> toRemoveWireLists;
/*      */     long timestamp;
/*  957 */     this.moduleDatabase.readLock();
/*      */     try {
/*  959 */       checkSystemExtensionRefresh(initial);
/*  960 */       timestamp = this.moduleDatabase.getRevisionsTimestamp();
/*  961 */       wiringCopy = this.moduleDatabase.getWiringsCopy();
/*  962 */       refreshTriggers = new ArrayList<>(getRefreshClosure(initial, wiringCopy));
/*  963 */       toRemoveRevisions = new ArrayList<>();
/*  964 */       toRemoveWirings = new ArrayList<>();
/*  965 */       toRemoveWireLists = new HashMap<>();
/*  966 */       for (Iterator<Module> iTriggers = refreshTriggers.iterator(); iTriggers.hasNext(); ) {
/*  967 */         Module module = iTriggers.next();
/*  968 */         boolean first = true;
/*  969 */         for (ModuleRevision revision : module.getRevisions().getModuleRevisions()) {
/*  970 */           ModuleWiring removedWiring = wiringCopy.remove(revision);
/*  971 */           if (removedWiring != null) {
/*  972 */             toRemoveWirings.add(removedWiring);
/*  973 */             List<ModuleWire> removedWires = removedWiring.getRequiredModuleWires(null);
/*  974 */             for (ModuleWire wire : removedWires) {
/*  975 */               Collection<ModuleWire> providerWires = toRemoveWireLists.get(wire.getProviderWiring());
/*  976 */               if (providerWires == null) {
/*  977 */                 providerWires = new ArrayList<>();
/*  978 */                 toRemoveWireLists.put(wire.getProviderWiring(), providerWires);
/*      */               } 
/*  980 */               providerWires.add(wire);
/*      */             } 
/*      */           } 
/*  983 */           if (!first || revision.getRevisions().isUninstalled()) {
/*  984 */             toRemoveRevisions.add(revision);
/*      */           }
/*  986 */           first = false;
/*      */         } 
/*  988 */         if (module.getState().equals(Module.State.UNINSTALLED)) {
/*  989 */           iTriggers.remove();
/*      */         }
/*      */       } 
/*  992 */       this.moduleDatabase.sortModules(refreshTriggers, new ModuleDatabase.Sort[] { ModuleDatabase.Sort.BY_START_LEVEL, ModuleDatabase.Sort.BY_DEPENDENCY });
/*      */     } finally {
/*  994 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */     
/*  997 */     Module systemModule = this.moduleDatabase.getModule(0L);
/*  998 */     if (refreshTriggers.contains(systemModule) && Module.ACTIVE_SET.contains(systemModule.getState())) {
/*  999 */       refreshSystemModule();
/* 1000 */       return Collections.emptyList();
/*      */     } 
/* 1002 */     Collection<Module> modulesLocked = new ArrayList<>(refreshTriggers.size());
/* 1003 */     Collection<Module> modulesUnresolved = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1011 */     try { this._bundleStateLock.lock();
/*      */       
/*      */       try {
/* 1014 */         for (ListIterator<Module> listIterator = refreshTriggers.listIterator(refreshTriggers.size()); listIterator.hasPrevious(); ) {
/* 1015 */           Module refreshModule = listIterator.previous();
/* 1016 */           refreshModule.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED);
/* 1017 */           modulesLocked.add(refreshModule);
/*      */         } 
/* 1019 */       } catch (BundleException e) {
/*      */         
/* 1021 */         throw new IllegalStateException(Msg.ModuleContainer_StateLockError, e);
/*      */       } finally {
/* 1023 */         this._bundleStateLock.unlock();
/*      */       } 
/*      */ 
/*      */       
/* 1027 */       for (ListIterator<Module> iTriggers = refreshTriggers.listIterator(refreshTriggers.size()); iTriggers.hasPrevious(); ) {
/* 1028 */         Module refreshModule = iTriggers.previous();
/* 1029 */         Module.State previousState = refreshModule.getState();
/* 1030 */         if (Module.ACTIVE_SET.contains(previousState)) {
/*      */           try {
/* 1032 */             refreshModule.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/* 1033 */           } catch (BundleException e) {
/* 1034 */             this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, refreshModule, (Throwable)e, new FrameworkListener[0]);
/*      */           }  continue;
/*      */         } 
/* 1037 */         iTriggers.remove();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1042 */       for (Module module : modulesLocked) {
/* 1043 */         if (Module.ACTIVE_SET.contains(module.getState())) {
/* 1044 */           throw new IllegalStateException("Module is in the wrong state: " + module + ": " + module.getState());
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1049 */       this.moduleDatabase.writeLock();
/*      */       try {
/* 1051 */         if (timestamp != this.moduleDatabase.getRevisionsTimestamp()) {
/* 1052 */           return null;
/*      */         }
/* 1054 */         for (Map.Entry<ModuleWiring, Collection<ModuleWire>> entry : toRemoveWireLists.entrySet()) {
/* 1055 */           NamespaceList.Builder<ModuleWire> provided = ((ModuleWiring)entry.getKey()).getProvidedWires().createBuilder();
/* 1056 */           provided.removeAll(entry.getValue());
/* 1057 */           ((ModuleWiring)entry.getKey()).setProvidedWires(provided.build());
/* 1058 */           for (ModuleWire removedWire : entry.getValue())
/*      */           {
/* 1060 */             removedWire.invalidate();
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1065 */         for (ModuleRevision removed : toRemoveRevisions) {
/* 1066 */           removed.getRevisions().removeRevision(removed);
/* 1067 */           this.moduleDatabase.removeCapabilities(removed);
/*      */         } 
/*      */         
/* 1070 */         for (ModuleWiring moduleWiring : toRemoveWirings) {
/* 1071 */           moduleWiring.invalidate();
/*      */         }
/* 1073 */         this.moduleDatabase.setWiring(wiringCopy);
/*      */         
/* 1075 */         this.moduleDatabase.cleanupRemovalPending();
/*      */       } finally {
/* 1077 */         this.moduleDatabase.writeUnlock();
/*      */ 
/*      */       
/*      */       }
/*      */       
/*      */        }
/*      */     
/*      */     finally
/*      */     
/*      */     { 
/* 1087 */       for (Module module : modulesLocked)
/* 1088 */         module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED);  }  for (Module module : modulesLocked) module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED);
/*      */ 
/*      */ 
/*      */     
/* 1092 */     for (Module module : modulesUnresolved) {
/* 1093 */       this.adaptor.publishModuleEvent(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED, module, module);
/*      */     }
/* 1095 */     return refreshTriggers;
/*      */   }
/*      */   
/*      */   private void checkSystemExtensionRefresh(Collection<Module> initial) {
/* 1099 */     if (initial == null) {
/*      */       return;
/*      */     }
/* 1102 */     Long zero = Long.valueOf(0L);
/* 1103 */     for (Iterator<Module> iModules = initial.iterator(); iModules.hasNext(); ) {
/* 1104 */       Module m = iModules.next();
/* 1105 */       if (m.getId().equals(zero)) {
/*      */         
/* 1107 */         if (Module.ACTIVE_SET.contains(m.getState()))
/* 1108 */           iModules.remove(); 
/*      */         continue;
/*      */       } 
/* 1111 */       if (Module.RESOLVED_SET.contains(m.getState())) {
/*      */         
/* 1113 */         ModuleRevision current = m.getCurrentRevision();
/* 1114 */         if ((current.getTypes() & 0x1) != 0) {
/* 1115 */           ModuleWiring wiring = current.getWiring();
/* 1116 */           if (wiring != null) {
/* 1117 */             List<ModuleWire> hostWires = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 1118 */             for (ModuleWire hostWire : hostWires) {
/* 1119 */               if (hostWire.getProvider().getRevisions().getModule().getId().equals(zero))
/*      */               {
/*      */                 
/* 1122 */                 iModules.remove();
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolutionReport refresh(Collection<Module> initial) {
/* 1141 */     initial = (initial == null) ? null : new ArrayList<>(initial);
/* 1142 */     Collection<Module> refreshTriggers = unresolve(initial);
/* 1143 */     if (!isRefreshingSystemModule()) {
/* 1144 */       return resolve(refreshTriggers, false, true);
/*      */     }
/* 1146 */     return new ModuleResolutionReport(null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<Module> getDependencyClosure(Collection<Module> initial) {
/* 1156 */     this.moduleDatabase.readLock();
/*      */     try {
/* 1158 */       return getRefreshClosure(initial, this.moduleDatabase.getWiringsCopy());
/*      */     } finally {
/* 1160 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<ModuleRevision> getRemovalPending() {
/* 1170 */     return this.moduleDatabase.getRemovalPending();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStartLevel() {
/* 1183 */     return this.frameworkStartLevel.getStartLevel();
/*      */   }
/*      */   
/*      */   void setStartLevel(Module module, int startlevel) {
/* 1187 */     this.frameworkStartLevel.setStartLevel(module, startlevel);
/*      */   }
/*      */   
/*      */   long getModuleLockTimeout() {
/* 1191 */     return this.moduleLockTimeout;
/*      */   }
/*      */   
/*      */   void open() {
/* 1195 */     loadModules();
/* 1196 */     this.frameworkStartLevel.open();
/* 1197 */     this.frameworkWiring.open();
/* 1198 */     this.refreshingSystemModule.set(null);
/*      */   }
/*      */   
/*      */   void close() {
/* 1202 */     this.frameworkStartLevel.close();
/* 1203 */     this.frameworkWiring.close();
/* 1204 */     unloadModules();
/*      */   }
/*      */   
/*      */   private void loadModules() {
/* 1208 */     List<Module> modules = null;
/* 1209 */     this.moduleDatabase.readLock();
/*      */     try {
/* 1211 */       modules = getModules();
/* 1212 */       for (Module module : modules) {
/*      */         try {
/* 1214 */           module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.RESOLVED);
/* 1215 */           ModuleWiring wiring = this.moduleDatabase.getWiring(module.getCurrentRevision());
/* 1216 */           if (wiring != null) {
/* 1217 */             module.setState(Module.State.RESOLVED); continue;
/*      */           } 
/* 1219 */           module.setState(Module.State.INSTALLED);
/*      */         }
/* 1221 */         catch (BundleException e) {
/* 1222 */           throw new IllegalStateException("Unable to lock module state.", e);
/*      */         } 
/*      */       } 
/* 1225 */       Map<ModuleRevision, ModuleWiring> wirings = this.moduleDatabase.getWiringsCopy();
/* 1226 */       for (ModuleWiring wiring : wirings.values()) {
/* 1227 */         wiring.validate();
/*      */       }
/*      */     } finally {
/* 1230 */       if (modules != null) {
/* 1231 */         for (Module module : modules) {
/*      */           try {
/* 1233 */             module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.RESOLVED);
/* 1234 */           } catch (IllegalMonitorStateException illegalMonitorStateException) {}
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1239 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void unloadModules() {
/* 1244 */     List<Module> modules = null;
/* 1245 */     this.moduleDatabase.readLock();
/*      */     try {
/* 1247 */       modules = getModules();
/* 1248 */       for (Module module : modules) {
/* 1249 */         if (module.getId().longValue() != 0L) {
/*      */           try {
/* 1251 */             module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/* 1252 */           } catch (BundleException e) {
/* 1253 */             throw new IllegalStateException("Unable to lock module state.", e);
/*      */           } 
/* 1255 */           module.setState(Module.State.UNINSTALLED);
/*      */         } 
/*      */       } 
/* 1258 */       Map<ModuleRevision, ModuleWiring> wirings = this.moduleDatabase.getWiringsCopy();
/* 1259 */       for (ModuleWiring wiring : wirings.values()) {
/* 1260 */         wiring.unload();
/*      */       }
/*      */     } finally {
/* 1263 */       if (modules != null) {
/* 1264 */         for (Module module : modules) {
/* 1265 */           if (module.getId().longValue() != 0L) {
/*      */             try {
/* 1267 */               module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/* 1268 */             } catch (IllegalMonitorStateException illegalMonitorStateException) {}
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1274 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitialModuleStates() throws BundleException {
/* 1283 */     this.moduleDatabase.readLock();
/*      */     try {
/* 1285 */       List<Module> modules = getModules();
/* 1286 */       for (Module module : modules) {
/* 1287 */         if (module.getId().longValue() == 0L) {
/* 1288 */           module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */           try {
/* 1290 */             module.setState(Module.State.INSTALLED);
/*      */           } finally {
/* 1292 */             module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */           }  continue;
/*      */         } 
/* 1295 */         module.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */         try {
/* 1297 */           module.setState(Module.State.UNINSTALLED);
/*      */         } finally {
/* 1299 */           module.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNINSTALLED);
/*      */         } 
/*      */       } 
/*      */       
/* 1303 */       Map<ModuleRevision, ModuleWiring> wirings = this.moduleDatabase.getWiringsCopy();
/* 1304 */       for (ModuleWiring wiring : wirings.values()) {
/* 1305 */         wiring.unload();
/*      */       }
/*      */     } finally {
/* 1308 */       this.moduleDatabase.readUnlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   Set<Module> getRefreshClosure(Collection<Module> initial, Map<ModuleRevision, ModuleWiring> wiringCopy) {
/* 1313 */     Set<Module> refreshClosure = new HashSet<>();
/* 1314 */     if (initial == null) {
/* 1315 */       initial = new HashSet<>();
/* 1316 */       Collection<ModuleRevision> removalPending = this.moduleDatabase.getRemovalPending();
/* 1317 */       for (ModuleRevision revision : removalPending) {
/* 1318 */         initial.add(revision.getRevisions().getModule());
/*      */       }
/*      */     } 
/* 1321 */     for (Module module : initial)
/* 1322 */       addDependents(module, wiringCopy, refreshClosure); 
/* 1323 */     return refreshClosure;
/*      */   }
/*      */   
/*      */   private static void addDependents(Module module, Map<ModuleRevision, ModuleWiring> wiringCopy, Set<Module> refreshClosure) {
/* 1327 */     if (refreshClosure.contains(module))
/*      */       return; 
/* 1329 */     refreshClosure.add(module);
/* 1330 */     List<ModuleRevision> revisions = module.getRevisions().getModuleRevisions();
/* 1331 */     for (ModuleRevision revision : revisions) {
/* 1332 */       ModuleWiring wiring = wiringCopy.get(revision);
/* 1333 */       if (wiring == null)
/*      */         continue; 
/* 1335 */       List<ModuleWire> provided = wiring.getProvidedModuleWires(null);
/*      */ 
/*      */       
/* 1338 */       for (ModuleWire providedWire : provided) {
/* 1339 */         addDependents(providedWire.getRequirer().getRevisions().getModule(), wiringCopy, refreshClosure);
/*      */       }
/*      */       
/* 1342 */       if (revision.getTypes() == 1) {
/* 1343 */         List<ModuleWire> hosts = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 1344 */         for (ModuleWire hostWire : hosts) {
/* 1345 */           addDependents(hostWire.getProvider().getRevisions().getModule(), wiringCopy, refreshClosure);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static Collection<ModuleRevision> getDependencyClosure(ModuleRevision initial, Map<ModuleRevision, ModuleWiring> wiringCopy) {
/* 1352 */     Set<ModuleRevision> dependencyClosure = new HashSet<>();
/* 1353 */     addDependents(initial, wiringCopy, dependencyClosure);
/* 1354 */     return dependencyClosure;
/*      */   }
/*      */   
/*      */   private static void addDependents(ModuleRevision revision, Map<ModuleRevision, ModuleWiring> wiringCopy, Set<ModuleRevision> dependencyClosure) {
/* 1358 */     if (dependencyClosure.contains(revision))
/*      */       return; 
/* 1360 */     dependencyClosure.add(revision);
/* 1361 */     ModuleWiring wiring = wiringCopy.get(revision);
/* 1362 */     if (wiring == null)
/*      */       return; 
/* 1364 */     List<ModuleWire> provided = wiring.getProvidedModuleWires(null);
/*      */ 
/*      */     
/* 1367 */     for (ModuleWire providedWire : provided) {
/* 1368 */       addDependents(providedWire.getRequirer(), wiringCopy, dependencyClosure);
/*      */     }
/*      */     
/* 1371 */     if (revision.getTypes() == 1) {
/* 1372 */       List<ModuleWire> hosts = wiring.getRequiredModuleWires("osgi.wiring.host");
/* 1373 */       for (ModuleWire hostWire : hosts) {
/* 1374 */         addDependents(hostWire.getProvider(), wiringCopy, dependencyClosure);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   Bundle getSystemBundle() {
/* 1380 */     Module systemModule = this.moduleDatabase.getModule(0L);
/* 1381 */     return (systemModule == null) ? null : systemModule.getBundle();
/*      */   }
/*      */   
/*      */   void checkAdminPermission(Bundle bundle, String action) {
/* 1385 */     if (bundle == null)
/*      */       return; 
/* 1387 */     SecurityManager sm = System.getSecurityManager();
/* 1388 */     if (sm != null)
/* 1389 */       sm.checkPermission((Permission)new AdminPermission(bundle, action)); 
/*      */   }
/*      */   
/*      */   void refreshSystemModule() {
/* 1393 */     final SystemModule systemModule = (SystemModule)this.moduleDatabase.getModule(0L);
/* 1394 */     if (systemModule == this.refreshingSystemModule.getAndSet(systemModule)) {
/*      */       return;
/*      */     }
/* 1397 */     getAdaptor().refreshedSystemModule();
/* 1398 */     Thread t = new Thread(new Runnable()
/*      */         {
/*      */           public void run() {
/*      */             try {
/* 1402 */               systemModule.lockStateChange(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED);
/*      */               try {
/* 1404 */                 systemModule.stop(new Module.StopOptions[0]);
/*      */               } finally {
/* 1406 */                 systemModule.unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UNRESOLVED);
/*      */               } 
/* 1408 */             } catch (BundleException e) {
/* 1409 */               e.printStackTrace();
/*      */             } 
/*      */           }
/*      */         });
/* 1413 */     t.start();
/*      */   }
/*      */   
/*      */   boolean isRefreshingSystemModule() {
/* 1417 */     return (this.refreshingSystemModule.get() != null);
/*      */   }
/*      */   
/*      */   static Requirement getIdentityRequirement(String name, Version version) {
/* 1421 */     version = (version == null) ? Version.emptyVersion : version;
/* 1422 */     String filter = "(&(osgi.identity=" + name + ")(" + "version" + "=" + version.toString() + "))";
/* 1423 */     Map<String, String> directives = Collections.singletonMap("filter", filter);
/* 1424 */     return (Requirement)new ModuleRequirement("osgi.identity", directives, Collections.emptyMap(), null);
/*      */   }
/*      */   class ContainerWiring implements FrameworkWiring, EventDispatcher<ContainerWiring, FrameworkListener[], Collection<Module>> { private final Object monitor; private EventManager refreshThread;
/*      */     ContainerWiring() {
/* 1428 */       this.monitor = new Object();
/* 1429 */       this.refreshThread = null;
/*      */     }
/*      */     
/*      */     public Bundle getBundle() {
/* 1433 */       return ModuleContainer.this.getSystemBundle();
/*      */     }
/*      */ 
/*      */     
/*      */     public void refreshBundles(Collection<Bundle> bundles, FrameworkListener... listeners) {
/* 1438 */       ModuleContainer.this.checkAdminPermission(getBundle(), "resolve");
/* 1439 */       Collection<Module> modules = getModules(bundles);
/*      */ 
/*      */ 
/*      */       
/* 1443 */       CopyOnWriteIdentityMap<ContainerWiring, FrameworkListener[]> dispatchListeners = new CopyOnWriteIdentityMap();
/* 1444 */       dispatchListeners.put(this, listeners);
/* 1445 */       ListenerQueue<ContainerWiring, FrameworkListener[], Collection<Module>> queue = new ListenerQueue(getManager());
/* 1446 */       queue.queueListeners(dispatchListeners.entrySet(), this);
/*      */ 
/*      */       
/* 1449 */       queue.dispatchEventAsynchronous(0, modules);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean resolveBundles(Collection<Bundle> bundles) {
/* 1454 */       ModuleContainer.this.checkAdminPermission(getBundle(), "resolve");
/* 1455 */       Collection<Module> modules = getModules(bundles);
/* 1456 */       ModuleContainer.this.resolve(modules, false);
/*      */       
/* 1458 */       if (modules == null) {
/* 1459 */         modules = ModuleContainer.this.getModules();
/*      */       }
/* 1461 */       for (Module module : modules) {
/* 1462 */         if (ModuleContainer.this.getWiring(module.getCurrentRevision()) == null)
/* 1463 */           return false; 
/*      */       } 
/* 1465 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Bundle> getRemovalPendingBundles() {
/* 1470 */       ModuleContainer.this.moduleDatabase.readLock();
/*      */       try {
/* 1472 */         Collection<Bundle> removalPendingBundles = new HashSet<>();
/* 1473 */         Collection<ModuleRevision> removalPending = ModuleContainer.this.moduleDatabase.getRemovalPending();
/* 1474 */         for (ModuleRevision moduleRevision : removalPending) {
/* 1475 */           removalPendingBundles.add(moduleRevision.getBundle());
/*      */         }
/* 1477 */         return removalPendingBundles;
/*      */       } finally {
/* 1479 */         ModuleContainer.this.moduleDatabase.readUnlock();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Bundle> getDependencyClosure(Collection<Bundle> bundles) {
/* 1485 */       Collection<Module> modules = getModules(bundles);
/* 1486 */       ModuleContainer.this.moduleDatabase.readLock();
/*      */       try {
/* 1488 */         Collection<Module> closure = ModuleContainer.this.getRefreshClosure(modules, ModuleContainer.this.moduleDatabase.getWiringsCopy());
/* 1489 */         Collection<Bundle> result = new ArrayList<>(closure.size());
/* 1490 */         for (Module module : closure) {
/* 1491 */           result.add(module.getBundle());
/*      */         }
/* 1493 */         return result;
/*      */       } finally {
/* 1495 */         ModuleContainer.this.moduleDatabase.readUnlock();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<BundleCapability> findProviders(Requirement requirement) {
/* 1501 */       return InternalUtils.asList(ModuleContainer.this.moduleDatabase.findCapabilities(requirement));
/*      */     }
/*      */     
/*      */     private Collection<Module> getModules(final Collection<Bundle> bundles) {
/* 1505 */       if (bundles == null)
/* 1506 */         return null; 
/* 1507 */       return AccessController.<Collection<Module>>doPrivileged(new PrivilegedAction<Collection<Module>>()
/*      */           {
/*      */             public Collection<Module> run() {
/* 1510 */               Collection<Module> result = new ArrayList<>(bundles.size());
/* 1511 */               for (Bundle bundle : bundles) {
/* 1512 */                 Module module = (Module)bundle.adapt(Module.class);
/* 1513 */                 if (module == null)
/* 1514 */                   throw new IllegalStateException("Could not adapt a bundle to a module. " + bundle); 
/* 1515 */                 result.add(module);
/*      */               } 
/* 1517 */               return result;
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispatchEvent(ContainerWiring eventListener, FrameworkListener[] frameworkListeners, int eventAction, Collection<Module> eventObject) {
/*      */       try {
/* 1525 */         ModuleContainer.this.refresh(eventObject);
/*      */       } finally {
/* 1527 */         ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.REFRESH, ModuleContainer.this.moduleDatabase.getModule(0L), null, frameworkListeners);
/*      */       } 
/*      */     }
/*      */     
/*      */     private EventManager getManager() {
/* 1532 */       synchronized (this.monitor) {
/* 1533 */         if (this.refreshThread == null) {
/* 1534 */           this.refreshThread = new EventManager("Refresh Thread: " + ModuleContainer.this.adaptor.toString());
/*      */         }
/* 1536 */         return this.refreshThread;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void close() {
/* 1543 */       synchronized (this.monitor) {
/*      */         
/* 1545 */         EventManager manager = getManager();
/*      */         
/* 1547 */         manager.close();
/*      */       } 
/*      */     }
/*      */     
/*      */     void open() {
/* 1552 */       synchronized (this.monitor) {
/* 1553 */         if (this.refreshThread != null) {
/*      */           
/* 1555 */           this.refreshThread.close();
/*      */           
/* 1557 */           this.refreshThread = null;
/*      */         } 
/*      */       } 
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   public void optionsChanged(DebugOptions options) {
/* 1565 */     this.moduleResolver.setDebugOptions();
/* 1566 */     this.frameworkStartLevel.setDebugOptions();
/* 1567 */     if (options != null) {
/* 1568 */       this.DEBUG_MONITOR_LAZY = options.getBooleanOption("org.eclipse.osgi/monitor/lazy", false);
/* 1569 */       this.DEBUG_BUNDLE_START_TIME = options.getBooleanOption("org.eclipse.osgi/debug/bundleStartTime", false);
/*      */     } 
/*      */   }
/*      */   class ContainerStartLevel implements FrameworkStartLevel, EventDispatcher<Module, FrameworkListener[], Integer> { static final int USE_BEGINNING_START_LEVEL = -2147483648; private static final int FRAMEWORK_STARTLEVEL = 1; private static final int MODULE_STARTLEVEL = 2; private final AtomicInteger activeStartLevel; private final Object eventManagerLock; private EventManager startLevelThread;
/*      */     private final Object frameworkStartLevelLock;
/*      */     boolean debugStartLevel;
/*      */     
/*      */     ContainerStartLevel() {
/* 1577 */       this.activeStartLevel = new AtomicInteger(0);
/* 1578 */       this.eventManagerLock = new Object();
/* 1579 */       this.startLevelThread = null;
/* 1580 */       this.frameworkStartLevelLock = new Object();
/* 1581 */       this.debugStartLevel = false;
/*      */       
/* 1583 */       setDebugOptions();
/*      */     }
/*      */     
/*      */     void setDebugOptions() {
/* 1587 */       DebugOptions options = ModuleContainer.this.getAdaptor().getDebugOptions();
/* 1588 */       this.debugStartLevel = (options == null) ? false : options.getBooleanOption("org.eclipse.osgi/debug/startlevel", false);
/*      */     }
/*      */ 
/*      */     
/*      */     public Bundle getBundle() {
/* 1593 */       return ModuleContainer.this.getSystemBundle();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getStartLevel() {
/* 1598 */       return this.activeStartLevel.get();
/*      */     }
/*      */     
/*      */     void setStartLevel(Module module, int startlevel) {
/* 1602 */       ModuleContainer.this.checkAdminPermission(module.getBundle(), "execute");
/* 1603 */       if (module.getId().longValue() == 0L) {
/* 1604 */         throw new IllegalArgumentException(Msg.ModuleContainer_SystemStartLevelError);
/*      */       }
/* 1606 */       if (startlevel < 1) {
/* 1607 */         throw new IllegalArgumentException(String.valueOf(Msg.ModuleContainer_NegativeStartLevelError) + startlevel);
/*      */       }
/* 1609 */       int currentLevel = module.getStartLevel();
/* 1610 */       if (currentLevel == startlevel) {
/*      */         return;
/*      */       }
/* 1613 */       ModuleContainer.this.moduleDatabase.setStartLevel(module, startlevel);
/*      */ 
/*      */ 
/*      */       
/* 1617 */       if (currentLevel < startlevel || module.isPersistentlyStarted()) {
/*      */ 
/*      */         
/* 1620 */         CopyOnWriteIdentityMap<Module, FrameworkListener[]> dispatchListeners = new CopyOnWriteIdentityMap();
/* 1621 */         dispatchListeners.put(module, new FrameworkListener[0]);
/* 1622 */         ListenerQueue<Module, FrameworkListener[], Integer> queue = new ListenerQueue(getManager());
/* 1623 */         queue.queueListeners(dispatchListeners.entrySet(), this);
/*      */ 
/*      */         
/* 1626 */         queue.dispatchEventAsynchronous(2, Integer.valueOf(startlevel));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setStartLevel(int startlevel, FrameworkListener... listeners) {
/* 1632 */       ModuleContainer.this.checkAdminPermission(getBundle(), "startlevel");
/* 1633 */       if (startlevel < 1) {
/* 1634 */         throw new IllegalArgumentException(String.valueOf(Msg.ModuleContainer_NegativeStartLevelError) + startlevel);
/*      */       }
/*      */       
/* 1637 */       if (this.activeStartLevel.get() == 0) {
/* 1638 */         throw new IllegalStateException(Msg.ModuleContainer_SystemNotActiveError);
/*      */       }
/* 1640 */       if (this.debugStartLevel) {
/* 1641 */         Debug.println("StartLevel: setStartLevel: " + startlevel);
/*      */       }
/*      */ 
/*      */       
/* 1645 */       CopyOnWriteIdentityMap<Module, FrameworkListener[]> dispatchListeners = new CopyOnWriteIdentityMap();
/* 1646 */       dispatchListeners.put(ModuleContainer.this.moduleDatabase.getModule(0L), listeners);
/* 1647 */       ListenerQueue<Module, FrameworkListener[], Integer> queue = new ListenerQueue(getManager());
/* 1648 */       queue.queueListeners(dispatchListeners.entrySet(), this);
/*      */ 
/*      */       
/* 1651 */       queue.dispatchEventAsynchronous(1, Integer.valueOf(startlevel));
/*      */     }
/*      */ 
/*      */     
/*      */     public int getInitialBundleStartLevel() {
/* 1656 */       return ModuleContainer.this.moduleDatabase.getInitialModuleStartLevel();
/*      */     }
/*      */ 
/*      */     
/*      */     public void setInitialBundleStartLevel(int startlevel) {
/* 1661 */       ModuleContainer.this.checkAdminPermission(getBundle(), "startlevel");
/* 1662 */       if (startlevel < 1) {
/* 1663 */         throw new IllegalArgumentException(String.valueOf(Msg.ModuleContainer_NegativeStartLevelError) + startlevel);
/*      */       }
/* 1665 */       ModuleContainer.this.moduleDatabase.setInitialModuleStartLevel(startlevel);
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispatchEvent(Module module, FrameworkListener[] listeners, int eventAction, Integer startlevel) {
/* 1670 */       switch (eventAction) {
/*      */         case 1:
/* 1672 */           doContainerStartLevel(module, startlevel.intValue(), listeners);
/*      */           break;
/*      */         case 2:
/* 1675 */           if (this.debugStartLevel) {
/* 1676 */             Debug.println("StartLevel: changing bundle startlevel; " + toString(module) + "; newSL=" + startlevel + "; activeSL=" + getStartLevel());
/*      */           }
/*      */           try {
/* 1679 */             if (getStartLevel() < startlevel.intValue()) {
/* 1680 */               if (Module.ACTIVE_SET.contains(module.getState())) {
/* 1681 */                 if (this.debugStartLevel) {
/* 1682 */                   Debug.println("StartLevel: stopping bundle; " + toString(module) + "; with startLevel=" + startlevel);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1688 */                 module.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/*      */               }  break;
/*      */             } 
/* 1691 */             if (this.debugStartLevel) {
/* 1692 */               Debug.println("StartLevel: resuming bundle; " + toString(module) + "; with startLevel=" + startlevel);
/*      */             }
/* 1694 */             module.start(new Module.StartOptions[] { Module.StartOptions.TRANSIENT_IF_AUTO_START, Module.StartOptions.TRANSIENT_RESUME });
/*      */           }
/* 1696 */           catch (BundleException e) {
/* 1697 */             ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void doContainerStartLevel(Module module, int newStartLevel, FrameworkListener... listeners) {
/* 1706 */       synchronized (this.frameworkStartLevelLock) {
/* 1707 */         if (newStartLevel == Integer.MIN_VALUE) {
/* 1708 */           String beginningSL = ModuleContainer.this.adaptor.getProperty("org.osgi.framework.startlevel.beginning");
/* 1709 */           newStartLevel = (beginningSL == null) ? 1 : Integer.parseInt(beginningSL);
/*      */         } 
/*      */         try {
/* 1712 */           int currentSL = getStartLevel();
/* 1713 */           if (currentSL == 0) {
/*      */             
/* 1715 */             Module systemModule = ModuleContainer.this.moduleDatabase.getModule(0L);
/* 1716 */             if (systemModule != null && !Module.State.STARTING.equals(systemModule.getState())) {
/*      */               return;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1723 */           List<Module> sorted = null;
/* 1724 */           long currentTimestamp = Long.MIN_VALUE;
/* 1725 */           if (newStartLevel > currentSL) {
/* 1726 */             List<Module> lazyStart = null;
/* 1727 */             List<Module> lazyStartParallel = null;
/* 1728 */             List<Module> eagerStart = null;
/* 1729 */             List<Module> eagerStartParallel = null;
/* 1730 */             for (int i = currentSL; i < newStartLevel; i++) {
/* 1731 */               int toStartLevel = i + 1;
/* 1732 */               this.activeStartLevel.set(toStartLevel);
/* 1733 */               if (this.debugStartLevel) {
/* 1734 */                 Debug.println("StartLevel: incremented active start level to; " + toStartLevel);
/*      */               }
/* 1736 */               if (sorted == null || currentTimestamp != ModuleContainer.this.moduleDatabase.getTimestamp()) {
/* 1737 */                 ModuleContainer.this.moduleDatabase.readLock();
/*      */                 try {
/* 1739 */                   sorted = ModuleContainer.this.moduleDatabase.getSortedModules(new ModuleDatabase.Sort[] { ModuleDatabase.Sort.BY_START_LEVEL });
/* 1740 */                   lazyStart = new ArrayList<>(sorted.size());
/* 1741 */                   lazyStartParallel = new ArrayList<>(sorted.size());
/* 1742 */                   eagerStart = new ArrayList<>(sorted.size());
/* 1743 */                   eagerStartParallel = new ArrayList<>(sorted.size());
/* 1744 */                   separateModulesByActivationPolicy(sorted, lazyStart, lazyStartParallel, eagerStart, eagerStartParallel);
/* 1745 */                   currentTimestamp = ModuleContainer.this.moduleDatabase.getTimestamp();
/*      */                 } finally {
/* 1747 */                   ModuleContainer.this.moduleDatabase.readUnlock();
/*      */                 } 
/*      */               } 
/* 1750 */               incStartLevel(toStartLevel, lazyStart, lazyStartParallel, eagerStart, eagerStartParallel);
/*      */             } 
/*      */           } else {
/* 1753 */             for (int i = currentSL; i > newStartLevel; i--) {
/* 1754 */               int toStartLevel = i - 1;
/* 1755 */               this.activeStartLevel.set(toStartLevel);
/* 1756 */               if (this.debugStartLevel) {
/* 1757 */                 Debug.println("StartLevel: decremented active start level to " + toStartLevel);
/*      */               }
/* 1759 */               if (sorted == null || currentTimestamp != ModuleContainer.this.moduleDatabase.getTimestamp()) {
/* 1760 */                 ModuleContainer.this.moduleDatabase.readLock();
/*      */                 try {
/* 1762 */                   sorted = ModuleContainer.this.moduleDatabase.getSortedModules(new ModuleDatabase.Sort[] { ModuleDatabase.Sort.BY_START_LEVEL, ModuleDatabase.Sort.BY_DEPENDENCY });
/* 1763 */                   currentTimestamp = ModuleContainer.this.moduleDatabase.getTimestamp();
/*      */                 } finally {
/* 1765 */                   ModuleContainer.this.moduleDatabase.readUnlock();
/*      */                 } 
/*      */               } 
/* 1768 */               decStartLevel(toStartLevel, sorted);
/*      */             } 
/*      */           } 
/* 1771 */           if (currentSL > 0 && newStartLevel > 0)
/*      */           {
/*      */             
/* 1774 */             ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.START_LEVEL, module, null, listeners);
/*      */           }
/* 1776 */         } catch (Error|RuntimeException e) {
/* 1777 */           ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, e, listeners);
/* 1778 */           throw e;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void incStartLevel(int toStartLevel, List<Module> lazyStart, List<Module> lazyStartParallel, List<Module> eagerStart, List<Module> eagerStartParallel) {
/* 1786 */       incStartLevel(toStartLevel, lazyStartParallel, true);
/* 1787 */       incStartLevel(toStartLevel, lazyStart, false);
/* 1788 */       incStartLevel(toStartLevel, eagerStartParallel, true);
/* 1789 */       incStartLevel(toStartLevel, eagerStart, false);
/*      */     }
/*      */     
/*      */     private void separateModulesByActivationPolicy(List<Module> sortedModules, List<Module> lazyStart, List<Module> lazyStartParallel, List<Module> eagerStart, List<Module> eagerStartParallel) {
/* 1793 */       for (Module module : sortedModules) {
/* 1794 */         if (!ModuleContainer.this.restrictParallelStart || module.isParallelActivated()) {
/* 1795 */           if (module.isLazyActivate(new Module.StartOptions[0])) {
/* 1796 */             lazyStartParallel.add(module); continue;
/*      */           } 
/* 1798 */           eagerStartParallel.add(module);
/*      */           continue;
/*      */         } 
/* 1801 */         if (module.isLazyActivate(new Module.StartOptions[0])) {
/* 1802 */           lazyStart.add(module); continue;
/*      */         } 
/* 1804 */         eagerStart.add(module);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void incStartLevel(final int toStartLevel, List<Module> candidatesToStart, boolean inParallel) {
/* 1811 */       if (candidatesToStart.isEmpty()) {
/*      */         return;
/*      */       }
/* 1814 */       List<Module> toStart = new ArrayList<>();
/* 1815 */       for (Module module : candidatesToStart) {
/* 1816 */         if (ModuleContainer.this.isRefreshingSystemModule()) {
/*      */           return;
/*      */         }
/*      */         try {
/* 1820 */           int moduleStartLevel = module.getStartLevel();
/* 1821 */           if (moduleStartLevel < toStartLevel) {
/*      */             continue;
/*      */           }
/* 1824 */           if (moduleStartLevel == toStartLevel) {
/* 1825 */             toStart.add(module);
/*      */             continue;
/*      */           } 
/*      */           break;
/* 1829 */         } catch (IllegalStateException illegalStateException) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1834 */       if (toStart.isEmpty()) {
/*      */         return;
/*      */       }
/* 1837 */       Executor executor = inParallel ? ModuleContainer.this.adaptor.getStartLevelExecutor() : new Executor()
/*      */         {
/*      */           public void execute(Runnable command) {
/* 1840 */             command.run();
/*      */           }
/*      */         };
/* 1843 */       final CountDownLatch done = new CountDownLatch(toStart.size());
/* 1844 */       for (Module module : toStart) {
/* 1845 */         executor.execute(new Runnable()
/*      */             {
/*      */               public void run() {
/*      */                 try {
/* 1849 */                   if (ModuleContainer.ContainerStartLevel.this.debugStartLevel) {
/* 1850 */                     Debug.println("StartLevel: resuming bundle; " + ModuleContainer.ContainerStartLevel.this.toString(module) + "; with startLevel=" + toStartLevel);
/*      */                   }
/* 1852 */                   module.start(new Module.StartOptions[] { Module.StartOptions.TRANSIENT_IF_AUTO_START, Module.StartOptions.TRANSIENT_RESUME });
/* 1853 */                 } catch (BundleException e) {
/* 1854 */                   (ModuleContainer.ContainerStartLevel.access$1(ModuleContainer.ContainerStartLevel.this)).adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]);
/* 1855 */                 } catch (IllegalStateException illegalStateException) {
/*      */                 
/*      */                 } finally {
/* 1858 */                   done.countDown();
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       
/*      */       try {
/* 1865 */         done.await();
/* 1866 */       } catch (InterruptedException e) {
/* 1867 */         ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, ModuleContainer.this.moduleDatabase.getModule(0L), e, new FrameworkListener[0]);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void decStartLevel(int toStartLevel, List<Module> sortedModules) {
/* 1872 */       ListIterator<Module> iModules = sortedModules.listIterator(sortedModules.size());
/* 1873 */       while (iModules.hasPrevious()) {
/* 1874 */         Module module = iModules.previous();
/*      */         try {
/* 1876 */           int moduleStartLevel = module.getStartLevel();
/* 1877 */           if (moduleStartLevel > toStartLevel + 1) {
/*      */             continue;
/*      */           }
/* 1880 */           if (moduleStartLevel <= toStartLevel) {
/*      */             break;
/*      */           }
/*      */           
/*      */           try {
/* 1885 */             if (Module.ACTIVE_SET.contains(module.getState())) {
/* 1886 */               if (this.debugStartLevel) {
/* 1887 */                 Debug.println("StartLevel: stopping bundle; " + toString(module) + "; with startLevel=" + moduleStartLevel);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1893 */               module.stop(new Module.StopOptions[] { Module.StopOptions.TRANSIENT });
/*      */             } 
/* 1895 */           } catch (BundleException e) {
/* 1896 */             ModuleContainer.this.adaptor.publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, module, (Throwable)e, new FrameworkListener[0]);
/*      */           } 
/* 1898 */         } catch (IllegalStateException illegalStateException) {}
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventManager getManager() {
/* 1906 */       synchronized (this.eventManagerLock) {
/* 1907 */         if (this.startLevelThread == null) {
/* 1908 */           this.startLevelThread = new EventManager("Start Level: " + ModuleContainer.this.adaptor.toString());
/*      */         }
/* 1910 */         return this.startLevelThread;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void close() {
/* 1917 */       synchronized (this.eventManagerLock) {
/*      */         
/* 1919 */         EventManager manager = getManager();
/*      */         
/* 1921 */         manager.close();
/*      */       } 
/*      */     }
/*      */     
/*      */     void open() {
/* 1926 */       synchronized (this.eventManagerLock) {
/* 1927 */         if (this.startLevelThread != null) {
/*      */           
/* 1929 */           this.startLevelThread.close();
/*      */           
/* 1931 */           this.startLevelThread = null;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     String toString(Module m) {
/* 1937 */       Bundle b = m.getBundle();
/* 1938 */       return (b != null) ? b.toString() : m.toString();
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */