/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PermissionsHash
/*     */   extends PermissionCollection
/*     */ {
/*     */   private static final long serialVersionUID = 3258408426341284153L;
/*  41 */   Hashtable<Permission, Permission> perms = new Hashtable<>(8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Permission perm) {
/*  61 */     if (isReadOnly()) {
/*  62 */       throw new SecurityException();
/*     */     }
/*     */     
/*  65 */     this.perms.put(perm, perm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<Permission> elements() {
/*  77 */     return this.perms.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission perm) {
/*  93 */     Permission p = this.perms.get(perm);
/*     */     
/*  95 */     if (p != null && p.implies(perm)) {
/*  96 */       return true;
/*     */     }
/*     */     
/*  99 */     Enumeration<Permission> permsEnum = elements();
/*     */     
/* 101 */     while (permsEnum.hasMoreElements()) {
/* 102 */       if (((Permission)permsEnum.nextElement()).implies(perm)) {
/* 103 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\PermissionsHash.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */