/*    */ package org.eclipse.osgi.internal.permadmin;
/*    */ 
/*    */ import org.osgi.service.condpermadmin.ConditionInfo;
/*    */ import org.osgi.service.condpermadmin.ConditionalPermissionInfo;
/*    */ import org.osgi.service.permissionadmin.PermissionInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityRowSnapShot
/*    */   implements ConditionalPermissionInfo
/*    */ {
/*    */   private final String name;
/*    */   private final ConditionInfo[] conditionInfos;
/*    */   private final PermissionInfo[] permissionInfos;
/*    */   private final String decision;
/*    */   
/*    */   public SecurityRowSnapShot(String name, ConditionInfo[] conditionInfos, PermissionInfo[] permissionInfos, String decision) {
/* 28 */     if (permissionInfos == null || permissionInfos.length == 0)
/* 29 */       throw new IllegalArgumentException("It is invalid to have empty permissionInfos"); 
/* 30 */     decision = decision.toLowerCase();
/* 31 */     boolean d = "deny".equals(decision);
/* 32 */     boolean a = "allow".equals(decision);
/* 33 */     if (!(d | a))
/* 34 */       throw new IllegalArgumentException("Invalid decision: " + decision); 
/* 35 */     conditionInfos = (conditionInfos == null) ? new ConditionInfo[0] : conditionInfos;
/* 36 */     this.name = name;
/*    */     
/* 38 */     this.conditionInfos = (ConditionInfo[])SecurityRow.cloneArray((Object[])conditionInfos);
/* 39 */     this.permissionInfos = (PermissionInfo[])SecurityRow.cloneArray((Object[])permissionInfos);
/* 40 */     this.decision = decision;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConditionInfo[] getConditionInfos() {
/* 45 */     return (ConditionInfo[])SecurityRow.cloneArray((Object[])this.conditionInfos);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessDecision() {
/* 50 */     return this.decision;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 55 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public PermissionInfo[] getPermissionInfos() {
/* 60 */     return (PermissionInfo[])SecurityRow.cloneArray((Object[])this.permissionInfos);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void delete() {
/* 68 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return getEncoded();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getEncoded() {
/* 78 */     return SecurityRow.getEncoded(this.name, this.conditionInfos, this.permissionInfos, "deny".equalsIgnoreCase(this.decision));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 84 */     if (obj == this)
/* 85 */       return true; 
/* 86 */     if (!(obj instanceof ConditionalPermissionInfo)) {
/* 87 */       return false;
/*    */     }
/* 89 */     return getEncoded().equals(((ConditionalPermissionInfo)obj).getEncoded());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 94 */     return SecurityRow.getHashCode(this.name, this.conditionInfos, this.permissionInfos, getAccessDecision());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\SecurityRowSnapShot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */