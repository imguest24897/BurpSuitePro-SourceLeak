/*    */ package org.eclipse.osgi.internal.serviceregistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ServiceConsumer
/*    */ {
/* 30 */   public static final ServiceConsumer prototypeConsumer = new ServiceConsumer()
/*    */     {
/*    */       public <S> S getService(ServiceUse<S> use) {
/* 33 */         return use.newServiceObject();
/*    */       }
/*    */ 
/*    */       
/*    */       public <S> boolean ungetService(ServiceUse<S> use, S service) {
/* 38 */         return use.releaseServiceObject(service);
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static final ServiceConsumer singletonConsumer = new ServiceConsumer()
/*    */     {
/*    */       public <S> S getService(ServiceUse<S> use) {
/* 48 */         return use.getService();
/*    */       }
/*    */ 
/*    */       
/*    */       public <S> boolean ungetService(ServiceUse<S> use, S service) {
/* 53 */         return use.ungetService();
/*    */       }
/*    */     };
/*    */   
/*    */   <S> S getService(ServiceUse<S> paramServiceUse);
/*    */   
/*    */   <S> boolean ungetService(ServiceUse<S> paramServiceUse, S paramS);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */