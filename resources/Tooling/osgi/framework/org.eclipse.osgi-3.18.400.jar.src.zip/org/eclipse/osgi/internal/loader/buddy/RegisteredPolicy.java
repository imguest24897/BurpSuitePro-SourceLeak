/*     */ package org.eclipse.osgi.internal.loader.buddy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegisteredPolicy
/*     */   extends DependentPolicy
/*     */ {
/*     */   public RegisteredPolicy(BundleLoader requester) {
/*  35 */     super(requester);
/*     */ 
/*     */     
/*  38 */     if (this.allDependents == null) {
/*     */       return;
/*     */     }
/*  41 */     String requesterName = requester.getWiring().getRevision().getSymbolicName();
/*  42 */     for (Iterator<ModuleWiring> iter = this.allDependents.iterator(); iter.hasNext(); ) {
/*  43 */       ModuleWiring wiring = iter.next();
/*  44 */       List<ModuleCapability> moduleDatas = wiring.getRevision().getModuleCapabilities("equinox.module.data");
/*     */       
/*  46 */       List<String> registeredList = moduleDatas.isEmpty() ? null : (List<String>)((ModuleCapability)moduleDatas.get(0)).getAttributes().get("buddy.registered");
/*  47 */       if (registeredList == null || registeredList.isEmpty()) {
/*  48 */         iter.remove(); continue;
/*     */       } 
/*  50 */       boolean contributes = false;
/*  51 */       for (String registeredName : registeredList) {
/*  52 */         if (registeredName.equals(requesterName)) {
/*  53 */           contributes = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*  57 */       if (!contributes) {
/*  58 */         iter.remove();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  64 */     if (this.allDependents.size() == 0) {
/*  65 */       this.allDependents = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public Class<?> loadClass(String name) {
/*  70 */     if (this.allDependents == null) {
/*  71 */       return null;
/*     */     }
/*  73 */     int size = this.allDependents.size();
/*  74 */     for (int i = 0; i < size; i++) {
/*  75 */       ModuleWiring searchWiring = this.allDependents.get(i);
/*  76 */       BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/*  77 */       if (searchLoader != null) {
/*  78 */         Class<?> result = searchLoader.findClassNoParentNoException(name);
/*  79 */         if (result != null) {
/*  80 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public URL loadResource(String name) {
/*  89 */     if (this.allDependents == null) {
/*  90 */       return null;
/*     */     }
/*  92 */     URL result = null;
/*  93 */     int size = this.allDependents.size();
/*  94 */     for (int i = 0; i < size && result == null; i++) {
/*  95 */       ModuleWiring searchWiring = this.allDependents.get(i);
/*  96 */       BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/*  97 */       if (searchLoader != null) {
/*  98 */         result = searchLoader.findResource(name);
/*     */       }
/*     */     } 
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<URL> loadResources(String name) {
/* 106 */     if (this.allDependents == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     Enumeration<URL> results = null;
/* 110 */     int size = this.allDependents.size();
/* 111 */     for (int i = 0; i < size; i++) {
/*     */       try {
/* 113 */         ModuleWiring searchWiring = this.allDependents.get(i);
/* 114 */         BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/* 115 */         if (searchLoader != null) {
/* 116 */           results = BundleLoader.compoundEnumerations(results, searchLoader.findResources(name));
/*     */         }
/* 118 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 122 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListResources(Set<String> results, String path, String filePattern, int options) {
/* 127 */     if (this.allDependents == null) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     int size = this.allDependents.size();
/* 132 */     for (int i = 0; i < size; i++) {
/* 133 */       ModuleWiring searchWiring = this.allDependents.get(i);
/* 134 */       results.addAll(searchWiring.listResources(path, filePattern, options));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\RegisteredPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */