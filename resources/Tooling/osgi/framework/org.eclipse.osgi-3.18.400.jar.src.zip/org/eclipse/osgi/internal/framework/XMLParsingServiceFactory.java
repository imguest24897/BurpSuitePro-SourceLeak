/*    */ package org.eclipse.osgi.internal.framework;
/*    */ 
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ import org.osgi.framework.wiring.BundleWiring;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class XMLParsingServiceFactory
/*    */   implements ServiceFactory<Object>
/*    */ {
/*    */   private final boolean isSax;
/*    */   private final boolean setTccl;
/*    */   
/*    */   public XMLParsingServiceFactory(boolean isSax, boolean setTccl) {
/* 26 */     this.isSax = isSax;
/* 27 */     this.setTccl = setTccl;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getService(Bundle bundle, ServiceRegistration<Object> registration) {
/* 32 */     if (!this.setTccl || bundle == null) {
/* 33 */       return createService();
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 45 */     ClassLoader savedClassLoader = Thread.currentThread().getContextClassLoader();
/*    */     try {
/* 47 */       BundleWiring wiring = (BundleWiring)bundle.adapt(BundleWiring.class);
/* 48 */       ClassLoader cl = (wiring == null) ? null : wiring.getClassLoader();
/* 49 */       if (cl != null)
/* 50 */         Thread.currentThread().setContextClassLoader(cl); 
/* 51 */       return createService();
/*    */     } finally {
/* 53 */       Thread.currentThread().setContextClassLoader(savedClassLoader);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Object createService() {
/* 58 */     if (this.isSax)
/* 59 */       return SAXParserFactory.newInstance(); 
/* 60 */     return DocumentBuilderFactory.newInstance();
/*    */   }
/*    */   
/*    */   public void ungetService(Bundle bundle, ServiceRegistration<Object> registration, Object service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\XMLParsingServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */