/*    */ package org.eclipse.osgi.internal.loader;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.eclipse.osgi.container.ModuleLoader;
/*    */ import org.eclipse.osgi.container.ModuleRevision;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentLoader
/*    */   extends ModuleLoader
/*    */ {
/*    */   protected List<URL> findEntries(String path, String filePattern, int options) {
/* 25 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<String> listResources(String path, String filePattern, int options) {
/* 30 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   protected ClassLoader getClassLoader() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getAndSetTrigger() {
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTriggerSet() {
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   protected void loadFragments(Collection<ModuleRevision> fragments) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\FragmentLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */