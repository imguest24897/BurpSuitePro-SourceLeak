package org.eclipse.osgi.service.resolver;

import java.util.Map;

public interface ImportPackageSpecification extends VersionConstraint {
  public static final String RESOLUTION_STATIC = "static";
  
  public static final String RESOLUTION_OPTIONAL = "optional";
  
  public static final String RESOLUTION_DYNAMIC = "dynamic";
  
  String getBundleSymbolicName();
  
  VersionRange getBundleVersionRange();
  
  Map<String, Object> getAttributes();
  
  Map<String, Object> getDirectives();
  
  Object getDirective(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\ImportPackageSpecification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */