package org.eclipse.osgi.service.urlconversion;

import java.io.IOException;
import java.net.URL;

public interface URLConverter {
  URL toFileURL(URL paramURL) throws IOException;
  
  URL resolve(URL paramURL) throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\servic\\urlconversion\URLConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */