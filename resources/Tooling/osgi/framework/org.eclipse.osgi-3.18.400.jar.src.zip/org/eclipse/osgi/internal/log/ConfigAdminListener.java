/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigAdminListener
/*     */   implements ServiceTrackerCustomizer<Object, ServiceRegistration<?>>
/*     */ {
/*     */   private static final String CLASS_CONFIG_ADMIN = "org.osgi.service.cm.ConfigurationAdmin";
/*     */   private static final String METHOD_CONFIG_ADMIN_GET_CONFIGURATION = "getConfiguration";
/*     */   private static final String METHOD_CONFIG_ADMIN_LIST_CONFIGURATIONS = "listConfigurations";
/*     */   private static final String CLASS_SYNC_CONFIG_LISTENER = "org.osgi.service.cm.SynchronousConfigurationListener";
/*     */   private static final String CLASS_CONFIG_EVENT = "org.osgi.service.cm.ConfigurationEvent";
/*     */   private static final String METHOD_CONFIG_EVENT_GET_PID = "getPid";
/*     */   private static final String METHOD_CONFIG_EVENT_GET_FACTORY_PID = "getFactoryPid";
/*     */   private static final String METHOD_CONFIG_EVENT_GET_REFERENCE = "getReference";
/*     */   private static final String METHOD_CONFIG_EVENT_GET_TYPE = "getType";
/*     */   private static final int CM_UPDATED = 1;
/*     */   private static final int CM_DELETED = 2;
/*     */   private static final int CM_LOCATION_CHANGED = 3;
/*     */   private static final String CLASS_CONFIG = "org.osgi.service.cm.Configuration";
/*     */   private static final String METHOD_CONFIG_GET_PROPERTIES = "getProperties";
/*     */   private static final String METHOD_CONFIG_GET_PID = "getPid";
/*     */   private static final String METHOD_CONFIG_GET_FACTORY_PID = "getFactoryPid";
/*     */   private static final String PID_PREFIX_LOG_ADMIN = "org.osgi.service.log.admin";
/*     */   private static final String PID_FILTER = "(service.pid=org.osgi.service.log.admin*)";
/*     */   private final ServiceTracker<Object, ServiceRegistration<?>> configTracker;
/*     */   final ExtendedLogServiceFactory factory;
/*     */   final BundleContext context;
/*     */   
/*     */   ConfigAdminListener(BundleContext context, ExtendedLogServiceFactory factory) {
/*  64 */     this.context = context;
/*  65 */     this.configTracker = new ServiceTracker(context, "org.osgi.service.cm.ConfigurationAdmin", this);
/*  66 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   void start() {
/*  70 */     this.configTracker.open();
/*     */   }
/*     */   
/*     */   void stop() {
/*  74 */     this.configTracker.close();
/*     */   }
/*     */   
/*     */   private ServiceRegistration<?> registerConfigurationListener(ServiceReference<?> configRef) {
/*     */     try {
/*  79 */       Class<?> listenerClass = configRef.getBundle().loadClass("org.osgi.service.cm.SynchronousConfigurationListener");
/*  80 */       return registerProxyConfigListener(configRef, listenerClass);
/*  81 */     } catch (ClassNotFoundException|NoSuchMethodException e) {
/*  82 */       throw new RuntimeException("org.osgi.service.cm.SynchronousConfigurationListener", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ServiceRegistration<?> registerProxyConfigListener(ServiceReference<?> configRef, Class<?> listenerClass) throws ClassNotFoundException, NoSuchMethodException {
/*  87 */     LoggerContextConfiguration loggerConfiguration = new LoggerContextConfiguration(listenerClass, configRef);
/*  88 */     return loggerConfiguration.register();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServiceRegistration<?> addingService(ServiceReference<Object> configRef) {
/*  93 */     return registerConfigurationListener(configRef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<Object> configRef, ServiceRegistration<?> configReg) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<Object> configRef, ServiceRegistration<?> loggerConfiguration) {
/* 103 */     loggerConfiguration.unregister();
/*     */   }
/*     */ 
/*     */   
/*     */   class LoggerContextConfiguration
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Object listenerProxy;
/*     */     private final Object configAdmin;
/*     */     private final ServiceReference<?> configAdminRef;
/*     */     private final Class<?> configClass;
/*     */     private final Method getConfigProperties;
/*     */     private final Method getConfigPid;
/*     */     private final Method getConfigFactoryPid;
/*     */     private final Class<?> configAdminClass;
/*     */     private final Method getConfiguration;
/*     */     private final Method listConfigurations;
/*     */     private final Class<?> configEventClass;
/*     */     private final Method getEventPid;
/*     */     private final Method getEventFactoryPid;
/*     */     private final Method getEventReference;
/*     */     private final Method getEventType;
/*     */     
/*     */     public LoggerContextConfiguration(Class<?> listenerClass, ServiceReference<?> ref) throws ClassNotFoundException, NoSuchMethodException {
/* 127 */       this.listenerProxy = Proxy.newProxyInstance(listenerClass.getClassLoader(), new Class[] { listenerClass }, this);
/* 128 */       this.configAdminRef = ref;
/* 129 */       ClassLoader cl = listenerClass.getClassLoader();
/*     */       
/* 131 */       this.configClass = cl.loadClass("org.osgi.service.cm.Configuration");
/* 132 */       this.getConfigProperties = this.configClass.getMethod("getProperties", new Class[0]);
/* 133 */       this.getConfigFactoryPid = this.configClass.getMethod("getFactoryPid", new Class[0]);
/* 134 */       this.getConfigPid = this.configClass.getMethod("getPid", new Class[0]);
/*     */       
/* 136 */       this.configAdminClass = cl.loadClass("org.osgi.service.cm.ConfigurationAdmin");
/* 137 */       this.getConfiguration = this.configAdminClass.getMethod("getConfiguration", new Class[] { String.class, String.class });
/* 138 */       this.listConfigurations = this.configAdminClass.getMethod("listConfigurations", new Class[] { String.class });
/*     */       
/* 140 */       this.configEventClass = cl.loadClass("org.osgi.service.cm.ConfigurationEvent");
/* 141 */       this.getEventPid = this.configEventClass.getMethod("getPid", new Class[0]);
/* 142 */       this.getEventFactoryPid = this.configEventClass.getMethod("getFactoryPid", new Class[0]);
/* 143 */       this.getEventReference = this.configEventClass.getMethod("getReference", new Class[0]);
/* 144 */       this.getEventType = this.configEventClass.getMethod("getType", new Class[0]);
/*     */       
/* 146 */       this.configAdmin = ConfigAdminListener.this.context.getService(ref);
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceRegistration<?> register() {
/* 151 */       Bundle configBundle = this.configAdminRef.getBundle();
/* 152 */       BundleContext configContext = (configBundle != null) ? this.configAdminRef.getBundle().getBundleContext() : null;
/* 153 */       if (configContext == null)
/*     */       {
/* 155 */         return null;
/*     */       }
/* 157 */       ServiceRegistration<?> registration = configContext.registerService("org.osgi.service.cm.SynchronousConfigurationListener", this.listenerProxy, null);
/*     */       
/*     */       try {
/* 160 */         Object[] configs = (Object[])this.listConfigurations.invoke(this.configAdmin, new Object[] { "(service.pid=org.osgi.service.log.admin*)" });
/* 161 */         if (configs != null) {
/* 162 */           byte b; int i; Object[] arrayOfObject; for (i = (arrayOfObject = configs).length, b = 0; b < i; ) { Object config = arrayOfObject[b];
/* 163 */             String factoryPid = (String)this.getConfigFactoryPid.invoke(config, new Object[0]);
/* 164 */             if (factoryPid == null) {
/*     */ 
/*     */               
/* 167 */               String pid = (String)this.getConfigPid.invoke(config, new Object[0]);
/* 168 */               String contextName = getContextName(pid);
/*     */               
/* 170 */               Dictionary<String, Object> configDictionary = (Dictionary<String, Object>)this.getConfigProperties.invoke(config, new Object[0]);
/* 171 */               if (configDictionary != null)
/* 172 */                 setLogLevels(contextName, getLogLevels(configDictionary)); 
/*     */             }  b++; }
/*     */         
/*     */         } 
/* 176 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 177 */         throw new RuntimeException(e);
/*     */       } 
/* 179 */       return registration;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] event) throws Throwable {
/* 186 */       if (!this.configAdminRef.equals(getReference(event)))
/*     */       {
/* 188 */         return null;
/*     */       }
/*     */       
/* 191 */       String pid = getEventPid(event);
/* 192 */       if (pid == null)
/*     */       {
/* 194 */         return null;
/*     */       }
/*     */       
/* 197 */       int type = getType(event);
/* 198 */       if (type == 3)
/*     */       {
/* 200 */         return null;
/*     */       }
/*     */       
/* 203 */       String contextName = getContextName(pid);
/* 204 */       if (type == 2) {
/* 205 */         setLogLevels(contextName, Collections.emptyMap());
/* 206 */         return null;
/*     */       } 
/*     */       
/* 209 */       if (type == 1) {
/* 210 */         Dictionary<String, Object> configDictionary = findConfiguration(pid);
/* 211 */         if (configDictionary == null) {
/*     */           
/* 213 */           setLogLevels(contextName, Collections.emptyMap());
/* 214 */           return null;
/*     */         } 
/*     */         
/* 217 */         Map<String, LogLevel> levelConfig = getLogLevels(configDictionary);
/* 218 */         setLogLevels(contextName, levelConfig);
/*     */       } 
/* 220 */       return null;
/*     */     }
/*     */     
/*     */     private String getContextName(String pid) {
/* 224 */       if ("org.osgi.service.log.admin".equals(pid)) {
/* 225 */         return null;
/*     */       }
/* 227 */       char separator = pid.charAt("org.osgi.service.log.admin".length());
/* 228 */       if (separator != '|') {
/* 229 */         return null;
/*     */       }
/* 231 */       int startName = "org.osgi.service.log.admin".length() + 1;
/* 232 */       return pid.substring(startName);
/*     */     }
/*     */     
/*     */     private Map<String, LogLevel> getLogLevels(Dictionary<String, Object> configDictionary) {
/* 236 */       Map<String, LogLevel> result = new HashMap<>(configDictionary.size());
/* 237 */       for (Enumeration<String> keys = configDictionary.keys(); keys.hasMoreElements(); ) {
/* 238 */         String key = keys.nextElement();
/* 239 */         Object v = configDictionary.get(key);
/* 240 */         if (v instanceof String) {
/*     */           try {
/* 242 */             result.put(key, LogLevel.valueOf((String)v));
/* 243 */           } catch (IllegalArgumentException illegalArgumentException) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 248 */       return result;
/*     */     }
/*     */     
/*     */     private Object getReference(Object[] event) {
/*     */       try {
/* 253 */         return this.getEventReference.invoke(event[0], new Object[0]);
/* 254 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 255 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     private String getEventPid(Object[] event) {
/*     */       try {
/* 261 */         String factoryPid = (String)this.getEventFactoryPid.invoke(event[0], new Object[0]);
/* 262 */         if (factoryPid != null)
/*     */         {
/* 264 */           return null;
/*     */         }
/* 266 */         String pid = (String)this.getEventPid.invoke(event[0], new Object[0]);
/* 267 */         if (pid.startsWith("org.osgi.service.log.admin")) {
/* 268 */           return pid;
/*     */         }
/* 270 */         return null;
/* 271 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 272 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     private int getType(Object[] event) {
/*     */       try {
/* 278 */         Integer type = (Integer)this.getEventType.invoke(event[0], new Object[0]);
/* 279 */         return (type == null) ? 0 : type.intValue();
/* 280 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 281 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Dictionary<String, Object> findConfiguration(String pid) {
/*     */       try {
/* 288 */         Object config = this.getConfiguration.invoke(this.configAdmin, new Object[] { pid, null });
/* 289 */         return (Dictionary<String, Object>)this.getConfigProperties.invoke(config, new Object[0]);
/* 290 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 291 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setLogLevels(String contextName, Map<String, LogLevel> logLevels) {
/* 296 */       ConfigAdminListener.this.factory.getLoggerAdmin().getLoggerContext(contextName).setLogLevels(logLevels);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ConfigAdminListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */