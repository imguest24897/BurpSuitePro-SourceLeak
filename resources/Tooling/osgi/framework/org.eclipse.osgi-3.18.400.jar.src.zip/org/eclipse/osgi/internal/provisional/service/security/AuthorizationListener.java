package org.eclipse.osgi.internal.provisional.service.security;

import java.util.EventListener;

public interface AuthorizationListener extends EventListener {
  void authorizationEvent(AuthorizationEvent paramAuthorizationEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\service\security\AuthorizationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */