/*     */ package org.eclipse.osgi.storage.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.Permission;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BundleResourceHandler
/*     */   extends URLStreamHandler
/*     */ {
/*     */   public static final String OSGI_RESOURCE_URL_PROTOCOL = "bundleresource";
/*     */   public static final String OSGI_ENTRY_URL_PROTOCOL = "bundleentry";
/*     */   public static final String SECURITY_CHECKED = "SECURITY_CHECKED";
/*     */   public static final String SECURITY_UNCHECKED = "SECURITY_UNCHECKED";
/*     */   public static final String BID_FWKID_SEPARATOR = ".fwk";
/*     */   protected final ModuleContainer container;
/*     */   protected BundleEntry bundleEntry;
/*     */   
/*     */   protected BundleResourceHandler(ModuleContainer container, BundleEntry bundleEntry) {
/*  51 */     this.container = container;
/*  52 */     this.bundleEntry = bundleEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseURL(URL url, String str, int start, int end) {
/*  60 */     if (end < start)
/*     */       return; 
/*  62 */     if (url.getPath() != null)
/*     */     {
/*     */       
/*  65 */       this.bundleEntry = null; } 
/*  66 */     String spec = "";
/*  67 */     if (start < end)
/*  68 */       spec = str.substring(start, end); 
/*  69 */     end -= start;
/*     */     
/*  71 */     String path = url.getPath();
/*  72 */     String host = url.getHost();
/*  73 */     int resIndex = url.getPort();
/*  74 */     if (resIndex < 0)
/*  75 */       resIndex = 0; 
/*  76 */     int pathIdx = 0;
/*  77 */     if (spec.startsWith("//")) {
/*  78 */       int bundleIdIdx = 2;
/*  79 */       pathIdx = spec.indexOf('/', bundleIdIdx);
/*  80 */       if (pathIdx == -1) {
/*  81 */         pathIdx = end;
/*     */         
/*  83 */         path = "";
/*     */       } 
/*  85 */       int bundleIdEnd = spec.indexOf(':', bundleIdIdx);
/*  86 */       if (bundleIdEnd > pathIdx || bundleIdEnd == -1)
/*  87 */         bundleIdEnd = pathIdx; 
/*  88 */       if (bundleIdEnd < pathIdx - 1) {
/*     */         try {
/*  90 */           resIndex = Integer.parseInt(spec.substring(bundleIdEnd + 1, pathIdx));
/*  91 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */       
/*  94 */       host = spec.substring(bundleIdIdx, bundleIdEnd);
/*     */     } 
/*  96 */     if (pathIdx < end && spec.charAt(pathIdx) == '/') {
/*  97 */       path = spec.substring(pathIdx, end);
/*  98 */     } else if (end > pathIdx) {
/*  99 */       if (path == null || path.equals(""))
/* 100 */         path = "/"; 
/* 101 */       int last = path.lastIndexOf('/') + 1;
/* 102 */       if (last == 0) {
/* 103 */         path = spec.substring(pathIdx, end);
/*     */       } else {
/* 105 */         path = String.valueOf(path.substring(0, last)) + spec.substring(pathIdx, end);
/*     */       } 
/* 107 */     }  if (path == null) {
/* 108 */       path = "";
/*     */     }
/*     */ 
/*     */     
/* 112 */     if (path.endsWith("/.") || path.endsWith("/.."))
/* 113 */       path = String.valueOf(path) + '/'; 
/*     */     int dotIndex;
/* 115 */     while ((dotIndex = path.indexOf("/./")) >= 0)
/* 116 */       path = String.valueOf(path.substring(0, dotIndex + 1)) + path.substring(dotIndex + 3); 
/* 117 */     while ((dotIndex = path.indexOf("/../")) >= 0) {
/* 118 */       if (dotIndex != 0) {
/* 119 */         path = String.valueOf(path.substring(0, path.lastIndexOf('/', dotIndex - 1))) + path.substring(dotIndex + 3); continue;
/*     */       } 
/* 121 */       path = path.substring(dotIndex + 3);
/*     */     } 
/* 123 */     while ((dotIndex = path.indexOf("//")) >= 0) {
/* 124 */       path = String.valueOf(path.substring(0, dotIndex + 1)) + path.substring(dotIndex + 2);
/*     */     }
/*     */ 
/*     */     
/* 128 */     String authorized = "SECURITY_UNCHECKED";
/* 129 */     long bundleId = parseBundleIDFromURLHost(host);
/* 130 */     Module module = getModule(bundleId);
/* 131 */     if (checkAuthorization(module)) {
/* 132 */       authorized = "SECURITY_CHECKED";
/*     */     }
/* 134 */     host = createURLHostForBundleID(this.container, bundleId);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     setURL(url, url.getProtocol(), host, resIndex, authorized, null, path, null, url.getRef());
/*     */   }
/*     */   
/*     */   private Module getModule(long id) {
/* 143 */     return this.container.getModule(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URLConnection openConnection(URL url) throws IOException {
/*     */     long bundleID;
/* 158 */     if (this.bundleEntry != null) {
/* 159 */       return new BundleURLConnection(url, this.container, this.bundleEntry);
/*     */     }
/* 161 */     String host = url.getHost();
/* 162 */     if (host == null) {
/* 163 */       throw new IOException(NLS.bind(Msg.URL_NO_BUNDLE_ID, url.toExternalForm()));
/*     */     }
/*     */     
/*     */     try {
/* 167 */       bundleID = parseBundleIDFromURLHost(host);
/* 168 */     } catch (NumberFormatException nfe) {
/* 169 */       throw (MalformedURLException)(new MalformedURLException(NLS.bind(Msg.URL_INVALID_BUNDLE_ID, host))).initCause(nfe);
/*     */     } 
/* 171 */     Module module = getModule(bundleID);
/* 172 */     if (module == null) {
/* 173 */       throw new IOException(NLS.bind(Msg.URL_NO_BUNDLE_FOUND, url.toExternalForm()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (!url.getAuthority().equals("SECURITY_CHECKED"))
/*     */     {
/* 180 */       checkAuthorization(module);
/*     */     }
/* 182 */     return new BundleURLConnection(url, this.container, findBundleEntry(url, module));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract BundleEntry findBundleEntry(URL paramURL, Module paramModule) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toExternalForm(URL url) {
/* 204 */     StringBuilder result = new StringBuilder(url.getProtocol());
/* 205 */     result.append("://");
/*     */     
/* 207 */     String host = url.getHost();
/* 208 */     if (host != null && host.length() > 0) {
/* 209 */       result.append(host);
/*     */     }
/* 211 */     int index = url.getPort();
/* 212 */     if (index > 0) {
/* 213 */       result.append(':').append(index);
/*     */     }
/* 215 */     String path = url.getPath();
/* 216 */     if (path != null) {
/* 217 */       if (path.length() > 0 && path.charAt(0) != '/') {
/* 218 */         result.append("/");
/*     */       }
/* 220 */       result.append(path);
/*     */     } 
/* 222 */     String ref = url.getRef();
/* 223 */     if (ref != null && ref.length() > 0) {
/* 224 */       result.append('#').append(ref);
/*     */     }
/* 226 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int hashCode(URL url) {
/* 231 */     int hash = 0;
/* 232 */     String protocol = url.getProtocol();
/* 233 */     if (protocol != null) {
/* 234 */       hash += protocol.hashCode();
/*     */     }
/* 236 */     String host = url.getHost();
/* 237 */     if (host != null) {
/* 238 */       hash += host.hashCode();
/*     */     }
/* 240 */     hash += url.getPort();
/*     */     
/* 242 */     String path = url.getPath();
/* 243 */     if (path != null) {
/* 244 */       hash += path.hashCode();
/*     */     }
/* 246 */     hash += this.container.hashCode();
/* 247 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equals(URL url1, URL url2) {
/* 252 */     return sameFile(url1, url2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized InetAddress getHostAddress(URL url) {
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hostsEqual(URL url1, URL url2) {
/* 262 */     return equalsIgnoreCase(url1.getHost(), url2.getHost());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sameFile(URL url1, URL url2) {
/* 268 */     if (url1.hashCode() != url2.hashCode())
/* 269 */       return false; 
/* 270 */     return (equalsIgnoreCase(url1.getProtocol(), url2.getProtocol()) && 
/* 271 */       hostsEqual(url1, url2) && 
/* 272 */       url1.getPort() == url2.getPort() && 
/* 273 */       Objects.equals(url1.getPath(), url2.getPath()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkAuthorization(Module module) {
/* 279 */     SecurityManager sm = System.getSecurityManager();
/* 280 */     if (sm == null)
/* 281 */       return true; 
/* 282 */     Bundle moduleBundle = (module == null) ? null : module.getBundle();
/* 283 */     if (moduleBundle == null)
/* 284 */       return false; 
/* 285 */     sm.checkPermission((Permission)new AdminPermission(moduleBundle, "resource"));
/* 286 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean equalsIgnoreCase(String s1, String s2) {
/* 290 */     return (s1 != null) ? s1.equalsIgnoreCase(s2) : ((s2 == null));
/*     */   }
/*     */   
/*     */   public static String createURLHostForBundleID(ModuleContainer container, long bundleId) {
/* 294 */     return String.valueOf(bundleId) + ".fwk" + container.hashCode();
/*     */   }
/*     */   
/*     */   static long parseBundleIDFromURLHost(String host) {
/* 298 */     int dotIndex = host.indexOf(".fwk");
/* 299 */     return (dotIndex >= 0 && dotIndex < host.length() - 1) ? Long.parseLong(host.substring(0, dotIndex)) : Long.parseLong(host);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\BundleResourceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */