/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceException;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceFactoryUse<S>
/*     */   extends ServiceUse<S>
/*     */ {
/*     */   final ServiceFactory<S> factory;
/*     */   private S cachedService;
/*     */   private boolean factoryInUse;
/*     */   
/*     */   ServiceFactoryUse(BundleContextImpl context, ServiceRegistrationImpl<S> registration) {
/*  56 */     super(context, registration);
/*  57 */     this.factoryInUse = false;
/*  58 */     this.cachedService = null;
/*     */     
/*  60 */     ServiceFactory<S> f = (ServiceFactory<S>)registration.getServiceObject();
/*  61 */     this.factory = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getService() {
/*     */     S service;
/*  91 */     assert getLock().isHeldByCurrentThread();
/*  92 */     if (inUse()) {
/*  93 */       incrementUse();
/*  94 */       return this.cachedService;
/*     */     } 
/*     */     
/*  97 */     if (this.debug.DEBUG_SERVICES) {
/*  98 */       Debug.println("[" + Thread.currentThread().getName() + "] getService[Sfactory=" + this.registration.getBundle() + 
/*  99 */           "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/*     */     
/* 102 */     if (this.factoryInUse) {
/* 103 */       if (this.debug.DEBUG_SERVICES) {
/* 104 */         Debug.println(this.factory + ".getService() recursively called.");
/*     */       }
/*     */       
/* 107 */       ServiceException se = new ServiceException(NLS.bind(Msg.SERVICE_FACTORY_RECURSION, this.factory.getClass().getName(), "getService"), 6);
/* 108 */       this.context.getContainer().getEventPublisher().publishFrameworkEvent(16, this.registration.getBundle(), (Throwable)se);
/* 109 */       return null;
/*     */     } 
/* 111 */     this.factoryInUse = true;
/*     */     
/*     */     try {
/* 114 */       service = factoryGetService();
/* 115 */       if (service == null) {
/* 116 */         return null;
/*     */       }
/*     */     } finally {
/* 119 */       this.factoryInUse = false;
/*     */     } 
/*     */     
/* 122 */     this.cachedService = service;
/* 123 */     incrementUse();
/*     */     
/* 125 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean ungetService() {
/* 147 */     assert getLock().isHeldByCurrentThread();
/* 148 */     if (!inUse()) {
/* 149 */       return false;
/*     */     }
/*     */     
/* 152 */     decrementUse();
/* 153 */     if (inUse()) {
/* 154 */       return true;
/*     */     }
/*     */     
/* 157 */     S service = this.cachedService;
/* 158 */     this.cachedService = null;
/*     */     
/* 160 */     if (this.debug.DEBUG_SERVICES) {
/* 161 */       Debug.println("[" + Thread.currentThread().getName() + "] ungetService[Sfactory=" + this.registration.getBundle() + 
/* 162 */           "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/* 164 */     factoryUngetService(service);
/* 165 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void release() {
/* 180 */     super.release();
/*     */     
/* 182 */     S service = this.cachedService;
/* 183 */     if (service == null) {
/*     */       return;
/*     */     }
/* 186 */     this.cachedService = null;
/*     */     
/* 188 */     if (this.debug.DEBUG_SERVICES) {
/* 189 */       Debug.println("[" + Thread.currentThread().getName() + "] releaseService[Sfactory=" + 
/* 190 */           this.registration.getBundle() + "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/* 192 */     factoryUngetService(service);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getCachedService() {
/* 203 */     return this.cachedService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S factoryGetService() {
/*     */     S service;
/*     */     try {
/* 215 */       service = AccessController.doPrivileged(new PrivilegedAction<S>()
/*     */           {
/*     */             public S run() {
/* 218 */               return (S)ServiceFactoryUse.this.factory.getService((Bundle)ServiceFactoryUse.this.context.getBundleImpl(), ServiceFactoryUse.this.registration);
/*     */             }
/*     */           });
/* 221 */     } catch (Throwable t) {
/* 222 */       if (this.debug.DEBUG_SERVICES) {
/* 223 */         Debug.println(this.factory + ".getService() exception: " + t.getMessage());
/* 224 */         Debug.printStackTrace(t);
/*     */       } 
/*     */       
/* 227 */       this.context.getContainer().handleRuntimeError(t);
/* 228 */       ServiceException se = new ServiceException(NLS.bind(Msg.SERVICE_FACTORY_EXCEPTION, this.factory.getClass().getName(), "getService"), 3, t);
/* 229 */       this.context.getContainer().getEventPublisher().publishFrameworkEvent(2, this.registration.getBundle(), (Throwable)se);
/* 230 */       return null;
/*     */     } 
/*     */     
/* 233 */     if (service == null) {
/* 234 */       if (this.debug.DEBUG_SERVICES) {
/* 235 */         Debug.println(this.factory + ".getService() returned null.");
/*     */       }
/*     */       
/* 238 */       ServiceException se = new ServiceException(NLS.bind(Msg.SERVICE_OBJECT_NULL_EXCEPTION, this.factory.getClass().getName()), 2);
/* 239 */       this.context.getContainer().getEventPublisher().publishFrameworkEvent(16, this.registration.getBundle(), (Throwable)se);
/* 240 */       return null;
/*     */     } 
/*     */     
/* 243 */     String[] clazzes = this.registration.getClasses();
/* 244 */     String invalidService = ServiceRegistry.checkServiceClass(clazzes, service);
/* 245 */     if (invalidService != null) {
/* 246 */       if (this.debug.DEBUG_SERVICES) {
/* 247 */         Debug.println("Service object is not an instanceof " + invalidService);
/*     */       }
/* 249 */       ServiceException se = new ServiceException(
/* 250 */           NLS.bind(Msg.SERVICE_FACTORY_NOT_INSTANCEOF_CLASS_EXCEPTION, 
/* 251 */             new Object[] { this.factory.getClass().getName(), service.getClass().getName(), 
/* 252 */               invalidService
/* 253 */             }), 2);
/* 254 */       this.context.getContainer().getEventPublisher().publishFrameworkEvent(2, this.registration.getBundle(), (Throwable)se);
/* 255 */       return null;
/*     */     } 
/* 257 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void factoryUngetService(final S service) {
/*     */     try {
/* 268 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 271 */               ServiceFactoryUse.this.factory.ungetService((Bundle)ServiceFactoryUse.this.context.getBundleImpl(), ServiceFactoryUse.this.registration, service);
/* 272 */               return null;
/*     */             }
/*     */           });
/* 275 */     } catch (Throwable t) {
/* 276 */       if (this.debug.DEBUG_SERVICES) {
/* 277 */         Debug.println(this.factory + ".ungetService() exception");
/* 278 */         Debug.printStackTrace(t);
/*     */       } 
/*     */       
/* 281 */       ServiceException se = new ServiceException(NLS.bind(Msg.SERVICE_FACTORY_EXCEPTION, this.factory.getClass().getName(), "ungetService"), 3, t);
/* 282 */       this.context.getContainer().getEventPublisher().publishFrameworkEvent(2, this.registration.getBundle(), (Throwable)se);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceFactoryUse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */