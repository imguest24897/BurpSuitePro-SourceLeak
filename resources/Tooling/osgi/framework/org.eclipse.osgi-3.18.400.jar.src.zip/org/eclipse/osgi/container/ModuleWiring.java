/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.eclipse.osgi.internal.container.AtomicLazyInitializer;
/*     */ import org.eclipse.osgi.internal.container.InternalUtils;
/*     */ import org.eclipse.osgi.internal.container.NamespaceList;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRequirement;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleWire;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.resource.Wire;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleWiring
/*     */   implements BundleWiring
/*     */ {
/*     */   class LoaderInitializer
/*     */     implements Callable<ModuleLoader>
/*     */   {
/*     */     public ModuleLoader call() throws Exception {
/*  54 */       if (!ModuleWiring.this.isValid) {
/*  55 */         return null;
/*     */       }
/*  57 */       return (ModuleWiring.this.getRevision().getRevisions().getContainer()).adaptor.createModuleLoader(ModuleWiring.this);
/*     */     }
/*     */   }
/*     */   
/*  61 */   private static final RuntimePermission GET_CLASSLOADER_PERM = new RuntimePermission("getClassLoader");
/*     */   private static final String DYNAMICALLY_ADDED_IMPORT_DIRECTIVE = "x.dynamically.added";
/*     */   private final ModuleRevision revision;
/*     */   private volatile NamespaceList<ModuleCapability> capabilities;
/*     */   private volatile NamespaceList<ModuleRequirement> requirements;
/*     */   private final Collection<String> substitutedPkgNames;
/*  67 */   private final AtomicLazyInitializer<ModuleLoader> loader = new AtomicLazyInitializer();
/*  68 */   private final LoaderInitializer loaderInitializer = new LoaderInitializer();
/*     */   private volatile NamespaceList<ModuleWire> providedWires;
/*     */   private volatile NamespaceList<ModuleWire> requiredWires;
/*     */   volatile boolean isValid = true;
/*  72 */   private final AtomicReference<Set<String>> dynamicMissRef = new AtomicReference<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleWiring(ModuleRevision revision, NamespaceList<ModuleCapability> capabilities, NamespaceList<ModuleRequirement> requirements, NamespaceList<ModuleWire> providedWires, NamespaceList<ModuleWire> requiredWires, Collection<String> substitutedPkgNames) {
/*  78 */     this.revision = revision;
/*  79 */     this.capabilities = capabilities;
/*  80 */     this.requirements = requirements;
/*  81 */     this.providedWires = providedWires;
/*  82 */     this.requiredWires = requiredWires;
/*  83 */     this.substitutedPkgNames = substitutedPkgNames.isEmpty() ? Collections.<String>emptyList() : substitutedPkgNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/*  88 */     return this.revision.getBundle();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCurrent() {
/*  93 */     return (this.isValid && this.revision.isCurrent());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInUse() {
/*  98 */     return !(!isCurrent() && this.providedWires.isEmpty() && !isFragmentInUse());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isFragmentInUse() {
/* 103 */     if ((0x1 & this.revision.getTypes()) != 0) {
/* 104 */       List<ModuleWire> hostWires = getRequiredModuleWires("osgi.wiring.host");
/*     */       
/* 106 */       return (hostWires == null) ? false : (!hostWires.isEmpty());
/*     */     } 
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleCapability> getModuleCapabilities(String namespace) {
/* 120 */     if (!this.isValid) {
/* 121 */       return null;
/*     */     }
/* 123 */     return this.capabilities.getList(namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleRequirement> getModuleRequirements(String namespace) {
/* 135 */     if (!this.isValid) {
/* 136 */       return null;
/*     */     }
/* 138 */     return this.requirements.getList(namespace);
/*     */   }
/*     */   
/*     */   List<ModuleRequirement> getPersistentRequirements() {
/* 142 */     if (!this.isValid) {
/* 143 */       return null;
/*     */     }
/* 145 */     List<ModuleRequirement> persistentRequriements = new ArrayList<>(this.requirements.getList(null));
/* 146 */     for (Iterator<ModuleRequirement> iRequirements = persistentRequriements.iterator(); iRequirements.hasNext(); ) {
/* 147 */       ModuleRequirement requirement = iRequirements.next();
/* 148 */       if ("osgi.wiring.package".equals(requirement.getNamespace()) && 
/* 149 */         "true".equals(requirement.getDirectives().get("x.dynamically.added"))) {
/* 150 */         iRequirements.remove();
/*     */       }
/*     */     } 
/*     */     
/* 154 */     return persistentRequriements;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleCapability> getCapabilities(String namespace) {
/* 159 */     return InternalUtils.asCopy(getModuleCapabilities(namespace));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BundleRequirement> getRequirements(String namespace) {
/* 165 */     return InternalUtils.asCopy(getModuleRequirements(namespace));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleWire> getProvidedModuleWires(String namespace) {
/* 177 */     return getWires(namespace, this.providedWires);
/*     */   }
/*     */   
/*     */   List<ModuleWire> getPersistentProvidedWires() {
/* 181 */     return getPersistentWires(this.providedWires);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleWire> getRequiredModuleWires(String namespace) {
/* 193 */     return getWires(namespace, this.requiredWires);
/*     */   }
/*     */   
/*     */   List<ModuleWire> getPersistentRequiredWires() {
/* 197 */     return getPersistentWires(this.requiredWires);
/*     */   }
/*     */   
/*     */   private List<ModuleWire> getPersistentWires(NamespaceList<ModuleWire> allWires) {
/* 201 */     if (!this.isValid) {
/* 202 */       return null;
/*     */     }
/* 204 */     List<ModuleWire> persistentWires = new ArrayList<>(allWires.getList(null));
/* 205 */     for (Iterator<ModuleWire> iWires = persistentWires.iterator(); iWires.hasNext(); ) {
/* 206 */       ModuleWire wire = iWires.next();
/* 207 */       if ("osgi.wiring.package".equals(wire.getRequirement().getNamespace()) && 
/* 208 */         "true".equals(wire.getRequirement().getDirectives().get("x.dynamically.added"))) {
/* 209 */         iWires.remove();
/*     */       }
/*     */     } 
/*     */     
/* 213 */     return persistentWires;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleWire> getProvidedWires(String namespace) {
/* 218 */     return InternalUtils.asCopy(getWires(namespace, this.providedWires));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleWire> getRequiredWires(String namespace) {
/* 223 */     return InternalUtils.asCopy(getWires(namespace, this.requiredWires));
/*     */   }
/*     */   
/*     */   private List<ModuleWire> getWires(String namespace, NamespaceList<ModuleWire> wires) {
/* 227 */     if (!this.isValid) {
/* 228 */       return null;
/*     */     }
/* 230 */     return wires.getList(namespace);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleRevision getRevision() {
/* 235 */     return this.revision;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 240 */     SecurityManager sm = System.getSecurityManager();
/* 241 */     if (sm != null) {
/* 242 */       sm.checkPermission(GET_CLASSLOADER_PERM);
/*     */     }
/*     */     
/* 245 */     if (!this.isValid) {
/* 246 */       return null;
/*     */     }
/* 248 */     ModuleLoader current = getModuleLoader();
/* 249 */     if (current == null)
/*     */     {
/* 251 */       return null;
/*     */     }
/* 253 */     return current.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleLoader getModuleLoader() {
/* 262 */     return (ModuleLoader)this.loader.getInitialized(this.loaderInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   void loadFragments(Collection<ModuleRevision> fragments) {
/* 267 */     ModuleLoader current = (ModuleLoader)this.loader.get();
/* 268 */     if (current != null) {
/* 269 */       current.loadFragments(fragments);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public List<URL> findEntries(String path, String filePattern, int options) {
/* 275 */     if (!hasResourcePermission())
/* 276 */       return Collections.emptyList(); 
/* 277 */     if (!this.isValid) {
/* 278 */       return null;
/*     */     }
/* 280 */     ModuleLoader current = getModuleLoader();
/* 281 */     if (current == null)
/*     */     {
/* 283 */       return null;
/*     */     }
/* 285 */     return current.findEntries(path, filePattern, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> listResources(String path, String filePattern, int options) {
/* 290 */     if (!hasResourcePermission())
/* 291 */       return Collections.emptyList(); 
/* 292 */     if (!this.isValid) {
/* 293 */       return null;
/*     */     }
/* 295 */     ModuleLoader current = getModuleLoader();
/* 296 */     if (current == null)
/*     */     {
/* 298 */       return null;
/*     */     }
/* 300 */     return current.listResources(path, filePattern, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Capability> getResourceCapabilities(String namespace) {
/* 305 */     return InternalUtils.asCopy(getModuleCapabilities(namespace));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Requirement> getResourceRequirements(String namespace) {
/* 310 */     return InternalUtils.asCopy(getModuleRequirements(namespace));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Wire> getProvidedResourceWires(String namespace) {
/* 315 */     return InternalUtils.asCopy(getWires(namespace, this.providedWires));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Wire> getRequiredResourceWires(String namespace) {
/* 320 */     return InternalUtils.asCopy(getWires(namespace, this.requiredWires));
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleRevision getResource() {
/* 325 */     return this.revision;
/*     */   }
/*     */   
/*     */   void setProvidedWires(NamespaceList<ModuleWire> providedWires) {
/* 329 */     this.providedWires = providedWires;
/*     */   }
/*     */   
/*     */   void setRequiredWires(NamespaceList<ModuleWire> requiredWires) {
/* 333 */     this.requiredWires = requiredWires;
/*     */   }
/*     */   
/*     */   void setCapabilities(NamespaceList<ModuleCapability> capabilities) {
/* 337 */     this.capabilities = capabilities;
/*     */   }
/*     */   
/*     */   void setRequirements(NamespaceList<ModuleRequirement> requirements) {
/* 341 */     this.requirements = requirements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unload() {
/* 349 */     invalidate0(true);
/*     */   }
/*     */   
/*     */   void invalidate() {
/* 353 */     invalidate0(false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void invalidate0(boolean releaseLoader) {
/* 358 */     this.isValid = false;
/* 359 */     ModuleLoader current = releaseLoader ? (ModuleLoader)this.loader.getAndClear() : (ModuleLoader)this.loader.get();
/* 360 */     this.revision.getRevisions().getContainer().getAdaptor().invalidateWiring(this, current);
/*     */   }
/*     */   
/*     */   void validate() {
/* 364 */     this.isValid = true;
/*     */   }
/*     */   
/*     */   boolean isSubtituted(ModuleCapability capability) {
/* 368 */     if (!"osgi.wiring.package".equals(capability.getNamespace())) {
/* 369 */       return false;
/*     */     }
/* 371 */     return this.substitutedPkgNames.contains(capability.getAttributes().get("osgi.wiring.package"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubstitutedPackage(String packageName) {
/* 380 */     return this.substitutedPkgNames.contains(packageName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getSubstitutedNames() {
/* 389 */     return Collections.unmodifiableCollection(this.substitutedPkgNames);
/*     */   }
/*     */   
/*     */   private boolean hasResourcePermission() {
/* 393 */     SecurityManager sm = System.getSecurityManager();
/* 394 */     if (sm != null) {
/*     */       try {
/* 396 */         sm.checkPermission((Permission)new AdminPermission(getBundle(), "resource"));
/* 397 */       } catch (SecurityException securityException) {
/* 398 */         return false;
/*     */       } 
/*     */     }
/* 401 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDynamicImports(ModuleRevisionBuilder builder) {
/* 412 */     NamespaceList.Builder<ModuleRevisionBuilder.GenericInfo> newImports = builder.getRequirementsBuilder();
/* 413 */     NamespaceList.Builder<ModuleRequirement> newRequirements = newImports.transformIntoCopy(info -> {
/*     */           if (!"osgi.wiring.package".equals(info.getNamespace())) {
/*     */             throw new IllegalArgumentException("Invalid namespace for package imports: " + info.getNamespace());
/*     */           }
/*     */           Map<String, Object> attributes = new HashMap<>(info.getAttributes());
/*     */           Map<String, String> directives = new HashMap<>(info.getDirectives());
/*     */           directives.put("x.dynamically.added", "true");
/*     */           directives.put("resolution", "dynamic");
/*     */           return new ModuleRequirement(info.getNamespace(), directives, attributes, this.revision);
/* 422 */         }NamespaceList.REQUIREMENT);
/*     */     
/* 424 */     ModuleDatabase moduleDatabase = (this.revision.getRevisions().getContainer()).moduleDatabase;
/*     */ 
/*     */ 
/*     */     
/* 428 */     moduleDatabase.writeLockOperation(true, () -> {
/*     */           NamespaceList.Builder<ModuleRequirement> requirmentsBuilder = this.requirements.createBuilder();
/*     */           requirmentsBuilder.addAll((Collection)paramBuilder);
/*     */           this.requirements = requirmentsBuilder.build();
/*     */           this.dynamicMissRef.updateAndGet(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addDynamicPackageMiss(String packageName) {
/* 443 */     Set<String> misses = this.dynamicMissRef.get();
/* 444 */     if (misses == null) {
/* 445 */       this.dynamicMissRef.compareAndSet(null, Collections.synchronizedSet(new HashSet<>()));
/* 446 */       misses = this.dynamicMissRef.get();
/*     */     } 
/*     */     
/* 449 */     misses.add(packageName);
/*     */   }
/*     */   
/*     */   boolean isDynamicPackageMiss(String packageName) {
/* 453 */     Set<String> misses = this.dynamicMissRef.get();
/* 454 */     return (misses != null && misses.contains(packageName));
/*     */   }
/*     */   
/*     */   void removeDynamicPackageMisses(Collection<String> packageNames) {
/* 458 */     Set<String> misses = this.dynamicMissRef.get();
/* 459 */     if (misses != null) {
/* 460 */       misses.removeAll(packageNames);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 466 */     return this.revision.toString();
/*     */   }
/*     */   
/*     */   List<Wire> getSubstitutionWires() {
/* 470 */     if (this.substitutedPkgNames.isEmpty()) {
/* 471 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 474 */     List<Wire> substitutionWires = new ArrayList<>(this.substitutedPkgNames.size());
/* 475 */     List<ModuleWire> current = this.requiredWires.getList("osgi.wiring.package");
/* 476 */     for (ModuleWire wire : current) {
/* 477 */       ModuleCapability moduleCapability = wire.getCapability();
/* 478 */       if (this.substitutedPkgNames.contains(moduleCapability.getAttributes().get("osgi.wiring.package"))) {
/* 479 */         substitutionWires.add(wire);
/*     */       }
/*     */     } 
/* 482 */     return substitutionWires;
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleCapability> getCapabilities() {
/* 486 */     return this.capabilities;
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleWire> getProvidedWires() {
/* 490 */     return this.providedWires;
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleRequirement> getRequirements() {
/* 494 */     return this.requirements;
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleWire> getRequiredWires() {
/* 498 */     return this.requiredWires;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleWiring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */