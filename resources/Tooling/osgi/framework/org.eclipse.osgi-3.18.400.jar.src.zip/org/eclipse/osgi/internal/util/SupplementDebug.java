/*    */ package org.eclipse.osgi.internal.util;
/*    */ 
/*    */ public final class SupplementDebug {
/*    */   public static boolean STATIC_DEBUG_MANIFEST = false;
/*    */   public static boolean STATIC_DEBUG_MESSAGE_BUNDLES = false;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\util\SupplementDebug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */