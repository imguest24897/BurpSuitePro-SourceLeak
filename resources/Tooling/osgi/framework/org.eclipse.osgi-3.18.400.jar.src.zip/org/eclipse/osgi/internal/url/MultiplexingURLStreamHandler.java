/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiplexingURLStreamHandler
/*     */   extends URLStreamHandler
/*     */ {
/*     */   private static Method openConnectionMethod;
/*     */   private static Method openConnectionProxyMethod;
/*     */   private static Method equalsMethod;
/*     */   private static Method getDefaultPortMethod;
/*     */   private static Method getHostAddressMethod;
/*     */   private static Method hashCodeMethod;
/*     */   private static Method hostsEqualMethod;
/*     */   private static Method parseURLMethod;
/*     */   private static Method sameFileMethod;
/*     */   private static Method setURLMethod;
/*     */   private static Method toExternalFormMethod;
/*     */   private static Field handlerField;
/*     */   private static boolean methodsInitialized = false;
/*     */   private String protocol;
/*     */   private URLStreamHandlerFactoryImpl factory;
/*     */   private final URLStreamHandler authorized;
/*     */   
/*     */   private static synchronized void initializeMethods(URLStreamHandlerFactoryImpl factory) {
/*  40 */     if (methodsInitialized)
/*     */       return; 
/*     */     try {
/*  43 */       openConnectionMethod = URLStreamHandler.class.getDeclaredMethod("openConnection", new Class[] { URL.class });
/*  44 */       MultiplexingFactory.setAccessible(openConnectionMethod);
/*     */       
/*  46 */       openConnectionProxyMethod = URLStreamHandler.class.getDeclaredMethod("openConnection", new Class[] { URL.class, Proxy.class });
/*  47 */       MultiplexingFactory.setAccessible(openConnectionProxyMethod);
/*     */       
/*  49 */       equalsMethod = URLStreamHandler.class.getDeclaredMethod("equals", new Class[] { URL.class, URL.class });
/*  50 */       MultiplexingFactory.setAccessible(equalsMethod);
/*     */       
/*  52 */       getDefaultPortMethod = URLStreamHandler.class.getDeclaredMethod("getDefaultPort", null);
/*  53 */       MultiplexingFactory.setAccessible(getDefaultPortMethod);
/*     */       
/*  55 */       getHostAddressMethod = URLStreamHandler.class.getDeclaredMethod("getHostAddress", new Class[] { URL.class });
/*  56 */       MultiplexingFactory.setAccessible(getHostAddressMethod);
/*     */       
/*  58 */       hashCodeMethod = URLStreamHandler.class.getDeclaredMethod("hashCode", new Class[] { URL.class });
/*  59 */       MultiplexingFactory.setAccessible(hashCodeMethod);
/*     */       
/*  61 */       hostsEqualMethod = URLStreamHandler.class.getDeclaredMethod("hostsEqual", new Class[] { URL.class, URL.class });
/*  62 */       MultiplexingFactory.setAccessible(hostsEqualMethod);
/*     */       
/*  64 */       parseURLMethod = URLStreamHandler.class.getDeclaredMethod("parseURL", new Class[] { URL.class, String.class, int.class, int.class });
/*  65 */       MultiplexingFactory.setAccessible(parseURLMethod);
/*     */       
/*  67 */       sameFileMethod = URLStreamHandler.class.getDeclaredMethod("sameFile", new Class[] { URL.class, URL.class });
/*  68 */       MultiplexingFactory.setAccessible(sameFileMethod);
/*     */       
/*  70 */       setURLMethod = URLStreamHandler.class.getDeclaredMethod("setURL", new Class[] { URL.class, String.class, String.class, int.class, String.class, String.class, String.class, String.class, String.class });
/*  71 */       MultiplexingFactory.setAccessible(setURLMethod);
/*     */       
/*  73 */       toExternalFormMethod = URLStreamHandler.class.getDeclaredMethod("toExternalForm", new Class[] { URL.class });
/*  74 */       MultiplexingFactory.setAccessible(toExternalFormMethod);
/*     */       
/*     */       try {
/*  77 */         handlerField = URL.class.getDeclaredField("handler");
/*  78 */       } catch (NoSuchFieldException e) {
/*  79 */         handlerField = EquinoxFactoryManager.getField(URL.class, URLStreamHandler.class, true);
/*  80 */         if (handlerField == null)
/*  81 */           throw e; 
/*     */       } 
/*  83 */       MultiplexingFactory.setAccessible(handlerField);
/*  84 */     } catch (Exception e) {
/*  85 */       factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "initializeMethods", e);
/*  86 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*  88 */     methodsInitialized = true;
/*     */   }
/*     */   
/*     */   public MultiplexingURLStreamHandler(String protocol, URLStreamHandlerFactoryImpl factory, URLStreamHandler authorized) {
/*  92 */     this.protocol = protocol;
/*  93 */     this.factory = factory;
/*  94 */     this.authorized = authorized;
/*  95 */     initializeMethods(factory);
/*     */   }
/*     */ 
/*     */   
/*     */   protected URLConnection openConnection(URL url) throws IOException {
/* 100 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 101 */     if (handler != null) {
/*     */       try {
/* 103 */         return (URLConnection)openConnectionMethod.invoke(handler, new Object[] { url });
/* 104 */       } catch (InvocationTargetException e) {
/* 105 */         if (e.getTargetException() instanceof IOException)
/* 106 */           throw (IOException)e.getTargetException(); 
/* 107 */         throw (RuntimeException)e.getTargetException();
/* 108 */       } catch (Exception e) {
/* 109 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "openConnection", e);
/* 110 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 113 */     throw new MalformedURLException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected URLConnection openConnection(URL url, Proxy proxy) throws IOException {
/* 118 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 119 */     if (handler != null) {
/*     */       try {
/* 121 */         return (URLConnection)openConnectionProxyMethod.invoke(handler, new Object[] { url, proxy });
/* 122 */       } catch (InvocationTargetException e) {
/* 123 */         if (e.getTargetException() instanceof IOException)
/* 124 */           throw (IOException)e.getTargetException(); 
/* 125 */         throw (RuntimeException)e.getTargetException();
/* 126 */       } catch (Exception e) {
/* 127 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "openConnection", e);
/* 128 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 131 */     throw new MalformedURLException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equals(URL url1, URL url2) {
/* 136 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 137 */     if (handler != null) {
/*     */       try {
/* 139 */         return ((Boolean)equalsMethod.invoke(handler, new Object[] { url1, url2 })).booleanValue();
/* 140 */       } catch (InvocationTargetException e) {
/* 141 */         throw (RuntimeException)e.getTargetException();
/* 142 */       } catch (Exception e) {
/* 143 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "equals", e);
/* 144 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 147 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getDefaultPort() {
/* 152 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 153 */     if (handler != null) {
/*     */       try {
/* 155 */         return ((Integer)getDefaultPortMethod.invoke(handler, null)).intValue();
/* 156 */       } catch (InvocationTargetException e) {
/* 157 */         throw (RuntimeException)e.getTargetException();
/* 158 */       } catch (Exception e) {
/* 159 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "getDefaultPort", e);
/* 160 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 163 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected InetAddress getHostAddress(URL url) {
/* 168 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 169 */     if (handler != null) {
/*     */       try {
/* 171 */         return (InetAddress)getHostAddressMethod.invoke(handler, new Object[] { url });
/* 172 */       } catch (InvocationTargetException e) {
/* 173 */         throw (RuntimeException)e.getTargetException();
/* 174 */       } catch (Exception e) {
/* 175 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "hashCode", e);
/* 176 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 179 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int hashCode(URL url) {
/* 184 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 185 */     if (handler != null) {
/*     */       try {
/* 187 */         return ((Integer)hashCodeMethod.invoke(handler, new Object[] { url })).intValue();
/* 188 */       } catch (InvocationTargetException e) {
/* 189 */         throw (RuntimeException)e.getTargetException();
/* 190 */       } catch (Exception e) {
/* 191 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "hashCode", e);
/* 192 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 195 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hostsEqual(URL url1, URL url2) {
/* 200 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 201 */     if (handler != null) {
/*     */       try {
/* 203 */         return ((Boolean)hostsEqualMethod.invoke(handler, new Object[] { url1, url2 })).booleanValue();
/* 204 */       } catch (InvocationTargetException e) {
/* 205 */         throw (RuntimeException)e.getTargetException();
/* 206 */       } catch (Exception e) {
/* 207 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "hostsEqual", e);
/* 208 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 211 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parseURL(URL arg0, String arg1, int arg2, int arg3) {
/* 216 */     URLStreamHandler handler = this.factory.findAuthorizedURLStreamHandler(this.protocol);
/* 217 */     if (handler != null) {
/*     */       
/*     */       try {
/* 220 */         handlerField.set(arg0, handler);
/* 221 */         parseURLMethod.invoke(handler, new Object[] { arg0, arg1, Integer.valueOf(arg2), Integer.valueOf(arg3) });
/*     */         return;
/* 223 */       } catch (InvocationTargetException e) {
/* 224 */         throw (RuntimeException)e.getTargetException();
/* 225 */       } catch (Exception e) {
/* 226 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "parseURL", e);
/* 227 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 230 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean sameFile(URL url1, URL url2) {
/* 235 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 236 */     if (handler != null) {
/*     */       try {
/* 238 */         return ((Boolean)sameFileMethod.invoke(handler, new Object[] { url1, url2 })).booleanValue();
/* 239 */       } catch (InvocationTargetException e) {
/* 240 */         throw (RuntimeException)e.getTargetException();
/* 241 */       } catch (Exception e) {
/* 242 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "sameFile", e);
/* 243 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 246 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setURL(URL arg0, String arg1, String arg2, int arg3, String arg4, String arg5, String arg6, String arg7, String arg8) {
/* 251 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 252 */     if (handler != null) {
/*     */       
/*     */       try {
/* 255 */         handlerField.set(arg0, handler);
/* 256 */         setURLMethod.invoke(handler, new Object[] { arg0, arg1, arg2, Integer.valueOf(arg3), arg4, arg5, arg6, arg7, arg8 });
/*     */         return;
/* 258 */       } catch (InvocationTargetException e) {
/* 259 */         throw (RuntimeException)e.getTargetException();
/* 260 */       } catch (Exception e) {
/* 261 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "setURL", e);
/* 262 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 265 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String toExternalForm(URL url) {
/* 270 */     URLStreamHandler handler = findAuthorizedURLStreamHandler(this.protocol);
/* 271 */     if (handler != null) {
/*     */       try {
/* 273 */         return (String)toExternalFormMethod.invoke(handler, new Object[] { url });
/* 274 */       } catch (InvocationTargetException e) {
/* 275 */         throw (RuntimeException)e.getTargetException();
/* 276 */       } catch (Exception e) {
/* 277 */         this.factory.container.getLogServices().log(MultiplexingURLStreamHandler.class.getName(), 4, "toExternalForm", e);
/* 278 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/* 281 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   private URLStreamHandler findAuthorizedURLStreamHandler(String requested) {
/* 285 */     URLStreamHandler handler = this.factory.findAuthorizedURLStreamHandler(requested);
/* 286 */     return (handler == null) ? this.authorized : handler;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\MultiplexingURLStreamHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */