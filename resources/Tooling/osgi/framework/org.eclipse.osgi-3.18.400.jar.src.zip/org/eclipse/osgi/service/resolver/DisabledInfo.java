/*    */ package org.eclipse.osgi.service.resolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DisabledInfo
/*    */ {
/*    */   private final String policyName;
/*    */   private final String message;
/*    */   private final BundleDescription bundle;
/*    */   
/*    */   public DisabledInfo(String policyName, String message, BundleDescription bundle) {
/* 42 */     if (policyName == null || bundle == null)
/* 43 */       throw new IllegalArgumentException(); 
/* 44 */     this.policyName = policyName;
/* 45 */     this.message = message;
/* 46 */     this.bundle = bundle;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPolicyName() {
/* 54 */     return this.policyName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 62 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleDescription getBundle() {
/* 70 */     return this.bundle;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 75 */     if (obj == this)
/* 76 */       return true; 
/* 77 */     if (!(obj instanceof DisabledInfo))
/* 78 */       return false; 
/* 79 */     DisabledInfo other = (DisabledInfo)obj;
/* 80 */     if (getBundle() == other.getBundle() && getPolicyName().equals(other.getPolicyName()) && (
/* 81 */       (getMessage() == null) ? (other.getMessage() == null) : getMessage().equals(other.getMessage()))) {
/* 82 */       return true;
/*    */     }
/* 84 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 90 */     int result = 1;
/* 91 */     result = 31 * result + ((this.bundle == null) ? 0 : this.bundle.hashCode());
/* 92 */     result = 31 * result + ((this.policyName == null) ? 0 : this.policyName.hashCode());
/* 93 */     result = 31 * result + ((this.message == null) ? 0 : this.message.hashCode());
/* 94 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\DisabledInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */