package org.osgi.util.tracker;

import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.ServiceReference;

@ConsumerType
public interface ServiceTrackerCustomizer<S, T> {
  T addingService(ServiceReference<S> paramServiceReference);
  
  void modifiedService(ServiceReference<S> paramServiceReference, T paramT);
  
  void removedService(ServiceReference<S> paramServiceReference, T paramT);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osg\\util\tracker\ServiceTrackerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */