package org.osgi.resource;

import java.util.List;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface Resource {
  List<Capability> getCapabilities(String paramString);
  
  List<Requirement> getRequirements(String paramString);
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\Resource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */