package org.osgi.resource;

import java.util.List;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface Wiring {
  List<Capability> getResourceCapabilities(String paramString);
  
  List<Requirement> getResourceRequirements(String paramString);
  
  List<Wire> getProvidedResourceWires(String paramString);
  
  List<Wire> getRequiredResourceWires(String paramString);
  
  Resource getResource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\Wiring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */