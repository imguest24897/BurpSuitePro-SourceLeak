package org.osgi.resource.dto;

import java.util.Map;
import org.osgi.dto.DTO;

public class CapabilityDTO extends DTO {
  public int id;
  
  public String namespace;
  
  public Map<String, String> directives;
  
  public Map<String, Object> attributes;
  
  public int resource;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\dto\CapabilityDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */