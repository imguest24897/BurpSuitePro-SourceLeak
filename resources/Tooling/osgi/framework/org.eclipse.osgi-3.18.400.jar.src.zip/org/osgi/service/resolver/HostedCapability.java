package org.osgi.service.resolver;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.resource.Capability;
import org.osgi.resource.Resource;

@ProviderType
public interface HostedCapability extends Capability {
  Resource getResource();
  
  Capability getDeclaredCapability();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\resolver\HostedCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */