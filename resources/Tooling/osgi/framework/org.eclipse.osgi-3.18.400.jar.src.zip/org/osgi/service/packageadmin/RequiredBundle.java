package org.osgi.service.packageadmin;

import org.osgi.framework.Bundle;
import org.osgi.framework.Version;

public interface RequiredBundle {
  String getSymbolicName();
  
  Bundle getBundle();
  
  Bundle[] getRequiringBundles();
  
  Version getVersion();
  
  boolean isRemovalPending();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\packageadmin\RequiredBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */