/*    */ package org.osgi.service.condpermadmin;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.FrameworkUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleSignerCondition
/*    */ {
/*    */   private static final String CONDITION_TYPE = "org.osgi.service.condpermadmin.BundleSignerCondition";
/*    */   
/*    */   public static Condition getCondition(Bundle bundle, ConditionInfo info) {
/* 75 */     if (!"org.osgi.service.condpermadmin.BundleSignerCondition".equals(info.getType()))
/* 76 */       throw new IllegalArgumentException("ConditionInfo must be of type \"org.osgi.service.condpermadmin.BundleSignerCondition\""); 
/* 77 */     String[] args = info.getArgs();
/* 78 */     if (args.length != 1 && args.length != 2) {
/* 79 */       throw new IllegalArgumentException("Illegal number of args: " + args.length);
/*    */     }
/* 81 */     Map<X509Certificate, List<X509Certificate>> signers = bundle.getSignerCertificates(2);
/* 82 */     boolean match = false;
/* 83 */     for (List<X509Certificate> signerCerts : signers.values()) {
/* 84 */       List<String> dnChain = new ArrayList<>(signerCerts.size());
/* 85 */       for (X509Certificate signer : signerCerts) {
/* 86 */         dnChain.add(signer.getSubjectDN().getName());
/*    */       }
/* 88 */       if (FrameworkUtil.matchDistinguishedNameChain(args[0], dnChain)) {
/* 89 */         match = true;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 94 */     boolean negate = (args.length == 2) ? "!".equals(args[1]) : false;
/* 95 */     return (negate ^ match) ? Condition.TRUE : Condition.FALSE;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\BundleSignerCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */