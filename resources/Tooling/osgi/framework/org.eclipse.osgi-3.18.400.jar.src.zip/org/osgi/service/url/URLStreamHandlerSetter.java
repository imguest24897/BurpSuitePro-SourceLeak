package org.osgi.service.url;

import java.net.URL;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface URLStreamHandlerSetter {
  void setURL(URL paramURL, String paramString1, String paramString2, int paramInt, String paramString3, String paramString4);
  
  void setURL(URL paramURL, String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\servic\\url\URLStreamHandlerSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */