package org.osgi.service.log.admin;

import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.log.LogLevel;

@ProviderType
public interface LoggerContext {
  public static final String LOGGER_CONTEXT_PID = "org.osgi.service.log.admin";
  
  public static final String LOGGER_CONTEXT_DEFAULT_LOGLEVEL = "org.osgi.service.log.admin.loglevel";
  
  String getName();
  
  LogLevel getEffectiveLogLevel(String paramString);
  
  Map<String, LogLevel> getLogLevels();
  
  void setLogLevels(Map<String, LogLevel> paramMap);
  
  void clear();
  
  boolean isEmpty();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\log\admin\LoggerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */