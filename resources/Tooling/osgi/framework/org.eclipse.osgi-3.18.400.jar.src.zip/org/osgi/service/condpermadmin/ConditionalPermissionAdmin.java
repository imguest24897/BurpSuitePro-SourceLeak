package org.osgi.service.condpermadmin;

import java.security.AccessControlContext;
import java.util.Enumeration;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.permissionadmin.PermissionInfo;

@ProviderType
public interface ConditionalPermissionAdmin {
  ConditionalPermissionInfo addConditionalPermissionInfo(ConditionInfo[] paramArrayOfConditionInfo, PermissionInfo[] paramArrayOfPermissionInfo);
  
  ConditionalPermissionInfo setConditionalPermissionInfo(String paramString, ConditionInfo[] paramArrayOfConditionInfo, PermissionInfo[] paramArrayOfPermissionInfo);
  
  Enumeration<ConditionalPermissionInfo> getConditionalPermissionInfos();
  
  ConditionalPermissionInfo getConditionalPermissionInfo(String paramString);
  
  AccessControlContext getAccessControlContext(String[] paramArrayOfString);
  
  ConditionalPermissionUpdate newConditionalPermissionUpdate();
  
  ConditionalPermissionInfo newConditionalPermissionInfo(String paramString1, ConditionInfo[] paramArrayOfConditionInfo, PermissionInfo[] paramArrayOfPermissionInfo, String paramString2);
  
  ConditionalPermissionInfo newConditionalPermissionInfo(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\ConditionalPermissionAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */