package org.osgi.service.log;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;

@ProviderType
public interface LoggerFactory {
  Logger getLogger(String paramString);
  
  Logger getLogger(Class<?> paramClass);
  
  <L extends Logger> L getLogger(String paramString, Class<L> paramClass);
  
  <L extends Logger> L getLogger(Class<?> paramClass, Class<L> paramClass1);
  
  <L extends Logger> L getLogger(Bundle paramBundle, String paramString, Class<L> paramClass);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\log\LoggerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */