/*     */ package org.osgi.service.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.osgi.resource.Requirement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolutionException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final transient Collection<Requirement> unresolvedRequirements;
/*     */   
/*     */   public ResolutionException(String message, Throwable cause, Collection<Requirement> unresolvedRequirements) {
/*  56 */     super(message, cause);
/*  57 */     if (unresolvedRequirements == null || unresolvedRequirements.isEmpty()) {
/*  58 */       this.unresolvedRequirements = null;
/*     */     } else {
/*  60 */       this.unresolvedRequirements = Collections.unmodifiableCollection(new ArrayList<>(unresolvedRequirements));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolutionException(String message) {
/*  70 */     super(message);
/*  71 */     this.unresolvedRequirements = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolutionException(Throwable cause) {
/*  80 */     super(cause);
/*  81 */     this.unresolvedRequirements = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Collection<Requirement> emptyCollection() {
/*  86 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Requirement> getUnresolvedRequirements() {
/* 102 */     return (this.unresolvedRequirements != null) ? this.unresolvedRequirements : emptyCollection();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\resolver\ResolutionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */