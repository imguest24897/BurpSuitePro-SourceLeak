/*     */ package org.osgi.service.permissionadmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissionInfo
/*     */ {
/*     */   private final String type;
/*     */   private final String name;
/*     */   private final String actions;
/*     */   
/*     */   public PermissionInfo(String type, String name, String actions) {
/*  67 */     this.type = type;
/*  68 */     this.name = name;
/*  69 */     this.actions = actions;
/*  70 */     if (type == null) {
/*  71 */       throw new NullPointerException("type is null");
/*     */     }
/*  73 */     if (name == null && actions != null) {
/*  74 */       throw new IllegalArgumentException("name missing");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionInfo(String encodedPermission) {
/*  90 */     if (encodedPermission == null) {
/*  91 */       throw new NullPointerException("missing encoded permission");
/*     */     }
/*  93 */     if (encodedPermission.length() == 0) {
/*  94 */       throw new IllegalArgumentException("empty encoded permission");
/*     */     }
/*  96 */     String parsedType = null;
/*  97 */     String parsedName = null;
/*  98 */     String parsedActions = null;
/*     */     try {
/* 100 */       char[] encoded = encodedPermission.toCharArray();
/* 101 */       int length = encoded.length;
/* 102 */       int pos = 0;
/*     */ 
/*     */       
/* 105 */       while (Character.isWhitespace(encoded[pos])) {
/* 106 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 110 */       if (encoded[pos] != '(') {
/* 111 */         throw new IllegalArgumentException("expecting open parenthesis");
/*     */       }
/* 113 */       pos++;
/*     */ 
/*     */       
/* 116 */       while (Character.isWhitespace(encoded[pos])) {
/* 117 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 121 */       int begin = pos;
/* 122 */       while (!Character.isWhitespace(encoded[pos]) && encoded[pos] != ')') {
/* 123 */         pos++;
/*     */       }
/* 125 */       if (pos == begin || encoded[begin] == '"') {
/* 126 */         throw new IllegalArgumentException("expecting type");
/*     */       }
/* 128 */       parsedType = new String(encoded, begin, pos - begin);
/*     */ 
/*     */       
/* 131 */       while (Character.isWhitespace(encoded[pos])) {
/* 132 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 136 */       if (encoded[pos] == '"') {
/*     */         
/* 138 */         begin = ++pos;
/* 139 */         while (encoded[pos] != '"') {
/* 140 */           if (encoded[pos] == '\\') {
/* 141 */             pos++;
/*     */           }
/* 143 */           pos++;
/*     */         } 
/* 145 */         parsedName = unescapeString(encoded, begin, pos);
/* 146 */         pos++;
/*     */         
/* 148 */         if (Character.isWhitespace(encoded[pos])) {
/*     */           
/* 150 */           while (Character.isWhitespace(encoded[pos])) {
/* 151 */             pos++;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 158 */           if (encoded[pos] == '"') {
/*     */             
/* 160 */             begin = ++pos;
/* 161 */             while (encoded[pos] != '"') {
/* 162 */               if (encoded[pos] == '\\') {
/* 163 */                 pos++;
/*     */               }
/* 165 */               pos++;
/*     */             } 
/* 167 */             parsedActions = unescapeString(encoded, begin, pos);
/* 168 */             pos++;
/*     */ 
/*     */             
/* 171 */             while (Character.isWhitespace(encoded[pos])) {
/* 172 */               pos++;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 179 */       char c = encoded[pos];
/* 180 */       pos++;
/* 181 */       while (pos < length && Character.isWhitespace(encoded[pos])) {
/* 182 */         pos++;
/*     */       }
/* 184 */       if (c != ')' || pos != length) {
/* 185 */         throw new IllegalArgumentException("expecting close parenthesis");
/*     */       }
/* 187 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 188 */       throw new IllegalArgumentException("parsing terminated abruptly");
/*     */     } 
/*     */     
/* 191 */     this.type = parsedType;
/* 192 */     this.name = parsedName;
/* 193 */     this.actions = parsedActions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getEncoded() {
/* 233 */     StringBuilder output = new StringBuilder(
/* 234 */         8 + this.type.length() + (((this.name == null) ? 0 : this.name.length()) + (
/* 235 */         (this.actions == null) ? 0 : this.actions.length()) << 1));
/* 236 */     output.append('(');
/* 237 */     output.append(this.type);
/* 238 */     if (this.name != null) {
/* 239 */       output.append(" \"");
/* 240 */       escapeString(this.name, output);
/* 241 */       if (this.actions != null) {
/* 242 */         output.append("\" \"");
/* 243 */         escapeString(this.actions, output);
/*     */       } 
/* 245 */       output.append('"');
/*     */     } 
/* 247 */     output.append(')');
/* 248 */     return output.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 260 */     return getEncoded();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getType() {
/* 271 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 283 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getActions() {
/* 295 */     return this.actions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 312 */     if (obj == this) {
/* 313 */       return true;
/*     */     }
/* 315 */     if (!(obj instanceof PermissionInfo)) {
/* 316 */       return false;
/*     */     }
/* 318 */     PermissionInfo other = (PermissionInfo)obj;
/* 319 */     if (this.type.equals(other.type)) if ((((this.name == null) ? 1 : 0) ^ ((other.name == null) ? 1 : 0)) == 0) if ((((this.actions == null) ? 1 : 0) ^ ((other.actions == null) ? 1 : 0)) == 0) {
/*     */ 
/*     */           
/* 322 */           if (this.name != null) {
/* 323 */             if (this.actions != null) {
/* 324 */               return (this.name.equals(other.name) && this.actions.equals(other.actions));
/*     */             }
/* 326 */             return this.name.equals(other.name);
/*     */           } 
/*     */           
/* 329 */           return true;
/*     */         } 
/*     */     
/*     */     
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 340 */     int h = 527 + this.type.hashCode();
/* 341 */     if (this.name != null) {
/* 342 */       h = 31 * h + this.name.hashCode();
/* 343 */       if (this.actions != null) {
/* 344 */         h = 31 * h + this.actions.hashCode();
/*     */       }
/*     */     } 
/* 347 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void escapeString(String str, StringBuilder output) {
/* 355 */     int len = str.length();
/* 356 */     for (int i = 0; i < len; i++) {
/* 357 */       char c = str.charAt(i);
/* 358 */       switch (c) {
/*     */         case '"':
/*     */         case '\\':
/* 361 */           output.append('\\');
/* 362 */           output.append(c);
/*     */           break;
/*     */         case '\r':
/* 365 */           output.append("\\r");
/*     */           break;
/*     */         case '\n':
/* 368 */           output.append("\\n");
/*     */           break;
/*     */         default:
/* 371 */           output.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String unescapeString(char[] str, int begin, int end) {
/* 381 */     StringBuilder output = new StringBuilder(end - begin);
/* 382 */     for (int i = begin; i < end; i++) {
/* 383 */       char c = str[i];
/*     */       
/* 385 */       i++;
/* 386 */       if (c == '\\' && i < end) {
/* 387 */         c = str[i];
/* 388 */         switch (c) {
/*     */           case '"':
/*     */           case '\\':
/*     */             break;
/*     */           case 'r':
/* 393 */             c = '\r';
/*     */             break;
/*     */           case 'n':
/* 396 */             c = '\n';
/*     */             break;
/*     */           default:
/* 399 */             c = '\\';
/* 400 */             i--;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 405 */       output.append(c);
/*     */     } 
/*     */     
/* 408 */     return output.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\permissionadmin\PermissionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */