package org.osgi.service.packageadmin;

import org.osgi.framework.Bundle;

public interface PackageAdmin {
  public static final int BUNDLE_TYPE_FRAGMENT = 1;
  
  ExportedPackage[] getExportedPackages(Bundle paramBundle);
  
  ExportedPackage[] getExportedPackages(String paramString);
  
  ExportedPackage getExportedPackage(String paramString);
  
  void refreshPackages(Bundle[] paramArrayOfBundle);
  
  boolean resolveBundles(Bundle[] paramArrayOfBundle);
  
  RequiredBundle[] getRequiredBundles(String paramString);
  
  Bundle[] getBundles(String paramString1, String paramString2);
  
  Bundle[] getFragments(Bundle paramBundle);
  
  Bundle[] getHosts(Bundle paramBundle);
  
  Bundle getBundle(Class<?> paramClass);
  
  int getBundleType(Bundle paramBundle);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\packageadmin\PackageAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */