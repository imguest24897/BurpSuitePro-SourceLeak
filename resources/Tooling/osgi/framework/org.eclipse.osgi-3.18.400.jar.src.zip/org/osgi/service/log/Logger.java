package org.osgi.service.log;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface Logger {
  public static final String ROOT_LOGGER_NAME = "ROOT";
  
  String getName();
  
  boolean isTraceEnabled();
  
  void trace(String paramString);
  
  void trace(String paramString, Object paramObject);
  
  void trace(String paramString, Object paramObject1, Object paramObject2);
  
  void trace(String paramString, Object... paramVarArgs);
  
  <E extends Exception> void trace(LoggerConsumer<E> paramLoggerConsumer) throws E;
  
  boolean isDebugEnabled();
  
  void debug(String paramString);
  
  void debug(String paramString, Object paramObject);
  
  void debug(String paramString, Object paramObject1, Object paramObject2);
  
  void debug(String paramString, Object... paramVarArgs);
  
  <E extends Exception> void debug(LoggerConsumer<E> paramLoggerConsumer) throws E;
  
  boolean isInfoEnabled();
  
  void info(String paramString);
  
  void info(String paramString, Object paramObject);
  
  void info(String paramString, Object paramObject1, Object paramObject2);
  
  void info(String paramString, Object... paramVarArgs);
  
  <E extends Exception> void info(LoggerConsumer<E> paramLoggerConsumer) throws E;
  
  boolean isWarnEnabled();
  
  void warn(String paramString);
  
  void warn(String paramString, Object paramObject);
  
  void warn(String paramString, Object paramObject1, Object paramObject2);
  
  void warn(String paramString, Object... paramVarArgs);
  
  <E extends Exception> void warn(LoggerConsumer<E> paramLoggerConsumer) throws E;
  
  boolean isErrorEnabled();
  
  void error(String paramString);
  
  void error(String paramString, Object paramObject);
  
  void error(String paramString, Object paramObject1, Object paramObject2);
  
  void error(String paramString, Object... paramVarArgs);
  
  <E extends Exception> void error(LoggerConsumer<E> paramLoggerConsumer) throws E;
  
  void audit(String paramString);
  
  void audit(String paramString, Object paramObject);
  
  void audit(String paramString, Object paramObject1, Object paramObject2);
  
  void audit(String paramString, Object... paramVarArgs);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\log\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */