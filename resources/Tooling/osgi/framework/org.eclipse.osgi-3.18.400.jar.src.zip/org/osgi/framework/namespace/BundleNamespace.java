package org.osgi.framework.namespace;

public final class BundleNamespace extends AbstractWiringNamespace {
  public static final String BUNDLE_NAMESPACE = "osgi.wiring.bundle";
  
  public static final String CAPABILITY_SINGLETON_DIRECTIVE = "singleton";
  
  public static final String CAPABILITY_FRAGMENT_ATTACHMENT_DIRECTIVE = "fragment-attachment";
  
  public static final String REQUIREMENT_EXTENSION_DIRECTIVE = "extension";
  
  public static final String REQUIREMENT_VISIBILITY_DIRECTIVE = "visibility";
  
  public static final String VISIBILITY_PRIVATE = "private";
  
  public static final String VISIBILITY_REEXPORT = "reexport";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\namespace\BundleNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */