package org.osgi.framework;

import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.Dictionary;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface BundleContext extends BundleReference {
  String getProperty(String paramString);
  
  Bundle getBundle();
  
  Bundle installBundle(String paramString, InputStream paramInputStream) throws BundleException;
  
  Bundle installBundle(String paramString) throws BundleException;
  
  Bundle getBundle(long paramLong);
  
  Bundle[] getBundles();
  
  void addServiceListener(ServiceListener paramServiceListener, String paramString) throws InvalidSyntaxException;
  
  void addServiceListener(ServiceListener paramServiceListener);
  
  void removeServiceListener(ServiceListener paramServiceListener);
  
  void addBundleListener(BundleListener paramBundleListener);
  
  void removeBundleListener(BundleListener paramBundleListener);
  
  void addFrameworkListener(FrameworkListener paramFrameworkListener);
  
  void removeFrameworkListener(FrameworkListener paramFrameworkListener);
  
  ServiceRegistration<?> registerService(String[] paramArrayOfString, Object paramObject, Dictionary<String, ?> paramDictionary);
  
  ServiceRegistration<?> registerService(String paramString, Object paramObject, Dictionary<String, ?> paramDictionary);
  
  <S> ServiceRegistration<S> registerService(Class<S> paramClass, S paramS, Dictionary<String, ?> paramDictionary);
  
  <S> ServiceRegistration<S> registerService(Class<S> paramClass, ServiceFactory<S> paramServiceFactory, Dictionary<String, ?> paramDictionary);
  
  ServiceReference<?>[] getServiceReferences(String paramString1, String paramString2) throws InvalidSyntaxException;
  
  ServiceReference<?>[] getAllServiceReferences(String paramString1, String paramString2) throws InvalidSyntaxException;
  
  ServiceReference<?> getServiceReference(String paramString);
  
  <S> ServiceReference<S> getServiceReference(Class<S> paramClass);
  
  <S> Collection<ServiceReference<S>> getServiceReferences(Class<S> paramClass, String paramString) throws InvalidSyntaxException;
  
  <S> S getService(ServiceReference<S> paramServiceReference);
  
  boolean ungetService(ServiceReference<?> paramServiceReference);
  
  <S> ServiceObjects<S> getServiceObjects(ServiceReference<S> paramServiceReference);
  
  File getDataFile(String paramString);
  
  Filter createFilter(String paramString) throws InvalidSyntaxException;
  
  Bundle getBundle(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\BundleContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */