/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdaptPermission
/*     */   extends BasicPermission
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String ADAPT = "adapt";
/*     */   private static final int ACTION_ADAPT = 1;
/*     */   private static final int ACTION_ALL = 1;
/*     */   static final int ACTION_NONE = 0;
/*     */   transient int action_mask;
/*  69 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient Bundle bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile transient Map<String, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdaptPermission(String filter, String actions) {
/* 127 */     this(parseFilter(filter), parseActions(actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdaptPermission(String adaptClass, Bundle adaptableBundle, String actions) {
/* 142 */     super(adaptClass);
/* 143 */     setTransients(null, parseActions(actions));
/* 144 */     this.bundle = adaptableBundle;
/* 145 */     if (adaptClass == null) {
/* 146 */       throw new NullPointerException("adaptClass must not be null");
/*     */     }
/* 148 */     if (adaptableBundle == null) {
/* 149 */       throw new NullPointerException("adaptableBundle must not be null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AdaptPermission(Filter filter, int mask) {
/* 160 */     super((filter == null) ? "*" : filter.toString());
/* 161 */     setTransients(filter, mask);
/* 162 */     this.bundle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTransients(Filter filter, int mask) {
/* 172 */     this.filter = filter;
/* 173 */     if (mask == 0 || (mask & 0x1) != mask) {
/* 174 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/* 176 */     this.action_mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 186 */     boolean seencomma = false;
/*     */     
/* 188 */     int mask = 0;
/*     */     
/* 190 */     if (actions == null) {
/* 191 */       return mask;
/*     */     }
/*     */     
/* 194 */     char[] a = actions.toCharArray();
/*     */     
/* 196 */     int i = a.length - 1;
/* 197 */     if (i < 0) {
/* 198 */       return mask;
/*     */     }
/* 200 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 204 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 205 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 210 */       if (i >= 4 && (a[i - 4] == 'a' || a[i - 4] == 'A') && (
/* 211 */         a[i - 3] == 'd' || a[i - 3] == 'D') && (
/* 212 */         a[i - 2] == 'a' || a[i - 2] == 'A') && (
/* 213 */         a[i - 1] == 'p' || a[i - 1] == 'P') && (
/* 214 */         a[i] == 't' || a[i] == 'T')) {
/* 215 */         matchlen = 5;
/* 216 */         mask |= 0x1;
/*     */       }
/*     */       else {
/*     */         
/* 220 */         throw new IllegalArgumentException("invalid actions: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 225 */       seencomma = false;
/* 226 */       while (i >= matchlen && !seencomma) {
/* 227 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 229 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 238 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 240 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 244 */       i -= matchlen;
/*     */     } 
/*     */     
/* 247 */     if (seencomma) {
/* 248 */       throw new IllegalArgumentException("invalid actions: " + actions);
/*     */     }
/*     */     
/* 251 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter parseFilter(String filterString) {
/* 262 */     filterString = filterString.trim();
/* 263 */     if (filterString.equals("*")) {
/* 264 */       return null;
/*     */     }
/*     */     try {
/* 267 */       return FrameworkUtil.createFilter(filterString);
/* 268 */     } catch (InvalidSyntaxException e) {
/* 269 */       throw new IllegalArgumentException("invalid filter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 289 */     if (!(p instanceof AdaptPermission)) {
/* 290 */       return false;
/*     */     }
/* 292 */     AdaptPermission requested = (AdaptPermission)p;
/* 293 */     if (this.bundle != null) {
/* 294 */       return false;
/*     */     }
/*     */     
/* 297 */     if (requested.filter != null) {
/* 298 */       return false;
/*     */     }
/* 300 */     return implies0(requested, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean implies0(AdaptPermission requested, int effective) {
/* 316 */     effective |= this.action_mask;
/* 317 */     int desired = requested.action_mask;
/* 318 */     if ((effective & desired) != desired) {
/* 319 */       return false;
/*     */     }
/*     */     
/* 322 */     Filter f = this.filter;
/* 323 */     if (f == null)
/*     */     {
/* 325 */       return true;
/*     */     }
/* 327 */     return f.matches(requested.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 343 */     String result = this.actions;
/* 344 */     if (result == null) {
/* 345 */       this.actions = result = "adapt";
/*     */     }
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 358 */     return new AdaptPermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 375 */     if (obj == this) {
/* 376 */       return true;
/*     */     }
/*     */     
/* 379 */     if (!(obj instanceof AdaptPermission)) {
/* 380 */       return false;
/*     */     }
/*     */     
/* 383 */     AdaptPermission cp = (AdaptPermission)obj;
/*     */     
/* 385 */     return (this.action_mask == cp.action_mask && getName().equals(cp.getName()) && (this.bundle == cp.bundle || (this.bundle != null && this.bundle.equals(cp.bundle))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 395 */     int h = 527 + getName().hashCode();
/* 396 */     h = 31 * h + getActions().hashCode();
/* 397 */     if (this.bundle != null) {
/* 398 */       h = 31 * h + this.bundle.hashCode();
/*     */     }
/* 400 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 409 */     if (this.bundle != null) {
/* 410 */       throw new NotSerializableException("cannot serialize");
/*     */     }
/*     */ 
/*     */     
/* 414 */     if (this.actions == null)
/* 415 */       getActions(); 
/* 416 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 425 */     s.defaultReadObject();
/* 426 */     setTransients(parseFilter(getName()), parseActions(this.actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getProperties() {
/* 436 */     Map<String, Object> result = this.properties;
/* 437 */     if (result != null) {
/* 438 */       return result;
/*     */     }
/* 440 */     final Map<String, Object> map = new HashMap<>(5);
/* 441 */     map.put("adaptClass", getName());
/* 442 */     if (this.bundle != null) {
/* 443 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 446 */               map.put("id", Long.valueOf(AdaptPermission.this.bundle.getBundleId()));
/* 447 */               map.put("location", AdaptPermission.this.bundle.getLocation());
/* 448 */               String name = AdaptPermission.this.bundle.getSymbolicName();
/* 449 */               if (name != null) {
/* 450 */                 map.put("name", name);
/*     */               }
/* 452 */               SignerProperty signer = new SignerProperty(AdaptPermission.this.bundle);
/* 453 */               if (signer.isBundleSigned()) {
/* 454 */                 map.put("signer", signer);
/*     */               }
/* 456 */               return null;
/*     */             }
/*     */           });
/*     */     }
/* 460 */     return this.properties = map;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\AdaptPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */