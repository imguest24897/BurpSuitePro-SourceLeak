/*     */ package org.osgi.framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceException
/*     */   extends RuntimeException
/*     */ {
/*     */   static final long serialVersionUID = 3038963223712959631L;
/*     */   private final int type;
/*     */   public static final int UNSPECIFIED = 0;
/*     */   public static final int UNREGISTERED = 1;
/*     */   public static final int FACTORY_ERROR = 2;
/*     */   public static final int FACTORY_EXCEPTION = 3;
/*     */   public static final int SUBCLASSED = 4;
/*     */   public static final int REMOTE = 5;
/*     */   public static final int FACTORY_RECURSION = 6;
/*     */   public static final int ASYNC_ERROR = 7;
/*     */   
/*     */   public ServiceException(String msg, Throwable cause) {
/*  92 */     this(msg, 0, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceException(String msg) {
/* 101 */     this(msg, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceException(String msg, int type, Throwable cause) {
/* 113 */     super(msg, cause);
/* 114 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceException(String msg, int type) {
/* 124 */     super(msg);
/* 125 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 135 */     return this.type;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\ServiceException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */