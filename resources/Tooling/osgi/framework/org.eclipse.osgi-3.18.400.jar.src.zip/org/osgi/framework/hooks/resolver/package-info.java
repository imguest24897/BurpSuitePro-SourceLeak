package org.osgi.framework.hooks.resolver;

import org.osgi.annotation.versioning.Version;



/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\resolver\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */