/*     */ package org.osgi.framework.connect;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.osgi.annotation.versioning.ConsumerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConsumerType
/*     */ public interface ConnectContent
/*     */ {
/*     */   public static final String TAG_OSGI_CONNECT = "osgi.connect";
/*     */   
/*     */   Optional<Map<String, String>> getHeaders();
/*     */   
/*     */   Iterable<String> getEntries() throws IOException;
/*     */   
/*     */   Optional<ConnectEntry> getEntry(String paramString);
/*     */   
/*     */   Optional<ClassLoader> getClassLoader();
/*     */   
/*     */   void open() throws IOException;
/*     */   
/*     */   void close() throws IOException;
/*     */   
/*     */   @ConsumerType
/*     */   public static interface ConnectEntry
/*     */   {
/*     */     String getName();
/*     */     
/*     */     long getContentLength();
/*     */     
/*     */     long getLastModified();
/*     */     
/*     */     default byte[] getBytes() throws IOException {
/* 176 */       long longLength = getContentLength();
/* 177 */       if (longLength > 2147483639L) {
/* 178 */         throw new IOException(
/* 179 */             "Entry is to big to fit into a byte[]: " + getName());
/*     */       }
/*     */       
/* 182 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */       
/*     */       } finally {
/* 207 */         exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */       
/*     */       } 
/*     */     }
/*     */     
/*     */     InputStream getInputStream() throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\connect\ConnectContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */