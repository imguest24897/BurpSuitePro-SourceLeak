/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CapabilityPermission
/*     */   extends BasicPermission
/*     */ {
/*     */   static final long serialVersionUID = -7662148639076511574L;
/*     */   public static final String REQUIRE = "require";
/*     */   public static final String PROVIDE = "provide";
/*     */   private static final int ACTION_REQUIRE = 1;
/*     */   private static final int ACTION_PROVIDE = 2;
/*     */   private static final int ACTION_ALL = 3;
/*     */   static final int ACTION_NONE = 0;
/*     */   transient int action_mask;
/*  80 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient Map<String, Object> attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient Bundle bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile transient Map<String, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CapabilityPermission(String name, String actions) {
/* 157 */     this(name, parseActions(actions));
/* 158 */     if (this.filter != null && (this.action_mask & 0x3) != 1) {
/* 159 */       throw new IllegalArgumentException("invalid action string for filter expression");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CapabilityPermission(String namespace, Map<String, ?> attributes, Bundle providingBundle, String actions) {
/* 179 */     super(namespace);
/* 180 */     setTransients(namespace, parseActions(actions));
/* 181 */     if (attributes == null) {
/* 182 */       throw new IllegalArgumentException("attributes must not be null");
/*     */     }
/* 184 */     if (providingBundle == null) {
/* 185 */       throw new IllegalArgumentException("bundle must not be null");
/*     */     }
/* 187 */     this.attributes = new HashMap<>(attributes);
/* 188 */     this.bundle = providingBundle;
/* 189 */     if ((this.action_mask & 0x3) != 1) {
/* 190 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CapabilityPermission(String name, int mask) {
/* 201 */     super(name);
/* 202 */     setTransients(name, mask);
/* 203 */     this.attributes = null;
/* 204 */     this.bundle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTransients(String name, int mask) {
/* 213 */     if (mask == 0 || (mask & 0x3) != mask) {
/* 214 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/* 216 */     this.action_mask = mask;
/* 217 */     this.filter = parseFilter(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 227 */     boolean seencomma = false;
/*     */     
/* 229 */     int mask = 0;
/*     */     
/* 231 */     if (actions == null) {
/* 232 */       return mask;
/*     */     }
/*     */     
/* 235 */     char[] a = actions.toCharArray();
/*     */     
/* 237 */     int i = a.length - 1;
/* 238 */     if (i < 0) {
/* 239 */       return mask;
/*     */     }
/* 241 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 245 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 246 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 251 */       if (i >= 6 && (a[i - 6] == 'r' || a[i - 6] == 'R') && (
/* 252 */         a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 253 */         a[i - 4] == 'q' || a[i - 4] == 'Q') && (
/* 254 */         a[i - 3] == 'u' || a[i - 3] == 'U') && (
/* 255 */         a[i - 2] == 'i' || a[i - 2] == 'I') && (
/* 256 */         a[i - 1] == 'r' || a[i - 1] == 'R') && (
/* 257 */         a[i] == 'e' || a[i] == 'E')) {
/* 258 */         matchlen = 7;
/* 259 */         mask |= 0x1;
/*     */       }
/* 261 */       else if (i >= 6 && (a[i - 6] == 'p' || a[i - 6] == 'P') && (
/* 262 */         a[i - 5] == 'r' || a[i - 5] == 'R') && (
/* 263 */         a[i - 4] == 'o' || a[i - 4] == 'O') && (
/* 264 */         a[i - 3] == 'v' || a[i - 3] == 'V') && (
/* 265 */         a[i - 2] == 'i' || a[i - 2] == 'I') && (
/* 266 */         a[i - 1] == 'd' || a[i - 1] == 'D') && (
/* 267 */         a[i] == 'e' || a[i] == 'E')) {
/* 268 */         matchlen = 7;
/* 269 */         mask |= 0x2;
/*     */       } else {
/*     */         
/* 272 */         throw new IllegalArgumentException("invalid permission: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 277 */       seencomma = false;
/* 278 */       while (i >= matchlen && !seencomma) {
/* 279 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 281 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 290 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 292 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 296 */       i -= matchlen;
/*     */     } 
/*     */     
/* 299 */     if (seencomma) {
/* 300 */       throw new IllegalArgumentException("invalid permission: " + actions);
/*     */     }
/*     */     
/* 303 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter parseFilter(String filterString) {
/* 315 */     filterString = filterString.trim();
/* 316 */     if (filterString.charAt(0) != '(') {
/* 317 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 321 */       return FrameworkUtil.createFilter(filterString);
/* 322 */     } catch (InvalidSyntaxException e) {
/* 323 */       throw new IllegalArgumentException("invalid filter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 337 */     if (!(p instanceof CapabilityPermission)) {
/* 338 */       return false;
/*     */     }
/* 340 */     CapabilityPermission requested = (CapabilityPermission)p;
/* 341 */     if (this.bundle != null) {
/* 342 */       return false;
/*     */     }
/*     */     
/* 345 */     if (requested.filter != null) {
/* 346 */       return false;
/*     */     }
/* 348 */     return implies0(requested, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean implies0(CapabilityPermission requested, int effective) {
/* 364 */     effective |= this.action_mask;
/* 365 */     int desired = requested.action_mask;
/* 366 */     if ((effective & desired) != desired) {
/* 367 */       return false;
/*     */     }
/*     */     
/* 370 */     Filter f = this.filter;
/* 371 */     if (f == null) {
/* 372 */       return super.implies(requested);
/*     */     }
/* 374 */     return f.matches(requested.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 386 */     String result = this.actions;
/* 387 */     if (result == null) {
/* 388 */       StringBuilder sb = new StringBuilder();
/* 389 */       boolean comma = false;
/*     */       
/* 391 */       int mask = this.action_mask;
/* 392 */       if ((mask & 0x1) == 1) {
/* 393 */         sb.append("require");
/* 394 */         comma = true;
/*     */       } 
/*     */       
/* 397 */       if ((mask & 0x2) == 2) {
/* 398 */         if (comma)
/* 399 */           sb.append(','); 
/* 400 */         sb.append("provide");
/*     */       } 
/*     */       
/* 403 */       this.actions = result = sb.toString();
/*     */     } 
/*     */     
/* 406 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 418 */     return new CapabilityPermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 434 */     if (obj == this) {
/* 435 */       return true;
/*     */     }
/*     */     
/* 438 */     if (!(obj instanceof CapabilityPermission)) {
/* 439 */       return false;
/*     */     }
/*     */     
/* 442 */     CapabilityPermission cp = (CapabilityPermission)obj;
/*     */     
/* 444 */     return (this.action_mask == cp.action_mask && getName().equals(cp.getName()) && (this.attributes == cp.attributes || (this.attributes != null && this.attributes.equals(cp.attributes))) && (
/* 445 */       this.bundle == cp.bundle || (this.bundle != null && this.bundle.equals(cp.bundle))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 455 */     int h = 527 + getName().hashCode();
/* 456 */     h = 31 * h + getActions().hashCode();
/* 457 */     if (this.attributes != null) {
/* 458 */       h = 31 * h + this.attributes.hashCode();
/*     */     }
/* 460 */     if (this.bundle != null) {
/* 461 */       h = 31 * h + this.bundle.hashCode();
/*     */     }
/* 463 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 471 */     if (this.bundle != null) {
/* 472 */       throw new NotSerializableException("cannot serialize");
/*     */     }
/*     */ 
/*     */     
/* 476 */     if (this.actions == null)
/* 477 */       getActions(); 
/* 478 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 487 */     s.defaultReadObject();
/* 488 */     setTransients(getName(), parseActions(this.actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getProperties() {
/* 498 */     Map<String, Object> result = this.properties;
/* 499 */     if (result != null) {
/* 500 */       return result;
/*     */     }
/* 502 */     final Map<String, Object> props = new HashMap<>(5);
/* 503 */     props.put("capability.namespace", getName());
/* 504 */     if (this.bundle == null) {
/* 505 */       return this.properties = props;
/*     */     }
/* 507 */     AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */         {
/*     */           public Void run() {
/* 510 */             props.put("id", Long.valueOf(CapabilityPermission.this.bundle.getBundleId()));
/* 511 */             props.put("location", CapabilityPermission.this.bundle.getLocation());
/* 512 */             String name = CapabilityPermission.this.bundle.getSymbolicName();
/* 513 */             if (name != null) {
/* 514 */               props.put("name", name);
/*     */             }
/* 516 */             SignerProperty signer = new SignerProperty(CapabilityPermission.this.bundle);
/* 517 */             if (signer.isBundleSigned()) {
/* 518 */               props.put("signer", signer);
/*     */             }
/* 520 */             return null;
/*     */           }
/*     */         });
/* 523 */     return this.properties = new Properties(props, this.attributes);
/*     */   }
/*     */   
/*     */   private static final class Properties extends AbstractMap<String, Object> {
/*     */     private final Map<String, Object> properties;
/*     */     private final Map<String, Object> attributes;
/*     */     private volatile transient Set<Map.Entry<String, Object>> entries;
/*     */     
/*     */     Properties(Map<String, Object> properties, Map<String, Object> attributes) {
/* 532 */       this.properties = properties;
/* 533 */       this.attributes = attributes;
/* 534 */       this.entries = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(Object k) {
/* 539 */       if (!(k instanceof String)) {
/* 540 */         return null;
/*     */       }
/* 542 */       String key = (String)k;
/* 543 */       if (key.charAt(0) == '@') {
/* 544 */         return this.attributes.get(key.substring(1));
/*     */       }
/* 546 */       Object value = this.properties.get(key);
/* 547 */       if (value != null) {
/* 548 */         return value;
/*     */       }
/* 550 */       return this.attributes.get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet() {
/* 555 */       if (this.entries != null) {
/* 556 */         return this.entries;
/*     */       }
/* 558 */       Set<Map.Entry<String, Object>> all = new HashSet<>(this.attributes.size() + this.properties.size());
/* 559 */       all.addAll(this.attributes.entrySet());
/* 560 */       all.addAll(this.properties.entrySet());
/* 561 */       return this.entries = Collections.unmodifiableSet(all);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\CapabilityPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */