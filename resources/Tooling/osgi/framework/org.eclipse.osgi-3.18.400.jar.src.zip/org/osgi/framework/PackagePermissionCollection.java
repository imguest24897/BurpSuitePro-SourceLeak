/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PackagePermissionCollection
/*     */   extends PermissionCollection
/*     */ {
/*     */   static final long serialVersionUID = -3350758995234427603L;
/* 602 */   private transient Map<String, PackagePermission> permissions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean all_allowed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, PackagePermission> filterPermissions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Permission permission) {
/* 618 */     if (!(permission instanceof PackagePermission)) {
/* 619 */       throw new IllegalArgumentException("invalid permission: " + permission);
/*     */     }
/* 621 */     if (isReadOnly()) {
/* 622 */       throw new SecurityException("attempt to add a Permission to a readonly PermissionCollection");
/*     */     }
/*     */     
/* 625 */     PackagePermission pp = (PackagePermission)permission;
/* 626 */     if (pp.bundle != null) {
/* 627 */       throw new IllegalArgumentException("cannot add to collection: " + pp);
/*     */     }
/*     */     
/* 630 */     String name = pp.getName();
/* 631 */     Filter f = pp.filter;
/* 632 */     synchronized (this) {
/*     */       Map<String, PackagePermission> pc;
/*     */       
/* 635 */       if (f != null) {
/* 636 */         pc = this.filterPermissions;
/* 637 */         if (pc == null) {
/* 638 */           this.filterPermissions = pc = new HashMap<>();
/*     */         }
/*     */       } else {
/* 641 */         pc = this.permissions;
/*     */       } 
/*     */       
/* 644 */       PackagePermission existing = pc.get(name);
/* 645 */       if (existing != null) {
/* 646 */         int oldMask = existing.action_mask;
/* 647 */         int newMask = pp.action_mask;
/* 648 */         if (oldMask != newMask) {
/* 649 */           pc.put(name, new PackagePermission(name, oldMask | newMask));
/*     */         }
/*     */       } else {
/*     */         
/* 653 */         pc.put(name, pp);
/*     */       } 
/*     */       
/* 656 */       if (!this.all_allowed && 
/* 657 */         name.equals("*")) {
/* 658 */         this.all_allowed = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission permission) {
/*     */     Collection<PackagePermission> perms;
/* 675 */     if (!(permission instanceof PackagePermission)) {
/* 676 */       return false;
/*     */     }
/* 678 */     PackagePermission requested = (PackagePermission)permission;
/*     */     
/* 680 */     if (requested.filter != null) {
/* 681 */       return false;
/*     */     }
/* 683 */     String requestedName = requested.getName();
/* 684 */     int desired = requested.action_mask;
/* 685 */     int effective = 0;
/*     */ 
/*     */     
/* 688 */     synchronized (this) {
/* 689 */       Map<String, PackagePermission> pc = this.permissions;
/*     */ 
/*     */       
/* 692 */       if (this.all_allowed) {
/* 693 */         PackagePermission packagePermission = pc.get("*");
/* 694 */         if (packagePermission != null) {
/* 695 */           effective |= packagePermission.action_mask;
/* 696 */           if ((effective & desired) == desired) {
/* 697 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 705 */       PackagePermission pp = pc.get(requestedName);
/* 706 */       if (pp != null) {
/*     */         
/* 708 */         effective |= pp.action_mask;
/* 709 */         if ((effective & desired) == desired) {
/* 710 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 715 */       int offset = requestedName.length() - 1; int last;
/* 716 */       while ((last = requestedName.lastIndexOf('.', offset)) != -1) {
/* 717 */         requestedName = String.valueOf(requestedName.substring(0, last + 1)) + "*";
/* 718 */         pp = pc.get(requestedName);
/* 719 */         if (pp != null) {
/* 720 */           effective |= pp.action_mask;
/* 721 */           if ((effective & desired) == desired) {
/* 722 */             return true;
/*     */           }
/*     */         } 
/* 725 */         offset = last - 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 731 */       pc = this.filterPermissions;
/* 732 */       if (pc == null) {
/* 733 */         return false;
/*     */       }
/* 735 */       perms = pc.values();
/*     */     } 
/*     */     
/* 738 */     for (PackagePermission perm : perms) {
/* 739 */       if (perm.implies0(requested, effective)) {
/* 740 */         return true;
/*     */       }
/*     */     } 
/* 743 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<Permission> elements() {
/* 754 */     List<Permission> all = new ArrayList<>(this.permissions.values());
/* 755 */     Map<String, PackagePermission> pc = this.filterPermissions;
/* 756 */     if (pc != null) {
/* 757 */       all.addAll(pc.values());
/*     */     }
/* 759 */     return Collections.enumeration(all);
/*     */   }
/*     */ 
/*     */   
/* 763 */   private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { new ObjectStreamField("permissions", Hashtable.class), new ObjectStreamField("all_allowed", boolean.class), 
/* 764 */       new ObjectStreamField("filterPermissions", HashMap.class) };
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream out) throws IOException {
/* 767 */     Hashtable<String, PackagePermission> hashtable = new Hashtable<>(this.permissions);
/* 768 */     ObjectOutputStream.PutField pfields = out.putFields();
/* 769 */     pfields.put("permissions", hashtable);
/* 770 */     pfields.put("all_allowed", this.all_allowed);
/* 771 */     pfields.put("filterPermissions", this.filterPermissions);
/* 772 */     out.writeFields();
/*     */   }
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 776 */     ObjectInputStream.GetField gfields = in.readFields();
/*     */     
/* 778 */     Hashtable<String, PackagePermission> hashtable = (Hashtable<String, PackagePermission>)gfields.get("permissions", (Object)null);
/* 779 */     this.permissions = new HashMap<>(hashtable);
/* 780 */     this.all_allowed = gfields.get("all_allowed", false);
/*     */     
/* 782 */     HashMap<String, PackagePermission> fp = (HashMap<String, PackagePermission>)gfields.get("filterPermissions", (Object)null);
/* 783 */     this.filterPermissions = fp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\PackagePermissionCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */