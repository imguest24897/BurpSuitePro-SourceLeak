package org.osgi.framework.hooks.weaving;

import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface WovenClassListener {
  void modified(WovenClass paramWovenClass);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\weaving\WovenClassListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */