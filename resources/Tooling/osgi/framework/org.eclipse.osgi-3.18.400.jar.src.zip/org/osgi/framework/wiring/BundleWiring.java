package org.osgi.framework.wiring;

import java.net.URL;
import java.util.Collection;
import java.util.List;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.BundleReference;
import org.osgi.resource.Capability;
import org.osgi.resource.Requirement;
import org.osgi.resource.Resource;
import org.osgi.resource.Wire;
import org.osgi.resource.Wiring;

@ProviderType
public interface BundleWiring extends BundleReference, Wiring {
  public static final int FINDENTRIES_RECURSE = 1;
  
  public static final int LISTRESOURCES_RECURSE = 1;
  
  public static final int LISTRESOURCES_LOCAL = 2;
  
  boolean isCurrent();
  
  boolean isInUse();
  
  List<BundleCapability> getCapabilities(String paramString);
  
  List<BundleRequirement> getRequirements(String paramString);
  
  List<BundleWire> getProvidedWires(String paramString);
  
  List<BundleWire> getRequiredWires(String paramString);
  
  BundleRevision getRevision();
  
  ClassLoader getClassLoader();
  
  List<URL> findEntries(String paramString1, String paramString2, int paramInt);
  
  Collection<String> listResources(String paramString1, String paramString2, int paramInt);
  
  List<Capability> getResourceCapabilities(String paramString);
  
  List<Requirement> getResourceRequirements(String paramString);
  
  List<Wire> getProvidedResourceWires(String paramString);
  
  List<Wire> getRequiredResourceWires(String paramString);
  
  BundleRevision getResource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\BundleWiring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */