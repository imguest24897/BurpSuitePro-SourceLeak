package org.osgi.framework.wiring;

import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.resource.Requirement;
import org.osgi.resource.Resource;

@ProviderType
public interface BundleRequirement extends Requirement {
  BundleRevision getRevision();
  
  boolean matches(BundleCapability paramBundleCapability);
  
  String getNamespace();
  
  Map<String, String> getDirectives();
  
  Map<String, Object> getAttributes();
  
  BundleRevision getResource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\BundleRequirement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */