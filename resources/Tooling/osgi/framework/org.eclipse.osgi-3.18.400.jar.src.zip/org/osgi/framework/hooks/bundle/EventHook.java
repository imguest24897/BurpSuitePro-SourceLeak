package org.osgi.framework.hooks.bundle;

import java.util.Collection;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;

@ConsumerType
public interface EventHook {
  void event(BundleEvent paramBundleEvent, Collection<BundleContext> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\bundle\EventHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */