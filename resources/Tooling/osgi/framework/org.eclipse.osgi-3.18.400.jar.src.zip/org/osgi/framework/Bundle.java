package org.osgi.framework;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface Bundle extends Comparable<Bundle> {
  public static final int UNINSTALLED = 1;
  
  public static final int INSTALLED = 2;
  
  public static final int RESOLVED = 4;
  
  public static final int STARTING = 8;
  
  public static final int STOPPING = 16;
  
  public static final int ACTIVE = 32;
  
  public static final int START_TRANSIENT = 1;
  
  public static final int START_ACTIVATION_POLICY = 2;
  
  public static final int STOP_TRANSIENT = 1;
  
  public static final int SIGNERS_ALL = 1;
  
  public static final int SIGNERS_TRUSTED = 2;
  
  int getState();
  
  void start(int paramInt) throws BundleException;
  
  void start() throws BundleException;
  
  void stop(int paramInt) throws BundleException;
  
  void stop() throws BundleException;
  
  void update(InputStream paramInputStream) throws BundleException;
  
  void update() throws BundleException;
  
  void uninstall() throws BundleException;
  
  Dictionary<String, String> getHeaders();
  
  long getBundleId();
  
  String getLocation();
  
  ServiceReference<?>[] getRegisteredServices();
  
  ServiceReference<?>[] getServicesInUse();
  
  boolean hasPermission(Object paramObject);
  
  URL getResource(String paramString);
  
  Dictionary<String, String> getHeaders(String paramString);
  
  String getSymbolicName();
  
  Class<?> loadClass(String paramString) throws ClassNotFoundException;
  
  Enumeration<URL> getResources(String paramString) throws IOException;
  
  Enumeration<String> getEntryPaths(String paramString);
  
  URL getEntry(String paramString);
  
  long getLastModified();
  
  Enumeration<URL> findEntries(String paramString1, String paramString2, boolean paramBoolean);
  
  BundleContext getBundleContext();
  
  Map<X509Certificate, List<X509Certificate>> getSignerCertificates(int paramInt);
  
  Version getVersion();
  
  <A> A adapt(Class<A> paramClass);
  
  File getDataFile(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\Bundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */