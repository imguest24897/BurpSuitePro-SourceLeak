package org.osgi.framework;

import java.util.Dictionary;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ServiceReference<S> extends Comparable<Object>, BundleReference {
  Object getProperty(String paramString);
  
  String[] getPropertyKeys();
  
  Bundle getBundle();
  
  Bundle[] getUsingBundles();
  
  boolean isAssignableTo(Bundle paramBundle, String paramString);
  
  int compareTo(Object paramObject);
  
  Dictionary<String, Object> getProperties();
  
  <A> A adapt(Class<A> paramClass);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\ServiceReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */