package org.osgi.framework.namespace;

public final class PackageNamespace extends AbstractWiringNamespace {
  public static final String PACKAGE_NAMESPACE = "osgi.wiring.package";
  
  public static final String CAPABILITY_INCLUDE_DIRECTIVE = "include";
  
  public static final String CAPABILITY_EXCLUDE_DIRECTIVE = "exclude";
  
  public static final String CAPABILITY_VERSION_ATTRIBUTE = "version";
  
  public static final String CAPABILITY_BUNDLE_SYMBOLICNAME_ATTRIBUTE = "bundle-symbolic-name";
  
  public static final String RESOLUTION_DYNAMIC = "dynamic";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\namespace\PackageNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */