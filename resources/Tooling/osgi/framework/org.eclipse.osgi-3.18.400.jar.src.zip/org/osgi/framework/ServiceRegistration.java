package org.osgi.framework;

import java.util.Dictionary;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ServiceRegistration<S> {
  ServiceReference<S> getReference();
  
  void setProperties(Dictionary<String, ?> paramDictionary);
  
  void unregister();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\ServiceRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */