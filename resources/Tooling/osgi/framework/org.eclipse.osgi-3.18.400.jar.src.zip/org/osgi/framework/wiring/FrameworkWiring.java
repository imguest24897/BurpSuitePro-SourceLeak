package org.osgi.framework.wiring;

import java.util.Collection;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleReference;
import org.osgi.framework.FrameworkListener;
import org.osgi.resource.Requirement;

@ProviderType
public interface FrameworkWiring extends BundleReference {
  void refreshBundles(Collection<Bundle> paramCollection, FrameworkListener... paramVarArgs);
  
  boolean resolveBundles(Collection<Bundle> paramCollection);
  
  Collection<Bundle> getRemovalPendingBundles();
  
  Collection<Bundle> getDependencyClosure(Collection<Bundle> paramCollection);
  
  Collection<BundleCapability> findProviders(Requirement paramRequirement);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\FrameworkWiring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */