package org.osgi.framework.dto;

import java.util.List;
import java.util.Map;
import org.osgi.dto.DTO;

public class FrameworkDTO extends DTO {
  public List<BundleDTO> bundles;
  
  public Map<String, Object> properties;
  
  public List<ServiceReferenceDTO> services;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\dto\FrameworkDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */