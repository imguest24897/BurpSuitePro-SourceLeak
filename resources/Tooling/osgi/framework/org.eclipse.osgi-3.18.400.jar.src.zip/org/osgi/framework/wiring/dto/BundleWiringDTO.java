package org.osgi.framework.wiring.dto;

import java.util.Set;
import org.osgi.dto.DTO;
import org.osgi.resource.dto.WiringDTO;

public class BundleWiringDTO extends DTO {
  public long bundle;
  
  public int root;
  
  public Set<NodeDTO> nodes;
  
  public Set<BundleRevisionDTO> resources;
  
  public static class NodeDTO extends WiringDTO {
    public boolean inUse;
    
    public boolean current;
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\dto\BundleWiringDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */