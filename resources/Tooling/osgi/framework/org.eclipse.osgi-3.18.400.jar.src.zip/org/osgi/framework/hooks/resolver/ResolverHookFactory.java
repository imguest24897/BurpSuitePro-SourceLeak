package org.osgi.framework.hooks.resolver;

import java.util.Collection;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.wiring.BundleRevision;

@ConsumerType
public interface ResolverHookFactory {
  ResolverHook begin(Collection<BundleRevision> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\resolver\ResolverHookFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */