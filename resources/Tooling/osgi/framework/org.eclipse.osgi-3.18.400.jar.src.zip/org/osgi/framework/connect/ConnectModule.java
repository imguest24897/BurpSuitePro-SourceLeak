package org.osgi.framework.connect;

import java.io.IOException;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface ConnectModule {
  ConnectContent getContent() throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\connect\ConnectModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */