/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.resource.Wire;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WireImpl
/*     */   implements Wire
/*     */ {
/*     */   private final Resource m_requirer;
/*     */   private final Requirement m_req;
/*     */   private final Resource m_provider;
/*     */   private final Capability m_cap;
/*     */   
/*     */   public WireImpl(Resource requirer, Requirement req, Resource provider, Capability cap) {
/*  37 */     this.m_requirer = requirer;
/*  38 */     this.m_req = req;
/*  39 */     this.m_provider = provider;
/*  40 */     this.m_cap = cap;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getRequirer() {
/*  45 */     return this.m_requirer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Requirement getRequirement() {
/*  50 */     return this.m_req;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getProvider() {
/*  55 */     return this.m_provider;
/*     */   }
/*     */ 
/*     */   
/*     */   public Capability getCapability() {
/*  60 */     return this.m_cap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  66 */     return this.m_req + 
/*  67 */       " -> " + 
/*  68 */       "[" + this.m_provider + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  74 */     if (obj == null)
/*     */     {
/*  76 */       return false;
/*     */     }
/*  78 */     if (!(obj instanceof Wire))
/*     */     {
/*  80 */       return false;
/*     */     }
/*  82 */     Wire other = (Wire)obj;
/*  83 */     if (this.m_requirer != other.getRequirer() && (
/*  84 */       this.m_requirer == null || !this.m_requirer.equals(other.getRequirer())))
/*     */     {
/*  86 */       return false;
/*     */     }
/*  88 */     if (this.m_req != other.getRequirement() && (
/*  89 */       this.m_req == null || !this.m_req.equals(other.getRequirement())))
/*     */     {
/*  91 */       return false;
/*     */     }
/*  93 */     if (this.m_provider != other.getProvider() && (
/*  94 */       this.m_provider == null || !this.m_provider.equals(other.getProvider())))
/*     */     {
/*  96 */       return false;
/*     */     }
/*  98 */     if (this.m_cap != other.getCapability() && (
/*  99 */       this.m_cap == null || !this.m_cap.equals(other.getCapability())))
/*     */     {
/* 101 */       return false;
/*     */     }
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 109 */     int hash = 5;
/* 110 */     hash = 29 * hash + ((this.m_requirer != null) ? this.m_requirer.hashCode() : 0);
/* 111 */     hash = 29 * hash + ((this.m_req != null) ? this.m_req.hashCode() : 0);
/* 112 */     hash = 29 * hash + ((this.m_provider != null) ? this.m_provider.hashCode() : 0);
/* 113 */     hash = 29 * hash + ((this.m_cap != null) ? this.m_cap.hashCode() : 0);
/* 114 */     return hash;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\WireImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */