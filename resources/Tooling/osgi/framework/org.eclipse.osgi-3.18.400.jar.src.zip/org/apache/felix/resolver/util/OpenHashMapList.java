/*    */ package org.apache.felix.resolver.util;
/*    */ 
/*    */ import org.osgi.resource.Requirement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenHashMapList
/*    */   extends OpenHashMap<Requirement, CandidateSelector>
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */   
/*    */   public OpenHashMapList() {}
/*    */   
/*    */   public OpenHashMapList(int initialCapacity) {
/* 31 */     super(initialCapacity);
/*    */   }
/*    */   
/*    */   public OpenHashMapList deepClone() {
/* 35 */     OpenHashMapList copy = (OpenHashMapList)clone();
/* 36 */     Object[] values = copy.value;
/* 37 */     for (int i = values.length; i-- > 0;) {
/* 38 */       if (values[i] != null) {
/* 39 */         values[i] = ((CandidateSelector)values[i]).copy();
/*    */       }
/*    */     } 
/* 42 */     return copy;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\OpenHashMapList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */