/*    */ package org.apache.felix.resolver.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.osgi.resource.Capability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CandidateSelector
/*    */ {
/*    */   protected final AtomicBoolean isUnmodifiable;
/*    */   protected final List<Capability> unmodifiable;
/* 31 */   private int currentIndex = 0;
/*    */   
/*    */   public CandidateSelector(List<Capability> candidates, AtomicBoolean isUnmodifiable) {
/* 34 */     this.isUnmodifiable = isUnmodifiable;
/* 35 */     this.unmodifiable = new ArrayList<>(candidates);
/*    */   }
/*    */   
/*    */   protected CandidateSelector(CandidateSelector candidateSelector) {
/* 39 */     this.isUnmodifiable = candidateSelector.isUnmodifiable;
/* 40 */     this.unmodifiable = candidateSelector.unmodifiable;
/* 41 */     this.currentIndex = candidateSelector.currentIndex;
/*    */   }
/*    */   
/*    */   public CandidateSelector copy() {
/* 45 */     return new CandidateSelector(this);
/*    */   }
/*    */   
/*    */   public int getRemainingCandidateCount() {
/* 49 */     return this.unmodifiable.size() - this.currentIndex;
/*    */   }
/*    */   
/*    */   public Capability getCurrentCandidate() {
/* 53 */     return (this.currentIndex < this.unmodifiable.size()) ? this.unmodifiable.get(this.currentIndex) : null;
/*    */   }
/*    */   
/*    */   public List<Capability> getRemainingCandidates() {
/* 57 */     return Collections.unmodifiableList(this.unmodifiable.subList(this.currentIndex, this.unmodifiable.size()));
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 61 */     return (this.unmodifiable.size() <= this.currentIndex);
/*    */   }
/*    */   
/*    */   public Capability removeCurrentCandidate() {
/* 65 */     Capability current = getCurrentCandidate();
/* 66 */     if (current != null) {
/* 67 */       this.currentIndex++;
/*    */     }
/* 69 */     return current;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 73 */     return getRemainingCandidates().toString();
/*    */   }
/*    */   
/*    */   public int remove(Capability cap) {
/* 77 */     checkModifiable();
/* 78 */     int index = this.unmodifiable.indexOf(cap);
/* 79 */     if (index != -1) {
/* 80 */       this.unmodifiable.remove(index);
/*    */     }
/* 82 */     return index;
/*    */   }
/*    */   
/*    */   protected void checkModifiable() {
/* 86 */     if (this.isUnmodifiable.get())
/* 87 */       throw new IllegalStateException("Trying to mutate after candidates have been prepared."); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\CandidateSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */