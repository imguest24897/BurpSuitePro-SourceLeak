/*    */ package org.apache.felix.resolver.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenHashMapSet<K, V>
/*    */   extends OpenHashMap<K, CopyOnWriteSet<V>>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OpenHashMapSet() {}
/*    */   
/*    */   public OpenHashMapSet(int initialCapacity) {
/* 29 */     super(initialCapacity);
/*    */   }
/*    */ 
/*    */   
/*    */   public OpenHashMapSet<K, V> deepClone() {
/* 34 */     OpenHashMapSet<K, V> copy = (OpenHashMapSet<K, V>)clone();
/* 35 */     Object[] values = copy.value;
/* 36 */     for (int i = values.length; i-- > 0;) {
/* 37 */       if (values[i] != null) {
/* 38 */         values[i] = new CopyOnWriteSet((CopyOnWriteSet)values[i]);
/*    */       }
/*    */     } 
/* 41 */     return copy;
/*    */   }
/*    */ 
/*    */   
/*    */   protected CopyOnWriteSet<V> compute(K key) {
/* 46 */     return new CopyOnWriteSet<>();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\OpenHashMapSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */