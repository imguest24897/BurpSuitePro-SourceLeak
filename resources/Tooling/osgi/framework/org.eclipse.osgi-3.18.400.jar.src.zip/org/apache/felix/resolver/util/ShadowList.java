/*    */ package org.apache.felix.resolver.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.osgi.resource.Capability;
/*    */ import org.osgi.service.resolver.HostedCapability;
/*    */ import org.osgi.service.resolver.ResolveContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShadowList
/*    */   extends CandidateSelector
/*    */ {
/*    */   private final List<Capability> m_original;
/*    */   
/*    */   public static ShadowList createShadowList(CandidateSelector original) {
/* 31 */     if (original instanceof ShadowList)
/*    */     {
/* 33 */       throw new IllegalArgumentException("Cannot create a ShadowList using another ShadowList.");
/*    */     }
/* 35 */     return new ShadowList(original.unmodifiable, original.unmodifiable, original.isUnmodifiable);
/*    */   }
/*    */   
/*    */   public static ShadowList deepCopy(ShadowList original) {
/* 39 */     return new ShadowList(original.unmodifiable, original.m_original, original.isUnmodifiable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ShadowList(CandidateSelector shadow, List<Capability> original) {
/* 46 */     super(shadow);
/* 47 */     this.m_original = original;
/*    */   }
/*    */   
/*    */   private ShadowList(List<Capability> unmodifiable, List<Capability> original, AtomicBoolean isUnmodifiable) {
/* 51 */     super(unmodifiable, isUnmodifiable);
/* 52 */     this.m_original = new ArrayList<>(original);
/*    */   }
/*    */   
/*    */   public ShadowList copy() {
/* 56 */     return new ShadowList(this, this.m_original);
/*    */   }
/*    */   
/*    */   public void insertHostedCapability(ResolveContext context, HostedCapability wrappedCapability, HostedCapability toInsertCapability) {
/* 60 */     checkModifiable();
/* 61 */     int removeIdx = this.m_original.indexOf(toInsertCapability.getDeclaredCapability());
/* 62 */     if (removeIdx != -1) {
/*    */       
/* 64 */       this.m_original.remove(removeIdx);
/* 65 */       this.unmodifiable.remove(removeIdx);
/*    */     } 
/* 67 */     int insertIdx = context.insertHostedCapability(this.m_original, toInsertCapability);
/* 68 */     this.unmodifiable.add(insertIdx, wrappedCapability);
/*    */   }
/*    */   
/*    */   public void replace(Capability origCap, Capability c) {
/* 72 */     checkModifiable();
/* 73 */     int idx = this.unmodifiable.indexOf(origCap);
/* 74 */     this.unmodifiable.set(idx, c);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\ShadowList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */