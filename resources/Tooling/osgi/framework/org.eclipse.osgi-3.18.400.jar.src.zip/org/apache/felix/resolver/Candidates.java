/*      */ package org.apache.felix.resolver;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.apache.felix.resolver.reason.ReasonException;
/*      */ import org.apache.felix.resolver.util.CandidateSelector;
/*      */ import org.apache.felix.resolver.util.CopyOnWriteSet;
/*      */ import org.apache.felix.resolver.util.OpenHashMap;
/*      */ import org.apache.felix.resolver.util.OpenHashMapList;
/*      */ import org.apache.felix.resolver.util.OpenHashMapSet;
/*      */ import org.apache.felix.resolver.util.ShadowList;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.resource.Capability;
/*      */ import org.osgi.resource.Requirement;
/*      */ import org.osgi.resource.Resource;
/*      */ import org.osgi.resource.Wire;
/*      */ import org.osgi.resource.Wiring;
/*      */ import org.osgi.service.resolver.HostedCapability;
/*      */ import org.osgi.service.resolver.ResolutionException;
/*      */ import org.osgi.service.resolver.ResolveContext;
/*      */ 
/*      */ class Candidates {
/*      */   private final ResolverImpl.ResolveSession m_session;
/*      */   private final OpenHashMapSet<Capability, Requirement> m_dependentMap;
/*      */   private final OpenHashMapList m_candidateMap;
/*      */   private final Map<Resource, WrappedResource> m_allWrappedHosts;
/*      */   private final OpenHashMap<Resource, PopulateResult> m_populateResultCache;
/*      */   private final Map<Capability, Requirement> m_subtitutableMap;
/*      */   private final OpenHashMapSet<Requirement, Capability> m_delta;
/*      */   private final AtomicBoolean m_candidateSelectorsUnmodifiable;
/*      */   private static final int UNPROCESSED = 0;
/*      */   private static final int PROCESSING = 1;
/*      */   private static final int SUBSTITUTED = 2;
/*      */   private static final int EXPORTED = 3;
/*      */   
/*      */   static class PopulateResult {
/*      */     public String toString() {
/*   46 */       return this.success ? "true" : ((this.error != null) ? this.error.getMessage() : "???");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean success;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ResolutionError error;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     List<Requirement> remaining;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Map<Requirement, List<Capability>> candidates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Candidates(ResolverImpl.ResolveSession session, AtomicBoolean candidateSelectorsUnmodifiable, OpenHashMapSet<Capability, Requirement> dependentMap, OpenHashMapList candidateMap, Map<Resource, WrappedResource> wrappedHosts, OpenHashMap<Resource, PopulateResult> populateResultCache, Map<Capability, Requirement> substitutableMap, OpenHashMapSet<Requirement, Capability> delta) {
/*   79 */     this.m_session = session;
/*   80 */     this.m_candidateSelectorsUnmodifiable = candidateSelectorsUnmodifiable;
/*   81 */     this.m_dependentMap = dependentMap;
/*   82 */     this.m_candidateMap = candidateMap;
/*   83 */     this.m_allWrappedHosts = wrappedHosts;
/*   84 */     this.m_populateResultCache = populateResultCache;
/*   85 */     this.m_subtitutableMap = substitutableMap;
/*   86 */     this.m_delta = delta;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Candidates(ResolverImpl.ResolveSession session) {
/*   94 */     this.m_session = session;
/*   95 */     this.m_candidateSelectorsUnmodifiable = new AtomicBoolean(false);
/*   96 */     this.m_dependentMap = new OpenHashMapSet();
/*   97 */     this.m_candidateMap = new OpenHashMapList();
/*   98 */     this.m_allWrappedHosts = new HashMap<>();
/*   99 */     this.m_populateResultCache = new OpenHashMap();
/*  100 */     this.m_subtitutableMap = (Map<Capability, Requirement>)new OpenHashMap();
/*  101 */     this.m_delta = new OpenHashMapSet(3);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNbResources() {
/*  106 */     return this.m_populateResultCache.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<Resource, Resource> getRootHosts() {
/*  111 */     Map<Resource, Resource> hosts = new LinkedHashMap<>();
/*  112 */     for (Resource res : this.m_session.getMandatoryResources())
/*      */     {
/*  114 */       addHost(res, hosts);
/*      */     }
/*      */     
/*  117 */     for (Resource res : this.m_session.getOptionalResources()) {
/*      */       
/*  119 */       if (isPopulated(res)) {
/*  120 */         addHost(res, hosts);
/*      */       }
/*      */     } 
/*      */     
/*  124 */     return hosts;
/*      */   }
/*      */   
/*      */   private void addHost(Resource res, Map<Resource, Resource> hosts) {
/*  128 */     if (res instanceof WrappedResource)
/*      */     {
/*  130 */       res = ((WrappedResource)res).getDeclaredResource();
/*      */     }
/*  132 */     if (!Util.isFragment(res)) {
/*      */       
/*  134 */       hosts.put(res, getWrappedHost(res));
/*      */     } else {
/*  136 */       Requirement hostReq = res.getRequirements("osgi.wiring.host").get(0);
/*  137 */       Capability hostCap = getFirstCandidate(hostReq);
/*      */ 
/*      */ 
/*      */       
/*  141 */       if (hostCap != null) {
/*  142 */         res = getWrappedHost(hostCap.getResource());
/*  143 */         if (res instanceof WrappedResource) {
/*  144 */           hosts.put(((WrappedResource)res).getDeclaredResource(), res);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getDelta() {
/*  157 */     return this.m_delta;
/*      */   }
/*      */ 
/*      */   
/*      */   public void populate(Collection<Resource> resources) {
/*  162 */     ResolveContext rc = this.m_session.getContext();
/*  163 */     Set<Resource> toRemove = new HashSet<>();
/*  164 */     LinkedList<Resource> toPopulate = new LinkedList<>(resources);
/*  165 */     while (!toPopulate.isEmpty()) {
/*      */       
/*  167 */       Resource resource = toPopulate.getFirst();
/*      */       
/*  169 */       PopulateResult result = (PopulateResult)this.m_populateResultCache.get(resource);
/*  170 */       if (result == null) {
/*      */         
/*  172 */         result = new PopulateResult();
/*  173 */         result.candidates = (Map<Requirement, List<Capability>>)new OpenHashMap();
/*  174 */         result.remaining = new ArrayList<>(resource.getRequirements(null));
/*  175 */         this.m_populateResultCache.put(resource, result);
/*      */       } 
/*  177 */       if (result.success || result.error != null) {
/*      */         
/*  179 */         toPopulate.removeFirst();
/*      */         continue;
/*      */       } 
/*  182 */       if (result.remaining.isEmpty()) {
/*      */         
/*  184 */         toPopulate.removeFirst();
/*  185 */         result.success = true;
/*  186 */         addCandidates(result.candidates);
/*  187 */         result.candidates = null;
/*  188 */         result.remaining = null;
/*  189 */         Collection<Resource> relatedResources = rc.findRelatedResources(resource);
/*  190 */         this.m_session.setRelatedResources(resource, relatedResources);
/*  191 */         for (Resource relatedResource : relatedResources) {
/*      */           
/*  193 */           if (this.m_session.isValidRelatedResource(relatedResource))
/*      */           {
/*      */ 
/*      */             
/*  197 */             toPopulate.addFirst(relatedResource);
/*      */           }
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*  203 */       Requirement requirement = result.remaining.remove(0);
/*  204 */       if (!isEffective(requirement)) {
/*      */         continue;
/*      */       }
/*      */       
/*  208 */       List<Capability> candidates = rc.findProviders(requirement);
/*  209 */       LinkedList<Resource> newToPopulate = new LinkedList<>();
/*  210 */       ResolutionError thrown = processCandidates(newToPopulate, requirement, candidates);
/*  211 */       if (candidates.isEmpty() && !Util.isOptional(requirement)) {
/*      */         
/*  213 */         if (Util.isFragment(resource) && rc.getWirings().containsKey(resource)) {
/*      */ 
/*      */           
/*  216 */           result.success = true;
/*      */         }
/*      */         else {
/*      */           
/*  220 */           result.error = new MissingRequirementError(requirement, thrown);
/*  221 */           toRemove.add(resource);
/*      */         } 
/*  223 */         toPopulate.removeFirst();
/*      */         
/*      */         continue;
/*      */       } 
/*  227 */       if (!candidates.isEmpty())
/*      */       {
/*  229 */         result.candidates.put(requirement, candidates);
/*      */       }
/*  231 */       if (!newToPopulate.isEmpty())
/*      */       {
/*  233 */         toPopulate.addAll(0, newToPopulate);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  238 */     while (!toRemove.isEmpty()) {
/*      */       
/*  240 */       Iterator<Resource> iterator = toRemove.iterator();
/*  241 */       Resource resource = iterator.next();
/*  242 */       iterator.remove();
/*  243 */       remove(resource, toRemove);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isEffective(Requirement req) {
/*  248 */     if (!this.m_session.getContext().isEffective(req)) {
/*  249 */       return false;
/*      */     }
/*  251 */     String res = (String)req.getDirectives().get("resolution");
/*  252 */     return !"dynamic".equals(res);
/*      */   }
/*      */ 
/*      */   
/*      */   private void populateSubstitutables() {
/*  257 */     for (Map.Entry<Resource, PopulateResult> populated : (Iterable<Map.Entry<Resource, PopulateResult>>)this.m_populateResultCache.fast()) {
/*      */       
/*  259 */       if (((PopulateResult)populated.getValue()).success)
/*      */       {
/*  261 */         populateSubstitutables(populated.getKey());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void populateSubstitutables(Resource resource) {
/*  270 */     OpenHashMap<String, List<Capability>> exportNames = new OpenHashMap<String, List<Capability>>()
/*      */       {
/*      */         protected List<Capability> compute(String s) {
/*  273 */           return new ArrayList<>(1);
/*      */         }
/*      */       };
/*  276 */     for (Capability packageExport : resource.getCapabilities(null)) {
/*      */       
/*  278 */       if (!"osgi.wiring.package".equals(packageExport.getNamespace())) {
/*      */         continue;
/*      */       }
/*      */       
/*  282 */       String packageName = (String)packageExport.getAttributes().get("osgi.wiring.package");
/*  283 */       List<Capability> caps = (List<Capability>)exportNames.getOrCompute(packageName);
/*  284 */       caps.add(packageExport);
/*      */     } 
/*  286 */     if (exportNames.isEmpty()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  291 */     for (Requirement req : resource.getRequirements(null)) {
/*      */       
/*  293 */       if (!"osgi.wiring.package".equals(req.getNamespace())) {
/*      */         continue;
/*      */       }
/*      */       
/*  297 */       CandidateSelector substitutes = (CandidateSelector)this.m_candidateMap.get(req);
/*  298 */       if (substitutes != null && !substitutes.isEmpty()) {
/*      */         
/*  300 */         String packageName = (String)substitutes.getCurrentCandidate().getAttributes().get("osgi.wiring.package");
/*  301 */         List<Capability> exportedPackages = (List<Capability>)exportNames.get(packageName);
/*  302 */         if (exportedPackages != null)
/*      */         {
/*      */ 
/*      */           
/*  306 */           if (!exportedPackages.containsAll(substitutes.getRemainingCandidates()))
/*      */           {
/*  308 */             for (Capability exportedPackage : exportedPackages)
/*      */             {
/*  310 */               this.m_subtitutableMap.put(exportedPackage, req);
/*      */             }
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResolutionError checkSubstitutes() {
/*  325 */     OpenHashMap<Capability, Integer> substituteStatuses = new OpenHashMap(this.m_subtitutableMap.size());
/*  326 */     for (Capability substitutable : this.m_subtitutableMap.keySet())
/*      */     {
/*      */       
/*  329 */       substituteStatuses.put(substitutable, Integer.valueOf(0));
/*      */     }
/*      */     
/*  332 */     for (Capability substitutable : this.m_subtitutableMap.keySet())
/*      */     {
/*  334 */       isSubstituted(substitutable, (Map<Capability, Integer>)substituteStatuses);
/*      */     }
/*      */ 
/*      */     
/*  338 */     for (Map.Entry<Capability, Integer> substituteStatus : (Iterable<Map.Entry<Capability, Integer>>)substituteStatuses.fast()) {
/*      */ 
/*      */       
/*  341 */       Requirement substitutedReq = this.m_subtitutableMap.get(substituteStatus.getKey());
/*  342 */       if (substitutedReq != null)
/*      */       {
/*  344 */         this.m_session.permutateIfNeeded(ResolverImpl.PermutationType.SUBSTITUTE, substitutedReq, this);
/*      */       }
/*  346 */       Set<Requirement> dependents = (Set<Requirement>)this.m_dependentMap.get(substituteStatus.getKey());
/*  347 */       if (dependents != null)
/*      */       {
/*  349 */         for (Requirement dependent : dependents) {
/*      */           
/*  351 */           CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(dependent);
/*  352 */           if (candidates != null) {
/*      */ 
/*      */             
/*  355 */             while (!candidates.isEmpty()) {
/*      */               
/*  357 */               Capability candidate = candidates.getCurrentCandidate();
/*  358 */               Integer candidateStatus = (Integer)substituteStatuses.get(candidate);
/*  359 */               if (candidateStatus == null)
/*      */               {
/*  361 */                 candidateStatus = Integer.valueOf(3);
/*      */               }
/*  363 */               switch (candidateStatus.intValue()) {
/*      */                 case 3:
/*      */                   break;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  371 */               candidates.removeCurrentCandidate();
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  376 */             if (candidates.isEmpty()) {
/*      */               
/*  378 */               if (Util.isOptional(dependent)) {
/*      */                 
/*  380 */                 this.m_candidateMap.remove(dependent);
/*      */                 
/*      */                 continue;
/*      */               } 
/*  384 */               return new MissingRequirementError(dependent);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  391 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isSubstituted(Capability substitutableCap, Map<Capability, Integer> substituteStatuses) {
/*  396 */     Integer substituteState = substituteStatuses.get(substitutableCap);
/*  397 */     if (substituteState == null)
/*      */     {
/*  399 */       return false;
/*      */     }
/*      */     
/*  402 */     switch (substituteState.intValue()) {
/*      */ 
/*      */       
/*      */       case 1:
/*  406 */         substituteStatuses.put(substitutableCap, Integer.valueOf(3));
/*  407 */         return false;
/*      */       case 2:
/*  409 */         return true;
/*      */       case 3:
/*  411 */         return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  416 */     Requirement substitutableReq = this.m_subtitutableMap.get(substitutableCap);
/*  417 */     if (substitutableReq == null)
/*      */     {
/*      */       
/*  420 */       return false;
/*      */     }
/*      */     
/*  423 */     substituteStatuses.put(substitutableCap, Integer.valueOf(1));
/*      */     
/*  425 */     CandidateSelector substitutes = (CandidateSelector)this.m_candidateMap.get(substitutableReq);
/*  426 */     if (substitutes != null)
/*      */     {
/*  428 */       for (Capability substituteCandidate : substitutes.getRemainingCandidates()) {
/*      */         
/*  430 */         if (substituteCandidate.getResource().equals(substitutableCap.getResource())) {
/*      */           
/*  432 */           substituteStatuses.put(substitutableCap, Integer.valueOf(3));
/*  433 */           return false;
/*      */         } 
/*  435 */         if (!isSubstituted(substituteCandidate, substituteStatuses)) {
/*      */ 
/*      */           
/*  438 */           substituteStatuses.put(substitutableCap, Integer.valueOf(2));
/*  439 */           return true;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  444 */     substituteStatuses.put(substitutableCap, Integer.valueOf(3));
/*  445 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolutionError populateDynamic() {
/*  454 */     LinkedList<Resource> toPopulate = new LinkedList<>();
/*  455 */     ResolutionError rethrow = processCandidates(toPopulate, this.m_session.getDynamicRequirement(), this.m_session.getDynamicCandidates());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  460 */     addCandidates(this.m_session.getDynamicRequirement(), this.m_session.getDynamicCandidates());
/*      */     
/*  462 */     populate(toPopulate);
/*      */     
/*  464 */     CandidateSelector caps = (CandidateSelector)this.m_candidateMap.get(this.m_session.getDynamicRequirement());
/*  465 */     if (caps != null) {
/*      */       
/*  467 */       this.m_session.getDynamicCandidates().retainAll(caps.getRemainingCandidates());
/*      */     }
/*      */     else {
/*      */       
/*  471 */       this.m_session.getDynamicCandidates().clear();
/*      */     } 
/*      */     
/*  474 */     if (this.m_session.getDynamicCandidates().isEmpty()) {
/*      */       
/*  476 */       if (rethrow == null)
/*      */       {
/*  478 */         rethrow = new DynamicImportFailed(this.m_session.getDynamicRequirement());
/*      */       }
/*  480 */       return rethrow;
/*      */     } 
/*      */     
/*  483 */     PopulateResult result = new PopulateResult();
/*  484 */     result.success = true;
/*  485 */     this.m_populateResultCache.put(this.m_session.getDynamicHost(), result);
/*  486 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResolutionError processCandidates(LinkedList<Resource> toPopulate, Requirement req, List<Capability> candidates) {
/*  494 */     ResolveContext rc = this.m_session.getContext();
/*      */     
/*  496 */     ResolutionError rethrow = null;
/*  497 */     Set<Capability> fragmentCands = null;
/*  498 */     Iterator<Capability> itCandCap = candidates.iterator();
/*  499 */     while (itCandCap.hasNext()) {
/*      */       
/*  501 */       Capability candCap = itCandCap.next();
/*      */       
/*  503 */       boolean isFragment = Util.isFragment(candCap.getResource());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  508 */       if (isFragment) {
/*      */         
/*  510 */         if (fragmentCands == null)
/*      */         {
/*  512 */           fragmentCands = new HashSet<>();
/*      */         }
/*  514 */         fragmentCands.add(candCap);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  519 */       if ("osgi.wiring.host".equals(req.getNamespace()) && 
/*  520 */         rc.getWirings().containsKey(candCap.getResource())) {
/*  521 */         itCandCap.remove();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  537 */       if ((isFragment || !rc.getWirings().containsKey(candCap.getResource())) && 
/*  538 */         !candCap.getResource().equals(req.getResource())) {
/*      */         
/*  540 */         PopulateResult result = (PopulateResult)this.m_populateResultCache.get(candCap.getResource());
/*  541 */         if (result != null) {
/*      */           
/*  543 */           if (result.error != null) {
/*      */             
/*  545 */             if (rethrow == null)
/*      */             {
/*  547 */               rethrow = result.error;
/*      */             }
/*      */ 
/*      */             
/*  551 */             itCandCap.remove(); continue;
/*      */           } 
/*  553 */           if (!result.success)
/*      */           {
/*  555 */             toPopulate.add(candCap.getResource());
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*  560 */         toPopulate.add(candCap.getResource());
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  569 */     if (fragmentCands != null)
/*      */     {
/*  571 */       for (Capability fragCand : fragmentCands) {
/*      */         
/*  573 */         String fragCandName = fragCand.getNamespace();
/*  574 */         if ("osgi.identity".equals(fragCandName)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  580 */         Wiring wiring = (Wiring)rc.getWirings().get(fragCand.getResource());
/*  581 */         if (wiring != null)
/*      */         {
/*      */ 
/*      */           
/*  585 */           for (Wire wire : wiring.getRequiredResourceWires("osgi.wiring.host")) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  590 */             if (!fragCandName.equals("osgi.wiring.package") || (
/*  591 */               (Wiring)rc.getWirings().get(wire.getProvider()))
/*  592 */               .getResourceCapabilities(null).contains(fragCand)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  609 */               candidates.remove(fragCand);
/*  610 */               rc.insertHostedCapability(
/*  611 */                   candidates, 
/*  612 */                   new WrappedCapability(
/*  613 */                     wire.getCapability().getResource(), 
/*  614 */                     fragCand));
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  621 */     return rethrow;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPopulated(Resource resource) {
/*  626 */     PopulateResult value = (PopulateResult)this.m_populateResultCache.get(resource);
/*  627 */     return (value != null && value.success);
/*      */   }
/*      */ 
/*      */   
/*      */   public ResolutionError getResolutionError(Resource resource) {
/*  632 */     PopulateResult value = (PopulateResult)this.m_populateResultCache.get(resource);
/*  633 */     return (value != null) ? value.error : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addCandidates(Requirement req, List<Capability> candidates) {
/*  649 */     this.m_candidateMap.put(req, new CandidateSelector(candidates, this.m_candidateSelectorsUnmodifiable));
/*  650 */     for (Capability cap : candidates)
/*      */     {
/*  652 */       ((CopyOnWriteSet)this.m_dependentMap.getOrCompute(cap)).add(req);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addCandidates(Map<Requirement, List<Capability>> candidates) {
/*  665 */     for (Map.Entry<Requirement, List<Capability>> entry : candidates.entrySet())
/*      */     {
/*  667 */       addCandidates(entry.getKey(), entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Resource getWrappedHost(Resource r) {
/*  683 */     Resource wrapped = this.m_allWrappedHosts.get(r);
/*  684 */     return (wrapped == null) ? r : wrapped;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Capability> getCandidates(Requirement req) {
/*  695 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/*  696 */     if (candidates != null)
/*      */     {
/*  698 */       return candidates.getRemainingCandidates();
/*      */     }
/*  700 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Capability getFirstCandidate(Requirement req) {
/*  705 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/*  706 */     if (candidates != null && !candidates.isEmpty())
/*      */     {
/*  708 */       return candidates.getCurrentCandidate();
/*      */     }
/*  710 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeFirstCandidate(Requirement req) {
/*  715 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/*      */     
/*  717 */     Capability cap = candidates.removeCurrentCandidate();
/*  718 */     if (candidates.isEmpty())
/*      */     {
/*  720 */       this.m_candidateMap.remove(req);
/*      */     }
/*      */     
/*  723 */     CopyOnWriteSet<Capability> capPath = (CopyOnWriteSet<Capability>)this.m_delta.getOrCompute(req);
/*  724 */     capPath.add(cap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CandidateSelector clearMultipleCardinalityCandidates(Requirement req, Collection<Capability> caps) {
/*  731 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/*  732 */     List<Capability> remaining = new ArrayList<>(candidates.getRemainingCandidates());
/*  733 */     remaining.removeAll(caps);
/*  734 */     candidates = new CandidateSelector(remaining, this.m_candidateSelectorsUnmodifiable);
/*  735 */     this.m_candidateMap.put(req, candidates);
/*  736 */     return candidates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolutionError prepare() {
/*  762 */     Map<Capability, Map<String, Map<Version, List<Requirement>>>> hostFragments = 
/*  763 */       getHostFragments();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  779 */     List<WrappedResource> hostResources = new ArrayList<>();
/*  780 */     List<Resource> unselectedFragments = new ArrayList<>();
/*  781 */     for (Map.Entry<Capability, Map<String, Map<Version, List<Requirement>>>> hostEntry : hostFragments.entrySet()) {
/*      */ 
/*      */       
/*  784 */       Capability hostCap = hostEntry.getKey();
/*  785 */       Map<String, Map<Version, List<Requirement>>> fragments = 
/*  786 */         hostEntry.getValue();
/*  787 */       List<Resource> selectedFragments = new ArrayList<>();
/*      */       
/*  789 */       Iterator<Map.Entry<String, Map<Version, List<Requirement>>>> iterator = fragments.entrySet().iterator(); while (iterator.hasNext()) { Map.Entry<String, Map<Version, List<Requirement>>> fragEntry = iterator.next();
/*      */         
/*  791 */         boolean isFirst = true;
/*      */         
/*  793 */         Iterator<Map.Entry<Version, List<Requirement>>> iterator1 = ((Map)fragEntry.getValue()).entrySet().iterator(); while (iterator1.hasNext()) { Map.Entry<Version, List<Requirement>> versionEntry = iterator1.next();
/*      */           
/*  795 */           for (Requirement hostReq : versionEntry.getValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  800 */             if (isFirst) {
/*      */               
/*  802 */               selectedFragments.add(hostReq.getResource());
/*  803 */               isFirst = false;
/*      */ 
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  812 */             ((CopyOnWriteSet)this.m_dependentMap.get(hostCap)).remove(hostReq);
/*  813 */             CandidateSelector hosts = removeCandidate(hostReq, hostCap);
/*  814 */             if (hosts.isEmpty())
/*      */             {
/*  816 */               unselectedFragments.add(hostReq.getResource());
/*      */             }
/*      */           }  }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  824 */       WrappedResource wrappedHost = 
/*  825 */         new WrappedResource(hostCap.getResource(), selectedFragments);
/*  826 */       hostResources.add(wrappedHost);
/*  827 */       this.m_allWrappedHosts.put(hostCap.getResource(), wrappedHost);
/*      */     } 
/*      */ 
/*      */     
/*  831 */     for (Resource fragment : unselectedFragments)
/*      */     {
/*  833 */       removeResource(fragment, new FragmentNotSelectedError(fragment));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  838 */     for (WrappedResource hostResource : hostResources) {
/*  839 */       for (Requirement r : hostResource.getRequirements(null)) {
/*      */         
/*  841 */         Requirement origReq = ((WrappedRequirement)r).getDeclaredRequirement();
/*  842 */         CandidateSelector cands = (CandidateSelector)this.m_candidateMap.get(origReq);
/*  843 */         if (cands != null) {
/*      */           
/*  845 */           if (cands instanceof ShadowList) {
/*      */             
/*  847 */             this.m_candidateMap.put(r, ShadowList.deepCopy((ShadowList)cands));
/*      */           } else {
/*  849 */             this.m_candidateMap.put(r, cands.copy());
/*      */           } 
/*  851 */           for (Capability cand : cands.getRemainingCandidates()) {
/*      */             
/*  853 */             Set<Requirement> dependents = (Set<Requirement>)this.m_dependentMap.get(cand);
/*  854 */             dependents.remove(origReq);
/*  855 */             dependents.add(r);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  861 */     for (WrappedResource hostResource : hostResources) {
/*      */ 
/*      */ 
/*      */       
/*  865 */       for (Capability c : hostResource.getCapabilities(null)) {
/*      */ 
/*      */ 
/*      */         
/*  869 */         if (!c.getNamespace().equals("osgi.wiring.host")) {
/*      */           
/*  871 */           Capability origCap = ((HostedCapability)c).getDeclaredCapability();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  876 */           CopyOnWriteSet<Requirement> dependents = (CopyOnWriteSet<Requirement>)this.m_dependentMap.get(origCap);
/*  877 */           if (dependents != null) {
/*      */             
/*  879 */             dependents = new CopyOnWriteSet(dependents);
/*  880 */             this.m_dependentMap.put(c, dependents);
/*  881 */             for (Requirement r : dependents) {
/*      */               ShadowList shadowList1, shadow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  910 */               CandidateSelector cands = (CandidateSelector)this.m_candidateMap.get(r);
/*      */               
/*  912 */               if (!(cands instanceof ShadowList)) {
/*      */                 
/*  914 */                 shadow = ShadowList.createShadowList(cands);
/*  915 */                 this.m_candidateMap.put(r, shadow);
/*  916 */                 shadowList1 = shadow;
/*      */               }
/*      */               else {
/*      */                 
/*  920 */                 shadow = shadowList1;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  926 */               if (!origCap.getResource().equals(hostResource.getDeclaredResource())) {
/*      */                 
/*  928 */                 shadow.insertHostedCapability(
/*  929 */                     this.m_session.getContext(), 
/*  930 */                     (HostedCapability)c, 
/*  931 */                     new SimpleHostedCapability(
/*  932 */                       hostResource.getDeclaredResource(), 
/*  933 */                       origCap));
/*      */ 
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */               
/*  939 */               shadow.replace(origCap, c);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  950 */     for (Resource resource : this.m_session.getMandatoryResources()) {
/*      */       
/*  952 */       if (!isPopulated(resource))
/*      */       {
/*  954 */         return getResolutionError(resource);
/*      */       }
/*      */     } 
/*      */     
/*  958 */     populateSubstitutables();
/*      */     
/*  960 */     this.m_candidateMap.trim();
/*  961 */     this.m_dependentMap.trim();
/*      */ 
/*      */     
/*  964 */     this.m_candidateSelectorsUnmodifiable.set(true);
/*  965 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<Capability, Map<String, Map<Version, List<Requirement>>>> getHostFragments() {
/*  974 */     Map<Capability, Map<String, Map<Version, List<Requirement>>>> hostFragments = 
/*  975 */       new HashMap<>();
/*  976 */     for (Map.Entry<Requirement, CandidateSelector> entry : (Iterable<Map.Entry<Requirement, CandidateSelector>>)this.m_candidateMap.fast()) {
/*      */       
/*  978 */       Requirement req = entry.getKey();
/*  979 */       CandidateSelector caps = entry.getValue();
/*  980 */       for (Capability cap : caps.getRemainingCandidates()) {
/*      */ 
/*      */         
/*  983 */         if (req.getNamespace().equals("osgi.wiring.host")) {
/*      */           
/*  985 */           String resSymName = Util.getSymbolicName(req.getResource());
/*  986 */           Version resVersion = Util.getVersion(req.getResource());
/*      */           
/*  988 */           Map<String, Map<Version, List<Requirement>>> fragments = hostFragments.get(cap);
/*  989 */           if (fragments == null) {
/*      */             
/*  991 */             fragments = new HashMap<>();
/*  992 */             hostFragments.put(cap, fragments);
/*      */           } 
/*  994 */           Map<Version, List<Requirement>> fragmentVersions = fragments.get(resSymName);
/*  995 */           if (fragmentVersions == null) {
/*      */             
/*  997 */             fragmentVersions = 
/*  998 */               new TreeMap<>(Collections.reverseOrder());
/*  999 */             fragments.put(resSymName, fragmentVersions);
/*      */           } 
/* 1001 */           List<Requirement> actual = fragmentVersions.get(resVersion);
/* 1002 */           if (actual == null) {
/*      */             
/* 1004 */             actual = new ArrayList<>();
/* 1005 */             if (resVersion == null)
/* 1006 */               resVersion = new Version(0, 0, 0); 
/* 1007 */             fragmentVersions.put(resVersion, actual);
/*      */           } 
/* 1009 */           actual.add(req);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1014 */     return hostFragments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeResource(Resource resource, ResolutionError ex) {
/* 1029 */     PopulateResult result = (PopulateResult)this.m_populateResultCache.get(resource);
/* 1030 */     result.success = false;
/* 1031 */     result.error = ex;
/*      */     
/* 1033 */     Set<Resource> unresolvedResources = new HashSet<>();
/* 1034 */     remove(resource, unresolvedResources);
/*      */     
/* 1036 */     while (!unresolvedResources.isEmpty()) {
/*      */       
/* 1038 */       Iterator<Resource> it = unresolvedResources.iterator();
/* 1039 */       resource = it.next();
/* 1040 */       it.remove();
/* 1041 */       remove(resource, unresolvedResources);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void remove(Resource resource, Set<Resource> unresolvedResources) {
/* 1057 */     for (Requirement r : resource.getRequirements(null))
/*      */     {
/* 1059 */       remove(r);
/*      */     }
/*      */     
/* 1062 */     for (Capability c : resource.getCapabilities(null))
/*      */     {
/* 1064 */       remove(c, unresolvedResources);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void remove(Requirement req) {
/* 1075 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.remove(req);
/* 1076 */     if (candidates != null)
/*      */     {
/* 1078 */       for (Capability cap : candidates.getRemainingCandidates()) {
/*      */         
/* 1080 */         Set<Requirement> dependents = (Set<Requirement>)this.m_dependentMap.get(cap);
/* 1081 */         if (dependents != null)
/*      */         {
/* 1083 */           dependents.remove(req);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void remove(Capability c, Set<Resource> unresolvedResources) {
/* 1100 */     Set<Requirement> dependents = (Set<Requirement>)this.m_dependentMap.remove(c);
/* 1101 */     if (dependents != null)
/*      */     {
/* 1103 */       for (Requirement r : dependents) {
/*      */         
/* 1105 */         CandidateSelector candidates = removeCandidate(r, c);
/* 1106 */         if (candidates.isEmpty()) {
/*      */           
/* 1108 */           this.m_candidateMap.remove(r);
/* 1109 */           if (!Util.isOptional(r)) {
/*      */             
/* 1111 */             PopulateResult result = (PopulateResult)this.m_populateResultCache.get(r.getResource());
/* 1112 */             if (result != null) {
/*      */               
/* 1114 */               result.success = false;
/* 1115 */               result.error = 
/* 1116 */                 new MissingRequirementError(r, ((PopulateResult)this.m_populateResultCache.get(c.getResource())).error);
/*      */             } 
/* 1118 */             unresolvedResources.add(r.getResource());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private CandidateSelector removeCandidate(Requirement req, Capability cap) {
/* 1126 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/* 1127 */     candidates.remove(cap);
/* 1128 */     return candidates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Candidates copy() {
/* 1139 */     return new Candidates(
/* 1140 */         this.m_session, 
/* 1141 */         this.m_candidateSelectorsUnmodifiable, 
/* 1142 */         this.m_dependentMap, 
/* 1143 */         this.m_candidateMap.deepClone(), 
/* 1144 */         this.m_allWrappedHosts, 
/* 1145 */         this.m_populateResultCache, 
/* 1146 */         this.m_subtitutableMap, 
/* 1147 */         this.m_delta.deepClone());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dump(ResolveContext rc) {
/* 1153 */     CopyOnWriteSet<Resource> copyOnWriteSet = new CopyOnWriteSet();
/*      */     
/* 1155 */     null = this.m_candidateMap.entrySet().iterator(); while (null.hasNext()) { Map.Entry<Requirement, CandidateSelector> entry = null.next();
/*      */       
/* 1157 */       copyOnWriteSet.add(((Requirement)entry.getKey()).getResource()); }
/*      */ 
/*      */     
/* 1160 */     System.out.println("=== BEGIN CANDIDATE MAP ===");
/* 1161 */     for (Resource resource : copyOnWriteSet) {
/*      */       
/* 1163 */       Wiring wiring = (Wiring)rc.getWirings().get(resource);
/* 1164 */       System.out.println("  " + resource + 
/* 1165 */           " (" + ((wiring != null) ? "RESOLVED)" : "UNRESOLVED)"));
/* 1166 */       List<Requirement> reqs = (wiring != null) ? 
/* 1167 */         wiring.getResourceRequirements(null) : 
/* 1168 */         resource.getRequirements(null);
/* 1169 */       for (Requirement req : reqs) {
/*      */         
/* 1171 */         CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/* 1172 */         if (candidates != null && !candidates.isEmpty())
/*      */         {
/* 1174 */           System.out.println("    " + req + ": " + candidates);
/*      */         }
/*      */       } 
/* 1177 */       reqs = (wiring != null) ? 
/* 1178 */         Util.getDynamicRequirements(wiring.getResourceRequirements(null)) : 
/* 1179 */         Util.getDynamicRequirements(resource.getRequirements(null));
/* 1180 */       for (Requirement req : reqs) {
/*      */         
/* 1182 */         CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/* 1183 */         if (candidates != null && !candidates.isEmpty())
/*      */         {
/* 1185 */           System.out.println("    " + req + ": " + candidates);
/*      */         }
/*      */       } 
/*      */     } 
/* 1189 */     System.out.println("=== END CANDIDATE MAP ===");
/*      */   }
/*      */ 
/*      */   
/*      */   public Candidates permutate(Requirement req) {
/* 1194 */     if (!Util.isMultiple(req) && canRemoveCandidate(req)) {
/*      */       
/* 1196 */       Candidates perm = copy();
/* 1197 */       perm.removeFirstCandidate(req);
/* 1198 */       return perm;
/*      */     } 
/* 1200 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canRemoveCandidate(Requirement req) {
/* 1205 */     CandidateSelector candidates = (CandidateSelector)this.m_candidateMap.get(req);
/* 1206 */     if (candidates != null) {
/*      */       
/* 1208 */       Capability current = candidates.getCurrentCandidate();
/* 1209 */       if (current != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1230 */         if (req.equals(this.m_subtitutableMap.get(current))) {
/*      */ 
/*      */ 
/*      */           
/* 1234 */           Set<Requirement> dependents = (Set<Requirement>)this.m_dependentMap.get(current);
/* 1235 */           if (dependents != null)
/*      */           {
/* 1237 */             for (Requirement dependent : dependents) {
/*      */               
/* 1239 */               CandidateSelector dependentSelector = (CandidateSelector)this.m_candidateMap.get(
/* 1240 */                   dependent);
/*      */ 
/*      */               
/* 1243 */               if (dependentSelector != null && 
/* 1244 */                 dependentSelector.getRemainingCandidateCount() <= 1)
/*      */               {
/* 1246 */                 if (current.equals(
/* 1247 */                     dependentSelector.getCurrentCandidate()))
/*      */                 {
/*      */ 
/*      */                   
/* 1251 */                   return false;
/*      */                 }
/*      */               }
/*      */             } 
/*      */           }
/*      */         } 
/*      */       }
/* 1258 */       return !(candidates.getRemainingCandidateCount() <= 1 && !Util.isOptional(req));
/*      */     } 
/* 1260 */     return false;
/*      */   }
/*      */   
/*      */   static class DynamicImportFailed
/*      */     extends ResolutionError {
/*      */     private final Requirement requirement;
/*      */     
/*      */     public DynamicImportFailed(Requirement requirement) {
/* 1268 */       this.requirement = requirement;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/* 1272 */       return "Dynamic import failed.";
/*      */     }
/*      */     
/*      */     public Collection<Requirement> getUnresolvedRequirements() {
/* 1276 */       return Collections.singleton(this.requirement);
/*      */     }
/*      */ 
/*      */     
/*      */     public ResolutionException toException() {
/* 1281 */       return (ResolutionException)new ReasonException(ReasonException.Reason.DynamicImport, getMessage(), null, getUnresolvedRequirements());
/*      */     }
/*      */   }
/*      */   
/*      */   static class FragmentNotSelectedError
/*      */     extends ResolutionError
/*      */   {
/*      */     private final Resource resource;
/*      */     
/*      */     public FragmentNotSelectedError(Resource resource) {
/* 1291 */       this.resource = resource;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/* 1295 */       return "Fragment was not selected for attachment: " + this.resource;
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Requirement> getUnresolvedRequirements() {
/* 1300 */       return this.resource.getRequirements("osgi.wiring.host");
/*      */     }
/*      */ 
/*      */     
/*      */     public ResolutionException toException() {
/* 1305 */       return (ResolutionException)new ReasonException(ReasonException.Reason.FragmentNotSelected, getMessage(), null, getUnresolvedRequirements());
/*      */     }
/*      */   }
/*      */   
/*      */   static class MissingRequirementError
/*      */     extends ResolutionError
/*      */   {
/*      */     private final Requirement requirement;
/*      */     private final ResolutionError cause;
/*      */     
/*      */     public MissingRequirementError(Requirement requirement) {
/* 1316 */       this(requirement, null);
/*      */     }
/*      */     
/*      */     public MissingRequirementError(Requirement requirement, ResolutionError cause) {
/* 1320 */       this.requirement = requirement;
/* 1321 */       this.cause = cause;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/* 1325 */       String msg = "Unable to resolve " + this.requirement.getResource() + 
/* 1326 */         ": missing requirement " + this.requirement;
/* 1327 */       if (this.cause != null)
/*      */       {
/* 1329 */         msg = String.valueOf(msg) + " [caused by: " + this.cause.getMessage() + "]";
/*      */       }
/* 1331 */       return msg;
/*      */     }
/*      */     
/*      */     public Collection<Requirement> getUnresolvedRequirements() {
/* 1335 */       return Collections.singleton(this.requirement);
/*      */     }
/*      */ 
/*      */     
/*      */     public ResolutionException toException() {
/* 1340 */       return (ResolutionException)new ReasonException(
/* 1341 */           ReasonException.Reason.MissingRequirement, getMessage(), (this.cause != null) ? (Throwable)this.cause.toException() : null, getUnresolvedRequirements());
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\Candidates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */