/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedRequirement
/*     */   implements Requirement
/*     */ {
/*     */   private final Resource m_host;
/*     */   private final Requirement m_req;
/*     */   
/*     */   public WrappedRequirement(Resource host, Requirement req) {
/*  33 */     this.m_host = host;
/*  34 */     this.m_req = req;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  40 */     if (obj == null)
/*     */     {
/*  42 */       return false;
/*     */     }
/*  44 */     if (getClass() != obj.getClass())
/*     */     {
/*  46 */       return false;
/*     */     }
/*  48 */     WrappedRequirement other = (WrappedRequirement)obj;
/*  49 */     if (this.m_host != other.m_host && (this.m_host == null || !this.m_host.equals(other.m_host)))
/*     */     {
/*  51 */       return false;
/*     */     }
/*  53 */     if (this.m_req != other.m_req && (this.m_req == null || !this.m_req.equals(other.m_req)))
/*     */     {
/*  55 */       return false;
/*     */     }
/*  57 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  63 */     int hash = 7;
/*  64 */     hash = 37 * hash + ((this.m_host != null) ? this.m_host.hashCode() : 0);
/*  65 */     hash = 37 * hash + ((this.m_req != null) ? this.m_req.hashCode() : 0);
/*  66 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public Requirement getDeclaredRequirement() {
/*  71 */     return this.m_req;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getResource() {
/*  76 */     return this.m_host;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  81 */     return this.m_req.getNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getDirectives() {
/*  86 */     return this.m_req.getDirectives();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  91 */     return this.m_req.getAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     return "[" + this.m_host + "] " + 
/*  98 */       getNamespace() + 
/*  99 */       "; " + 
/* 100 */       (String)getDirectives().get("filter");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\WrappedRequirement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */