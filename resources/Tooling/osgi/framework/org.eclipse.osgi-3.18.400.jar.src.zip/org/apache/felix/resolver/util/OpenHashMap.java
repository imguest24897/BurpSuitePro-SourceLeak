/*      */ package org.apache.felix.resolver.util;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.SortedSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OpenHashMap<K, V>
/*      */   implements Serializable, Cloneable, SortedMap<K, V>
/*      */ {
/*      */   private static final long serialVersionUID = 0L;
/*      */   protected transient Object[] key;
/*      */   protected transient Object[] value;
/*      */   protected transient int mask;
/*      */   protected transient boolean containsNullKey;
/*   62 */   protected transient int first = -1;
/*   63 */   protected transient int last = -1; protected transient long[] link; protected transient int n; protected transient int maxFill; protected int size; protected final float f; public OpenHashMap(int expected, float f) {
/*   64 */     if (f > 0.0F && f <= 1.0F) {
/*   65 */       if (expected < 0) {
/*   66 */         throw new IllegalArgumentException("The expected number of elements must be nonnegative");
/*      */       }
/*   68 */       this.f = f;
/*   69 */       this.n = arraySize(expected, f);
/*   70 */       this.mask = this.n - 1;
/*   71 */       this.maxFill = maxFill(this.n, f);
/*   72 */       this.key = new Object[this.n + 1];
/*   73 */       this.value = new Object[this.n + 1];
/*   74 */       this.link = new long[this.n + 1];
/*      */     } else {
/*      */       
/*   77 */       throw new IllegalArgumentException("Load factor must be greater than 0 and smaller than or equal to 1");
/*      */     } 
/*      */   }
/*      */   protected V defRetValue; protected transient Iterable<Map.Entry<K, V>> fast; protected transient SortedSet<Map.Entry<K, V>> entries; protected transient SortedSet<K> keys; protected transient Collection<V> values;
/*      */   public OpenHashMap(int expected) {
/*   82 */     this(expected, 0.75F);
/*      */   }
/*      */   
/*      */   public OpenHashMap() {
/*   86 */     this(16, 0.75F);
/*      */   }
/*      */   
/*      */   public OpenHashMap(Map<? extends K, ? extends V> m, float f) {
/*   90 */     this(m.size(), f);
/*   91 */     putAll(m);
/*      */   }
/*      */   
/*      */   public OpenHashMap(Map<? extends K, ? extends V> m) {
/*   95 */     this(m, 0.75F);
/*      */   }
/*      */   
/*      */   public OpenHashMap(Object[] k, Object[] v, float f) {
/*   99 */     this(k.length, f);
/*  100 */     if (k.length != v.length) {
/*  101 */       throw new IllegalArgumentException("The key array and the value array have different lengths (" + k.length + " and " + v.length + ")");
/*      */     }
/*  103 */     for (int i = 0; i < k.length; i++) {
/*  104 */       put((K)k[i], (V)v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OpenHashMap(Object[] k, Object[] v) {
/*  111 */     this((K[])k, (V[])v, 0.75F);
/*      */   }
/*      */   
/*      */   public void defaultReturnValue(V rv) {
/*  115 */     this.defRetValue = rv;
/*      */   }
/*      */   
/*      */   public V defaultReturnValue() {
/*  119 */     return this.defRetValue;
/*      */   }
/*      */   
/*      */   public boolean equals(Object o) {
/*  123 */     if (o == this)
/*  124 */       return true; 
/*  125 */     if (!(o instanceof Map)) {
/*  126 */       return false;
/*      */     }
/*  128 */     Map<?, ?> m = (Map<?, ?>)o;
/*  129 */     int n = m.size();
/*  130 */     if (size() != n) {
/*  131 */       return false;
/*      */     }
/*  133 */     Iterator<? extends Map.Entry<?, ?>> i = fast().iterator();
/*  134 */     while (n-- > 0) {
/*  135 */       Map.Entry<?, ?> e = i.next();
/*  136 */       Object k = e.getKey();
/*  137 */       Object v = e.getValue();
/*  138 */       Object v2 = m.get(k);
/*  139 */       if (v == null) {
/*  140 */         if (v2 != null)
/*  141 */           return false;  continue;
/*      */       } 
/*  143 */       if (!v.equals(v2)) {
/*  144 */         return false;
/*      */       }
/*      */     } 
/*  147 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  152 */     StringBuilder s = new StringBuilder();
/*  153 */     Iterator<Map.Entry<K, V>> i = fast().iterator();
/*  154 */     int n = size();
/*  155 */     boolean first = true;
/*  156 */     s.append("{");
/*      */     
/*  158 */     while (n-- != 0) {
/*  159 */       if (first) {
/*  160 */         first = false;
/*      */       } else {
/*  162 */         s.append(", ");
/*      */       } 
/*      */       
/*  165 */       Map.Entry<K, V> e = i.next();
/*  166 */       if (this == e.getKey()) {
/*  167 */         s.append("(this map)");
/*      */       } else {
/*  169 */         s.append(String.valueOf(e.getKey()));
/*      */       } 
/*      */       
/*  172 */       s.append("=>");
/*  173 */       if (this == e.getValue()) {
/*  174 */         s.append("(this map)"); continue;
/*      */       } 
/*  176 */       s.append(String.valueOf(e.getValue()));
/*      */     } 
/*      */ 
/*      */     
/*  180 */     s.append("}");
/*  181 */     return s.toString();
/*      */   }
/*      */   
/*      */   private int realSize() {
/*  185 */     return this.containsNullKey ? (this.size - 1) : this.size;
/*      */   }
/*      */   
/*      */   private void ensureCapacity(int capacity) {
/*  189 */     int needed = arraySize(capacity, this.f);
/*  190 */     if (needed > this.n) {
/*  191 */       rehash(needed);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void tryCapacity(long capacity) {
/*  197 */     int needed = (int)Math.min(1073741824L, Math.max(2L, nextPowerOfTwo((long)Math.ceil(((float)capacity / this.f)))));
/*  198 */     if (needed > this.n) {
/*  199 */       rehash(needed);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private V removeEntry(int pos) {
/*  206 */     Object oldValue = this.value[pos];
/*  207 */     this.value[pos] = null;
/*  208 */     this.size--;
/*  209 */     fixPointers(pos);
/*  210 */     shiftKeys(pos);
/*  211 */     if (this.size < this.maxFill / 4 && this.n > 16) {
/*  212 */       rehash(this.n / 2);
/*      */     }
/*      */     
/*  215 */     return (V)oldValue;
/*      */   }
/*      */ 
/*      */   
/*      */   private V removeNullEntry() {
/*  220 */     this.containsNullKey = false;
/*  221 */     Object oldValue = this.value[this.n];
/*  222 */     this.value[this.n] = null;
/*  223 */     this.size--;
/*  224 */     fixPointers(this.n);
/*  225 */     if (this.size < this.maxFill / 4 && this.n > 16) {
/*  226 */       rehash(this.n / 2);
/*      */     }
/*      */     
/*  229 */     return (V)oldValue;
/*      */   }
/*      */   
/*      */   public void putAll(Map<? extends K, ? extends V> m) {
/*  233 */     if (this.f <= 0.5D) {
/*  234 */       ensureCapacity(m.size());
/*      */     } else {
/*  236 */       tryCapacity((size() + m.size()));
/*      */     } 
/*      */     
/*  239 */     int n = m.size();
/*  240 */     if (m instanceof OpenHashMap) {
/*  241 */       Iterator<? extends Map.Entry<? extends K, ? extends V>> i = ((OpenHashMap)m).fast().iterator();
/*  242 */       while (n-- != 0) {
/*  243 */         Map.Entry<? extends K, ? extends V> e = i.next();
/*  244 */         put(e.getKey(), e.getValue());
/*      */       } 
/*      */     } else {
/*  247 */       Iterator<? extends Map.Entry<? extends K, ? extends V>> i = m.entrySet().iterator();
/*  248 */       while (n-- != 0) {
/*  249 */         Map.Entry<? extends K, ? extends V> e = i.next();
/*  250 */         put(e.getKey(), e.getValue());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private int insert(K k, V v) {
/*      */     int pos;
/*  257 */     if (k == null) {
/*  258 */       if (this.containsNullKey) {
/*  259 */         return this.n;
/*      */       }
/*      */       
/*  262 */       this.containsNullKey = true;
/*  263 */       pos = this.n;
/*      */     } else {
/*  265 */       Object[] key = this.key;
/*      */       Object curr;
/*  267 */       if ((curr = key[pos = mix(k.hashCode()) & this.mask]) != null) {
/*  268 */         if (curr.equals(k)) {
/*  269 */           return pos;
/*      */         }
/*      */         
/*  272 */         while ((curr = key[pos = pos + 1 & this.mask]) != null) {
/*  273 */           if (curr.equals(k)) {
/*  274 */             return pos;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  279 */       key[pos] = k;
/*      */     } 
/*      */     
/*  282 */     this.value[pos] = v;
/*  283 */     if (this.size == 0) {
/*  284 */       this.first = this.last = pos;
/*  285 */       this.link[pos] = -1L;
/*      */     } else {
/*  287 */       this.link[this.last] = this.link[this.last] ^ (this.link[this.last] ^ pos & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  288 */       this.link[pos] = (this.last & 0xFFFFFFFFL) << 32L | 0xFFFFFFFFL;
/*  289 */       this.last = pos;
/*      */     } 
/*      */     
/*  292 */     if (this.size++ >= this.maxFill) {
/*  293 */       rehash(arraySize(this.size + 1, this.f));
/*      */     }
/*      */     
/*  296 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K k, V v) {
/*  301 */     int pos = insert(k, v);
/*  302 */     if (pos < 0) {
/*  303 */       return this.defRetValue;
/*      */     }
/*  305 */     Object oldValue = this.value[pos];
/*  306 */     this.value[pos] = v;
/*  307 */     return (V)oldValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V getOrCompute(K k) {
/*      */     int pos;
/*  314 */     if (k == null) {
/*  315 */       if (this.containsNullKey) {
/*  316 */         return (V)this.value[this.n];
/*      */       }
/*      */       
/*  319 */       this.containsNullKey = true;
/*  320 */       pos = this.n;
/*      */     } else {
/*  322 */       Object[] key = this.key;
/*      */       Object curr;
/*  324 */       if ((curr = key[pos = mix(k.hashCode()) & this.mask]) != null) {
/*  325 */         if (curr.equals(k)) {
/*  326 */           return (V)this.value[pos];
/*      */         }
/*      */         
/*  329 */         while ((curr = key[pos = pos + 1 & this.mask]) != null) {
/*  330 */           if (curr.equals(k)) {
/*  331 */             return (V)this.value[pos];
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  336 */       key[pos] = k;
/*      */     } 
/*      */ 
/*      */     
/*  340 */     Object v = compute(k);
/*  341 */     if (this.size == 0) {
/*  342 */       this.first = this.last = pos;
/*  343 */       this.link[pos] = -1L;
/*      */     } else {
/*  345 */       this.link[this.last] = this.link[this.last] ^ (this.link[this.last] ^ pos & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  346 */       this.link[pos] = (this.last & 0xFFFFFFFFL) << 32L | 0xFFFFFFFFL;
/*  347 */       this.last = pos;
/*      */     } 
/*      */     
/*  350 */     if (this.size++ >= this.maxFill) {
/*  351 */       rehash(arraySize(this.size + 1, this.f));
/*      */     }
/*      */     
/*  354 */     return (V)v;
/*      */   }
/*      */   
/*      */   protected V compute(K k) {
/*  358 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   protected final void shiftKeys(int pos) {
/*      */     int last;
/*  362 */     Object[] key = this.key;
/*      */ 
/*      */     
/*      */     label21: while (true) {
/*  366 */       last = pos;
/*      */       
/*      */       Object curr;
/*  369 */       for (pos = pos + 1 & this.mask; (curr = key[pos]) != null; ) {
/*  370 */         int slot = mix(curr.hashCode()) & this.mask;
/*  371 */         if ((last <= pos) ? (
/*  372 */           last < slot && slot <= pos) : (
/*      */ 
/*      */           
/*  375 */           last < slot || slot <= pos)) {
/*      */           pos = pos + 1 & this.mask;
/*      */           continue;
/*      */         } 
/*  379 */         key[last] = curr;
/*  380 */         this.value[last] = this.value[pos];
/*  381 */         fixPointers(pos, last); continue label21;
/*      */       } 
/*      */       break;
/*      */     } 
/*  385 */     key[last] = null;
/*  386 */     this.value[last] = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V remove(Object k) {
/*  392 */     if (k == null) {
/*  393 */       return this.containsNullKey ? removeNullEntry() : this.defRetValue;
/*      */     }
/*  395 */     Object[] key = this.key;
/*      */     Object curr;
/*      */     int pos;
/*  398 */     if ((curr = key[pos = mix(k.hashCode()) & this.mask]) == null)
/*  399 */       return this.defRetValue; 
/*  400 */     if (k.equals(curr)) {
/*  401 */       return removeEntry(pos);
/*      */     }
/*  403 */     while ((curr = key[pos = pos + 1 & this.mask]) != null) {
/*  404 */       if (k.equals(curr)) {
/*  405 */         return removeEntry(pos);
/*      */       }
/*      */     } 
/*      */     
/*  409 */     return this.defRetValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V removeFirst() {
/*  416 */     if (this.size == 0) {
/*  417 */       throw new NoSuchElementException();
/*      */     }
/*  419 */     int pos = this.first;
/*  420 */     this.first = (int)this.link[pos];
/*  421 */     if (this.first >= 0) {
/*  422 */       this.link[this.first] = this.link[this.first] | 0xFFFFFFFF00000000L;
/*      */     }
/*      */     
/*  425 */     this.size--;
/*  426 */     Object v = this.value[pos];
/*  427 */     if (pos == this.n) {
/*  428 */       this.containsNullKey = false;
/*  429 */       this.value[this.n] = null;
/*      */     } else {
/*  431 */       shiftKeys(pos);
/*      */     } 
/*      */     
/*  434 */     if (this.size < this.maxFill / 4 && this.n > 16) {
/*  435 */       rehash(this.n / 2);
/*      */     }
/*      */     
/*  438 */     return (V)v;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V removeLast() {
/*  444 */     if (this.size == 0) {
/*  445 */       throw new NoSuchElementException();
/*      */     }
/*  447 */     int pos = this.last;
/*  448 */     this.last = (int)(this.link[pos] >>> 32L);
/*  449 */     if (this.last >= 0) {
/*  450 */       this.link[this.last] = this.link[this.last] | 0xFFFFFFFFL;
/*      */     }
/*      */     
/*  453 */     this.size--;
/*  454 */     Object v = this.value[pos];
/*  455 */     if (pos == this.n) {
/*  456 */       this.containsNullKey = false;
/*  457 */       this.value[this.n] = null;
/*      */     } else {
/*  459 */       shiftKeys(pos);
/*      */     } 
/*      */     
/*  462 */     if (this.size < this.maxFill / 4 && this.n > 16) {
/*  463 */       rehash(this.n / 2);
/*      */     }
/*      */     
/*  466 */     return (V)v;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V get(Object k) {
/*  472 */     if (k == null) {
/*  473 */       return this.containsNullKey ? (V)this.value[this.n] : this.defRetValue;
/*      */     }
/*      */     
/*  476 */     Object[] key = this.key;
/*      */     
/*      */     Object curr;
/*      */     
/*      */     int pos;
/*  481 */     if ((curr = key[pos = mix(k.hashCode()) & this.mask]) == null) {
/*  482 */       return this.defRetValue;
/*      */     }
/*  484 */     if (k.equals(curr)) {
/*  485 */       return (V)this.value[pos];
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/*  490 */       if ((curr = key[pos = pos + 1 & this.mask]) == null) {
/*  491 */         return this.defRetValue;
/*      */       }
/*  493 */       if (k.equals(curr)) {
/*  494 */         return (V)this.value[pos];
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean containsKey(Object k) {
/*  500 */     if (k == null) {
/*  501 */       return this.containsNullKey;
/*      */     }
/*  503 */     Object[] key = this.key;
/*      */     Object curr;
/*      */     int pos;
/*  506 */     if ((curr = key[pos = mix(k.hashCode()) & this.mask]) == null)
/*  507 */       return false; 
/*  508 */     if (k.equals(curr)) {
/*  509 */       return true;
/*      */     }
/*  511 */     while ((curr = key[pos = pos + 1 & this.mask]) != null) {
/*  512 */       if (k.equals(curr)) {
/*  513 */         return true;
/*      */       }
/*      */     } 
/*      */     
/*  517 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object v) {
/*  523 */     Object[] value = this.value;
/*  524 */     Object[] key = this.key;
/*  525 */     if ((this.containsNullKey && value[this.n] == null && v == null) || value[this.n].equals(v)) {
/*  526 */       return true;
/*      */     }
/*  528 */     for (int i = this.n; i-- != 0;) {
/*  529 */       if ((key[i] != null && value[i] == null && v == null) || value[i].equals(v)) {
/*  530 */         return true;
/*      */       }
/*      */     } 
/*  533 */     return false;
/*      */   }
/*      */   
/*      */   public void clear() {
/*  537 */     if (this.size != 0) {
/*  538 */       this.size = 0;
/*  539 */       this.containsNullKey = false;
/*  540 */       Arrays.fill(this.key, (Object)null);
/*  541 */       Arrays.fill(this.value, (Object)null);
/*  542 */       this.first = this.last = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int size() {
/*  547 */     return this.size;
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  551 */     return (this.size == 0);
/*      */   }
/*      */   
/*      */   protected void fixPointers(int i) {
/*  555 */     if (this.size == 0) {
/*  556 */       this.first = this.last = -1;
/*  557 */     } else if (this.first == i) {
/*  558 */       this.first = (int)this.link[i];
/*  559 */       if (this.first >= 0) {
/*  560 */         this.link[this.first] = this.link[this.first] | 0xFFFFFFFF00000000L;
/*      */       }
/*  562 */     } else if (this.last == i) {
/*  563 */       this.last = (int)(this.link[i] >>> 32L);
/*  564 */       if (this.last >= 0) {
/*  565 */         this.link[this.last] = this.link[this.last] | 0xFFFFFFFFL;
/*      */       }
/*      */     } else {
/*  568 */       long linki = this.link[i];
/*  569 */       int prev = (int)(linki >>> 32L);
/*  570 */       int next = (int)linki;
/*  571 */       this.link[prev] = this.link[prev] ^ (this.link[prev] ^ linki & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  572 */       this.link[next] = this.link[next] ^ (this.link[next] ^ linki & 0xFFFFFFFF00000000L) & 0xFFFFFFFF00000000L;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void fixPointers(int s, int d) {
/*  577 */     if (this.size == 1) {
/*  578 */       this.first = this.last = d;
/*  579 */       this.link[d] = -1L;
/*  580 */     } else if (this.first == s) {
/*  581 */       this.first = d;
/*  582 */       this.link[(int)this.link[s]] = this.link[(int)this.link[s]] ^ (this.link[(int)this.link[s]] ^ (d & 0xFFFFFFFFL) << 32L) & 0xFFFFFFFF00000000L;
/*  583 */       this.link[d] = this.link[s];
/*  584 */     } else if (this.last == s) {
/*  585 */       this.last = d;
/*  586 */       this.link[(int)(this.link[s] >>> 32L)] = this.link[(int)(this.link[s] >>> 32L)] ^ (this.link[(int)(this.link[s] >>> 32L)] ^ d & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  587 */       this.link[d] = this.link[s];
/*      */     } else {
/*  589 */       long links = this.link[s];
/*  590 */       int prev = (int)(links >>> 32L);
/*  591 */       int next = (int)links;
/*  592 */       this.link[prev] = this.link[prev] ^ (this.link[prev] ^ d & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  593 */       this.link[next] = this.link[next] ^ (this.link[next] ^ (d & 0xFFFFFFFFL) << 32L) & 0xFFFFFFFF00000000L;
/*  594 */       this.link[d] = links;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public K firstKey() {
/*  600 */     if (this.size == 0) {
/*  601 */       throw new NoSuchElementException();
/*      */     }
/*  603 */     return (K)this.key[this.first];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public K lastKey() {
/*  609 */     if (this.size == 0) {
/*  610 */       throw new NoSuchElementException();
/*      */     }
/*  612 */     return (K)this.key[this.last];
/*      */   }
/*      */ 
/*      */   
/*      */   public Comparator<? super K> comparator() {
/*  617 */     return null;
/*      */   }
/*      */   
/*      */   public SortedMap<K, V> tailMap(K from) {
/*  621 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public SortedMap<K, V> headMap(K to) {
/*  625 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public SortedMap<K, V> subMap(K from, K to) {
/*  629 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Iterable<Map.Entry<K, V>> fast() {
/*  633 */     if (this.fast == null) {
/*  634 */       this.fast = new Iterable<Map.Entry<K, V>>() {
/*      */           public Iterator<Map.Entry<K, V>> iterator() {
/*  636 */             return new OpenHashMap.FastEntryIterator();
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*  641 */     return this.fast;
/*      */   }
/*      */   
/*      */   public SortedSet<Map.Entry<K, V>> entrySet() {
/*  645 */     if (this.entries == null) {
/*  646 */       this.entries = new MapEntrySet(null);
/*      */     }
/*      */     
/*  649 */     return this.entries;
/*      */   }
/*      */   
/*      */   public SortedSet<K> keySet() {
/*  653 */     if (this.keys == null) {
/*  654 */       this.keys = new KeySet(null);
/*      */     }
/*      */     
/*  657 */     return this.keys;
/*      */   }
/*      */   
/*      */   public Collection<V> values() {
/*  661 */     if (this.values == null) {
/*  662 */       this.values = new AbstractObjectCollection<V>() {
/*      */           public Iterator<V> iterator() {
/*  664 */             return new OpenHashMap.ValueIterator();
/*      */           }
/*      */           
/*      */           public int size() {
/*  668 */             return OpenHashMap.this.size;
/*      */           }
/*      */           
/*      */           public boolean contains(Object v) {
/*  672 */             return OpenHashMap.this.containsValue(v);
/*      */           }
/*      */           
/*      */           public void clear() {
/*  676 */             OpenHashMap.this.clear();
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*  681 */     return this.values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean trim() {
/*  697 */     int l = arraySize(this.size, this.f);
/*  698 */     if (l >= this.n) {
/*  699 */       return true;
/*      */     }
/*      */     try {
/*  702 */       rehash(l);
/*  703 */       return true;
/*  704 */     } catch (OutOfMemoryError outOfMemoryError) {
/*  705 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean trim(int n) {
/*  729 */     int l = nextPowerOfTwo((int)Math.ceil((n / this.f)));
/*  730 */     if (n <= l) {
/*  731 */       return true;
/*      */     }
/*      */     try {
/*  734 */       rehash(l);
/*  735 */       return true;
/*  736 */     } catch (OutOfMemoryError outOfMemoryError) {
/*  737 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rehash(int newN) {
/*  752 */     Object[] key = this.key;
/*  753 */     Object[] value = this.value;
/*      */     
/*  755 */     int mask = newN - 1;
/*  756 */     Object[] newKey = new Object[newN + 1];
/*  757 */     Object[] newValue = new Object[newN + 1];
/*      */     
/*  759 */     int i = this.first, prev = -1, newPrev = -1;
/*  760 */     long[] link = this.link;
/*  761 */     long[] newLink = new long[newN + 1];
/*  762 */     this.first = -1;
/*      */     
/*  764 */     for (int j = this.size; j-- != 0; ) {
/*  765 */       int pos; if (key[i] == null) {
/*  766 */         pos = newN;
/*      */       } else {
/*  768 */         pos = mix(key[i].hashCode()) & mask;
/*  769 */         while (newKey[pos] != null) {
/*  770 */           pos = pos + 1 & mask;
/*      */         }
/*  772 */         newKey[pos] = key[i];
/*      */       } 
/*      */       
/*  775 */       newValue[pos] = value[i];
/*      */       
/*  777 */       if (prev != -1) {
/*  778 */         newLink[newPrev] = newLink[newPrev] ^ (newLink[newPrev] ^ pos & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  779 */         newLink[pos] = newLink[pos] ^ (newLink[pos] ^ (newPrev & 0xFFFFFFFFL) << 32L) & 0xFFFFFFFF00000000L;
/*  780 */         newPrev = pos;
/*      */       } else {
/*  782 */         newPrev = this.first = pos;
/*  783 */         newLink[pos] = -1L;
/*      */       } 
/*      */       
/*  786 */       int t = i;
/*  787 */       i = (int)link[i];
/*  788 */       prev = t;
/*      */     } 
/*      */     
/*  791 */     this.link = newLink;
/*  792 */     this.last = newPrev;
/*  793 */     if (newPrev != -1) {
/*  794 */       newLink[newPrev] = newLink[newPrev] | 0xFFFFFFFFL;
/*      */     }
/*      */     
/*  797 */     this.n = newN;
/*  798 */     this.mask = mask;
/*  799 */     this.maxFill = maxFill(this.n, this.f);
/*  800 */     this.key = newKey;
/*  801 */     this.value = newValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public OpenHashMap<K, V> clone() {
/*      */     OpenHashMap<K, V> c;
/*      */     try {
/*  808 */       c = (OpenHashMap<K, V>)super.clone();
/*  809 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*  810 */       throw new InternalError();
/*      */     } 
/*      */     
/*  813 */     c.fast = null;
/*  814 */     c.keys = null;
/*  815 */     c.values = null;
/*  816 */     c.entries = null;
/*  817 */     c.containsNullKey = this.containsNullKey;
/*  818 */     c.key = (Object[])this.key.clone();
/*  819 */     c.value = (Object[])this.value.clone();
/*  820 */     c.link = (long[])this.link.clone();
/*  821 */     return c;
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  825 */     int h = 0;
/*  826 */     for (int j = realSize(), i = 0, t = 0; j-- != 0; ) {
/*  827 */       while (this.key[i] == null) {
/*  828 */         i++;
/*      */       }
/*      */       
/*  831 */       if (this != this.key[i]) {
/*  832 */         t = this.key[i].hashCode();
/*      */       }
/*      */       
/*  835 */       if (this != this.value[i]) {
/*  836 */         t ^= (this.value[i] == null) ? 0 : this.value[i].hashCode();
/*      */       }
/*      */       
/*  839 */       h += t;
/*  840 */       i++;
/*      */     } 
/*      */     
/*  843 */     if (this.containsNullKey) {
/*  844 */       h += (this.value[this.n] == null) ? 0 : this.value[this.n].hashCode();
/*      */     }
/*      */     
/*  847 */     return h;
/*      */   }
/*      */   
/*      */   private void writeObject(ObjectOutputStream s) throws IOException {
/*  851 */     Object[] key = this.key;
/*  852 */     Object[] value = this.value;
/*  853 */     MapIterator i = new MapIterator(null, null);
/*  854 */     s.defaultWriteObject();
/*  855 */     int j = this.size;
/*      */     
/*  857 */     while (j-- != 0) {
/*  858 */       int e = i.nextEntry();
/*  859 */       s.writeObject(key[e]);
/*  860 */       s.writeObject(value[e]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/*  866 */     s.defaultReadObject();
/*  867 */     this.n = arraySize(this.size, this.f);
/*  868 */     this.maxFill = maxFill(this.n, this.f);
/*  869 */     this.mask = this.n - 1;
/*  870 */     Object[] key = this.key = new Object[this.n + 1];
/*  871 */     Object[] value = this.value = new Object[this.n + 1];
/*  872 */     long[] link = this.link = new long[this.n + 1];
/*  873 */     int prev = -1;
/*  874 */     this.first = this.last = -1;
/*  875 */     int i = this.size;
/*      */     
/*  877 */     while (i-- != 0) {
/*  878 */       int pos; Object k = s.readObject();
/*  879 */       Object v = s.readObject();
/*      */       
/*  881 */       if (k == null) {
/*  882 */         pos = this.n;
/*  883 */         this.containsNullKey = true;
/*      */       } else {
/*  885 */         for (pos = mix(k.hashCode()) & this.mask; key[pos] != null; pos = pos + 1 & this.mask);
/*      */ 
/*      */ 
/*      */         
/*  889 */         key[pos] = k;
/*      */       } 
/*      */       
/*  892 */       value[pos] = v;
/*  893 */       if (this.first != -1) {
/*  894 */         link[prev] = link[prev] ^ (link[prev] ^ pos & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*  895 */         link[pos] = link[pos] ^ (link[pos] ^ (prev & 0xFFFFFFFFL) << 32L) & 0xFFFFFFFF00000000L;
/*  896 */         prev = pos; continue;
/*      */       } 
/*  898 */       prev = this.first = pos;
/*  899 */       link[pos] = link[pos] | 0xFFFFFFFF00000000L;
/*      */     } 
/*      */ 
/*      */     
/*  903 */     this.last = prev;
/*  904 */     if (prev != -1)
/*  905 */       link[prev] = link[prev] | 0xFFFFFFFFL; 
/*      */   }
/*      */   
/*      */   private final class ValueIterator
/*      */     extends MapIterator
/*      */     implements Iterator<V> {
/*      */     public ValueIterator() {
/*  912 */       super(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public V next() {
/*  917 */       return (V)OpenHashMap.this.value[nextEntry()];
/*      */     }
/*      */   }
/*      */   
/*      */   private final class KeySet
/*      */     extends AbstractObjectSet<K> implements SortedSet<K> {
/*      */     private KeySet() {}
/*      */     
/*      */     public Iterator<K> iterator() {
/*  926 */       return new OpenHashMap.KeyIterator();
/*      */     }
/*      */     
/*      */     public int size() {
/*  930 */       return OpenHashMap.this.size;
/*      */     }
/*      */     
/*      */     public boolean contains(Object k) {
/*  934 */       return OpenHashMap.this.containsKey(k);
/*      */     }
/*      */     
/*      */     public boolean remove(Object k) {
/*  938 */       int oldSize = OpenHashMap.this.size;
/*  939 */       OpenHashMap.this.remove(k);
/*  940 */       return (OpenHashMap.this.size != oldSize);
/*      */     }
/*      */     
/*      */     public void clear() {
/*  944 */       OpenHashMap.this.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public K first() {
/*  949 */       if (OpenHashMap.this.size == 0) {
/*  950 */         throw new NoSuchElementException();
/*      */       }
/*  952 */       return (K)OpenHashMap.this.key[OpenHashMap.this.first];
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public K last() {
/*  958 */       if (OpenHashMap.this.size == 0) {
/*  959 */         throw new NoSuchElementException();
/*      */       }
/*  961 */       return (K)OpenHashMap.this.key[OpenHashMap.this.last];
/*      */     }
/*      */ 
/*      */     
/*      */     public Comparator<? super K> comparator() {
/*  966 */       return null;
/*      */     }
/*      */     
/*      */     public final SortedSet<K> tailSet(K from) {
/*  970 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public final SortedSet<K> headSet(K to) {
/*  974 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public final SortedSet<K> subSet(K from, K to) {
/*  978 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */   private final class KeyIterator extends MapIterator implements Iterator<K> {
/*      */     public KeyIterator() {
/*  984 */       super(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public K next() {
/*  989 */       return (K)OpenHashMap.this.key[nextEntry()];
/*      */     }
/*      */   }
/*      */   
/*      */   private final class MapEntrySet
/*      */     extends AbstractObjectSet<Map.Entry<K, V>> implements SortedSet<Map.Entry<K, V>> {
/*      */     private MapEntrySet() {}
/*      */     
/*      */     public OpenHashMap<K, V>.EntryIterator iterator() {
/*  998 */       return new OpenHashMap.EntryIterator();
/*      */     }
/*      */     
/*      */     public Comparator<? super Map.Entry<K, V>> comparator() {
/* 1002 */       return null;
/*      */     }
/*      */     
/*      */     public SortedSet<Map.Entry<K, V>> subSet(Map.Entry<K, V> fromElement, Map.Entry<K, V> toElement) {
/* 1006 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public SortedSet<Map.Entry<K, V>> headSet(Map.Entry<K, V> toElement) {
/* 1010 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public SortedSet<Map.Entry<K, V>> tailSet(Map.Entry<K, V> fromElement) {
/* 1014 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public Map.Entry<K, V> first() {
/* 1018 */       if (OpenHashMap.this.size == 0) {
/* 1019 */         throw new NoSuchElementException();
/*      */       }
/* 1021 */       return new OpenHashMap.MapEntry(OpenHashMap.this.first);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map.Entry<K, V> last() {
/* 1026 */       if (OpenHashMap.this.size == 0) {
/* 1027 */         throw new NoSuchElementException();
/*      */       }
/* 1029 */       return new OpenHashMap.MapEntry(OpenHashMap.this.last);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/* 1034 */       if (!(o instanceof Map.Entry)) {
/* 1035 */         return false;
/*      */       }
/* 1037 */       Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
/* 1038 */       Object k = e.getKey();
/* 1039 */       if (k == null) {
/* 1040 */         if (OpenHashMap.this.containsNullKey) {
/* 1041 */           if (OpenHashMap.this.value[OpenHashMap.this.n] == null) {
/* 1042 */             if (e.getValue() != null) {
/* 1043 */               return false;
/*      */             }
/* 1045 */           } else if (!OpenHashMap.this.value[OpenHashMap.this.n].equals(e.getValue())) {
/* 1046 */             return false;
/*      */           } 
/*      */           
/* 1049 */           return true;
/*      */         } 
/*      */         
/* 1052 */         return false;
/*      */       } 
/* 1054 */       Object[] key = OpenHashMap.this.key;
/*      */       Object curr;
/*      */       int pos;
/* 1057 */       if ((curr = key[pos = OpenHashMap.mix(k.hashCode()) & OpenHashMap.this.mask]) == null)
/* 1058 */         return false; 
/* 1059 */       if (k.equals(curr)) {
/* 1060 */         return (OpenHashMap.this.value[pos] == null) ? ((e.getValue() == null)) : OpenHashMap.this.value[pos].equals(e.getValue());
/*      */       }
/* 1062 */       while ((curr = key[pos = pos + 1 & OpenHashMap.this.mask]) != null) {
/* 1063 */         if (k.equals(curr)) {
/* 1064 */           return (OpenHashMap.this.value[pos] == null) ? ((e.getValue() == null)) : OpenHashMap.this.value[pos].equals(e.getValue());
/*      */         }
/*      */       } 
/*      */       
/* 1068 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean remove(Object o) {
/* 1075 */       if (!(o instanceof Map.Entry)) {
/* 1076 */         return false;
/*      */       }
/* 1078 */       Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
/* 1079 */       Object k = e.getKey();
/* 1080 */       Object v = e.getValue();
/* 1081 */       if (k == null) {
/* 1082 */         if (OpenHashMap.this.containsNullKey) {
/* 1083 */           if (OpenHashMap.this.value[OpenHashMap.this.n] == null) {
/* 1084 */             if (v != null) {
/* 1085 */               return false;
/*      */             }
/* 1087 */           } else if (!OpenHashMap.this.value[OpenHashMap.this.n].equals(v)) {
/* 1088 */             return false;
/*      */           } 
/*      */           
/* 1091 */           OpenHashMap.this.removeNullEntry();
/* 1092 */           return true;
/*      */         } 
/* 1094 */         return false;
/*      */       } 
/*      */       
/* 1097 */       Object[] key = OpenHashMap.this.key;
/*      */       Object curr;
/*      */       int pos;
/* 1100 */       if ((curr = key[pos = OpenHashMap.mix(k.hashCode()) & OpenHashMap.this.mask]) == null)
/* 1101 */         return false; 
/* 1102 */       if (curr.equals(k)) {
/* 1103 */         if (OpenHashMap.this.value[pos] == null) {
/* 1104 */           if (v != null) {
/* 1105 */             return false;
/*      */           }
/* 1107 */         } else if (!OpenHashMap.this.value[pos].equals(v)) {
/* 1108 */           return false;
/*      */         } 
/*      */         
/* 1111 */         OpenHashMap.this.removeEntry(pos);
/* 1112 */         return true;
/*      */       } 
/*      */       
/*      */       while (true) {
/* 1116 */         if ((curr = key[pos = pos + 1 & OpenHashMap.this.mask]) == null) {
/* 1117 */           return false;
/*      */         }
/* 1119 */         if (curr.equals(k))
/*      */         {
/* 1121 */           if ((OpenHashMap.this.value[pos] == null) ? (
/* 1122 */             v == null) : 
/*      */ 
/*      */             
/* 1125 */             OpenHashMap.this.value[pos].equals(v)) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       } 
/* 1130 */       OpenHashMap.this.removeEntry(pos);
/* 1131 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 1138 */       return OpenHashMap.this.size;
/*      */     }
/*      */     
/*      */     public void clear() {
/* 1142 */       OpenHashMap.this.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   private class FastEntryIterator extends MapIterator implements Iterator<Map.Entry<K, V>> {
/*      */     final OpenHashMap<K, V>.MapEntry entry;
/*      */     
/*      */     public FastEntryIterator() {
/* 1150 */       super(null);
/* 1151 */       this.entry = new OpenHashMap.MapEntry();
/*      */     }
/*      */     
/*      */     public OpenHashMap<K, V>.MapEntry next() {
/* 1155 */       this.entry.index = nextEntry();
/* 1156 */       return this.entry;
/*      */     }
/*      */   }
/*      */   
/*      */   private class EntryIterator extends MapIterator implements Iterator<Map.Entry<K, V>> {
/*      */     private OpenHashMap<K, V>.MapEntry entry;
/*      */     
/*      */     public EntryIterator() {
/* 1164 */       super(null);
/*      */     }
/*      */     
/*      */     public OpenHashMap<K, V>.MapEntry next() {
/* 1168 */       return this.entry = new OpenHashMap.MapEntry(nextEntry());
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1172 */       super.remove();
/* 1173 */       this.entry.index = -1;
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class AbstractObjectSet<K> extends AbstractObjectCollection<K> implements Cloneable {
/*      */     public boolean equals(Object o) {
/* 1179 */       if (o == this)
/* 1180 */         return true; 
/* 1181 */       if (!(o instanceof Set)) {
/* 1182 */         return false;
/*      */       }
/* 1184 */       Set<?> s = (Set)o;
/* 1185 */       return (s.size() == size() && containsAll(s));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1190 */       int h = 0;
/* 1191 */       int n = size();
/*      */ 
/*      */       
/* 1194 */       for (Iterator<K> i = iterator(); n-- != 0; h += (k == null) ? 0 : k.hashCode()) {
/* 1195 */         Object k = i.next();
/*      */       }
/*      */       
/* 1198 */       return h;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class MapIterator
/*      */   {
/* 1206 */     int prev = -1;
/*      */ 
/*      */ 
/*      */     
/* 1210 */     int next = -1;
/*      */ 
/*      */ 
/*      */     
/* 1214 */     int curr = -1;
/*      */ 
/*      */ 
/*      */     
/* 1218 */     int index = -1;
/*      */     
/*      */     private MapIterator() {
/* 1221 */       this.next = OpenHashMap.this.first;
/* 1222 */       this.index = 0;
/*      */     }
/*      */     
/*      */     public boolean hasNext() {
/* 1226 */       return (this.next != -1);
/*      */     }
/*      */     
/*      */     private void ensureIndexKnown() {
/* 1230 */       if (this.index < 0) {
/* 1231 */         if (this.prev == -1) {
/* 1232 */           this.index = 0;
/* 1233 */         } else if (this.next == -1) {
/* 1234 */           this.index = OpenHashMap.this.size;
/*      */         } else {
/* 1236 */           int pos = OpenHashMap.this.first;
/* 1237 */           for (this.index = 1; pos != this.prev; this.index++) {
/* 1238 */             pos = (int)OpenHashMap.this.link[pos];
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public int nextEntry() {
/* 1245 */       if (!hasNext()) {
/* 1246 */         throw new NoSuchElementException();
/*      */       }
/* 1248 */       this.curr = this.next;
/* 1249 */       this.next = (int)OpenHashMap.this.link[this.curr];
/* 1250 */       this.prev = this.curr;
/* 1251 */       if (this.index >= 0) {
/* 1252 */         this.index++;
/*      */       }
/* 1254 */       return this.curr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1259 */       ensureIndexKnown();
/* 1260 */       if (this.curr == -1) throw new IllegalStateException();
/*      */       
/* 1262 */       if (this.curr == this.prev) {
/*      */ 
/*      */         
/* 1265 */         this.index--;
/* 1266 */         this.prev = (int)(OpenHashMap.this.link[this.curr] >>> 32L);
/*      */       } else {
/* 1268 */         this.next = (int)OpenHashMap.this.link[this.curr];
/*      */       } 
/*      */       
/* 1271 */       OpenHashMap.this.size--;
/*      */ 
/*      */       
/* 1274 */       if (this.prev == -1) {
/* 1275 */         OpenHashMap.this.first = this.next;
/*      */       } else {
/* 1277 */         OpenHashMap.this.link[this.prev] = OpenHashMap.this.link[this.prev] ^ (OpenHashMap.this.link[this.prev] ^ this.next & 0xFFFFFFFFL) & 0xFFFFFFFFL;
/*      */       } 
/* 1279 */       if (this.next == -1) {
/* 1280 */         OpenHashMap.this.last = this.prev;
/*      */       } else {
/* 1282 */         OpenHashMap.this.link[this.next] = OpenHashMap.this.link[this.next] ^ (OpenHashMap.this.link[this.next] ^ (this.prev & 0xFFFFFFFFL) << 32L) & 0xFFFFFFFF00000000L;
/*      */       } 
/*      */       
/* 1285 */       int pos = this.curr;
/* 1286 */       this.curr = -1;
/*      */       
/* 1288 */       if (pos == OpenHashMap.this.n) {
/* 1289 */         OpenHashMap.this.containsNullKey = false;
/* 1290 */         OpenHashMap.this.value[OpenHashMap.this.n] = null;
/*      */       } else {
/*      */         
/* 1293 */         Object[] key = OpenHashMap.this.key; while (true) {
/*      */           Object curr;
/*      */           int last;
/* 1296 */           pos = (last = pos) + 1 & OpenHashMap.this.mask;
/*      */           while (true) {
/* 1298 */             if ((curr = key[pos]) == null) {
/* 1299 */               key[last] = null;
/* 1300 */               OpenHashMap.this.value[last] = null;
/*      */               return;
/*      */             } 
/* 1303 */             int slot = OpenHashMap.mix(curr.hashCode()) & OpenHashMap.this.mask;
/* 1304 */             if ((last <= pos) ? (last >= slot || slot > pos) : (last >= slot && slot > pos))
/* 1305 */               break;  pos = pos + 1 & OpenHashMap.this.mask;
/*      */           } 
/* 1307 */           key[last] = curr;
/* 1308 */           OpenHashMap.this.value[last] = OpenHashMap.this.value[pos];
/* 1309 */           if (this.next == pos) this.next = last; 
/* 1310 */           if (this.prev == pos) this.prev = last; 
/* 1311 */           OpenHashMap.this.fixPointers(pos, last);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   final class MapEntry implements Map.Entry<K, V> {
/*      */     int index;
/*      */     
/*      */     MapEntry(int index) {
/* 1321 */       this.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     MapEntry() {}
/*      */ 
/*      */     
/*      */     public K getKey() {
/* 1329 */       return (K)OpenHashMap.this.key[this.index];
/*      */     }
/*      */ 
/*      */     
/*      */     public V getValue() {
/* 1334 */       return (V)OpenHashMap.this.value[this.index];
/*      */     }
/*      */ 
/*      */     
/*      */     public V setValue(V v) {
/* 1339 */       Object oldValue = OpenHashMap.this.value[this.index];
/* 1340 */       OpenHashMap.this.value[this.index] = v;
/* 1341 */       return (V)oldValue;
/*      */     }
/*      */     
/*      */     public boolean equals(Object o) {
/* 1345 */       if (!(o instanceof Map.Entry)) {
/* 1346 */         return false;
/*      */       }
/* 1348 */       Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
/* 1349 */       if (OpenHashMap.this.key[this.index] == null) {
/* 1350 */         if (e.getKey() != null) {
/* 1351 */           return false;
/*      */         }
/* 1353 */       } else if (!OpenHashMap.this.key[this.index].equals(e.getKey())) {
/* 1354 */         return false;
/*      */       } 
/*      */       
/* 1357 */       if (OpenHashMap.this.value[this.index] == null) {
/* 1358 */         if (e.getValue() != null) {
/* 1359 */           return false;
/*      */         }
/* 1361 */       } else if (!OpenHashMap.this.value[this.index].equals(e.getValue())) {
/* 1362 */         return false;
/*      */       } 
/*      */       
/* 1365 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1370 */       return ((OpenHashMap.this.key[this.index] == null) ? 0 : 
/* 1371 */         OpenHashMap.this.key[this.index].hashCode()) ^ ((OpenHashMap.this.value[this.index] == null) ? 0 : 
/* 1372 */         OpenHashMap.this.value[this.index].hashCode());
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1376 */       return OpenHashMap.this.key[this.index] + "=>" + OpenHashMap.this.value[this.index];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractObjectCollection<K>
/*      */     extends AbstractCollection<K>
/*      */   {
/*      */     public Object[] toArray() {
/* 1386 */       Object[] a = new Object[size()];
/* 1387 */       OpenHashMap.unwrap(iterator(), (K[])a);
/* 1388 */       return a;
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(Object[] a) {
/* 1393 */       if (a.length < size()) {
/* 1394 */         a = (Object[])Array.newInstance(a.getClass().getComponentType(), size());
/*      */       }
/* 1396 */       OpenHashMap.unwrap(iterator(), (K[])a);
/* 1397 */       return (T[])a;
/*      */     }
/*      */     
/*      */     public boolean addAll(Collection<? extends K> c) {
/* 1401 */       boolean retVal = false;
/* 1402 */       Iterator<? extends K> i = c.iterator();
/* 1403 */       int n = c.size();
/*      */       
/* 1405 */       while (n-- != 0) {
/* 1406 */         if (add(i.next())) {
/* 1407 */           retVal = true;
/*      */         }
/*      */       } 
/*      */       
/* 1411 */       return retVal;
/*      */     }
/*      */     
/*      */     public boolean add(K k) {
/* 1415 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*      */     public boolean containsAll(Collection<?> c) {
/* 1419 */       int n = c.size();
/* 1420 */       Iterator<?> i = c.iterator();
/*      */       
/*      */       do {
/* 1423 */         if (n-- == 0) {
/* 1424 */           return true;
/*      */         }
/* 1426 */       } while (contains(i.next()));
/*      */       
/* 1428 */       return false;
/*      */     }
/*      */     
/*      */     public boolean retainAll(Collection<?> c) {
/* 1432 */       boolean retVal = false;
/* 1433 */       int n = size();
/* 1434 */       Iterator<K> i = iterator();
/*      */       
/* 1436 */       while (n-- != 0) {
/* 1437 */         if (!c.contains(i.next())) {
/* 1438 */           i.remove();
/* 1439 */           retVal = true;
/*      */         } 
/*      */       } 
/*      */       
/* 1443 */       return retVal;
/*      */     }
/*      */     
/*      */     public boolean removeAll(Collection<?> c) {
/* 1447 */       boolean retVal = false;
/* 1448 */       int n = c.size();
/* 1449 */       Iterator<?> i = c.iterator();
/*      */       
/* 1451 */       while (n-- != 0) {
/* 1452 */         if (remove(i.next())) {
/* 1453 */           retVal = true;
/*      */         }
/*      */       } 
/*      */       
/* 1457 */       return retVal;
/*      */     }
/*      */     
/*      */     public boolean isEmpty() {
/* 1461 */       return (size() == 0);
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1465 */       StringBuilder s = new StringBuilder();
/* 1466 */       Iterator<K> i = iterator();
/* 1467 */       int n = size();
/* 1468 */       boolean first = true;
/* 1469 */       s.append("{");
/*      */       
/* 1471 */       while (n-- != 0) {
/* 1472 */         if (first) {
/* 1473 */           first = false;
/*      */         } else {
/* 1475 */           s.append(", ");
/*      */         } 
/*      */         
/* 1478 */         Object k = i.next();
/* 1479 */         if (this == k) {
/* 1480 */           s.append("(this collection)"); continue;
/*      */         } 
/* 1482 */         s.append(String.valueOf(k));
/*      */       } 
/*      */ 
/*      */       
/* 1486 */       s.append("}");
/* 1487 */       return s.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static int arraySize(int expected, float f) {
/* 1492 */     long s = Math.max(2L, nextPowerOfTwo((long)Math.ceil((expected / f))));
/* 1493 */     if (s > 1073741824L) {
/* 1494 */       throw new IllegalArgumentException("Too large (" + expected + " expected elements with load factor " + f + ")");
/*      */     }
/* 1496 */     return (int)s;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int maxFill(int n, float f) {
/* 1501 */     return Math.min((int)Math.ceil((n * f)), n - 1);
/*      */   }
/*      */   
/*      */   private static int nextPowerOfTwo(int x) {
/* 1505 */     if (x == 0) {
/* 1506 */       return 1;
/*      */     }
/* 1508 */     x--;
/* 1509 */     x |= x >> 1;
/* 1510 */     x |= x >> 2;
/* 1511 */     x |= x >> 4;
/* 1512 */     x |= x >> 8;
/* 1513 */     return (x | x >> 16) + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   private static long nextPowerOfTwo(long x) {
/* 1518 */     if (x == 0L) {
/* 1519 */       return 1L;
/*      */     }
/* 1521 */     x--;
/* 1522 */     x |= x >> 1L;
/* 1523 */     x |= x >> 2L;
/* 1524 */     x |= x >> 4L;
/* 1525 */     x |= x >> 8L;
/* 1526 */     x |= x >> 16L;
/* 1527 */     return (x | x >> 32L) + 1L;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int mix(int x) {
/* 1532 */     int h = x * -1640531527;
/* 1533 */     return h ^ h >>> 16;
/*      */   }
/*      */   
/*      */   private static <K> int unwrap(Iterator<? extends K> i, Object[] array, int offset, int max) {
/* 1537 */     if (max < 0)
/* 1538 */       throw new IllegalArgumentException("The maximum number of elements (" + max + ") is negative"); 
/* 1539 */     if (offset >= 0 && offset + max <= array.length) {
/*      */       int j;
/* 1541 */       for (j = max; j-- != 0 && i.hasNext(); array[offset++] = i.next());
/*      */ 
/*      */ 
/*      */       
/* 1545 */       return max - j - 1;
/*      */     } 
/* 1547 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */   
/*      */   private static <K> int unwrap(Iterator<? extends K> i, Object[] array) {
/* 1552 */     return unwrap(i, (K[])array, 0, array.length);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\OpenHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */