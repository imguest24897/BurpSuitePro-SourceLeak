/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import org.osgi.resource.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logger
/*     */ {
/*     */   public static final int LOG_ERROR = 1;
/*     */   public static final int LOG_WARNING = 2;
/*     */   public static final int LOG_INFO = 3;
/*     */   public static final int LOG_DEBUG = 4;
/*  49 */   private int m_logLevel = 1;
/*     */ 
/*     */   
/*     */   public Logger(int i) {
/*  53 */     this.m_logLevel = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void setLogLevel(int i) {
/*  58 */     this.m_logLevel = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized int getLogLevel() {
/*  63 */     return this.m_logLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void log(int level, String msg) {
/*  68 */     _log(level, msg, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void log(int level, String msg, Throwable throwable) {
/*  73 */     _log(level, msg, throwable);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  78 */     return (this.m_logLevel >= 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void debug(String msg) {
/*  83 */     _log(4, msg, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doLog(int level, String msg, Throwable throwable) {
/*  88 */     if (level > this.m_logLevel) {
/*     */       return;
/*     */     }
/*     */     
/*  92 */     String s = msg;
/*  93 */     if (throwable != null)
/*     */     {
/*  95 */       s = String.valueOf(s) + " (" + throwable + ")";
/*     */     }
/*  97 */     switch (level) {
/*     */       
/*     */       case 4:
/* 100 */         System.out.println("DEBUG: " + s);
/*     */         return;
/*     */       case 1:
/* 103 */         System.out.println("ERROR: " + s);
/* 104 */         if (throwable != null)
/*     */         {
/* 106 */           throwable.printStackTrace();
/*     */         }
/*     */         return;
/*     */       case 3:
/* 110 */         System.out.println("INFO: " + s);
/*     */         return;
/*     */       case 2:
/* 113 */         System.out.println("WARNING: " + s);
/*     */         return;
/*     */     } 
/* 116 */     System.out.println("UNKNOWN[" + level + "]: " + s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _log(int level, String msg, Throwable throwable) {
/* 124 */     if (this.m_logLevel >= level)
/*     */     {
/* 126 */       doLog(level, msg, throwable);
/*     */     }
/*     */   }
/*     */   
/*     */   public void logUsesConstraintViolation(Resource resource, ResolutionError error) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */