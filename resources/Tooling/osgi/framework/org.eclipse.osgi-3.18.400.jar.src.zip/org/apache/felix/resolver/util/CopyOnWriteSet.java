/*     */ package org.apache.felix.resolver.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyOnWriteSet<E>
/*     */   implements Set<E>, Cloneable
/*     */ {
/*     */   Object[] data;
/*     */   
/*     */   public CopyOnWriteSet() {
/*  32 */     this.data = new Object[0];
/*     */   }
/*     */   
/*     */   public CopyOnWriteSet(CopyOnWriteSet<? extends E> col) {
/*  36 */     this.data = col.data;
/*     */   }
/*     */   
/*     */   public CopyOnWriteSet(Collection<? extends E> col) {
/*  40 */     this.data = col.toArray(new Object[col.size()]);
/*     */   }
/*     */   
/*     */   public Iterator<E> iterator() {
/*  44 */     return new Iterator<E>() {
/*  45 */         int idx = 0;
/*     */         public boolean hasNext() {
/*  47 */           return (this.idx < CopyOnWriteSet.this.data.length);
/*     */         }
/*     */         
/*     */         public E next() {
/*  51 */           return (E)CopyOnWriteSet.this.data[this.idx++];
/*     */         }
/*     */         public void remove() {
/*  54 */           CopyOnWriteSet.this.remove(--this.idx);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public int size() {
/*  60 */     return this.data.length;
/*     */   }
/*     */   
/*     */   public boolean add(E e) {
/*  64 */     Object[] d = this.data;
/*  65 */     if (d.length == 0) {
/*  66 */       this.data = new Object[] { e };
/*     */     } else {
/*  68 */       byte b; int i; Object[] arrayOfObject1; for (i = (arrayOfObject1 = d).length, b = 0; b < i; ) { Object o = arrayOfObject1[b];
/*  69 */         if ((o == null) ? (e == null) : o.equals(e))
/*  70 */           return false; 
/*     */         b++; }
/*     */       
/*  73 */       Object[] a = new Object[d.length + 1];
/*  74 */       System.arraycopy(d, 0, a, 0, d.length);
/*  75 */       a[d.length] = e;
/*  76 */       this.data = a;
/*     */     } 
/*  78 */     return true;
/*     */   }
/*     */   
/*     */   private void remove(int index) {
/*  82 */     Object[] d = this.data;
/*  83 */     int len = d.length;
/*  84 */     Object[] a = new Object[len - 1];
/*  85 */     int numMoved = len - index - 1;
/*  86 */     if (index > 0) {
/*  87 */       System.arraycopy(d, 0, a, 0, index);
/*     */     }
/*  89 */     if (numMoved > 0) {
/*  90 */       System.arraycopy(d, index + 1, a, index, numMoved);
/*     */     }
/*  92 */     this.data = a;
/*     */   }
/*     */   
/*     */   public Object[] toArray() {
/*  96 */     return (Object[])this.data.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(Object[] a) {
/* 101 */     int size = this.data.length;
/* 102 */     if (a.length < size)
/*     */     {
/* 104 */       return copyOf(this.data, size, (Class)a.getClass()); } 
/* 105 */     System.arraycopy(this.data, 0, a, 0, size);
/* 106 */     if (a.length > size)
/* 107 */       a[size] = null; 
/* 108 */     return (T[])a;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 113 */     if (!(o instanceof CopyOnWriteSet)) {
/* 114 */       return false;
/*     */     }
/* 116 */     Object[] o1 = this.data;
/*     */     
/* 118 */     Object[] o2 = ((CopyOnWriteSet)o).data;
/* 119 */     if (o1 == o2) {
/* 120 */       return true;
/*     */     }
/* 122 */     int l = o1.length;
/* 123 */     if (l != o2.length) {
/* 124 */       return false;
/*     */     }
/*     */     
/* 127 */     for (int i = l; i-- > 0; ) {
/* 128 */       Object v2, v1 = o1[i];
/* 129 */       int j = l; do { if (j-- <= 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 136 */           return false; }  v2 = o2[j]; if (v1 == v2)
/*     */           break;  } while (v1 == null || !v1.equals(v2));
/* 138 */     }  return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 143 */     return Arrays.hashCode(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteSet<E> clone() {
/*     */     try {
/* 155 */       return (CopyOnWriteSet<E>)super.clone();
/* 156 */     } catch (CloneNotSupportedException exc) {
/* 157 */       InternalError e = new InternalError();
/* 158 */       e.initCause(exc);
/* 159 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 164 */     return (size() == 0);
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/* 168 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/*     */     int index;
/* 173 */     if ((index = indexOf(o, this.data, this.data.length)) >= 0) {
/* 174 */       remove(index);
/* 175 */       return true;
/*     */     } 
/* 177 */     return false;
/*     */   }
/*     */   
/*     */   private static int indexOf(Object o, Object[] d, int len) {
/* 181 */     if (o == null) {
/* 182 */       for (int i = len; i-- > 0;) {
/* 183 */         if (d[i] == null)
/* 184 */           return i; 
/*     */       } 
/*     */     } else {
/* 187 */       for (int i = len; i-- > 0;) {
/* 188 */         if (o.equals(d[i]))
/* 189 */           return i; 
/*     */       } 
/*     */     } 
/* 192 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 196 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection<? extends E> c) {
/* 200 */     Object[] cs = c.toArray();
/* 201 */     if (cs.length == 0)
/* 202 */       return false; 
/* 203 */     Object[] elements = this.data;
/* 204 */     int len = elements.length;
/* 205 */     int added = 0;
/*     */     
/* 207 */     for (int i = 0; i < cs.length; i++) {
/* 208 */       Object e = cs[i];
/* 209 */       if (indexOf(e, elements, len) < 0 && 
/* 210 */         indexOf(e, cs, added) < 0)
/* 211 */         cs[added++] = e; 
/*     */     } 
/* 213 */     if (added > 0) {
/* 214 */       Object[] newElements = copyOf(elements, len + added);
/* 215 */       System.arraycopy(cs, 0, newElements, len, added);
/* 216 */       this.data = newElements;
/* 217 */       return true;
/*     */     } 
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 223 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 227 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 231 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T[] copyOf(Object[] original, int newLength) {
/* 236 */     return copyOf(original, newLength, (Class)original.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T, U> T[] copyOf(Object[] original, int newLength, Class<? extends T[]> newType) {
/*     */     Object[] copy;
/* 242 */     if (newType == Object[].class) {
/* 243 */       copy = new Object[newLength];
/*     */     } else {
/* 245 */       copy = (Object[])Array.newInstance(newType.getComponentType(), newLength);
/*     */     } 
/* 247 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
/* 248 */     return (T[])copy;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\framework\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\CopyOnWriteSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */