package burp.api.montoya;

import burp.api.montoya.burpsuite.BurpSuite;
import burp.api.montoya.collaborator.Collaborator;
import burp.api.montoya.comparer.Comparer;
import burp.api.montoya.decoder.Decoder;
import burp.api.montoya.extension.Extension;
import burp.api.montoya.http.Http;
import burp.api.montoya.intruder.Intruder;
import burp.api.montoya.logging.Logging;
import burp.api.montoya.organizer.Organizer;
import burp.api.montoya.persistence.Persistence;
import burp.api.montoya.project.Project;
import burp.api.montoya.proxy.Proxy;
import burp.api.montoya.repeater.Repeater;
import burp.api.montoya.scanner.Scanner;
import burp.api.montoya.scope.Scope;
import burp.api.montoya.sitemap.SiteMap;
import burp.api.montoya.ui.UserInterface;
import burp.api.montoya.utilities.Utilities;
import burp.api.montoya.websocket.WebSockets;

public interface MontoyaApi {
  BurpSuite burpSuite();
  
  Collaborator collaborator();
  
  Comparer comparer();
  
  Decoder decoder();
  
  Extension extension();
  
  Http http();
  
  Intruder intruder();
  
  Logging logging();
  
  Organizer organizer();
  
  Persistence persistence();
  
  Project project();
  
  Proxy proxy();
  
  Repeater repeater();
  
  Scanner scanner();
  
  Scope scope();
  
  SiteMap siteMap();
  
  UserInterface userInterface();
  
  Utilities utilities();
  
  WebSockets websockets();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\MontoyaApi.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */