package burp.api.montoya.scope;

import burp.api.montoya.core.Registration;

public interface Scope {
  boolean isInScope(String paramString);
  
  void includeInScope(String paramString);
  
  void excludeFromScope(String paramString);
  
  Registration registerScopeChangeHandler(ScopeChangeHandler paramScopeChangeHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scope\Scope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */