package burp.api.montoya.internal;

import burp.api.montoya.collaborator.InteractionFilter;
import burp.api.montoya.collaborator.SecretKey;
import burp.api.montoya.core.Annotations;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.HighlightColor;
import burp.api.montoya.core.Marker;
import burp.api.montoya.core.Range;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.RequestOptions;
import burp.api.montoya.http.handler.RequestToBeSentAction;
import burp.api.montoya.http.handler.ResponseReceivedAction;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.params.HttpParameter;
import burp.api.montoya.http.message.params.HttpParameterType;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.sessions.ActionResult;
import burp.api.montoya.intruder.GeneratedPayload;
import burp.api.montoya.intruder.HttpRequestTemplate;
import burp.api.montoya.intruder.HttpRequestTemplateGenerationOptions;
import burp.api.montoya.intruder.PayloadProcessingAction;
import burp.api.montoya.intruder.PayloadProcessingResult;
import burp.api.montoya.persistence.PersistedList;
import burp.api.montoya.persistence.PersistedObject;
import burp.api.montoya.proxy.MessageReceivedAction;
import burp.api.montoya.proxy.MessageToBeSentAction;
import burp.api.montoya.proxy.http.ProxyRequestReceivedAction;
import burp.api.montoya.proxy.http.ProxyRequestToBeSentAction;
import burp.api.montoya.proxy.http.ProxyResponseReceivedAction;
import burp.api.montoya.proxy.http.ProxyResponseToBeSentAction;
import burp.api.montoya.proxy.websocket.BinaryMessageReceivedAction;
import burp.api.montoya.proxy.websocket.BinaryMessageToBeSentAction;
import burp.api.montoya.proxy.websocket.TextMessageReceivedAction;
import burp.api.montoya.proxy.websocket.TextMessageToBeSentAction;
import burp.api.montoya.scanner.AuditConfiguration;
import burp.api.montoya.scanner.AuditResult;
import burp.api.montoya.scanner.BuiltInAuditConfiguration;
import burp.api.montoya.scanner.CrawlConfiguration;
import burp.api.montoya.scanner.audit.insertionpoint.AuditInsertionPoint;
import burp.api.montoya.scanner.audit.issues.AuditIssue;
import burp.api.montoya.scanner.audit.issues.AuditIssueConfidence;
import burp.api.montoya.scanner.audit.issues.AuditIssueDefinition;
import burp.api.montoya.scanner.audit.issues.AuditIssueSeverity;
import burp.api.montoya.sitemap.SiteMapFilter;
import burp.api.montoya.ui.Selection;
import burp.api.montoya.ui.menu.BasicMenuItem;
import burp.api.montoya.ui.menu.Menu;
import burp.api.montoya.utilities.json.JsonArrayNode;
import burp.api.montoya.utilities.json.JsonBooleanNode;
import burp.api.montoya.utilities.json.JsonNode;
import burp.api.montoya.utilities.json.JsonNullNode;
import burp.api.montoya.utilities.json.JsonNumberNode;
import burp.api.montoya.utilities.json.JsonObjectNode;
import burp.api.montoya.utilities.json.JsonStringNode;
import burp.api.montoya.websocket.BinaryMessageAction;
import burp.api.montoya.websocket.MessageAction;
import burp.api.montoya.websocket.TextMessageAction;
import java.util.List;
import java.util.Map;

public interface MontoyaObjectFactory {
  HttpService httpService(String paramString);
  
  HttpService httpService(String paramString, boolean paramBoolean);
  
  HttpService httpService(String paramString, int paramInt, boolean paramBoolean);
  
  HttpHeader httpHeader(String paramString1, String paramString2);
  
  HttpHeader httpHeader(String paramString);
  
  HttpParameter parameter(String paramString1, String paramString2, HttpParameterType paramHttpParameterType);
  
  HttpRequest httpRequest();
  
  HttpRequest httpRequest(ByteArray paramByteArray);
  
  HttpRequest httpRequest(String paramString);
  
  HttpRequest httpRequest(HttpService paramHttpService, ByteArray paramByteArray);
  
  HttpRequest httpRequest(HttpService paramHttpService, String paramString);
  
  HttpRequest http2Request(HttpService paramHttpService, List<HttpHeader> paramList, String paramString);
  
  HttpRequest http2Request(HttpService paramHttpService, List<HttpHeader> paramList, ByteArray paramByteArray);
  
  HttpRequest httpRequestFromUrl(String paramString);
  
  HttpResponse httpResponse();
  
  HttpResponse httpResponse(String paramString);
  
  HttpResponse httpResponse(ByteArray paramByteArray);
  
  HttpRequestResponse httpRequestResponse(HttpRequest paramHttpRequest, HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  HttpRequestResponse httpRequestResponse(HttpRequest paramHttpRequest, HttpResponse paramHttpResponse);
  
  Range range(int paramInt1, int paramInt2);
  
  Annotations annotations();
  
  Annotations annotations(String paramString);
  
  Annotations annotations(HighlightColor paramHighlightColor);
  
  Annotations annotations(String paramString, HighlightColor paramHighlightColor);
  
  AuditInsertionPoint auditInsertionPoint(String paramString, HttpRequest paramHttpRequest, int paramInt1, int paramInt2);
  
  AuditIssueDefinition auditIssueDefinition(String paramString1, String paramString2, String paramString3, AuditIssueSeverity paramAuditIssueSeverity);
  
  AuditIssue auditIssue(String paramString1, String paramString2, String paramString3, String paramString4, AuditIssueSeverity paramAuditIssueSeverity1, AuditIssueConfidence paramAuditIssueConfidence, String paramString5, String paramString6, AuditIssueSeverity paramAuditIssueSeverity2, List<HttpRequestResponse> paramList);
  
  AuditIssue auditIssue(String paramString1, String paramString2, String paramString3, String paramString4, AuditIssueSeverity paramAuditIssueSeverity1, AuditIssueConfidence paramAuditIssueConfidence, String paramString5, String paramString6, AuditIssueSeverity paramAuditIssueSeverity2, HttpRequestResponse... paramVarArgs);
  
  Selection selection(ByteArray paramByteArray);
  
  Selection selection(int paramInt1, int paramInt2);
  
  Selection selection(ByteArray paramByteArray, int paramInt1, int paramInt2);
  
  SecretKey secretKey(String paramString);
  
  ProxyRequestReceivedAction proxyRequestReceivedAction(HttpRequest paramHttpRequest, Annotations paramAnnotations, MessageReceivedAction paramMessageReceivedAction);
  
  ProxyRequestToBeSentAction proxyRequestToBeSentAction(HttpRequest paramHttpRequest, Annotations paramAnnotations, MessageToBeSentAction paramMessageToBeSentAction);
  
  ProxyResponseToBeSentAction proxyResponseToReturnAction(HttpResponse paramHttpResponse, Annotations paramAnnotations, MessageToBeSentAction paramMessageToBeSentAction);
  
  ProxyResponseReceivedAction proxyResponseReceivedAction(HttpResponse paramHttpResponse, Annotations paramAnnotations, MessageReceivedAction paramMessageReceivedAction);
  
  RequestToBeSentAction requestResult(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  ResponseReceivedAction responseResult(HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  HttpRequestTemplate httpRequestTemplate(ByteArray paramByteArray, List<Range> paramList);
  
  HttpRequestTemplate httpRequestTemplate(HttpRequest paramHttpRequest, List<Range> paramList);
  
  HttpRequestTemplate httpRequestTemplate(ByteArray paramByteArray, HttpRequestTemplateGenerationOptions paramHttpRequestTemplateGenerationOptions);
  
  HttpRequestTemplate httpRequestTemplate(HttpRequest paramHttpRequest, HttpRequestTemplateGenerationOptions paramHttpRequestTemplateGenerationOptions);
  
  PayloadProcessingResult payloadProcessingResult(ByteArray paramByteArray, PayloadProcessingAction paramPayloadProcessingAction);
  
  InteractionFilter interactionIdFilter(String paramString);
  
  InteractionFilter interactionPayloadFilter(String paramString);
  
  SiteMapFilter prefixFilter(String paramString);
  
  Marker marker(Range paramRange);
  
  Marker marker(int paramInt1, int paramInt2);
  
  ByteArray byteArrayOfLength(int paramInt);
  
  ByteArray byteArray(byte[] paramArrayOfbyte);
  
  ByteArray byteArray(int[] paramArrayOfint);
  
  ByteArray byteArray(String paramString);
  
  TextMessageAction continueWithTextMessage(String paramString);
  
  TextMessageAction dropTextMessage();
  
  TextMessageAction textMessageAction(String paramString, MessageAction paramMessageAction);
  
  BinaryMessageAction continueWithBinaryMessage(ByteArray paramByteArray);
  
  BinaryMessageAction dropBinaryMessage();
  
  BinaryMessageAction binaryMessageAction(ByteArray paramByteArray, MessageAction paramMessageAction);
  
  BinaryMessageReceivedAction followUserRulesInitialProxyBinaryMessage(ByteArray paramByteArray);
  
  TextMessageReceivedAction followUserRulesInitialProxyTextMessage(String paramString);
  
  BinaryMessageReceivedAction interceptInitialProxyBinaryMessage(ByteArray paramByteArray);
  
  TextMessageReceivedAction interceptInitialProxyTextMessage(String paramString);
  
  BinaryMessageReceivedAction dropInitialProxyBinaryMessage();
  
  TextMessageReceivedAction dropInitialProxyTextMessage();
  
  BinaryMessageReceivedAction doNotInterceptInitialProxyBinaryMessage(ByteArray paramByteArray);
  
  TextMessageReceivedAction doNotInterceptInitialProxyTextMessage(String paramString);
  
  BinaryMessageToBeSentAction continueWithFinalProxyBinaryMessage(ByteArray paramByteArray);
  
  TextMessageToBeSentAction continueWithFinalProxyTextMessage(String paramString);
  
  BinaryMessageToBeSentAction dropFinalProxyBinaryMessage();
  
  TextMessageToBeSentAction dropFinalProxyTextMessage();
  
  PersistedObject persistedObject();
  
  PersistedList<Boolean> persistedBooleanList();
  
  PersistedList<Short> persistedShortList();
  
  PersistedList<Integer> persistedIntegerList();
  
  PersistedList<Long> persistedLongList();
  
  PersistedList<String> persistedStringList();
  
  PersistedList<ByteArray> persistedByteArrayList();
  
  PersistedList<HttpRequest> persistedHttpRequestList();
  
  PersistedList<HttpResponse> persistedHttpResponseList();
  
  PersistedList<HttpRequestResponse> persistedHttpRequestResponseList();
  
  AuditResult auditResult(List<AuditIssue> paramList);
  
  AuditResult auditResult(AuditIssue... paramVarArgs);
  
  AuditConfiguration auditConfiguration(BuiltInAuditConfiguration paramBuiltInAuditConfiguration);
  
  CrawlConfiguration crawlConfiguration(String... paramVarArgs);
  
  HttpParameter urlParameter(String paramString1, String paramString2);
  
  HttpParameter bodyParameter(String paramString1, String paramString2);
  
  HttpParameter cookieParameter(String paramString1, String paramString2);
  
  GeneratedPayload payload(String paramString);
  
  GeneratedPayload payload(ByteArray paramByteArray);
  
  GeneratedPayload payloadEnd();
  
  PayloadProcessingResult usePayload(ByteArray paramByteArray);
  
  PayloadProcessingResult skipPayload();
  
  ProxyRequestToBeSentAction requestFinalInterceptResultContinueWith(HttpRequest paramHttpRequest);
  
  ProxyRequestToBeSentAction requestFinalInterceptResultContinueWith(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  ProxyRequestToBeSentAction requestFinalInterceptResultDrop();
  
  ProxyResponseToBeSentAction responseFinalInterceptResultDrop();
  
  ProxyResponseToBeSentAction responseFinalInterceptResultContinueWith(HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  ProxyResponseToBeSentAction responseFinalInterceptResultContinueWith(HttpResponse paramHttpResponse);
  
  ProxyResponseReceivedAction responseInitialInterceptResultIntercept(HttpResponse paramHttpResponse);
  
  ProxyResponseReceivedAction responseInitialInterceptResultIntercept(HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  ProxyResponseReceivedAction responseInitialInterceptResultDoNotIntercept(HttpResponse paramHttpResponse);
  
  ProxyResponseReceivedAction responseInitialInterceptResultDoNotIntercept(HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  ProxyResponseReceivedAction responseInitialInterceptResultFollowUserRules(HttpResponse paramHttpResponse);
  
  ProxyResponseReceivedAction responseInitialInterceptResultFollowUserRules(HttpResponse paramHttpResponse, Annotations paramAnnotations);
  
  ProxyResponseReceivedAction responseInitialInterceptResultDrop();
  
  ProxyRequestReceivedAction requestInitialInterceptResultIntercept(HttpRequest paramHttpRequest);
  
  ProxyRequestReceivedAction requestInitialInterceptResultIntercept(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  ProxyRequestReceivedAction requestInitialInterceptResultDoNotIntercept(HttpRequest paramHttpRequest);
  
  ProxyRequestReceivedAction requestInitialInterceptResultDoNotIntercept(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  ProxyRequestReceivedAction requestInitialInterceptResultFollowUserRules(HttpRequest paramHttpRequest);
  
  ProxyRequestReceivedAction requestInitialInterceptResultFollowUserRules(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  ProxyRequestReceivedAction requestInitialInterceptResultDrop();
  
  ResponseReceivedAction responseResult(HttpResponse paramHttpResponse);
  
  RequestToBeSentAction requestResult(HttpRequest paramHttpRequest);
  
  HighlightColor highlightColor(String paramString);
  
  ActionResult actionResult(HttpRequest paramHttpRequest);
  
  ActionResult actionResult(HttpRequest paramHttpRequest, Annotations paramAnnotations);
  
  Menu menu(String paramString);
  
  BasicMenuItem basicMenuItem(String paramString);
  
  RequestOptions requestOptions();
  
  JsonNode jsonNode(String paramString);
  
  JsonArrayNode jsonArrayNode();
  
  JsonArrayNode jsonArrayNode(List<? extends JsonNode> paramList);
  
  JsonArrayNode jsonArrayNode(JsonNode... paramVarArgs);
  
  JsonBooleanNode jsonBooleanNode(boolean paramBoolean);
  
  JsonNullNode jsonNullNode();
  
  JsonNumberNode jsonNumberNode(long paramLong);
  
  JsonNumberNode jsonNumberNode(double paramDouble);
  
  JsonNumberNode jsonNumberNode(Number paramNumber);
  
  JsonObjectNode jsonObjectNode();
  
  JsonObjectNode jsonObjectNode(Map<String, ? extends JsonNode> paramMap);
  
  JsonStringNode jsonStringNode(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\internal\MontoyaObjectFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */