/*     */ package burp.api.montoya.http.message.requests;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.core.Marker;
/*     */ import burp.api.montoya.http.HttpService;
/*     */ import burp.api.montoya.http.message.ContentType;
/*     */ import burp.api.montoya.http.message.HttpHeader;
/*     */ import burp.api.montoya.http.message.HttpMessage;
/*     */ import burp.api.montoya.http.message.params.HttpParameter;
/*     */ import burp.api.montoya.http.message.params.HttpParameterType;
/*     */ import burp.api.montoya.http.message.params.ParsedHttpParameter;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpRequest
/*     */   extends HttpMessage
/*     */ {
/*     */   boolean isInScope();
/*     */   
/*     */   HttpService httpService();
/*     */   
/*     */   String url();
/*     */   
/*     */   String method();
/*     */   
/*     */   String path();
/*     */   
/*     */   String query();
/*     */   
/*     */   String pathWithoutQuery();
/*     */   
/*     */   String fileExtension();
/*     */   
/*     */   ContentType contentType();
/*     */   
/*     */   List<ParsedHttpParameter> parameters();
/*     */   
/*     */   List<ParsedHttpParameter> parameters(HttpParameterType paramHttpParameterType);
/*     */   
/*     */   boolean hasParameters();
/*     */   
/*     */   boolean hasParameters(HttpParameterType paramHttpParameterType);
/*     */   
/*     */   ParsedHttpParameter parameter(String paramString, HttpParameterType paramHttpParameterType);
/*     */   
/*     */   String parameterValue(String paramString, HttpParameterType paramHttpParameterType);
/*     */   
/*     */   boolean hasParameter(String paramString, HttpParameterType paramHttpParameterType);
/*     */   
/*     */   boolean hasParameter(HttpParameter paramHttpParameter);
/*     */   
/*     */   boolean hasHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   boolean hasHeader(String paramString);
/*     */   
/*     */   boolean hasHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpHeader header(String paramString);
/*     */   
/*     */   String headerValue(String paramString);
/*     */   
/*     */   List<HttpHeader> headers();
/*     */   
/*     */   String httpVersion();
/*     */   
/*     */   int bodyOffset();
/*     */   
/*     */   ByteArray body();
/*     */   
/*     */   String bodyToString();
/*     */   
/*     */   List<Marker> markers();
/*     */   
/*     */   boolean contains(String paramString, boolean paramBoolean);
/*     */   
/*     */   boolean contains(Pattern paramPattern);
/*     */   
/*     */   ByteArray toByteArray();
/*     */   
/*     */   String toString();
/*     */   
/*     */   HttpRequest copyToTempFile();
/*     */   
/*     */   HttpRequest withService(HttpService paramHttpService);
/*     */   
/*     */   HttpRequest withPath(String paramString);
/*     */   
/*     */   HttpRequest withMethod(String paramString);
/*     */   
/*     */   HttpRequest withHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpRequest withHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpRequest withParameter(HttpParameter paramHttpParameter);
/*     */   
/*     */   HttpRequest withAddedParameters(List<? extends HttpParameter> paramList);
/*     */   
/*     */   HttpRequest withAddedParameters(HttpParameter... paramVarArgs);
/*     */   
/*     */   HttpRequest withRemovedParameters(List<? extends HttpParameter> paramList);
/*     */   
/*     */   HttpRequest withRemovedParameters(HttpParameter... paramVarArgs);
/*     */   
/*     */   HttpRequest withUpdatedParameters(List<? extends HttpParameter> paramList);
/*     */   
/*     */   HttpRequest withUpdatedParameters(HttpParameter... paramVarArgs);
/*     */   
/*     */   HttpRequest withTransformationApplied(HttpTransformation paramHttpTransformation);
/*     */   
/*     */   HttpRequest withBody(String paramString);
/*     */   
/*     */   HttpRequest withBody(ByteArray paramByteArray);
/*     */   
/*     */   HttpRequest withAddedHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpRequest withAddedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpRequest withAddedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpRequest withAddedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpRequest withUpdatedHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpRequest withUpdatedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpRequest withUpdatedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpRequest withUpdatedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpRequest withRemovedHeader(String paramString);
/*     */   
/*     */   HttpRequest withRemovedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpRequest withRemovedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpRequest withRemovedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpRequest withMarkers(List<Marker> paramList);
/*     */   
/*     */   HttpRequest withMarkers(Marker... paramVarArgs);
/*     */   
/*     */   HttpRequest withDefaultHeaders();
/*     */   
/*     */   static HttpRequest httpRequest() {
/* 578 */     return ObjectFactoryLocator.FACTORY.httpRequest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest httpRequest(ByteArray request) {
/* 590 */     return ObjectFactoryLocator.FACTORY.httpRequest(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest httpRequest(String request) {
/* 602 */     return ObjectFactoryLocator.FACTORY.httpRequest(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest httpRequest(HttpService service, ByteArray request) {
/* 615 */     return ObjectFactoryLocator.FACTORY.httpRequest(service, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest httpRequest(HttpService service, String request) {
/* 628 */     return ObjectFactoryLocator.FACTORY.httpRequest(service, request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest httpRequestFromUrl(String url) {
/* 640 */     return ObjectFactoryLocator.FACTORY.httpRequestFromUrl(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest http2Request(HttpService service, List<HttpHeader> headers, ByteArray body) {
/* 654 */     return ObjectFactoryLocator.FACTORY.http2Request(service, headers, body);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequest http2Request(HttpService service, List<HttpHeader> headers, String body) {
/* 668 */     return ObjectFactoryLocator.FACTORY.http2Request(service, headers, body);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\requests\HttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */