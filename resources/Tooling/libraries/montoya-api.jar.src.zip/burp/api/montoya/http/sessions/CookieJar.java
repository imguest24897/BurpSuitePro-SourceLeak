package burp.api.montoya.http.sessions;

import burp.api.montoya.http.message.Cookie;
import java.time.ZonedDateTime;
import java.util.List;

public interface CookieJar {
  void setCookie(String paramString1, String paramString2, String paramString3, String paramString4, ZonedDateTime paramZonedDateTime);
  
  List<Cookie> cookies();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\sessions\CookieJar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */