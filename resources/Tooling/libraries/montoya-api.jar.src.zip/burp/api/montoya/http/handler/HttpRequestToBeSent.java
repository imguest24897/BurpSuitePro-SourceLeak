package burp.api.montoya.http.handler;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Marker;
import burp.api.montoya.core.ToolSource;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.message.ContentType;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.params.HttpParameter;
import burp.api.montoya.http.message.params.HttpParameterType;
import burp.api.montoya.http.message.params.ParsedHttpParameter;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.requests.HttpTransformation;
import java.util.List;
import java.util.regex.Pattern;

public interface HttpRequestToBeSent extends HttpRequest {
  int messageId();
  
  Annotations annotations();
  
  ToolSource toolSource();
  
  boolean isInScope();
  
  HttpService httpService();
  
  String url();
  
  String method();
  
  String path();
  
  String pathWithoutQuery();
  
  String httpVersion();
  
  List<HttpHeader> headers();
  
  boolean hasHeader(HttpHeader paramHttpHeader);
  
  boolean hasHeader(String paramString);
  
  boolean hasHeader(String paramString1, String paramString2);
  
  HttpHeader header(String paramString);
  
  String headerValue(String paramString);
  
  boolean hasParameters();
  
  boolean hasParameters(HttpParameterType paramHttpParameterType);
  
  ParsedHttpParameter parameter(String paramString, HttpParameterType paramHttpParameterType);
  
  String parameterValue(String paramString, HttpParameterType paramHttpParameterType);
  
  boolean hasParameter(String paramString, HttpParameterType paramHttpParameterType);
  
  boolean hasParameter(HttpParameter paramHttpParameter);
  
  ContentType contentType();
  
  List<ParsedHttpParameter> parameters();
  
  List<ParsedHttpParameter> parameters(HttpParameterType paramHttpParameterType);
  
  ByteArray body();
  
  String bodyToString();
  
  int bodyOffset();
  
  List<Marker> markers();
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
  
  ByteArray toByteArray();
  
  String toString();
  
  HttpRequest copyToTempFile();
  
  HttpRequest withService(HttpService paramHttpService);
  
  HttpRequest withPath(String paramString);
  
  HttpRequest withMethod(String paramString);
  
  HttpRequest withHeader(HttpHeader paramHttpHeader);
  
  HttpRequest withHeader(String paramString1, String paramString2);
  
  HttpRequest withParameter(HttpParameter paramHttpParameter);
  
  HttpRequest withAddedParameters(List<? extends HttpParameter> paramList);
  
  HttpRequest withAddedParameters(HttpParameter... paramVarArgs);
  
  HttpRequest withRemovedParameters(List<? extends HttpParameter> paramList);
  
  HttpRequest withRemovedParameters(HttpParameter... paramVarArgs);
  
  HttpRequest withUpdatedParameters(List<? extends HttpParameter> paramList);
  
  HttpRequest withUpdatedParameters(HttpParameter... paramVarArgs);
  
  HttpRequest withTransformationApplied(HttpTransformation paramHttpTransformation);
  
  HttpRequest withBody(String paramString);
  
  HttpRequest withBody(ByteArray paramByteArray);
  
  HttpRequest withAddedHeader(String paramString1, String paramString2);
  
  HttpRequest withAddedHeader(HttpHeader paramHttpHeader);
  
  HttpRequest withUpdatedHeader(String paramString1, String paramString2);
  
  HttpRequest withUpdatedHeader(HttpHeader paramHttpHeader);
  
  HttpRequest withRemovedHeader(String paramString);
  
  HttpRequest withRemovedHeader(HttpHeader paramHttpHeader);
  
  HttpRequest withMarkers(List<Marker> paramList);
  
  HttpRequest withMarkers(Marker... paramVarArgs);
  
  HttpRequest withDefaultHeaders();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\handler\HttpRequestToBeSent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */