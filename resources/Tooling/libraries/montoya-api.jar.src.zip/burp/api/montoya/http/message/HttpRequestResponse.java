/*     */ package burp.api.montoya.http.message;
/*     */ 
/*     */ import burp.api.montoya.core.Annotations;
/*     */ import burp.api.montoya.core.Marker;
/*     */ import burp.api.montoya.http.HttpService;
/*     */ import burp.api.montoya.http.handler.TimingData;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.http.message.responses.HttpResponse;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpRequestResponse
/*     */ {
/*     */   HttpRequest request();
/*     */   
/*     */   HttpResponse response();
/*     */   
/*     */   HttpService httpService();
/*     */   
/*     */   Annotations annotations();
/*     */   
/*     */   Optional<TimingData> timingData();
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   String url();
/*     */   
/*     */   boolean hasResponse();
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   ContentType contentType();
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   short statusCode();
/*     */   
/*     */   List<Marker> requestMarkers();
/*     */   
/*     */   List<Marker> responseMarkers();
/*     */   
/*     */   boolean contains(String paramString, boolean paramBoolean);
/*     */   
/*     */   boolean contains(Pattern paramPattern);
/*     */   
/*     */   HttpRequestResponse copyToTempFile();
/*     */   
/*     */   HttpRequestResponse withAnnotations(Annotations paramAnnotations);
/*     */   
/*     */   HttpRequestResponse withRequestMarkers(List<Marker> paramList);
/*     */   
/*     */   HttpRequestResponse withRequestMarkers(Marker... paramVarArgs);
/*     */   
/*     */   HttpRequestResponse withResponseMarkers(List<Marker> paramList);
/*     */   
/*     */   HttpRequestResponse withResponseMarkers(Marker... paramVarArgs);
/*     */   
/*     */   static HttpRequestResponse httpRequestResponse(HttpRequest request, HttpResponse response) {
/* 185 */     return ObjectFactoryLocator.FACTORY.httpRequestResponse(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpRequestResponse httpRequestResponse(HttpRequest httpRequest, HttpResponse httpResponse, Annotations annotations) {
/* 199 */     return ObjectFactoryLocator.FACTORY.httpRequestResponse(httpRequest, httpResponse, annotations);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\HttpRequestResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */