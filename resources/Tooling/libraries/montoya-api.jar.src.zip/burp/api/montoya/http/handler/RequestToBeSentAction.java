/*    */ package burp.api.montoya.http.handler;
/*    */ 
/*    */ import burp.api.montoya.core.Annotations;
/*    */ import burp.api.montoya.http.message.requests.HttpRequest;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RequestToBeSentAction
/*    */ {
/*    */   default RequestAction action() {
/* 26 */     return RequestAction.CONTINUE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HttpRequest request();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Annotations annotations();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static RequestToBeSentAction continueWith(HttpRequest request) {
/* 48 */     return ObjectFactoryLocator.FACTORY.requestResult(request);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static RequestToBeSentAction continueWith(HttpRequest request, Annotations annotations) {
/* 61 */     return ObjectFactoryLocator.FACTORY.requestResult(request, annotations);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\handler\RequestToBeSentAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */