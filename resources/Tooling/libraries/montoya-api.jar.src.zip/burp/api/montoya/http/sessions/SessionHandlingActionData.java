package burp.api.montoya.http.sessions;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import java.util.List;

public interface SessionHandlingActionData {
  HttpRequest request();
  
  List<HttpRequestResponse> macroRequestResponses();
  
  Annotations annotations();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\sessions\SessionHandlingActionData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */