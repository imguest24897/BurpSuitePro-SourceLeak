/*    */ package burp.api.montoya.http.message;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface HttpHeader
/*    */ {
/*    */   String name();
/*    */   
/*    */   String value();
/*    */   
/*    */   String toString();
/*    */   
/*    */   static HttpHeader httpHeader(String name, String value) {
/* 44 */     return ObjectFactoryLocator.FACTORY.httpHeader(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpHeader httpHeader(String header) {
/* 57 */     return ObjectFactoryLocator.FACTORY.httpHeader(header);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\HttpHeader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */