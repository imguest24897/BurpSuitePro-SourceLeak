package burp.api.montoya.http.sessions;

public interface SessionHandlingAction {
  String name();
  
  ActionResult performAction(SessionHandlingActionData paramSessionHandlingActionData);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\sessions\SessionHandlingAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */