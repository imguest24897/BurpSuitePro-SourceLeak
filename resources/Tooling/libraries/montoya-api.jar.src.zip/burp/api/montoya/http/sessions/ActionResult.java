/*    */ package burp.api.montoya.http.sessions;
/*    */ 
/*    */ import burp.api.montoya.core.Annotations;
/*    */ import burp.api.montoya.http.message.requests.HttpRequest;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ActionResult
/*    */ {
/*    */   HttpRequest request();
/*    */   
/*    */   Annotations annotations();
/*    */   
/*    */   static ActionResult actionResult(HttpRequest request) {
/* 41 */     return ObjectFactoryLocator.FACTORY.actionResult(request);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ActionResult actionResult(HttpRequest request, Annotations annotations) {
/* 54 */     return ObjectFactoryLocator.FACTORY.actionResult(request, annotations);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\sessions\ActionResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */