package burp.api.montoya.http;

import burp.api.montoya.core.Registration;
import burp.api.montoya.http.handler.HttpHandler;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.analysis.ResponseKeywordsAnalyzer;
import burp.api.montoya.http.message.responses.analysis.ResponseVariationsAnalyzer;
import burp.api.montoya.http.sessions.CookieJar;
import burp.api.montoya.http.sessions.SessionHandlingAction;
import java.util.List;

public interface Http {
  Registration registerHttpHandler(HttpHandler paramHttpHandler);
  
  Registration registerSessionHandlingAction(SessionHandlingAction paramSessionHandlingAction);
  
  HttpRequestResponse sendRequest(HttpRequest paramHttpRequest);
  
  HttpRequestResponse sendRequest(HttpRequest paramHttpRequest, HttpMode paramHttpMode);
  
  HttpRequestResponse sendRequest(HttpRequest paramHttpRequest, HttpMode paramHttpMode, String paramString);
  
  HttpRequestResponse sendRequest(HttpRequest paramHttpRequest, RequestOptions paramRequestOptions);
  
  List<HttpRequestResponse> sendRequests(List<HttpRequest> paramList);
  
  List<HttpRequestResponse> sendRequests(List<HttpRequest> paramList, HttpMode paramHttpMode);
  
  ResponseKeywordsAnalyzer createResponseKeywordsAnalyzer(List<String> paramList);
  
  ResponseVariationsAnalyzer createResponseVariationsAnalyzer();
  
  CookieJar cookieJar();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\Http.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */