package burp.api.montoya.http.message.responses.analysis;

public interface KeywordCount {
  String keyword();
  
  int count();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\responses\analysis\KeywordCount.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */