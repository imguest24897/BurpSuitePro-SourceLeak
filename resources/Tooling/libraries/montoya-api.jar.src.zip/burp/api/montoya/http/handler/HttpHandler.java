package burp.api.montoya.http.handler;

public interface HttpHandler {
  RequestToBeSentAction handleHttpRequestToBeSent(HttpRequestToBeSent paramHttpRequestToBeSent);
  
  ResponseReceivedAction handleHttpResponseReceived(HttpResponseReceived paramHttpResponseReceived);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\handler\HttpHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */