/*    */ package burp.api.montoya.http;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface HttpService
/*    */ {
/*    */   String host();
/*    */   
/*    */   int port();
/*    */   
/*    */   boolean secure();
/*    */   
/*    */   String ipAddress();
/*    */   
/*    */   String toString();
/*    */   
/*    */   static HttpService httpService(String baseUrl) {
/* 58 */     return ObjectFactoryLocator.FACTORY.httpService(baseUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpService httpService(String host, boolean secure) {
/* 71 */     return ObjectFactoryLocator.FACTORY.httpService(host, secure);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpService httpService(String host, int port, boolean secure) {
/* 85 */     return ObjectFactoryLocator.FACTORY.httpService(host, port, secure);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\HttpService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */