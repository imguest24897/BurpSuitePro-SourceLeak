/*     */ package burp.api.montoya.http.message.responses;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.core.Marker;
/*     */ import burp.api.montoya.http.message.Cookie;
/*     */ import burp.api.montoya.http.message.HttpHeader;
/*     */ import burp.api.montoya.http.message.HttpMessage;
/*     */ import burp.api.montoya.http.message.MimeType;
/*     */ import burp.api.montoya.http.message.StatusCodeClass;
/*     */ import burp.api.montoya.http.message.responses.analysis.Attribute;
/*     */ import burp.api.montoya.http.message.responses.analysis.AttributeType;
/*     */ import burp.api.montoya.http.message.responses.analysis.KeywordCount;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpResponse
/*     */   extends HttpMessage
/*     */ {
/*     */   short statusCode();
/*     */   
/*     */   String reasonPhrase();
/*     */   
/*     */   boolean isStatusCodeClass(StatusCodeClass paramStatusCodeClass);
/*     */   
/*     */   List<Cookie> cookies();
/*     */   
/*     */   Cookie cookie(String paramString);
/*     */   
/*     */   String cookieValue(String paramString);
/*     */   
/*     */   boolean hasCookie(String paramString);
/*     */   
/*     */   boolean hasCookie(Cookie paramCookie);
/*     */   
/*     */   MimeType mimeType();
/*     */   
/*     */   MimeType statedMimeType();
/*     */   
/*     */   MimeType inferredMimeType();
/*     */   
/*     */   List<KeywordCount> keywordCounts(String... paramVarArgs);
/*     */   
/*     */   List<Attribute> attributes(AttributeType... paramVarArgs);
/*     */   
/*     */   boolean hasHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   boolean hasHeader(String paramString);
/*     */   
/*     */   boolean hasHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpHeader header(String paramString);
/*     */   
/*     */   String headerValue(String paramString);
/*     */   
/*     */   List<HttpHeader> headers();
/*     */   
/*     */   String httpVersion();
/*     */   
/*     */   int bodyOffset();
/*     */   
/*     */   ByteArray body();
/*     */   
/*     */   String bodyToString();
/*     */   
/*     */   List<Marker> markers();
/*     */   
/*     */   boolean contains(String paramString, boolean paramBoolean);
/*     */   
/*     */   boolean contains(Pattern paramPattern);
/*     */   
/*     */   ByteArray toByteArray();
/*     */   
/*     */   String toString();
/*     */   
/*     */   HttpResponse copyToTempFile();
/*     */   
/*     */   HttpResponse withStatusCode(short paramShort);
/*     */   
/*     */   HttpResponse withReasonPhrase(String paramString);
/*     */   
/*     */   HttpResponse withHttpVersion(String paramString);
/*     */   
/*     */   HttpResponse withBody(String paramString);
/*     */   
/*     */   HttpResponse withBody(ByteArray paramByteArray);
/*     */   
/*     */   HttpResponse withAddedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpResponse withAddedHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpResponse withAddedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpResponse withAddedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpResponse withUpdatedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpResponse withUpdatedHeader(String paramString1, String paramString2);
/*     */   
/*     */   HttpResponse withUpdatedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpResponse withUpdatedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpResponse withRemovedHeader(HttpHeader paramHttpHeader);
/*     */   
/*     */   HttpResponse withRemovedHeader(String paramString);
/*     */   
/*     */   HttpResponse withRemovedHeaders(List<? extends HttpHeader> paramList);
/*     */   
/*     */   HttpResponse withRemovedHeaders(HttpHeader... paramVarArgs);
/*     */   
/*     */   HttpResponse withMarkers(List<Marker> paramList);
/*     */   
/*     */   HttpResponse withMarkers(Marker... paramVarArgs);
/*     */   
/*     */   static HttpResponse httpResponse() {
/* 449 */     return ObjectFactoryLocator.FACTORY.httpResponse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpResponse httpResponse(ByteArray response) {
/* 461 */     return ObjectFactoryLocator.FACTORY.httpResponse(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HttpResponse httpResponse(String response) {
/* 473 */     return ObjectFactoryLocator.FACTORY.httpResponse(response);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\responses\HttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */