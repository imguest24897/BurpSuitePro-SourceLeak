/*    */ package burp.api.montoya.http.handler;
/*    */ 
/*    */ import burp.api.montoya.core.Annotations;
/*    */ import burp.api.montoya.http.message.responses.HttpResponse;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ResponseReceivedAction
/*    */ {
/*    */   default ResponseAction action() {
/* 26 */     return ResponseAction.CONTINUE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HttpResponse response();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Annotations annotations();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ResponseReceivedAction continueWith(HttpResponse response) {
/* 48 */     return ObjectFactoryLocator.FACTORY.responseResult(response);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ResponseReceivedAction continueWith(HttpResponse response, Annotations annotations) {
/* 61 */     return ObjectFactoryLocator.FACTORY.responseResult(response, annotations);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\handler\ResponseReceivedAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */