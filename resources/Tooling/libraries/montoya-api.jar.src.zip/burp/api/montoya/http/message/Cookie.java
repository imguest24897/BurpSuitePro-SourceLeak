package burp.api.montoya.http.message;

import java.time.ZonedDateTime;
import java.util.Optional;

public interface Cookie {
  String name();
  
  String value();
  
  String domain();
  
  String path();
  
  Optional<ZonedDateTime> expiration();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\Cookie.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */