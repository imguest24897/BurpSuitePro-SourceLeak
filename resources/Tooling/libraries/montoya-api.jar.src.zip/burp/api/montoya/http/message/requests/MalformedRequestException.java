/*    */ package burp.api.montoya.http.message.requests;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MalformedRequestException
/*    */   extends RuntimeException
/*    */ {
/*    */   public MalformedRequestException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\requests\MalformedRequestException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */