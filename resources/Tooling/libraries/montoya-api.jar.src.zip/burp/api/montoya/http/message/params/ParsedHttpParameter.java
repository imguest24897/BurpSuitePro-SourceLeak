package burp.api.montoya.http.message.params;

import burp.api.montoya.core.Range;

public interface ParsedHttpParameter extends HttpParameter {
  HttpParameterType type();
  
  String name();
  
  String value();
  
  Range nameOffsets();
  
  Range valueOffsets();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\params\ParsedHttpParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */