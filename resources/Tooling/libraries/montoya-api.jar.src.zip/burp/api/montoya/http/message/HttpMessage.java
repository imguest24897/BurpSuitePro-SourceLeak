package burp.api.montoya.http.message;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Marker;
import java.util.List;
import java.util.regex.Pattern;

public interface HttpMessage {
  boolean hasHeader(HttpHeader paramHttpHeader);
  
  boolean hasHeader(String paramString);
  
  boolean hasHeader(String paramString1, String paramString2);
  
  HttpHeader header(String paramString);
  
  String headerValue(String paramString);
  
  List<HttpHeader> headers();
  
  String httpVersion();
  
  int bodyOffset();
  
  ByteArray body();
  
  String bodyToString();
  
  List<Marker> markers();
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
  
  ByteArray toByteArray();
  
  String toString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\HttpMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */