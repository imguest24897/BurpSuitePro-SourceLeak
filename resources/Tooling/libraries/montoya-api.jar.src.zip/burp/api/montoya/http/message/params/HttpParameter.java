/*    */ package burp.api.montoya.http.message.params;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface HttpParameter
/*    */ {
/*    */   HttpParameterType type();
/*    */   
/*    */   String name();
/*    */   
/*    */   String value();
/*    */   
/*    */   static HttpParameter urlParameter(String name, String value) {
/* 43 */     return ObjectFactoryLocator.FACTORY.urlParameter(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpParameter bodyParameter(String name, String value) {
/* 56 */     return ObjectFactoryLocator.FACTORY.bodyParameter(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpParameter cookieParameter(String name, String value) {
/* 69 */     return ObjectFactoryLocator.FACTORY.cookieParameter(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpParameter parameter(String name, String value, HttpParameterType type) {
/* 83 */     return ObjectFactoryLocator.FACTORY.parameter(name, value, type);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\params\HttpParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */