package burp.api.montoya.http.message.responses.analysis;

import burp.api.montoya.http.message.responses.HttpResponse;
import java.util.Set;

public interface ResponseVariationsAnalyzer {
  Set<AttributeType> variantAttributes();
  
  Set<AttributeType> invariantAttributes();
  
  void updateWith(HttpResponse paramHttpResponse);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\message\responses\analysis\ResponseVariationsAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */