/*    */ package burp.api.montoya.http;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RequestOptions
/*    */ {
/*    */   RequestOptions withHttpMode(HttpMode paramHttpMode);
/*    */   
/*    */   RequestOptions withConnectionId(String paramString);
/*    */   
/*    */   RequestOptions withUpstreamTLSVerification();
/*    */   
/*    */   RequestOptions withRedirectionMode(RedirectionMode paramRedirectionMode);
/*    */   
/*    */   static RequestOptions requestOptions() {
/* 51 */     return ObjectFactoryLocator.FACTORY.requestOptions();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\http\RequestOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */