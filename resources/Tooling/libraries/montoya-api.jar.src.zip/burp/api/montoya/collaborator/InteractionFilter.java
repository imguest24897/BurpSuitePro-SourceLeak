/*    */ package burp.api.montoya.collaborator;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InteractionFilter
/*    */ {
/*    */   boolean matches(CollaboratorServer paramCollaboratorServer, Interaction paramInteraction);
/*    */   
/*    */   static InteractionFilter interactionIdFilter(String id) {
/* 45 */     return ObjectFactoryLocator.FACTORY.interactionIdFilter(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static InteractionFilter interactionPayloadFilter(String payload) {
/* 59 */     return ObjectFactoryLocator.FACTORY.interactionPayloadFilter(payload);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\InteractionFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */