/*    */ package burp.api.montoya.collaborator;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SecretKey
/*    */ {
/*    */   String toString();
/*    */   
/*    */   static SecretKey secretKey(String encodedKey) {
/* 37 */     return ObjectFactoryLocator.FACTORY.secretKey(encodedKey);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\SecretKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */