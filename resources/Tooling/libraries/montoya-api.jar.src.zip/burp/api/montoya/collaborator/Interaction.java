package burp.api.montoya.collaborator;

import java.net.InetAddress;
import java.time.ZonedDateTime;
import java.util.Optional;

public interface Interaction {
  InteractionId id();
  
  InteractionType type();
  
  ZonedDateTime timeStamp();
  
  InetAddress clientIp();
  
  int clientPort();
  
  Optional<DnsDetails> dnsDetails();
  
  Optional<HttpDetails> httpDetails();
  
  Optional<SmtpDetails> smtpDetails();
  
  Optional<String> customData();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\Interaction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */