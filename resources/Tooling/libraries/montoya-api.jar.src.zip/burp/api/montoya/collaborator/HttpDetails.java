package burp.api.montoya.collaborator;

import burp.api.montoya.http.HttpProtocol;
import burp.api.montoya.http.message.HttpRequestResponse;

public interface HttpDetails {
  HttpProtocol protocol();
  
  HttpRequestResponse requestResponse();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\HttpDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */