package burp.api.montoya.collaborator;

import java.util.Optional;

public interface CollaboratorPayload {
  InteractionId id();
  
  Optional<String> customData();
  
  Optional<CollaboratorServer> server();
  
  String toString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\CollaboratorPayload.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */