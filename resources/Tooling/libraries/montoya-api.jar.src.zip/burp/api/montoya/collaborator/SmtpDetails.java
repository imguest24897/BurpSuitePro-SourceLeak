package burp.api.montoya.collaborator;

public interface SmtpDetails {
  SmtpProtocol protocol();
  
  String conversation();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\SmtpDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */