package burp.api.montoya.collaborator;

import java.util.List;

public interface CollaboratorClient extends CollaboratorPayloadGenerator {
  CollaboratorPayload generatePayload(PayloadOption... paramVarArgs);
  
  CollaboratorPayload generatePayload(String paramString, PayloadOption... paramVarArgs);
  
  List<Interaction> getAllInteractions();
  
  List<Interaction> getInteractions(InteractionFilter paramInteractionFilter);
  
  CollaboratorServer server();
  
  SecretKey getSecretKey();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\CollaboratorClient.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */