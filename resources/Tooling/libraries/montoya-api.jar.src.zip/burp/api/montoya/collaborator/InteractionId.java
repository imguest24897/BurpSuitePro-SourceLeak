package burp.api.montoya.collaborator;

public interface InteractionId {
  String toString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\collaborator\InteractionId.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */