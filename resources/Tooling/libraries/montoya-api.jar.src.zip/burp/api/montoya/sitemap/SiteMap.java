package burp.api.montoya.sitemap;

import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.scanner.audit.issues.AuditIssue;
import java.util.List;

public interface SiteMap {
  List<HttpRequestResponse> requestResponses(SiteMapFilter paramSiteMapFilter);
  
  List<HttpRequestResponse> requestResponses();
  
  List<AuditIssue> issues(SiteMapFilter paramSiteMapFilter);
  
  List<AuditIssue> issues();
  
  void add(HttpRequestResponse paramHttpRequestResponse);
  
  void add(AuditIssue paramAuditIssue);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\sitemap\SiteMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */