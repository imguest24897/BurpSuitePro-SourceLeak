/*    */ package burp.api.montoya.sitemap;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SiteMapFilter
/*    */ {
/*    */   boolean matches(SiteMapNode paramSiteMapNode);
/*    */   
/*    */   static SiteMapFilter prefixFilter(String prefix) {
/* 38 */     return ObjectFactoryLocator.FACTORY.prefixFilter(prefix);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\sitemap\SiteMapFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */