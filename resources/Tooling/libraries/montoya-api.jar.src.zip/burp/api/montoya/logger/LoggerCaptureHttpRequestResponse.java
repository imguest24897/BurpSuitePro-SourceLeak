package burp.api.montoya.logger;

import burp.api.montoya.core.ToolSource;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.handler.TimingData;
import burp.api.montoya.http.message.MimeType;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import java.time.ZonedDateTime;
import java.util.regex.Pattern;

public interface LoggerCaptureHttpRequestResponse {
  HttpRequest request();
  
  HttpResponse response();
  
  HttpService httpService();
  
  ZonedDateTime time();
  
  MimeType mimeType();
  
  boolean hasResponse();
  
  TimingData timingData();
  
  String pageTitle();
  
  ToolSource toolSource();
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
  
  boolean isSessionHandlingEvent();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\logger\LoggerCaptureHttpRequestResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */