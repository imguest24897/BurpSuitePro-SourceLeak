/*     */ package burp.api.montoya.persistence;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.http.message.HttpRequestResponse;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.http.message.responses.HttpResponse;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PersistedObject
/*     */ {
/*     */   PersistedObject getChildObject(String paramString);
/*     */   
/*     */   void setChildObject(String paramString, PersistedObject paramPersistedObject);
/*     */   
/*     */   void deleteChildObject(String paramString);
/*     */   
/*     */   Set<String> childObjectKeys();
/*     */   
/*     */   String getString(String paramString);
/*     */   
/*     */   void setString(String paramString1, String paramString2);
/*     */   
/*     */   void deleteString(String paramString);
/*     */   
/*     */   Set<String> stringKeys();
/*     */   
/*     */   Boolean getBoolean(String paramString);
/*     */   
/*     */   void setBoolean(String paramString, boolean paramBoolean);
/*     */   
/*     */   void deleteBoolean(String paramString);
/*     */   
/*     */   Set<String> booleanKeys();
/*     */   
/*     */   Byte getByte(String paramString);
/*     */   
/*     */   void setByte(String paramString, byte paramByte);
/*     */   
/*     */   void deleteByte(String paramString);
/*     */   
/*     */   Set<String> byteKeys();
/*     */   
/*     */   Short getShort(String paramString);
/*     */   
/*     */   void setShort(String paramString, short paramShort);
/*     */   
/*     */   void deleteShort(String paramString);
/*     */   
/*     */   Set<String> shortKeys();
/*     */   
/*     */   Integer getInteger(String paramString);
/*     */   
/*     */   void setInteger(String paramString, int paramInt);
/*     */   
/*     */   void deleteInteger(String paramString);
/*     */   
/*     */   Set<String> integerKeys();
/*     */   
/*     */   Long getLong(String paramString);
/*     */   
/*     */   void setLong(String paramString, long paramLong);
/*     */   
/*     */   void deleteLong(String paramString);
/*     */   
/*     */   Set<String> longKeys();
/*     */   
/*     */   ByteArray getByteArray(String paramString);
/*     */   
/*     */   void setByteArray(String paramString, ByteArray paramByteArray);
/*     */   
/*     */   void deleteByteArray(String paramString);
/*     */   
/*     */   Set<String> byteArrayKeys();
/*     */   
/*     */   HttpRequest getHttpRequest(String paramString);
/*     */   
/*     */   void setHttpRequest(String paramString, HttpRequest paramHttpRequest);
/*     */   
/*     */   void deleteHttpRequest(String paramString);
/*     */   
/*     */   Set<String> httpRequestKeys();
/*     */   
/*     */   PersistedList<HttpRequest> getHttpRequestList(String paramString);
/*     */   
/*     */   void setHttpRequestList(String paramString, PersistedList<HttpRequest> paramPersistedList);
/*     */   
/*     */   void deleteHttpRequestList(String paramString);
/*     */   
/*     */   Set<String> httpRequestListKeys();
/*     */   
/*     */   HttpResponse getHttpResponse(String paramString);
/*     */   
/*     */   void setHttpResponse(String paramString, HttpResponse paramHttpResponse);
/*     */   
/*     */   void deleteHttpResponse(String paramString);
/*     */   
/*     */   Set<String> httpResponseKeys();
/*     */   
/*     */   PersistedList<HttpResponse> getHttpResponseList(String paramString);
/*     */   
/*     */   void setHttpResponseList(String paramString, PersistedList<HttpResponse> paramPersistedList);
/*     */   
/*     */   void deleteHttpResponseList(String paramString);
/*     */   
/*     */   Set<String> httpResponseListKeys();
/*     */   
/*     */   HttpRequestResponse getHttpRequestResponse(String paramString);
/*     */   
/*     */   void setHttpRequestResponse(String paramString, HttpRequestResponse paramHttpRequestResponse);
/*     */   
/*     */   void deleteHttpRequestResponse(String paramString);
/*     */   
/*     */   Set<String> httpRequestResponseKeys();
/*     */   
/*     */   PersistedList<HttpRequestResponse> getHttpRequestResponseList(String paramString);
/*     */   
/*     */   void setHttpRequestResponseList(String paramString, PersistedList<HttpRequestResponse> paramPersistedList);
/*     */   
/*     */   void deleteHttpRequestResponseList(String paramString);
/*     */   
/*     */   Set<String> httpRequestResponseListKeys();
/*     */   
/*     */   PersistedList<Boolean> getBooleanList(String paramString);
/*     */   
/*     */   void setBooleanList(String paramString, PersistedList<Boolean> paramPersistedList);
/*     */   
/*     */   void deleteBooleanList(String paramString);
/*     */   
/*     */   Set<String> booleanListKeys();
/*     */   
/*     */   PersistedList<Short> getShortList(String paramString);
/*     */   
/*     */   void setShortList(String paramString, PersistedList<Short> paramPersistedList);
/*     */   
/*     */   void deleteShortList(String paramString);
/*     */   
/*     */   Set<String> shortListKeys();
/*     */   
/*     */   PersistedList<Integer> getIntegerList(String paramString);
/*     */   
/*     */   void setIntegerList(String paramString, PersistedList<Integer> paramPersistedList);
/*     */   
/*     */   void deleteIntegerList(String paramString);
/*     */   
/*     */   Set<String> integerListKeys();
/*     */   
/*     */   PersistedList<Long> getLongList(String paramString);
/*     */   
/*     */   void setLongList(String paramString, PersistedList<Long> paramPersistedList);
/*     */   
/*     */   void deleteLongList(String paramString);
/*     */   
/*     */   Set<String> longListKeys();
/*     */   
/*     */   PersistedList<String> getStringList(String paramString);
/*     */   
/*     */   void setStringList(String paramString, PersistedList<String> paramPersistedList);
/*     */   
/*     */   void deleteStringList(String paramString);
/*     */   
/*     */   Set<String> stringListKeys();
/*     */   
/*     */   PersistedList<ByteArray> getByteArrayList(String paramString);
/*     */   
/*     */   void setByteArrayList(String paramString, PersistedList<ByteArray> paramPersistedList);
/*     */   
/*     */   void deleteByteArrayList(String paramString);
/*     */   
/*     */   Set<String> byteArrayListKeys();
/*     */   
/*     */   static PersistedObject persistedObject() {
/* 742 */     return ObjectFactoryLocator.FACTORY.persistedObject();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\persistence\PersistedObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */