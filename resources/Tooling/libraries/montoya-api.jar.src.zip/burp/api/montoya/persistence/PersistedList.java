/*     */ package burp.api.montoya.persistence;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.http.message.HttpRequestResponse;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.http.message.responses.HttpResponse;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PersistedList<T>
/*     */   extends List<T>
/*     */ {
/*     */   static PersistedList<Boolean> persistedBooleanList() {
/*  33 */     return ObjectFactoryLocator.FACTORY.persistedBooleanList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<Short> persistedShortList() {
/*  43 */     return ObjectFactoryLocator.FACTORY.persistedShortList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<Integer> persistedIntegerList() {
/*  53 */     return ObjectFactoryLocator.FACTORY.persistedIntegerList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<Long> persistedLongList() {
/*  63 */     return ObjectFactoryLocator.FACTORY.persistedLongList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<String> persistedStringList() {
/*  73 */     return ObjectFactoryLocator.FACTORY.persistedStringList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<ByteArray> persistedByteArrayList() {
/*  83 */     return ObjectFactoryLocator.FACTORY.persistedByteArrayList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<HttpRequest> persistedHttpRequestList() {
/*  93 */     return ObjectFactoryLocator.FACTORY.persistedHttpRequestList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<HttpResponse> persistedHttpResponseList() {
/* 103 */     return ObjectFactoryLocator.FACTORY.persistedHttpResponseList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PersistedList<HttpRequestResponse> persistedHttpRequestResponseList() {
/* 113 */     return ObjectFactoryLocator.FACTORY.persistedHttpRequestResponseList();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\persistence\PersistedList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */