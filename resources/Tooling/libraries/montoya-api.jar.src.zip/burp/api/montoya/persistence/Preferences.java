package burp.api.montoya.persistence;

import java.util.Set;

public interface Preferences {
  String getString(String paramString);
  
  void setString(String paramString1, String paramString2);
  
  void deleteString(String paramString);
  
  Set<String> stringKeys();
  
  Boolean getBoolean(String paramString);
  
  void setBoolean(String paramString, boolean paramBoolean);
  
  void deleteBoolean(String paramString);
  
  Set<String> booleanKeys();
  
  Byte getByte(String paramString);
  
  void setByte(String paramString, byte paramByte);
  
  void deleteByte(String paramString);
  
  Set<String> byteKeys();
  
  Short getShort(String paramString);
  
  void setShort(String paramString, short paramShort);
  
  void deleteShort(String paramString);
  
  Set<String> shortKeys();
  
  Integer getInteger(String paramString);
  
  void setInteger(String paramString, int paramInt);
  
  void deleteInteger(String paramString);
  
  Set<String> integerKeys();
  
  Long getLong(String paramString);
  
  void setLong(String paramString, long paramLong);
  
  void deleteLong(String paramString);
  
  Set<String> longKeys();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\persistence\Preferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */