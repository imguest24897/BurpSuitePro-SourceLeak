package burp.api.montoya.websocket.extension;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Registration;

public interface ExtensionWebSocket {
  void sendTextMessage(String paramString);
  
  void sendBinaryMessage(ByteArray paramByteArray);
  
  void close();
  
  Registration registerMessageHandler(ExtensionWebSocketMessageHandler paramExtensionWebSocketMessageHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\extension\ExtensionWebSocket.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */