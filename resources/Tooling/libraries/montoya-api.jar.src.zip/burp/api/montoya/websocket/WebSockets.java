package burp.api.montoya.websocket;

import burp.api.montoya.core.Registration;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.websocket.extension.ExtensionWebSocketCreation;

public interface WebSockets {
  Registration registerWebSocketCreatedHandler(WebSocketCreatedHandler paramWebSocketCreatedHandler);
  
  ExtensionWebSocketCreation createWebSocket(HttpService paramHttpService, String paramString);
  
  ExtensionWebSocketCreation createWebSocket(HttpRequest paramHttpRequest);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\WebSockets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */