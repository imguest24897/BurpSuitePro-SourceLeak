package burp.api.montoya.websocket;

import burp.api.montoya.core.ByteArray;

public interface BinaryMessage {
  ByteArray payload();
  
  Direction direction();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\BinaryMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */