package burp.api.montoya.websocket.extension;

import burp.api.montoya.websocket.BinaryMessage;
import burp.api.montoya.websocket.TextMessage;

public interface ExtensionWebSocketMessageHandler {
  void textMessageReceived(TextMessage paramTextMessage);
  
  void binaryMessageReceived(BinaryMessage paramBinaryMessage);
  
  default void onClose() {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\extension\ExtensionWebSocketMessageHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */