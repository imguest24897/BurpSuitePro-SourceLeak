package burp.api.montoya.websocket;

import burp.api.montoya.core.ToolSource;
import burp.api.montoya.http.message.requests.HttpRequest;

public interface WebSocketCreated {
  WebSocket webSocket();
  
  HttpRequest upgradeRequest();
  
  ToolSource toolSource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\WebSocketCreated.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */