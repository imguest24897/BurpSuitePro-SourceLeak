/*    */ package burp.api.montoya.websocket;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TextMessageAction
/*    */ {
/*    */   MessageAction action();
/*    */   
/*    */   String payload();
/*    */   
/*    */   static TextMessageAction continueWith(String payload) {
/* 37 */     return ObjectFactoryLocator.FACTORY.continueWithTextMessage(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TextMessageAction continueWith(TextMessage textMessage) {
/* 49 */     return ObjectFactoryLocator.FACTORY.continueWithTextMessage(textMessage.payload());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TextMessageAction drop() {
/* 59 */     return ObjectFactoryLocator.FACTORY.dropTextMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TextMessageAction textMessageAction(String payload, MessageAction action) {
/* 72 */     return ObjectFactoryLocator.FACTORY.textMessageAction(payload, action);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\TextMessageAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */