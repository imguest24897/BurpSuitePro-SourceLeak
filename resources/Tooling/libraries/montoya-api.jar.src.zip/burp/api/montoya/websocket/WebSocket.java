package burp.api.montoya.websocket;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Registration;

public interface WebSocket {
  void sendTextMessage(String paramString);
  
  void sendBinaryMessage(ByteArray paramByteArray);
  
  void close();
  
  Registration registerMessageHandler(MessageHandler paramMessageHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\WebSocket.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */