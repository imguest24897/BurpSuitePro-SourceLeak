package burp.api.montoya.websocket;

public interface TextMessage {
  String payload();
  
  Direction direction();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\TextMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */