/*    */ package burp.api.montoya.websocket;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BinaryMessageAction
/*    */ {
/*    */   MessageAction action();
/*    */   
/*    */   ByteArray payload();
/*    */   
/*    */   static BinaryMessageAction continueWith(ByteArray payload) {
/* 39 */     return ObjectFactoryLocator.FACTORY.continueWithBinaryMessage(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BinaryMessageAction continueWith(BinaryMessage binaryMessage) {
/* 51 */     return ObjectFactoryLocator.FACTORY.continueWithBinaryMessage(binaryMessage.payload());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BinaryMessageAction drop() {
/* 61 */     return ObjectFactoryLocator.FACTORY.dropBinaryMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BinaryMessageAction binaryMessageAction(ByteArray payload, MessageAction action) {
/* 74 */     return ObjectFactoryLocator.FACTORY.binaryMessageAction(payload, action);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\BinaryMessageAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */