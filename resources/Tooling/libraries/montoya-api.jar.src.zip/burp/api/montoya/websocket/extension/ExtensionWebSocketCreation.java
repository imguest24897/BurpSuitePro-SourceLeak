package burp.api.montoya.websocket.extension;

import burp.api.montoya.http.message.responses.HttpResponse;
import java.util.Optional;

public interface ExtensionWebSocketCreation {
  ExtensionWebSocketCreationStatus status();
  
  Optional<ExtensionWebSocket> webSocket();
  
  Optional<HttpResponse> upgradeResponse();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\websocket\extension\ExtensionWebSocketCreation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */