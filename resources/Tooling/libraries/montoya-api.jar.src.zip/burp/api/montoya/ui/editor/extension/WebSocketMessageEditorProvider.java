package burp.api.montoya.ui.editor.extension;

public interface WebSocketMessageEditorProvider {
  ExtensionProvidedWebSocketMessageEditor provideMessageEditor(EditorCreationContext paramEditorCreationContext);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\editor\extension\WebSocketMessageEditorProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */