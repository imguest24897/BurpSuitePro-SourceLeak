/*    */ package burp.api.montoya.ui.menu;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Menu
/*    */ {
/*    */   String caption();
/*    */   
/*    */   List<MenuItem> menuItems();
/*    */   
/*    */   Menu withCaption(String paramString);
/*    */   
/*    */   Menu withMenuItems(MenuItem... paramVarArgs);
/*    */   
/*    */   Menu withMenuItems(List<MenuItem> paramList);
/*    */   
/*    */   static Menu menu(String caption) {
/* 62 */     return ObjectFactoryLocator.FACTORY.menu(caption);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\menu\Menu.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */