package burp.api.montoya.ui;

import burp.api.montoya.core.Registration;
import burp.api.montoya.ui.contextmenu.ContextMenuItemsProvider;
import burp.api.montoya.ui.editor.EditorOptions;
import burp.api.montoya.ui.editor.HttpRequestEditor;
import burp.api.montoya.ui.editor.HttpResponseEditor;
import burp.api.montoya.ui.editor.RawEditor;
import burp.api.montoya.ui.editor.WebSocketMessageEditor;
import burp.api.montoya.ui.editor.extension.HttpRequestEditorProvider;
import burp.api.montoya.ui.editor.extension.HttpResponseEditorProvider;
import burp.api.montoya.ui.editor.extension.WebSocketMessageEditorProvider;
import burp.api.montoya.ui.menu.MenuBar;
import burp.api.montoya.ui.swing.SwingUtils;
import java.awt.Component;
import java.awt.Font;

public interface UserInterface {
  MenuBar menuBar();
  
  Registration registerSuiteTab(String paramString, Component paramComponent);
  
  Registration registerContextMenuItemsProvider(ContextMenuItemsProvider paramContextMenuItemsProvider);
  
  Registration registerHttpRequestEditorProvider(HttpRequestEditorProvider paramHttpRequestEditorProvider);
  
  Registration registerHttpResponseEditorProvider(HttpResponseEditorProvider paramHttpResponseEditorProvider);
  
  Registration registerWebSocketMessageEditorProvider(WebSocketMessageEditorProvider paramWebSocketMessageEditorProvider);
  
  RawEditor createRawEditor(EditorOptions... paramVarArgs);
  
  WebSocketMessageEditor createWebSocketMessageEditor(EditorOptions... paramVarArgs);
  
  HttpRequestEditor createHttpRequestEditor(EditorOptions... paramVarArgs);
  
  HttpResponseEditor createHttpResponseEditor(EditorOptions... paramVarArgs);
  
  void applyThemeToComponent(Component paramComponent);
  
  Theme currentTheme();
  
  Font currentEditorFont();
  
  Font currentDisplayFont();
  
  SwingUtils swingUtils();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\UserInterface.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */