package burp.api.montoya.ui.editor.extension;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.ui.Selection;
import burp.api.montoya.ui.contextmenu.WebSocketMessage;
import java.awt.Component;

public interface ExtensionProvidedWebSocketMessageEditor {
  ByteArray getMessage();
  
  void setMessage(WebSocketMessage paramWebSocketMessage);
  
  boolean isEnabledFor(WebSocketMessage paramWebSocketMessage);
  
  String caption();
  
  Component uiComponent();
  
  Selection selectedData();
  
  boolean isModified();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\editor\extension\ExtensionProvidedWebSocketMessageEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */