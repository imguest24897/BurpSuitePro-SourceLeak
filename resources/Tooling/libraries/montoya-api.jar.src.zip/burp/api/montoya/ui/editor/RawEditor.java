package burp.api.montoya.ui.editor;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.ui.Selection;
import java.awt.Component;
import java.util.Optional;

public interface RawEditor extends Editor {
  void setEditable(boolean paramBoolean);
  
  ByteArray getContents();
  
  void setContents(ByteArray paramByteArray);
  
  void setSearchExpression(String paramString);
  
  boolean isModified();
  
  int caretPosition();
  
  Optional<Selection> selection();
  
  Component uiComponent();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\editor\RawEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */