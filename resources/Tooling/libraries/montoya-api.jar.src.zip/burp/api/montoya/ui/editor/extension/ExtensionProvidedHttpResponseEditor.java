package burp.api.montoya.ui.editor.extension;

import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.ui.Selection;
import java.awt.Component;

public interface ExtensionProvidedHttpResponseEditor extends ExtensionProvidedEditor {
  HttpResponse getResponse();
  
  void setRequestResponse(HttpRequestResponse paramHttpRequestResponse);
  
  boolean isEnabledFor(HttpRequestResponse paramHttpRequestResponse);
  
  String caption();
  
  Component uiComponent();
  
  Selection selectedData();
  
  boolean isModified();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\editor\extension\ExtensionProvidedHttpResponseEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */