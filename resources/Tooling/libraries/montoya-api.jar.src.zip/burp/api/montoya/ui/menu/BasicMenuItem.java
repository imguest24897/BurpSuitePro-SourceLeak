/*    */ package burp.api.montoya.ui.menu;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BasicMenuItem
/*    */   extends MenuItem
/*    */ {
/*    */   void action();
/*    */   
/*    */   BasicMenuItem withAction(Runnable paramRunnable);
/*    */   
/*    */   BasicMenuItem withCaption(String paramString);
/*    */   
/*    */   static BasicMenuItem basicMenuItem(String caption) {
/* 39 */     return ObjectFactoryLocator.FACTORY.basicMenuItem(caption);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\menu\BasicMenuItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */