package burp.api.montoya.ui.menu;

import burp.api.montoya.core.Registration;
import javax.swing.JMenu;

public interface MenuBar {
  Registration registerMenu(JMenu paramJMenu);
  
  Registration registerMenu(Menu paramMenu);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\menu\MenuBar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */