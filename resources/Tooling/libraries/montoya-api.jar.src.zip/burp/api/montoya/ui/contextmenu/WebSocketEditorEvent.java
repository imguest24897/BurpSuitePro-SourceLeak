package burp.api.montoya.ui.contextmenu;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Range;
import burp.api.montoya.core.ToolSource;
import java.util.Optional;

public interface WebSocketEditorEvent extends ComponentEvent, ToolSource {
  ByteArray getContents();
  
  void setContents(ByteArray paramByteArray);
  
  WebSocketMessage webSocketMessage();
  
  boolean isReadOnly();
  
  Optional<Range> selectionOffsets();
  
  int caretPosition();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\WebSocketEditorEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */