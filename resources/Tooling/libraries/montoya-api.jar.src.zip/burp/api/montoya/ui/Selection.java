/*    */ package burp.api.montoya.ui;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.core.Range;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Selection
/*    */ {
/*    */   ByteArray contents();
/*    */   
/*    */   Range offsets();
/*    */   
/*    */   static Selection selection(ByteArray selectionContents) {
/* 38 */     return ObjectFactoryLocator.FACTORY.selection(selectionContents);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Selection selection(int startIndexInclusive, int endIndexExclusive) {
/* 51 */     return ObjectFactoryLocator.FACTORY.selection(startIndexInclusive, endIndexExclusive);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Selection selection(ByteArray selectionContents, int startIndexInclusive, int endIndexExclusive) {
/* 65 */     return ObjectFactoryLocator.FACTORY.selection(selectionContents, startIndexInclusive, endIndexExclusive);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\Selection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */