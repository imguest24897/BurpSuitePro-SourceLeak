package burp.api.montoya.ui.contextmenu;

import burp.api.montoya.core.ToolSource;
import java.util.List;
import java.util.Optional;

public interface WebSocketContextMenuEvent extends ComponentEvent, ToolSource {
  Optional<WebSocketEditorEvent> messageEditorWebSocket();
  
  List<WebSocketMessage> selectedWebSocketMessages();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\WebSocketContextMenuEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */