package burp.api.montoya.ui.contextmenu;

import java.awt.event.InputEvent;

public interface ComponentEvent {
  InputEvent inputEvent();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\ComponentEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */