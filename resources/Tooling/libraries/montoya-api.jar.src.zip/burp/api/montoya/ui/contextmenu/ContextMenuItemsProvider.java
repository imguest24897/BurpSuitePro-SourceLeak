/*    */ package burp.api.montoya.ui.contextmenu;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ContextMenuItemsProvider
/*    */ {
/*    */   default List<Component> provideMenuItems(ContextMenuEvent event) {
/* 31 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default List<Component> provideMenuItems(WebSocketContextMenuEvent event) {
/* 44 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default List<Component> provideMenuItems(AuditIssueContextMenuEvent event) {
/* 57 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\ContextMenuItemsProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */