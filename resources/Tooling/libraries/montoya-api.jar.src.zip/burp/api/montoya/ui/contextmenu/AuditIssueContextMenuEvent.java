package burp.api.montoya.ui.contextmenu;

import burp.api.montoya.core.ToolSource;
import burp.api.montoya.scanner.audit.issues.AuditIssue;
import java.util.List;

public interface AuditIssueContextMenuEvent extends ComponentEvent, ToolSource, InvocationSource {
  List<AuditIssue> selectedIssues();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\AuditIssueContextMenuEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */