package burp.api.montoya.ui.swing;

import burp.api.montoya.core.HighlightColor;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Window;

public interface SwingUtils {
  Frame suiteFrame();
  
  Window windowForComponent(Component paramComponent);
  
  Color colorForHighLight(HighlightColor paramHighlightColor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\swing\SwingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */