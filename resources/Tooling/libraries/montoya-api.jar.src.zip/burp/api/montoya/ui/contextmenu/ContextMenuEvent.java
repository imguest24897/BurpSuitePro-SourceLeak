package burp.api.montoya.ui.contextmenu;

import burp.api.montoya.core.ToolSource;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.scanner.audit.issues.AuditIssue;
import java.util.List;
import java.util.Optional;

public interface ContextMenuEvent extends ComponentEvent, ToolSource, InvocationSource {
  Optional<MessageEditorHttpRequestResponse> messageEditorRequestResponse();
  
  List<HttpRequestResponse> selectedRequestResponses();
  
  @Deprecated
  List<AuditIssue> selectedIssues();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\contextmenu\ContextMenuEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */