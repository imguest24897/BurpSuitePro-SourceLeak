/*    */ package burp.api.montoya.ui.menu;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MenuItem
/*    */ {
/*    */   String caption();
/*    */   
/*    */   static BasicMenuItem basicMenuItem(String caption) {
/* 26 */     return ObjectFactoryLocator.FACTORY.basicMenuItem(caption);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\ui\menu\MenuItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */