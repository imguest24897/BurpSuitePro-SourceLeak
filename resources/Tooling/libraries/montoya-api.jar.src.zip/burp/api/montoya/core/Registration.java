package burp.api.montoya.core;

public interface Registration {
  boolean isRegistered();
  
  void deregister();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\core\Registration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */