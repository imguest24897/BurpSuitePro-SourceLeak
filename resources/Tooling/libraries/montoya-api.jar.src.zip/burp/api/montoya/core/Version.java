package burp.api.montoya.core;

public interface Version {
  String name();
  
  @Deprecated(forRemoval = true)
  String major();
  
  @Deprecated(forRemoval = true)
  String minor();
  
  @Deprecated(forRemoval = true)
  String build();
  
  long buildNumber();
  
  BurpSuiteEdition edition();
  
  String toString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\core\Version.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */