/*     */ package burp.api.montoya.core;
/*     */ 
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ByteArray
/*     */   extends Iterable<Byte>
/*     */ {
/*     */   byte getByte(int paramInt);
/*     */   
/*     */   void setByte(int paramInt, byte paramByte);
/*     */   
/*     */   void setByte(int paramInt1, int paramInt2);
/*     */   
/*     */   void setBytes(int paramInt, byte... paramVarArgs);
/*     */   
/*     */   void setBytes(int paramInt, int... paramVarArgs);
/*     */   
/*     */   void setBytes(int paramInt, ByteArray paramByteArray);
/*     */   
/*     */   int length();
/*     */   
/*     */   byte[] getBytes();
/*     */   
/*     */   ByteArray subArray(int paramInt1, int paramInt2);
/*     */   
/*     */   ByteArray subArray(Range paramRange);
/*     */   
/*     */   ByteArray copy();
/*     */   
/*     */   ByteArray copyToTempFile();
/*     */   
/*     */   int indexOf(ByteArray paramByteArray);
/*     */   
/*     */   int indexOf(String paramString);
/*     */   
/*     */   int indexOf(ByteArray paramByteArray, boolean paramBoolean);
/*     */   
/*     */   int indexOf(String paramString, boolean paramBoolean);
/*     */   
/*     */   int indexOf(ByteArray paramByteArray, boolean paramBoolean, int paramInt1, int paramInt2);
/*     */   
/*     */   int indexOf(String paramString, boolean paramBoolean, int paramInt1, int paramInt2);
/*     */   
/*     */   int indexOf(Pattern paramPattern);
/*     */   
/*     */   int indexOf(Pattern paramPattern, int paramInt1, int paramInt2);
/*     */   
/*     */   int countMatches(ByteArray paramByteArray);
/*     */   
/*     */   int countMatches(String paramString);
/*     */   
/*     */   int countMatches(ByteArray paramByteArray, boolean paramBoolean);
/*     */   
/*     */   int countMatches(String paramString, boolean paramBoolean);
/*     */   
/*     */   int countMatches(ByteArray paramByteArray, boolean paramBoolean, int paramInt1, int paramInt2);
/*     */   
/*     */   int countMatches(String paramString, boolean paramBoolean, int paramInt1, int paramInt2);
/*     */   
/*     */   int countMatches(Pattern paramPattern);
/*     */   
/*     */   int countMatches(Pattern paramPattern, int paramInt1, int paramInt2);
/*     */   
/*     */   String toString();
/*     */   
/*     */   ByteArray withAppended(byte... paramVarArgs);
/*     */   
/*     */   ByteArray withAppended(int... paramVarArgs);
/*     */   
/*     */   ByteArray withAppended(String paramString);
/*     */   
/*     */   ByteArray withAppended(ByteArray paramByteArray);
/*     */   
/*     */   static ByteArray byteArrayOfLength(int length) {
/* 335 */     return ObjectFactoryLocator.FACTORY.byteArrayOfLength(length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteArray byteArray(byte... data) {
/* 347 */     return ObjectFactoryLocator.FACTORY.byteArray(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteArray byteArray(int... data) {
/* 359 */     return ObjectFactoryLocator.FACTORY.byteArray(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteArray byteArray(String text) {
/* 371 */     return ObjectFactoryLocator.FACTORY.byteArray(text);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\core\ByteArray.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */