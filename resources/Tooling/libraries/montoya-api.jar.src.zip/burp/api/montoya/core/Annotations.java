/*     */ package burp.api.montoya.core;
/*     */ 
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Annotations
/*     */ {
/*     */   String notes();
/*     */   
/*     */   boolean hasNotes();
/*     */   
/*     */   boolean hasHighlightColor();
/*     */   
/*     */   void setNotes(String paramString);
/*     */   
/*     */   HighlightColor highlightColor();
/*     */   
/*     */   void setHighlightColor(HighlightColor paramHighlightColor);
/*     */   
/*     */   Annotations withNotes(String paramString);
/*     */   
/*     */   Annotations withHighlightColor(HighlightColor paramHighlightColor);
/*     */   
/*     */   static Annotations annotations() {
/*  77 */     return ObjectFactoryLocator.FACTORY.annotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Annotations annotations(String notes) {
/*  89 */     return ObjectFactoryLocator.FACTORY.annotations(notes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Annotations annotations(HighlightColor highlightColor) {
/* 101 */     return ObjectFactoryLocator.FACTORY.annotations(highlightColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Annotations annotations(String notes, HighlightColor highlightColor) {
/* 114 */     return ObjectFactoryLocator.FACTORY.annotations(notes, highlightColor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\core\Annotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */