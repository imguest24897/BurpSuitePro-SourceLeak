/*    */ package burp.api.montoya.utilities.json;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JsonNullNode
/*    */   extends JsonNode
/*    */ {
/*    */   Object getValue();
/*    */   
/*    */   static JsonNullNode jsonNullNode() {
/* 28 */     return ObjectFactoryLocator.FACTORY.jsonNullNode();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonNullNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */