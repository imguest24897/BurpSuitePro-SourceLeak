package burp.api.montoya.utilities;

import burp.api.montoya.core.ByteArray;

public interface NumberUtils {
  String convertBinaryToOctal(String paramString);
  
  String convertBinaryToOctal(ByteArray paramByteArray);
  
  String convertBinaryToDecimal(String paramString);
  
  String convertBinaryToDecimal(ByteArray paramByteArray);
  
  String convertBinaryToHex(String paramString);
  
  String convertBinaryToHex(ByteArray paramByteArray);
  
  String convertOctalToBinary(String paramString);
  
  String convertOctalToDecimal(String paramString);
  
  String convertOctalToHex(String paramString);
  
  String convertDecimalToBinary(String paramString);
  
  String convertDecimalToOctal(String paramString);
  
  String convertDecimalToHex(String paramString);
  
  String convertHexToBinary(String paramString);
  
  String convertHexToOctal(String paramString);
  
  String convertHexToDecimal(String paramString);
  
  String convertBinary(String paramString, int paramInt);
  
  String convertOctal(String paramString, int paramInt);
  
  String convertDecimal(String paramString, int paramInt);
  
  String convertHex(String paramString, int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\NumberUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */