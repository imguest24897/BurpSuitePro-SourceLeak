/*    */ package burp.api.montoya.utilities.json;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JsonNumberNode
/*    */   extends JsonNode
/*    */ {
/*    */   static JsonNumberNode jsonNumberNode(long value) {
/* 30 */     return ObjectFactoryLocator.FACTORY.jsonNumberNode(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static JsonNumberNode jsonNumberNode(double value) {
/* 42 */     return ObjectFactoryLocator.FACTORY.jsonNumberNode(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static JsonNumberNode jsonNumberNode(Number value) {
/* 54 */     return ObjectFactoryLocator.FACTORY.jsonNumberNode(value);
/*    */   }
/*    */   
/*    */   Number getValue();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonNumberNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */