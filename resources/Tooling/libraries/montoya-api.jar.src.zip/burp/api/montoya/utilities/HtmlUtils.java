package burp.api.montoya.utilities;

public interface HtmlUtils {
  String encode(String paramString);
  
  String encode(String paramString, HtmlEncoding paramHtmlEncoding);
  
  String decode(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\HtmlUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */