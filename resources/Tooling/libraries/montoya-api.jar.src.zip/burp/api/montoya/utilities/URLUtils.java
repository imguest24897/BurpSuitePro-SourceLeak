package burp.api.montoya.utilities;

import burp.api.montoya.core.ByteArray;

public interface URLUtils {
  String encode(String paramString);
  
  String decode(String paramString);
  
  ByteArray encode(ByteArray paramByteArray);
  
  ByteArray decode(ByteArray paramByteArray);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\URLUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */