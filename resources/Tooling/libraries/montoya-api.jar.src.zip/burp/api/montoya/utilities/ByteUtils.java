package burp.api.montoya.utilities;

import java.util.regex.Pattern;

public interface ByteUtils {
  int indexOf(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  int indexOf(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean);
  
  int indexOf(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean, int paramInt1, int paramInt2);
  
  int indexOf(byte[] paramArrayOfbyte, Pattern paramPattern);
  
  int indexOf(byte[] paramArrayOfbyte, Pattern paramPattern, int paramInt1, int paramInt2);
  
  int countMatches(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  int countMatches(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean);
  
  int countMatches(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean, int paramInt1, int paramInt2);
  
  int countMatches(byte[] paramArrayOfbyte, Pattern paramPattern);
  
  int countMatches(byte[] paramArrayOfbyte, Pattern paramPattern, int paramInt1, int paramInt2);
  
  String convertToString(byte[] paramArrayOfbyte);
  
  byte[] convertFromString(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\ByteUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */