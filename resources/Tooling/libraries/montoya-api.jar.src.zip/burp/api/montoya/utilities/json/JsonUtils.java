package burp.api.montoya.utilities.json;

public interface JsonUtils {
  String add(String paramString1, String paramString2, String paramString3);
  
  String update(String paramString1, String paramString2, String paramString3);
  
  String remove(String paramString1, String paramString2);
  
  String read(String paramString1, String paramString2);
  
  Boolean readBoolean(String paramString1, String paramString2);
  
  Double readDouble(String paramString1, String paramString2);
  
  Long readLong(String paramString1, String paramString2);
  
  String readString(String paramString1, String paramString2);
  
  boolean isValidJson(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */