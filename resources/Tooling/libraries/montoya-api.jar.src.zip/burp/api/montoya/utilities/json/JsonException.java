/*    */ package burp.api.montoya.utilities.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonException
/*    */   extends RuntimeException
/*    */ {
/*    */   public JsonException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */