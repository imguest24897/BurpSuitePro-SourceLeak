/*     */ package burp.api.montoya.utilities.json;
/*     */ 
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface JsonArrayNode
/*     */   extends JsonNode
/*     */ {
/*     */   static JsonArrayNode jsonArrayNode() {
/* 143 */     return ObjectFactoryLocator.FACTORY.jsonArrayNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonArrayNode jsonArrayNode(List<? extends JsonNode> value) {
/* 155 */     return ObjectFactoryLocator.FACTORY.jsonArrayNode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonArrayNode jsonArrayNode(JsonNode... values) {
/* 167 */     return ObjectFactoryLocator.FACTORY.jsonArrayNode(values);
/*     */   }
/*     */   
/*     */   List<JsonNode> getValue();
/*     */   
/*     */   List<JsonNode> asList();
/*     */   
/*     */   void add(JsonNode paramJsonNode);
/*     */   
/*     */   void addString(String paramString);
/*     */   
/*     */   void addBoolean(boolean paramBoolean);
/*     */   
/*     */   void addNumber(long paramLong);
/*     */   
/*     */   void addNumber(double paramDouble);
/*     */   
/*     */   void addNumber(Number paramNumber);
/*     */   
/*     */   JsonNode get(int paramInt);
/*     */   
/*     */   String getString(int paramInt);
/*     */   
/*     */   Boolean getBoolean(int paramInt);
/*     */   
/*     */   Long getLong(int paramInt);
/*     */   
/*     */   Double getDouble(int paramInt);
/*     */   
/*     */   Number getNumber(int paramInt);
/*     */   
/*     */   void remove(int paramInt);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonArrayNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */