/*    */ package burp.api.montoya.utilities.json;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JsonStringNode
/*    */   extends JsonNode
/*    */ {
/*    */   static JsonStringNode jsonStringNode(String value) {
/* 30 */     return ObjectFactoryLocator.FACTORY.jsonStringNode(value);
/*    */   }
/*    */   
/*    */   String getValue();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonStringNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */