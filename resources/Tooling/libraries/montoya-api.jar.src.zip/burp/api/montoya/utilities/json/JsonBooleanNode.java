/*    */ package burp.api.montoya.utilities.json;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface JsonBooleanNode
/*    */   extends JsonNode
/*    */ {
/*    */   static JsonBooleanNode jsonBooleanNode(boolean value) {
/* 30 */     return ObjectFactoryLocator.FACTORY.jsonBooleanNode(value);
/*    */   }
/*    */   
/*    */   Boolean getValue();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonBooleanNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */