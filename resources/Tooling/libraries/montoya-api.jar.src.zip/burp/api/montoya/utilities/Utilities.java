package burp.api.montoya.utilities;

import burp.api.montoya.utilities.json.JsonUtils;

public interface Utilities {
  Base64Utils base64Utils();
  
  ByteUtils byteUtils();
  
  CompressionUtils compressionUtils();
  
  CryptoUtils cryptoUtils();
  
  HtmlUtils htmlUtils();
  
  NumberUtils numberUtils();
  
  RandomUtils randomUtils();
  
  StringUtils stringUtils();
  
  URLUtils urlUtils();
  
  JsonUtils jsonUtils();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\Utilities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */