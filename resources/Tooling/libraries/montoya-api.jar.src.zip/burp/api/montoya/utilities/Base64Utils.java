package burp.api.montoya.utilities;

import burp.api.montoya.core.ByteArray;

public interface Base64Utils {
  ByteArray encode(ByteArray paramByteArray, Base64EncodingOptions... paramVarArgs);
  
  ByteArray encode(String paramString, Base64EncodingOptions... paramVarArgs);
  
  String encodeToString(ByteArray paramByteArray, Base64EncodingOptions... paramVarArgs);
  
  String encodeToString(String paramString, Base64EncodingOptions... paramVarArgs);
  
  ByteArray decode(ByteArray paramByteArray, Base64DecodingOptions... paramVarArgs);
  
  ByteArray decode(String paramString, Base64DecodingOptions... paramVarArgs);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\Base64Utils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */