/*     */ package burp.api.montoya.utilities.json;
/*     */ 
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface JsonObjectNode
/*     */   extends JsonNode
/*     */ {
/*     */   static JsonObjectNode jsonObjectNode() {
/* 203 */     return ObjectFactoryLocator.FACTORY.jsonObjectNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonObjectNode jsonObjectNode(Map<String, ? extends JsonNode> value) {
/* 215 */     return ObjectFactoryLocator.FACTORY.jsonObjectNode(value);
/*     */   }
/*     */   
/*     */   Map<String, JsonNode> getValue();
/*     */   
/*     */   Map<String, JsonNode> asMap();
/*     */   
/*     */   void put(String paramString, JsonNode paramJsonNode);
/*     */   
/*     */   void putString(String paramString1, String paramString2);
/*     */   
/*     */   void putBoolean(String paramString, boolean paramBoolean);
/*     */   
/*     */   void putNumber(String paramString, long paramLong);
/*     */   
/*     */   void putNumber(String paramString, double paramDouble);
/*     */   
/*     */   void putNumber(String paramString, Number paramNumber);
/*     */   
/*     */   JsonNode get(String paramString);
/*     */   
/*     */   String getString(String paramString);
/*     */   
/*     */   Boolean getBoolean(String paramString);
/*     */   
/*     */   Long getLong(String paramString);
/*     */   
/*     */   Double getDouble(String paramString);
/*     */   
/*     */   Number getNumber(String paramString);
/*     */   
/*     */   void remove(String paramString);
/*     */   
/*     */   boolean has(String paramString);
/*     */   
/*     */   boolean hasString(String paramString);
/*     */   
/*     */   boolean hasBoolean(String paramString);
/*     */   
/*     */   boolean hasNumber(String paramString);
/*     */   
/*     */   boolean hasArray(String paramString);
/*     */   
/*     */   boolean hasObject(String paramString);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoy\\utilities\json\JsonObjectNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */