package burp.api.montoya.scanner;

import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.scanner.audit.insertionpoint.AuditInsertionPoint;
import burp.api.montoya.scanner.audit.issues.AuditIssue;

public interface ScanCheck {
  AuditResult activeAudit(HttpRequestResponse paramHttpRequestResponse, AuditInsertionPoint paramAuditInsertionPoint);
  
  AuditResult passiveAudit(HttpRequestResponse paramHttpRequestResponse);
  
  ConsolidationAction consolidateIssues(AuditIssue paramAuditIssue1, AuditIssue paramAuditIssue2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\ScanCheck.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */