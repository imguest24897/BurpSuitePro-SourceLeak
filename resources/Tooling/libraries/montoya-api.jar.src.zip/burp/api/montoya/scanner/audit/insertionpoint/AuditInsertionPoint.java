/*     */ package burp.api.montoya.scanner.audit.insertionpoint;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.core.Range;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AuditInsertionPoint
/*     */ {
/*     */   String name();
/*     */   
/*     */   String baseValue();
/*     */   
/*     */   HttpRequest buildHttpRequestWithPayload(ByteArray paramByteArray);
/*     */   
/*     */   List<Range> issueHighlights(ByteArray paramByteArray);
/*     */   
/*     */   default AuditInsertionPointType type() {
/*  89 */     return AuditInsertionPointType.EXTENSION_PROVIDED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AuditInsertionPoint auditInsertionPoint(String name, HttpRequest baseRequest, int startIndexInclusive, int endIndexExclusive) {
/* 104 */     return ObjectFactoryLocator.FACTORY.auditInsertionPoint(name, baseRequest, startIndexInclusive, endIndexExclusive);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\audit\insertionpoint\AuditInsertionPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */