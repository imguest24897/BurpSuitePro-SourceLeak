/*    */ package burp.api.montoya.scanner;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ import burp.api.montoya.scanner.audit.issues.AuditIssue;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AuditResult
/*    */ {
/*    */   List<AuditIssue> auditIssues();
/*    */   
/*    */   static AuditResult auditResult(List<AuditIssue> auditIssues) {
/* 23 */     return ObjectFactoryLocator.FACTORY.auditResult(auditIssues);
/*    */   }
/*    */ 
/*    */   
/*    */   static AuditResult auditResult(AuditIssue... auditIssues) {
/* 28 */     return ObjectFactoryLocator.FACTORY.auditResult(auditIssues);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\AuditResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */