package burp.api.montoya.scanner;

import burp.api.montoya.core.Registration;
import burp.api.montoya.scanner.audit.Audit;
import burp.api.montoya.scanner.audit.AuditIssueHandler;
import burp.api.montoya.scanner.audit.insertionpoint.AuditInsertionPointProvider;
import burp.api.montoya.scanner.audit.issues.AuditIssue;
import burp.api.montoya.scanner.bchecks.BChecks;
import java.nio.file.Path;
import java.util.List;

public interface Scanner {
  Registration registerAuditIssueHandler(AuditIssueHandler paramAuditIssueHandler);
  
  Registration registerScanCheck(ScanCheck paramScanCheck);
  
  Registration registerInsertionPointProvider(AuditInsertionPointProvider paramAuditInsertionPointProvider);
  
  Crawl startCrawl(CrawlConfiguration paramCrawlConfiguration);
  
  Audit startAudit(AuditConfiguration paramAuditConfiguration);
  
  void generateReport(List<AuditIssue> paramList, ReportFormat paramReportFormat, Path paramPath);
  
  BChecks bChecks();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\Scanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */