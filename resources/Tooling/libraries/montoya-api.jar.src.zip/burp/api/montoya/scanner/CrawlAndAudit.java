package burp.api.montoya.scanner;

public interface CrawlAndAudit extends ScanTask {
  int requestCount();
  
  int errorCount();
  
  void delete();
  
  String statusMessage();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\CrawlAndAudit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */