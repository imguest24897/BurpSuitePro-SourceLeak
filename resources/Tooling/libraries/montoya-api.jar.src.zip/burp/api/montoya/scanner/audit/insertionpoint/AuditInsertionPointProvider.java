package burp.api.montoya.scanner.audit.insertionpoint;

import burp.api.montoya.http.message.HttpRequestResponse;
import java.util.List;

public interface AuditInsertionPointProvider {
  List<AuditInsertionPoint> provideInsertionPoints(HttpRequestResponse paramHttpRequestResponse);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\scanner\audit\insertionpoint\AuditInsertionPointProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */