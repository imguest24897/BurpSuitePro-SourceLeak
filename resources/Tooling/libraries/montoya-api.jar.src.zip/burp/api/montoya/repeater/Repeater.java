package burp.api.montoya.repeater;

import burp.api.montoya.http.message.requests.HttpRequest;

public interface Repeater {
  void sendToRepeater(HttpRequest paramHttpRequest);
  
  void sendToRepeater(HttpRequest paramHttpRequest, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\repeater\Repeater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */