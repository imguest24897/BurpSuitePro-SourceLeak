package burp.api.montoya;

public interface BurpExtension {
  void initialize(MontoyaApi paramMontoyaApi);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\BurpExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */