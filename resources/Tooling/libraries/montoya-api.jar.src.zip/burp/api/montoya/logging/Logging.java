package burp.api.montoya.logging;

import java.io.PrintStream;

public interface Logging {
  @Deprecated
  PrintStream output();
  
  @Deprecated
  PrintStream error();
  
  void logToOutput(String paramString);
  
  void logToError(String paramString);
  
  void logToError(String paramString, Throwable paramThrowable);
  
  void logToError(Throwable paramThrowable);
  
  void raiseDebugEvent(String paramString);
  
  void raiseInfoEvent(String paramString);
  
  void raiseErrorEvent(String paramString);
  
  void raiseCriticalEvent(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\logging\Logging.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */