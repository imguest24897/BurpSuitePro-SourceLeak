/*    */ package burp.api.montoya.intruder;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PayloadProcessingResult
/*    */ {
/*    */   ByteArray processedPayload();
/*    */   
/*    */   PayloadProcessingAction action();
/*    */   
/*    */   static PayloadProcessingResult usePayload(ByteArray processedPayload) {
/* 45 */     return ObjectFactoryLocator.FACTORY.usePayload(processedPayload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static PayloadProcessingResult skipPayload() {
/* 56 */     return ObjectFactoryLocator.FACTORY.skipPayload();
/*    */   }
/*    */ 
/*    */   
/*    */   static PayloadProcessingResult payloadProcessingResult(ByteArray processedPayload, PayloadProcessingAction action) {
/* 61 */     return ObjectFactoryLocator.FACTORY.payloadProcessingResult(processedPayload, action);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\PayloadProcessingResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */