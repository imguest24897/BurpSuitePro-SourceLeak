/*    */ package burp.api.montoya.intruder;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface GeneratedPayload
/*    */ {
/*    */   ByteArray value();
/*    */   
/*    */   static GeneratedPayload payload(String payload) {
/* 34 */     return ObjectFactoryLocator.FACTORY.payload(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static GeneratedPayload payload(ByteArray payload) {
/* 46 */     return ObjectFactoryLocator.FACTORY.payload(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static GeneratedPayload end() {
/* 56 */     return ObjectFactoryLocator.FACTORY.payloadEnd();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\GeneratedPayload.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */