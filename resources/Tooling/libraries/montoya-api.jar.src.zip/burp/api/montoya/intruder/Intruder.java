package burp.api.montoya.intruder;

import burp.api.montoya.core.Registration;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.message.requests.HttpRequest;

public interface Intruder {
  Registration registerPayloadProcessor(PayloadProcessor paramPayloadProcessor);
  
  Registration registerPayloadGeneratorProvider(PayloadGeneratorProvider paramPayloadGeneratorProvider);
  
  void sendToIntruder(HttpService paramHttpService, HttpRequestTemplate paramHttpRequestTemplate);
  
  void sendToIntruder(HttpService paramHttpService, HttpRequestTemplate paramHttpRequestTemplate, String paramString);
  
  void sendToIntruder(HttpRequest paramHttpRequest);
  
  void sendToIntruder(HttpRequest paramHttpRequest, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\Intruder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */