/*    */ package burp.api.montoya.intruder;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.core.Range;
/*    */ import burp.api.montoya.http.message.requests.HttpRequest;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface HttpRequestTemplate
/*    */ {
/*    */   ByteArray content();
/*    */   
/*    */   List<Range> insertionPointOffsets();
/*    */   
/*    */   static HttpRequestTemplate httpRequestTemplate(HttpRequest request, List<Range> insertionPointOffsets) {
/* 47 */     return ObjectFactoryLocator.FACTORY.httpRequestTemplate(request, insertionPointOffsets);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpRequestTemplate httpRequestTemplate(ByteArray content, List<Range> insertionPointOffsets) {
/* 61 */     return ObjectFactoryLocator.FACTORY.httpRequestTemplate(content, insertionPointOffsets);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpRequestTemplate httpRequestTemplate(HttpRequest request, HttpRequestTemplateGenerationOptions options) {
/* 75 */     return ObjectFactoryLocator.FACTORY.httpRequestTemplate(request, options);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static HttpRequestTemplate httpRequestTemplate(ByteArray content, HttpRequestTemplateGenerationOptions options) {
/* 89 */     return ObjectFactoryLocator.FACTORY.httpRequestTemplate(content, options);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\HttpRequestTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */