package burp.api.montoya.intruder;

public interface PayloadGeneratorProvider {
  String displayName();
  
  PayloadGenerator providePayloadGenerator(AttackConfiguration paramAttackConfiguration);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\PayloadGeneratorProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */