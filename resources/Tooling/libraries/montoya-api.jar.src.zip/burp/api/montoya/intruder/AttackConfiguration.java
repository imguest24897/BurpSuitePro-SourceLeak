package burp.api.montoya.intruder;

import burp.api.montoya.http.HttpService;
import java.util.Optional;

public interface AttackConfiguration {
  Optional<HttpService> httpService();
  
  HttpRequestTemplate requestTemplate();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\intruder\AttackConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */