package burp.api.montoya.burpsuite;

import burp.api.montoya.core.Version;
import java.util.List;

public interface BurpSuite {
  Version version();
  
  String exportProjectOptionsAsJson(String... paramVarArgs);
  
  void importProjectOptionsFromJson(String paramString);
  
  String exportUserOptionsAsJson(String... paramVarArgs);
  
  void importUserOptionsFromJson(String paramString);
  
  List<String> commandLineArguments();
  
  void shutdown(ShutdownOptions... paramVarArgs);
  
  TaskExecutionEngine taskExecutionEngine();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\burpsuite\BurpSuite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */