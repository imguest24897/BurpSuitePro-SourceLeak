package burp.api.montoya.decoder;

import burp.api.montoya.core.ByteArray;

public interface Decoder {
  void sendToDecoder(ByteArray paramByteArray);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\decoder\Decoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */