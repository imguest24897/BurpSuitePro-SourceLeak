package burp.api.montoya.extension;

import burp.api.montoya.core.Registration;

public interface Extension {
  void setName(String paramString);
  
  String filename();
  
  boolean isBapp();
  
  void unload();
  
  Registration registerUnloadingHandler(ExtensionUnloadingHandler paramExtensionUnloadingHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\extension\Extension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */