package burp.api.montoya.extension;

public interface ExtensionUnloadingHandler {
  void extensionUnloaded();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\extension\ExtensionUnloadingHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */