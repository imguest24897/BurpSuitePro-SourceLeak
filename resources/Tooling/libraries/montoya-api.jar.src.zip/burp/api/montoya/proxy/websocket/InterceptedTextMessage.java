package burp.api.montoya.proxy.websocket;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.websocket.Direction;
import burp.api.montoya.websocket.TextMessage;

public interface InterceptedTextMessage extends TextMessage {
  Annotations annotations();
  
  String payload();
  
  Direction direction();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\InterceptedTextMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */