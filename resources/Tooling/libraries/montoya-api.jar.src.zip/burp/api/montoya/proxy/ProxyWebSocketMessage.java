package burp.api.montoya.proxy;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.ui.contextmenu.WebSocketMessage;
import burp.api.montoya.websocket.Direction;
import java.time.ZonedDateTime;
import java.util.regex.Pattern;

public interface ProxyWebSocketMessage extends WebSocketMessage {
  Annotations annotations();
  
  Direction direction();
  
  ByteArray payload();
  
  HttpRequest upgradeRequest();
  
  int webSocketId();
  
  ZonedDateTime time();
  
  ByteArray editedPayload();
  
  int listenerPort();
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\ProxyWebSocketMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */