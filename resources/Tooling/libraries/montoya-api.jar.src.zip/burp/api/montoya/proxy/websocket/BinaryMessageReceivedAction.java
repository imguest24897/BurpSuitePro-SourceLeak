/*     */ package burp.api.montoya.proxy.websocket;
/*     */ 
/*     */ import burp.api.montoya.core.ByteArray;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import burp.api.montoya.proxy.MessageReceivedAction;
/*     */ import burp.api.montoya.websocket.BinaryMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BinaryMessageReceivedAction
/*     */ {
/*     */   MessageReceivedAction action();
/*     */   
/*     */   ByteArray payload();
/*     */   
/*     */   static BinaryMessageReceivedAction continueWith(ByteArray payload) {
/*  45 */     return ObjectFactoryLocator.FACTORY.followUserRulesInitialProxyBinaryMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction continueWith(BinaryMessage message) {
/*  60 */     return ObjectFactoryLocator.FACTORY.followUserRulesInitialProxyBinaryMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction intercept(ByteArray payload) {
/*  72 */     return ObjectFactoryLocator.FACTORY.interceptInitialProxyBinaryMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction intercept(BinaryMessage message) {
/*  84 */     return ObjectFactoryLocator.FACTORY.interceptInitialProxyBinaryMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction doNotIntercept(ByteArray payload) {
/*  96 */     return ObjectFactoryLocator.FACTORY.doNotInterceptInitialProxyBinaryMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction doNotIntercept(BinaryMessage message) {
/* 108 */     return ObjectFactoryLocator.FACTORY.doNotInterceptInitialProxyBinaryMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BinaryMessageReceivedAction drop() {
/* 118 */     return ObjectFactoryLocator.FACTORY.dropInitialProxyBinaryMessage();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\BinaryMessageReceivedAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */