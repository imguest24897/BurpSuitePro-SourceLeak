package burp.api.montoya.proxy;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.handler.TimingData;
import burp.api.montoya.http.message.MimeType;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import java.time.ZonedDateTime;
import java.util.regex.Pattern;

public interface ProxyHttpRequestResponse {
  HttpRequest request();
  
  HttpRequest finalRequest();
  
  HttpResponse response();
  
  HttpResponse originalResponse();
  
  Annotations annotations();
  
  HttpService httpService();
  
  @Deprecated(forRemoval = true)
  String url();
  
  @Deprecated(forRemoval = true)
  String method();
  
  @Deprecated(forRemoval = true)
  String path();
  
  @Deprecated(forRemoval = true)
  String host();
  
  @Deprecated(forRemoval = true)
  int port();
  
  @Deprecated(forRemoval = true)
  boolean secure();
  
  @Deprecated(forRemoval = true)
  String httpServiceString();
  
  @Deprecated(forRemoval = true)
  String requestHttpVersion();
  
  @Deprecated(forRemoval = true)
  String requestBody();
  
  boolean edited();
  
  ZonedDateTime time();
  
  int listenerPort();
  
  MimeType mimeType();
  
  boolean hasResponse();
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
  
  TimingData timingData();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\ProxyHttpRequestResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */