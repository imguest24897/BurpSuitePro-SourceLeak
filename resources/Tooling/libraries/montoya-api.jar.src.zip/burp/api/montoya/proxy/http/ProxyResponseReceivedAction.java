/*     */ package burp.api.montoya.proxy.http;
/*     */ 
/*     */ import burp.api.montoya.core.Annotations;
/*     */ import burp.api.montoya.http.message.responses.HttpResponse;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import burp.api.montoya.proxy.MessageReceivedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ProxyResponseReceivedAction
/*     */ {
/*     */   MessageReceivedAction action();
/*     */   
/*     */   HttpResponse response();
/*     */   
/*     */   Annotations annotations();
/*     */   
/*     */   static ProxyResponseReceivedAction continueWith(HttpResponse response) {
/*  62 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultFollowUserRules(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction continueWith(HttpResponse response, Annotations annotations) {
/*  81 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultFollowUserRules(response, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction intercept(HttpResponse response) {
/*  98 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultIntercept(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction intercept(HttpResponse response, Annotations annotations) {
/* 116 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultIntercept(response, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction doNotIntercept(HttpResponse response) {
/* 132 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultDoNotIntercept(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction doNotIntercept(HttpResponse response, Annotations annotations) {
/* 149 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultDoNotIntercept(response, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction drop() {
/* 161 */     return ObjectFactoryLocator.FACTORY.responseInitialInterceptResultDrop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyResponseReceivedAction proxyResponseReceivedAction(HttpResponse response, Annotations annotations, MessageReceivedAction action) {
/* 176 */     return ObjectFactoryLocator.FACTORY.proxyResponseReceivedAction(response, annotations, action);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\http\ProxyResponseReceivedAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */