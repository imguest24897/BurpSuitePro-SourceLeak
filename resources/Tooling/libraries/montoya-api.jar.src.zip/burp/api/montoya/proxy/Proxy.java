package burp.api.montoya.proxy;

import burp.api.montoya.core.Registration;
import burp.api.montoya.proxy.http.ProxyRequestHandler;
import burp.api.montoya.proxy.http.ProxyResponseHandler;
import burp.api.montoya.proxy.websocket.ProxyWebSocketCreationHandler;
import java.util.List;

public interface Proxy {
  void enableIntercept();
  
  void disableIntercept();
  
  boolean isInterceptEnabled();
  
  List<ProxyHttpRequestResponse> history();
  
  List<ProxyHttpRequestResponse> history(ProxyHistoryFilter paramProxyHistoryFilter);
  
  List<ProxyWebSocketMessage> webSocketHistory();
  
  List<ProxyWebSocketMessage> webSocketHistory(ProxyWebSocketHistoryFilter paramProxyWebSocketHistoryFilter);
  
  Registration registerRequestHandler(ProxyRequestHandler paramProxyRequestHandler);
  
  Registration registerResponseHandler(ProxyResponseHandler paramProxyResponseHandler);
  
  Registration registerWebSocketCreationHandler(ProxyWebSocketCreationHandler paramProxyWebSocketCreationHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\Proxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */