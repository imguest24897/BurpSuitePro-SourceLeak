package burp.api.montoya.proxy.websocket;

public interface ProxyMessageHandler {
  TextMessageReceivedAction handleTextMessageReceived(InterceptedTextMessage paramInterceptedTextMessage);
  
  TextMessageToBeSentAction handleTextMessageToBeSent(InterceptedTextMessage paramInterceptedTextMessage);
  
  BinaryMessageReceivedAction handleBinaryMessageReceived(InterceptedBinaryMessage paramInterceptedBinaryMessage);
  
  BinaryMessageToBeSentAction handleBinaryMessageToBeSent(InterceptedBinaryMessage paramInterceptedBinaryMessage);
  
  default void onClose() {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\ProxyMessageHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */