package burp.api.montoya.proxy.websocket;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.websocket.BinaryMessage;
import burp.api.montoya.websocket.Direction;

public interface InterceptedBinaryMessage extends BinaryMessage {
  Annotations annotations();
  
  ByteArray payload();
  
  Direction direction();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\InterceptedBinaryMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */