package burp.api.montoya.proxy.websocket;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Registration;
import burp.api.montoya.websocket.Direction;

public interface ProxyWebSocket {
  void sendTextMessage(String paramString, Direction paramDirection);
  
  void sendBinaryMessage(ByteArray paramByteArray, Direction paramDirection);
  
  void close();
  
  Registration registerProxyMessageHandler(ProxyMessageHandler paramProxyMessageHandler);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\ProxyWebSocket.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */