/*     */ package burp.api.montoya.proxy.http;
/*     */ 
/*     */ import burp.api.montoya.core.Annotations;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import burp.api.montoya.proxy.MessageReceivedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ProxyRequestReceivedAction
/*     */ {
/*     */   MessageReceivedAction action();
/*     */   
/*     */   HttpRequest request();
/*     */   
/*     */   Annotations annotations();
/*     */   
/*     */   static ProxyRequestReceivedAction continueWith(HttpRequest request) {
/*  61 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultFollowUserRules(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction continueWith(HttpRequest request, Annotations annotations) {
/*  80 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultFollowUserRules(request, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction intercept(HttpRequest request) {
/*  96 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultIntercept(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction intercept(HttpRequest request, Annotations annotations) {
/* 113 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultIntercept(request, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction doNotIntercept(HttpRequest request) {
/* 129 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultDoNotIntercept(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction doNotIntercept(HttpRequest request, Annotations annotations) {
/* 146 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultDoNotIntercept(request, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction drop() {
/* 158 */     return ObjectFactoryLocator.FACTORY.requestInitialInterceptResultDrop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestReceivedAction proxyRequestReceivedAction(HttpRequest request, Annotations annotations, MessageReceivedAction action) {
/* 174 */     return ObjectFactoryLocator.FACTORY.proxyRequestReceivedAction(request, annotations, action);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\http\ProxyRequestReceivedAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */