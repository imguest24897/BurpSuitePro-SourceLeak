/*    */ package burp.api.montoya.proxy.websocket;
/*    */ 
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ import burp.api.montoya.proxy.MessageToBeSentAction;
/*    */ import burp.api.montoya.websocket.TextMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TextMessageToBeSentAction
/*    */ {
/*    */   MessageToBeSentAction action();
/*    */   
/*    */   String payload();
/*    */   
/*    */   static TextMessageToBeSentAction continueWith(String payload) {
/* 42 */     return ObjectFactoryLocator.FACTORY.continueWithFinalProxyTextMessage(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TextMessageToBeSentAction continueWith(TextMessage message) {
/* 54 */     return ObjectFactoryLocator.FACTORY.continueWithFinalProxyTextMessage(message.payload());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TextMessageToBeSentAction drop() {
/* 64 */     return ObjectFactoryLocator.FACTORY.dropFinalProxyTextMessage();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\TextMessageToBeSentAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */