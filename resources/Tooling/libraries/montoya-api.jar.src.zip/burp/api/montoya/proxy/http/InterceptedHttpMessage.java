package burp.api.montoya.proxy.http;

import java.net.InetAddress;

public interface InterceptedHttpMessage {
  int messageId();
  
  String listenerInterface();
  
  InetAddress sourceIpAddress();
  
  InetAddress destinationIpAddress();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\http\InterceptedHttpMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */