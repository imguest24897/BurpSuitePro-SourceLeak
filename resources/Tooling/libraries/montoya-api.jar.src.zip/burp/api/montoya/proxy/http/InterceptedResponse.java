package burp.api.montoya.proxy.http;

import burp.api.montoya.core.Annotations;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.Marker;
import burp.api.montoya.http.message.Cookie;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.MimeType;
import burp.api.montoya.http.message.StatusCodeClass;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.responses.analysis.Attribute;
import burp.api.montoya.http.message.responses.analysis.AttributeType;
import burp.api.montoya.http.message.responses.analysis.KeywordCount;
import java.net.InetAddress;
import java.util.List;
import java.util.regex.Pattern;

public interface InterceptedResponse extends InterceptedHttpMessage, HttpResponse {
  HttpRequest request();
  
  HttpRequest initiatingRequest();
  
  Annotations annotations();
  
  short statusCode();
  
  String reasonPhrase();
  
  boolean isStatusCodeClass(StatusCodeClass paramStatusCodeClass);
  
  String httpVersion();
  
  List<HttpHeader> headers();
  
  boolean hasHeader(HttpHeader paramHttpHeader);
  
  boolean hasHeader(String paramString);
  
  boolean hasHeader(String paramString1, String paramString2);
  
  HttpHeader header(String paramString);
  
  String headerValue(String paramString);
  
  ByteArray body();
  
  String bodyToString();
  
  int bodyOffset();
  
  List<Marker> markers();
  
  List<Cookie> cookies();
  
  Cookie cookie(String paramString);
  
  String cookieValue(String paramString);
  
  boolean hasCookie(String paramString);
  
  boolean hasCookie(Cookie paramCookie);
  
  MimeType mimeType();
  
  MimeType statedMimeType();
  
  MimeType inferredMimeType();
  
  List<KeywordCount> keywordCounts(String... paramVarArgs);
  
  List<Attribute> attributes(AttributeType... paramVarArgs);
  
  boolean contains(String paramString, boolean paramBoolean);
  
  boolean contains(Pattern paramPattern);
  
  ByteArray toByteArray();
  
  String toString();
  
  HttpResponse withStatusCode(short paramShort);
  
  HttpResponse withReasonPhrase(String paramString);
  
  HttpResponse withHttpVersion(String paramString);
  
  HttpResponse withBody(String paramString);
  
  HttpResponse withBody(ByteArray paramByteArray);
  
  HttpResponse withAddedHeader(HttpHeader paramHttpHeader);
  
  HttpResponse withAddedHeader(String paramString1, String paramString2);
  
  HttpResponse withUpdatedHeader(HttpHeader paramHttpHeader);
  
  HttpResponse withUpdatedHeader(String paramString1, String paramString2);
  
  HttpResponse withRemovedHeader(HttpHeader paramHttpHeader);
  
  HttpResponse withRemovedHeader(String paramString);
  
  HttpResponse withMarkers(List<Marker> paramList);
  
  HttpResponse withMarkers(Marker... paramVarArgs);
  
  int messageId();
  
  String listenerInterface();
  
  InetAddress sourceIpAddress();
  
  InetAddress destinationIpAddress();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\http\InterceptedResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */