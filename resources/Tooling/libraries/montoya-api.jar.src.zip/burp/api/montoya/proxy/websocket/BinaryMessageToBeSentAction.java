/*    */ package burp.api.montoya.proxy.websocket;
/*    */ 
/*    */ import burp.api.montoya.core.ByteArray;
/*    */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*    */ import burp.api.montoya.proxy.MessageToBeSentAction;
/*    */ import burp.api.montoya.websocket.BinaryMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BinaryMessageToBeSentAction
/*    */ {
/*    */   MessageToBeSentAction action();
/*    */   
/*    */   ByteArray payload();
/*    */   
/*    */   static BinaryMessageToBeSentAction continueWith(ByteArray payload) {
/* 42 */     return ObjectFactoryLocator.FACTORY.continueWithFinalProxyBinaryMessage(payload);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BinaryMessageToBeSentAction continueWith(BinaryMessage message) {
/* 54 */     return ObjectFactoryLocator.FACTORY.continueWithFinalProxyBinaryMessage(message.payload());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static BinaryMessageToBeSentAction drop() {
/* 64 */     return ObjectFactoryLocator.FACTORY.dropFinalProxyBinaryMessage();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\BinaryMessageToBeSentAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */