/*     */ package burp.api.montoya.proxy.websocket;
/*     */ 
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import burp.api.montoya.proxy.MessageReceivedAction;
/*     */ import burp.api.montoya.websocket.TextMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TextMessageReceivedAction
/*     */ {
/*     */   MessageReceivedAction action();
/*     */   
/*     */   String payload();
/*     */   
/*     */   static TextMessageReceivedAction continueWith(String payload) {
/*  45 */     return ObjectFactoryLocator.FACTORY.followUserRulesInitialProxyTextMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction continueWith(TextMessage message) {
/*  60 */     return ObjectFactoryLocator.FACTORY.followUserRulesInitialProxyTextMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction intercept(String payload) {
/*  72 */     return ObjectFactoryLocator.FACTORY.interceptInitialProxyTextMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction intercept(TextMessage message) {
/*  84 */     return ObjectFactoryLocator.FACTORY.interceptInitialProxyTextMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction doNotIntercept(String payload) {
/*  96 */     return ObjectFactoryLocator.FACTORY.doNotInterceptInitialProxyTextMessage(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction doNotIntercept(TextMessage message) {
/* 108 */     return ObjectFactoryLocator.FACTORY.doNotInterceptInitialProxyTextMessage(message.payload());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextMessageReceivedAction drop() {
/* 118 */     return ObjectFactoryLocator.FACTORY.dropInitialProxyTextMessage();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\TextMessageReceivedAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */