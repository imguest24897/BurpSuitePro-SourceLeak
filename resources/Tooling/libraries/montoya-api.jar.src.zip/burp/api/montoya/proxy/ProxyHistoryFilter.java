package burp.api.montoya.proxy;

public interface ProxyHistoryFilter {
  boolean matches(ProxyHttpRequestResponse paramProxyHttpRequestResponse);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\ProxyHistoryFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */