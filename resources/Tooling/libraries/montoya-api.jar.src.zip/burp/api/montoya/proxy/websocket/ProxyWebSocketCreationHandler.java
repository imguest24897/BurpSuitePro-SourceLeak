package burp.api.montoya.proxy.websocket;

public interface ProxyWebSocketCreationHandler {
  void handleWebSocketCreation(ProxyWebSocketCreation paramProxyWebSocketCreation);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\websocket\ProxyWebSocketCreationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */