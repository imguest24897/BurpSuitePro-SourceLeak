/*     */ package burp.api.montoya.proxy.http;
/*     */ 
/*     */ import burp.api.montoya.core.Annotations;
/*     */ import burp.api.montoya.http.message.requests.HttpRequest;
/*     */ import burp.api.montoya.internal.ObjectFactoryLocator;
/*     */ import burp.api.montoya.proxy.MessageToBeSentAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ProxyRequestToBeSentAction
/*     */ {
/*     */   MessageToBeSentAction action();
/*     */   
/*     */   HttpRequest request();
/*     */   
/*     */   Annotations annotations();
/*     */   
/*     */   static ProxyRequestToBeSentAction continueWith(HttpRequest request) {
/*  60 */     return ObjectFactoryLocator.FACTORY.requestFinalInterceptResultContinueWith(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestToBeSentAction continueWith(HttpRequest request, Annotations annotations) {
/*  77 */     return ObjectFactoryLocator.FACTORY.requestFinalInterceptResultContinueWith(request, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestToBeSentAction drop() {
/*  89 */     return ObjectFactoryLocator.FACTORY.requestFinalInterceptResultDrop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyRequestToBeSentAction proxyRequestToBeSentAction(HttpRequest request, Annotations annotations, MessageToBeSentAction action) {
/* 105 */     return ObjectFactoryLocator.FACTORY.proxyRequestToBeSentAction(request, annotations, action);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\libraries\montoya-api.jar!\burp\api\montoya\proxy\http\ProxyRequestToBeSentAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */