package org.objectweb.asm;

class Frame {
  static final int[] a;
  
  Label b;
  
  int[] c;
  
  int[] d;
  
  private int[] e;
  
  private int[] f;
  
  int g;
  
  private int h;
  
  private int[] i;
  
  private static final String[] j;
  
  private static final String[] k;
  
  final void a(ClassWriter paramClassWriter, int paramInt1, Object[] paramArrayOfObject1, int paramInt2, Object[] paramArrayOfObject2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #6
    //   5: aload_1
    //   6: iload_2
    //   7: aload_3
    //   8: aload_0
    //   9: getfield c : [I
    //   12: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[Ljava/lang/Object;[I)I
    //   15: istore #7
    //   17: iload #7
    //   19: aload_3
    //   20: arraylength
    //   21: if_icmpge -> 41
    //   24: aload_0
    //   25: getfield c : [I
    //   28: iload #7
    //   30: iinc #7, 1
    //   33: ldc 16777216
    //   35: iastore
    //   36: iload #6
    //   38: ifeq -> 17
    //   41: iconst_0
    //   42: istore #8
    //   44: iconst_0
    //   45: istore #9
    //   47: iload #9
    //   49: iload #4
    //   51: if_icmpge -> 100
    //   54: aload #5
    //   56: iload #9
    //   58: aaload
    //   59: getstatic org/objectweb/asm/Opcodes.LONG : Ljava/lang/Integer;
    //   62: iload #6
    //   64: ifne -> 86
    //   67: if_acmpeq -> 89
    //   70: goto -> 74
    //   73: athrow
    //   74: aload #5
    //   76: iload #9
    //   78: aaload
    //   79: getstatic org/objectweb/asm/Opcodes.DOUBLE : Ljava/lang/Integer;
    //   82: goto -> 86
    //   85: athrow
    //   86: if_acmpne -> 92
    //   89: iinc #8, 1
    //   92: iinc #9, 1
    //   95: iload #6
    //   97: ifeq -> 47
    //   100: aload_0
    //   101: iload #4
    //   103: iload #8
    //   105: iadd
    //   106: newarray int
    //   108: putfield d : [I
    //   111: aload_1
    //   112: iload #4
    //   114: aload #5
    //   116: aload_0
    //   117: getfield d : [I
    //   120: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[Ljava/lang/Object;[I)I
    //   123: pop
    //   124: aload_0
    //   125: iconst_0
    //   126: putfield g : I
    //   129: aload_0
    //   130: iconst_0
    //   131: putfield h : I
    //   134: return
    // Exception table:
    //   from	to	target	type
    //   54	70	73	java/lang/RuntimeException
    //   67	82	85	java/lang/RuntimeException
  }
  
  private static int a(ClassWriter paramClassWriter, int paramInt, Object[] paramArrayOfObject, int[] paramArrayOfint) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: iconst_0
    //   7: istore #6
    //   9: istore #4
    //   11: iload #6
    //   13: iload_1
    //   14: if_icmpge -> 205
    //   17: aload_2
    //   18: iload #6
    //   20: aaload
    //   21: instanceof java/lang/Integer
    //   24: iload #4
    //   26: ifne -> 207
    //   29: iload #4
    //   31: ifne -> 131
    //   34: goto -> 38
    //   37: athrow
    //   38: ifeq -> 120
    //   41: goto -> 45
    //   44: athrow
    //   45: aload_3
    //   46: iload #5
    //   48: iinc #5, 1
    //   51: ldc 16777216
    //   53: aload_2
    //   54: iload #6
    //   56: aaload
    //   57: checkcast java/lang/Integer
    //   60: invokevirtual intValue : ()I
    //   63: ior
    //   64: iastore
    //   65: iload #4
    //   67: ifne -> 115
    //   70: goto -> 74
    //   73: athrow
    //   74: aload_2
    //   75: iload #6
    //   77: aaload
    //   78: getstatic org/objectweb/asm/Opcodes.LONG : Ljava/lang/Integer;
    //   81: if_acmpeq -> 102
    //   84: goto -> 88
    //   87: athrow
    //   88: aload_2
    //   89: iload #6
    //   91: aaload
    //   92: getstatic org/objectweb/asm/Opcodes.DOUBLE : Ljava/lang/Integer;
    //   95: if_acmpne -> 197
    //   98: goto -> 102
    //   101: athrow
    //   102: aload_3
    //   103: iload #5
    //   105: iinc #5, 1
    //   108: ldc 16777216
    //   110: iastore
    //   111: goto -> 115
    //   114: athrow
    //   115: iload #4
    //   117: ifeq -> 197
    //   120: aload_2
    //   121: iload #6
    //   123: aaload
    //   124: instanceof java/lang/String
    //   127: goto -> 131
    //   130: athrow
    //   131: ifeq -> 167
    //   134: aload_3
    //   135: iload #5
    //   137: iinc #5, 1
    //   140: aload_0
    //   141: aload_2
    //   142: iload #6
    //   144: aaload
    //   145: checkcast java/lang/String
    //   148: invokestatic getObjectType : (Ljava/lang/String;)Lorg/objectweb/asm/Type;
    //   151: invokevirtual getDescriptor : ()Ljava/lang/String;
    //   154: invokestatic b : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)I
    //   157: iastore
    //   158: iload #4
    //   160: ifeq -> 197
    //   163: goto -> 167
    //   166: athrow
    //   167: aload_3
    //   168: iload #5
    //   170: iinc #5, 1
    //   173: ldc 25165824
    //   175: aload_0
    //   176: ldc ''
    //   178: aload_2
    //   179: iload #6
    //   181: aaload
    //   182: checkcast org/objectweb/asm/Label
    //   185: getfield c : I
    //   188: invokevirtual a : (Ljava/lang/String;I)I
    //   191: ior
    //   192: iastore
    //   193: goto -> 197
    //   196: athrow
    //   197: iinc #6, 1
    //   200: iload #4
    //   202: ifeq -> 11
    //   205: iload #5
    //   207: ireturn
    // Exception table:
    //   from	to	target	type
    //   17	34	37	java/lang/RuntimeException
    //   29	41	44	java/lang/RuntimeException
    //   38	70	73	java/lang/RuntimeException
    //   45	84	87	java/lang/RuntimeException
    //   74	98	101	java/lang/RuntimeException
    //   88	111	114	java/lang/RuntimeException
    //   115	127	130	java/lang/RuntimeException
    //   131	163	166	java/lang/RuntimeException
    //   134	193	196	java/lang/RuntimeException
  }
  
  final void b(Frame paramFrame) {
    this.c = paramFrame.c;
    this.d = paramFrame.d;
    this.e = paramFrame.e;
    this.f = paramFrame.f;
    this.g = paramFrame.g;
    this.h = paramFrame.h;
    this.i = paramFrame.i;
  }
  
  private int a(int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield e : [I
    //   8: ifnull -> 32
    //   11: iload_1
    //   12: iload_2
    //   13: ifne -> 44
    //   16: goto -> 20
    //   19: athrow
    //   20: aload_0
    //   21: getfield e : [I
    //   24: arraylength
    //   25: if_icmplt -> 38
    //   28: goto -> 32
    //   31: athrow
    //   32: ldc 33554432
    //   34: iload_1
    //   35: ior
    //   36: ireturn
    //   37: athrow
    //   38: aload_0
    //   39: getfield e : [I
    //   42: iload_1
    //   43: iaload
    //   44: istore_3
    //   45: iload_3
    //   46: iload_2
    //   47: ifne -> 70
    //   50: ifne -> 69
    //   53: goto -> 57
    //   56: athrow
    //   57: aload_0
    //   58: getfield e : [I
    //   61: iload_1
    //   62: ldc 33554432
    //   64: iload_1
    //   65: ior
    //   66: dup_x2
    //   67: iastore
    //   68: istore_3
    //   69: iload_3
    //   70: ireturn
    // Exception table:
    //   from	to	target	type
    //   4	16	19	java/lang/RuntimeException
    //   11	28	31	java/lang/RuntimeException
    //   20	37	37	java/lang/RuntimeException
    //   45	53	56	java/lang/RuntimeException
  }
  
  private void a(int paramInt1, int paramInt2) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.e == null)
            this.e = new int[10]; 
        } catch (RuntimeException runtimeException) {
          throw null;
        }  
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    int j = this.e.length;
    try {
      if (i == 0) {
        if (paramInt1 >= j) {
          int[] arrayOfInt = new int[Math.max(paramInt1 + 1, 2 * j)];
          System.arraycopy(this.e, 0, arrayOfInt, 0, j);
          this.e = arrayOfInt;
        } 
        this.e[paramInt1] = paramInt2;
      } 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
  }
  
  private void b(int paramInt) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.f == null)
            this.f = new int[10]; 
        } catch (RuntimeException runtimeException) {
          throw null;
        }  
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    int j = this.f.length;
    try {
      if (i == 0) {
        if (this.g >= j) {
          int[] arrayOfInt = new int[Math.max(this.g + 1, 2 * j)];
          System.arraycopy(this.f, 0, arrayOfInt, 0, j);
          this.f = arrayOfInt;
        } 
        this.f[this.g++] = paramInt;
      } 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    int k = this.b.f + this.g;
    try {
      if (k > this.b.g)
        this.b.g = k; 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
  }
  
  private void a(ClassWriter paramClassWriter, String paramString) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_1
    //   5: aload_2
    //   6: invokestatic b : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)I
    //   9: istore #4
    //   11: iload #4
    //   13: iload_3
    //   14: ifne -> 44
    //   17: ifeq -> 70
    //   20: goto -> 24
    //   23: athrow
    //   24: aload_0
    //   25: iload #4
    //   27: iload_3
    //   28: ifne -> 67
    //   31: goto -> 35
    //   34: athrow
    //   35: invokespecial b : (I)V
    //   38: iload #4
    //   40: goto -> 44
    //   43: athrow
    //   44: ldc 16777220
    //   46: if_icmpeq -> 60
    //   49: iload #4
    //   51: ldc 16777219
    //   53: if_icmpne -> 70
    //   56: goto -> 60
    //   59: athrow
    //   60: aload_0
    //   61: ldc 16777216
    //   63: goto -> 67
    //   66: athrow
    //   67: invokespecial b : (I)V
    //   70: return
    // Exception table:
    //   from	to	target	type
    //   11	20	23	java/lang/RuntimeException
    //   17	31	34	java/lang/RuntimeException
    //   24	40	43	java/lang/RuntimeException
    //   44	56	59	java/lang/RuntimeException
    //   49	63	66	java/lang/RuntimeException
  }
  
  private static int b(ClassWriter paramClassWriter, String paramString) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: iconst_0
    //   6: invokevirtual charAt : (I)C
    //   9: bipush #40
    //   11: iload_2
    //   12: ifne -> 33
    //   15: if_icmpne -> 37
    //   18: goto -> 22
    //   21: athrow
    //   22: aload_1
    //   23: bipush #41
    //   25: invokevirtual indexOf : (I)I
    //   28: iconst_1
    //   29: goto -> 33
    //   32: athrow
    //   33: iadd
    //   34: goto -> 38
    //   37: iconst_0
    //   38: istore #4
    //   40: aload_1
    //   41: iload #4
    //   43: invokevirtual charAt : (I)C
    //   46: iload_2
    //   47: ifne -> 208
    //   50: tableswitch default -> 204, 66 -> 168, 67 -> 168, 68 -> 177, 69 -> 204, 70 -> 171, 71 -> 204, 72 -> 204, 73 -> 168, 74 -> 174, 75 -> 204, 76 -> 180, 77 -> 204, 78 -> 204, 79 -> 204, 80 -> 204, 81 -> 204, 82 -> 204, 83 -> 168, 84 -> 204, 85 -> 204, 86 -> 165, 87 -> 204, 88 -> 204, 89 -> 204, 90 -> 168
    //   164: athrow
    //   165: iconst_0
    //   166: ireturn
    //   167: athrow
    //   168: ldc 16777217
    //   170: ireturn
    //   171: ldc 16777218
    //   173: ireturn
    //   174: ldc 16777220
    //   176: ireturn
    //   177: ldc 16777219
    //   179: ireturn
    //   180: aload_1
    //   181: iload #4
    //   183: iconst_1
    //   184: iadd
    //   185: aload_1
    //   186: invokevirtual length : ()I
    //   189: iconst_1
    //   190: isub
    //   191: invokevirtual substring : (II)Ljava/lang/String;
    //   194: astore_3
    //   195: ldc 24117248
    //   197: aload_0
    //   198: aload_3
    //   199: invokevirtual c : (Ljava/lang/String;)I
    //   202: ior
    //   203: ireturn
    //   204: iload #4
    //   206: iconst_1
    //   207: iadd
    //   208: istore #6
    //   210: aload_1
    //   211: iload #6
    //   213: invokevirtual charAt : (I)C
    //   216: bipush #91
    //   218: if_icmpne -> 236
    //   221: iinc #6, 1
    //   224: iload_2
    //   225: ifne -> 369
    //   228: iload_2
    //   229: ifeq -> 210
    //   232: goto -> 236
    //   235: athrow
    //   236: aload_1
    //   237: iload #6
    //   239: iload_2
    //   240: ifne -> 434
    //   243: invokevirtual charAt : (I)C
    //   246: tableswitch default -> 425, 66 -> 377, 67 -> 369, 68 -> 417, 69 -> 425, 70 -> 401, 71 -> 425, 72 -> 425, 73 -> 393, 74 -> 409, 75 -> 425, 76 -> 425, 77 -> 425, 78 -> 425, 79 -> 425, 80 -> 425, 81 -> 425, 82 -> 425, 83 -> 385, 84 -> 425, 85 -> 425, 86 -> 425, 87 -> 425, 88 -> 425, 89 -> 425, 90 -> 361
    //   360: athrow
    //   361: ldc 16777225
    //   363: istore #5
    //   365: iload_2
    //   366: ifeq -> 454
    //   369: ldc 16777227
    //   371: istore #5
    //   373: iload_2
    //   374: ifeq -> 454
    //   377: ldc 16777226
    //   379: istore #5
    //   381: iload_2
    //   382: ifeq -> 454
    //   385: ldc 16777228
    //   387: istore #5
    //   389: iload_2
    //   390: ifeq -> 454
    //   393: ldc 16777217
    //   395: istore #5
    //   397: iload_2
    //   398: ifeq -> 454
    //   401: ldc 16777218
    //   403: istore #5
    //   405: iload_2
    //   406: ifeq -> 454
    //   409: ldc 16777220
    //   411: istore #5
    //   413: iload_2
    //   414: ifeq -> 454
    //   417: ldc 16777219
    //   419: istore #5
    //   421: iload_2
    //   422: ifeq -> 454
    //   425: aload_1
    //   426: iload #6
    //   428: iconst_1
    //   429: iadd
    //   430: goto -> 434
    //   433: athrow
    //   434: aload_1
    //   435: invokevirtual length : ()I
    //   438: iconst_1
    //   439: isub
    //   440: invokevirtual substring : (II)Ljava/lang/String;
    //   443: astore_3
    //   444: ldc 24117248
    //   446: aload_0
    //   447: aload_3
    //   448: invokevirtual c : (Ljava/lang/String;)I
    //   451: ior
    //   452: istore #5
    //   454: iload #6
    //   456: iload #4
    //   458: isub
    //   459: bipush #28
    //   461: ishl
    //   462: iload #5
    //   464: ior
    //   465: ireturn
    // Exception table:
    //   from	to	target	type
    //   4	18	21	java/lang/RuntimeException
    //   15	29	32	java/lang/RuntimeException
    //   40	164	164	java/lang/RuntimeException
    //   50	167	167	java/lang/RuntimeException
    //   221	232	235	java/lang/RuntimeException
    //   236	360	360	java/lang/RuntimeException
    //   421	430	433	java/lang/RuntimeException
  }
  
  private int a() {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.g > 0)
            return this.f[--this.g]; 
        } catch (RuntimeException runtimeException) {
          throw null;
        }  
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    return 0x3000000 | ---this.b.f;
  }
  
  private void c(int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: iload_2
    //   6: ifne -> 61
    //   9: getfield g : I
    //   12: iload_1
    //   13: if_icmplt -> 38
    //   16: goto -> 20
    //   19: athrow
    //   20: aload_0
    //   21: dup
    //   22: getfield g : I
    //   25: iload_1
    //   26: isub
    //   27: putfield g : I
    //   30: iload_2
    //   31: ifeq -> 65
    //   34: goto -> 38
    //   37: athrow
    //   38: aload_0
    //   39: getfield b : Lorg/objectweb/asm/Label;
    //   42: dup
    //   43: getfield f : I
    //   46: iload_1
    //   47: aload_0
    //   48: getfield g : I
    //   51: isub
    //   52: isub
    //   53: putfield f : I
    //   56: aload_0
    //   57: goto -> 61
    //   60: athrow
    //   61: iconst_0
    //   62: putfield g : I
    //   65: return
    // Exception table:
    //   from	to	target	type
    //   4	16	19	java/lang/RuntimeException
    //   9	34	37	java/lang/RuntimeException
    //   20	57	60	java/lang/RuntimeException
  }
  
  private void a(String paramString) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: iconst_0
    //   6: invokevirtual charAt : (I)C
    //   9: istore_3
    //   10: iload_3
    //   11: bipush #40
    //   13: iload_2
    //   14: ifne -> 51
    //   17: if_icmpne -> 44
    //   20: goto -> 24
    //   23: athrow
    //   24: aload_0
    //   25: aload_1
    //   26: invokestatic getArgumentsAndReturnSizes : (Ljava/lang/String;)I
    //   29: iconst_2
    //   30: ishr
    //   31: iconst_1
    //   32: isub
    //   33: invokespecial c : (I)V
    //   36: iload_2
    //   37: ifeq -> 94
    //   40: goto -> 44
    //   43: athrow
    //   44: iload_3
    //   45: bipush #74
    //   47: goto -> 51
    //   50: athrow
    //   51: iload_2
    //   52: ifne -> 69
    //   55: if_icmpeq -> 72
    //   58: goto -> 62
    //   61: athrow
    //   62: iload_3
    //   63: bipush #68
    //   65: goto -> 69
    //   68: athrow
    //   69: if_icmpne -> 85
    //   72: aload_0
    //   73: iconst_2
    //   74: invokespecial c : (I)V
    //   77: iload_2
    //   78: ifeq -> 94
    //   81: goto -> 85
    //   84: athrow
    //   85: aload_0
    //   86: iconst_1
    //   87: invokespecial c : (I)V
    //   90: goto -> 94
    //   93: athrow
    //   94: return
    // Exception table:
    //   from	to	target	type
    //   10	20	23	java/lang/RuntimeException
    //   17	40	43	java/lang/RuntimeException
    //   24	47	50	java/lang/RuntimeException
    //   51	58	61	java/lang/RuntimeException
    //   55	65	68	java/lang/RuntimeException
    //   69	81	84	java/lang/RuntimeException
    //   72	90	93	java/lang/RuntimeException
  }
  
  private void d(int paramInt) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.i == null)
            this.i = new int[2]; 
        } catch (RuntimeException runtimeException) {
          throw null;
        }  
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    int j = this.i.length;
    try {
      if (i == 0)
        if (this.h >= j) {
          int[] arrayOfInt = new int[Math.max(this.h + 1, 2 * j)];
          System.arraycopy(this.i, 0, arrayOfInt, 0, j);
          this.i = arrayOfInt;
        }  
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    this.i[this.h++] = paramInt;
  }
  
  private int a(ClassWriter paramClassWriter, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: iload_2
    //   5: ldc 16777222
    //   7: iload_3
    //   8: ifne -> 53
    //   11: if_icmpne -> 35
    //   14: goto -> 18
    //   17: athrow
    //   18: ldc 24117248
    //   20: aload_1
    //   21: aload_1
    //   22: getfield I : Ljava/lang/String;
    //   25: invokevirtual c : (Ljava/lang/String;)I
    //   28: ior
    //   29: istore #4
    //   31: iload_3
    //   32: ifeq -> 91
    //   35: iload_2
    //   36: ldc -1048576
    //   38: iand
    //   39: iload_3
    //   40: ifne -> 90
    //   43: goto -> 47
    //   46: athrow
    //   47: ldc 25165824
    //   49: goto -> 53
    //   52: athrow
    //   53: if_icmpne -> 85
    //   56: aload_1
    //   57: getfield H : [Lorg/objectweb/asm/Item;
    //   60: iload_2
    //   61: ldc 1048575
    //   63: iand
    //   64: aaload
    //   65: getfield g : Ljava/lang/String;
    //   68: astore #5
    //   70: ldc 24117248
    //   72: aload_1
    //   73: aload #5
    //   75: invokevirtual c : (Ljava/lang/String;)I
    //   78: ior
    //   79: istore #4
    //   81: iload_3
    //   82: ifeq -> 91
    //   85: iload_2
    //   86: goto -> 90
    //   89: athrow
    //   90: ireturn
    //   91: iconst_0
    //   92: istore #5
    //   94: iload #5
    //   96: aload_0
    //   97: getfield h : I
    //   100: if_icmpge -> 232
    //   103: aload_0
    //   104: getfield i : [I
    //   107: iload #5
    //   109: iaload
    //   110: istore #6
    //   112: iload #6
    //   114: ldc -268435456
    //   116: iand
    //   117: istore #7
    //   119: iload #6
    //   121: ldc 251658240
    //   123: iand
    //   124: istore #8
    //   126: iload #8
    //   128: iload_3
    //   129: ifne -> 233
    //   132: ldc 33554432
    //   134: iload_3
    //   135: ifne -> 176
    //   138: goto -> 142
    //   141: athrow
    //   142: if_icmpne -> 168
    //   145: goto -> 149
    //   148: athrow
    //   149: iload #7
    //   151: aload_0
    //   152: getfield c : [I
    //   155: iload #6
    //   157: ldc 8388607
    //   159: iand
    //   160: iaload
    //   161: iadd
    //   162: istore #6
    //   164: iload_3
    //   165: ifeq -> 208
    //   168: iload #8
    //   170: ldc 50331648
    //   172: goto -> 176
    //   175: athrow
    //   176: iload_3
    //   177: ifne -> 219
    //   180: if_icmpne -> 208
    //   183: goto -> 187
    //   186: athrow
    //   187: iload #7
    //   189: aload_0
    //   190: getfield d : [I
    //   193: aload_0
    //   194: getfield d : [I
    //   197: arraylength
    //   198: iload #6
    //   200: ldc 8388607
    //   202: iand
    //   203: isub
    //   204: iaload
    //   205: iadd
    //   206: istore #6
    //   208: iload_2
    //   209: iload_3
    //   210: ifne -> 224
    //   213: iload #6
    //   215: goto -> 219
    //   218: athrow
    //   219: if_icmpne -> 225
    //   222: iload #4
    //   224: ireturn
    //   225: iinc #5, 1
    //   228: iload_3
    //   229: ifeq -> 94
    //   232: iload_2
    //   233: ireturn
    // Exception table:
    //   from	to	target	type
    //   4	14	17	java/lang/RuntimeException
    //   31	43	46	java/lang/RuntimeException
    //   35	49	52	java/lang/RuntimeException
    //   81	86	89	java/lang/RuntimeException
    //   126	138	141	java/lang/RuntimeException
    //   132	145	148	java/lang/RuntimeException
    //   164	172	175	java/lang/RuntimeException
    //   176	183	186	java/lang/RuntimeException
    //   208	215	218	java/lang/RuntimeException
  }
  
  final void a(ClassWriter paramClassWriter, int paramInt1, Type[] paramArrayOfType, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iload #4
    //   3: newarray int
    //   5: putfield c : [I
    //   8: aload_0
    //   9: iconst_0
    //   10: newarray int
    //   12: putfield d : [I
    //   15: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   18: iconst_0
    //   19: istore #6
    //   21: istore #5
    //   23: iload_2
    //   24: bipush #8
    //   26: iand
    //   27: iload #5
    //   29: ifne -> 97
    //   32: ifne -> 96
    //   35: goto -> 39
    //   38: athrow
    //   39: iload_2
    //   40: ldc 524288
    //   42: iand
    //   43: ifne -> 80
    //   46: goto -> 50
    //   49: athrow
    //   50: aload_0
    //   51: getfield c : [I
    //   54: iload #6
    //   56: iinc #6, 1
    //   59: ldc 24117248
    //   61: aload_1
    //   62: aload_1
    //   63: getfield I : Ljava/lang/String;
    //   66: invokevirtual c : (Ljava/lang/String;)I
    //   69: ior
    //   70: iastore
    //   71: iload #5
    //   73: ifeq -> 96
    //   76: goto -> 80
    //   79: athrow
    //   80: aload_0
    //   81: getfield c : [I
    //   84: iload #6
    //   86: iinc #6, 1
    //   89: ldc 16777222
    //   91: iastore
    //   92: goto -> 96
    //   95: athrow
    //   96: iconst_0
    //   97: istore #7
    //   99: iload #7
    //   101: aload_3
    //   102: arraylength
    //   103: if_icmpge -> 191
    //   106: aload_1
    //   107: aload_3
    //   108: iload #7
    //   110: aaload
    //   111: invokevirtual getDescriptor : ()Ljava/lang/String;
    //   114: invokestatic b : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)I
    //   117: istore #8
    //   119: aload_0
    //   120: getfield c : [I
    //   123: iload #6
    //   125: iinc #6, 1
    //   128: iload #8
    //   130: iload #5
    //   132: ifne -> 182
    //   135: iastore
    //   136: iload #8
    //   138: ldc 16777220
    //   140: iload #5
    //   142: ifne -> 195
    //   145: goto -> 149
    //   148: athrow
    //   149: if_icmpeq -> 167
    //   152: goto -> 156
    //   155: athrow
    //   156: iload #8
    //   158: ldc 16777219
    //   160: if_icmpne -> 183
    //   163: goto -> 167
    //   166: athrow
    //   167: aload_0
    //   168: getfield c : [I
    //   171: iload #6
    //   173: iinc #6, 1
    //   176: ldc 16777216
    //   178: goto -> 182
    //   181: athrow
    //   182: iastore
    //   183: iinc #7, 1
    //   186: iload #5
    //   188: ifeq -> 99
    //   191: iload #6
    //   193: iload #4
    //   195: if_icmpge -> 219
    //   198: aload_0
    //   199: getfield c : [I
    //   202: iload #6
    //   204: iinc #6, 1
    //   207: ldc 16777216
    //   209: iastore
    //   210: iload #5
    //   212: ifeq -> 191
    //   215: goto -> 219
    //   218: athrow
    //   219: return
    // Exception table:
    //   from	to	target	type
    //   23	35	38	java/lang/RuntimeException
    //   32	46	49	java/lang/RuntimeException
    //   39	76	79	java/lang/RuntimeException
    //   50	92	95	java/lang/RuntimeException
    //   119	145	148	java/lang/RuntimeException
    //   135	152	155	java/lang/RuntimeException
    //   149	163	166	java/lang/RuntimeException
    //   156	178	181	java/lang/RuntimeException
    //   195	215	218	java/lang/RuntimeException
  }
  
  void a(int paramInt1, int paramInt2, ClassWriter paramClassWriter, Item paramItem) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: iload_1
    //   6: tableswitch default -> 2763, 0 -> 820, 1 -> 829, 2 -> 844, 3 -> 844, 4 -> 844, 5 -> 844, 6 -> 844, 7 -> 844, 8 -> 844, 9 -> 859, 10 -> 859, 11 -> 880, 12 -> 880, 13 -> 880, 14 -> 895, 15 -> 895, 16 -> 844, 17 -> 844, 18 -> 916, 19 -> 2763, 20 -> 2763, 21 -> 844, 22 -> 859, 23 -> 880, 24 -> 895, 25 -> 1181, 26 -> 2763, 27 -> 2763, 28 -> 2763, 29 -> 2763, 30 -> 2763, 31 -> 2763, 32 -> 2763, 33 -> 2763, 34 -> 2763, 35 -> 2763, 36 -> 2763, 37 -> 2763, 38 -> 2763, 39 -> 2763, 40 -> 2763, 41 -> 2763, 42 -> 2763, 43 -> 2763, 44 -> 2763, 45 -> 2763, 46 -> 1199, 47 -> 1219, 48 -> 1245, 49 -> 1265, 50 -> 1291, 51 -> 1199, 52 -> 1199, 53 -> 1199, 54 -> 1316, 55 -> 1444, 56 -> 1316, 57 -> 1444, 58 -> 1316, 59 -> 2763, 60 -> 2763, 61 -> 2763, 62 -> 2763, 63 -> 2763, 64 -> 2763, 65 -> 2763, 66 -> 2763, 67 -> 2763, 68 -> 2763, 69 -> 2763, 70 -> 2763, 71 -> 2763, 72 -> 2763, 73 -> 2763, 74 -> 2763, 75 -> 2763, 76 -> 2763, 77 -> 2763, 78 -> 2763, 79 -> 1586, 80 -> 1600, 81 -> 1586, 82 -> 1600, 83 -> 1586, 84 -> 1586, 85 -> 1586, 86 -> 1586, 87 -> 1614, 88 -> 1628, 89 -> 1642, 90 -> 1665, 91 -> 1700, 92 -> 1747, 93 -> 1788, 94 -> 1841, 95 -> 1906, 96 -> 1935, 97 -> 1955, 98 -> 1981, 99 -> 2001, 100 -> 1935, 101 -> 1955, 102 -> 1981, 103 -> 2001, 104 -> 1935, 105 -> 1955, 106 -> 1981, 107 -> 2001, 108 -> 1935, 109 -> 1955, 110 -> 1981, 111 -> 2001, 112 -> 1935, 113 -> 1955, 114 -> 1981, 115 -> 2001, 116 -> 820, 117 -> 820, 118 -> 820, 119 -> 820, 120 -> 1935, 121 -> 2027, 122 -> 1935, 123 -> 2027, 124 -> 1935, 125 -> 2027, 126 -> 1935, 127 -> 1955, 128 -> 1935, 129 -> 1955, 130 -> 1935, 131 -> 1955, 132 -> 2053, 133 -> 2069, 134 -> 2095, 135 -> 2115, 136 -> 1935, 137 -> 1981, 138 -> 1265, 139 -> 2141, 140 -> 2069, 141 -> 2115, 142 -> 1935, 143 -> 1219, 144 -> 1981, 145 -> 820, 146 -> 820, 147 -> 820, 148 -> 2161, 149 -> 1935, 150 -> 1935, 151 -> 2161, 152 -> 2161, 153 -> 1614, 154 -> 1614, 155 -> 1614, 156 -> 1614, 157 -> 1614, 158 -> 1614, 159 -> 1628, 160 -> 1628, 161 -> 1628, 162 -> 1628, 163 -> 1628, 164 -> 1628, 165 -> 1628, 166 -> 1628, 167 -> 820, 168 -> 2181, 169 -> 2181, 170 -> 1614, 171 -> 1614, 172 -> 1614, 173 -> 1628, 174 -> 1614, 175 -> 1628, 176 -> 1614, 177 -> 820, 178 -> 2199, 179 -> 2214, 180 -> 2232, 181 -> 2256, 182 -> 2279, 183 -> 2279, 184 -> 2279, 185 -> 2279, 186 -> 2373, 187 -> 2401, 188 -> 2427, 189 -> 2605, 190 -> 2141, 191 -> 1614, 192 -> 2693, 193 -> 2141, 194 -> 1614, 195 -> 1614, 196 -> 2763, 197 -> 2763, 198 -> 1614, 199 -> 1614
    //   820: iload #5
    //   822: ifeq -> 2782
    //   825: goto -> 829
    //   828: athrow
    //   829: aload_0
    //   830: ldc 16777221
    //   832: invokespecial b : (I)V
    //   835: iload #5
    //   837: ifeq -> 2782
    //   840: goto -> 844
    //   843: athrow
    //   844: aload_0
    //   845: ldc 16777217
    //   847: invokespecial b : (I)V
    //   850: iload #5
    //   852: ifeq -> 2782
    //   855: goto -> 859
    //   858: athrow
    //   859: aload_0
    //   860: ldc 16777220
    //   862: invokespecial b : (I)V
    //   865: aload_0
    //   866: ldc 16777216
    //   868: invokespecial b : (I)V
    //   871: iload #5
    //   873: ifeq -> 2782
    //   876: goto -> 880
    //   879: athrow
    //   880: aload_0
    //   881: ldc 16777218
    //   883: invokespecial b : (I)V
    //   886: iload #5
    //   888: ifeq -> 2782
    //   891: goto -> 895
    //   894: athrow
    //   895: aload_0
    //   896: ldc 16777219
    //   898: invokespecial b : (I)V
    //   901: aload_0
    //   902: ldc 16777216
    //   904: invokespecial b : (I)V
    //   907: iload #5
    //   909: ifeq -> 2782
    //   912: goto -> 916
    //   915: athrow
    //   916: aload #4
    //   918: getfield b : I
    //   921: tableswitch default -> 1152, 3 -> 993, 4 -> 1029, 5 -> 1008, 6 -> 1044, 7 -> 1065, 8 -> 1094, 9 -> 1152, 10 -> 1152, 11 -> 1152, 12 -> 1152, 13 -> 1152, 14 -> 1152, 15 -> 1152, 16 -> 1123
    //   992: athrow
    //   993: aload_0
    //   994: ldc 16777217
    //   996: invokespecial b : (I)V
    //   999: iload #5
    //   1001: ifeq -> 2782
    //   1004: goto -> 1008
    //   1007: athrow
    //   1008: aload_0
    //   1009: ldc 16777220
    //   1011: invokespecial b : (I)V
    //   1014: aload_0
    //   1015: ldc 16777216
    //   1017: invokespecial b : (I)V
    //   1020: iload #5
    //   1022: ifeq -> 2782
    //   1025: goto -> 1029
    //   1028: athrow
    //   1029: aload_0
    //   1030: ldc 16777218
    //   1032: invokespecial b : (I)V
    //   1035: iload #5
    //   1037: ifeq -> 2782
    //   1040: goto -> 1044
    //   1043: athrow
    //   1044: aload_0
    //   1045: ldc 16777219
    //   1047: invokespecial b : (I)V
    //   1050: aload_0
    //   1051: ldc 16777216
    //   1053: invokespecial b : (I)V
    //   1056: iload #5
    //   1058: ifeq -> 2782
    //   1061: goto -> 1065
    //   1064: athrow
    //   1065: aload_0
    //   1066: ldc 24117248
    //   1068: aload_3
    //   1069: sipush #21724
    //   1072: sipush #22431
    //   1075: invokestatic b : (II)Ljava/lang/String;
    //   1078: invokevirtual c : (Ljava/lang/String;)I
    //   1081: ior
    //   1082: invokespecial b : (I)V
    //   1085: iload #5
    //   1087: ifeq -> 2782
    //   1090: goto -> 1094
    //   1093: athrow
    //   1094: aload_0
    //   1095: ldc 24117248
    //   1097: aload_3
    //   1098: sipush #21726
    //   1101: sipush #-19750
    //   1104: invokestatic b : (II)Ljava/lang/String;
    //   1107: invokevirtual c : (Ljava/lang/String;)I
    //   1110: ior
    //   1111: invokespecial b : (I)V
    //   1114: iload #5
    //   1116: ifeq -> 2782
    //   1119: goto -> 1123
    //   1122: athrow
    //   1123: aload_0
    //   1124: ldc 24117248
    //   1126: aload_3
    //   1127: sipush #21721
    //   1130: sipush #31913
    //   1133: invokestatic b : (II)Ljava/lang/String;
    //   1136: invokevirtual c : (Ljava/lang/String;)I
    //   1139: ior
    //   1140: invokespecial b : (I)V
    //   1143: iload #5
    //   1145: ifeq -> 2782
    //   1148: goto -> 1152
    //   1151: athrow
    //   1152: aload_0
    //   1153: ldc 24117248
    //   1155: aload_3
    //   1156: sipush #21725
    //   1159: sipush #-17184
    //   1162: invokestatic b : (II)Ljava/lang/String;
    //   1165: invokevirtual c : (Ljava/lang/String;)I
    //   1168: ior
    //   1169: invokespecial b : (I)V
    //   1172: iload #5
    //   1174: ifeq -> 2782
    //   1177: goto -> 1181
    //   1180: athrow
    //   1181: aload_0
    //   1182: aload_0
    //   1183: iload_2
    //   1184: invokespecial a : (I)I
    //   1187: invokespecial b : (I)V
    //   1190: iload #5
    //   1192: ifeq -> 2782
    //   1195: goto -> 1199
    //   1198: athrow
    //   1199: aload_0
    //   1200: iconst_2
    //   1201: invokespecial c : (I)V
    //   1204: aload_0
    //   1205: ldc 16777217
    //   1207: invokespecial b : (I)V
    //   1210: iload #5
    //   1212: ifeq -> 2782
    //   1215: goto -> 1219
    //   1218: athrow
    //   1219: aload_0
    //   1220: iconst_2
    //   1221: invokespecial c : (I)V
    //   1224: aload_0
    //   1225: ldc 16777220
    //   1227: invokespecial b : (I)V
    //   1230: aload_0
    //   1231: ldc 16777216
    //   1233: invokespecial b : (I)V
    //   1236: iload #5
    //   1238: ifeq -> 2782
    //   1241: goto -> 1245
    //   1244: athrow
    //   1245: aload_0
    //   1246: iconst_2
    //   1247: invokespecial c : (I)V
    //   1250: aload_0
    //   1251: ldc 16777218
    //   1253: invokespecial b : (I)V
    //   1256: iload #5
    //   1258: ifeq -> 2782
    //   1261: goto -> 1265
    //   1264: athrow
    //   1265: aload_0
    //   1266: iconst_2
    //   1267: invokespecial c : (I)V
    //   1270: aload_0
    //   1271: ldc 16777219
    //   1273: invokespecial b : (I)V
    //   1276: aload_0
    //   1277: ldc 16777216
    //   1279: invokespecial b : (I)V
    //   1282: iload #5
    //   1284: ifeq -> 2782
    //   1287: goto -> 1291
    //   1290: athrow
    //   1291: aload_0
    //   1292: iconst_1
    //   1293: invokespecial c : (I)V
    //   1296: aload_0
    //   1297: invokespecial a : ()I
    //   1300: istore #6
    //   1302: aload_0
    //   1303: ldc -268435456
    //   1305: iload #6
    //   1307: iadd
    //   1308: invokespecial b : (I)V
    //   1311: iload #5
    //   1313: ifeq -> 2782
    //   1316: aload_0
    //   1317: invokespecial a : ()I
    //   1320: istore #6
    //   1322: aload_0
    //   1323: iload_2
    //   1324: iload #6
    //   1326: invokespecial a : (II)V
    //   1329: iload_2
    //   1330: iload #5
    //   1332: ifne -> 1353
    //   1335: ifle -> 2782
    //   1338: goto -> 1342
    //   1341: athrow
    //   1342: aload_0
    //   1343: iload_2
    //   1344: iconst_1
    //   1345: isub
    //   1346: invokespecial a : (I)I
    //   1349: goto -> 1353
    //   1352: athrow
    //   1353: istore #7
    //   1355: iload #5
    //   1357: ifne -> 1404
    //   1360: iload #7
    //   1362: ldc 16777220
    //   1364: if_icmpeq -> 1391
    //   1367: goto -> 1371
    //   1370: athrow
    //   1371: iload #7
    //   1373: ldc 16777219
    //   1375: iload #5
    //   1377: ifne -> 1420
    //   1380: goto -> 1384
    //   1383: athrow
    //   1384: if_icmpne -> 1409
    //   1387: goto -> 1391
    //   1390: athrow
    //   1391: aload_0
    //   1392: iload_2
    //   1393: iconst_1
    //   1394: isub
    //   1395: ldc 16777216
    //   1397: invokespecial a : (II)V
    //   1400: goto -> 1404
    //   1403: athrow
    //   1404: iload #5
    //   1406: ifeq -> 2782
    //   1409: iload #7
    //   1411: ldc 251658240
    //   1413: iand
    //   1414: ldc 16777216
    //   1416: goto -> 1420
    //   1419: athrow
    //   1420: if_icmpeq -> 2782
    //   1423: aload_0
    //   1424: iload_2
    //   1425: iconst_1
    //   1426: isub
    //   1427: iload #7
    //   1429: ldc 8388608
    //   1431: ior
    //   1432: invokespecial a : (II)V
    //   1435: iload #5
    //   1437: ifeq -> 2782
    //   1440: goto -> 1444
    //   1443: athrow
    //   1444: aload_0
    //   1445: iconst_1
    //   1446: invokespecial c : (I)V
    //   1449: aload_0
    //   1450: invokespecial a : ()I
    //   1453: istore #6
    //   1455: aload_0
    //   1456: iload_2
    //   1457: iload #6
    //   1459: invokespecial a : (II)V
    //   1462: aload_0
    //   1463: iload_2
    //   1464: iconst_1
    //   1465: iadd
    //   1466: ldc 16777216
    //   1468: invokespecial a : (II)V
    //   1471: iload_2
    //   1472: iload #5
    //   1474: ifne -> 1495
    //   1477: ifle -> 2782
    //   1480: goto -> 1484
    //   1483: athrow
    //   1484: aload_0
    //   1485: iload_2
    //   1486: iconst_1
    //   1487: isub
    //   1488: invokespecial a : (I)I
    //   1491: goto -> 1495
    //   1494: athrow
    //   1495: istore #7
    //   1497: iload #5
    //   1499: ifne -> 1546
    //   1502: iload #7
    //   1504: ldc 16777220
    //   1506: if_icmpeq -> 1533
    //   1509: goto -> 1513
    //   1512: athrow
    //   1513: iload #7
    //   1515: ldc 16777219
    //   1517: iload #5
    //   1519: ifne -> 1562
    //   1522: goto -> 1526
    //   1525: athrow
    //   1526: if_icmpne -> 1551
    //   1529: goto -> 1533
    //   1532: athrow
    //   1533: aload_0
    //   1534: iload_2
    //   1535: iconst_1
    //   1536: isub
    //   1537: ldc 16777216
    //   1539: invokespecial a : (II)V
    //   1542: goto -> 1546
    //   1545: athrow
    //   1546: iload #5
    //   1548: ifeq -> 2782
    //   1551: iload #7
    //   1553: ldc 251658240
    //   1555: iand
    //   1556: ldc 16777216
    //   1558: goto -> 1562
    //   1561: athrow
    //   1562: if_icmpeq -> 2782
    //   1565: aload_0
    //   1566: iload_2
    //   1567: iconst_1
    //   1568: isub
    //   1569: iload #7
    //   1571: ldc 8388608
    //   1573: ior
    //   1574: invokespecial a : (II)V
    //   1577: iload #5
    //   1579: ifeq -> 2782
    //   1582: goto -> 1586
    //   1585: athrow
    //   1586: aload_0
    //   1587: iconst_3
    //   1588: invokespecial c : (I)V
    //   1591: iload #5
    //   1593: ifeq -> 2782
    //   1596: goto -> 1600
    //   1599: athrow
    //   1600: aload_0
    //   1601: iconst_4
    //   1602: invokespecial c : (I)V
    //   1605: iload #5
    //   1607: ifeq -> 2782
    //   1610: goto -> 1614
    //   1613: athrow
    //   1614: aload_0
    //   1615: iconst_1
    //   1616: invokespecial c : (I)V
    //   1619: iload #5
    //   1621: ifeq -> 2782
    //   1624: goto -> 1628
    //   1627: athrow
    //   1628: aload_0
    //   1629: iconst_2
    //   1630: invokespecial c : (I)V
    //   1633: iload #5
    //   1635: ifeq -> 2782
    //   1638: goto -> 1642
    //   1641: athrow
    //   1642: aload_0
    //   1643: invokespecial a : ()I
    //   1646: istore #6
    //   1648: aload_0
    //   1649: iload #6
    //   1651: invokespecial b : (I)V
    //   1654: aload_0
    //   1655: iload #6
    //   1657: invokespecial b : (I)V
    //   1660: iload #5
    //   1662: ifeq -> 2782
    //   1665: aload_0
    //   1666: invokespecial a : ()I
    //   1669: istore #6
    //   1671: aload_0
    //   1672: invokespecial a : ()I
    //   1675: istore #7
    //   1677: aload_0
    //   1678: iload #6
    //   1680: invokespecial b : (I)V
    //   1683: aload_0
    //   1684: iload #7
    //   1686: invokespecial b : (I)V
    //   1689: aload_0
    //   1690: iload #6
    //   1692: invokespecial b : (I)V
    //   1695: iload #5
    //   1697: ifeq -> 2782
    //   1700: aload_0
    //   1701: invokespecial a : ()I
    //   1704: istore #6
    //   1706: aload_0
    //   1707: invokespecial a : ()I
    //   1710: istore #7
    //   1712: aload_0
    //   1713: invokespecial a : ()I
    //   1716: istore #8
    //   1718: aload_0
    //   1719: iload #6
    //   1721: invokespecial b : (I)V
    //   1724: aload_0
    //   1725: iload #8
    //   1727: invokespecial b : (I)V
    //   1730: aload_0
    //   1731: iload #7
    //   1733: invokespecial b : (I)V
    //   1736: aload_0
    //   1737: iload #6
    //   1739: invokespecial b : (I)V
    //   1742: iload #5
    //   1744: ifeq -> 2782
    //   1747: aload_0
    //   1748: invokespecial a : ()I
    //   1751: istore #6
    //   1753: aload_0
    //   1754: invokespecial a : ()I
    //   1757: istore #7
    //   1759: aload_0
    //   1760: iload #7
    //   1762: invokespecial b : (I)V
    //   1765: aload_0
    //   1766: iload #6
    //   1768: invokespecial b : (I)V
    //   1771: aload_0
    //   1772: iload #7
    //   1774: invokespecial b : (I)V
    //   1777: aload_0
    //   1778: iload #6
    //   1780: invokespecial b : (I)V
    //   1783: iload #5
    //   1785: ifeq -> 2782
    //   1788: aload_0
    //   1789: invokespecial a : ()I
    //   1792: istore #6
    //   1794: aload_0
    //   1795: invokespecial a : ()I
    //   1798: istore #7
    //   1800: aload_0
    //   1801: invokespecial a : ()I
    //   1804: istore #8
    //   1806: aload_0
    //   1807: iload #7
    //   1809: invokespecial b : (I)V
    //   1812: aload_0
    //   1813: iload #6
    //   1815: invokespecial b : (I)V
    //   1818: aload_0
    //   1819: iload #8
    //   1821: invokespecial b : (I)V
    //   1824: aload_0
    //   1825: iload #7
    //   1827: invokespecial b : (I)V
    //   1830: aload_0
    //   1831: iload #6
    //   1833: invokespecial b : (I)V
    //   1836: iload #5
    //   1838: ifeq -> 2782
    //   1841: aload_0
    //   1842: invokespecial a : ()I
    //   1845: istore #6
    //   1847: aload_0
    //   1848: invokespecial a : ()I
    //   1851: istore #7
    //   1853: aload_0
    //   1854: invokespecial a : ()I
    //   1857: istore #8
    //   1859: aload_0
    //   1860: invokespecial a : ()I
    //   1863: istore #9
    //   1865: aload_0
    //   1866: iload #7
    //   1868: invokespecial b : (I)V
    //   1871: aload_0
    //   1872: iload #6
    //   1874: invokespecial b : (I)V
    //   1877: aload_0
    //   1878: iload #9
    //   1880: invokespecial b : (I)V
    //   1883: aload_0
    //   1884: iload #8
    //   1886: invokespecial b : (I)V
    //   1889: aload_0
    //   1890: iload #7
    //   1892: invokespecial b : (I)V
    //   1895: aload_0
    //   1896: iload #6
    //   1898: invokespecial b : (I)V
    //   1901: iload #5
    //   1903: ifeq -> 2782
    //   1906: aload_0
    //   1907: invokespecial a : ()I
    //   1910: istore #6
    //   1912: aload_0
    //   1913: invokespecial a : ()I
    //   1916: istore #7
    //   1918: aload_0
    //   1919: iload #6
    //   1921: invokespecial b : (I)V
    //   1924: aload_0
    //   1925: iload #7
    //   1927: invokespecial b : (I)V
    //   1930: iload #5
    //   1932: ifeq -> 2782
    //   1935: aload_0
    //   1936: iconst_2
    //   1937: invokespecial c : (I)V
    //   1940: aload_0
    //   1941: ldc 16777217
    //   1943: invokespecial b : (I)V
    //   1946: iload #5
    //   1948: ifeq -> 2782
    //   1951: goto -> 1955
    //   1954: athrow
    //   1955: aload_0
    //   1956: iconst_4
    //   1957: invokespecial c : (I)V
    //   1960: aload_0
    //   1961: ldc 16777220
    //   1963: invokespecial b : (I)V
    //   1966: aload_0
    //   1967: ldc 16777216
    //   1969: invokespecial b : (I)V
    //   1972: iload #5
    //   1974: ifeq -> 2782
    //   1977: goto -> 1981
    //   1980: athrow
    //   1981: aload_0
    //   1982: iconst_2
    //   1983: invokespecial c : (I)V
    //   1986: aload_0
    //   1987: ldc 16777218
    //   1989: invokespecial b : (I)V
    //   1992: iload #5
    //   1994: ifeq -> 2782
    //   1997: goto -> 2001
    //   2000: athrow
    //   2001: aload_0
    //   2002: iconst_4
    //   2003: invokespecial c : (I)V
    //   2006: aload_0
    //   2007: ldc 16777219
    //   2009: invokespecial b : (I)V
    //   2012: aload_0
    //   2013: ldc 16777216
    //   2015: invokespecial b : (I)V
    //   2018: iload #5
    //   2020: ifeq -> 2782
    //   2023: goto -> 2027
    //   2026: athrow
    //   2027: aload_0
    //   2028: iconst_3
    //   2029: invokespecial c : (I)V
    //   2032: aload_0
    //   2033: ldc 16777220
    //   2035: invokespecial b : (I)V
    //   2038: aload_0
    //   2039: ldc 16777216
    //   2041: invokespecial b : (I)V
    //   2044: iload #5
    //   2046: ifeq -> 2782
    //   2049: goto -> 2053
    //   2052: athrow
    //   2053: aload_0
    //   2054: iload_2
    //   2055: ldc 16777217
    //   2057: invokespecial a : (II)V
    //   2060: iload #5
    //   2062: ifeq -> 2782
    //   2065: goto -> 2069
    //   2068: athrow
    //   2069: aload_0
    //   2070: iconst_1
    //   2071: invokespecial c : (I)V
    //   2074: aload_0
    //   2075: ldc 16777220
    //   2077: invokespecial b : (I)V
    //   2080: aload_0
    //   2081: ldc 16777216
    //   2083: invokespecial b : (I)V
    //   2086: iload #5
    //   2088: ifeq -> 2782
    //   2091: goto -> 2095
    //   2094: athrow
    //   2095: aload_0
    //   2096: iconst_1
    //   2097: invokespecial c : (I)V
    //   2100: aload_0
    //   2101: ldc 16777218
    //   2103: invokespecial b : (I)V
    //   2106: iload #5
    //   2108: ifeq -> 2782
    //   2111: goto -> 2115
    //   2114: athrow
    //   2115: aload_0
    //   2116: iconst_1
    //   2117: invokespecial c : (I)V
    //   2120: aload_0
    //   2121: ldc 16777219
    //   2123: invokespecial b : (I)V
    //   2126: aload_0
    //   2127: ldc 16777216
    //   2129: invokespecial b : (I)V
    //   2132: iload #5
    //   2134: ifeq -> 2782
    //   2137: goto -> 2141
    //   2140: athrow
    //   2141: aload_0
    //   2142: iconst_1
    //   2143: invokespecial c : (I)V
    //   2146: aload_0
    //   2147: ldc 16777217
    //   2149: invokespecial b : (I)V
    //   2152: iload #5
    //   2154: ifeq -> 2782
    //   2157: goto -> 2161
    //   2160: athrow
    //   2161: aload_0
    //   2162: iconst_4
    //   2163: invokespecial c : (I)V
    //   2166: aload_0
    //   2167: ldc 16777217
    //   2169: invokespecial b : (I)V
    //   2172: iload #5
    //   2174: ifeq -> 2782
    //   2177: goto -> 2181
    //   2180: athrow
    //   2181: new java/lang/RuntimeException
    //   2184: dup
    //   2185: sipush #21727
    //   2188: sipush #22240
    //   2191: invokestatic b : (II)Ljava/lang/String;
    //   2194: invokespecial <init> : (Ljava/lang/String;)V
    //   2197: athrow
    //   2198: athrow
    //   2199: aload_0
    //   2200: aload_3
    //   2201: aload #4
    //   2203: getfield i : Ljava/lang/String;
    //   2206: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2209: iload #5
    //   2211: ifeq -> 2782
    //   2214: aload_0
    //   2215: aload #4
    //   2217: getfield i : Ljava/lang/String;
    //   2220: invokespecial a : (Ljava/lang/String;)V
    //   2223: iload #5
    //   2225: ifeq -> 2782
    //   2228: goto -> 2232
    //   2231: athrow
    //   2232: aload_0
    //   2233: iconst_1
    //   2234: invokespecial c : (I)V
    //   2237: aload_0
    //   2238: aload_3
    //   2239: aload #4
    //   2241: getfield i : Ljava/lang/String;
    //   2244: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2247: iload #5
    //   2249: ifeq -> 2782
    //   2252: goto -> 2256
    //   2255: athrow
    //   2256: aload_0
    //   2257: aload #4
    //   2259: getfield i : Ljava/lang/String;
    //   2262: invokespecial a : (Ljava/lang/String;)V
    //   2265: aload_0
    //   2266: invokespecial a : ()I
    //   2269: pop
    //   2270: iload #5
    //   2272: ifeq -> 2782
    //   2275: goto -> 2279
    //   2278: athrow
    //   2279: aload_0
    //   2280: aload #4
    //   2282: getfield i : Ljava/lang/String;
    //   2285: invokespecial a : (Ljava/lang/String;)V
    //   2288: iload #5
    //   2290: ifne -> 2368
    //   2293: goto -> 2297
    //   2296: athrow
    //   2297: iload_1
    //   2298: sipush #184
    //   2301: if_icmpeq -> 2358
    //   2304: goto -> 2308
    //   2307: athrow
    //   2308: aload_0
    //   2309: invokespecial a : ()I
    //   2312: istore #6
    //   2314: iload #5
    //   2316: ifne -> 2368
    //   2319: iload_1
    //   2320: sipush #183
    //   2323: if_icmpne -> 2358
    //   2326: goto -> 2330
    //   2329: athrow
    //   2330: aload #4
    //   2332: getfield h : Ljava/lang/String;
    //   2335: iconst_0
    //   2336: invokevirtual charAt : (I)C
    //   2339: bipush #60
    //   2341: if_icmpne -> 2358
    //   2344: goto -> 2348
    //   2347: athrow
    //   2348: aload_0
    //   2349: iload #6
    //   2351: invokespecial d : (I)V
    //   2354: goto -> 2358
    //   2357: athrow
    //   2358: aload_0
    //   2359: aload_3
    //   2360: aload #4
    //   2362: getfield i : Ljava/lang/String;
    //   2365: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2368: iload #5
    //   2370: ifeq -> 2782
    //   2373: aload_0
    //   2374: aload #4
    //   2376: getfield h : Ljava/lang/String;
    //   2379: invokespecial a : (Ljava/lang/String;)V
    //   2382: aload_0
    //   2383: aload_3
    //   2384: aload #4
    //   2386: getfield h : Ljava/lang/String;
    //   2389: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2392: iload #5
    //   2394: ifeq -> 2782
    //   2397: goto -> 2401
    //   2400: athrow
    //   2401: aload_0
    //   2402: ldc 25165824
    //   2404: aload_3
    //   2405: aload #4
    //   2407: getfield g : Ljava/lang/String;
    //   2410: iload_2
    //   2411: invokevirtual a : (Ljava/lang/String;I)I
    //   2414: ior
    //   2415: invokespecial b : (I)V
    //   2418: iload #5
    //   2420: ifeq -> 2782
    //   2423: goto -> 2427
    //   2426: athrow
    //   2427: aload_0
    //   2428: invokespecial a : ()I
    //   2431: pop
    //   2432: iload #5
    //   2434: ifne -> 2600
    //   2437: goto -> 2441
    //   2440: athrow
    //   2441: iload_2
    //   2442: tableswitch default -> 2590, 4 -> 2485, 5 -> 2500, 6 -> 2560, 7 -> 2575, 8 -> 2515, 9 -> 2530, 10 -> 2545
    //   2484: athrow
    //   2485: aload_0
    //   2486: ldc 285212681
    //   2488: invokespecial b : (I)V
    //   2491: iload #5
    //   2493: ifeq -> 2782
    //   2496: goto -> 2500
    //   2499: athrow
    //   2500: aload_0
    //   2501: ldc 285212683
    //   2503: invokespecial b : (I)V
    //   2506: iload #5
    //   2508: ifeq -> 2782
    //   2511: goto -> 2515
    //   2514: athrow
    //   2515: aload_0
    //   2516: ldc 285212682
    //   2518: invokespecial b : (I)V
    //   2521: iload #5
    //   2523: ifeq -> 2782
    //   2526: goto -> 2530
    //   2529: athrow
    //   2530: aload_0
    //   2531: ldc 285212684
    //   2533: invokespecial b : (I)V
    //   2536: iload #5
    //   2538: ifeq -> 2782
    //   2541: goto -> 2545
    //   2544: athrow
    //   2545: aload_0
    //   2546: ldc 285212673
    //   2548: invokespecial b : (I)V
    //   2551: iload #5
    //   2553: ifeq -> 2782
    //   2556: goto -> 2560
    //   2559: athrow
    //   2560: aload_0
    //   2561: ldc 285212674
    //   2563: invokespecial b : (I)V
    //   2566: iload #5
    //   2568: ifeq -> 2782
    //   2571: goto -> 2575
    //   2574: athrow
    //   2575: aload_0
    //   2576: ldc 285212675
    //   2578: invokespecial b : (I)V
    //   2581: iload #5
    //   2583: ifeq -> 2782
    //   2586: goto -> 2590
    //   2589: athrow
    //   2590: aload_0
    //   2591: ldc 285212676
    //   2593: invokespecial b : (I)V
    //   2596: goto -> 2600
    //   2599: athrow
    //   2600: iload #5
    //   2602: ifeq -> 2782
    //   2605: aload #4
    //   2607: getfield g : Ljava/lang/String;
    //   2610: astore #10
    //   2612: aload_0
    //   2613: invokespecial a : ()I
    //   2616: pop
    //   2617: iload #5
    //   2619: ifne -> 2688
    //   2622: aload #10
    //   2624: iconst_0
    //   2625: invokevirtual charAt : (I)C
    //   2628: bipush #91
    //   2630: if_icmpne -> 2671
    //   2633: goto -> 2637
    //   2636: athrow
    //   2637: aload_0
    //   2638: aload_3
    //   2639: new java/lang/StringBuffer
    //   2642: dup
    //   2643: invokespecial <init> : ()V
    //   2646: bipush #91
    //   2648: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   2651: aload #10
    //   2653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   2656: invokevirtual toString : ()Ljava/lang/String;
    //   2659: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2662: iload #5
    //   2664: ifeq -> 2782
    //   2667: goto -> 2671
    //   2670: athrow
    //   2671: aload_0
    //   2672: ldc 292552704
    //   2674: aload_3
    //   2675: aload #10
    //   2677: invokevirtual c : (Ljava/lang/String;)I
    //   2680: ior
    //   2681: invokespecial b : (I)V
    //   2684: goto -> 2688
    //   2687: athrow
    //   2688: iload #5
    //   2690: ifeq -> 2782
    //   2693: aload #4
    //   2695: getfield g : Ljava/lang/String;
    //   2698: astore #10
    //   2700: aload_0
    //   2701: invokespecial a : ()I
    //   2704: pop
    //   2705: iload #5
    //   2707: ifne -> 2758
    //   2710: aload #10
    //   2712: iconst_0
    //   2713: invokevirtual charAt : (I)C
    //   2716: bipush #91
    //   2718: if_icmpne -> 2741
    //   2721: goto -> 2725
    //   2724: athrow
    //   2725: aload_0
    //   2726: aload_3
    //   2727: aload #10
    //   2729: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2732: iload #5
    //   2734: ifeq -> 2782
    //   2737: goto -> 2741
    //   2740: athrow
    //   2741: aload_0
    //   2742: ldc 24117248
    //   2744: aload_3
    //   2745: aload #10
    //   2747: invokevirtual c : (Ljava/lang/String;)I
    //   2750: ior
    //   2751: invokespecial b : (I)V
    //   2754: goto -> 2758
    //   2757: athrow
    //   2758: iload #5
    //   2760: ifeq -> 2782
    //   2763: aload_0
    //   2764: iload_2
    //   2765: invokespecial c : (I)V
    //   2768: aload_0
    //   2769: aload_3
    //   2770: aload #4
    //   2772: getfield g : Ljava/lang/String;
    //   2775: invokespecial a : (Lorg/objectweb/asm/ClassWriter;Ljava/lang/String;)V
    //   2778: goto -> 2782
    //   2781: athrow
    //   2782: return
    // Exception table:
    //   from	to	target	type
    //   5	825	828	java/lang/RuntimeException
    //   820	840	843	java/lang/RuntimeException
    //   829	855	858	java/lang/RuntimeException
    //   844	876	879	java/lang/RuntimeException
    //   859	891	894	java/lang/RuntimeException
    //   880	912	915	java/lang/RuntimeException
    //   895	992	992	java/lang/RuntimeException
    //   916	1004	1007	java/lang/RuntimeException
    //   993	1025	1028	java/lang/RuntimeException
    //   1008	1040	1043	java/lang/RuntimeException
    //   1029	1061	1064	java/lang/RuntimeException
    //   1044	1090	1093	java/lang/RuntimeException
    //   1065	1119	1122	java/lang/RuntimeException
    //   1094	1148	1151	java/lang/RuntimeException
    //   1123	1177	1180	java/lang/RuntimeException
    //   1152	1195	1198	java/lang/RuntimeException
    //   1181	1215	1218	java/lang/RuntimeException
    //   1199	1241	1244	java/lang/RuntimeException
    //   1219	1261	1264	java/lang/RuntimeException
    //   1245	1287	1290	java/lang/RuntimeException
    //   1322	1338	1341	java/lang/RuntimeException
    //   1335	1349	1352	java/lang/RuntimeException
    //   1355	1367	1370	java/lang/RuntimeException
    //   1360	1380	1383	java/lang/RuntimeException
    //   1371	1387	1390	java/lang/RuntimeException
    //   1384	1400	1403	java/lang/RuntimeException
    //   1404	1416	1419	java/lang/RuntimeException
    //   1420	1440	1443	java/lang/RuntimeException
    //   1455	1480	1483	java/lang/RuntimeException
    //   1477	1491	1494	java/lang/RuntimeException
    //   1497	1509	1512	java/lang/RuntimeException
    //   1502	1522	1525	java/lang/RuntimeException
    //   1513	1529	1532	java/lang/RuntimeException
    //   1526	1542	1545	java/lang/RuntimeException
    //   1546	1558	1561	java/lang/RuntimeException
    //   1562	1582	1585	java/lang/RuntimeException
    //   1565	1596	1599	java/lang/RuntimeException
    //   1586	1610	1613	java/lang/RuntimeException
    //   1600	1624	1627	java/lang/RuntimeException
    //   1614	1638	1641	java/lang/RuntimeException
    //   1918	1951	1954	java/lang/RuntimeException
    //   1935	1977	1980	java/lang/RuntimeException
    //   1955	1997	2000	java/lang/RuntimeException
    //   1981	2023	2026	java/lang/RuntimeException
    //   2001	2049	2052	java/lang/RuntimeException
    //   2027	2065	2068	java/lang/RuntimeException
    //   2053	2091	2094	java/lang/RuntimeException
    //   2069	2111	2114	java/lang/RuntimeException
    //   2095	2137	2140	java/lang/RuntimeException
    //   2115	2157	2160	java/lang/RuntimeException
    //   2141	2177	2180	java/lang/RuntimeException
    //   2161	2198	2198	java/lang/RuntimeException
    //   2199	2228	2231	java/lang/RuntimeException
    //   2214	2252	2255	java/lang/RuntimeException
    //   2232	2275	2278	java/lang/RuntimeException
    //   2256	2293	2296	java/lang/RuntimeException
    //   2279	2304	2307	java/lang/RuntimeException
    //   2314	2326	2329	java/lang/RuntimeException
    //   2319	2344	2347	java/lang/RuntimeException
    //   2330	2354	2357	java/lang/RuntimeException
    //   2368	2397	2400	java/lang/RuntimeException
    //   2373	2423	2426	java/lang/RuntimeException
    //   2401	2437	2440	java/lang/RuntimeException
    //   2427	2484	2484	java/lang/RuntimeException
    //   2441	2496	2499	java/lang/RuntimeException
    //   2485	2511	2514	java/lang/RuntimeException
    //   2500	2526	2529	java/lang/RuntimeException
    //   2515	2541	2544	java/lang/RuntimeException
    //   2530	2556	2559	java/lang/RuntimeException
    //   2545	2571	2574	java/lang/RuntimeException
    //   2560	2586	2589	java/lang/RuntimeException
    //   2575	2596	2599	java/lang/RuntimeException
    //   2612	2633	2636	java/lang/RuntimeException
    //   2622	2667	2670	java/lang/RuntimeException
    //   2637	2684	2687	java/lang/RuntimeException
    //   2700	2721	2724	java/lang/RuntimeException
    //   2710	2737	2740	java/lang/RuntimeException
    //   2725	2754	2757	java/lang/RuntimeException
    //   2758	2778	2781	java/lang/RuntimeException
  }
  
  final boolean a(ClassWriter paramClassWriter, Frame paramFrame, int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: aload_0
    //   7: getfield c : [I
    //   10: arraylength
    //   11: istore #11
    //   13: istore #4
    //   15: aload_0
    //   16: getfield d : [I
    //   19: arraylength
    //   20: istore #12
    //   22: aload_2
    //   23: iload #4
    //   25: ifne -> 43
    //   28: getfield c : [I
    //   31: ifnonnull -> 53
    //   34: goto -> 38
    //   37: athrow
    //   38: aload_2
    //   39: goto -> 43
    //   42: athrow
    //   43: iload #11
    //   45: newarray int
    //   47: putfield c : [I
    //   50: iconst_1
    //   51: istore #5
    //   53: iconst_0
    //   54: istore #6
    //   56: iload #6
    //   58: iload #11
    //   60: if_icmpge -> 386
    //   63: aload_0
    //   64: getfield e : [I
    //   67: iload #4
    //   69: ifne -> 504
    //   72: iload #4
    //   74: ifne -> 327
    //   77: goto -> 81
    //   80: athrow
    //   81: ifnull -> 319
    //   84: goto -> 88
    //   87: athrow
    //   88: iload #6
    //   90: iload #4
    //   92: ifne -> 330
    //   95: goto -> 99
    //   98: athrow
    //   99: aload_0
    //   100: getfield e : [I
    //   103: arraylength
    //   104: if_icmpge -> 319
    //   107: goto -> 111
    //   110: athrow
    //   111: aload_0
    //   112: getfield e : [I
    //   115: iload #6
    //   117: iaload
    //   118: istore #7
    //   120: iload #7
    //   122: iload #4
    //   124: ifne -> 157
    //   127: ifne -> 148
    //   130: goto -> 134
    //   133: athrow
    //   134: aload_0
    //   135: getfield c : [I
    //   138: iload #6
    //   140: iaload
    //   141: istore #10
    //   143: iload #4
    //   145: ifeq -> 332
    //   148: iload #7
    //   150: ldc -268435456
    //   152: iand
    //   153: goto -> 157
    //   156: athrow
    //   157: istore #8
    //   159: iload #7
    //   161: ldc 251658240
    //   163: iand
    //   164: istore #9
    //   166: iload #9
    //   168: ldc 16777216
    //   170: iload #4
    //   172: ifne -> 199
    //   175: if_icmpne -> 191
    //   178: goto -> 182
    //   181: athrow
    //   182: iload #7
    //   184: istore #10
    //   186: iload #4
    //   188: ifeq -> 332
    //   191: iload #9
    //   193: ldc 33554432
    //   195: goto -> 199
    //   198: athrow
    //   199: iload #4
    //   201: ifne -> 250
    //   204: if_icmpne -> 231
    //   207: goto -> 211
    //   210: athrow
    //   211: iload #8
    //   213: aload_0
    //   214: getfield c : [I
    //   217: iload #7
    //   219: ldc 8388607
    //   221: iand
    //   222: iaload
    //   223: iadd
    //   224: istore #10
    //   226: iload #4
    //   228: ifeq -> 253
    //   231: iload #8
    //   233: aload_0
    //   234: getfield d : [I
    //   237: iload #12
    //   239: iload #7
    //   241: ldc 8388607
    //   243: iand
    //   244: isub
    //   245: iaload
    //   246: goto -> 250
    //   249: athrow
    //   250: iadd
    //   251: istore #10
    //   253: iload #7
    //   255: ldc 8388608
    //   257: iand
    //   258: iload #4
    //   260: ifne -> 272
    //   263: ifeq -> 332
    //   266: goto -> 270
    //   269: athrow
    //   270: iload #10
    //   272: iload #4
    //   274: ifne -> 312
    //   277: ldc 16777220
    //   279: if_icmpeq -> 306
    //   282: goto -> 286
    //   285: athrow
    //   286: iload #10
    //   288: iload #4
    //   290: ifne -> 312
    //   293: goto -> 297
    //   296: athrow
    //   297: ldc 16777219
    //   299: if_icmpne -> 332
    //   302: goto -> 306
    //   305: athrow
    //   306: ldc 16777216
    //   308: goto -> 312
    //   311: athrow
    //   312: istore #10
    //   314: iload #4
    //   316: ifeq -> 332
    //   319: aload_0
    //   320: getfield c : [I
    //   323: goto -> 327
    //   326: athrow
    //   327: iload #6
    //   329: iaload
    //   330: istore #10
    //   332: aload_0
    //   333: iload #4
    //   335: ifne -> 353
    //   338: getfield i : [I
    //   341: ifnull -> 361
    //   344: goto -> 348
    //   347: athrow
    //   348: aload_0
    //   349: goto -> 353
    //   352: athrow
    //   353: aload_1
    //   354: iload #10
    //   356: invokespecial a : (Lorg/objectweb/asm/ClassWriter;I)I
    //   359: istore #10
    //   361: iload #5
    //   363: aload_1
    //   364: iload #10
    //   366: aload_2
    //   367: getfield c : [I
    //   370: iload #6
    //   372: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[II)Z
    //   375: ior
    //   376: istore #5
    //   378: iinc #6, 1
    //   381: iload #4
    //   383: ifeq -> 56
    //   386: iload_3
    //   387: iload #4
    //   389: ifne -> 513
    //   392: ifle -> 500
    //   395: goto -> 399
    //   398: athrow
    //   399: iconst_0
    //   400: istore #6
    //   402: iload #6
    //   404: iload #11
    //   406: if_icmpge -> 452
    //   409: aload_0
    //   410: getfield c : [I
    //   413: iload #6
    //   415: iaload
    //   416: istore #10
    //   418: iload #5
    //   420: aload_1
    //   421: iload #10
    //   423: aload_2
    //   424: getfield c : [I
    //   427: iload #6
    //   429: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[II)Z
    //   432: ior
    //   433: istore #5
    //   435: iinc #6, 1
    //   438: iload #4
    //   440: ifne -> 497
    //   443: iload #4
    //   445: ifeq -> 402
    //   448: goto -> 452
    //   451: athrow
    //   452: aload_2
    //   453: iload #4
    //   455: ifne -> 473
    //   458: getfield d : [I
    //   461: ifnonnull -> 482
    //   464: goto -> 468
    //   467: athrow
    //   468: aload_2
    //   469: goto -> 473
    //   472: athrow
    //   473: iconst_1
    //   474: newarray int
    //   476: putfield d : [I
    //   479: iconst_1
    //   480: istore #5
    //   482: iload #5
    //   484: aload_1
    //   485: iload_3
    //   486: aload_2
    //   487: getfield d : [I
    //   490: iconst_0
    //   491: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[II)Z
    //   494: ior
    //   495: istore #5
    //   497: iload #5
    //   499: ireturn
    //   500: aload_0
    //   501: getfield d : [I
    //   504: arraylength
    //   505: aload_0
    //   506: getfield b : Lorg/objectweb/asm/Label;
    //   509: getfield f : I
    //   512: iadd
    //   513: istore #13
    //   515: aload_2
    //   516: iload #4
    //   518: ifne -> 536
    //   521: getfield d : [I
    //   524: ifnonnull -> 551
    //   527: goto -> 531
    //   530: athrow
    //   531: aload_2
    //   532: goto -> 536
    //   535: athrow
    //   536: iload #13
    //   538: aload_0
    //   539: getfield g : I
    //   542: iadd
    //   543: newarray int
    //   545: putfield d : [I
    //   548: iconst_1
    //   549: istore #5
    //   551: iconst_0
    //   552: istore #6
    //   554: iload #6
    //   556: iload #13
    //   558: if_icmpge -> 629
    //   561: aload_0
    //   562: getfield d : [I
    //   565: iload #6
    //   567: iaload
    //   568: istore #10
    //   570: iload #4
    //   572: ifne -> 624
    //   575: aload_0
    //   576: getfield i : [I
    //   579: iload #4
    //   581: ifne -> 645
    //   584: goto -> 588
    //   587: athrow
    //   588: ifnull -> 604
    //   591: goto -> 595
    //   594: athrow
    //   595: aload_0
    //   596: aload_1
    //   597: iload #10
    //   599: invokespecial a : (Lorg/objectweb/asm/ClassWriter;I)I
    //   602: istore #10
    //   604: iload #5
    //   606: aload_1
    //   607: iload #10
    //   609: aload_2
    //   610: getfield d : [I
    //   613: iload #6
    //   615: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[II)Z
    //   618: ior
    //   619: istore #5
    //   621: iinc #6, 1
    //   624: iload #4
    //   626: ifeq -> 554
    //   629: iconst_0
    //   630: istore #6
    //   632: iload #6
    //   634: aload_0
    //   635: getfield g : I
    //   638: if_icmpge -> 878
    //   641: aload_0
    //   642: getfield f : [I
    //   645: iload #6
    //   647: iaload
    //   648: istore #7
    //   650: iload #7
    //   652: ldc -268435456
    //   654: iand
    //   655: istore #8
    //   657: iload #7
    //   659: ldc 251658240
    //   661: iand
    //   662: istore #9
    //   664: iload #9
    //   666: iload #4
    //   668: ifne -> 880
    //   671: ldc 16777216
    //   673: iload #4
    //   675: ifne -> 706
    //   678: goto -> 682
    //   681: athrow
    //   682: if_icmpne -> 698
    //   685: goto -> 689
    //   688: athrow
    //   689: iload #7
    //   691: istore #10
    //   693: iload #4
    //   695: ifeq -> 821
    //   698: iload #9
    //   700: ldc 33554432
    //   702: goto -> 706
    //   705: athrow
    //   706: iload #4
    //   708: ifne -> 757
    //   711: if_icmpne -> 738
    //   714: goto -> 718
    //   717: athrow
    //   718: iload #8
    //   720: aload_0
    //   721: getfield c : [I
    //   724: iload #7
    //   726: ldc 8388607
    //   728: iand
    //   729: iaload
    //   730: iadd
    //   731: istore #10
    //   733: iload #4
    //   735: ifeq -> 760
    //   738: iload #8
    //   740: aload_0
    //   741: getfield d : [I
    //   744: iload #12
    //   746: iload #7
    //   748: ldc 8388607
    //   750: iand
    //   751: isub
    //   752: iaload
    //   753: goto -> 757
    //   756: athrow
    //   757: iadd
    //   758: istore #10
    //   760: iload #7
    //   762: ldc 8388608
    //   764: iand
    //   765: iload #4
    //   767: ifne -> 779
    //   770: ifeq -> 821
    //   773: goto -> 777
    //   776: athrow
    //   777: iload #10
    //   779: iload #4
    //   781: ifne -> 819
    //   784: ldc 16777220
    //   786: if_icmpeq -> 813
    //   789: goto -> 793
    //   792: athrow
    //   793: iload #10
    //   795: iload #4
    //   797: ifne -> 819
    //   800: goto -> 804
    //   803: athrow
    //   804: ldc 16777219
    //   806: if_icmpne -> 821
    //   809: goto -> 813
    //   812: athrow
    //   813: ldc 16777216
    //   815: goto -> 819
    //   818: athrow
    //   819: istore #10
    //   821: aload_0
    //   822: iload #4
    //   824: ifne -> 842
    //   827: getfield i : [I
    //   830: ifnull -> 850
    //   833: goto -> 837
    //   836: athrow
    //   837: aload_0
    //   838: goto -> 842
    //   841: athrow
    //   842: aload_1
    //   843: iload #10
    //   845: invokespecial a : (Lorg/objectweb/asm/ClassWriter;I)I
    //   848: istore #10
    //   850: iload #5
    //   852: aload_1
    //   853: iload #10
    //   855: aload_2
    //   856: getfield d : [I
    //   859: iload #13
    //   861: iload #6
    //   863: iadd
    //   864: invokestatic a : (Lorg/objectweb/asm/ClassWriter;I[II)Z
    //   867: ior
    //   868: istore #5
    //   870: iinc #6, 1
    //   873: iload #4
    //   875: ifeq -> 632
    //   878: iload #5
    //   880: ireturn
    // Exception table:
    //   from	to	target	type
    //   22	34	37	java/lang/RuntimeException
    //   28	39	42	java/lang/RuntimeException
    //   63	77	80	java/lang/RuntimeException
    //   72	84	87	java/lang/RuntimeException
    //   81	95	98	java/lang/RuntimeException
    //   88	107	110	java/lang/RuntimeException
    //   120	130	133	java/lang/RuntimeException
    //   143	153	156	java/lang/RuntimeException
    //   166	178	181	java/lang/RuntimeException
    //   186	195	198	java/lang/RuntimeException
    //   199	207	210	java/lang/RuntimeException
    //   226	246	249	java/lang/RuntimeException
    //   253	266	269	java/lang/RuntimeException
    //   272	282	285	java/lang/RuntimeException
    //   277	293	296	java/lang/RuntimeException
    //   286	302	305	java/lang/RuntimeException
    //   297	308	311	java/lang/RuntimeException
    //   314	323	326	java/lang/RuntimeException
    //   332	344	347	java/lang/RuntimeException
    //   338	349	352	java/lang/RuntimeException
    //   386	395	398	java/lang/RuntimeException
    //   435	448	451	java/lang/RuntimeException
    //   452	464	467	java/lang/RuntimeException
    //   458	469	472	java/lang/RuntimeException
    //   515	527	530	java/lang/RuntimeException
    //   521	532	535	java/lang/RuntimeException
    //   570	584	587	java/lang/RuntimeException
    //   575	591	594	java/lang/RuntimeException
    //   664	678	681	java/lang/RuntimeException
    //   671	685	688	java/lang/RuntimeException
    //   693	702	705	java/lang/RuntimeException
    //   706	714	717	java/lang/RuntimeException
    //   733	753	756	java/lang/RuntimeException
    //   760	773	776	java/lang/RuntimeException
    //   779	789	792	java/lang/RuntimeException
    //   784	800	803	java/lang/RuntimeException
    //   793	809	812	java/lang/RuntimeException
    //   804	815	818	java/lang/RuntimeException
    //   821	833	836	java/lang/RuntimeException
    //   827	838	841	java/lang/RuntimeException
  }
  
  private static boolean a(ClassWriter paramClassWriter, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #4
    //   5: aload_2
    //   6: iload_3
    //   7: iaload
    //   8: istore #5
    //   10: iload #5
    //   12: iload_1
    //   13: iload #4
    //   15: ifne -> 43
    //   18: if_icmpne -> 28
    //   21: goto -> 25
    //   24: athrow
    //   25: iconst_0
    //   26: ireturn
    //   27: athrow
    //   28: iload_1
    //   29: ldc 268435455
    //   31: iand
    //   32: iload #4
    //   34: ifne -> 74
    //   37: ldc 16777221
    //   39: goto -> 43
    //   42: athrow
    //   43: if_icmpne -> 72
    //   46: iload #5
    //   48: iload #4
    //   50: ifne -> 71
    //   53: goto -> 57
    //   56: athrow
    //   57: ldc 16777221
    //   59: if_icmpne -> 69
    //   62: goto -> 66
    //   65: athrow
    //   66: iconst_0
    //   67: ireturn
    //   68: athrow
    //   69: ldc 16777221
    //   71: istore_1
    //   72: iload #5
    //   74: iload #4
    //   76: ifne -> 98
    //   79: ifne -> 93
    //   82: goto -> 86
    //   85: athrow
    //   86: aload_2
    //   87: iload_3
    //   88: iload_1
    //   89: iastore
    //   90: iconst_1
    //   91: ireturn
    //   92: athrow
    //   93: iload #5
    //   95: ldc 267386880
    //   97: iand
    //   98: ldc 24117248
    //   100: iload #4
    //   102: ifne -> 140
    //   105: if_icmpeq -> 133
    //   108: goto -> 112
    //   111: athrow
    //   112: iload #5
    //   114: ldc -268435456
    //   116: iand
    //   117: iload #4
    //   119: ifne -> 476
    //   122: goto -> 126
    //   125: athrow
    //   126: ifeq -> 470
    //   129: goto -> 133
    //   132: athrow
    //   133: iload_1
    //   134: ldc 16777221
    //   136: goto -> 140
    //   139: athrow
    //   140: iload #4
    //   142: ifne -> 164
    //   145: if_icmpne -> 155
    //   148: goto -> 152
    //   151: athrow
    //   152: iconst_0
    //   153: ireturn
    //   154: athrow
    //   155: iload_1
    //   156: ldc -1048576
    //   158: iand
    //   159: iload #5
    //   161: ldc -1048576
    //   163: iand
    //   164: iload #4
    //   166: ifne -> 277
    //   169: if_icmpne -> 267
    //   172: goto -> 176
    //   175: athrow
    //   176: iload #5
    //   178: ldc 267386880
    //   180: iand
    //   181: ldc 24117248
    //   183: iload #4
    //   185: ifne -> 238
    //   188: goto -> 192
    //   191: athrow
    //   192: if_icmpne -> 227
    //   195: goto -> 199
    //   198: athrow
    //   199: iload_1
    //   200: ldc -268435456
    //   202: iand
    //   203: ldc 24117248
    //   205: ior
    //   206: aload_0
    //   207: iload_1
    //   208: ldc 1048575
    //   210: iand
    //   211: iload #5
    //   213: ldc 1048575
    //   215: iand
    //   216: invokevirtual a : (II)I
    //   219: ior
    //   220: istore #6
    //   222: iload #4
    //   224: ifeq -> 553
    //   227: ldc -268435456
    //   229: iload #5
    //   231: ldc -268435456
    //   233: iand
    //   234: goto -> 238
    //   237: athrow
    //   238: iadd
    //   239: istore #7
    //   241: iload #7
    //   243: ldc 24117248
    //   245: ior
    //   246: aload_0
    //   247: sipush #21720
    //   250: sipush #5708
    //   253: invokestatic b : (II)Ljava/lang/String;
    //   256: invokevirtual c : (Ljava/lang/String;)I
    //   259: ior
    //   260: istore #6
    //   262: iload #4
    //   264: ifeq -> 553
    //   267: iload_1
    //   268: ldc 267386880
    //   270: iand
    //   271: ldc 24117248
    //   273: goto -> 277
    //   276: athrow
    //   277: iload #4
    //   279: ifne -> 316
    //   282: if_icmpeq -> 309
    //   285: goto -> 289
    //   288: athrow
    //   289: iload_1
    //   290: ldc -268435456
    //   292: iand
    //   293: iload #4
    //   295: ifne -> 463
    //   298: goto -> 302
    //   301: athrow
    //   302: ifeq -> 457
    //   305: goto -> 309
    //   308: athrow
    //   309: iload_1
    //   310: ldc -268435456
    //   312: goto -> 316
    //   315: athrow
    //   316: iand
    //   317: iload #4
    //   319: ifne -> 356
    //   322: ifeq -> 351
    //   325: goto -> 329
    //   328: athrow
    //   329: iload_1
    //   330: ldc 267386880
    //   332: iand
    //   333: iload #4
    //   335: ifne -> 356
    //   338: goto -> 342
    //   341: athrow
    //   342: ldc 24117248
    //   344: if_icmpne -> 359
    //   347: goto -> 351
    //   350: athrow
    //   351: iconst_0
    //   352: goto -> 356
    //   355: athrow
    //   356: goto -> 361
    //   359: ldc -268435456
    //   361: iload_1
    //   362: ldc -268435456
    //   364: iand
    //   365: iadd
    //   366: istore #7
    //   368: iload #5
    //   370: ldc -268435456
    //   372: iand
    //   373: iload #4
    //   375: ifne -> 413
    //   378: ifeq -> 408
    //   381: goto -> 385
    //   384: athrow
    //   385: iload #5
    //   387: ldc 267386880
    //   389: iand
    //   390: iload #4
    //   392: ifne -> 413
    //   395: goto -> 399
    //   398: athrow
    //   399: ldc 24117248
    //   401: if_icmpne -> 416
    //   404: goto -> 408
    //   407: athrow
    //   408: iconst_0
    //   409: goto -> 413
    //   412: athrow
    //   413: goto -> 418
    //   416: ldc -268435456
    //   418: iload #5
    //   420: ldc -268435456
    //   422: iand
    //   423: iadd
    //   424: istore #8
    //   426: iload #7
    //   428: iload #8
    //   430: invokestatic min : (II)I
    //   433: ldc 24117248
    //   435: ior
    //   436: aload_0
    //   437: sipush #21720
    //   440: sipush #5708
    //   443: invokestatic b : (II)Ljava/lang/String;
    //   446: invokevirtual c : (Ljava/lang/String;)I
    //   449: ior
    //   450: istore #6
    //   452: iload #4
    //   454: ifeq -> 553
    //   457: ldc 16777216
    //   459: goto -> 463
    //   462: athrow
    //   463: istore #6
    //   465: iload #4
    //   467: ifeq -> 553
    //   470: iload #5
    //   472: goto -> 476
    //   475: athrow
    //   476: iload #4
    //   478: ifne -> 551
    //   481: ldc 16777221
    //   483: if_icmpne -> 545
    //   486: goto -> 490
    //   489: athrow
    //   490: iload_1
    //   491: ldc 267386880
    //   493: iand
    //   494: iload #4
    //   496: ifne -> 533
    //   499: goto -> 503
    //   502: athrow
    //   503: ldc 24117248
    //   505: if_icmpeq -> 532
    //   508: goto -> 512
    //   511: athrow
    //   512: iload_1
    //   513: ldc -268435456
    //   515: iand
    //   516: iload #4
    //   518: ifne -> 533
    //   521: goto -> 525
    //   524: athrow
    //   525: ifeq -> 536
    //   528: goto -> 532
    //   531: athrow
    //   532: iload_1
    //   533: goto -> 538
    //   536: ldc 16777216
    //   538: istore #6
    //   540: iload #4
    //   542: ifeq -> 553
    //   545: ldc 16777216
    //   547: goto -> 551
    //   550: athrow
    //   551: istore #6
    //   553: iload #5
    //   555: iload #4
    //   557: ifne -> 578
    //   560: iload #6
    //   562: if_icmpeq -> 577
    //   565: goto -> 569
    //   568: athrow
    //   569: aload_2
    //   570: iload_3
    //   571: iload #6
    //   573: iastore
    //   574: iconst_1
    //   575: ireturn
    //   576: athrow
    //   577: iconst_0
    //   578: ireturn
    // Exception table:
    //   from	to	target	type
    //   10	21	24	java/lang/RuntimeException
    //   18	27	27	java/lang/RuntimeException
    //   28	39	42	java/lang/RuntimeException
    //   43	53	56	java/lang/RuntimeException
    //   46	62	65	java/lang/RuntimeException
    //   57	68	68	java/lang/RuntimeException
    //   74	82	85	java/lang/RuntimeException
    //   79	92	92	java/lang/RuntimeException
    //   98	108	111	java/lang/RuntimeException
    //   105	122	125	java/lang/RuntimeException
    //   112	129	132	java/lang/RuntimeException
    //   126	136	139	java/lang/RuntimeException
    //   140	148	151	java/lang/RuntimeException
    //   145	154	154	java/lang/RuntimeException
    //   164	172	175	java/lang/RuntimeException
    //   169	188	191	java/lang/RuntimeException
    //   176	195	198	java/lang/RuntimeException
    //   222	234	237	java/lang/RuntimeException
    //   262	273	276	java/lang/RuntimeException
    //   277	285	288	java/lang/RuntimeException
    //   282	298	301	java/lang/RuntimeException
    //   289	305	308	java/lang/RuntimeException
    //   302	312	315	java/lang/RuntimeException
    //   316	325	328	java/lang/RuntimeException
    //   322	338	341	java/lang/RuntimeException
    //   329	347	350	java/lang/RuntimeException
    //   342	352	355	java/lang/RuntimeException
    //   368	381	384	java/lang/RuntimeException
    //   378	395	398	java/lang/RuntimeException
    //   385	404	407	java/lang/RuntimeException
    //   399	409	412	java/lang/RuntimeException
    //   452	459	462	java/lang/RuntimeException
    //   465	472	475	java/lang/RuntimeException
    //   476	486	489	java/lang/RuntimeException
    //   481	499	502	java/lang/RuntimeException
    //   490	508	511	java/lang/RuntimeException
    //   503	521	524	java/lang/RuntimeException
    //   512	528	531	java/lang/RuntimeException
    //   540	547	550	java/lang/RuntimeException
    //   553	565	568	java/lang/RuntimeException
    //   560	576	576	java/lang/RuntimeException
  }
  
  static {
    // Byte code:
    //   0: bipush #7
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc '#öÖxØü±Ûý*ñÑÈ³wlp>÷wc%r®Ù}ä¤&÷Æ\\rråê'4.3GÛþó¤Ò²ÁGÅU«X¹ÅøäÕÛ"eDt4N1T¾ð´Bò±|¼Ce-%pë¾9?÷UX¨ø¿[<-\\bÍÊÎ¼'%B¦»~3R6¼Oùó¡ÍÍ\\tÖ°Õª'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #29
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: jsr -> 137
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 23
    //   65: ldc '5ã°Î°ÛåÑøñE§Gç/Ê).s<]D%ß|1ÊD÷ÿslª#¹­¤8Rè|`\\rÊNoPfúAÇ`+Üè}ó¹Ç/>ã\\b¹ÇÎ>6ñ_µ;¥Ûáöú6m¿¦çÚÚTòØköÊP/Ñ-Ì\\bÎ`ëÜ0})¹|¿>ñ\\bÈ¹TÇ?ñxß,µ<ýV÷\\fq¶Õ|k¨­@\\fPýËQ©¤xrÀX¡§ã¹z¹Z|}Çiuï2° ?~ë?ð!ñ§Ê·FþºU¦3.Q}'
    //   67: dup
    //   68: astore_2
    //   69: invokevirtual length : ()I
    //   72: istore #4
    //   74: bipush #16
    //   76: istore_1
    //   77: iconst_m1
    //   78: istore_0
    //   79: iinc #0, 1
    //   82: aload_2
    //   83: iload_0
    //   84: dup
    //   85: iload_1
    //   86: iadd
    //   87: invokevirtual substring : (II)Ljava/lang/String;
    //   90: jsr -> 137
    //   93: aload #5
    //   95: swap
    //   96: iload_3
    //   97: iinc #3, 1
    //   100: swap
    //   101: aastore
    //   102: iload_0
    //   103: iload_1
    //   104: iadd
    //   105: dup
    //   106: istore_0
    //   107: iload #4
    //   109: if_icmpge -> 121
    //   112: aload_2
    //   113: iload_0
    //   114: invokevirtual charAt : (I)C
    //   117: istore_1
    //   118: goto -> 79
    //   121: aload #5
    //   123: putstatic org/objectweb/asm/Frame.j : [Ljava/lang/String;
    //   126: bipush #7
    //   128: anewarray java/lang/String
    //   131: putstatic org/objectweb/asm/Frame.k : [Ljava/lang/String;
    //   134: goto -> 279
    //   137: astore #6
    //   139: invokevirtual toCharArray : ()[C
    //   142: dup
    //   143: arraylength
    //   144: swap
    //   145: iconst_0
    //   146: istore #7
    //   148: swap
    //   149: dup_x1
    //   150: iconst_1
    //   151: if_icmpgt -> 257
    //   154: dup
    //   155: iload #7
    //   157: dup2
    //   158: caload
    //   159: iload #7
    //   161: bipush #7
    //   163: irem
    //   164: tableswitch default -> 239, 0 -> 204, 1 -> 210, 2 -> 216, 3 -> 222, 4 -> 227, 5 -> 233
    //   204: sipush #220
    //   207: goto -> 241
    //   210: sipush #207
    //   213: goto -> 241
    //   216: sipush #220
    //   219: goto -> 241
    //   222: bipush #103
    //   224: goto -> 241
    //   227: sipush #170
    //   230: goto -> 241
    //   233: sipush #207
    //   236: goto -> 241
    //   239: bipush #13
    //   241: ixor
    //   242: i2c
    //   243: castore
    //   244: iinc #7, 1
    //   247: swap
    //   248: dup_x1
    //   249: ifne -> 257
    //   252: dup2
    //   253: swap
    //   254: goto -> 157
    //   257: swap
    //   258: dup_x1
    //   259: iload #7
    //   261: if_icmpgt -> 154
    //   264: new java/lang/String
    //   267: dup_x1
    //   268: swap
    //   269: invokespecial <init> : ([C)V
    //   272: invokevirtual intern : ()Ljava/lang/String;
    //   275: swap
    //   276: pop
    //   277: ret #6
    //   279: invokestatic _clinit_ : ()V
    //   282: sipush #202
    //   285: newarray int
    //   287: astore #9
    //   289: sipush #21723
    //   292: sipush #-28031
    //   295: invokestatic b : (II)Ljava/lang/String;
    //   298: astore #10
    //   300: iconst_0
    //   301: istore #8
    //   303: iload #8
    //   305: aload #9
    //   307: arraylength
    //   308: if_icmpge -> 333
    //   311: aload #9
    //   313: iload #8
    //   315: aload #10
    //   317: iload #8
    //   319: invokevirtual charAt : (I)C
    //   322: bipush #69
    //   324: isub
    //   325: iastore
    //   326: iinc #8, 1
    //   329: goto -> 303
    //   332: athrow
    //   333: aload #9
    //   335: putstatic org/objectweb/asm/Frame.a : [I
    //   338: return
    // Exception table:
    //   from	to	target	type
    //   303	332	332	java/lang/RuntimeException
  }
  
  static void _clinit_() {}
  
  private static String b(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0x54DD) & 0xFFFF;
    if (k[i] == null) {
      char[] arrayOfChar = j[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      char c = '';
      int j = (paramInt2 & 0xFF) - c;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - c;
      if (k < 0)
        k += 256; 
      for (byte b = 0; b < arrayOfChar.length; b++) {
        int m = b % 2;
        if (m == 0) {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
        } else {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b]) & 0xFF;
        } 
      } 
      k[i] = (new String(arrayOfChar)).intern();
    } 
    return k[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Frame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */