package org.objectweb.asm;

public class ByteVector {
  byte[] a = new byte[64];
  
  int b;
  
  public ByteVector() {}
  
  public ByteVector(int paramInt) {}
  
  public ByteVector putByte(int paramInt) {
    int i = MethodVisitor.b;
    int j = this.b;
    try {
      if (i == 0) {
        try {
          if (j + 1 > this.a.length)
            a(1); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
        this.a[j++] = (byte)paramInt;
        this.b = j;
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return this;
  }
  
  ByteVector a(int paramInt1, int paramInt2) {
    int i = this.b;
    try {
      if (i + 2 > this.a.length)
        a(2); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = this.a;
    arrayOfByte[i++] = (byte)paramInt1;
    arrayOfByte[i++] = (byte)paramInt2;
    this.b = i;
    return this;
  }
  
  public ByteVector putShort(int paramInt) {
    int i = this.b;
    try {
      if (i + 2 > this.a.length)
        a(2); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = this.a;
    arrayOfByte[i++] = (byte)(paramInt >>> 8);
    arrayOfByte[i++] = (byte)paramInt;
    this.b = i;
    return this;
  }
  
  ByteVector b(int paramInt1, int paramInt2) {
    int i = this.b;
    try {
      if (i + 3 > this.a.length)
        a(3); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = this.a;
    arrayOfByte[i++] = (byte)paramInt1;
    arrayOfByte[i++] = (byte)(paramInt2 >>> 8);
    arrayOfByte[i++] = (byte)paramInt2;
    this.b = i;
    return this;
  }
  
  public ByteVector putInt(int paramInt) {
    int i = this.b;
    try {
      if (i + 4 > this.a.length)
        a(4); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = this.a;
    arrayOfByte[i++] = (byte)(paramInt >>> 24);
    arrayOfByte[i++] = (byte)(paramInt >>> 16);
    arrayOfByte[i++] = (byte)(paramInt >>> 8);
    arrayOfByte[i++] = (byte)paramInt;
    this.b = i;
    return this;
  }
  
  public ByteVector putLong(long paramLong) {
    int i = this.b;
    try {
      if (i + 8 > this.a.length)
        a(8); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = this.a;
    int j = (int)(paramLong >>> 32L);
    arrayOfByte[i++] = (byte)(j >>> 24);
    arrayOfByte[i++] = (byte)(j >>> 16);
    arrayOfByte[i++] = (byte)(j >>> 8);
    arrayOfByte[i++] = (byte)j;
    j = (int)paramLong;
    arrayOfByte[i++] = (byte)(j >>> 24);
    arrayOfByte[i++] = (byte)(j >>> 16);
    arrayOfByte[i++] = (byte)(j >>> 8);
    arrayOfByte[i++] = (byte)j;
    this.b = i;
    return this;
  }
  
  public ByteVector putUTF8(String paramString) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: istore_3
    //   9: iload_3
    //   10: iload_2
    //   11: ifne -> 36
    //   14: ldc 65535
    //   16: if_icmple -> 32
    //   19: goto -> 23
    //   22: athrow
    //   23: new java/lang/IllegalArgumentException
    //   26: dup
    //   27: invokespecial <init> : ()V
    //   30: athrow
    //   31: athrow
    //   32: aload_0
    //   33: getfield b : I
    //   36: istore #4
    //   38: iload #4
    //   40: iconst_2
    //   41: iadd
    //   42: iload_3
    //   43: iadd
    //   44: aload_0
    //   45: getfield a : [B
    //   48: arraylength
    //   49: if_icmple -> 63
    //   52: aload_0
    //   53: iconst_2
    //   54: iload_3
    //   55: iadd
    //   56: invokespecial a : (I)V
    //   59: goto -> 63
    //   62: athrow
    //   63: aload_0
    //   64: getfield a : [B
    //   67: astore #5
    //   69: aload #5
    //   71: iload #4
    //   73: iinc #4, 1
    //   76: iload_3
    //   77: bipush #8
    //   79: iushr
    //   80: i2b
    //   81: bastore
    //   82: aload #5
    //   84: iload #4
    //   86: iinc #4, 1
    //   89: iload_3
    //   90: i2b
    //   91: bastore
    //   92: iconst_0
    //   93: istore #6
    //   95: iload #6
    //   97: iload_3
    //   98: if_icmpge -> 188
    //   101: aload_1
    //   102: iload #6
    //   104: invokevirtual charAt : (I)C
    //   107: istore #7
    //   109: iload_2
    //   110: ifne -> 194
    //   113: iload_2
    //   114: ifne -> 171
    //   117: goto -> 121
    //   120: athrow
    //   121: iload #7
    //   123: iconst_1
    //   124: if_icmplt -> 161
    //   127: goto -> 131
    //   130: athrow
    //   131: iload #7
    //   133: bipush #127
    //   135: if_icmpgt -> 161
    //   138: goto -> 142
    //   141: athrow
    //   142: aload #5
    //   144: iload #4
    //   146: iinc #4, 1
    //   149: iload #7
    //   151: i2b
    //   152: bastore
    //   153: iload_2
    //   154: ifeq -> 181
    //   157: goto -> 161
    //   160: athrow
    //   161: aload_0
    //   162: iload #4
    //   164: putfield b : I
    //   167: goto -> 171
    //   170: athrow
    //   171: aload_0
    //   172: aload_1
    //   173: iload #6
    //   175: ldc 65535
    //   177: invokevirtual c : (Ljava/lang/String;II)Lorg/objectweb/asm/ByteVector;
    //   180: areturn
    //   181: iinc #6, 1
    //   184: iload_2
    //   185: ifeq -> 95
    //   188: aload_0
    //   189: iload #4
    //   191: putfield b : I
    //   194: aload_0
    //   195: areturn
    // Exception table:
    //   from	to	target	type
    //   9	19	22	java/lang/IllegalArgumentException
    //   14	31	31	java/lang/IllegalArgumentException
    //   38	59	62	java/lang/IllegalArgumentException
    //   109	117	120	java/lang/IllegalArgumentException
    //   113	127	130	java/lang/IllegalArgumentException
    //   121	138	141	java/lang/IllegalArgumentException
    //   131	157	160	java/lang/IllegalArgumentException
    //   142	167	170	java/lang/IllegalArgumentException
  }
  
  ByteVector c(String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual length : ()I
    //   4: istore #5
    //   6: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   9: iload_2
    //   10: istore #6
    //   12: iload_2
    //   13: istore #8
    //   15: istore #4
    //   17: iload #8
    //   19: iload #5
    //   21: if_icmpge -> 127
    //   24: aload_1
    //   25: iload #8
    //   27: invokevirtual charAt : (I)C
    //   30: istore #7
    //   32: iload #7
    //   34: iconst_1
    //   35: iload #4
    //   37: ifne -> 130
    //   40: iload #4
    //   42: ifne -> 97
    //   45: goto -> 49
    //   48: athrow
    //   49: if_icmplt -> 88
    //   52: goto -> 56
    //   55: athrow
    //   56: iload #7
    //   58: bipush #127
    //   60: iload #4
    //   62: ifne -> 97
    //   65: goto -> 69
    //   68: athrow
    //   69: if_icmpgt -> 88
    //   72: goto -> 76
    //   75: athrow
    //   76: iinc #6, 1
    //   79: iload #4
    //   81: ifeq -> 119
    //   84: goto -> 88
    //   87: athrow
    //   88: iload #7
    //   90: sipush #2047
    //   93: goto -> 97
    //   96: athrow
    //   97: if_icmple -> 112
    //   100: iinc #6, 3
    //   103: iload #4
    //   105: ifeq -> 119
    //   108: goto -> 112
    //   111: athrow
    //   112: iinc #6, 2
    //   115: goto -> 119
    //   118: athrow
    //   119: iinc #8, 1
    //   122: iload #4
    //   124: ifeq -> 17
    //   127: iload #6
    //   129: iload_3
    //   130: iload #4
    //   132: ifne -> 158
    //   135: if_icmple -> 151
    //   138: goto -> 142
    //   141: athrow
    //   142: new java/lang/IllegalArgumentException
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: athrow
    //   150: athrow
    //   151: aload_0
    //   152: getfield b : I
    //   155: iload_2
    //   156: isub
    //   157: iconst_2
    //   158: isub
    //   159: istore #8
    //   161: iload #8
    //   163: iload #4
    //   165: ifne -> 213
    //   168: iflt -> 204
    //   171: goto -> 175
    //   174: athrow
    //   175: aload_0
    //   176: getfield a : [B
    //   179: iload #8
    //   181: iload #6
    //   183: bipush #8
    //   185: iushr
    //   186: i2b
    //   187: bastore
    //   188: aload_0
    //   189: getfield a : [B
    //   192: iload #8
    //   194: iconst_1
    //   195: iadd
    //   196: iload #6
    //   198: i2b
    //   199: bastore
    //   200: goto -> 204
    //   203: athrow
    //   204: aload_0
    //   205: getfield b : I
    //   208: iload #6
    //   210: iadd
    //   211: iload_2
    //   212: isub
    //   213: iload #4
    //   215: ifne -> 246
    //   218: aload_0
    //   219: getfield a : [B
    //   222: arraylength
    //   223: if_icmple -> 242
    //   226: goto -> 230
    //   229: athrow
    //   230: aload_0
    //   231: iload #6
    //   233: iload_2
    //   234: isub
    //   235: invokespecial a : (I)V
    //   238: goto -> 242
    //   241: athrow
    //   242: aload_0
    //   243: getfield b : I
    //   246: istore #9
    //   248: iload_2
    //   249: istore #10
    //   251: iload #10
    //   253: iload #5
    //   255: if_icmpge -> 474
    //   258: aload_1
    //   259: iload #10
    //   261: invokevirtual charAt : (I)C
    //   264: istore #7
    //   266: iload #4
    //   268: ifne -> 480
    //   271: iload #7
    //   273: iconst_1
    //   274: iload #4
    //   276: ifne -> 341
    //   279: goto -> 283
    //   282: athrow
    //   283: if_icmplt -> 332
    //   286: goto -> 290
    //   289: athrow
    //   290: iload #7
    //   292: bipush #127
    //   294: iload #4
    //   296: ifne -> 341
    //   299: goto -> 303
    //   302: athrow
    //   303: if_icmpgt -> 332
    //   306: goto -> 310
    //   309: athrow
    //   310: aload_0
    //   311: getfield a : [B
    //   314: iload #9
    //   316: iinc #9, 1
    //   319: iload #7
    //   321: i2b
    //   322: bastore
    //   323: iload #4
    //   325: ifeq -> 466
    //   328: goto -> 332
    //   331: athrow
    //   332: iload #7
    //   334: sipush #2047
    //   337: goto -> 341
    //   340: athrow
    //   341: if_icmple -> 419
    //   344: aload_0
    //   345: getfield a : [B
    //   348: iload #9
    //   350: iinc #9, 1
    //   353: sipush #224
    //   356: iload #7
    //   358: bipush #12
    //   360: ishr
    //   361: bipush #15
    //   363: iand
    //   364: ior
    //   365: i2b
    //   366: bastore
    //   367: aload_0
    //   368: getfield a : [B
    //   371: iload #9
    //   373: iinc #9, 1
    //   376: sipush #128
    //   379: iload #7
    //   381: bipush #6
    //   383: ishr
    //   384: bipush #63
    //   386: iand
    //   387: ior
    //   388: i2b
    //   389: bastore
    //   390: aload_0
    //   391: getfield a : [B
    //   394: iload #9
    //   396: iinc #9, 1
    //   399: sipush #128
    //   402: iload #7
    //   404: bipush #63
    //   406: iand
    //   407: ior
    //   408: i2b
    //   409: bastore
    //   410: iload #4
    //   412: ifeq -> 466
    //   415: goto -> 419
    //   418: athrow
    //   419: aload_0
    //   420: getfield a : [B
    //   423: iload #9
    //   425: iinc #9, 1
    //   428: sipush #192
    //   431: iload #7
    //   433: bipush #6
    //   435: ishr
    //   436: bipush #31
    //   438: iand
    //   439: ior
    //   440: i2b
    //   441: bastore
    //   442: aload_0
    //   443: getfield a : [B
    //   446: iload #9
    //   448: iinc #9, 1
    //   451: sipush #128
    //   454: iload #7
    //   456: bipush #63
    //   458: iand
    //   459: ior
    //   460: i2b
    //   461: bastore
    //   462: goto -> 466
    //   465: athrow
    //   466: iinc #10, 1
    //   469: iload #4
    //   471: ifeq -> 251
    //   474: aload_0
    //   475: iload #9
    //   477: putfield b : I
    //   480: aload_0
    //   481: areturn
    // Exception table:
    //   from	to	target	type
    //   32	45	48	java/lang/IllegalArgumentException
    //   40	52	55	java/lang/IllegalArgumentException
    //   49	65	68	java/lang/IllegalArgumentException
    //   56	72	75	java/lang/IllegalArgumentException
    //   69	84	87	java/lang/IllegalArgumentException
    //   76	93	96	java/lang/IllegalArgumentException
    //   97	108	111	java/lang/IllegalArgumentException
    //   100	115	118	java/lang/IllegalArgumentException
    //   130	138	141	java/lang/IllegalArgumentException
    //   135	150	150	java/lang/IllegalArgumentException
    //   161	171	174	java/lang/IllegalArgumentException
    //   168	200	203	java/lang/IllegalArgumentException
    //   213	226	229	java/lang/IllegalArgumentException
    //   218	238	241	java/lang/IllegalArgumentException
    //   266	279	282	java/lang/IllegalArgumentException
    //   271	286	289	java/lang/IllegalArgumentException
    //   283	299	302	java/lang/IllegalArgumentException
    //   290	306	309	java/lang/IllegalArgumentException
    //   303	328	331	java/lang/IllegalArgumentException
    //   310	337	340	java/lang/IllegalArgumentException
    //   341	415	418	java/lang/IllegalArgumentException
    //   344	462	465	java/lang/IllegalArgumentException
  }
  
  public ByteVector putByteArray(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #4
    //   5: aload_0
    //   6: iload #4
    //   8: ifne -> 33
    //   11: getfield b : I
    //   14: iload_3
    //   15: iadd
    //   16: aload_0
    //   17: getfield a : [B
    //   20: arraylength
    //   21: if_icmple -> 37
    //   24: goto -> 28
    //   27: athrow
    //   28: aload_0
    //   29: goto -> 33
    //   32: athrow
    //   33: iload_3
    //   34: invokespecial a : (I)V
    //   37: aload_1
    //   38: iload #4
    //   40: ifne -> 51
    //   43: ifnull -> 64
    //   46: goto -> 50
    //   49: athrow
    //   50: aload_1
    //   51: iload_2
    //   52: aload_0
    //   53: getfield a : [B
    //   56: aload_0
    //   57: getfield b : I
    //   60: iload_3
    //   61: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   64: aload_0
    //   65: dup
    //   66: getfield b : I
    //   69: iload_3
    //   70: iadd
    //   71: putfield b : I
    //   74: aload_0
    //   75: areturn
    // Exception table:
    //   from	to	target	type
    //   5	24	27	java/lang/IllegalArgumentException
    //   11	29	32	java/lang/IllegalArgumentException
    //   37	46	49	java/lang/IllegalArgumentException
  }
  
  private void a(int paramInt) {
    int j = 2 * this.a.length;
    int k = this.b + paramInt;
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
        
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    byte[] arrayOfByte = new byte[(j > k) ? j : k];
    System.arraycopy(this.a, 0, arrayOfByte, 0, this.b);
    this.a = arrayOfByte;
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\ByteVector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */