package org.objectweb.asm;

final class FieldWriter extends FieldVisitor {
  private final ClassWriter b;
  
  private final int c;
  
  private final int d;
  
  private final int e;
  
  private int f;
  
  private int g;
  
  private AnnotationWriter h;
  
  private AnnotationWriter i;
  
  private AnnotationWriter k;
  
  private AnnotationWriter l;
  
  private Attribute j;
  
  private static final String[] a;
  
  private static final String[] m;
  
  FieldWriter(ClassWriter paramClassWriter, int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #7
    //   5: aload_0
    //   6: ldc 327680
    //   8: invokespecial <init> : (I)V
    //   11: aload_1
    //   12: getfield B : Lorg/objectweb/asm/FieldWriter;
    //   15: iload #7
    //   17: ifne -> 37
    //   20: ifnonnull -> 33
    //   23: aload_1
    //   24: aload_0
    //   25: putfield B : Lorg/objectweb/asm/FieldWriter;
    //   28: iload #7
    //   30: ifeq -> 41
    //   33: aload_1
    //   34: getfield C : Lorg/objectweb/asm/FieldWriter;
    //   37: aload_0
    //   38: putfield fv : Lorg/objectweb/asm/FieldVisitor;
    //   41: aload_1
    //   42: aload_0
    //   43: putfield C : Lorg/objectweb/asm/FieldWriter;
    //   46: aload_0
    //   47: aload_1
    //   48: putfield b : Lorg/objectweb/asm/ClassWriter;
    //   51: aload_0
    //   52: iload_2
    //   53: putfield c : I
    //   56: aload_0
    //   57: aload_1
    //   58: aload_3
    //   59: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   62: putfield d : I
    //   65: aload_0
    //   66: aload_1
    //   67: aload #4
    //   69: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   72: putfield e : I
    //   75: aload #5
    //   77: iload #7
    //   79: ifne -> 97
    //   82: ifnull -> 95
    //   85: aload_0
    //   86: aload_1
    //   87: aload #5
    //   89: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   92: putfield f : I
    //   95: aload #6
    //   97: ifnull -> 113
    //   100: aload_0
    //   101: aload_1
    //   102: aload #6
    //   104: invokevirtual a : (Ljava/lang/Object;)Lorg/objectweb/asm/Item;
    //   107: getfield a : I
    //   110: putfield g : I
    //   113: return
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   12: aload #4
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_1
    //   19: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   22: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   25: iconst_0
    //   26: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   29: pop
    //   30: istore_3
    //   31: new org/objectweb/asm/AnnotationWriter
    //   34: dup
    //   35: aload_0
    //   36: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   39: iconst_1
    //   40: aload #4
    //   42: aload #4
    //   44: iconst_2
    //   45: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   48: astore #5
    //   50: iload_3
    //   51: ifne -> 86
    //   54: iload_2
    //   55: ifeq -> 77
    //   58: aload #5
    //   60: aload_0
    //   61: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   64: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   67: aload_0
    //   68: aload #5
    //   70: putfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   73: iload_3
    //   74: ifeq -> 92
    //   77: aload #5
    //   79: aload_0
    //   80: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   83: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   86: aload_0
    //   87: aload #5
    //   89: putfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   92: aload #5
    //   94: areturn
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   12: iload_1
    //   13: aload_2
    //   14: aload #6
    //   16: invokestatic a : (ILorg/objectweb/asm/TypePath;Lorg/objectweb/asm/ByteVector;)V
    //   19: istore #5
    //   21: aload #6
    //   23: aload_0
    //   24: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   27: aload_3
    //   28: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   31: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   34: iconst_0
    //   35: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   38: pop
    //   39: new org/objectweb/asm/AnnotationWriter
    //   42: dup
    //   43: aload_0
    //   44: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   47: iconst_1
    //   48: aload #6
    //   50: aload #6
    //   52: aload #6
    //   54: getfield b : I
    //   57: iconst_2
    //   58: isub
    //   59: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   62: astore #7
    //   64: iload #5
    //   66: ifne -> 103
    //   69: iload #4
    //   71: ifeq -> 94
    //   74: aload #7
    //   76: aload_0
    //   77: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   80: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   83: aload_0
    //   84: aload #7
    //   86: putfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   89: iload #5
    //   91: ifeq -> 109
    //   94: aload #7
    //   96: aload_0
    //   97: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   100: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   103: aload_0
    //   104: aload #7
    //   106: putfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   109: aload #7
    //   111: areturn
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    paramAttribute.a = this.j;
    this.j = paramAttribute;
  }
  
  public void visitEnd() {}
  
  int a() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: bipush #8
    //   6: istore_2
    //   7: aload_0
    //   8: getfield g : I
    //   11: iload_1
    //   12: ifne -> 46
    //   15: ifeq -> 38
    //   18: aload_0
    //   19: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   22: sipush #-26258
    //   25: sipush #-21487
    //   28: invokestatic a : (II)Ljava/lang/String;
    //   31: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   34: pop
    //   35: iinc #2, 8
    //   38: aload_0
    //   39: getfield c : I
    //   42: sipush #4096
    //   45: iand
    //   46: iload_1
    //   47: ifne -> 113
    //   50: ifeq -> 106
    //   53: aload_0
    //   54: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   57: getfield b : I
    //   60: ldc 65535
    //   62: iand
    //   63: iload_1
    //   64: ifne -> 102
    //   67: bipush #49
    //   69: if_icmplt -> 86
    //   72: aload_0
    //   73: getfield c : I
    //   76: ldc 262144
    //   78: iand
    //   79: iload_1
    //   80: ifne -> 113
    //   83: ifeq -> 106
    //   86: aload_0
    //   87: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   90: sipush #-26263
    //   93: sipush #27678
    //   96: invokestatic a : (II)Ljava/lang/String;
    //   99: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   102: pop
    //   103: iinc #2, 6
    //   106: aload_0
    //   107: getfield c : I
    //   110: ldc 131072
    //   112: iand
    //   113: iload_1
    //   114: ifne -> 148
    //   117: ifeq -> 140
    //   120: aload_0
    //   121: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   124: sipush #-26260
    //   127: sipush #-21144
    //   130: invokestatic a : (II)Ljava/lang/String;
    //   133: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   136: pop
    //   137: iinc #2, 6
    //   140: aload_0
    //   141: iload_1
    //   142: ifne -> 172
    //   145: getfield f : I
    //   148: ifeq -> 171
    //   151: aload_0
    //   152: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   155: sipush #-26261
    //   158: sipush #14290
    //   161: invokestatic a : (II)Ljava/lang/String;
    //   164: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   167: pop
    //   168: iinc #2, 8
    //   171: aload_0
    //   172: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   175: iload_1
    //   176: ifne -> 216
    //   179: ifnull -> 212
    //   182: aload_0
    //   183: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   186: sipush #-26257
    //   189: sipush #-990
    //   192: invokestatic a : (II)Ljava/lang/String;
    //   195: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   198: pop
    //   199: iload_2
    //   200: bipush #8
    //   202: aload_0
    //   203: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   206: invokevirtual a : ()I
    //   209: iadd
    //   210: iadd
    //   211: istore_2
    //   212: aload_0
    //   213: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   216: iload_1
    //   217: ifne -> 257
    //   220: ifnull -> 253
    //   223: aload_0
    //   224: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   227: sipush #-26262
    //   230: sipush #-11926
    //   233: invokestatic a : (II)Ljava/lang/String;
    //   236: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   239: pop
    //   240: iload_2
    //   241: bipush #8
    //   243: aload_0
    //   244: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   247: invokevirtual a : ()I
    //   250: iadd
    //   251: iadd
    //   252: istore_2
    //   253: aload_0
    //   254: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   257: iload_1
    //   258: ifne -> 302
    //   261: ifnull -> 294
    //   264: aload_0
    //   265: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   268: sipush #-26264
    //   271: sipush #-11351
    //   274: invokestatic a : (II)Ljava/lang/String;
    //   277: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   280: pop
    //   281: iload_2
    //   282: bipush #8
    //   284: aload_0
    //   285: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   288: invokevirtual a : ()I
    //   291: iadd
    //   292: iadd
    //   293: istore_2
    //   294: aload_0
    //   295: iload_1
    //   296: ifne -> 336
    //   299: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   302: ifnull -> 335
    //   305: aload_0
    //   306: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   309: sipush #-26259
    //   312: sipush #-378
    //   315: invokestatic a : (II)Ljava/lang/String;
    //   318: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   321: pop
    //   322: iload_2
    //   323: bipush #8
    //   325: aload_0
    //   326: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   329: invokevirtual a : ()I
    //   332: iadd
    //   333: iadd
    //   334: istore_2
    //   335: aload_0
    //   336: getfield j : Lorg/objectweb/asm/Attribute;
    //   339: ifnull -> 360
    //   342: iload_2
    //   343: aload_0
    //   344: getfield j : Lorg/objectweb/asm/Attribute;
    //   347: aload_0
    //   348: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   351: aconst_null
    //   352: iconst_0
    //   353: iconst_m1
    //   354: iconst_m1
    //   355: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIII)I
    //   358: iadd
    //   359: istore_2
    //   360: iload_2
    //   361: ireturn
  }
  
  void a(ByteVector paramByteVector) {
    // Byte code:
    //   0: bipush #64
    //   2: istore_3
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: ldc 393216
    //   8: aload_0
    //   9: getfield c : I
    //   12: ldc 262144
    //   14: iand
    //   15: bipush #64
    //   17: idiv
    //   18: ior
    //   19: istore #4
    //   21: istore_2
    //   22: aload_1
    //   23: aload_0
    //   24: getfield c : I
    //   27: iload #4
    //   29: iconst_m1
    //   30: ixor
    //   31: iand
    //   32: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   35: aload_0
    //   36: getfield d : I
    //   39: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   42: aload_0
    //   43: getfield e : I
    //   46: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   49: pop
    //   50: iconst_0
    //   51: istore #5
    //   53: aload_0
    //   54: getfield g : I
    //   57: iload_2
    //   58: ifne -> 75
    //   61: ifeq -> 67
    //   64: iinc #5, 1
    //   67: aload_0
    //   68: getfield c : I
    //   71: sipush #4096
    //   74: iand
    //   75: iload_2
    //   76: ifne -> 125
    //   79: ifeq -> 118
    //   82: aload_0
    //   83: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   86: getfield b : I
    //   89: ldc 65535
    //   91: iand
    //   92: bipush #49
    //   94: iload_2
    //   95: ifne -> 107
    //   98: if_icmplt -> 115
    //   101: aload_0
    //   102: getfield c : I
    //   105: ldc 262144
    //   107: iand
    //   108: iload_2
    //   109: ifne -> 125
    //   112: ifeq -> 118
    //   115: iinc #5, 1
    //   118: aload_0
    //   119: getfield c : I
    //   122: ldc 131072
    //   124: iand
    //   125: iload_2
    //   126: ifne -> 143
    //   129: ifeq -> 135
    //   132: iinc #5, 1
    //   135: aload_0
    //   136: iload_2
    //   137: ifne -> 150
    //   140: getfield f : I
    //   143: ifeq -> 149
    //   146: iinc #5, 1
    //   149: aload_0
    //   150: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   153: iload_2
    //   154: ifne -> 167
    //   157: ifnull -> 163
    //   160: iinc #5, 1
    //   163: aload_0
    //   164: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   167: iload_2
    //   168: ifne -> 181
    //   171: ifnull -> 177
    //   174: iinc #5, 1
    //   177: aload_0
    //   178: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   181: iload_2
    //   182: ifne -> 199
    //   185: ifnull -> 191
    //   188: iinc #5, 1
    //   191: aload_0
    //   192: iload_2
    //   193: ifne -> 206
    //   196: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   199: ifnull -> 205
    //   202: iinc #5, 1
    //   205: aload_0
    //   206: iload_2
    //   207: ifne -> 236
    //   210: getfield j : Lorg/objectweb/asm/Attribute;
    //   213: ifnull -> 228
    //   216: iload #5
    //   218: aload_0
    //   219: getfield j : Lorg/objectweb/asm/Attribute;
    //   222: invokevirtual a : ()I
    //   225: iadd
    //   226: istore #5
    //   228: aload_1
    //   229: iload #5
    //   231: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   234: pop
    //   235: aload_0
    //   236: getfield g : I
    //   239: iload_2
    //   240: ifne -> 288
    //   243: ifeq -> 280
    //   246: aload_1
    //   247: aload_0
    //   248: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   251: sipush #-26258
    //   254: sipush #-21487
    //   257: invokestatic a : (II)Ljava/lang/String;
    //   260: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   263: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   266: pop
    //   267: aload_1
    //   268: iconst_2
    //   269: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   272: aload_0
    //   273: getfield g : I
    //   276: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   279: pop
    //   280: aload_0
    //   281: getfield c : I
    //   284: sipush #4096
    //   287: iand
    //   288: iload_2
    //   289: ifne -> 360
    //   292: ifeq -> 353
    //   295: aload_0
    //   296: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   299: getfield b : I
    //   302: ldc 65535
    //   304: iand
    //   305: bipush #49
    //   307: iload_2
    //   308: ifne -> 320
    //   311: if_icmplt -> 328
    //   314: aload_0
    //   315: getfield c : I
    //   318: ldc 262144
    //   320: iand
    //   321: iload_2
    //   322: ifne -> 360
    //   325: ifeq -> 353
    //   328: aload_1
    //   329: aload_0
    //   330: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   333: sipush #-26263
    //   336: sipush #27678
    //   339: invokestatic a : (II)Ljava/lang/String;
    //   342: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   345: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   348: iconst_0
    //   349: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   352: pop
    //   353: aload_0
    //   354: getfield c : I
    //   357: ldc 131072
    //   359: iand
    //   360: iload_2
    //   361: ifne -> 400
    //   364: ifeq -> 392
    //   367: aload_1
    //   368: aload_0
    //   369: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   372: sipush #-26260
    //   375: sipush #-21144
    //   378: invokestatic a : (II)Ljava/lang/String;
    //   381: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   384: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   387: iconst_0
    //   388: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   391: pop
    //   392: aload_0
    //   393: iload_2
    //   394: ifne -> 438
    //   397: getfield f : I
    //   400: ifeq -> 437
    //   403: aload_1
    //   404: aload_0
    //   405: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   408: sipush #-26261
    //   411: sipush #14290
    //   414: invokestatic a : (II)Ljava/lang/String;
    //   417: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   420: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   423: pop
    //   424: aload_1
    //   425: iconst_2
    //   426: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   429: aload_0
    //   430: getfield f : I
    //   433: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   436: pop
    //   437: aload_0
    //   438: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   441: iload_2
    //   442: ifne -> 481
    //   445: ifnull -> 477
    //   448: aload_1
    //   449: aload_0
    //   450: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   453: sipush #-26257
    //   456: sipush #-990
    //   459: invokestatic a : (II)Ljava/lang/String;
    //   462: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   465: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   468: pop
    //   469: aload_0
    //   470: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   473: aload_1
    //   474: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   477: aload_0
    //   478: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   481: iload_2
    //   482: ifne -> 521
    //   485: ifnull -> 517
    //   488: aload_1
    //   489: aload_0
    //   490: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   493: sipush #-26262
    //   496: sipush #-11926
    //   499: invokestatic a : (II)Ljava/lang/String;
    //   502: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   505: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   508: pop
    //   509: aload_0
    //   510: getfield i : Lorg/objectweb/asm/AnnotationWriter;
    //   513: aload_1
    //   514: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   517: aload_0
    //   518: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   521: iload_2
    //   522: ifne -> 565
    //   525: ifnull -> 557
    //   528: aload_1
    //   529: aload_0
    //   530: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   533: sipush #-26264
    //   536: sipush #-11351
    //   539: invokestatic a : (II)Ljava/lang/String;
    //   542: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   545: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   548: pop
    //   549: aload_0
    //   550: getfield k : Lorg/objectweb/asm/AnnotationWriter;
    //   553: aload_1
    //   554: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   557: aload_0
    //   558: iload_2
    //   559: ifne -> 598
    //   562: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   565: ifnull -> 597
    //   568: aload_1
    //   569: aload_0
    //   570: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   573: sipush #-26259
    //   576: sipush #-378
    //   579: invokestatic a : (II)Ljava/lang/String;
    //   582: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   585: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   588: pop
    //   589: aload_0
    //   590: getfield l : Lorg/objectweb/asm/AnnotationWriter;
    //   593: aload_1
    //   594: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   597: aload_0
    //   598: getfield j : Lorg/objectweb/asm/Attribute;
    //   601: iload_2
    //   602: ifne -> 612
    //   605: ifnull -> 624
    //   608: aload_0
    //   609: getfield j : Lorg/objectweb/asm/Attribute;
    //   612: aload_0
    //   613: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   616: aconst_null
    //   617: iconst_0
    //   618: iconst_m1
    //   619: iconst_m1
    //   620: aload_1
    //   621: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIIILorg/objectweb/asm/ByteVector;)V
    //   624: return
  }
  
  static {
    // Byte code:
    //   0: bipush #8
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc 'SúÉ8f¨W/9QL! ¯o8ãd,`³|YYF\\tY©~5÷^\Ô¾9&¥(q1.Hú½/Â¼|~É.\\t+"îüçÄy\\nôF÷.­-R¶©¢Ótÿ°ËýVÏª·0yëdK¤¤ð'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #29
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: jsr -> 137
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 23
    //   65: ldc 'Â/DÚ\þE¦ÁKñ8?ÓpK4º2<M»5¥¨2ÛþÕ µ'
    //   67: dup
    //   68: astore_2
    //   69: invokevirtual length : ()I
    //   72: istore #4
    //   74: bipush #13
    //   76: istore_1
    //   77: iconst_m1
    //   78: istore_0
    //   79: iinc #0, 1
    //   82: aload_2
    //   83: iload_0
    //   84: dup
    //   85: iload_1
    //   86: iadd
    //   87: invokevirtual substring : (II)Ljava/lang/String;
    //   90: jsr -> 137
    //   93: aload #5
    //   95: swap
    //   96: iload_3
    //   97: iinc #3, 1
    //   100: swap
    //   101: aastore
    //   102: iload_0
    //   103: iload_1
    //   104: iadd
    //   105: dup
    //   106: istore_0
    //   107: iload #4
    //   109: if_icmpge -> 121
    //   112: aload_2
    //   113: iload_0
    //   114: invokevirtual charAt : (I)C
    //   117: istore_1
    //   118: goto -> 79
    //   121: aload #5
    //   123: putstatic org/objectweb/asm/FieldWriter.a : [Ljava/lang/String;
    //   126: bipush #8
    //   128: anewarray java/lang/String
    //   131: putstatic org/objectweb/asm/FieldWriter.m : [Ljava/lang/String;
    //   134: goto -> 278
    //   137: astore #6
    //   139: invokevirtual toCharArray : ()[C
    //   142: dup
    //   143: arraylength
    //   144: swap
    //   145: iconst_0
    //   146: istore #7
    //   148: swap
    //   149: dup_x1
    //   150: iconst_1
    //   151: if_icmpgt -> 256
    //   154: dup
    //   155: iload #7
    //   157: dup2
    //   158: caload
    //   159: iload #7
    //   161: bipush #7
    //   163: irem
    //   164: tableswitch default -> 237, 0 -> 204, 1 -> 210, 2 -> 215, 3 -> 221, 4 -> 226, 5 -> 232
    //   204: sipush #185
    //   207: goto -> 240
    //   210: bipush #109
    //   212: goto -> 240
    //   215: sipush #226
    //   218: goto -> 240
    //   221: bipush #83
    //   223: goto -> 240
    //   226: sipush #151
    //   229: goto -> 240
    //   232: bipush #41
    //   234: goto -> 240
    //   237: sipush #178
    //   240: ixor
    //   241: i2c
    //   242: castore
    //   243: iinc #7, 1
    //   246: swap
    //   247: dup_x1
    //   248: ifne -> 256
    //   251: dup2
    //   252: swap
    //   253: goto -> 157
    //   256: swap
    //   257: dup_x1
    //   258: iload #7
    //   260: if_icmpgt -> 154
    //   263: new java/lang/String
    //   266: dup_x1
    //   267: swap
    //   268: invokespecial <init> : ([C)V
    //   271: invokevirtual intern : ()Ljava/lang/String;
    //   274: swap
    //   275: pop
    //   276: ret #6
    //   278: return
  }
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0xFFFF9968) & 0xFFFF;
    if (m[i] == null) {
      char[] arrayOfChar = a[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      char c = 'è';
      int j = (paramInt2 & 0xFF) - c;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - c;
      if (k < 0)
        k += 256; 
      for (byte b = 0; b < arrayOfChar.length; b++) {
        int m = b % 2;
        if (m == 0) {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
        } else {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b]) & 0xFF;
        } 
      } 
      m[i] = (new String(arrayOfChar)).intern();
    } 
    return m[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\FieldWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */