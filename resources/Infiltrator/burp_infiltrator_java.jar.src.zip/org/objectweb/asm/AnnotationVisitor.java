package org.objectweb.asm;

public abstract class AnnotationVisitor {
  protected final int api;
  
  protected AnnotationVisitor av;
  
  public AnnotationVisitor(int paramInt) {
    this(paramInt, null);
  }
  
  public AnnotationVisitor(int paramInt, AnnotationVisitor paramAnnotationVisitor) {
    if (i == 0) {
      try {
        if (paramInt != 262144)
          try {
            if (paramInt != 327680)
              throw new IllegalArgumentException(); 
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          }  
      } catch (IllegalArgumentException illegalArgumentException) {
        throw null;
      } 
      this.api = paramInt;
      this.av = paramAnnotationVisitor;
    } 
  }
  
  public void visit(String paramString, Object paramObject) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.av != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.av.visit(paramString, paramObject);
  }
  
  public void visitEnum(String paramString1, String paramString2, String paramString3) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.av != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.av.visitEnum(paramString1, paramString2, paramString3);
  }
  
  public AnnotationVisitor visitAnnotation(String paramString1, String paramString2) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.av != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.av;
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitArray(String paramString) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.av != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.av;
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitEnd() {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.av != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.av.visitEnd();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\AnnotationVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */