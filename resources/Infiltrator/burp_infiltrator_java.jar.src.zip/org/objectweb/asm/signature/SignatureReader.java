package org.objectweb.asm.signature;

public class SignatureReader {
  private final String a;
  
  public SignatureReader(String paramString) {
    this.a = paramString;
  }
  
  public void accept(SignatureVisitor paramSignatureVisitor) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/lang/String;
    //   4: astore_3
    //   5: getstatic org/objectweb/asm/signature/SignatureVisitor.d : Z
    //   8: aload_3
    //   9: invokevirtual length : ()I
    //   12: istore #4
    //   14: istore_2
    //   15: aload_3
    //   16: iconst_0
    //   17: invokevirtual charAt : (I)C
    //   20: iload_2
    //   21: ifne -> 173
    //   24: bipush #60
    //   26: if_icmpne -> 172
    //   29: iconst_2
    //   30: istore #5
    //   32: aload_3
    //   33: bipush #58
    //   35: iload #5
    //   37: invokevirtual indexOf : (II)I
    //   40: istore #7
    //   42: aload_1
    //   43: aload_3
    //   44: iload #5
    //   46: iconst_1
    //   47: isub
    //   48: iload #7
    //   50: invokevirtual substring : (II)Ljava/lang/String;
    //   53: invokevirtual visitFormalTypeParameter : (Ljava/lang/String;)V
    //   56: iload #7
    //   58: iconst_1
    //   59: iadd
    //   60: istore #5
    //   62: aload_3
    //   63: iload #5
    //   65: invokevirtual charAt : (I)C
    //   68: istore #6
    //   70: iload #6
    //   72: bipush #76
    //   74: if_icmpeq -> 99
    //   77: iload #6
    //   79: iload_2
    //   80: ifne -> 109
    //   83: bipush #91
    //   85: if_icmpeq -> 99
    //   88: iload #6
    //   90: bipush #84
    //   92: iload_2
    //   93: ifne -> 125
    //   96: if_icmpne -> 111
    //   99: aload_3
    //   100: iload #5
    //   102: aload_1
    //   103: invokevirtual visitClassBound : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   106: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   109: istore #5
    //   111: aload_3
    //   112: iload #5
    //   114: iinc #5, 1
    //   117: invokevirtual charAt : (I)C
    //   120: dup
    //   121: istore #6
    //   123: bipush #58
    //   125: if_icmpne -> 162
    //   128: aload_3
    //   129: iload #5
    //   131: aload_1
    //   132: invokevirtual visitInterfaceBound : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   135: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   138: istore #5
    //   140: iload_2
    //   141: ifne -> 70
    //   144: iload_2
    //   145: ifeq -> 111
    //   148: getstatic org/objectweb/asm/ClassVisitor.b : Z
    //   151: ifeq -> 158
    //   154: iconst_0
    //   155: goto -> 159
    //   158: iconst_1
    //   159: putstatic org/objectweb/asm/ClassVisitor.b : Z
    //   162: iload #6
    //   164: bipush #62
    //   166: if_icmpne -> 32
    //   169: goto -> 175
    //   172: iconst_0
    //   173: istore #5
    //   175: aload_3
    //   176: iload #5
    //   178: invokevirtual charAt : (I)C
    //   181: iload_2
    //   182: ifne -> 273
    //   185: bipush #40
    //   187: if_icmpne -> 263
    //   190: iinc #5, 1
    //   193: aload_3
    //   194: iload #5
    //   196: invokevirtual charAt : (I)C
    //   199: bipush #41
    //   201: if_icmpeq -> 224
    //   204: aload_3
    //   205: iload #5
    //   207: aload_1
    //   208: invokevirtual visitParameterType : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   211: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   214: istore #5
    //   216: iload_2
    //   217: ifne -> 238
    //   220: iload_2
    //   221: ifeq -> 193
    //   224: aload_3
    //   225: iload #5
    //   227: iconst_1
    //   228: iadd
    //   229: aload_1
    //   230: invokevirtual visitReturnType : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   233: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   236: istore #5
    //   238: iload #5
    //   240: iload #4
    //   242: if_icmpge -> 298
    //   245: aload_3
    //   246: iload #5
    //   248: iconst_1
    //   249: iadd
    //   250: aload_1
    //   251: invokevirtual visitExceptionType : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   254: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   257: istore #5
    //   259: iload_2
    //   260: ifeq -> 238
    //   263: aload_3
    //   264: iload #5
    //   266: aload_1
    //   267: invokevirtual visitSuperclass : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   270: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   273: istore #5
    //   275: iload #5
    //   277: iload #4
    //   279: if_icmpge -> 298
    //   282: aload_3
    //   283: iload #5
    //   285: aload_1
    //   286: invokevirtual visitInterface : ()Lorg/objectweb/asm/signature/SignatureVisitor;
    //   289: invokestatic a : (Ljava/lang/String;ILorg/objectweb/asm/signature/SignatureVisitor;)I
    //   292: istore #5
    //   294: iload_2
    //   295: ifeq -> 275
    //   298: return
  }
  
  public void acceptType(SignatureVisitor paramSignatureVisitor) {
    a(this.a, 0, paramSignatureVisitor);
  }
  
  private static int a(String paramString, int paramInt, SignatureVisitor paramSignatureVisitor) {
    char c;
    boolean bool = SignatureVisitor.d;
    if (!bool) {
      int j;
      switch (c = paramString.charAt(paramInt++)) {
        case 'B':
        case 'C':
        case 'D':
        case 'F':
        case 'I':
        case 'J':
        case 'S':
        case 'V':
        case 'Z':
          paramSignatureVisitor.visitBaseType(c);
          return paramInt;
        case '[':
          return a(paramString, paramInt, paramSignatureVisitor.visitArrayType());
        case 'T':
          j = paramString.indexOf(';', paramInt);
          paramSignatureVisitor.visitTypeVariable(paramString.substring(paramInt, j));
          return j + 1;
      } 
    } 
    int i = paramInt;
    boolean bool1 = false;
    boolean bool2 = false;
    while (true) {
      String str;
      switch (c = paramString.charAt(paramInt++)) {
        case '.':
        case ';':
        
        case '<':
          str = paramString.substring(i, paramInt - 1);
      } 
    } 
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\signature\SignatureReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */