package org.objectweb.asm;

public abstract class ClassVisitor {
  protected final int api;
  
  protected ClassVisitor cv;
  
  public static boolean b;
  
  public ClassVisitor(int paramInt) {
    this(paramInt, null);
  }
  
  public ClassVisitor(int paramInt, ClassVisitor paramClassVisitor) {
    if (i == 0) {
      try {
        if (paramInt != 262144)
          try {
            if (paramInt != 327680)
              throw new IllegalArgumentException(); 
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          }  
      } catch (IllegalArgumentException illegalArgumentException) {
        throw null;
      } 
      this.api = paramInt;
      this.cv = paramClassVisitor;
    } 
  }
  
  public void visit(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visit(paramInt1, paramInt2, paramString1, paramString2, paramString3, paramArrayOfString);
  }
  
  public void visitSource(String paramString1, String paramString2) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visitSource(paramString1, paramString2);
  }
  
  public void visitOuterClass(String paramString1, String paramString2, String paramString3) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visitOuterClass(paramString1, paramString2, paramString3);
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.cv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.cv.visitAnnotation(paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.cv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.cv.visitTypeAnnotation(paramInt, paramTypePath, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visitAttribute(paramAttribute);
  }
  
  public void visitInnerClass(String paramString1, String paramString2, String paramString3, int paramInt) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visitInnerClass(paramString1, paramString2, paramString3, paramInt);
  }
  
  public FieldVisitor visitField(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.cv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.cv.visitField(paramInt, paramString1, paramString2, paramString3, paramObject);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public MethodVisitor visitMethod(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.cv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.cv.visitMethod(paramInt, paramString1, paramString2, paramString3, paramArrayOfString);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitEnd() {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.cv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.cv.visitEnd();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\ClassVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */