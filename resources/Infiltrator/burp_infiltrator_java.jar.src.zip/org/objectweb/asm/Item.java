package org.objectweb.asm;

final class Item {
  int a;
  
  int b;
  
  int c;
  
  long d;
  
  String g;
  
  String h;
  
  String i;
  
  int j;
  
  Item k;
  
  Item() {}
  
  Item(int paramInt) {
    this.a = paramInt;
  }
  
  Item(int paramInt, Item paramItem) {
    this.a = paramInt;
    this.b = paramItem.b;
    this.c = paramItem.c;
    this.d = paramItem.d;
    this.g = paramItem.g;
    this.h = paramItem.h;
    this.i = paramItem.i;
    this.j = paramItem.j;
  }
  
  void a(int paramInt) {
    this.b = 3;
    this.c = paramInt;
    this.j = Integer.MAX_VALUE & this.b + paramInt;
  }
  
  void a(long paramLong) {
    this.b = 5;
    this.d = paramLong;
    this.j = Integer.MAX_VALUE & this.b + (int)paramLong;
  }
  
  void a(float paramFloat) {
    this.b = 4;
    this.c = Float.floatToRawIntBits(paramFloat);
    this.j = Integer.MAX_VALUE & this.b + (int)paramFloat;
  }
  
  void a(double paramDouble) {
    this.b = 6;
    this.d = Double.doubleToRawLongBits(paramDouble);
    this.j = Integer.MAX_VALUE & this.b + (int)paramDouble;
  }
  
  void a(int paramInt, String paramString1, String paramString2, String paramString3) {
    this.b = paramInt;
    this.g = paramString1;
    int i = MethodVisitor.b;
    this.h = paramString2;
    this.i = paramString3;
    if (i == 0) {
      switch (paramInt) {
        case 7:
          this.c = 0;
        case 1:
        case 8:
        case 16:
        case 30:
          this.j = Integer.MAX_VALUE & paramInt + paramString1.hashCode();
          return;
        case 12:
          this.j = Integer.MAX_VALUE & paramInt + paramString1.hashCode() * paramString2.hashCode();
          return;
      } 
      this.j = Integer.MAX_VALUE & paramInt + paramString1.hashCode() * paramString2.hashCode() * paramString3.hashCode();
    } 
  }
  
  void a(String paramString1, String paramString2, int paramInt) {
    this.b = 18;
    this.d = paramInt;
    this.g = paramString1;
    this.h = paramString2;
    this.j = Integer.MAX_VALUE & 18 + paramInt * this.g.hashCode() * this.h.hashCode();
  }
  
  void a(int paramInt1, int paramInt2) {
    this.b = 33;
    this.c = paramInt1;
    this.j = paramInt2;
  }
  
  boolean a(Item paramItem) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield b : I
    //   8: iload_2
    //   9: ifne -> 361
    //   12: tableswitch default -> 350, 1 -> 156, 2 -> 350, 3 -> 190, 4 -> 190, 5 -> 168, 6 -> 168, 7 -> 156, 8 -> 156, 9 -> 350, 10 -> 350, 11 -> 350, 12 -> 250, 13 -> 350, 14 -> 350, 15 -> 350, 16 -> 156, 17 -> 350, 18 -> 292, 19 -> 350, 20 -> 350, 21 -> 350, 22 -> 350, 23 -> 350, 24 -> 350, 25 -> 350, 26 -> 350, 27 -> 350, 28 -> 350, 29 -> 350, 30 -> 156, 31 -> 211, 32 -> 168
    //   156: aload_1
    //   157: getfield g : Ljava/lang/String;
    //   160: aload_0
    //   161: getfield g : Ljava/lang/String;
    //   164: invokevirtual equals : (Ljava/lang/Object;)Z
    //   167: ireturn
    //   168: aload_1
    //   169: getfield d : J
    //   172: aload_0
    //   173: getfield d : J
    //   176: lcmp
    //   177: iload_2
    //   178: ifne -> 185
    //   181: ifne -> 188
    //   184: iconst_1
    //   185: goto -> 189
    //   188: iconst_0
    //   189: ireturn
    //   190: aload_1
    //   191: getfield c : I
    //   194: iload_2
    //   195: ifne -> 206
    //   198: aload_0
    //   199: getfield c : I
    //   202: if_icmpne -> 209
    //   205: iconst_1
    //   206: goto -> 210
    //   209: iconst_0
    //   210: ireturn
    //   211: aload_1
    //   212: getfield c : I
    //   215: iload_2
    //   216: ifne -> 237
    //   219: aload_0
    //   220: getfield c : I
    //   223: if_icmpne -> 248
    //   226: aload_1
    //   227: getfield g : Ljava/lang/String;
    //   230: aload_0
    //   231: getfield g : Ljava/lang/String;
    //   234: invokevirtual equals : (Ljava/lang/Object;)Z
    //   237: iload_2
    //   238: ifne -> 245
    //   241: ifeq -> 248
    //   244: iconst_1
    //   245: goto -> 249
    //   248: iconst_0
    //   249: ireturn
    //   250: aload_1
    //   251: getfield g : Ljava/lang/String;
    //   254: aload_0
    //   255: getfield g : Ljava/lang/String;
    //   258: invokevirtual equals : (Ljava/lang/Object;)Z
    //   261: iload_2
    //   262: ifne -> 279
    //   265: ifeq -> 290
    //   268: aload_1
    //   269: getfield h : Ljava/lang/String;
    //   272: aload_0
    //   273: getfield h : Ljava/lang/String;
    //   276: invokevirtual equals : (Ljava/lang/Object;)Z
    //   279: iload_2
    //   280: ifne -> 287
    //   283: ifeq -> 290
    //   286: iconst_1
    //   287: goto -> 291
    //   290: iconst_0
    //   291: ireturn
    //   292: aload_1
    //   293: getfield d : J
    //   296: aload_0
    //   297: getfield d : J
    //   300: lcmp
    //   301: iload_2
    //   302: ifne -> 319
    //   305: ifne -> 348
    //   308: aload_1
    //   309: getfield g : Ljava/lang/String;
    //   312: aload_0
    //   313: getfield g : Ljava/lang/String;
    //   316: invokevirtual equals : (Ljava/lang/Object;)Z
    //   319: iload_2
    //   320: ifne -> 337
    //   323: ifeq -> 348
    //   326: aload_1
    //   327: getfield h : Ljava/lang/String;
    //   330: aload_0
    //   331: getfield h : Ljava/lang/String;
    //   334: invokevirtual equals : (Ljava/lang/Object;)Z
    //   337: iload_2
    //   338: ifne -> 345
    //   341: ifeq -> 348
    //   344: iconst_1
    //   345: goto -> 349
    //   348: iconst_0
    //   349: ireturn
    //   350: aload_1
    //   351: getfield g : Ljava/lang/String;
    //   354: aload_0
    //   355: getfield g : Ljava/lang/String;
    //   358: invokevirtual equals : (Ljava/lang/Object;)Z
    //   361: iload_2
    //   362: ifne -> 379
    //   365: ifeq -> 408
    //   368: aload_1
    //   369: getfield h : Ljava/lang/String;
    //   372: aload_0
    //   373: getfield h : Ljava/lang/String;
    //   376: invokevirtual equals : (Ljava/lang/Object;)Z
    //   379: iload_2
    //   380: ifne -> 397
    //   383: ifeq -> 408
    //   386: aload_1
    //   387: getfield i : Ljava/lang/String;
    //   390: aload_0
    //   391: getfield i : Ljava/lang/String;
    //   394: invokevirtual equals : (Ljava/lang/Object;)Z
    //   397: iload_2
    //   398: ifne -> 405
    //   401: ifeq -> 408
    //   404: iconst_1
    //   405: goto -> 409
    //   408: iconst_0
    //   409: ireturn
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Item.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */