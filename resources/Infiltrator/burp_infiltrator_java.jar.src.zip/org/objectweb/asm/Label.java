package org.objectweb.asm;

public class Label {
  public Object info;
  
  int a;
  
  int b;
  
  int c;
  
  private int d;
  
  private int[] e;
  
  int f;
  
  int g;
  
  Frame h;
  
  Label i;
  
  Edge j;
  
  Label k;
  
  private static final String l;
  
  public int getOffset() {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if ((this.a & 0x2) == 0)
            throw new IllegalStateException(l); 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        }  
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    return this.c;
  }
  
  void a(MethodWriter paramMethodWriter, ByteVector paramByteVector, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: aload_0
    //   6: getfield a : I
    //   9: iconst_2
    //   10: iand
    //   11: iload #5
    //   13: ifne -> 88
    //   16: ifne -> 82
    //   19: goto -> 23
    //   22: athrow
    //   23: iload #4
    //   25: ifeq -> 58
    //   28: goto -> 32
    //   31: athrow
    //   32: aload_0
    //   33: iconst_m1
    //   34: iload_3
    //   35: isub
    //   36: aload_2
    //   37: getfield b : I
    //   40: invokespecial a : (II)V
    //   43: aload_2
    //   44: iconst_m1
    //   45: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   48: pop
    //   49: iload #5
    //   51: ifeq -> 126
    //   54: goto -> 58
    //   57: athrow
    //   58: aload_0
    //   59: iload_3
    //   60: aload_2
    //   61: getfield b : I
    //   64: invokespecial a : (II)V
    //   67: aload_2
    //   68: iconst_m1
    //   69: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   72: pop
    //   73: iload #5
    //   75: ifeq -> 126
    //   78: goto -> 82
    //   81: athrow
    //   82: iload #4
    //   84: goto -> 88
    //   87: athrow
    //   88: ifeq -> 111
    //   91: aload_2
    //   92: aload_0
    //   93: getfield c : I
    //   96: iload_3
    //   97: isub
    //   98: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   101: pop
    //   102: iload #5
    //   104: ifeq -> 126
    //   107: goto -> 111
    //   110: athrow
    //   111: aload_2
    //   112: aload_0
    //   113: getfield c : I
    //   116: iload_3
    //   117: isub
    //   118: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   121: pop
    //   122: goto -> 126
    //   125: athrow
    //   126: return
    // Exception table:
    //   from	to	target	type
    //   5	19	22	java/lang/IllegalStateException
    //   16	28	31	java/lang/IllegalStateException
    //   23	54	57	java/lang/IllegalStateException
    //   32	78	81	java/lang/IllegalStateException
    //   58	84	87	java/lang/IllegalStateException
    //   88	107	110	java/lang/IllegalStateException
    //   91	122	125	java/lang/IllegalStateException
  }
  
  private void a(int paramInt1, int paramInt2) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.e == null)
            this.e = new int[6]; 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        }  
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    try {
      if (i == 0) {
        if (this.d >= this.e.length) {
          int[] arrayOfInt = new int[this.e.length + 6];
          System.arraycopy(this.e, 0, arrayOfInt, 0, this.e.length);
          this.e = arrayOfInt;
        } 
        this.e[this.d++] = paramInt1;
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.e[this.d++] = paramInt2;
  }
  
  boolean a(MethodWriter paramMethodWriter, int paramInt, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: aload_0
    //   7: dup
    //   8: getfield a : I
    //   11: iconst_2
    //   12: ior
    //   13: putfield a : I
    //   16: istore #4
    //   18: aload_0
    //   19: iload_2
    //   20: putfield c : I
    //   23: iconst_0
    //   24: istore #6
    //   26: iload #6
    //   28: aload_0
    //   29: getfield d : I
    //   32: if_icmpge -> 287
    //   35: aload_0
    //   36: getfield e : [I
    //   39: iload #6
    //   41: iinc #6, 1
    //   44: iaload
    //   45: istore #7
    //   47: aload_0
    //   48: getfield e : [I
    //   51: iload #6
    //   53: iinc #6, 1
    //   56: iaload
    //   57: istore #8
    //   59: iload #7
    //   61: iload #4
    //   63: ifne -> 289
    //   66: iload #4
    //   68: ifne -> 234
    //   71: goto -> 75
    //   74: athrow
    //   75: iflt -> 224
    //   78: goto -> 82
    //   81: athrow
    //   82: iload_2
    //   83: iload #7
    //   85: isub
    //   86: istore #9
    //   88: iload #9
    //   90: sipush #-32768
    //   93: iload #4
    //   95: ifne -> 139
    //   98: if_icmplt -> 126
    //   101: goto -> 105
    //   104: athrow
    //   105: iload #9
    //   107: sipush #32767
    //   110: iload #4
    //   112: ifne -> 139
    //   115: goto -> 119
    //   118: athrow
    //   119: if_icmple -> 199
    //   122: goto -> 126
    //   125: athrow
    //   126: aload_3
    //   127: iload #8
    //   129: iconst_1
    //   130: isub
    //   131: baload
    //   132: sipush #255
    //   135: goto -> 139
    //   138: athrow
    //   139: iand
    //   140: istore #10
    //   142: iload #4
    //   144: ifne -> 175
    //   147: iload #10
    //   149: sipush #168
    //   152: if_icmpgt -> 180
    //   155: goto -> 159
    //   158: athrow
    //   159: aload_3
    //   160: iload #8
    //   162: iconst_1
    //   163: isub
    //   164: iload #10
    //   166: bipush #49
    //   168: iadd
    //   169: i2b
    //   170: bastore
    //   171: goto -> 175
    //   174: athrow
    //   175: iload #4
    //   177: ifeq -> 196
    //   180: aload_3
    //   181: iload #8
    //   183: iconst_1
    //   184: isub
    //   185: iload #10
    //   187: bipush #20
    //   189: iadd
    //   190: i2b
    //   191: bastore
    //   192: goto -> 196
    //   195: athrow
    //   196: iconst_1
    //   197: istore #5
    //   199: aload_3
    //   200: iload #8
    //   202: iinc #8, 1
    //   205: iload #9
    //   207: bipush #8
    //   209: iushr
    //   210: i2b
    //   211: bastore
    //   212: aload_3
    //   213: iload #8
    //   215: iload #9
    //   217: i2b
    //   218: bastore
    //   219: iload #4
    //   221: ifeq -> 282
    //   224: iload_2
    //   225: iload #7
    //   227: iadd
    //   228: iconst_1
    //   229: iadd
    //   230: goto -> 234
    //   233: athrow
    //   234: istore #9
    //   236: aload_3
    //   237: iload #8
    //   239: iinc #8, 1
    //   242: iload #9
    //   244: bipush #24
    //   246: iushr
    //   247: i2b
    //   248: bastore
    //   249: aload_3
    //   250: iload #8
    //   252: iinc #8, 1
    //   255: iload #9
    //   257: bipush #16
    //   259: iushr
    //   260: i2b
    //   261: bastore
    //   262: aload_3
    //   263: iload #8
    //   265: iinc #8, 1
    //   268: iload #9
    //   270: bipush #8
    //   272: iushr
    //   273: i2b
    //   274: bastore
    //   275: aload_3
    //   276: iload #8
    //   278: iload #9
    //   280: i2b
    //   281: bastore
    //   282: iload #4
    //   284: ifeq -> 26
    //   287: iload #5
    //   289: ireturn
    // Exception table:
    //   from	to	target	type
    //   59	71	74	java/lang/IllegalStateException
    //   66	78	81	java/lang/IllegalStateException
    //   88	101	104	java/lang/IllegalStateException
    //   98	115	118	java/lang/IllegalStateException
    //   105	122	125	java/lang/IllegalStateException
    //   119	135	138	java/lang/IllegalStateException
    //   142	155	158	java/lang/IllegalStateException
    //   147	171	174	java/lang/IllegalStateException
    //   175	192	195	java/lang/IllegalStateException
    //   199	230	233	java/lang/IllegalStateException
  }
  
  Label a() {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.h == null) {
          
          } else {
          
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        return this.h.b;
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
  }
  
  boolean a(long paramLong) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if ((this.a & 0x400) != 0)
            try {
              if (i == 0)
                if ((this.e[(int)(paramLong >>> 32L)] & (int)paramLong) != 0) {
                
                } else {
                  return false;
                }  
            } catch (IllegalStateException illegalStateException) {
              throw null;
            }  
        } catch (IllegalStateException illegalStateException) {
          throw null;
        }  
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    return false;
  }
  
  boolean a(Label paramLabel) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield a : I
    //   8: sipush #1024
    //   11: iand
    //   12: iload_2
    //   13: ifne -> 47
    //   16: ifeq -> 46
    //   19: goto -> 23
    //   22: athrow
    //   23: aload_1
    //   24: getfield a : I
    //   27: sipush #1024
    //   30: iand
    //   31: iload_2
    //   32: ifne -> 49
    //   35: goto -> 39
    //   38: athrow
    //   39: ifne -> 48
    //   42: goto -> 46
    //   45: athrow
    //   46: iconst_0
    //   47: ireturn
    //   48: iconst_0
    //   49: istore_3
    //   50: iload_3
    //   51: aload_0
    //   52: getfield e : [I
    //   55: arraylength
    //   56: if_icmpge -> 100
    //   59: aload_0
    //   60: getfield e : [I
    //   63: iload_3
    //   64: iaload
    //   65: aload_1
    //   66: getfield e : [I
    //   69: iload_3
    //   70: iaload
    //   71: iand
    //   72: iload_2
    //   73: ifne -> 101
    //   76: iload_2
    //   77: ifne -> 92
    //   80: goto -> 84
    //   83: athrow
    //   84: ifeq -> 93
    //   87: goto -> 91
    //   90: athrow
    //   91: iconst_1
    //   92: ireturn
    //   93: iinc #3, 1
    //   96: iload_2
    //   97: ifeq -> 50
    //   100: iconst_0
    //   101: ireturn
    // Exception table:
    //   from	to	target	type
    //   4	19	22	java/lang/IllegalStateException
    //   16	35	38	java/lang/IllegalStateException
    //   23	42	45	java/lang/IllegalStateException
    //   59	80	83	java/lang/IllegalStateException
    //   76	87	90	java/lang/IllegalStateException
  }
  
  void a(long paramLong, int paramInt) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if ((this.a & 0x400) == 0) {
            this.a |= 0x400;
            this.e = new int[paramInt / 32 + 1];
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        }  
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.e[(int)(paramLong >>> 32L)] = this.e[(int)(paramLong >>> 32L)] | (int)paramLong;
  }
  
  void b(Label paramLabel, long paramLong, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: aload_0
    //   6: astore #6
    //   8: aload #6
    //   10: ifnull -> 335
    //   13: aload #6
    //   15: astore #7
    //   17: aload #7
    //   19: getfield k : Lorg/objectweb/asm/Label;
    //   22: astore #6
    //   24: aload #7
    //   26: aconst_null
    //   27: putfield k : Lorg/objectweb/asm/Label;
    //   30: aload_1
    //   31: iload #5
    //   33: ifne -> 186
    //   36: ifnull -> 180
    //   39: goto -> 43
    //   42: athrow
    //   43: aload #7
    //   45: getfield a : I
    //   48: sipush #2048
    //   51: iand
    //   52: iload #5
    //   54: ifne -> 102
    //   57: goto -> 61
    //   60: athrow
    //   61: ifeq -> 71
    //   64: goto -> 68
    //   67: athrow
    //   68: goto -> 8
    //   71: aload #7
    //   73: dup
    //   74: getfield a : I
    //   77: sipush #2048
    //   80: ior
    //   81: putfield a : I
    //   84: aload #7
    //   86: iload #5
    //   88: ifne -> 215
    //   91: getfield a : I
    //   94: sipush #256
    //   97: iand
    //   98: goto -> 102
    //   101: athrow
    //   102: ifeq -> 213
    //   105: aload #7
    //   107: iload #5
    //   109: ifne -> 215
    //   112: goto -> 116
    //   115: athrow
    //   116: aload_1
    //   117: invokevirtual a : (Lorg/objectweb/asm/Label;)Z
    //   120: ifne -> 213
    //   123: goto -> 127
    //   126: athrow
    //   127: new org/objectweb/asm/Edge
    //   130: dup
    //   131: invokespecial <init> : ()V
    //   134: astore #8
    //   136: aload #8
    //   138: aload #7
    //   140: getfield f : I
    //   143: putfield a : I
    //   146: aload #8
    //   148: aload_1
    //   149: getfield j : Lorg/objectweb/asm/Edge;
    //   152: getfield b : Lorg/objectweb/asm/Label;
    //   155: putfield b : Lorg/objectweb/asm/Label;
    //   158: aload #8
    //   160: aload #7
    //   162: getfield j : Lorg/objectweb/asm/Edge;
    //   165: putfield c : Lorg/objectweb/asm/Edge;
    //   168: aload #7
    //   170: aload #8
    //   172: putfield j : Lorg/objectweb/asm/Edge;
    //   175: iload #5
    //   177: ifeq -> 213
    //   180: aload #7
    //   182: goto -> 186
    //   185: athrow
    //   186: lload_2
    //   187: iload #5
    //   189: ifne -> 208
    //   192: invokevirtual a : (J)Z
    //   195: goto -> 199
    //   198: athrow
    //   199: ifeq -> 205
    //   202: goto -> 8
    //   205: aload #7
    //   207: lload_2
    //   208: iload #4
    //   210: invokevirtual a : (JI)V
    //   213: aload #7
    //   215: getfield j : Lorg/objectweb/asm/Edge;
    //   218: astore #8
    //   220: aload #8
    //   222: ifnull -> 330
    //   225: aload #7
    //   227: iload #5
    //   229: ifne -> 298
    //   232: getfield a : I
    //   235: sipush #128
    //   238: iand
    //   239: iload #5
    //   241: ifne -> 199
    //   244: goto -> 248
    //   247: athrow
    //   248: ifeq -> 277
    //   251: aload #8
    //   253: iload #5
    //   255: ifne -> 323
    //   258: goto -> 262
    //   261: athrow
    //   262: aload #7
    //   264: getfield j : Lorg/objectweb/asm/Edge;
    //   267: getfield c : Lorg/objectweb/asm/Edge;
    //   270: if_acmpeq -> 318
    //   273: goto -> 277
    //   276: athrow
    //   277: aload #8
    //   279: iload #5
    //   281: ifne -> 323
    //   284: goto -> 288
    //   287: athrow
    //   288: getfield b : Lorg/objectweb/asm/Label;
    //   291: getfield k : Lorg/objectweb/asm/Label;
    //   294: goto -> 298
    //   297: athrow
    //   298: ifnonnull -> 318
    //   301: aload #8
    //   303: getfield b : Lorg/objectweb/asm/Label;
    //   306: aload #6
    //   308: putfield k : Lorg/objectweb/asm/Label;
    //   311: aload #8
    //   313: getfield b : Lorg/objectweb/asm/Label;
    //   316: astore #6
    //   318: aload #8
    //   320: getfield c : Lorg/objectweb/asm/Edge;
    //   323: astore #8
    //   325: iload #5
    //   327: ifeq -> 220
    //   330: iload #5
    //   332: ifeq -> 8
    //   335: return
    // Exception table:
    //   from	to	target	type
    //   24	39	42	java/lang/IllegalStateException
    //   36	57	60	java/lang/IllegalStateException
    //   43	64	67	java/lang/IllegalStateException
    //   71	98	101	java/lang/IllegalStateException
    //   102	112	115	java/lang/IllegalStateException
    //   105	123	126	java/lang/IllegalStateException
    //   136	182	185	java/lang/IllegalStateException
    //   186	195	198	java/lang/IllegalStateException
    //   225	244	247	java/lang/IllegalStateException
    //   248	258	261	java/lang/IllegalStateException
    //   251	273	276	java/lang/IllegalStateException
    //   262	284	287	java/lang/IllegalStateException
    //   277	294	297	java/lang/IllegalStateException
  }
  
  public String toString() {
    return "L" + System.identityHashCode(this);
  }
  
  static {
    // Byte code:
    //   0: ldc '`mù£¸¿;g|ù»¸ 2rfè¦÷¾}inïïö¿)!mùªöð/d|ó£îµ9!vù»'
    //   2: jsr -> 11
    //   5: putstatic org/objectweb/asm/Label.l : Ljava/lang/String;
    //   8: goto -> 144
    //   11: astore_0
    //   12: invokevirtual toCharArray : ()[C
    //   15: dup
    //   16: arraylength
    //   17: swap
    //   18: iconst_0
    //   19: istore_1
    //   20: swap
    //   21: dup_x1
    //   22: iconst_1
    //   23: if_icmpgt -> 123
    //   26: dup
    //   27: iload_1
    //   28: dup2
    //   29: caload
    //   30: iload_1
    //   31: bipush #7
    //   33: irem
    //   34: tableswitch default -> 104, 0 -> 72, 1 -> 77, 2 -> 81, 3 -> 86, 4 -> 92, 5 -> 98
    //   72: bipush #93
    //   74: goto -> 107
    //   77: iconst_1
    //   78: goto -> 107
    //   81: bipush #15
    //   83: goto -> 107
    //   86: sipush #156
    //   89: goto -> 107
    //   92: sipush #207
    //   95: goto -> 107
    //   98: sipush #152
    //   101: goto -> 107
    //   104: sipush #208
    //   107: ixor
    //   108: i2c
    //   109: castore
    //   110: iinc #1, 1
    //   113: swap
    //   114: dup_x1
    //   115: ifne -> 123
    //   118: dup2
    //   119: swap
    //   120: goto -> 28
    //   123: swap
    //   124: dup_x1
    //   125: iload_1
    //   126: if_icmpgt -> 26
    //   129: new java/lang/String
    //   132: dup_x1
    //   133: swap
    //   134: invokespecial <init> : ([C)V
    //   137: invokevirtual intern : ()Ljava/lang/String;
    //   140: swap
    //   141: pop
    //   142: ret #0
    //   144: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Label.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */