package org.objectweb.asm;

final class AnnotationWriter extends AnnotationVisitor {
  private final ClassWriter a;
  
  private int b;
  
  private final boolean c;
  
  private final ByteVector d;
  
  private final ByteVector e;
  
  private final int f;
  
  AnnotationWriter g;
  
  AnnotationWriter h;
  
  private static final String i;
  
  AnnotationWriter(ClassWriter paramClassWriter, boolean paramBoolean, ByteVector paramByteVector1, ByteVector paramByteVector2, int paramInt) {
    super(327680);
    this.a = paramClassWriter;
    this.c = paramBoolean;
    this.d = paramByteVector1;
    this.e = paramByteVector2;
    this.f = paramInt;
  }
  
  public void visit(String paramString, Object paramObject) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: dup
    //   6: getfield b : I
    //   9: iconst_1
    //   10: iadd
    //   11: putfield b : I
    //   14: aload_0
    //   15: getfield c : Z
    //   18: iload_3
    //   19: ifne -> 45
    //   22: ifeq -> 41
    //   25: aload_0
    //   26: getfield d : Lorg/objectweb/asm/ByteVector;
    //   29: aload_0
    //   30: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   33: aload_1
    //   34: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   37: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   40: pop
    //   41: aload_2
    //   42: instanceof java/lang/String
    //   45: iload_3
    //   46: ifne -> 81
    //   49: ifeq -> 77
    //   52: aload_0
    //   53: getfield d : Lorg/objectweb/asm/ByteVector;
    //   56: bipush #115
    //   58: aload_0
    //   59: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   62: aload_2
    //   63: checkcast java/lang/String
    //   66: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   69: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   72: pop
    //   73: iload_3
    //   74: ifeq -> 1014
    //   77: aload_2
    //   78: instanceof java/lang/Byte
    //   81: iload_3
    //   82: ifne -> 123
    //   85: ifeq -> 119
    //   88: aload_0
    //   89: getfield d : Lorg/objectweb/asm/ByteVector;
    //   92: bipush #66
    //   94: aload_0
    //   95: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   98: aload_2
    //   99: checkcast java/lang/Byte
    //   102: invokevirtual byteValue : ()B
    //   105: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   108: getfield a : I
    //   111: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   114: pop
    //   115: iload_3
    //   116: ifeq -> 1014
    //   119: aload_2
    //   120: instanceof java/lang/Boolean
    //   123: iload_3
    //   124: ifne -> 181
    //   127: ifeq -> 177
    //   130: aload_2
    //   131: checkcast java/lang/Boolean
    //   134: invokevirtual booleanValue : ()Z
    //   137: iload_3
    //   138: ifne -> 145
    //   141: ifeq -> 148
    //   144: iconst_1
    //   145: goto -> 149
    //   148: iconst_0
    //   149: istore #4
    //   151: aload_0
    //   152: getfield d : Lorg/objectweb/asm/ByteVector;
    //   155: bipush #90
    //   157: aload_0
    //   158: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   161: iload #4
    //   163: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   166: getfield a : I
    //   169: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   172: pop
    //   173: iload_3
    //   174: ifeq -> 1014
    //   177: aload_2
    //   178: instanceof java/lang/Character
    //   181: iload_3
    //   182: ifne -> 223
    //   185: ifeq -> 219
    //   188: aload_0
    //   189: getfield d : Lorg/objectweb/asm/ByteVector;
    //   192: bipush #67
    //   194: aload_0
    //   195: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   198: aload_2
    //   199: checkcast java/lang/Character
    //   202: invokevirtual charValue : ()C
    //   205: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   208: getfield a : I
    //   211: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   214: pop
    //   215: iload_3
    //   216: ifeq -> 1014
    //   219: aload_2
    //   220: instanceof java/lang/Short
    //   223: iload_3
    //   224: ifne -> 265
    //   227: ifeq -> 261
    //   230: aload_0
    //   231: getfield d : Lorg/objectweb/asm/ByteVector;
    //   234: bipush #83
    //   236: aload_0
    //   237: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   240: aload_2
    //   241: checkcast java/lang/Short
    //   244: invokevirtual shortValue : ()S
    //   247: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   250: getfield a : I
    //   253: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   256: pop
    //   257: iload_3
    //   258: ifeq -> 1014
    //   261: aload_2
    //   262: instanceof org/objectweb/asm/Type
    //   265: iload_3
    //   266: ifne -> 304
    //   269: ifeq -> 300
    //   272: aload_0
    //   273: getfield d : Lorg/objectweb/asm/ByteVector;
    //   276: bipush #99
    //   278: aload_0
    //   279: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   282: aload_2
    //   283: checkcast org/objectweb/asm/Type
    //   286: invokevirtual getDescriptor : ()Ljava/lang/String;
    //   289: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   292: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   295: pop
    //   296: iload_3
    //   297: ifeq -> 1014
    //   300: aload_2
    //   301: instanceof [B
    //   304: iload_3
    //   305: ifne -> 388
    //   308: ifeq -> 384
    //   311: aload_2
    //   312: checkcast [B
    //   315: checkcast [B
    //   318: astore #4
    //   320: aload_0
    //   321: getfield d : Lorg/objectweb/asm/ByteVector;
    //   324: bipush #91
    //   326: aload #4
    //   328: arraylength
    //   329: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   332: pop
    //   333: iconst_0
    //   334: istore #5
    //   336: iload #5
    //   338: aload #4
    //   340: arraylength
    //   341: if_icmpge -> 380
    //   344: aload_0
    //   345: getfield d : Lorg/objectweb/asm/ByteVector;
    //   348: bipush #66
    //   350: aload_0
    //   351: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   354: aload #4
    //   356: iload #5
    //   358: baload
    //   359: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   362: getfield a : I
    //   365: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   368: pop
    //   369: iinc #5, 1
    //   372: iload_3
    //   373: ifne -> 1014
    //   376: iload_3
    //   377: ifeq -> 336
    //   380: iload_3
    //   381: ifeq -> 1014
    //   384: aload_2
    //   385: instanceof [Z
    //   388: iload_3
    //   389: ifne -> 480
    //   392: ifeq -> 476
    //   395: aload_2
    //   396: checkcast [Z
    //   399: checkcast [Z
    //   402: astore #4
    //   404: aload_0
    //   405: getfield d : Lorg/objectweb/asm/ByteVector;
    //   408: bipush #91
    //   410: aload #4
    //   412: arraylength
    //   413: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   416: pop
    //   417: iconst_0
    //   418: istore #5
    //   420: iload #5
    //   422: aload #4
    //   424: arraylength
    //   425: if_icmpge -> 472
    //   428: aload_0
    //   429: getfield d : Lorg/objectweb/asm/ByteVector;
    //   432: bipush #90
    //   434: aload_0
    //   435: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   438: aload #4
    //   440: iload #5
    //   442: baload
    //   443: iload_3
    //   444: ifne -> 451
    //   447: ifeq -> 454
    //   450: iconst_1
    //   451: goto -> 455
    //   454: iconst_0
    //   455: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   458: getfield a : I
    //   461: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   464: pop
    //   465: iinc #5, 1
    //   468: iload_3
    //   469: ifeq -> 420
    //   472: iload_3
    //   473: ifeq -> 1014
    //   476: aload_2
    //   477: instanceof [S
    //   480: iload_3
    //   481: ifne -> 564
    //   484: ifeq -> 560
    //   487: aload_2
    //   488: checkcast [S
    //   491: checkcast [S
    //   494: astore #4
    //   496: aload_0
    //   497: getfield d : Lorg/objectweb/asm/ByteVector;
    //   500: bipush #91
    //   502: aload #4
    //   504: arraylength
    //   505: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   508: pop
    //   509: iconst_0
    //   510: istore #5
    //   512: iload #5
    //   514: aload #4
    //   516: arraylength
    //   517: if_icmpge -> 556
    //   520: aload_0
    //   521: getfield d : Lorg/objectweb/asm/ByteVector;
    //   524: bipush #83
    //   526: aload_0
    //   527: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   530: aload #4
    //   532: iload #5
    //   534: saload
    //   535: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   538: getfield a : I
    //   541: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   544: pop
    //   545: iinc #5, 1
    //   548: iload_3
    //   549: ifne -> 1014
    //   552: iload_3
    //   553: ifeq -> 512
    //   556: iload_3
    //   557: ifeq -> 1014
    //   560: aload_2
    //   561: instanceof [C
    //   564: iload_3
    //   565: ifne -> 648
    //   568: ifeq -> 644
    //   571: aload_2
    //   572: checkcast [C
    //   575: checkcast [C
    //   578: astore #4
    //   580: aload_0
    //   581: getfield d : Lorg/objectweb/asm/ByteVector;
    //   584: bipush #91
    //   586: aload #4
    //   588: arraylength
    //   589: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   592: pop
    //   593: iconst_0
    //   594: istore #5
    //   596: iload #5
    //   598: aload #4
    //   600: arraylength
    //   601: if_icmpge -> 640
    //   604: aload_0
    //   605: getfield d : Lorg/objectweb/asm/ByteVector;
    //   608: bipush #67
    //   610: aload_0
    //   611: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   614: aload #4
    //   616: iload #5
    //   618: caload
    //   619: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   622: getfield a : I
    //   625: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   628: pop
    //   629: iinc #5, 1
    //   632: iload_3
    //   633: ifne -> 1014
    //   636: iload_3
    //   637: ifeq -> 596
    //   640: iload_3
    //   641: ifeq -> 1014
    //   644: aload_2
    //   645: instanceof [I
    //   648: iload_3
    //   649: ifne -> 732
    //   652: ifeq -> 728
    //   655: aload_2
    //   656: checkcast [I
    //   659: checkcast [I
    //   662: astore #4
    //   664: aload_0
    //   665: getfield d : Lorg/objectweb/asm/ByteVector;
    //   668: bipush #91
    //   670: aload #4
    //   672: arraylength
    //   673: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   676: pop
    //   677: iconst_0
    //   678: istore #5
    //   680: iload #5
    //   682: aload #4
    //   684: arraylength
    //   685: if_icmpge -> 724
    //   688: aload_0
    //   689: getfield d : Lorg/objectweb/asm/ByteVector;
    //   692: bipush #73
    //   694: aload_0
    //   695: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   698: aload #4
    //   700: iload #5
    //   702: iaload
    //   703: invokevirtual a : (I)Lorg/objectweb/asm/Item;
    //   706: getfield a : I
    //   709: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   712: pop
    //   713: iinc #5, 1
    //   716: iload_3
    //   717: ifne -> 1014
    //   720: iload_3
    //   721: ifeq -> 680
    //   724: iload_3
    //   725: ifeq -> 1014
    //   728: aload_2
    //   729: instanceof [J
    //   732: iload_3
    //   733: ifne -> 816
    //   736: ifeq -> 812
    //   739: aload_2
    //   740: checkcast [J
    //   743: checkcast [J
    //   746: astore #4
    //   748: aload_0
    //   749: getfield d : Lorg/objectweb/asm/ByteVector;
    //   752: bipush #91
    //   754: aload #4
    //   756: arraylength
    //   757: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   760: pop
    //   761: iconst_0
    //   762: istore #5
    //   764: iload #5
    //   766: aload #4
    //   768: arraylength
    //   769: if_icmpge -> 808
    //   772: aload_0
    //   773: getfield d : Lorg/objectweb/asm/ByteVector;
    //   776: bipush #74
    //   778: aload_0
    //   779: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   782: aload #4
    //   784: iload #5
    //   786: laload
    //   787: invokevirtual a : (J)Lorg/objectweb/asm/Item;
    //   790: getfield a : I
    //   793: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   796: pop
    //   797: iinc #5, 1
    //   800: iload_3
    //   801: ifne -> 1014
    //   804: iload_3
    //   805: ifeq -> 764
    //   808: iload_3
    //   809: ifeq -> 1014
    //   812: aload_2
    //   813: instanceof [F
    //   816: iload_3
    //   817: ifne -> 904
    //   820: ifeq -> 896
    //   823: aload_2
    //   824: checkcast [F
    //   827: checkcast [F
    //   830: astore #4
    //   832: aload_0
    //   833: getfield d : Lorg/objectweb/asm/ByteVector;
    //   836: bipush #91
    //   838: aload #4
    //   840: arraylength
    //   841: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   844: pop
    //   845: iconst_0
    //   846: istore #5
    //   848: iload #5
    //   850: aload #4
    //   852: arraylength
    //   853: if_icmpge -> 892
    //   856: aload_0
    //   857: getfield d : Lorg/objectweb/asm/ByteVector;
    //   860: bipush #70
    //   862: aload_0
    //   863: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   866: aload #4
    //   868: iload #5
    //   870: faload
    //   871: invokevirtual a : (F)Lorg/objectweb/asm/Item;
    //   874: getfield a : I
    //   877: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   880: pop
    //   881: iinc #5, 1
    //   884: iload_3
    //   885: ifne -> 1014
    //   888: iload_3
    //   889: ifeq -> 848
    //   892: iload_3
    //   893: ifeq -> 1014
    //   896: aload_2
    //   897: iload_3
    //   898: ifne -> 908
    //   901: instanceof [D
    //   904: ifeq -> 980
    //   907: aload_2
    //   908: checkcast [D
    //   911: checkcast [D
    //   914: astore #4
    //   916: aload_0
    //   917: getfield d : Lorg/objectweb/asm/ByteVector;
    //   920: bipush #91
    //   922: aload #4
    //   924: arraylength
    //   925: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   928: pop
    //   929: iconst_0
    //   930: istore #5
    //   932: iload #5
    //   934: aload #4
    //   936: arraylength
    //   937: if_icmpge -> 976
    //   940: aload_0
    //   941: getfield d : Lorg/objectweb/asm/ByteVector;
    //   944: bipush #68
    //   946: aload_0
    //   947: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   950: aload #4
    //   952: iload #5
    //   954: daload
    //   955: invokevirtual a : (D)Lorg/objectweb/asm/Item;
    //   958: getfield a : I
    //   961: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   964: pop
    //   965: iinc #5, 1
    //   968: iload_3
    //   969: ifne -> 1014
    //   972: iload_3
    //   973: ifeq -> 932
    //   976: iload_3
    //   977: ifeq -> 1014
    //   980: aload_0
    //   981: getfield a : Lorg/objectweb/asm/ClassWriter;
    //   984: aload_2
    //   985: invokevirtual a : (Ljava/lang/Object;)Lorg/objectweb/asm/Item;
    //   988: astore #4
    //   990: aload_0
    //   991: getfield d : Lorg/objectweb/asm/ByteVector;
    //   994: getstatic org/objectweb/asm/AnnotationWriter.i : Ljava/lang/String;
    //   997: aload #4
    //   999: getfield b : I
    //   1002: invokevirtual charAt : (I)C
    //   1005: aload #4
    //   1007: getfield a : I
    //   1010: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   1013: pop
    //   1014: return
  }
  
  public void visitEnum(String paramString1, String paramString2, String paramString3) {
    int i = MethodVisitor.b;
    this.b++;
    if (i == 0)
      if (this.c)
        this.d.putShort(this.a.newUTF8(paramString1));  
    this.d.b(101, this.a.newUTF8(paramString2)).putShort(this.a.newUTF8(paramString3));
  }
  
  public AnnotationVisitor visitAnnotation(String paramString1, String paramString2) {
    int i = MethodVisitor.b;
    this.b++;
    if (i == 0) {
      if (this.c)
        this.d.putShort(this.a.newUTF8(paramString1)); 
      this.d.b(64, this.a.newUTF8(paramString2)).putShort(0);
    } 
    return new AnnotationWriter(this.a, true, this.d, this.d, this.d.b - 2);
  }
  
  public AnnotationVisitor visitArray(String paramString) {
    int i = MethodVisitor.b;
    this.b++;
    if (i == 0) {
      if (this.c)
        this.d.putShort(this.a.newUTF8(paramString)); 
      this.d.b(91, 0);
    } 
    return new AnnotationWriter(this.a, false, this.d, this.d, this.d.b - 2);
  }
  
  public void visitEnd() {
    int i = MethodVisitor.b;
    if (i == 0)
      if (this.e != null) {
      
      } else {
        return;
      }  
    byte[] arrayOfByte = this.e.a;
    arrayOfByte[this.f] = (byte)(this.b >>> 8);
    arrayOfByte[this.f + 1] = (byte)this.b;
  }
  
  int a() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   5: aload_0
    //   6: astore_3
    //   7: istore_1
    //   8: aload_3
    //   9: ifnull -> 35
    //   12: iload_2
    //   13: aload_3
    //   14: getfield d : Lorg/objectweb/asm/ByteVector;
    //   17: getfield b : I
    //   20: iadd
    //   21: iload_1
    //   22: ifne -> 36
    //   25: istore_2
    //   26: aload_3
    //   27: getfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   30: astore_3
    //   31: iload_1
    //   32: ifeq -> 8
    //   35: iload_2
    //   36: ireturn
  }
  
  void a(ByteVector paramByteVector) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: iconst_2
    //   3: istore #4
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: aload_0
    //   9: astore #5
    //   11: istore_2
    //   12: aconst_null
    //   13: astore #6
    //   15: aload #5
    //   17: ifnull -> 67
    //   20: iinc #3, 1
    //   23: iload #4
    //   25: aload #5
    //   27: getfield d : Lorg/objectweb/asm/ByteVector;
    //   30: getfield b : I
    //   33: iadd
    //   34: istore #4
    //   36: aload #5
    //   38: invokevirtual visitEnd : ()V
    //   41: aload #5
    //   43: aload #6
    //   45: putfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   48: aload #5
    //   50: astore #6
    //   52: aload #5
    //   54: getfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   57: astore #5
    //   59: iload_2
    //   60: ifne -> 80
    //   63: iload_2
    //   64: ifeq -> 15
    //   67: aload_1
    //   68: iload #4
    //   70: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   73: pop
    //   74: aload_1
    //   75: iload_3
    //   76: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   79: pop
    //   80: aload #6
    //   82: astore #5
    //   84: aload #5
    //   86: ifnull -> 122
    //   89: aload_1
    //   90: aload #5
    //   92: getfield d : Lorg/objectweb/asm/ByteVector;
    //   95: getfield a : [B
    //   98: iconst_0
    //   99: aload #5
    //   101: getfield d : Lorg/objectweb/asm/ByteVector;
    //   104: getfield b : I
    //   107: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   110: pop
    //   111: aload #5
    //   113: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   116: astore #5
    //   118: iload_2
    //   119: ifeq -> 84
    //   122: return
  }
  
  static void a(AnnotationWriter[] paramArrayOfAnnotationWriter, int paramInt, ByteVector paramByteVector) {
    // Byte code:
    //   0: iconst_1
    //   1: iconst_2
    //   2: aload_0
    //   3: arraylength
    //   4: iload_1
    //   5: isub
    //   6: imul
    //   7: iadd
    //   8: istore #4
    //   10: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   13: iload_1
    //   14: istore #5
    //   16: istore_3
    //   17: iload #5
    //   19: aload_0
    //   20: arraylength
    //   21: if_icmpge -> 62
    //   24: iload #4
    //   26: aload_0
    //   27: iload_3
    //   28: ifne -> 82
    //   31: iload #5
    //   33: aaload
    //   34: iload_3
    //   35: ifne -> 49
    //   38: ifnonnull -> 45
    //   41: iconst_0
    //   42: goto -> 52
    //   45: aload_0
    //   46: iload #5
    //   48: aaload
    //   49: invokevirtual a : ()I
    //   52: iadd
    //   53: istore #4
    //   55: iinc #5, 1
    //   58: iload_3
    //   59: ifeq -> 17
    //   62: aload_2
    //   63: iload #4
    //   65: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   68: aload_0
    //   69: arraylength
    //   70: iload_1
    //   71: isub
    //   72: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   75: pop
    //   76: iload_1
    //   77: istore #5
    //   79: iload #5
    //   81: aload_0
    //   82: arraylength
    //   83: if_icmpge -> 197
    //   86: aload_0
    //   87: iload #5
    //   89: aaload
    //   90: astore #6
    //   92: aconst_null
    //   93: astore #7
    //   95: iconst_0
    //   96: istore #8
    //   98: aload #6
    //   100: ifnull -> 137
    //   103: iinc #8, 1
    //   106: aload #6
    //   108: invokevirtual visitEnd : ()V
    //   111: aload #6
    //   113: aload #7
    //   115: putfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   118: aload #6
    //   120: astore #7
    //   122: aload #6
    //   124: getfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   127: astore #6
    //   129: iload_3
    //   130: ifne -> 144
    //   133: iload_3
    //   134: ifeq -> 98
    //   137: aload_2
    //   138: iload #8
    //   140: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   143: pop
    //   144: aload #7
    //   146: astore #6
    //   148: aload #6
    //   150: ifnull -> 190
    //   153: aload_2
    //   154: aload #6
    //   156: getfield d : Lorg/objectweb/asm/ByteVector;
    //   159: getfield a : [B
    //   162: iconst_0
    //   163: aload #6
    //   165: getfield d : Lorg/objectweb/asm/ByteVector;
    //   168: getfield b : I
    //   171: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   174: pop
    //   175: aload #6
    //   177: getfield h : Lorg/objectweb/asm/AnnotationWriter;
    //   180: astore #6
    //   182: iload_3
    //   183: ifne -> 193
    //   186: iload_3
    //   187: ifeq -> 148
    //   190: iinc #5, 1
    //   193: iload_3
    //   194: ifeq -> 79
    //   197: return
  }
  
  static void a(int paramInt, TypePath paramTypePath, ByteVector paramByteVector) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: iload_0
    //   5: bipush #24
    //   7: iushr
    //   8: lookupswitch default -> 144, 0 -> 108, 1 -> 108, 19 -> 121, 20 -> 121, 21 -> 121, 22 -> 108, 71 -> 134, 72 -> 134, 73 -> 134, 74 -> 134, 75 -> 134
    //   108: aload_2
    //   109: iload_0
    //   110: bipush #16
    //   112: iushr
    //   113: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   116: pop
    //   117: iload_3
    //   118: ifeq -> 160
    //   121: aload_2
    //   122: iload_0
    //   123: bipush #24
    //   125: iushr
    //   126: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   129: pop
    //   130: iload_3
    //   131: ifeq -> 160
    //   134: aload_2
    //   135: iload_0
    //   136: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   139: pop
    //   140: iload_3
    //   141: ifeq -> 160
    //   144: aload_2
    //   145: iload_0
    //   146: bipush #24
    //   148: iushr
    //   149: iload_0
    //   150: ldc 16776960
    //   152: iand
    //   153: bipush #8
    //   155: ishr
    //   156: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   159: pop
    //   160: aload_1
    //   161: iload_3
    //   162: ifne -> 179
    //   165: ifnonnull -> 178
    //   168: aload_2
    //   169: iconst_0
    //   170: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   173: pop
    //   174: iload_3
    //   175: ifeq -> 208
    //   178: aload_1
    //   179: getfield a : [B
    //   182: aload_1
    //   183: getfield b : I
    //   186: baload
    //   187: iconst_2
    //   188: imul
    //   189: iconst_1
    //   190: iadd
    //   191: istore #4
    //   193: aload_2
    //   194: aload_1
    //   195: getfield a : [B
    //   198: aload_1
    //   199: getfield b : I
    //   202: iload #4
    //   204: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   207: pop
    //   208: return
  }
  
  static {
    // Byte code:
    //   0: ldc 'a °B\\f²'
    //   2: jsr -> 11
    //   5: putstatic org/objectweb/asm/AnnotationWriter.i : Ljava/lang/String;
    //   8: goto -> 144
    //   11: astore_0
    //   12: invokevirtual toCharArray : ()[C
    //   15: dup
    //   16: arraylength
    //   17: swap
    //   18: iconst_0
    //   19: istore_1
    //   20: swap
    //   21: dup_x1
    //   22: iconst_1
    //   23: if_icmpgt -> 123
    //   26: dup
    //   27: iload_1
    //   28: dup2
    //   29: caload
    //   30: iload_1
    //   31: bipush #7
    //   33: irem
    //   34: tableswitch default -> 105, 0 -> 72, 1 -> 77, 2 -> 83, 3 -> 88, 4 -> 94, 5 -> 100
    //   72: bipush #79
    //   74: goto -> 107
    //   77: sipush #225
    //   80: goto -> 107
    //   83: bipush #14
    //   85: goto -> 107
    //   88: sipush #216
    //   91: goto -> 107
    //   94: sipush #246
    //   97: goto -> 107
    //   100: bipush #8
    //   102: goto -> 107
    //   105: bipush #94
    //   107: ixor
    //   108: i2c
    //   109: castore
    //   110: iinc #1, 1
    //   113: swap
    //   114: dup_x1
    //   115: ifne -> 123
    //   118: dup2
    //   119: swap
    //   120: goto -> 28
    //   123: swap
    //   124: dup_x1
    //   125: iload_1
    //   126: if_icmpgt -> 26
    //   129: new java/lang/String
    //   132: dup_x1
    //   133: swap
    //   134: invokespecial <init> : ([C)V
    //   137: invokevirtual intern : ()Ljava/lang/String;
    //   140: swap
    //   141: pop
    //   142: ret #0
    //   144: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\AnnotationWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */