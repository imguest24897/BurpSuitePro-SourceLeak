package org.objectweb.asm;

public abstract class FieldVisitor {
  protected final int api;
  
  protected FieldVisitor fv;
  
  public FieldVisitor(int paramInt) {
    this(paramInt, null);
  }
  
  public FieldVisitor(int paramInt, FieldVisitor paramFieldVisitor) {
    if (i == 0) {
      try {
        if (paramInt != 262144)
          try {
            if (paramInt != 327680)
              throw new IllegalArgumentException(); 
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          }  
      } catch (IllegalArgumentException illegalArgumentException) {
        throw null;
      } 
      this.api = paramInt;
      this.fv = paramFieldVisitor;
    } 
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.fv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.fv.visitAnnotation(paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.fv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.fv.visitTypeAnnotation(paramInt, paramTypePath, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.fv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.fv.visitAttribute(paramAttribute);
  }
  
  public void visitEnd() {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.fv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.fv.visitEnd();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\FieldVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */