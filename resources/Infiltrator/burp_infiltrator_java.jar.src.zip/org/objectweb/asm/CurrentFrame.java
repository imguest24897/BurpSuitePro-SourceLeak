package org.objectweb.asm;

class CurrentFrame extends Frame {
  void a(int paramInt1, int paramInt2, ClassWriter paramClassWriter, Item paramItem) {
    super.a(paramInt1, paramInt2, paramClassWriter, paramItem);
    Frame frame = new Frame();
    a(paramClassWriter, frame, 0);
    b(frame);
    this.b.f = 0;
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\CurrentFrame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */