package org.objectweb.asm;

public class Attribute {
  public final String type;
  
  byte[] b;
  
  Attribute a;
  
  protected Attribute(String paramString) {
    this.type = paramString;
  }
  
  public boolean isUnknown() {
    return true;
  }
  
  public boolean isCodeAttribute() {
    return false;
  }
  
  protected Label[] getLabels() {
    return null;
  }
  
  protected Attribute read(ClassReader paramClassReader, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, Label[] paramArrayOfLabel) {
    Attribute attribute = new Attribute(this.type);
    attribute.b = new byte[paramInt2];
    System.arraycopy(paramClassReader.b, paramInt1, attribute.b, 0, paramInt2);
    return attribute;
  }
  
  protected ByteVector write(ClassWriter paramClassWriter, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
    ByteVector byteVector = new ByteVector();
    byteVector.a = this.b;
    byteVector.b = this.b.length;
    return byteVector;
  }
  
  final int a() {
    byte b = 0;
    Attribute attribute = this;
    int i = MethodVisitor.b;
    while (attribute != null) {
      b++;
      attribute = attribute.a;
      if (i != 0)
        break; 
    } 
    return b;
  }
  
  final int a(ClassWriter paramClassWriter, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: astore #7
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: iconst_0
    //   7: istore #8
    //   9: istore #6
    //   11: aload #7
    //   13: ifnull -> 66
    //   16: aload_1
    //   17: aload #7
    //   19: getfield type : Ljava/lang/String;
    //   22: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   25: pop
    //   26: iload #8
    //   28: aload #7
    //   30: aload_1
    //   31: aload_2
    //   32: iload_3
    //   33: iload #4
    //   35: iload #5
    //   37: invokevirtual write : (Lorg/objectweb/asm/ClassWriter;[BIII)Lorg/objectweb/asm/ByteVector;
    //   40: getfield b : I
    //   43: bipush #6
    //   45: iadd
    //   46: iadd
    //   47: iload #6
    //   49: ifne -> 68
    //   52: istore #8
    //   54: aload #7
    //   56: getfield a : Lorg/objectweb/asm/Attribute;
    //   59: astore #7
    //   61: iload #6
    //   63: ifeq -> 11
    //   66: iload #8
    //   68: ireturn
  }
  
  final void a(ClassWriter paramClassWriter, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, ByteVector paramByteVector) {
    int i = MethodVisitor.b;
    Attribute attribute = this;
    while (attribute != null) {
      ByteVector byteVector = attribute.write(paramClassWriter, paramArrayOfbyte, paramInt1, paramInt2, paramInt3);
      paramByteVector.putShort(paramClassWriter.newUTF8(attribute.type)).putInt(byteVector.b);
      paramByteVector.putByteArray(byteVector.a, 0, byteVector.b);
      attribute = attribute.a;
      if (i != 0)
        break; 
    } 
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Attribute.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */