package org.objectweb.asm;

public class TypePath {
  public static final int ARRAY_ELEMENT = 0;
  
  public static final int INNER_TYPE = 1;
  
  public static final int WILDCARD_BOUND = 2;
  
  public static final int TYPE_ARGUMENT = 3;
  
  byte[] a;
  
  int b;
  
  TypePath(byte[] paramArrayOfbyte, int paramInt) {
    this.a = paramArrayOfbyte;
    this.b = paramInt;
  }
  
  public int getLength() {
    return this.a[this.b];
  }
  
  public int getStep(int paramInt) {
    return this.a[this.b + 2 * paramInt + 1];
  }
  
  public int getStepArgument(int paramInt) {
    return this.a[this.b + 2 * paramInt + 2];
  }
  
  public static TypePath fromString(String paramString) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: iload_1
    //   6: ifne -> 13
    //   9: ifnull -> 23
    //   12: aload_0
    //   13: invokevirtual length : ()I
    //   16: iload_1
    //   17: ifne -> 29
    //   20: ifne -> 25
    //   23: aconst_null
    //   24: areturn
    //   25: aload_0
    //   26: invokevirtual length : ()I
    //   29: istore_2
    //   30: new org/objectweb/asm/ByteVector
    //   33: dup
    //   34: iload_2
    //   35: invokespecial <init> : (I)V
    //   38: astore_3
    //   39: aload_3
    //   40: iconst_0
    //   41: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   44: pop
    //   45: iconst_0
    //   46: istore #4
    //   48: iload #4
    //   50: iload_2
    //   51: if_icmpge -> 259
    //   54: aload_0
    //   55: iload #4
    //   57: iinc #4, 1
    //   60: invokevirtual charAt : (I)C
    //   63: istore #5
    //   65: iload_1
    //   66: ifne -> 272
    //   69: iload #5
    //   71: bipush #91
    //   73: iload_1
    //   74: ifne -> 95
    //   77: if_icmpne -> 91
    //   80: aload_3
    //   81: iconst_0
    //   82: iconst_0
    //   83: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   86: pop
    //   87: iload_1
    //   88: ifeq -> 255
    //   91: iload #5
    //   93: bipush #46
    //   95: iload_1
    //   96: ifne -> 117
    //   99: if_icmpne -> 113
    //   102: aload_3
    //   103: iconst_1
    //   104: iconst_0
    //   105: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   108: pop
    //   109: iload_1
    //   110: ifeq -> 255
    //   113: iload #5
    //   115: bipush #42
    //   117: iload_1
    //   118: ifne -> 139
    //   121: if_icmpne -> 135
    //   124: aload_3
    //   125: iconst_2
    //   126: iconst_0
    //   127: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   130: pop
    //   131: iload_1
    //   132: ifeq -> 255
    //   135: iload #5
    //   137: bipush #48
    //   139: iload_1
    //   140: ifne -> 150
    //   143: if_icmplt -> 255
    //   146: iload #5
    //   148: bipush #57
    //   150: iload_1
    //   151: ifne -> 161
    //   154: if_icmpgt -> 255
    //   157: iload #5
    //   159: bipush #48
    //   161: isub
    //   162: istore #6
    //   164: iload #4
    //   166: iload_2
    //   167: if_icmpge -> 223
    //   170: aload_0
    //   171: iload #4
    //   173: invokevirtual charAt : (I)C
    //   176: dup
    //   177: istore #5
    //   179: bipush #48
    //   181: iload_1
    //   182: ifne -> 226
    //   185: iload_1
    //   186: ifne -> 226
    //   189: if_icmplt -> 223
    //   192: iload #5
    //   194: bipush #57
    //   196: iload_1
    //   197: ifne -> 226
    //   200: if_icmpgt -> 223
    //   203: iload #6
    //   205: bipush #10
    //   207: imul
    //   208: iload #5
    //   210: iadd
    //   211: bipush #48
    //   213: isub
    //   214: istore #6
    //   216: iinc #4, 1
    //   219: iload_1
    //   220: ifeq -> 164
    //   223: iload #4
    //   225: iload_2
    //   226: iload_1
    //   227: ifne -> 241
    //   230: if_icmpge -> 247
    //   233: aload_0
    //   234: iload #4
    //   236: invokevirtual charAt : (I)C
    //   239: bipush #59
    //   241: if_icmpne -> 247
    //   244: iinc #4, 1
    //   247: aload_3
    //   248: iconst_3
    //   249: iload #6
    //   251: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   254: pop
    //   255: iload_1
    //   256: ifeq -> 48
    //   259: aload_3
    //   260: getfield a : [B
    //   263: iconst_0
    //   264: aload_3
    //   265: getfield b : I
    //   268: iconst_2
    //   269: idiv
    //   270: i2b
    //   271: bastore
    //   272: new org/objectweb/asm/TypePath
    //   275: dup
    //   276: aload_3
    //   277: getfield a : [B
    //   280: iconst_0
    //   281: invokespecial <init> : ([BI)V
    //   284: areturn
  }
  
  public String toString() {
    int j = getLength();
    StringBuffer stringBuffer = new StringBuffer(j * 2);
    int i = MethodVisitor.b;
    byte b = 0;
    while (b < j) {
      switch (getStep(b)) {
        case 0:
          stringBuffer.append('[');
        case 1:
          stringBuffer.append('.');
        case 2:
          stringBuffer.append('*');
        case 3:
          stringBuffer.append(getStepArgument(b)).append(';');
        default:
          stringBuffer.append('_');
          break;
      } 
      b++;
      continue;
      if (i != 0)
        break; 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\TypePath.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */