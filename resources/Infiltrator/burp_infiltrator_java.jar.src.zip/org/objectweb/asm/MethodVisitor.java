package org.objectweb.asm;

public abstract class MethodVisitor {
  protected final int api;
  
  protected MethodVisitor mv;
  
  public static int b;
  
  private static final String a;
  
  public MethodVisitor(int paramInt) {
    this(paramInt, null);
  }
  
  public MethodVisitor(int paramInt, MethodVisitor paramMethodVisitor) {
    if (i == 0) {
      try {
        if (paramInt != 262144)
          try {
            if (paramInt != 327680)
              throw new IllegalArgumentException(); 
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          }  
      } catch (IllegalArgumentException illegalArgumentException) {
        throw null;
      } 
      this.api = paramInt;
      this.mv = paramMethodVisitor;
    } 
  }
  
  public void visitParameter(String paramString, int paramInt) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitParameter(paramString, paramInt);
  }
  
  public AnnotationVisitor visitAnnotationDefault() {
    int i = b;
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitAnnotationDefault();
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitAnnotation(paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitTypeAnnotation(paramInt, paramTypePath, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public AnnotationVisitor visitParameterAnnotation(int paramInt, String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitParameterAnnotation(paramInt, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitAttribute(paramAttribute);
  }
  
  public void visitCode() {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitCode();
  }
  
  public void visitFrame(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitFrame(paramInt1, paramInt2, paramArrayOfObject1, paramInt3, paramArrayOfObject2);
  }
  
  public void visitInsn(int paramInt) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitInsn(paramInt);
  }
  
  public void visitIntInsn(int paramInt1, int paramInt2) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitIntInsn(paramInt1, paramInt2);
  }
  
  public void visitVarInsn(int paramInt1, int paramInt2) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitVarInsn(paramInt1, paramInt2);
  }
  
  public void visitTypeInsn(int paramInt, String paramString) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitTypeInsn(paramInt, paramString);
  }
  
  public void visitFieldInsn(int paramInt, String paramString1, String paramString2, String paramString3) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitFieldInsn(paramInt, paramString1, paramString2, paramString3);
  }
  
  public void visitMethodInsn(int paramInt, String paramString1, String paramString2, String paramString3) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api >= 327680) {
            try {
              if (i == 0)
                try {
                
                } catch (IllegalArgumentException illegalArgumentException) {
                  throw null;
                }  
            } catch (IllegalArgumentException illegalArgumentException) {
              throw null;
            } 
            boolean bool = (paramInt == 185) ? true : false;
            visitMethodInsn(paramInt, paramString1, paramString2, paramString3, bool);
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitMethodInsn(paramInt, paramString1, paramString2, paramString3);
  }
  
  public void visitMethodInsn(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680) {
            try {
              if (i == 0)
                try {
                
                } catch (IllegalArgumentException illegalArgumentException) {
                  throw null;
                }  
            } catch (IllegalArgumentException illegalArgumentException) {
              throw null;
            } 
            try {
              if (paramBoolean != ((paramInt == 185)))
                throw new IllegalArgumentException(a); 
            } catch (IllegalArgumentException illegalArgumentException) {
              throw null;
            } 
            visitMethodInsn(paramInt, paramString1, paramString2, paramString3);
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitMethodInsn(paramInt, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public void visitInvokeDynamicInsn(String paramString1, String paramString2, Handle paramHandle, Object[] paramArrayOfObject) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitInvokeDynamicInsn(paramString1, paramString2, paramHandle, paramArrayOfObject);
  }
  
  public void visitJumpInsn(int paramInt, Label paramLabel) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitJumpInsn(paramInt, paramLabel);
  }
  
  public void visitLabel(Label paramLabel) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitLabel(paramLabel);
  }
  
  public void visitLdcInsn(Object paramObject) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitLdcInsn(paramObject);
  }
  
  public void visitIincInsn(int paramInt1, int paramInt2) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitIincInsn(paramInt1, paramInt2);
  }
  
  public void visitTableSwitchInsn(int paramInt1, int paramInt2, Label paramLabel, Label[] paramArrayOfLabel) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitTableSwitchInsn(paramInt1, paramInt2, paramLabel, paramArrayOfLabel);
  }
  
  public void visitLookupSwitchInsn(Label paramLabel, int[] paramArrayOfint, Label[] paramArrayOfLabel) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitLookupSwitchInsn(paramLabel, paramArrayOfint, paramArrayOfLabel);
  }
  
  public void visitMultiANewArrayInsn(String paramString, int paramInt) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitMultiANewArrayInsn(paramString, paramInt);
  }
  
  public AnnotationVisitor visitInsnAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitInsnAnnotation(paramInt, paramTypePath, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitTryCatchBlock(Label paramLabel1, Label paramLabel2, Label paramLabel3, String paramString) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitTryCatchBlock(paramLabel1, paramLabel2, paramLabel3, paramString);
  }
  
  public AnnotationVisitor visitTryCatchAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitTryCatchAnnotation(paramInt, paramTypePath, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitLocalVariable(String paramString1, String paramString2, String paramString3, Label paramLabel1, Label paramLabel2, int paramInt) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitLocalVariable(paramString1, paramString2, paramString3, paramLabel1, paramLabel2, paramInt);
  }
  
  public AnnotationVisitor visitLocalVariableAnnotation(int paramInt, TypePath paramTypePath, Label[] paramArrayOfLabel1, Label[] paramArrayOfLabel2, int[] paramArrayOfint, String paramString, boolean paramBoolean) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.api < 327680)
            throw new RuntimeException(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.mv != null);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } else {
        return this.mv.visitLocalVariableAnnotation(paramInt, paramTypePath, paramArrayOfLabel1, paramArrayOfLabel2, paramArrayOfint, paramString, paramBoolean);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return null;
  }
  
  public void visitLineNumber(int paramInt, Label paramLabel) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitLineNumber(paramInt, paramLabel);
  }
  
  public void visitMaxs(int paramInt1, int paramInt2) {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitMaxs(paramInt1, paramInt2);
  }
  
  public void visitEnd() {
    int i = b;
    try {
      if (i == 0)
        try {
          if (this.mv != null) {
          
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.mv.visitEnd();
  }
  
  static {
    // Byte code:
    //   0: ldc 'î1SyG\\n÷:FsNvô+D {AyÈ%=\v<Õd7WqyÕt![p<>V7'
    //   2: jsr -> 11
    //   5: putstatic org/objectweb/asm/MethodVisitor.a : Ljava/lang/String;
    //   8: goto -> 140
    //   11: astore_0
    //   12: invokevirtual toCharArray : ()[C
    //   15: dup
    //   16: arraylength
    //   17: swap
    //   18: iconst_0
    //   19: istore_1
    //   20: swap
    //   21: dup_x1
    //   22: iconst_1
    //   23: if_icmpgt -> 119
    //   26: dup
    //   27: iload_1
    //   28: dup2
    //   29: caload
    //   30: iload_1
    //   31: bipush #7
    //   33: irem
    //   34: tableswitch default -> 101, 0 -> 72, 1 -> 78, 2 -> 83, 3 -> 87, 4 -> 92, 5 -> 97
    //   72: sipush #167
    //   75: goto -> 103
    //   78: bipush #127
    //   80: goto -> 103
    //   83: iconst_5
    //   84: goto -> 103
    //   87: bipush #84
    //   89: goto -> 103
    //   92: bipush #50
    //   94: goto -> 103
    //   97: iconst_2
    //   98: goto -> 103
    //   101: bipush #89
    //   103: ixor
    //   104: i2c
    //   105: castore
    //   106: iinc #1, 1
    //   109: swap
    //   110: dup_x1
    //   111: ifne -> 119
    //   114: dup2
    //   115: swap
    //   116: goto -> 28
    //   119: swap
    //   120: dup_x1
    //   121: iload_1
    //   122: if_icmpgt -> 26
    //   125: new java/lang/String
    //   128: dup_x1
    //   129: swap
    //   130: invokespecial <init> : ([C)V
    //   133: invokevirtual intern : ()Ljava/lang/String;
    //   136: swap
    //   137: pop
    //   138: ret #0
    //   140: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\MethodVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */