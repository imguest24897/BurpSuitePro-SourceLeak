package org.objectweb.asm;

public class ClassWriter extends ClassVisitor {
  public static final int COMPUTE_MAXS = 1;
  
  public static final int COMPUTE_FRAMES = 2;
  
  static final byte[] a;
  
  ClassReader K;
  
  int b;
  
  int c;
  
  final ByteVector d;
  
  Item[] e;
  
  int f;
  
  final Item g;
  
  final Item h;
  
  final Item i;
  
  final Item j;
  
  Item[] H;
  
  private short G;
  
  private int k;
  
  private int l;
  
  String I;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private int[] p;
  
  private int q;
  
  private ByteVector r;
  
  private int s;
  
  private int t;
  
  private AnnotationWriter u;
  
  private AnnotationWriter v;
  
  private AnnotationWriter N;
  
  private AnnotationWriter O;
  
  private Attribute w;
  
  private int x;
  
  private ByteVector y;
  
  int z;
  
  ByteVector A;
  
  FieldWriter B;
  
  FieldWriter C;
  
  MethodWriter D;
  
  MethodWriter E;
  
  private int F;
  
  boolean J;
  
  private static final String[] L;
  
  private static final String[] M;
  
  public ClassWriter(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: ldc 327680
    //   3: invokespecial <init> : (I)V
    //   6: aload_0
    //   7: iconst_1
    //   8: putfield c : I
    //   11: aload_0
    //   12: new org/objectweb/asm/ByteVector
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: putfield d : Lorg/objectweb/asm/ByteVector;
    //   22: aload_0
    //   23: sipush #256
    //   26: anewarray org/objectweb/asm/Item
    //   29: putfield e : [Lorg/objectweb/asm/Item;
    //   32: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   35: aload_0
    //   36: ldc2_w 0.75
    //   39: aload_0
    //   40: getfield e : [Lorg/objectweb/asm/Item;
    //   43: arraylength
    //   44: i2d
    //   45: dmul
    //   46: d2i
    //   47: putfield f : I
    //   50: aload_0
    //   51: new org/objectweb/asm/Item
    //   54: dup
    //   55: invokespecial <init> : ()V
    //   58: putfield g : Lorg/objectweb/asm/Item;
    //   61: aload_0
    //   62: new org/objectweb/asm/Item
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: putfield h : Lorg/objectweb/asm/Item;
    //   72: istore_2
    //   73: aload_0
    //   74: new org/objectweb/asm/Item
    //   77: dup
    //   78: invokespecial <init> : ()V
    //   81: putfield i : Lorg/objectweb/asm/Item;
    //   84: aload_0
    //   85: new org/objectweb/asm/Item
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: putfield j : Lorg/objectweb/asm/Item;
    //   95: aload_0
    //   96: iload_1
    //   97: iconst_2
    //   98: iand
    //   99: iload_2
    //   100: ifne -> 118
    //   103: ifeq -> 115
    //   106: goto -> 110
    //   109: athrow
    //   110: iconst_0
    //   111: goto -> 134
    //   114: athrow
    //   115: iload_1
    //   116: iconst_1
    //   117: iand
    //   118: iload_2
    //   119: ifne -> 130
    //   122: ifeq -> 133
    //   125: goto -> 129
    //   128: athrow
    //   129: iconst_2
    //   130: goto -> 134
    //   133: iconst_3
    //   134: putfield F : I
    //   137: return
    // Exception table:
    //   from	to	target	type
    //   73	106	109	java/lang/IllegalArgumentException
    //   103	114	114	java/lang/IllegalArgumentException
    //   118	125	128	java/lang/IllegalArgumentException
  }
  
  public ClassWriter(ClassReader paramClassReader, int paramInt) {
    this(paramInt);
    paramClassReader.a(this);
    this.K = paramClassReader;
  }
  
  public final void visit(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    this.b = paramInt1;
    this.k = paramInt2;
    int i = MethodVisitor.b;
    try {
      this.l = newClass(paramString1);
      if (i == 0)
        try {
          this.I = paramString1;
          if (paramString2 != null)
            this.m = newUTF8(paramString2); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
    
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      this.n = (paramString3 == null) ? 0 : newClass(paramString3);
      if (i == 0)
        if (paramArrayOfString != null) {
        
        } else {
          return;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (paramArrayOfString.length > 0) {
            this.o = paramArrayOfString.length;
            this.p = new int[this.o];
          } else {
            return;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    int j = paramArrayOfString.length;
    while (j < this.o) {
      this.p[j] = newClass(paramArrayOfString[j]);
      j++;
      if (i != 0)
        break; 
    } 
  }
  
  public final void visitSource(String paramString1, String paramString2) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (paramString1 != null)
            this.q = newUTF8(paramString1); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (paramString2 != null)
        this.r = (new ByteVector()).c(paramString2, 0, 2147483647); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
  }
  
  public final void visitOuterClass(String paramString1, String paramString2, String paramString3) {
    int i = MethodVisitor.b;
    try {
      this.s = newClass(paramString1);
      if (i == 0)
        if (paramString2 != null) {
        
        } else {
          return;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (paramString2 != null)
        this.t = newNameType(paramString2, paramString3); 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
  }
  
  public final AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   12: aload #4
    //   14: aload_0
    //   15: aload_1
    //   16: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   19: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   22: iconst_0
    //   23: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   26: pop
    //   27: istore_3
    //   28: new org/objectweb/asm/AnnotationWriter
    //   31: dup
    //   32: aload_0
    //   33: iconst_1
    //   34: aload #4
    //   36: aload #4
    //   38: iconst_2
    //   39: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   42: astore #5
    //   44: iload_3
    //   45: ifne -> 92
    //   48: iload_2
    //   49: ifeq -> 79
    //   52: goto -> 56
    //   55: athrow
    //   56: aload #5
    //   58: aload_0
    //   59: getfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   62: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   65: aload_0
    //   66: aload #5
    //   68: putfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   71: iload_3
    //   72: ifeq -> 98
    //   75: goto -> 79
    //   78: athrow
    //   79: aload #5
    //   81: aload_0
    //   82: getfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   85: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   88: goto -> 92
    //   91: athrow
    //   92: aload_0
    //   93: aload #5
    //   95: putfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   98: aload #5
    //   100: areturn
    // Exception table:
    //   from	to	target	type
    //   44	52	55	java/lang/IllegalArgumentException
    //   48	75	78	java/lang/IllegalArgumentException
    //   56	88	91	java/lang/IllegalArgumentException
  }
  
  public final AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: iload_1
    //   10: aload_2
    //   11: aload #6
    //   13: invokestatic a : (ILorg/objectweb/asm/TypePath;Lorg/objectweb/asm/ByteVector;)V
    //   16: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   19: aload #6
    //   21: aload_0
    //   22: aload_3
    //   23: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   26: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   29: iconst_0
    //   30: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   33: pop
    //   34: istore #5
    //   36: new org/objectweb/asm/AnnotationWriter
    //   39: dup
    //   40: aload_0
    //   41: iconst_1
    //   42: aload #6
    //   44: aload #6
    //   46: aload #6
    //   48: getfield b : I
    //   51: iconst_2
    //   52: isub
    //   53: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   56: astore #7
    //   58: iload #5
    //   60: ifne -> 109
    //   63: iload #4
    //   65: ifeq -> 96
    //   68: goto -> 72
    //   71: athrow
    //   72: aload #7
    //   74: aload_0
    //   75: getfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   78: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   81: aload_0
    //   82: aload #7
    //   84: putfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   87: iload #5
    //   89: ifeq -> 115
    //   92: goto -> 96
    //   95: athrow
    //   96: aload #7
    //   98: aload_0
    //   99: getfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   102: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   105: goto -> 109
    //   108: athrow
    //   109: aload_0
    //   110: aload #7
    //   112: putfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   115: aload #7
    //   117: areturn
    // Exception table:
    //   from	to	target	type
    //   58	68	71	java/lang/IllegalArgumentException
    //   63	92	95	java/lang/IllegalArgumentException
    //   72	105	108	java/lang/IllegalArgumentException
  }
  
  public final void visitAttribute(Attribute paramAttribute) {
    paramAttribute.a = this.w;
    this.w = paramAttribute;
  }
  
  public final void visitInnerClass(String paramString1, String paramString2, String paramString3, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: aload_0
    //   6: iload #5
    //   8: ifne -> 37
    //   11: getfield y : Lorg/objectweb/asm/ByteVector;
    //   14: ifnonnull -> 36
    //   17: goto -> 21
    //   20: athrow
    //   21: aload_0
    //   22: new org/objectweb/asm/ByteVector
    //   25: dup
    //   26: invokespecial <init> : ()V
    //   29: putfield y : Lorg/objectweb/asm/ByteVector;
    //   32: goto -> 36
    //   35: athrow
    //   36: aload_0
    //   37: aload_1
    //   38: invokevirtual a : (Ljava/lang/String;)Lorg/objectweb/asm/Item;
    //   41: astore #6
    //   43: iload #5
    //   45: ifne -> 96
    //   48: aload #6
    //   50: getfield c : I
    //   53: ifne -> 162
    //   56: goto -> 60
    //   59: athrow
    //   60: aload_0
    //   61: dup
    //   62: getfield x : I
    //   65: iconst_1
    //   66: iadd
    //   67: putfield x : I
    //   70: aload_0
    //   71: getfield y : Lorg/objectweb/asm/ByteVector;
    //   74: aload #6
    //   76: getfield a : I
    //   79: iload #5
    //   81: ifne -> 109
    //   84: goto -> 88
    //   87: athrow
    //   88: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   91: pop
    //   92: goto -> 96
    //   95: athrow
    //   96: aload_0
    //   97: getfield y : Lorg/objectweb/asm/ByteVector;
    //   100: aload_2
    //   101: ifnonnull -> 112
    //   104: iconst_0
    //   105: goto -> 109
    //   108: athrow
    //   109: goto -> 117
    //   112: aload_0
    //   113: aload_2
    //   114: invokevirtual newClass : (Ljava/lang/String;)I
    //   117: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   120: pop
    //   121: aload_0
    //   122: getfield y : Lorg/objectweb/asm/ByteVector;
    //   125: aload_3
    //   126: ifnonnull -> 134
    //   129: iconst_0
    //   130: goto -> 139
    //   133: athrow
    //   134: aload_0
    //   135: aload_3
    //   136: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   139: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   142: pop
    //   143: aload_0
    //   144: getfield y : Lorg/objectweb/asm/ByteVector;
    //   147: iload #4
    //   149: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   152: pop
    //   153: aload #6
    //   155: aload_0
    //   156: getfield x : I
    //   159: putfield c : I
    //   162: return
    // Exception table:
    //   from	to	target	type
    //   5	17	20	java/lang/IllegalArgumentException
    //   11	32	35	java/lang/IllegalArgumentException
    //   43	56	59	java/lang/IllegalArgumentException
    //   48	84	87	java/lang/IllegalArgumentException
    //   60	92	95	java/lang/IllegalArgumentException
    //   96	105	108	java/lang/IllegalArgumentException
    //   117	133	133	java/lang/IllegalArgumentException
  }
  
  public final FieldVisitor visitField(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    return new FieldWriter(this, paramInt, paramString1, paramString2, paramString3, paramObject);
  }
  
  public final MethodVisitor visitMethod(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    return new MethodWriter(this, paramInt, paramString1, paramString2, paramString3, paramArrayOfString, this.F);
  }
  
  public final void visitEnd() {}
  
  public byte[] toByteArray() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: getfield c : I
    //   8: ldc 65535
    //   10: iload_1
    //   11: ifne -> 47
    //   14: if_icmple -> 39
    //   17: goto -> 21
    //   20: athrow
    //   21: new java/lang/RuntimeException
    //   24: dup
    //   25: sipush #18855
    //   28: sipush #-13417
    //   31: invokestatic b : (II)Ljava/lang/String;
    //   34: invokespecial <init> : (Ljava/lang/String;)V
    //   37: athrow
    //   38: athrow
    //   39: bipush #24
    //   41: iconst_2
    //   42: aload_0
    //   43: getfield o : I
    //   46: imul
    //   47: iadd
    //   48: istore_2
    //   49: iconst_0
    //   50: istore_3
    //   51: aload_0
    //   52: getfield B : Lorg/objectweb/asm/FieldWriter;
    //   55: astore #4
    //   57: aload #4
    //   59: ifnull -> 106
    //   62: iinc #3, 1
    //   65: iload_2
    //   66: aload #4
    //   68: invokevirtual a : ()I
    //   71: iadd
    //   72: iload_1
    //   73: ifne -> 107
    //   76: istore_2
    //   77: aload #4
    //   79: getfield fv : Lorg/objectweb/asm/FieldVisitor;
    //   82: checkcast org/objectweb/asm/FieldWriter
    //   85: astore #4
    //   87: iload_1
    //   88: ifeq -> 57
    //   91: getstatic org/objectweb/asm/ClassVisitor.b : Z
    //   94: ifeq -> 102
    //   97: iconst_0
    //   98: goto -> 103
    //   101: athrow
    //   102: iconst_1
    //   103: putstatic org/objectweb/asm/ClassVisitor.b : Z
    //   106: iconst_0
    //   107: istore #5
    //   109: aload_0
    //   110: getfield D : Lorg/objectweb/asm/MethodWriter;
    //   113: astore #6
    //   115: aload #6
    //   117: ifnull -> 149
    //   120: iinc #5, 1
    //   123: iload_2
    //   124: aload #6
    //   126: invokevirtual a : ()I
    //   129: iadd
    //   130: iload_1
    //   131: ifne -> 150
    //   134: istore_2
    //   135: aload #6
    //   137: getfield mv : Lorg/objectweb/asm/MethodVisitor;
    //   140: checkcast org/objectweb/asm/MethodWriter
    //   143: astore #6
    //   145: iload_1
    //   146: ifeq -> 115
    //   149: iconst_0
    //   150: istore #7
    //   152: aload_0
    //   153: iload_1
    //   154: ifne -> 198
    //   157: getfield A : Lorg/objectweb/asm/ByteVector;
    //   160: ifnull -> 197
    //   163: goto -> 167
    //   166: athrow
    //   167: iinc #7, 1
    //   170: iload_2
    //   171: bipush #8
    //   173: aload_0
    //   174: getfield A : Lorg/objectweb/asm/ByteVector;
    //   177: getfield b : I
    //   180: iadd
    //   181: iadd
    //   182: istore_2
    //   183: aload_0
    //   184: sipush #18852
    //   187: sipush #-23842
    //   190: invokestatic b : (II)Ljava/lang/String;
    //   193: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   196: pop
    //   197: aload_0
    //   198: getfield m : I
    //   201: iload_1
    //   202: ifne -> 248
    //   205: ifeq -> 236
    //   208: goto -> 212
    //   211: athrow
    //   212: iinc #7, 1
    //   215: iinc #2, 8
    //   218: aload_0
    //   219: sipush #18854
    //   222: sipush #-13025
    //   225: invokestatic b : (II)Ljava/lang/String;
    //   228: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   231: pop
    //   232: goto -> 236
    //   235: athrow
    //   236: aload_0
    //   237: iload_1
    //   238: ifne -> 276
    //   241: getfield q : I
    //   244: goto -> 248
    //   247: athrow
    //   248: ifeq -> 275
    //   251: iinc #7, 1
    //   254: iinc #2, 8
    //   257: aload_0
    //   258: sipush #18860
    //   261: sipush #-12306
    //   264: invokestatic b : (II)Ljava/lang/String;
    //   267: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   270: pop
    //   271: goto -> 275
    //   274: athrow
    //   275: aload_0
    //   276: iload_1
    //   277: ifne -> 321
    //   280: getfield r : Lorg/objectweb/asm/ByteVector;
    //   283: ifnull -> 320
    //   286: goto -> 290
    //   289: athrow
    //   290: iinc #7, 1
    //   293: iload_2
    //   294: aload_0
    //   295: getfield r : Lorg/objectweb/asm/ByteVector;
    //   298: getfield b : I
    //   301: bipush #6
    //   303: iadd
    //   304: iadd
    //   305: istore_2
    //   306: aload_0
    //   307: sipush #18850
    //   310: sipush #-9342
    //   313: invokestatic b : (II)Ljava/lang/String;
    //   316: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   319: pop
    //   320: aload_0
    //   321: getfield s : I
    //   324: iload_1
    //   325: ifne -> 366
    //   328: ifeq -> 359
    //   331: goto -> 335
    //   334: athrow
    //   335: iinc #7, 1
    //   338: iinc #2, 10
    //   341: aload_0
    //   342: sipush #18859
    //   345: sipush #-18332
    //   348: invokestatic b : (II)Ljava/lang/String;
    //   351: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   354: pop
    //   355: goto -> 359
    //   358: athrow
    //   359: aload_0
    //   360: getfield k : I
    //   363: ldc 131072
    //   365: iand
    //   366: iload_1
    //   367: ifne -> 417
    //   370: ifeq -> 401
    //   373: goto -> 377
    //   376: athrow
    //   377: iinc #7, 1
    //   380: iinc #2, 6
    //   383: aload_0
    //   384: sipush #18848
    //   387: sipush #-10539
    //   390: invokestatic b : (II)Ljava/lang/String;
    //   393: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   396: pop
    //   397: goto -> 401
    //   400: athrow
    //   401: aload_0
    //   402: iload_1
    //   403: ifne -> 491
    //   406: getfield k : I
    //   409: sipush #4096
    //   412: iand
    //   413: goto -> 417
    //   416: athrow
    //   417: ifeq -> 490
    //   420: aload_0
    //   421: getfield b : I
    //   424: ldc 65535
    //   426: iand
    //   427: iload_1
    //   428: ifne -> 489
    //   431: goto -> 435
    //   434: athrow
    //   435: bipush #49
    //   437: if_icmplt -> 466
    //   440: goto -> 444
    //   443: athrow
    //   444: aload_0
    //   445: iload_1
    //   446: ifne -> 491
    //   449: goto -> 453
    //   452: athrow
    //   453: getfield k : I
    //   456: ldc 262144
    //   458: iand
    //   459: ifeq -> 490
    //   462: goto -> 466
    //   465: athrow
    //   466: iinc #7, 1
    //   469: iinc #2, 6
    //   472: aload_0
    //   473: sipush #18849
    //   476: sipush #-31450
    //   479: invokestatic b : (II)Ljava/lang/String;
    //   482: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   485: goto -> 489
    //   488: athrow
    //   489: pop
    //   490: aload_0
    //   491: iload_1
    //   492: ifne -> 536
    //   495: getfield y : Lorg/objectweb/asm/ByteVector;
    //   498: ifnull -> 535
    //   501: goto -> 505
    //   504: athrow
    //   505: iinc #7, 1
    //   508: iload_2
    //   509: bipush #8
    //   511: aload_0
    //   512: getfield y : Lorg/objectweb/asm/ByteVector;
    //   515: getfield b : I
    //   518: iadd
    //   519: iadd
    //   520: istore_2
    //   521: aload_0
    //   522: sipush #18863
    //   525: sipush #-18445
    //   528: invokestatic b : (II)Ljava/lang/String;
    //   531: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   534: pop
    //   535: aload_0
    //   536: getfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   539: iload_1
    //   540: ifne -> 584
    //   543: ifnull -> 580
    //   546: goto -> 550
    //   549: athrow
    //   550: iinc #7, 1
    //   553: iload_2
    //   554: bipush #8
    //   556: aload_0
    //   557: getfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   560: invokevirtual a : ()I
    //   563: iadd
    //   564: iadd
    //   565: istore_2
    //   566: aload_0
    //   567: sipush #18861
    //   570: sipush #16792
    //   573: invokestatic b : (II)Ljava/lang/String;
    //   576: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   579: pop
    //   580: aload_0
    //   581: getfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   584: iload_1
    //   585: ifne -> 629
    //   588: ifnull -> 625
    //   591: goto -> 595
    //   594: athrow
    //   595: iinc #7, 1
    //   598: iload_2
    //   599: bipush #8
    //   601: aload_0
    //   602: getfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   605: invokevirtual a : ()I
    //   608: iadd
    //   609: iadd
    //   610: istore_2
    //   611: aload_0
    //   612: sipush #18851
    //   615: sipush #28209
    //   618: invokestatic b : (II)Ljava/lang/String;
    //   621: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   624: pop
    //   625: aload_0
    //   626: getfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   629: iload_1
    //   630: ifne -> 682
    //   633: ifnull -> 670
    //   636: goto -> 640
    //   639: athrow
    //   640: iinc #7, 1
    //   643: iload_2
    //   644: bipush #8
    //   646: aload_0
    //   647: getfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   650: invokevirtual a : ()I
    //   653: iadd
    //   654: iadd
    //   655: istore_2
    //   656: aload_0
    //   657: sipush #18853
    //   660: sipush #21546
    //   663: invokestatic b : (II)Ljava/lang/String;
    //   666: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   669: pop
    //   670: aload_0
    //   671: iload_1
    //   672: ifne -> 716
    //   675: getfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   678: goto -> 682
    //   681: athrow
    //   682: ifnull -> 715
    //   685: iinc #7, 1
    //   688: iload_2
    //   689: bipush #8
    //   691: aload_0
    //   692: getfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   695: invokevirtual a : ()I
    //   698: iadd
    //   699: iadd
    //   700: istore_2
    //   701: aload_0
    //   702: sipush #18862
    //   705: sipush #11096
    //   708: invokestatic b : (II)Ljava/lang/String;
    //   711: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   714: pop
    //   715: aload_0
    //   716: getfield w : Lorg/objectweb/asm/Attribute;
    //   719: ifnull -> 749
    //   722: iload #7
    //   724: aload_0
    //   725: getfield w : Lorg/objectweb/asm/Attribute;
    //   728: invokevirtual a : ()I
    //   731: iadd
    //   732: istore #7
    //   734: iload_2
    //   735: aload_0
    //   736: getfield w : Lorg/objectweb/asm/Attribute;
    //   739: aload_0
    //   740: aconst_null
    //   741: iconst_0
    //   742: iconst_m1
    //   743: iconst_m1
    //   744: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIII)I
    //   747: iadd
    //   748: istore_2
    //   749: iload_2
    //   750: aload_0
    //   751: getfield d : Lorg/objectweb/asm/ByteVector;
    //   754: getfield b : I
    //   757: iadd
    //   758: istore_2
    //   759: new org/objectweb/asm/ByteVector
    //   762: dup
    //   763: iload_2
    //   764: invokespecial <init> : (I)V
    //   767: astore #8
    //   769: aload #8
    //   771: ldc -889275714
    //   773: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   776: aload_0
    //   777: getfield b : I
    //   780: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   783: pop
    //   784: aload #8
    //   786: aload_0
    //   787: getfield c : I
    //   790: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   793: aload_0
    //   794: getfield d : Lorg/objectweb/asm/ByteVector;
    //   797: getfield a : [B
    //   800: iconst_0
    //   801: aload_0
    //   802: getfield d : Lorg/objectweb/asm/ByteVector;
    //   805: getfield b : I
    //   808: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   811: pop
    //   812: ldc 393216
    //   814: aload_0
    //   815: getfield k : I
    //   818: ldc 262144
    //   820: iand
    //   821: bipush #64
    //   823: idiv
    //   824: ior
    //   825: istore #9
    //   827: aload #8
    //   829: aload_0
    //   830: getfield k : I
    //   833: iload #9
    //   835: iconst_m1
    //   836: ixor
    //   837: iand
    //   838: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   841: aload_0
    //   842: getfield l : I
    //   845: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   848: aload_0
    //   849: getfield n : I
    //   852: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   855: pop
    //   856: aload #8
    //   858: aload_0
    //   859: getfield o : I
    //   862: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   865: pop
    //   866: iconst_0
    //   867: istore #10
    //   869: iload #10
    //   871: aload_0
    //   872: getfield o : I
    //   875: if_icmpge -> 906
    //   878: aload #8
    //   880: aload_0
    //   881: getfield p : [I
    //   884: iload #10
    //   886: iaload
    //   887: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   890: pop
    //   891: iinc #10, 1
    //   894: iload_1
    //   895: ifne -> 913
    //   898: iload_1
    //   899: ifeq -> 869
    //   902: goto -> 906
    //   905: athrow
    //   906: aload #8
    //   908: iload_3
    //   909: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   912: pop
    //   913: aload_0
    //   914: getfield B : Lorg/objectweb/asm/FieldWriter;
    //   917: astore #4
    //   919: aload #4
    //   921: ifnull -> 953
    //   924: aload #4
    //   926: aload #8
    //   928: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   931: aload #4
    //   933: getfield fv : Lorg/objectweb/asm/FieldVisitor;
    //   936: checkcast org/objectweb/asm/FieldWriter
    //   939: astore #4
    //   941: iload_1
    //   942: ifne -> 961
    //   945: iload_1
    //   946: ifeq -> 919
    //   949: goto -> 953
    //   952: athrow
    //   953: aload #8
    //   955: iload #5
    //   957: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   960: pop
    //   961: aload_0
    //   962: getfield D : Lorg/objectweb/asm/MethodWriter;
    //   965: astore #6
    //   967: aload #6
    //   969: ifnull -> 1001
    //   972: aload #6
    //   974: aload #8
    //   976: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   979: aload #6
    //   981: getfield mv : Lorg/objectweb/asm/MethodVisitor;
    //   984: checkcast org/objectweb/asm/MethodWriter
    //   987: astore #6
    //   989: iload_1
    //   990: ifne -> 1009
    //   993: iload_1
    //   994: ifeq -> 967
    //   997: goto -> 1001
    //   1000: athrow
    //   1001: aload #8
    //   1003: iload #7
    //   1005: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1008: pop
    //   1009: aload_0
    //   1010: iload_1
    //   1011: ifne -> 1091
    //   1014: getfield A : Lorg/objectweb/asm/ByteVector;
    //   1017: ifnull -> 1090
    //   1020: goto -> 1024
    //   1023: athrow
    //   1024: aload #8
    //   1026: aload_0
    //   1027: sipush #18852
    //   1030: sipush #-23842
    //   1033: invokestatic b : (II)Ljava/lang/String;
    //   1036: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1039: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1042: pop
    //   1043: aload #8
    //   1045: aload_0
    //   1046: getfield A : Lorg/objectweb/asm/ByteVector;
    //   1049: getfield b : I
    //   1052: iconst_2
    //   1053: iadd
    //   1054: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1057: aload_0
    //   1058: getfield z : I
    //   1061: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1064: pop
    //   1065: aload #8
    //   1067: aload_0
    //   1068: getfield A : Lorg/objectweb/asm/ByteVector;
    //   1071: getfield a : [B
    //   1074: iconst_0
    //   1075: aload_0
    //   1076: getfield A : Lorg/objectweb/asm/ByteVector;
    //   1079: getfield b : I
    //   1082: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1085: pop
    //   1086: goto -> 1090
    //   1089: athrow
    //   1090: aload_0
    //   1091: getfield m : I
    //   1094: iload_1
    //   1095: ifne -> 1151
    //   1098: ifeq -> 1139
    //   1101: goto -> 1105
    //   1104: athrow
    //   1105: aload #8
    //   1107: aload_0
    //   1108: sipush #18854
    //   1111: sipush #-13025
    //   1114: invokestatic b : (II)Ljava/lang/String;
    //   1117: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1120: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1123: iconst_2
    //   1124: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1127: aload_0
    //   1128: getfield m : I
    //   1131: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1134: pop
    //   1135: goto -> 1139
    //   1138: athrow
    //   1139: aload_0
    //   1140: iload_1
    //   1141: ifne -> 1189
    //   1144: getfield q : I
    //   1147: goto -> 1151
    //   1150: athrow
    //   1151: ifeq -> 1188
    //   1154: aload #8
    //   1156: aload_0
    //   1157: sipush #18860
    //   1160: sipush #-12306
    //   1163: invokestatic b : (II)Ljava/lang/String;
    //   1166: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1169: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1172: iconst_2
    //   1173: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1176: aload_0
    //   1177: getfield q : I
    //   1180: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1183: pop
    //   1184: goto -> 1188
    //   1187: athrow
    //   1188: aload_0
    //   1189: iload_1
    //   1190: ifne -> 1253
    //   1193: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1196: ifnull -> 1252
    //   1199: goto -> 1203
    //   1202: athrow
    //   1203: aload_0
    //   1204: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1207: getfield b : I
    //   1210: istore #10
    //   1212: aload #8
    //   1214: aload_0
    //   1215: sipush #18850
    //   1218: sipush #-9342
    //   1221: invokestatic b : (II)Ljava/lang/String;
    //   1224: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1227: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1230: iload #10
    //   1232: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1235: pop
    //   1236: aload #8
    //   1238: aload_0
    //   1239: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1242: getfield a : [B
    //   1245: iconst_0
    //   1246: iload #10
    //   1248: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1251: pop
    //   1252: aload_0
    //   1253: getfield s : I
    //   1256: iload_1
    //   1257: ifne -> 1318
    //   1260: ifeq -> 1311
    //   1263: goto -> 1267
    //   1266: athrow
    //   1267: aload #8
    //   1269: aload_0
    //   1270: sipush #18859
    //   1273: sipush #-18332
    //   1276: invokestatic b : (II)Ljava/lang/String;
    //   1279: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1282: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1285: iconst_4
    //   1286: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1289: pop
    //   1290: aload #8
    //   1292: aload_0
    //   1293: getfield s : I
    //   1296: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1299: aload_0
    //   1300: getfield t : I
    //   1303: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1306: pop
    //   1307: goto -> 1311
    //   1310: athrow
    //   1311: aload_0
    //   1312: getfield k : I
    //   1315: ldc 131072
    //   1317: iand
    //   1318: iload_1
    //   1319: ifne -> 1372
    //   1322: ifeq -> 1356
    //   1325: goto -> 1329
    //   1328: athrow
    //   1329: aload #8
    //   1331: aload_0
    //   1332: sipush #18848
    //   1335: sipush #-10539
    //   1338: invokestatic b : (II)Ljava/lang/String;
    //   1341: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1344: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1347: iconst_0
    //   1348: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1351: pop
    //   1352: goto -> 1356
    //   1355: athrow
    //   1356: aload_0
    //   1357: iload_1
    //   1358: ifne -> 1449
    //   1361: getfield k : I
    //   1364: sipush #4096
    //   1367: iand
    //   1368: goto -> 1372
    //   1371: athrow
    //   1372: ifeq -> 1448
    //   1375: aload_0
    //   1376: getfield b : I
    //   1379: ldc 65535
    //   1381: iand
    //   1382: bipush #49
    //   1384: iload_1
    //   1385: ifne -> 1417
    //   1388: goto -> 1392
    //   1391: athrow
    //   1392: if_icmplt -> 1421
    //   1395: goto -> 1399
    //   1398: athrow
    //   1399: aload_0
    //   1400: iload_1
    //   1401: ifne -> 1449
    //   1404: goto -> 1408
    //   1407: athrow
    //   1408: getfield k : I
    //   1411: ldc 262144
    //   1413: goto -> 1417
    //   1416: athrow
    //   1417: iand
    //   1418: ifeq -> 1448
    //   1421: aload #8
    //   1423: aload_0
    //   1424: sipush #18849
    //   1427: sipush #-31450
    //   1430: invokestatic b : (II)Ljava/lang/String;
    //   1433: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1436: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1439: iconst_0
    //   1440: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1443: pop
    //   1444: goto -> 1448
    //   1447: athrow
    //   1448: aload_0
    //   1449: iload_1
    //   1450: ifne -> 1530
    //   1453: getfield y : Lorg/objectweb/asm/ByteVector;
    //   1456: ifnull -> 1529
    //   1459: goto -> 1463
    //   1462: athrow
    //   1463: aload #8
    //   1465: aload_0
    //   1466: sipush #18863
    //   1469: sipush #-18445
    //   1472: invokestatic b : (II)Ljava/lang/String;
    //   1475: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1478: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1481: pop
    //   1482: aload #8
    //   1484: aload_0
    //   1485: getfield y : Lorg/objectweb/asm/ByteVector;
    //   1488: getfield b : I
    //   1491: iconst_2
    //   1492: iadd
    //   1493: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1496: aload_0
    //   1497: getfield x : I
    //   1500: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1503: pop
    //   1504: aload #8
    //   1506: aload_0
    //   1507: getfield y : Lorg/objectweb/asm/ByteVector;
    //   1510: getfield a : [B
    //   1513: iconst_0
    //   1514: aload_0
    //   1515: getfield y : Lorg/objectweb/asm/ByteVector;
    //   1518: getfield b : I
    //   1521: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1524: pop
    //   1525: goto -> 1529
    //   1528: athrow
    //   1529: aload_0
    //   1530: getfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   1533: iload_1
    //   1534: ifne -> 1580
    //   1537: ifnull -> 1576
    //   1540: goto -> 1544
    //   1543: athrow
    //   1544: aload #8
    //   1546: aload_0
    //   1547: sipush #18861
    //   1550: sipush #16792
    //   1553: invokestatic b : (II)Ljava/lang/String;
    //   1556: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1559: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1562: pop
    //   1563: aload_0
    //   1564: getfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   1567: aload #8
    //   1569: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1572: goto -> 1576
    //   1575: athrow
    //   1576: aload_0
    //   1577: getfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   1580: iload_1
    //   1581: ifne -> 1627
    //   1584: ifnull -> 1623
    //   1587: goto -> 1591
    //   1590: athrow
    //   1591: aload #8
    //   1593: aload_0
    //   1594: sipush #18851
    //   1597: sipush #28209
    //   1600: invokestatic b : (II)Ljava/lang/String;
    //   1603: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1606: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1609: pop
    //   1610: aload_0
    //   1611: getfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   1614: aload #8
    //   1616: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1619: goto -> 1623
    //   1622: athrow
    //   1623: aload_0
    //   1624: getfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   1627: iload_1
    //   1628: ifne -> 1682
    //   1631: ifnull -> 1670
    //   1634: goto -> 1638
    //   1637: athrow
    //   1638: aload #8
    //   1640: aload_0
    //   1641: sipush #18853
    //   1644: sipush #21546
    //   1647: invokestatic b : (II)Ljava/lang/String;
    //   1650: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1653: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1656: pop
    //   1657: aload_0
    //   1658: getfield N : Lorg/objectweb/asm/AnnotationWriter;
    //   1661: aload #8
    //   1663: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1666: goto -> 1670
    //   1669: athrow
    //   1670: aload_0
    //   1671: iload_1
    //   1672: ifne -> 1718
    //   1675: getfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   1678: goto -> 1682
    //   1681: athrow
    //   1682: ifnull -> 1717
    //   1685: aload #8
    //   1687: aload_0
    //   1688: sipush #18862
    //   1691: sipush #11096
    //   1694: invokestatic b : (II)Ljava/lang/String;
    //   1697: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1700: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1703: pop
    //   1704: aload_0
    //   1705: getfield O : Lorg/objectweb/asm/AnnotationWriter;
    //   1708: aload #8
    //   1710: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1713: goto -> 1717
    //   1716: athrow
    //   1717: aload_0
    //   1718: iload_1
    //   1719: ifne -> 1751
    //   1722: getfield w : Lorg/objectweb/asm/Attribute;
    //   1725: ifnull -> 1750
    //   1728: goto -> 1732
    //   1731: athrow
    //   1732: aload_0
    //   1733: getfield w : Lorg/objectweb/asm/Attribute;
    //   1736: aload_0
    //   1737: aconst_null
    //   1738: iconst_0
    //   1739: iconst_m1
    //   1740: iconst_m1
    //   1741: aload #8
    //   1743: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIIILorg/objectweb/asm/ByteVector;)V
    //   1746: goto -> 1750
    //   1749: athrow
    //   1750: aload_0
    //   1751: iload_1
    //   1752: ifne -> 1844
    //   1755: getfield J : Z
    //   1758: ifeq -> 1848
    //   1761: goto -> 1765
    //   1764: athrow
    //   1765: aload_0
    //   1766: aconst_null
    //   1767: putfield u : Lorg/objectweb/asm/AnnotationWriter;
    //   1770: aload_0
    //   1771: aconst_null
    //   1772: putfield v : Lorg/objectweb/asm/AnnotationWriter;
    //   1775: aload_0
    //   1776: aconst_null
    //   1777: putfield w : Lorg/objectweb/asm/Attribute;
    //   1780: aload_0
    //   1781: iconst_0
    //   1782: putfield x : I
    //   1785: aload_0
    //   1786: aconst_null
    //   1787: putfield y : Lorg/objectweb/asm/ByteVector;
    //   1790: aload_0
    //   1791: aconst_null
    //   1792: putfield B : Lorg/objectweb/asm/FieldWriter;
    //   1795: aload_0
    //   1796: aconst_null
    //   1797: putfield C : Lorg/objectweb/asm/FieldWriter;
    //   1800: aload_0
    //   1801: aconst_null
    //   1802: putfield D : Lorg/objectweb/asm/MethodWriter;
    //   1805: aload_0
    //   1806: aconst_null
    //   1807: putfield E : Lorg/objectweb/asm/MethodWriter;
    //   1810: aload_0
    //   1811: iconst_1
    //   1812: putfield F : I
    //   1815: aload_0
    //   1816: iconst_0
    //   1817: putfield J : Z
    //   1820: new org/objectweb/asm/ClassReader
    //   1823: dup
    //   1824: aload #8
    //   1826: getfield a : [B
    //   1829: invokespecial <init> : ([B)V
    //   1832: aload_0
    //   1833: sipush #264
    //   1836: invokevirtual accept : (Lorg/objectweb/asm/ClassVisitor;I)V
    //   1839: aload_0
    //   1840: goto -> 1844
    //   1843: athrow
    //   1844: invokevirtual toByteArray : ()[B
    //   1847: areturn
    //   1848: aload #8
    //   1850: getfield a : [B
    //   1853: areturn
    // Exception table:
    //   from	to	target	type
    //   4	17	20	java/lang/IllegalArgumentException
    //   14	38	38	java/lang/IllegalArgumentException
    //   91	101	101	java/lang/IllegalArgumentException
    //   152	163	166	java/lang/IllegalArgumentException
    //   198	208	211	java/lang/IllegalArgumentException
    //   205	232	235	java/lang/IllegalArgumentException
    //   236	244	247	java/lang/IllegalArgumentException
    //   248	271	274	java/lang/IllegalArgumentException
    //   276	286	289	java/lang/IllegalArgumentException
    //   321	331	334	java/lang/IllegalArgumentException
    //   328	355	358	java/lang/IllegalArgumentException
    //   366	373	376	java/lang/IllegalArgumentException
    //   370	397	400	java/lang/IllegalArgumentException
    //   401	413	416	java/lang/IllegalArgumentException
    //   417	431	434	java/lang/IllegalArgumentException
    //   420	440	443	java/lang/IllegalArgumentException
    //   435	449	452	java/lang/IllegalArgumentException
    //   444	462	465	java/lang/IllegalArgumentException
    //   453	485	488	java/lang/IllegalArgumentException
    //   491	501	504	java/lang/IllegalArgumentException
    //   536	546	549	java/lang/IllegalArgumentException
    //   584	591	594	java/lang/IllegalArgumentException
    //   629	636	639	java/lang/IllegalArgumentException
    //   670	678	681	java/lang/IllegalArgumentException
    //   878	902	905	java/lang/IllegalArgumentException
    //   941	949	952	java/lang/IllegalArgumentException
    //   989	997	1000	java/lang/IllegalArgumentException
    //   1009	1020	1023	java/lang/IllegalArgumentException
    //   1014	1086	1089	java/lang/IllegalArgumentException
    //   1091	1101	1104	java/lang/IllegalArgumentException
    //   1098	1135	1138	java/lang/IllegalArgumentException
    //   1139	1147	1150	java/lang/IllegalArgumentException
    //   1151	1184	1187	java/lang/IllegalArgumentException
    //   1189	1199	1202	java/lang/IllegalArgumentException
    //   1253	1263	1266	java/lang/IllegalArgumentException
    //   1260	1307	1310	java/lang/IllegalArgumentException
    //   1318	1325	1328	java/lang/IllegalArgumentException
    //   1322	1352	1355	java/lang/IllegalArgumentException
    //   1356	1368	1371	java/lang/IllegalArgumentException
    //   1372	1388	1391	java/lang/IllegalArgumentException
    //   1375	1395	1398	java/lang/IllegalArgumentException
    //   1392	1404	1407	java/lang/IllegalArgumentException
    //   1399	1413	1416	java/lang/IllegalArgumentException
    //   1417	1444	1447	java/lang/IllegalArgumentException
    //   1449	1459	1462	java/lang/IllegalArgumentException
    //   1453	1525	1528	java/lang/IllegalArgumentException
    //   1530	1540	1543	java/lang/IllegalArgumentException
    //   1537	1572	1575	java/lang/IllegalArgumentException
    //   1580	1587	1590	java/lang/IllegalArgumentException
    //   1584	1619	1622	java/lang/IllegalArgumentException
    //   1627	1634	1637	java/lang/IllegalArgumentException
    //   1631	1666	1669	java/lang/IllegalArgumentException
    //   1670	1678	1681	java/lang/IllegalArgumentException
    //   1682	1713	1716	java/lang/IllegalArgumentException
    //   1718	1728	1731	java/lang/IllegalArgumentException
    //   1722	1746	1749	java/lang/IllegalArgumentException
    //   1751	1761	1764	java/lang/IllegalArgumentException
    //   1755	1840	1843	java/lang/IllegalArgumentException
  }
  
  Item a(Object paramObject) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (paramObject instanceof Integer) {
          int j = ((Integer)paramObject).intValue();
          return a(j);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Byte) {
          int j = ((Byte)paramObject).intValue();
          return a(j);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Character) {
          char c = ((Character)paramObject).charValue();
          return a(c);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Short) {
          int j = ((Short)paramObject).intValue();
          return a(j);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (paramObject instanceof Boolean)
            try {
              if (i == 0)
                if (((Boolean)paramObject).booleanValue()) {
                
                } else {
                  boolean bool = false;
                  return a(bool);
                }  
            } catch (IllegalArgumentException illegalArgumentException) {
              throw null;
            }  
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Float) {
          float f = ((Float)paramObject).floatValue();
          return a(f);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Long) {
          long l = ((Long)paramObject).longValue();
          return a(l);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (paramObject instanceof Double) {
          double d = ((Double)paramObject).doubleValue();
          return a(d);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        try {
          if (paramObject instanceof String)
            return b((String)paramObject); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0) {
        if (paramObject instanceof Type) {
          Type type = (Type)paramObject;
          int j = type.getSort();
          try {
            if (i == 0)
              try {
                if (j == 10)
                  return a(type.getInternalName()); 
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              }  
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          } 
          try {
            if (j == 11)
              return c(type.getDescriptor()); 
          } catch (IllegalArgumentException illegalArgumentException) {
            throw null;
          } 
          return a(type.getDescriptor());
        } 
        try {
          if (i == 0) {
          
          } else {
            Handle handle = (Handle)(paramObject instanceof Handle);
            return a(handle.a, handle.b, handle.c, handle.d, handle.e);
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    if (paramObject instanceof Type) {
      Handle handle = (Handle)paramObject;
      return a(handle.a, handle.b, handle.c, handle.d, handle.e);
    } 
    throw new IllegalArgumentException(b(18856, -25321) + paramObject);
  }
  
  public int newConst(Object paramObject) {
    return (a(paramObject)).a;
  }
  
  public int newUTF8(String paramString) {
    this.g.a(1, paramString, null, null);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.putByte(1).putUTF8(paramString);
          item = new Item(this.c++, this.g);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item.a;
  }
  
  Item a(String paramString) {
    this.h.a(7, paramString, null, null);
    Item item = a(this.h);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.b(7, newUTF8(paramString));
          item = new Item(this.c++, this.h);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  public int newClass(String paramString) {
    return (a(paramString)).a;
  }
  
  Item c(String paramString) {
    this.h.a(16, paramString, null, null);
    Item item = a(this.h);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.b(16, newUTF8(paramString));
          item = new Item(this.c++, this.h);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  public int newMethodType(String paramString) {
    return (c(paramString)).a;
  }
  
  Item a(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Lorg/objectweb/asm/Item;
    //   4: bipush #20
    //   6: iload_1
    //   7: iadd
    //   8: aload_2
    //   9: aload_3
    //   10: aload #4
    //   12: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   15: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   18: aload_0
    //   19: aload_0
    //   20: getfield j : Lorg/objectweb/asm/Item;
    //   23: invokespecial a : (Lorg/objectweb/asm/Item;)Lorg/objectweb/asm/Item;
    //   26: astore #7
    //   28: istore #6
    //   30: aload #7
    //   32: iload #6
    //   34: ifne -> 130
    //   37: ifnonnull -> 128
    //   40: goto -> 44
    //   43: athrow
    //   44: iload_1
    //   45: iconst_4
    //   46: if_icmpgt -> 77
    //   49: goto -> 53
    //   52: athrow
    //   53: aload_0
    //   54: bipush #15
    //   56: iload_1
    //   57: aload_0
    //   58: aload_2
    //   59: aload_3
    //   60: aload #4
    //   62: invokevirtual newField : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   65: invokespecial b : (III)V
    //   68: iload #6
    //   70: ifeq -> 98
    //   73: goto -> 77
    //   76: athrow
    //   77: aload_0
    //   78: bipush #15
    //   80: iload_1
    //   81: aload_0
    //   82: aload_2
    //   83: aload_3
    //   84: aload #4
    //   86: iload #5
    //   88: invokevirtual newMethod : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I
    //   91: invokespecial b : (III)V
    //   94: goto -> 98
    //   97: athrow
    //   98: new org/objectweb/asm/Item
    //   101: dup
    //   102: aload_0
    //   103: dup
    //   104: getfield c : I
    //   107: dup_x1
    //   108: iconst_1
    //   109: iadd
    //   110: putfield c : I
    //   113: aload_0
    //   114: getfield j : Lorg/objectweb/asm/Item;
    //   117: invokespecial <init> : (ILorg/objectweb/asm/Item;)V
    //   120: astore #7
    //   122: aload_0
    //   123: aload #7
    //   125: invokespecial b : (Lorg/objectweb/asm/Item;)V
    //   128: aload #7
    //   130: areturn
    // Exception table:
    //   from	to	target	type
    //   30	40	43	java/lang/IllegalArgumentException
    //   37	49	52	java/lang/IllegalArgumentException
    //   44	73	76	java/lang/IllegalArgumentException
    //   53	94	97	java/lang/IllegalArgumentException
  }
  
  public int newHandle(int paramInt, String paramString1, String paramString2, String paramString3) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
        
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return newHandle(paramInt, paramString1, paramString2, paramString3, (paramInt == 9));
  }
  
  public int newHandle(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    return (a(paramInt, paramString1, paramString2, paramString3, paramBoolean)).a;
  }
  
  Item a(String paramString1, String paramString2, Handle paramHandle, Object[] paramArrayOfObject) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: aload_0
    //   6: getfield A : Lorg/objectweb/asm/ByteVector;
    //   9: astore #6
    //   11: aload #6
    //   13: iload #5
    //   15: ifne -> 41
    //   18: ifnonnull -> 39
    //   21: goto -> 25
    //   24: athrow
    //   25: aload_0
    //   26: new org/objectweb/asm/ByteVector
    //   29: dup
    //   30: invokespecial <init> : ()V
    //   33: dup_x1
    //   34: putfield A : Lorg/objectweb/asm/ByteVector;
    //   37: astore #6
    //   39: aload #6
    //   41: getfield b : I
    //   44: istore #7
    //   46: aload_3
    //   47: invokevirtual hashCode : ()I
    //   50: istore #8
    //   52: aload #6
    //   54: aload_0
    //   55: aload_3
    //   56: getfield a : I
    //   59: aload_3
    //   60: getfield b : Ljava/lang/String;
    //   63: aload_3
    //   64: getfield c : Ljava/lang/String;
    //   67: aload_3
    //   68: getfield d : Ljava/lang/String;
    //   71: aload_3
    //   72: invokevirtual isInterface : ()Z
    //   75: invokevirtual newHandle : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I
    //   78: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   81: pop
    //   82: aload #4
    //   84: arraylength
    //   85: istore #9
    //   87: aload #6
    //   89: iload #9
    //   91: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   94: pop
    //   95: iconst_0
    //   96: istore #10
    //   98: iload #10
    //   100: iload #9
    //   102: if_icmpge -> 151
    //   105: aload #4
    //   107: iload #10
    //   109: aaload
    //   110: astore #11
    //   112: iload #8
    //   114: aload #11
    //   116: invokevirtual hashCode : ()I
    //   119: ixor
    //   120: istore #8
    //   122: aload #6
    //   124: aload_0
    //   125: aload #11
    //   127: invokevirtual newConst : (Ljava/lang/Object;)I
    //   130: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   133: iload #5
    //   135: ifne -> 153
    //   138: pop
    //   139: iinc #10, 1
    //   142: iload #5
    //   144: ifeq -> 98
    //   147: goto -> 151
    //   150: athrow
    //   151: aload #6
    //   153: getfield a : [B
    //   156: astore #10
    //   158: iconst_2
    //   159: iload #9
    //   161: iadd
    //   162: iconst_1
    //   163: ishl
    //   164: istore #11
    //   166: iload #8
    //   168: ldc 2147483647
    //   170: iand
    //   171: istore #8
    //   173: aload_0
    //   174: getfield e : [Lorg/objectweb/asm/Item;
    //   177: iload #8
    //   179: aload_0
    //   180: getfield e : [Lorg/objectweb/asm/Item;
    //   183: arraylength
    //   184: irem
    //   185: aaload
    //   186: astore #12
    //   188: aload #12
    //   190: ifnull -> 328
    //   193: aload #12
    //   195: iload #5
    //   197: ifne -> 253
    //   200: getfield b : I
    //   203: iload #5
    //   205: ifne -> 376
    //   208: goto -> 212
    //   211: athrow
    //   212: bipush #33
    //   214: if_icmpne -> 244
    //   217: goto -> 221
    //   220: athrow
    //   221: aload #12
    //   223: getfield j : I
    //   226: iload #5
    //   228: ifne -> 265
    //   231: goto -> 235
    //   234: athrow
    //   235: iload #8
    //   237: if_icmpeq -> 260
    //   240: goto -> 244
    //   243: athrow
    //   244: aload #12
    //   246: getfield k : Lorg/objectweb/asm/Item;
    //   249: goto -> 253
    //   252: athrow
    //   253: astore #12
    //   255: iload #5
    //   257: ifeq -> 188
    //   260: aload #12
    //   262: getfield c : I
    //   265: istore #13
    //   267: iconst_0
    //   268: istore #14
    //   270: iload #14
    //   272: iload #11
    //   274: if_icmpge -> 325
    //   277: aload #10
    //   279: iload #7
    //   281: iload #14
    //   283: iadd
    //   284: baload
    //   285: iload #5
    //   287: ifne -> 376
    //   290: aload #10
    //   292: iload #13
    //   294: iload #14
    //   296: iadd
    //   297: baload
    //   298: if_icmpeq -> 317
    //   301: goto -> 305
    //   304: athrow
    //   305: aload #12
    //   307: getfield k : Lorg/objectweb/asm/Item;
    //   310: astore #12
    //   312: iload #5
    //   314: ifeq -> 188
    //   317: iinc #14, 1
    //   320: iload #5
    //   322: ifeq -> 270
    //   325: goto -> 328
    //   328: aload #12
    //   330: iload #5
    //   332: ifne -> 344
    //   335: ifnull -> 361
    //   338: goto -> 342
    //   341: athrow
    //   342: aload #12
    //   344: getfield a : I
    //   347: istore #13
    //   349: aload #6
    //   351: iload #7
    //   353: putfield b : I
    //   356: iload #5
    //   358: ifeq -> 404
    //   361: aload_0
    //   362: dup
    //   363: getfield z : I
    //   366: dup_x1
    //   367: iconst_1
    //   368: iadd
    //   369: putfield z : I
    //   372: goto -> 376
    //   375: athrow
    //   376: istore #13
    //   378: new org/objectweb/asm/Item
    //   381: dup
    //   382: iload #13
    //   384: invokespecial <init> : (I)V
    //   387: astore #12
    //   389: aload #12
    //   391: iload #7
    //   393: iload #8
    //   395: invokevirtual a : (II)V
    //   398: aload_0
    //   399: aload #12
    //   401: invokespecial b : (Lorg/objectweb/asm/Item;)V
    //   404: aload_0
    //   405: getfield i : Lorg/objectweb/asm/Item;
    //   408: aload_1
    //   409: aload_2
    //   410: iload #13
    //   412: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;I)V
    //   415: aload_0
    //   416: aload_0
    //   417: getfield i : Lorg/objectweb/asm/Item;
    //   420: invokespecial a : (Lorg/objectweb/asm/Item;)Lorg/objectweb/asm/Item;
    //   423: astore #12
    //   425: aload #12
    //   427: iload #5
    //   429: ifne -> 485
    //   432: ifnonnull -> 483
    //   435: goto -> 439
    //   438: athrow
    //   439: aload_0
    //   440: bipush #18
    //   442: iload #13
    //   444: aload_0
    //   445: aload_1
    //   446: aload_2
    //   447: invokevirtual newNameType : (Ljava/lang/String;Ljava/lang/String;)I
    //   450: invokespecial a : (III)V
    //   453: new org/objectweb/asm/Item
    //   456: dup
    //   457: aload_0
    //   458: dup
    //   459: getfield c : I
    //   462: dup_x1
    //   463: iconst_1
    //   464: iadd
    //   465: putfield c : I
    //   468: aload_0
    //   469: getfield i : Lorg/objectweb/asm/Item;
    //   472: invokespecial <init> : (ILorg/objectweb/asm/Item;)V
    //   475: astore #12
    //   477: aload_0
    //   478: aload #12
    //   480: invokespecial b : (Lorg/objectweb/asm/Item;)V
    //   483: aload #12
    //   485: areturn
    // Exception table:
    //   from	to	target	type
    //   11	21	24	java/lang/IllegalArgumentException
    //   122	147	150	java/lang/IllegalArgumentException
    //   193	208	211	java/lang/IllegalArgumentException
    //   200	217	220	java/lang/IllegalArgumentException
    //   212	231	234	java/lang/IllegalArgumentException
    //   221	240	243	java/lang/IllegalArgumentException
    //   235	249	252	java/lang/IllegalArgumentException
    //   277	301	304	java/lang/IllegalArgumentException
    //   328	338	341	java/lang/IllegalArgumentException
    //   349	372	375	java/lang/IllegalArgumentException
    //   425	435	438	java/lang/IllegalArgumentException
  }
  
  public int newInvokeDynamic(String paramString1, String paramString2, Handle paramHandle, Object[] paramArrayOfObject) {
    return (a(paramString1, paramString2, paramHandle, paramArrayOfObject)).a;
  }
  
  Item a(String paramString1, String paramString2, String paramString3) {
    this.i.a(9, paramString1, paramString2, paramString3);
    Item item = a(this.i);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          a(9, newClass(paramString1), newNameType(paramString2, paramString3));
          item = new Item(this.c++, this.i);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  public int newField(String paramString1, String paramString2, String paramString3) {
    return (a(paramString1, paramString2, paramString3)).a;
  }
  
  Item a(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (paramBoolean) {
        
        } else {
          byte b = 10;
          this.i.a(b, paramString1, paramString2, paramString3);
          Item item = a(this.i);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
  }
  
  public int newMethod(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    return (a(paramString1, paramString2, paramString3, paramBoolean)).a;
  }
  
  Item a(int paramInt) {
    this.g.a(paramInt);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.putByte(3).putInt(paramInt);
          item = new Item(this.c++, this.g);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  Item a(float paramFloat) {
    this.g.a(paramFloat);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.putByte(4).putInt(this.g.c);
          item = new Item(this.c++, this.g);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  Item a(long paramLong) {
    this.g.a(paramLong);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.putByte(5).putLong(paramLong);
          item = new Item(this.c, this.g);
          this.c += 2;
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  Item a(double paramDouble) {
    this.g.a(paramDouble);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.putByte(6).putLong(this.g.d);
          item = new Item(this.c, this.g);
          this.c += 2;
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  private Item b(String paramString) {
    this.h.a(8, paramString, null, null);
    Item item = a(this.h);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          this.d.b(8, newUTF8(paramString));
          item = new Item(this.c++, this.h);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  public int newNameType(String paramString1, String paramString2) {
    return (a(paramString1, paramString2)).a;
  }
  
  Item a(String paramString1, String paramString2) {
    this.h.a(12, paramString1, paramString2, null);
    Item item = a(this.h);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null) {
          a(12, newUTF8(paramString1), newUTF8(paramString2));
          item = new Item(this.c++, this.h);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item;
  }
  
  int c(String paramString) {
    this.g.a(30, paramString, null, null);
    Item item = a(this.g);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        if (item == null)
          item = c(this.g);  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item.a;
  }
  
  int a(String paramString, int paramInt) {
    this.g.b = 31;
    this.g.c = paramInt;
    this.g.g = paramString;
    this.g.j = Integer.MAX_VALUE & 31 + paramString.hashCode() + paramInt;
    int i = MethodVisitor.b;
    Item item = a(this.g);
    try {
      if (i == 0)
        if (item == null)
          item = c(this.g);  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item.a;
  }
  
  private Item c(Item paramItem) {
    this.G = (short)(this.G + 1);
    Item item = new Item(this.G, this.g);
    b(item);
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (this.H == null)
            this.H = new Item[16]; 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (i == 0)
        if (this.G == this.H.length) {
          Item[] arrayOfItem = new Item[2 * this.H.length];
          System.arraycopy(this.H, 0, arrayOfItem, 0, this.H.length);
          this.H = arrayOfItem;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    this.H[this.G] = item;
    return item;
  }
  
  int a(int paramInt1, int paramInt2) {
    this.h.b = 32;
    this.h.d = paramInt1 | paramInt2 << 32L;
    int i = MethodVisitor.b;
    this.h.j = Integer.MAX_VALUE & 32 + paramInt1 + paramInt2;
    Item item = a(this.h);
    try {
      if (i == 0)
        if (item == null) {
          String str1 = (this.H[paramInt1]).g;
          String str2 = (this.H[paramInt2]).g;
          this.h.c = c(getCommonSuperClass(str1, str2));
          item = new Item(0, this.h);
          b(item);
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return item.c;
  }
  
  protected String getCommonSuperClass(String paramString1, String paramString2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: invokevirtual getClass : ()Ljava/lang/Class;
    //   8: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   11: astore #6
    //   13: aload_1
    //   14: bipush #47
    //   16: bipush #46
    //   18: invokevirtual replace : (CC)Ljava/lang/String;
    //   21: iconst_0
    //   22: aload #6
    //   24: dup2_x1
    //   25: pop2
    //   26: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   29: dup_x2
    //   30: pop
    //   31: invokestatic forName : (Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    //   34: astore #4
    //   36: aload_2
    //   37: bipush #47
    //   39: bipush #46
    //   41: invokevirtual replace : (CC)Ljava/lang/String;
    //   44: iconst_0
    //   45: aload #6
    //   47: dup2_x1
    //   48: pop2
    //   49: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   52: dup_x2
    //   53: pop
    //   54: invokestatic forName : (Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    //   57: astore #5
    //   59: goto -> 77
    //   62: astore #7
    //   64: new java/lang/RuntimeException
    //   67: dup
    //   68: aload #7
    //   70: invokevirtual toString : ()Ljava/lang/String;
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: athrow
    //   77: aload #4
    //   79: aload #5
    //   81: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   84: iload_3
    //   85: ifne -> 105
    //   88: ifeq -> 98
    //   91: goto -> 95
    //   94: athrow
    //   95: aload_1
    //   96: areturn
    //   97: athrow
    //   98: aload #5
    //   100: aload #4
    //   102: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   105: iload_3
    //   106: ifne -> 124
    //   109: ifeq -> 119
    //   112: goto -> 116
    //   115: athrow
    //   116: aload_2
    //   117: areturn
    //   118: athrow
    //   119: aload #4
    //   121: invokevirtual isInterface : ()Z
    //   124: iload_3
    //   125: ifne -> 144
    //   128: ifne -> 155
    //   131: goto -> 135
    //   134: athrow
    //   135: aload #5
    //   137: invokevirtual isInterface : ()Z
    //   140: goto -> 144
    //   143: athrow
    //   144: iload_3
    //   145: ifne -> 180
    //   148: ifeq -> 166
    //   151: goto -> 155
    //   154: athrow
    //   155: sipush #18858
    //   158: sipush #-2478
    //   161: invokestatic b : (II)Ljava/lang/String;
    //   164: areturn
    //   165: athrow
    //   166: aload #4
    //   168: invokevirtual getSuperclass : ()Ljava/lang/Class;
    //   171: astore #4
    //   173: aload #4
    //   175: aload #5
    //   177: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   180: ifeq -> 166
    //   183: aload #4
    //   185: iload_3
    //   186: ifne -> 175
    //   189: invokevirtual getName : ()Ljava/lang/String;
    //   192: bipush #46
    //   194: bipush #47
    //   196: invokevirtual replace : (CC)Ljava/lang/String;
    //   199: areturn
    // Exception table:
    //   from	to	target	type
    //   13	59	62	java/lang/Exception
    //   77	91	94	java/lang/Exception
    //   88	97	97	java/lang/Exception
    //   105	112	115	java/lang/Exception
    //   109	118	118	java/lang/Exception
    //   124	131	134	java/lang/Exception
    //   128	140	143	java/lang/Exception
    //   144	151	154	java/lang/Exception
    //   148	165	165	java/lang/Exception
  }
  
  private Item a(Item paramItem) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield e : [Lorg/objectweb/asm/Item;
    //   8: aload_1
    //   9: getfield j : I
    //   12: aload_0
    //   13: getfield e : [Lorg/objectweb/asm/Item;
    //   16: arraylength
    //   17: irem
    //   18: aaload
    //   19: astore_3
    //   20: aload_3
    //   21: ifnull -> 84
    //   24: aload_3
    //   25: iload_2
    //   26: ifne -> 85
    //   29: iload_2
    //   30: ifne -> 79
    //   33: goto -> 37
    //   36: athrow
    //   37: getfield b : I
    //   40: aload_1
    //   41: getfield b : I
    //   44: if_icmpne -> 71
    //   47: goto -> 51
    //   50: athrow
    //   51: aload_1
    //   52: iload_2
    //   53: ifne -> 85
    //   56: goto -> 60
    //   59: athrow
    //   60: aload_3
    //   61: invokevirtual a : (Lorg/objectweb/asm/Item;)Z
    //   64: ifne -> 84
    //   67: goto -> 71
    //   70: athrow
    //   71: aload_3
    //   72: getfield k : Lorg/objectweb/asm/Item;
    //   75: goto -> 79
    //   78: athrow
    //   79: astore_3
    //   80: iload_2
    //   81: ifeq -> 20
    //   84: aload_3
    //   85: areturn
    // Exception table:
    //   from	to	target	type
    //   24	33	36	java/lang/IllegalArgumentException
    //   29	47	50	java/lang/IllegalArgumentException
    //   37	56	59	java/lang/IllegalArgumentException
    //   51	67	70	java/lang/IllegalArgumentException
    //   60	75	78	java/lang/IllegalArgumentException
  }
  
  private void b(Item paramItem) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield c : I
    //   8: aload_0
    //   9: getfield G : S
    //   12: iadd
    //   13: aload_0
    //   14: getfield f : I
    //   17: iload_2
    //   18: ifne -> 161
    //   21: if_icmple -> 152
    //   24: goto -> 28
    //   27: athrow
    //   28: aload_0
    //   29: getfield e : [Lorg/objectweb/asm/Item;
    //   32: arraylength
    //   33: istore_3
    //   34: iload_3
    //   35: iconst_2
    //   36: imul
    //   37: iconst_1
    //   38: iadd
    //   39: istore #4
    //   41: iload #4
    //   43: anewarray org/objectweb/asm/Item
    //   46: astore #5
    //   48: iload_3
    //   49: iconst_1
    //   50: isub
    //   51: istore #6
    //   53: iload #6
    //   55: iflt -> 134
    //   58: aload_0
    //   59: getfield e : [Lorg/objectweb/asm/Item;
    //   62: iload #6
    //   64: aaload
    //   65: iload_2
    //   66: ifne -> 164
    //   69: astore #7
    //   71: aload #7
    //   73: ifnull -> 127
    //   76: aload #7
    //   78: getfield j : I
    //   81: aload #5
    //   83: arraylength
    //   84: irem
    //   85: istore #8
    //   87: aload #7
    //   89: getfield k : Lorg/objectweb/asm/Item;
    //   92: astore #9
    //   94: aload #7
    //   96: aload #5
    //   98: iload #8
    //   100: aaload
    //   101: putfield k : Lorg/objectweb/asm/Item;
    //   104: aload #5
    //   106: iload #8
    //   108: aload #7
    //   110: aastore
    //   111: aload #9
    //   113: astore #7
    //   115: iload_2
    //   116: ifne -> 130
    //   119: iload_2
    //   120: ifeq -> 71
    //   123: goto -> 127
    //   126: athrow
    //   127: iinc #6, -1
    //   130: iload_2
    //   131: ifeq -> 53
    //   134: aload_0
    //   135: aload #5
    //   137: putfield e : [Lorg/objectweb/asm/Item;
    //   140: aload_0
    //   141: iload #4
    //   143: i2d
    //   144: ldc2_w 0.75
    //   147: dmul
    //   148: d2i
    //   149: putfield f : I
    //   152: aload_1
    //   153: getfield j : I
    //   156: aload_0
    //   157: getfield e : [Lorg/objectweb/asm/Item;
    //   160: arraylength
    //   161: irem
    //   162: istore_3
    //   163: aload_1
    //   164: aload_0
    //   165: getfield e : [Lorg/objectweb/asm/Item;
    //   168: iload_3
    //   169: aaload
    //   170: putfield k : Lorg/objectweb/asm/Item;
    //   173: aload_0
    //   174: getfield e : [Lorg/objectweb/asm/Item;
    //   177: iload_3
    //   178: aload_1
    //   179: aastore
    //   180: return
    // Exception table:
    //   from	to	target	type
    //   4	24	27	java/lang/IllegalArgumentException
    //   115	123	126	java/lang/IllegalArgumentException
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3) {
    this.d.b(paramInt1, paramInt2).putShort(paramInt3);
  }
  
  private void b(int paramInt1, int paramInt2, int paramInt3) {
    this.d.a(paramInt1, paramInt2).putShort(paramInt3);
  }
  
  static {
    // Byte code:
    //   0: bipush #16
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc 'húCQ\£¬Ñów3½)÷x© ¥i§G!RIê³Ø½ásÊ¸u\\t¥c¼!ô÷¯\\bÉ2JªClÁß¤?ú°Ïô\\n¤w×0¢æÞ\\tÒ&ÉÊ¡ ª³L4ûn|_|ÐÔîKñ×¯ÈB4,ÇØ¯eëð^,Å¯ã÷M<b§=HÅ\\nED õJ¿×?ðý âWSzçê8½>´YWòÛ¬zõbãsóÉmÙæ-½;ÿ\\fËöàóûQY£Gßè!\\f¨À0&IZ]ó¾þ|ÊÄ¦X÷ÜÔIùÞ»u~ÝàÛ\\nyAý«ÞµE<÷,pD\\n'cg<(ÐñCWÃnSÎº4}ãÞª\úkÉïº­:§Õv9J|©·¤¢y{Oyë,­hmE¯«%sglï]bNÓ\\fPñÚÓtAøï0±æÍóÖh6,íå«¾v#Ïïþ2?-úÆ=i+cdïL¬Çÿðo~ûÍ|od,G÷þJ)(ÁÒÒÝW©üÿÐÆUëÒ]xÿO¾{x-åÃ'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #16
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: jsr -> 137
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 23
    //   65: ldc '³\\f$Ó¢å3ZÂjÏØ&,aOø,\\tÐÇÏ'
    //   67: dup
    //   68: astore_2
    //   69: invokevirtual length : ()I
    //   72: istore #4
    //   74: bipush #16
    //   76: istore_1
    //   77: iconst_m1
    //   78: istore_0
    //   79: iinc #0, 1
    //   82: aload_2
    //   83: iload_0
    //   84: dup
    //   85: iload_1
    //   86: iadd
    //   87: invokevirtual substring : (II)Ljava/lang/String;
    //   90: jsr -> 137
    //   93: aload #5
    //   95: swap
    //   96: iload_3
    //   97: iinc #3, 1
    //   100: swap
    //   101: aastore
    //   102: iload_0
    //   103: iload_1
    //   104: iadd
    //   105: dup
    //   106: istore_0
    //   107: iload #4
    //   109: if_icmpge -> 121
    //   112: aload_2
    //   113: iload_0
    //   114: invokevirtual charAt : (I)C
    //   117: istore_1
    //   118: goto -> 79
    //   121: aload #5
    //   123: putstatic org/objectweb/asm/ClassWriter.L : [Ljava/lang/String;
    //   126: bipush #16
    //   128: anewarray java/lang/String
    //   131: putstatic org/objectweb/asm/ClassWriter.M : [Ljava/lang/String;
    //   134: goto -> 278
    //   137: astore #6
    //   139: invokevirtual toCharArray : ()[C
    //   142: dup
    //   143: arraylength
    //   144: swap
    //   145: iconst_0
    //   146: istore #7
    //   148: swap
    //   149: dup_x1
    //   150: iconst_1
    //   151: if_icmpgt -> 256
    //   154: dup
    //   155: iload #7
    //   157: dup2
    //   158: caload
    //   159: iload #7
    //   161: bipush #7
    //   163: irem
    //   164: tableswitch default -> 237, 0 -> 204, 1 -> 209, 2 -> 215, 3 -> 221, 4 -> 226, 5 -> 232
    //   204: bipush #87
    //   206: goto -> 240
    //   209: sipush #212
    //   212: goto -> 240
    //   215: sipush #193
    //   218: goto -> 240
    //   221: bipush #98
    //   223: goto -> 240
    //   226: sipush #253
    //   229: goto -> 240
    //   232: bipush #75
    //   234: goto -> 240
    //   237: sipush #247
    //   240: ixor
    //   241: i2c
    //   242: castore
    //   243: iinc #7, 1
    //   246: swap
    //   247: dup_x1
    //   248: ifne -> 256
    //   251: dup2
    //   252: swap
    //   253: goto -> 157
    //   256: swap
    //   257: dup_x1
    //   258: iload #7
    //   260: if_icmpgt -> 154
    //   263: new java/lang/String
    //   266: dup_x1
    //   267: swap
    //   268: invokespecial <init> : ([C)V
    //   271: invokevirtual intern : ()Ljava/lang/String;
    //   274: swap
    //   275: pop
    //   276: ret #6
    //   278: invokestatic _clinit_ : ()V
    //   281: sipush #220
    //   284: newarray byte
    //   286: astore #9
    //   288: sipush #18857
    //   291: sipush #30814
    //   294: invokestatic b : (II)Ljava/lang/String;
    //   297: astore #10
    //   299: iconst_0
    //   300: istore #8
    //   302: iload #8
    //   304: aload #9
    //   306: arraylength
    //   307: if_icmpge -> 333
    //   310: aload #9
    //   312: iload #8
    //   314: aload #10
    //   316: iload #8
    //   318: invokevirtual charAt : (I)C
    //   321: bipush #65
    //   323: isub
    //   324: i2b
    //   325: bastore
    //   326: iinc #8, 1
    //   329: goto -> 302
    //   332: athrow
    //   333: aload #9
    //   335: putstatic org/objectweb/asm/ClassWriter.a : [B
    //   338: return
    // Exception table:
    //   from	to	target	type
    //   302	332	332	java/lang/IllegalArgumentException
  }
  
  static void _clinit_() {}
  
  private static String b(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0x49A4) & 0xFFFF;
    if (M[i] == null) {
      char[] arrayOfChar = L[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 61;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      M[i] = (new String(arrayOfChar)).intern();
    } 
    return M[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\ClassWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */