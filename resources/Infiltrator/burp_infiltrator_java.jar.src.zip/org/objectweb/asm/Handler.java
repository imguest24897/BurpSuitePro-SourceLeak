package org.objectweb.asm;

class Handler {
  Label a;
  
  Label b;
  
  Label c;
  
  String d;
  
  int e;
  
  Handler f;
  
  static Handler a(Handler paramHandler, Label paramLabel1, Label paramLabel2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: iload_3
    //   6: ifne -> 28
    //   9: ifnonnull -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload_0
    //   15: aload_0
    //   16: getfield f : Lorg/objectweb/asm/Handler;
    //   19: aload_1
    //   20: aload_2
    //   21: invokestatic a : (Lorg/objectweb/asm/Handler;Lorg/objectweb/asm/Label;Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Handler;
    //   24: putfield f : Lorg/objectweb/asm/Handler;
    //   27: aload_0
    //   28: getfield a : Lorg/objectweb/asm/Label;
    //   31: getfield c : I
    //   34: istore #4
    //   36: aload_0
    //   37: getfield b : Lorg/objectweb/asm/Label;
    //   40: getfield c : I
    //   43: istore #5
    //   45: aload_1
    //   46: getfield c : I
    //   49: istore #6
    //   51: aload_2
    //   52: iload_3
    //   53: ifne -> 65
    //   56: ifnonnull -> 64
    //   59: ldc 2147483647
    //   61: goto -> 68
    //   64: aload_2
    //   65: getfield c : I
    //   68: istore #7
    //   70: iload #6
    //   72: iload #5
    //   74: iload_3
    //   75: ifne -> 85
    //   78: if_icmpge -> 215
    //   81: iload #7
    //   83: iload #4
    //   85: iload_3
    //   86: ifne -> 96
    //   89: if_icmple -> 215
    //   92: iload #6
    //   94: iload #4
    //   96: iload_3
    //   97: ifne -> 132
    //   100: if_icmpgt -> 128
    //   103: iload #7
    //   105: iload #5
    //   107: if_icmplt -> 119
    //   110: aload_0
    //   111: getfield f : Lorg/objectweb/asm/Handler;
    //   114: astore_0
    //   115: iload_3
    //   116: ifeq -> 215
    //   119: aload_0
    //   120: aload_2
    //   121: putfield a : Lorg/objectweb/asm/Label;
    //   124: iload_3
    //   125: ifeq -> 215
    //   128: iload #7
    //   130: iload #5
    //   132: if_icmplt -> 144
    //   135: aload_0
    //   136: aload_1
    //   137: putfield b : Lorg/objectweb/asm/Label;
    //   140: iload_3
    //   141: ifeq -> 215
    //   144: new org/objectweb/asm/Handler
    //   147: dup
    //   148: invokespecial <init> : ()V
    //   151: astore #8
    //   153: aload #8
    //   155: aload_2
    //   156: putfield a : Lorg/objectweb/asm/Label;
    //   159: aload #8
    //   161: aload_0
    //   162: getfield b : Lorg/objectweb/asm/Label;
    //   165: putfield b : Lorg/objectweb/asm/Label;
    //   168: aload #8
    //   170: aload_0
    //   171: getfield c : Lorg/objectweb/asm/Label;
    //   174: putfield c : Lorg/objectweb/asm/Label;
    //   177: aload #8
    //   179: aload_0
    //   180: getfield d : Ljava/lang/String;
    //   183: putfield d : Ljava/lang/String;
    //   186: aload #8
    //   188: aload_0
    //   189: getfield e : I
    //   192: putfield e : I
    //   195: aload #8
    //   197: aload_0
    //   198: getfield f : Lorg/objectweb/asm/Handler;
    //   201: putfield f : Lorg/objectweb/asm/Handler;
    //   204: aload_0
    //   205: aload_1
    //   206: putfield b : Lorg/objectweb/asm/Label;
    //   209: aload_0
    //   210: aload #8
    //   212: putfield f : Lorg/objectweb/asm/Handler;
    //   215: aload_0
    //   216: areturn
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */