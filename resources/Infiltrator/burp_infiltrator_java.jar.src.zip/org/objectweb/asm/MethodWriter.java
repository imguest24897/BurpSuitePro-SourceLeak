package org.objectweb.asm;

class MethodWriter extends MethodVisitor {
  final ClassWriter b;
  
  private int c;
  
  private final int d;
  
  private final int e;
  
  private final String f;
  
  String g;
  
  int h;
  
  int i;
  
  int j;
  
  int[] k;
  
  private ByteVector l;
  
  private AnnotationWriter m;
  
  private AnnotationWriter n;
  
  private AnnotationWriter U;
  
  private AnnotationWriter V;
  
  private AnnotationWriter[] o;
  
  private AnnotationWriter[] p;
  
  private int R;
  
  private Attribute q;
  
  private ByteVector r;
  
  private int s;
  
  private int t;
  
  private int T;
  
  private int u;
  
  private ByteVector v;
  
  private int w;
  
  private int[] x;
  
  private int[] z;
  
  private int A;
  
  private Handler B;
  
  private Handler C;
  
  private int Z;
  
  private ByteVector $;
  
  private int D;
  
  private ByteVector E;
  
  private int F;
  
  private ByteVector G;
  
  private int H;
  
  private ByteVector I;
  
  private int Y;
  
  private AnnotationWriter W;
  
  private AnnotationWriter X;
  
  private Attribute J;
  
  private int K;
  
  private final int L;
  
  private Label M;
  
  private Label N;
  
  private Label O;
  
  private int P;
  
  private int Q;
  
  private static final String[] y;
  
  private static final String[] S;
  
  MethodWriter(ClassWriter paramClassWriter, int paramInt1, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: ldc 327680
    //   3: invokespecial <init> : (I)V
    //   6: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   9: aload_0
    //   10: new org/objectweb/asm/ByteVector
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield r : Lorg/objectweb/asm/ByteVector;
    //   20: istore #8
    //   22: aload_1
    //   23: getfield D : Lorg/objectweb/asm/MethodWriter;
    //   26: iload #8
    //   28: ifne -> 60
    //   31: ifnonnull -> 52
    //   34: goto -> 38
    //   37: athrow
    //   38: aload_1
    //   39: aload_0
    //   40: putfield D : Lorg/objectweb/asm/MethodWriter;
    //   43: iload #8
    //   45: ifeq -> 64
    //   48: goto -> 52
    //   51: athrow
    //   52: aload_1
    //   53: getfield E : Lorg/objectweb/asm/MethodWriter;
    //   56: goto -> 60
    //   59: athrow
    //   60: aload_0
    //   61: putfield mv : Lorg/objectweb/asm/MethodVisitor;
    //   64: aload_1
    //   65: aload_0
    //   66: putfield E : Lorg/objectweb/asm/MethodWriter;
    //   69: aload_0
    //   70: aload_1
    //   71: putfield b : Lorg/objectweb/asm/ClassWriter;
    //   74: aload_0
    //   75: iload_2
    //   76: putfield c : I
    //   79: iload #8
    //   81: ifne -> 150
    //   84: sipush #-21099
    //   87: sipush #-30831
    //   90: invokestatic b : (II)Ljava/lang/String;
    //   93: aload_3
    //   94: invokevirtual equals : (Ljava/lang/Object;)Z
    //   97: ifeq -> 119
    //   100: goto -> 104
    //   103: athrow
    //   104: aload_0
    //   105: dup
    //   106: getfield c : I
    //   109: ldc 524288
    //   111: ior
    //   112: putfield c : I
    //   115: goto -> 119
    //   118: athrow
    //   119: aload_0
    //   120: aload_1
    //   121: aload_3
    //   122: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   125: putfield d : I
    //   128: aload_0
    //   129: aload_1
    //   130: aload #4
    //   132: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   135: putfield e : I
    //   138: aload_0
    //   139: aload #4
    //   141: putfield f : Ljava/lang/String;
    //   144: aload_0
    //   145: aload #5
    //   147: putfield g : Ljava/lang/String;
    //   150: iload #8
    //   152: ifne -> 251
    //   155: aload #6
    //   157: ifnull -> 245
    //   160: goto -> 164
    //   163: athrow
    //   164: aload #6
    //   166: arraylength
    //   167: iload #8
    //   169: ifne -> 253
    //   172: goto -> 176
    //   175: athrow
    //   176: ifle -> 245
    //   179: goto -> 183
    //   182: athrow
    //   183: aload_0
    //   184: aload #6
    //   186: arraylength
    //   187: putfield j : I
    //   190: aload_0
    //   191: aload_0
    //   192: getfield j : I
    //   195: newarray int
    //   197: putfield k : [I
    //   200: iconst_0
    //   201: istore #9
    //   203: iload #9
    //   205: aload_0
    //   206: getfield j : I
    //   209: if_icmpge -> 245
    //   212: aload_0
    //   213: getfield k : [I
    //   216: iload #9
    //   218: aload_1
    //   219: aload #6
    //   221: iload #9
    //   223: aaload
    //   224: invokevirtual newClass : (Ljava/lang/String;)I
    //   227: iastore
    //   228: iinc #9, 1
    //   231: iload #8
    //   233: ifne -> 251
    //   236: iload #8
    //   238: ifeq -> 203
    //   241: goto -> 245
    //   244: athrow
    //   245: aload_0
    //   246: iload #7
    //   248: putfield L : I
    //   251: iload #7
    //   253: iconst_3
    //   254: iload #8
    //   256: ifne -> 278
    //   259: if_icmpeq -> 349
    //   262: goto -> 266
    //   265: athrow
    //   266: aload_0
    //   267: getfield f : Ljava/lang/String;
    //   270: invokestatic getArgumentsAndReturnSizes : (Ljava/lang/String;)I
    //   273: iconst_2
    //   274: goto -> 278
    //   277: athrow
    //   278: ishr
    //   279: istore #9
    //   281: iload #8
    //   283: ifne -> 341
    //   286: iload_2
    //   287: bipush #8
    //   289: iand
    //   290: ifeq -> 304
    //   293: goto -> 297
    //   296: athrow
    //   297: iinc #9, -1
    //   300: goto -> 304
    //   303: athrow
    //   304: aload_0
    //   305: iload #9
    //   307: putfield t : I
    //   310: aload_0
    //   311: iload #9
    //   313: putfield T : I
    //   316: aload_0
    //   317: new org/objectweb/asm/Label
    //   320: dup
    //   321: invokespecial <init> : ()V
    //   324: putfield M : Lorg/objectweb/asm/Label;
    //   327: aload_0
    //   328: getfield M : Lorg/objectweb/asm/Label;
    //   331: dup
    //   332: getfield a : I
    //   335: bipush #8
    //   337: ior
    //   338: putfield a : I
    //   341: aload_0
    //   342: aload_0
    //   343: getfield M : Lorg/objectweb/asm/Label;
    //   346: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   349: return
    // Exception table:
    //   from	to	target	type
    //   22	34	37	java/lang/IllegalStateException
    //   31	48	51	java/lang/IllegalStateException
    //   38	56	59	java/lang/IllegalStateException
    //   64	100	103	java/lang/IllegalStateException
    //   84	115	118	java/lang/IllegalStateException
    //   150	160	163	java/lang/IllegalStateException
    //   155	172	175	java/lang/IllegalStateException
    //   164	179	182	java/lang/IllegalStateException
    //   212	241	244	java/lang/IllegalStateException
    //   253	262	265	java/lang/IllegalStateException
    //   259	274	277	java/lang/IllegalStateException
    //   281	293	296	java/lang/IllegalStateException
    //   286	300	303	java/lang/IllegalStateException
  }
  
  public void visitParameter(String paramString, int paramInt) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.$ == null)
            this.$ = new ByteVector(); 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        this.Z++;
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    try {
    
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.$.putShort((paramString == null) ? 0 : this.b.newUTF8(paramString)).putShort(paramInt);
  }
  
  public AnnotationVisitor visitAnnotationDefault() {
    this.l = new ByteVector();
    return new AnnotationWriter(this.b, false, this.l, null, 0);
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   12: aload #4
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_1
    //   19: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   22: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   25: iconst_0
    //   26: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   29: pop
    //   30: istore_3
    //   31: new org/objectweb/asm/AnnotationWriter
    //   34: dup
    //   35: aload_0
    //   36: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   39: iconst_1
    //   40: aload #4
    //   42: aload #4
    //   44: iconst_2
    //   45: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   48: astore #5
    //   50: iload_3
    //   51: ifne -> 98
    //   54: iload_2
    //   55: ifeq -> 85
    //   58: goto -> 62
    //   61: athrow
    //   62: aload #5
    //   64: aload_0
    //   65: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   68: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   71: aload_0
    //   72: aload #5
    //   74: putfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   77: iload_3
    //   78: ifeq -> 104
    //   81: goto -> 85
    //   84: athrow
    //   85: aload #5
    //   87: aload_0
    //   88: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   91: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   94: goto -> 98
    //   97: athrow
    //   98: aload_0
    //   99: aload #5
    //   101: putfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   104: aload #5
    //   106: areturn
    // Exception table:
    //   from	to	target	type
    //   50	58	61	java/lang/IllegalStateException
    //   54	81	84	java/lang/IllegalStateException
    //   62	94	97	java/lang/IllegalStateException
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: iload_1
    //   10: aload_2
    //   11: aload #6
    //   13: invokestatic a : (ILorg/objectweb/asm/TypePath;Lorg/objectweb/asm/ByteVector;)V
    //   16: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   19: aload #6
    //   21: aload_0
    //   22: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   25: aload_3
    //   26: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   29: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   32: iconst_0
    //   33: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   36: pop
    //   37: istore #5
    //   39: new org/objectweb/asm/AnnotationWriter
    //   42: dup
    //   43: aload_0
    //   44: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   47: iconst_1
    //   48: aload #6
    //   50: aload #6
    //   52: aload #6
    //   54: getfield b : I
    //   57: iconst_2
    //   58: isub
    //   59: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   62: astore #7
    //   64: iload #5
    //   66: ifne -> 115
    //   69: iload #4
    //   71: ifeq -> 102
    //   74: goto -> 78
    //   77: athrow
    //   78: aload #7
    //   80: aload_0
    //   81: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   84: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   87: aload_0
    //   88: aload #7
    //   90: putfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   93: iload #5
    //   95: ifeq -> 121
    //   98: goto -> 102
    //   101: athrow
    //   102: aload #7
    //   104: aload_0
    //   105: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   108: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   111: goto -> 115
    //   114: athrow
    //   115: aload_0
    //   116: aload #7
    //   118: putfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   121: aload #7
    //   123: areturn
    // Exception table:
    //   from	to	target	type
    //   64	74	77	java/lang/IllegalStateException
    //   69	98	101	java/lang/IllegalStateException
    //   78	111	114	java/lang/IllegalStateException
  }
  
  public AnnotationVisitor visitParameterAnnotation(int paramInt, String paramString, boolean paramBoolean) {
    int i = MethodVisitor.b;
    ByteVector byteVector = new ByteVector();
    try {
      if (i == 0) {
        try {
          if (b(-21090, 30702).equals(paramString)) {
            this.R = Math.max(this.R, paramInt + 1);
            return new AnnotationWriter(this.b, false, byteVector, null, 0);
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        byteVector.putShort(this.b.newUTF8(paramString)).putShort(0);
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    AnnotationWriter annotationWriter = new AnnotationWriter(this.b, true, byteVector, byteVector, 2);
    try {
      if (paramBoolean) {
        try {
          if (i == 0) {
            try {
              if (this.o == null)
                this.o = new AnnotationWriter[(Type.getArgumentTypes(this.f)).length]; 
            } catch (IllegalStateException illegalStateException) {
              throw null;
            } 
            annotationWriter.g = this.o[paramInt];
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        try {
          this.o[paramInt] = annotationWriter;
          if (i != 0) {
            try {
              if (i == 0) {
                try {
                  if (this.p == null)
                    this.p = new AnnotationWriter[(Type.getArgumentTypes(this.f)).length]; 
                } catch (IllegalStateException illegalStateException) {
                  throw null;
                } 
                annotationWriter.g = this.p[paramInt];
              } 
            } catch (IllegalStateException illegalStateException) {
              throw null;
            } 
            this.p[paramInt] = annotationWriter;
            return annotationWriter;
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        return annotationWriter;
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    try {
      if (i == 0) {
        try {
          if (this.p == null)
            this.p = new AnnotationWriter[(Type.getArgumentTypes(this.f)).length]; 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        annotationWriter.g = this.p[paramInt];
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.p[paramInt] = annotationWriter;
    return annotationWriter;
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: iload_2
    //   6: ifne -> 45
    //   9: invokevirtual isCodeAttribute : ()Z
    //   12: ifeq -> 40
    //   15: goto -> 19
    //   18: athrow
    //   19: aload_1
    //   20: aload_0
    //   21: getfield J : Lorg/objectweb/asm/Attribute;
    //   24: putfield a : Lorg/objectweb/asm/Attribute;
    //   27: aload_0
    //   28: aload_1
    //   29: putfield J : Lorg/objectweb/asm/Attribute;
    //   32: iload_2
    //   33: ifeq -> 57
    //   36: goto -> 40
    //   39: athrow
    //   40: aload_1
    //   41: goto -> 45
    //   44: athrow
    //   45: aload_0
    //   46: getfield q : Lorg/objectweb/asm/Attribute;
    //   49: putfield a : Lorg/objectweb/asm/Attribute;
    //   52: aload_0
    //   53: aload_1
    //   54: putfield q : Lorg/objectweb/asm/Attribute;
    //   57: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   9	36	39	java/lang/IllegalStateException
    //   19	41	44	java/lang/IllegalStateException
  }
  
  public void visitCode() {}
  
  public void visitFrame(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #6
    //   5: aload_0
    //   6: getfield L : I
    //   9: iload #6
    //   11: ifne -> 26
    //   14: ifne -> 22
    //   17: goto -> 21
    //   20: athrow
    //   21: return
    //   22: aload_0
    //   23: getfield L : I
    //   26: iconst_1
    //   27: iload #6
    //   29: ifne -> 184
    //   32: if_icmpne -> 178
    //   35: goto -> 39
    //   38: athrow
    //   39: aload_0
    //   40: getfield O : Lorg/objectweb/asm/Label;
    //   43: getfield h : Lorg/objectweb/asm/Frame;
    //   46: iload #6
    //   48: ifne -> 101
    //   51: goto -> 55
    //   54: athrow
    //   55: ifnonnull -> 129
    //   58: goto -> 62
    //   61: athrow
    //   62: aload_0
    //   63: getfield O : Lorg/objectweb/asm/Label;
    //   66: new org/objectweb/asm/CurrentFrame
    //   69: dup
    //   70: invokespecial <init> : ()V
    //   73: putfield h : Lorg/objectweb/asm/Frame;
    //   76: aload_0
    //   77: getfield O : Lorg/objectweb/asm/Label;
    //   80: getfield h : Lorg/objectweb/asm/Frame;
    //   83: aload_0
    //   84: getfield O : Lorg/objectweb/asm/Label;
    //   87: putfield b : Lorg/objectweb/asm/Label;
    //   90: aload_0
    //   91: getfield O : Lorg/objectweb/asm/Label;
    //   94: getfield h : Lorg/objectweb/asm/Frame;
    //   97: goto -> 101
    //   100: athrow
    //   101: aload_0
    //   102: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   105: aload_0
    //   106: getfield c : I
    //   109: aload_0
    //   110: getfield f : Ljava/lang/String;
    //   113: invokestatic getArgumentTypes : (Ljava/lang/String;)[Lorg/objectweb/asm/Type;
    //   116: iload_2
    //   117: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;I[Lorg/objectweb/asm/Type;I)V
    //   120: aload_0
    //   121: invokespecial f : ()V
    //   124: iload #6
    //   126: ifeq -> 1056
    //   129: iload_1
    //   130: iconst_m1
    //   131: if_icmpne -> 162
    //   134: goto -> 138
    //   137: athrow
    //   138: aload_0
    //   139: getfield O : Lorg/objectweb/asm/Label;
    //   142: getfield h : Lorg/objectweb/asm/Frame;
    //   145: aload_0
    //   146: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   149: iload_2
    //   150: aload_3
    //   151: iload #4
    //   153: aload #5
    //   155: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;I[Ljava/lang/Object;I[Ljava/lang/Object;)V
    //   158: goto -> 162
    //   161: athrow
    //   162: aload_0
    //   163: aload_0
    //   164: getfield O : Lorg/objectweb/asm/Label;
    //   167: getfield h : Lorg/objectweb/asm/Frame;
    //   170: invokespecial b : (Lorg/objectweb/asm/Frame;)V
    //   173: iload #6
    //   175: ifeq -> 1056
    //   178: iload_1
    //   179: iconst_m1
    //   180: goto -> 184
    //   183: athrow
    //   184: if_icmpne -> 562
    //   187: aload_0
    //   188: iload #6
    //   190: ifne -> 221
    //   193: goto -> 197
    //   196: athrow
    //   197: getfield x : [I
    //   200: ifnonnull -> 215
    //   203: goto -> 207
    //   206: athrow
    //   207: aload_0
    //   208: invokespecial f : ()V
    //   211: goto -> 215
    //   214: athrow
    //   215: aload_0
    //   216: iload_2
    //   217: putfield T : I
    //   220: aload_0
    //   221: aload_0
    //   222: getfield r : Lorg/objectweb/asm/ByteVector;
    //   225: getfield b : I
    //   228: iload_2
    //   229: iload #4
    //   231: invokespecial a : (III)I
    //   234: istore #7
    //   236: iconst_0
    //   237: istore #8
    //   239: iload #8
    //   241: iload_2
    //   242: if_icmpge -> 396
    //   245: aload_3
    //   246: iload #8
    //   248: aaload
    //   249: instanceof java/lang/String
    //   252: iload #6
    //   254: ifne -> 397
    //   257: iload #6
    //   259: ifne -> 320
    //   262: goto -> 266
    //   265: athrow
    //   266: ifeq -> 309
    //   269: goto -> 273
    //   272: athrow
    //   273: aload_0
    //   274: getfield z : [I
    //   277: iload #7
    //   279: iinc #7, 1
    //   282: ldc 24117248
    //   284: aload_0
    //   285: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   288: aload_3
    //   289: iload #8
    //   291: aaload
    //   292: checkcast java/lang/String
    //   295: invokevirtual c : (Ljava/lang/String;)I
    //   298: ior
    //   299: iastore
    //   300: iload #6
    //   302: ifeq -> 388
    //   305: goto -> 309
    //   308: athrow
    //   309: aload_3
    //   310: iload #8
    //   312: aaload
    //   313: instanceof java/lang/Integer
    //   316: goto -> 320
    //   319: athrow
    //   320: ifeq -> 352
    //   323: aload_0
    //   324: getfield z : [I
    //   327: iload #7
    //   329: iinc #7, 1
    //   332: aload_3
    //   333: iload #8
    //   335: aaload
    //   336: checkcast java/lang/Integer
    //   339: invokevirtual intValue : ()I
    //   342: iastore
    //   343: iload #6
    //   345: ifeq -> 388
    //   348: goto -> 352
    //   351: athrow
    //   352: aload_0
    //   353: getfield z : [I
    //   356: iload #7
    //   358: iinc #7, 1
    //   361: ldc 25165824
    //   363: aload_0
    //   364: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   367: ldc ''
    //   369: aload_3
    //   370: iload #8
    //   372: aaload
    //   373: checkcast org/objectweb/asm/Label
    //   376: getfield c : I
    //   379: invokevirtual a : (Ljava/lang/String;I)I
    //   382: ior
    //   383: iastore
    //   384: goto -> 388
    //   387: athrow
    //   388: iinc #8, 1
    //   391: iload #6
    //   393: ifeq -> 239
    //   396: iconst_0
    //   397: istore #8
    //   399: iload #8
    //   401: iload #4
    //   403: if_icmpge -> 553
    //   406: aload #5
    //   408: iload #8
    //   410: aaload
    //   411: instanceof java/lang/String
    //   414: iload #6
    //   416: ifne -> 475
    //   419: ifeq -> 463
    //   422: goto -> 426
    //   425: athrow
    //   426: aload_0
    //   427: getfield z : [I
    //   430: iload #7
    //   432: iinc #7, 1
    //   435: ldc 24117248
    //   437: aload_0
    //   438: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   441: aload #5
    //   443: iload #8
    //   445: aaload
    //   446: checkcast java/lang/String
    //   449: invokevirtual c : (Ljava/lang/String;)I
    //   452: ior
    //   453: iastore
    //   454: iload #6
    //   456: ifeq -> 545
    //   459: goto -> 463
    //   462: athrow
    //   463: aload #5
    //   465: iload #8
    //   467: aaload
    //   468: instanceof java/lang/Integer
    //   471: goto -> 475
    //   474: athrow
    //   475: ifeq -> 508
    //   478: aload_0
    //   479: getfield z : [I
    //   482: iload #7
    //   484: iinc #7, 1
    //   487: aload #5
    //   489: iload #8
    //   491: aaload
    //   492: checkcast java/lang/Integer
    //   495: invokevirtual intValue : ()I
    //   498: iastore
    //   499: iload #6
    //   501: ifeq -> 545
    //   504: goto -> 508
    //   507: athrow
    //   508: aload_0
    //   509: getfield z : [I
    //   512: iload #7
    //   514: iinc #7, 1
    //   517: ldc 25165824
    //   519: aload_0
    //   520: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   523: ldc ''
    //   525: aload #5
    //   527: iload #8
    //   529: aaload
    //   530: checkcast org/objectweb/asm/Label
    //   533: getfield c : I
    //   536: invokevirtual a : (Ljava/lang/String;I)I
    //   539: ior
    //   540: iastore
    //   541: goto -> 545
    //   544: athrow
    //   545: iinc #8, 1
    //   548: iload #6
    //   550: ifeq -> 399
    //   553: aload_0
    //   554: invokespecial b : ()V
    //   557: iload #6
    //   559: ifeq -> 1056
    //   562: aload_0
    //   563: getfield v : Lorg/objectweb/asm/ByteVector;
    //   566: iload #6
    //   568: ifne -> 615
    //   571: goto -> 575
    //   574: athrow
    //   575: ifnonnull -> 607
    //   578: goto -> 582
    //   581: athrow
    //   582: aload_0
    //   583: new org/objectweb/asm/ByteVector
    //   586: dup
    //   587: invokespecial <init> : ()V
    //   590: putfield v : Lorg/objectweb/asm/ByteVector;
    //   593: aload_0
    //   594: getfield r : Lorg/objectweb/asm/ByteVector;
    //   597: getfield b : I
    //   600: istore #7
    //   602: iload #6
    //   604: ifeq -> 660
    //   607: aload_0
    //   608: getfield r : Lorg/objectweb/asm/ByteVector;
    //   611: goto -> 615
    //   614: athrow
    //   615: getfield b : I
    //   618: aload_0
    //   619: getfield w : I
    //   622: isub
    //   623: iconst_1
    //   624: isub
    //   625: istore #7
    //   627: iload #7
    //   629: iload #6
    //   631: ifne -> 661
    //   634: ifge -> 660
    //   637: goto -> 641
    //   640: athrow
    //   641: iload_1
    //   642: iconst_3
    //   643: if_icmpne -> 652
    //   646: goto -> 650
    //   649: athrow
    //   650: return
    //   651: athrow
    //   652: new java/lang/IllegalStateException
    //   655: dup
    //   656: invokespecial <init> : ()V
    //   659: athrow
    //   660: iload_1
    //   661: iload #6
    //   663: ifne -> 731
    //   666: tableswitch default -> 1035, 0 -> 701, 1 -> 815, 2 -> 882, 3 -> 919, 4 -> 974
    //   700: athrow
    //   701: aload_0
    //   702: iload_2
    //   703: putfield T : I
    //   706: aload_0
    //   707: getfield v : Lorg/objectweb/asm/ByteVector;
    //   710: sipush #255
    //   713: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   716: iload #7
    //   718: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   721: iload_2
    //   722: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   725: pop
    //   726: iconst_0
    //   727: goto -> 731
    //   730: athrow
    //   731: istore #8
    //   733: iload #8
    //   735: iload_2
    //   736: if_icmpge -> 764
    //   739: aload_0
    //   740: aload_3
    //   741: iload #8
    //   743: aaload
    //   744: invokespecial a : (Ljava/lang/Object;)V
    //   747: iinc #8, 1
    //   750: iload #6
    //   752: ifne -> 774
    //   755: iload #6
    //   757: ifeq -> 733
    //   760: goto -> 764
    //   763: athrow
    //   764: aload_0
    //   765: getfield v : Lorg/objectweb/asm/ByteVector;
    //   768: iload #4
    //   770: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   773: pop
    //   774: iconst_0
    //   775: istore #8
    //   777: iload #8
    //   779: iload #4
    //   781: if_icmpge -> 810
    //   784: aload_0
    //   785: aload #5
    //   787: iload #8
    //   789: aaload
    //   790: invokespecial a : (Ljava/lang/Object;)V
    //   793: iinc #8, 1
    //   796: iload #6
    //   798: ifne -> 1046
    //   801: iload #6
    //   803: ifeq -> 777
    //   806: goto -> 810
    //   809: athrow
    //   810: iload #6
    //   812: ifeq -> 1035
    //   815: aload_0
    //   816: dup
    //   817: getfield T : I
    //   820: iload_2
    //   821: iadd
    //   822: putfield T : I
    //   825: aload_0
    //   826: getfield v : Lorg/objectweb/asm/ByteVector;
    //   829: sipush #251
    //   832: iload_2
    //   833: iadd
    //   834: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   837: iload #7
    //   839: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   842: pop
    //   843: iconst_0
    //   844: istore #8
    //   846: iload #8
    //   848: iload_2
    //   849: if_icmpge -> 877
    //   852: aload_0
    //   853: aload_3
    //   854: iload #8
    //   856: aaload
    //   857: invokespecial a : (Ljava/lang/Object;)V
    //   860: iinc #8, 1
    //   863: iload #6
    //   865: ifne -> 1046
    //   868: iload #6
    //   870: ifeq -> 846
    //   873: goto -> 877
    //   876: athrow
    //   877: iload #6
    //   879: ifeq -> 1035
    //   882: aload_0
    //   883: dup
    //   884: getfield T : I
    //   887: iload_2
    //   888: isub
    //   889: putfield T : I
    //   892: aload_0
    //   893: getfield v : Lorg/objectweb/asm/ByteVector;
    //   896: sipush #251
    //   899: iload_2
    //   900: isub
    //   901: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   904: iload #7
    //   906: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   909: pop
    //   910: iload #6
    //   912: ifeq -> 1035
    //   915: goto -> 919
    //   918: athrow
    //   919: iload #7
    //   921: bipush #64
    //   923: if_icmpge -> 949
    //   926: goto -> 930
    //   929: athrow
    //   930: aload_0
    //   931: getfield v : Lorg/objectweb/asm/ByteVector;
    //   934: iload #7
    //   936: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   939: pop
    //   940: iload #6
    //   942: ifeq -> 1035
    //   945: goto -> 949
    //   948: athrow
    //   949: aload_0
    //   950: getfield v : Lorg/objectweb/asm/ByteVector;
    //   953: sipush #251
    //   956: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   959: iload #7
    //   961: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   964: pop
    //   965: iload #6
    //   967: ifeq -> 1035
    //   970: goto -> 974
    //   973: athrow
    //   974: iload #7
    //   976: bipush #64
    //   978: if_icmpge -> 1007
    //   981: goto -> 985
    //   984: athrow
    //   985: aload_0
    //   986: getfield v : Lorg/objectweb/asm/ByteVector;
    //   989: bipush #64
    //   991: iload #7
    //   993: iadd
    //   994: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   997: pop
    //   998: iload #6
    //   1000: ifeq -> 1027
    //   1003: goto -> 1007
    //   1006: athrow
    //   1007: aload_0
    //   1008: getfield v : Lorg/objectweb/asm/ByteVector;
    //   1011: sipush #247
    //   1014: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   1017: iload #7
    //   1019: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1022: pop
    //   1023: goto -> 1027
    //   1026: athrow
    //   1027: aload_0
    //   1028: aload #5
    //   1030: iconst_0
    //   1031: aaload
    //   1032: invokespecial a : (Ljava/lang/Object;)V
    //   1035: aload_0
    //   1036: aload_0
    //   1037: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1040: getfield b : I
    //   1043: putfield w : I
    //   1046: aload_0
    //   1047: dup
    //   1048: getfield u : I
    //   1051: iconst_1
    //   1052: iadd
    //   1053: putfield u : I
    //   1056: aload_0
    //   1057: aload_0
    //   1058: getfield s : I
    //   1061: iload #4
    //   1063: invokestatic max : (II)I
    //   1066: putfield s : I
    //   1069: aload_0
    //   1070: aload_0
    //   1071: getfield t : I
    //   1074: aload_0
    //   1075: getfield T : I
    //   1078: invokestatic max : (II)I
    //   1081: putfield t : I
    //   1084: return
    // Exception table:
    //   from	to	target	type
    //   5	17	20	java/lang/IllegalStateException
    //   26	35	38	java/lang/IllegalStateException
    //   32	51	54	java/lang/IllegalStateException
    //   39	58	61	java/lang/IllegalStateException
    //   55	97	100	java/lang/IllegalStateException
    //   101	134	137	java/lang/IllegalStateException
    //   129	158	161	java/lang/IllegalStateException
    //   162	180	183	java/lang/IllegalStateException
    //   184	193	196	java/lang/IllegalStateException
    //   187	203	206	java/lang/IllegalStateException
    //   197	211	214	java/lang/IllegalStateException
    //   245	262	265	java/lang/IllegalStateException
    //   257	269	272	java/lang/IllegalStateException
    //   266	305	308	java/lang/IllegalStateException
    //   273	316	319	java/lang/IllegalStateException
    //   320	348	351	java/lang/IllegalStateException
    //   323	384	387	java/lang/IllegalStateException
    //   406	422	425	java/lang/IllegalStateException
    //   419	459	462	java/lang/IllegalStateException
    //   426	471	474	java/lang/IllegalStateException
    //   475	504	507	java/lang/IllegalStateException
    //   478	541	544	java/lang/IllegalStateException
    //   553	571	574	java/lang/IllegalStateException
    //   562	578	581	java/lang/IllegalStateException
    //   602	611	614	java/lang/IllegalStateException
    //   627	637	640	java/lang/IllegalStateException
    //   634	646	649	java/lang/IllegalStateException
    //   641	651	651	java/lang/IllegalStateException
    //   661	700	700	java/lang/IllegalStateException
    //   666	727	730	java/lang/IllegalStateException
    //   739	760	763	java/lang/IllegalStateException
    //   784	806	809	java/lang/IllegalStateException
    //   852	873	876	java/lang/IllegalStateException
    //   877	915	918	java/lang/IllegalStateException
    //   882	926	929	java/lang/IllegalStateException
    //   919	945	948	java/lang/IllegalStateException
    //   930	970	973	java/lang/IllegalStateException
    //   949	981	984	java/lang/IllegalStateException
    //   974	1003	1006	java/lang/IllegalStateException
    //   985	1023	1026	java/lang/IllegalStateException
  }
  
  public void visitInsn(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield r : Lorg/objectweb/asm/ByteVector;
    //   18: iload_1
    //   19: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   22: pop
    //   23: istore_2
    //   24: aload_0
    //   25: iload_2
    //   26: ifne -> 44
    //   29: getfield O : Lorg/objectweb/asm/Label;
    //   32: ifnull -> 186
    //   35: goto -> 39
    //   38: athrow
    //   39: aload_0
    //   40: goto -> 44
    //   43: athrow
    //   44: iload_2
    //   45: ifne -> 79
    //   48: getfield L : I
    //   51: ifeq -> 78
    //   54: goto -> 58
    //   57: athrow
    //   58: aload_0
    //   59: getfield L : I
    //   62: iconst_1
    //   63: iload_2
    //   64: ifne -> 109
    //   67: goto -> 71
    //   70: athrow
    //   71: if_icmpne -> 96
    //   74: goto -> 78
    //   77: athrow
    //   78: aload_0
    //   79: getfield O : Lorg/objectweb/asm/Label;
    //   82: getfield h : Lorg/objectweb/asm/Frame;
    //   85: iload_1
    //   86: iconst_0
    //   87: aconst_null
    //   88: aconst_null
    //   89: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   92: iload_2
    //   93: ifeq -> 133
    //   96: aload_0
    //   97: getfield P : I
    //   100: getstatic org/objectweb/asm/Frame.a : [I
    //   103: iload_1
    //   104: iaload
    //   105: goto -> 109
    //   108: athrow
    //   109: iadd
    //   110: istore_3
    //   111: iload_3
    //   112: aload_0
    //   113: getfield Q : I
    //   116: if_icmple -> 128
    //   119: aload_0
    //   120: iload_3
    //   121: putfield Q : I
    //   124: goto -> 128
    //   127: athrow
    //   128: aload_0
    //   129: iload_3
    //   130: putfield P : I
    //   133: iload_1
    //   134: sipush #172
    //   137: iload_2
    //   138: ifne -> 175
    //   141: if_icmplt -> 167
    //   144: goto -> 148
    //   147: athrow
    //   148: iload_1
    //   149: sipush #177
    //   152: iload_2
    //   153: ifne -> 175
    //   156: goto -> 160
    //   159: athrow
    //   160: if_icmple -> 178
    //   163: goto -> 167
    //   166: athrow
    //   167: iload_1
    //   168: sipush #191
    //   171: goto -> 175
    //   174: athrow
    //   175: if_icmpne -> 186
    //   178: aload_0
    //   179: invokespecial e : ()V
    //   182: goto -> 186
    //   185: athrow
    //   186: return
    // Exception table:
    //   from	to	target	type
    //   24	35	38	java/lang/IllegalStateException
    //   29	40	43	java/lang/IllegalStateException
    //   44	54	57	java/lang/IllegalStateException
    //   48	67	70	java/lang/IllegalStateException
    //   58	74	77	java/lang/IllegalStateException
    //   79	105	108	java/lang/IllegalStateException
    //   111	124	127	java/lang/IllegalStateException
    //   133	144	147	java/lang/IllegalStateException
    //   141	156	159	java/lang/IllegalStateException
    //   148	163	166	java/lang/IllegalStateException
    //   160	171	174	java/lang/IllegalStateException
    //   175	182	185	java/lang/IllegalStateException
  }
  
  public void visitIntInsn(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: aload_0
    //   6: getfield r : Lorg/objectweb/asm/ByteVector;
    //   9: getfield b : I
    //   12: putfield Y : I
    //   15: aload_0
    //   16: iload_3
    //   17: ifne -> 35
    //   20: getfield O : Lorg/objectweb/asm/Label;
    //   23: ifnull -> 139
    //   26: goto -> 30
    //   29: athrow
    //   30: aload_0
    //   31: goto -> 35
    //   34: athrow
    //   35: iload_3
    //   36: ifne -> 70
    //   39: getfield L : I
    //   42: ifeq -> 69
    //   45: goto -> 49
    //   48: athrow
    //   49: aload_0
    //   50: getfield L : I
    //   53: iconst_1
    //   54: iload_3
    //   55: ifne -> 95
    //   58: goto -> 62
    //   61: athrow
    //   62: if_icmpne -> 87
    //   65: goto -> 69
    //   68: athrow
    //   69: aload_0
    //   70: getfield O : Lorg/objectweb/asm/Label;
    //   73: getfield h : Lorg/objectweb/asm/Frame;
    //   76: iload_1
    //   77: iload_2
    //   78: aconst_null
    //   79: aconst_null
    //   80: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   83: iload_3
    //   84: ifeq -> 139
    //   87: iload_1
    //   88: sipush #188
    //   91: goto -> 95
    //   94: athrow
    //   95: iload_3
    //   96: ifne -> 142
    //   99: if_icmpeq -> 139
    //   102: goto -> 106
    //   105: athrow
    //   106: aload_0
    //   107: getfield P : I
    //   110: iconst_1
    //   111: iadd
    //   112: istore #4
    //   114: iload #4
    //   116: aload_0
    //   117: getfield Q : I
    //   120: if_icmple -> 133
    //   123: aload_0
    //   124: iload #4
    //   126: putfield Q : I
    //   129: goto -> 133
    //   132: athrow
    //   133: aload_0
    //   134: iload #4
    //   136: putfield P : I
    //   139: iload_1
    //   140: bipush #17
    //   142: if_icmpne -> 163
    //   145: aload_0
    //   146: getfield r : Lorg/objectweb/asm/ByteVector;
    //   149: iload_1
    //   150: iload_2
    //   151: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   154: pop
    //   155: iload_3
    //   156: ifeq -> 177
    //   159: goto -> 163
    //   162: athrow
    //   163: aload_0
    //   164: getfield r : Lorg/objectweb/asm/ByteVector;
    //   167: iload_1
    //   168: iload_2
    //   169: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   172: pop
    //   173: goto -> 177
    //   176: athrow
    //   177: return
    // Exception table:
    //   from	to	target	type
    //   4	26	29	java/lang/IllegalStateException
    //   20	31	34	java/lang/IllegalStateException
    //   35	45	48	java/lang/IllegalStateException
    //   39	58	61	java/lang/IllegalStateException
    //   49	65	68	java/lang/IllegalStateException
    //   70	91	94	java/lang/IllegalStateException
    //   95	102	105	java/lang/IllegalStateException
    //   114	129	132	java/lang/IllegalStateException
    //   142	159	162	java/lang/IllegalStateException
    //   145	173	176	java/lang/IllegalStateException
  }
  
  public void visitVarInsn(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: aload_0
    //   6: getfield r : Lorg/objectweb/asm/ByteVector;
    //   9: getfield b : I
    //   12: putfield Y : I
    //   15: aload_0
    //   16: iload_3
    //   17: ifne -> 186
    //   20: getfield O : Lorg/objectweb/asm/Label;
    //   23: ifnull -> 185
    //   26: goto -> 30
    //   29: athrow
    //   30: aload_0
    //   31: iload_3
    //   32: ifne -> 70
    //   35: goto -> 39
    //   38: athrow
    //   39: getfield L : I
    //   42: ifeq -> 69
    //   45: goto -> 49
    //   48: athrow
    //   49: aload_0
    //   50: getfield L : I
    //   53: iconst_1
    //   54: iload_3
    //   55: ifne -> 95
    //   58: goto -> 62
    //   61: athrow
    //   62: if_icmpne -> 87
    //   65: goto -> 69
    //   68: athrow
    //   69: aload_0
    //   70: getfield O : Lorg/objectweb/asm/Label;
    //   73: getfield h : Lorg/objectweb/asm/Frame;
    //   76: iload_1
    //   77: iload_2
    //   78: aconst_null
    //   79: aconst_null
    //   80: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   83: iload_3
    //   84: ifeq -> 185
    //   87: iload_1
    //   88: sipush #169
    //   91: goto -> 95
    //   94: athrow
    //   95: iload_3
    //   96: ifne -> 157
    //   99: if_icmpne -> 144
    //   102: goto -> 106
    //   105: athrow
    //   106: aload_0
    //   107: getfield O : Lorg/objectweb/asm/Label;
    //   110: dup
    //   111: getfield a : I
    //   114: sipush #256
    //   117: ior
    //   118: putfield a : I
    //   121: aload_0
    //   122: getfield O : Lorg/objectweb/asm/Label;
    //   125: aload_0
    //   126: getfield P : I
    //   129: putfield f : I
    //   132: aload_0
    //   133: invokespecial e : ()V
    //   136: iload_3
    //   137: ifeq -> 185
    //   140: goto -> 144
    //   143: athrow
    //   144: aload_0
    //   145: getfield P : I
    //   148: getstatic org/objectweb/asm/Frame.a : [I
    //   151: iload_1
    //   152: iaload
    //   153: goto -> 157
    //   156: athrow
    //   157: iadd
    //   158: istore #4
    //   160: iload #4
    //   162: aload_0
    //   163: getfield Q : I
    //   166: if_icmple -> 179
    //   169: aload_0
    //   170: iload #4
    //   172: putfield Q : I
    //   175: goto -> 179
    //   178: athrow
    //   179: aload_0
    //   180: iload #4
    //   182: putfield P : I
    //   185: aload_0
    //   186: getfield L : I
    //   189: iconst_3
    //   190: iload_3
    //   191: ifne -> 324
    //   194: if_icmpeq -> 322
    //   197: goto -> 201
    //   200: athrow
    //   201: iload_1
    //   202: bipush #22
    //   204: iload_3
    //   205: ifne -> 279
    //   208: goto -> 212
    //   211: athrow
    //   212: if_icmpeq -> 273
    //   215: goto -> 219
    //   218: athrow
    //   219: iload_1
    //   220: bipush #24
    //   222: iload_3
    //   223: ifne -> 279
    //   226: goto -> 230
    //   229: athrow
    //   230: if_icmpeq -> 273
    //   233: goto -> 237
    //   236: athrow
    //   237: iload_1
    //   238: bipush #55
    //   240: iload_3
    //   241: ifne -> 279
    //   244: goto -> 248
    //   247: athrow
    //   248: if_icmpeq -> 273
    //   251: goto -> 255
    //   254: athrow
    //   255: iload_1
    //   256: bipush #57
    //   258: iload_3
    //   259: ifne -> 292
    //   262: goto -> 266
    //   265: athrow
    //   266: if_icmpne -> 286
    //   269: goto -> 273
    //   272: athrow
    //   273: iload_2
    //   274: iconst_2
    //   275: goto -> 279
    //   278: athrow
    //   279: iadd
    //   280: istore #4
    //   282: iload_3
    //   283: ifeq -> 295
    //   286: iload_2
    //   287: iconst_1
    //   288: goto -> 292
    //   291: athrow
    //   292: iadd
    //   293: istore #4
    //   295: iload #4
    //   297: aload_0
    //   298: getfield t : I
    //   301: iload_3
    //   302: ifne -> 324
    //   305: if_icmple -> 322
    //   308: goto -> 312
    //   311: athrow
    //   312: aload_0
    //   313: iload #4
    //   315: putfield t : I
    //   318: goto -> 322
    //   321: athrow
    //   322: iload_2
    //   323: iconst_4
    //   324: iload_3
    //   325: ifne -> 428
    //   328: if_icmpge -> 420
    //   331: goto -> 335
    //   334: athrow
    //   335: iload_1
    //   336: sipush #169
    //   339: iload_3
    //   340: ifne -> 428
    //   343: goto -> 347
    //   346: athrow
    //   347: if_icmpeq -> 420
    //   350: goto -> 354
    //   353: athrow
    //   354: iload_1
    //   355: bipush #54
    //   357: iload_3
    //   358: ifne -> 403
    //   361: goto -> 365
    //   364: athrow
    //   365: if_icmpge -> 389
    //   368: goto -> 372
    //   371: athrow
    //   372: bipush #26
    //   374: iload_1
    //   375: bipush #21
    //   377: isub
    //   378: iconst_2
    //   379: ishl
    //   380: iadd
    //   381: iload_2
    //   382: iadd
    //   383: istore #4
    //   385: iload_3
    //   386: ifeq -> 406
    //   389: bipush #59
    //   391: iload_1
    //   392: bipush #54
    //   394: isub
    //   395: iconst_2
    //   396: ishl
    //   397: iadd
    //   398: iload_2
    //   399: goto -> 403
    //   402: athrow
    //   403: iadd
    //   404: istore #4
    //   406: aload_0
    //   407: getfield r : Lorg/objectweb/asm/ByteVector;
    //   410: iload #4
    //   412: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   415: pop
    //   416: iload_3
    //   417: ifeq -> 469
    //   420: iload_2
    //   421: sipush #256
    //   424: goto -> 428
    //   427: athrow
    //   428: if_icmplt -> 455
    //   431: aload_0
    //   432: getfield r : Lorg/objectweb/asm/ByteVector;
    //   435: sipush #196
    //   438: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   441: iload_1
    //   442: iload_2
    //   443: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   446: pop
    //   447: iload_3
    //   448: ifeq -> 469
    //   451: goto -> 455
    //   454: athrow
    //   455: aload_0
    //   456: getfield r : Lorg/objectweb/asm/ByteVector;
    //   459: iload_1
    //   460: iload_2
    //   461: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   464: pop
    //   465: goto -> 469
    //   468: athrow
    //   469: iload_1
    //   470: iload_3
    //   471: ifne -> 491
    //   474: bipush #54
    //   476: if_icmplt -> 532
    //   479: goto -> 483
    //   482: athrow
    //   483: aload_0
    //   484: getfield L : I
    //   487: goto -> 491
    //   490: athrow
    //   491: iload_3
    //   492: ifne -> 518
    //   495: ifne -> 532
    //   498: goto -> 502
    //   501: athrow
    //   502: aload_0
    //   503: iload_3
    //   504: ifne -> 522
    //   507: goto -> 511
    //   510: athrow
    //   511: getfield A : I
    //   514: goto -> 518
    //   517: athrow
    //   518: ifle -> 532
    //   521: aload_0
    //   522: new org/objectweb/asm/Label
    //   525: dup
    //   526: invokespecial <init> : ()V
    //   529: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   532: return
    // Exception table:
    //   from	to	target	type
    //   4	26	29	java/lang/IllegalStateException
    //   20	35	38	java/lang/IllegalStateException
    //   30	45	48	java/lang/IllegalStateException
    //   39	58	61	java/lang/IllegalStateException
    //   49	65	68	java/lang/IllegalStateException
    //   70	91	94	java/lang/IllegalStateException
    //   95	102	105	java/lang/IllegalStateException
    //   99	140	143	java/lang/IllegalStateException
    //   106	153	156	java/lang/IllegalStateException
    //   160	175	178	java/lang/IllegalStateException
    //   186	197	200	java/lang/IllegalStateException
    //   194	208	211	java/lang/IllegalStateException
    //   201	215	218	java/lang/IllegalStateException
    //   212	226	229	java/lang/IllegalStateException
    //   219	233	236	java/lang/IllegalStateException
    //   230	244	247	java/lang/IllegalStateException
    //   237	251	254	java/lang/IllegalStateException
    //   248	262	265	java/lang/IllegalStateException
    //   255	269	272	java/lang/IllegalStateException
    //   266	275	278	java/lang/IllegalStateException
    //   282	288	291	java/lang/IllegalStateException
    //   295	308	311	java/lang/IllegalStateException
    //   305	318	321	java/lang/IllegalStateException
    //   324	331	334	java/lang/IllegalStateException
    //   328	343	346	java/lang/IllegalStateException
    //   335	350	353	java/lang/IllegalStateException
    //   347	361	364	java/lang/IllegalStateException
    //   354	368	371	java/lang/IllegalStateException
    //   385	399	402	java/lang/IllegalStateException
    //   406	424	427	java/lang/IllegalStateException
    //   428	451	454	java/lang/IllegalStateException
    //   431	465	468	java/lang/IllegalStateException
    //   469	479	482	java/lang/IllegalStateException
    //   474	487	490	java/lang/IllegalStateException
    //   491	498	501	java/lang/IllegalStateException
    //   495	507	510	java/lang/IllegalStateException
    //   502	514	517	java/lang/IllegalStateException
  }
  
  public void visitTypeInsn(int paramInt, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_2
    //   19: invokevirtual a : (Ljava/lang/String;)Lorg/objectweb/asm/Item;
    //   22: astore #4
    //   24: istore_3
    //   25: aload_0
    //   26: iload_3
    //   27: ifne -> 164
    //   30: getfield O : Lorg/objectweb/asm/Label;
    //   33: ifnull -> 163
    //   36: goto -> 40
    //   39: athrow
    //   40: aload_0
    //   41: iload_3
    //   42: ifne -> 80
    //   45: goto -> 49
    //   48: athrow
    //   49: getfield L : I
    //   52: ifeq -> 79
    //   55: goto -> 59
    //   58: athrow
    //   59: aload_0
    //   60: getfield L : I
    //   63: iconst_1
    //   64: iload_3
    //   65: ifne -> 115
    //   68: goto -> 72
    //   71: athrow
    //   72: if_icmpne -> 107
    //   75: goto -> 79
    //   78: athrow
    //   79: aload_0
    //   80: getfield O : Lorg/objectweb/asm/Label;
    //   83: getfield h : Lorg/objectweb/asm/Frame;
    //   86: iload_1
    //   87: aload_0
    //   88: getfield r : Lorg/objectweb/asm/ByteVector;
    //   91: getfield b : I
    //   94: aload_0
    //   95: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   98: aload #4
    //   100: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   103: iload_3
    //   104: ifeq -> 163
    //   107: iload_1
    //   108: sipush #187
    //   111: goto -> 115
    //   114: athrow
    //   115: iload_3
    //   116: ifne -> 135
    //   119: if_icmpne -> 163
    //   122: goto -> 126
    //   125: athrow
    //   126: aload_0
    //   127: getfield P : I
    //   130: iconst_1
    //   131: goto -> 135
    //   134: athrow
    //   135: iadd
    //   136: istore #5
    //   138: iload #5
    //   140: aload_0
    //   141: getfield Q : I
    //   144: if_icmple -> 157
    //   147: aload_0
    //   148: iload #5
    //   150: putfield Q : I
    //   153: goto -> 157
    //   156: athrow
    //   157: aload_0
    //   158: iload #5
    //   160: putfield P : I
    //   163: aload_0
    //   164: getfield r : Lorg/objectweb/asm/ByteVector;
    //   167: iload_1
    //   168: aload #4
    //   170: getfield a : I
    //   173: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   176: pop
    //   177: return
    // Exception table:
    //   from	to	target	type
    //   25	36	39	java/lang/IllegalStateException
    //   30	45	48	java/lang/IllegalStateException
    //   40	55	58	java/lang/IllegalStateException
    //   49	68	71	java/lang/IllegalStateException
    //   59	75	78	java/lang/IllegalStateException
    //   80	111	114	java/lang/IllegalStateException
    //   115	122	125	java/lang/IllegalStateException
    //   119	131	134	java/lang/IllegalStateException
    //   138	153	156	java/lang/IllegalStateException
  }
  
  public void visitFieldInsn(int paramInt, String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_2
    //   19: aload_3
    //   20: aload #4
    //   22: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/objectweb/asm/Item;
    //   25: astore #6
    //   27: istore #5
    //   29: aload_0
    //   30: iload #5
    //   32: ifne -> 425
    //   35: getfield O : Lorg/objectweb/asm/Label;
    //   38: ifnull -> 424
    //   41: goto -> 45
    //   44: athrow
    //   45: aload_0
    //   46: iload #5
    //   48: ifne -> 91
    //   51: goto -> 55
    //   54: athrow
    //   55: getfield L : I
    //   58: ifeq -> 86
    //   61: goto -> 65
    //   64: athrow
    //   65: aload_0
    //   66: getfield L : I
    //   69: iload #5
    //   71: ifne -> 123
    //   74: goto -> 78
    //   77: athrow
    //   78: iconst_1
    //   79: if_icmpne -> 113
    //   82: goto -> 86
    //   85: athrow
    //   86: aload_0
    //   87: goto -> 91
    //   90: athrow
    //   91: getfield O : Lorg/objectweb/asm/Label;
    //   94: getfield h : Lorg/objectweb/asm/Frame;
    //   97: iload_1
    //   98: iconst_0
    //   99: aload_0
    //   100: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   103: aload #6
    //   105: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   108: iload #5
    //   110: ifeq -> 424
    //   113: aload #4
    //   115: iconst_0
    //   116: invokevirtual charAt : (I)C
    //   119: goto -> 123
    //   122: athrow
    //   123: istore #8
    //   125: iload_1
    //   126: iload #5
    //   128: ifne -> 349
    //   131: tableswitch default -> 341, 178 -> 157, 179 -> 218, 180 -> 280
    //   156: athrow
    //   157: aload_0
    //   158: getfield P : I
    //   161: iload #8
    //   163: iload #5
    //   165: ifne -> 206
    //   168: goto -> 172
    //   171: athrow
    //   172: bipush #68
    //   174: if_icmpeq -> 201
    //   177: goto -> 181
    //   180: athrow
    //   181: iload #8
    //   183: iload #5
    //   185: ifne -> 206
    //   188: goto -> 192
    //   191: athrow
    //   192: bipush #74
    //   194: if_icmpne -> 209
    //   197: goto -> 201
    //   200: athrow
    //   201: iconst_2
    //   202: goto -> 206
    //   205: athrow
    //   206: goto -> 210
    //   209: iconst_1
    //   210: iadd
    //   211: istore #7
    //   213: iload #5
    //   215: ifeq -> 399
    //   218: aload_0
    //   219: getfield P : I
    //   222: iload #8
    //   224: iload #5
    //   226: ifne -> 268
    //   229: goto -> 233
    //   232: athrow
    //   233: bipush #68
    //   235: if_icmpeq -> 262
    //   238: goto -> 242
    //   241: athrow
    //   242: iload #8
    //   244: iload #5
    //   246: ifne -> 268
    //   249: goto -> 253
    //   252: athrow
    //   253: bipush #74
    //   255: if_icmpne -> 271
    //   258: goto -> 262
    //   261: athrow
    //   262: bipush #-2
    //   264: goto -> 268
    //   267: athrow
    //   268: goto -> 272
    //   271: iconst_m1
    //   272: iadd
    //   273: istore #7
    //   275: iload #5
    //   277: ifeq -> 399
    //   280: aload_0
    //   281: getfield P : I
    //   284: iload #8
    //   286: iload #5
    //   288: ifne -> 329
    //   291: goto -> 295
    //   294: athrow
    //   295: bipush #68
    //   297: if_icmpeq -> 324
    //   300: goto -> 304
    //   303: athrow
    //   304: iload #8
    //   306: iload #5
    //   308: ifne -> 329
    //   311: goto -> 315
    //   314: athrow
    //   315: bipush #74
    //   317: if_icmpne -> 332
    //   320: goto -> 324
    //   323: athrow
    //   324: iconst_1
    //   325: goto -> 329
    //   328: athrow
    //   329: goto -> 333
    //   332: iconst_0
    //   333: iadd
    //   334: istore #7
    //   336: iload #5
    //   338: ifeq -> 399
    //   341: aload_0
    //   342: getfield P : I
    //   345: goto -> 349
    //   348: athrow
    //   349: iload #8
    //   351: iload #5
    //   353: ifne -> 391
    //   356: bipush #68
    //   358: if_icmpeq -> 385
    //   361: goto -> 365
    //   364: athrow
    //   365: iload #8
    //   367: iload #5
    //   369: ifne -> 391
    //   372: goto -> 376
    //   375: athrow
    //   376: bipush #74
    //   378: if_icmpne -> 394
    //   381: goto -> 385
    //   384: athrow
    //   385: bipush #-3
    //   387: goto -> 391
    //   390: athrow
    //   391: goto -> 396
    //   394: bipush #-2
    //   396: iadd
    //   397: istore #7
    //   399: iload #7
    //   401: aload_0
    //   402: getfield Q : I
    //   405: if_icmple -> 418
    //   408: aload_0
    //   409: iload #7
    //   411: putfield Q : I
    //   414: goto -> 418
    //   417: athrow
    //   418: aload_0
    //   419: iload #7
    //   421: putfield P : I
    //   424: aload_0
    //   425: getfield r : Lorg/objectweb/asm/ByteVector;
    //   428: iload_1
    //   429: aload #6
    //   431: getfield a : I
    //   434: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   437: pop
    //   438: return
    // Exception table:
    //   from	to	target	type
    //   29	41	44	java/lang/IllegalStateException
    //   35	51	54	java/lang/IllegalStateException
    //   45	61	64	java/lang/IllegalStateException
    //   55	74	77	java/lang/IllegalStateException
    //   65	82	85	java/lang/IllegalStateException
    //   78	87	90	java/lang/IllegalStateException
    //   91	119	122	java/lang/IllegalStateException
    //   125	156	156	java/lang/IllegalStateException
    //   131	168	171	java/lang/IllegalStateException
    //   157	177	180	java/lang/IllegalStateException
    //   172	188	191	java/lang/IllegalStateException
    //   181	197	200	java/lang/IllegalStateException
    //   192	202	205	java/lang/IllegalStateException
    //   213	229	232	java/lang/IllegalStateException
    //   218	238	241	java/lang/IllegalStateException
    //   233	249	252	java/lang/IllegalStateException
    //   242	258	261	java/lang/IllegalStateException
    //   253	264	267	java/lang/IllegalStateException
    //   275	291	294	java/lang/IllegalStateException
    //   280	300	303	java/lang/IllegalStateException
    //   295	311	314	java/lang/IllegalStateException
    //   304	320	323	java/lang/IllegalStateException
    //   315	325	328	java/lang/IllegalStateException
    //   336	345	348	java/lang/IllegalStateException
    //   349	361	364	java/lang/IllegalStateException
    //   356	372	375	java/lang/IllegalStateException
    //   365	381	384	java/lang/IllegalStateException
    //   376	387	390	java/lang/IllegalStateException
    //   399	414	417	java/lang/IllegalStateException
  }
  
  public void visitMethodInsn(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: aload_0
    //   12: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   15: aload_2
    //   16: aload_3
    //   17: aload #4
    //   19: iload #5
    //   21: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Lorg/objectweb/asm/Item;
    //   24: astore #7
    //   26: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   29: aload #7
    //   31: getfield c : I
    //   34: istore #8
    //   36: istore #6
    //   38: aload_0
    //   39: iload #6
    //   41: ifne -> 59
    //   44: getfield O : Lorg/objectweb/asm/Label;
    //   47: ifnull -> 238
    //   50: goto -> 54
    //   53: athrow
    //   54: aload_0
    //   55: goto -> 59
    //   58: athrow
    //   59: iload #6
    //   61: ifne -> 100
    //   64: getfield L : I
    //   67: ifeq -> 95
    //   70: goto -> 74
    //   73: athrow
    //   74: aload_0
    //   75: getfield L : I
    //   78: iload #6
    //   80: ifne -> 128
    //   83: goto -> 87
    //   86: athrow
    //   87: iconst_1
    //   88: if_icmpne -> 122
    //   91: goto -> 95
    //   94: athrow
    //   95: aload_0
    //   96: goto -> 100
    //   99: athrow
    //   100: getfield O : Lorg/objectweb/asm/Label;
    //   103: getfield h : Lorg/objectweb/asm/Frame;
    //   106: iload_1
    //   107: iconst_0
    //   108: aload_0
    //   109: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   112: aload #7
    //   114: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   117: iload #6
    //   119: ifeq -> 238
    //   122: iload #8
    //   124: goto -> 128
    //   127: athrow
    //   128: iload #6
    //   130: ifne -> 155
    //   133: ifne -> 154
    //   136: goto -> 140
    //   139: athrow
    //   140: aload #4
    //   142: invokestatic getArgumentsAndReturnSizes : (Ljava/lang/String;)I
    //   145: istore #8
    //   147: aload #7
    //   149: iload #8
    //   151: putfield c : I
    //   154: iload_1
    //   155: sipush #184
    //   158: iload #6
    //   160: ifne -> 210
    //   163: if_icmpne -> 193
    //   166: goto -> 170
    //   169: athrow
    //   170: aload_0
    //   171: getfield P : I
    //   174: iload #8
    //   176: iconst_2
    //   177: ishr
    //   178: isub
    //   179: iload #8
    //   181: iconst_3
    //   182: iand
    //   183: iadd
    //   184: iconst_1
    //   185: iadd
    //   186: istore #9
    //   188: iload #6
    //   190: ifeq -> 213
    //   193: aload_0
    //   194: getfield P : I
    //   197: iload #8
    //   199: iconst_2
    //   200: ishr
    //   201: isub
    //   202: iload #8
    //   204: iconst_3
    //   205: iand
    //   206: goto -> 210
    //   209: athrow
    //   210: iadd
    //   211: istore #9
    //   213: iload #9
    //   215: aload_0
    //   216: getfield Q : I
    //   219: if_icmple -> 232
    //   222: aload_0
    //   223: iload #9
    //   225: putfield Q : I
    //   228: goto -> 232
    //   231: athrow
    //   232: aload_0
    //   233: iload #9
    //   235: putfield P : I
    //   238: iload_1
    //   239: iload #6
    //   241: ifne -> 260
    //   244: sipush #185
    //   247: if_icmpne -> 319
    //   250: goto -> 254
    //   253: athrow
    //   254: iload #8
    //   256: goto -> 260
    //   259: athrow
    //   260: iload #6
    //   262: ifne -> 281
    //   265: ifne -> 290
    //   268: goto -> 272
    //   271: athrow
    //   272: aload #4
    //   274: invokestatic getArgumentsAndReturnSizes : (Ljava/lang/String;)I
    //   277: goto -> 281
    //   280: athrow
    //   281: istore #8
    //   283: aload #7
    //   285: iload #8
    //   287: putfield c : I
    //   290: aload_0
    //   291: getfield r : Lorg/objectweb/asm/ByteVector;
    //   294: sipush #185
    //   297: aload #7
    //   299: getfield a : I
    //   302: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   305: iload #8
    //   307: iconst_2
    //   308: ishr
    //   309: iconst_0
    //   310: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   313: pop
    //   314: iload #6
    //   316: ifeq -> 337
    //   319: aload_0
    //   320: getfield r : Lorg/objectweb/asm/ByteVector;
    //   323: iload_1
    //   324: aload #7
    //   326: getfield a : I
    //   329: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   332: pop
    //   333: goto -> 337
    //   336: athrow
    //   337: return
    // Exception table:
    //   from	to	target	type
    //   38	50	53	java/lang/IllegalStateException
    //   44	55	58	java/lang/IllegalStateException
    //   59	70	73	java/lang/IllegalStateException
    //   64	83	86	java/lang/IllegalStateException
    //   74	91	94	java/lang/IllegalStateException
    //   87	96	99	java/lang/IllegalStateException
    //   100	124	127	java/lang/IllegalStateException
    //   128	136	139	java/lang/IllegalStateException
    //   155	166	169	java/lang/IllegalStateException
    //   188	206	209	java/lang/IllegalStateException
    //   213	228	231	java/lang/IllegalStateException
    //   238	250	253	java/lang/IllegalStateException
    //   244	256	259	java/lang/IllegalStateException
    //   260	268	271	java/lang/IllegalStateException
    //   265	277	280	java/lang/IllegalStateException
    //   290	333	336	java/lang/IllegalStateException
  }
  
  public void visitInvokeDynamicInsn(String paramString1, String paramString2, Handle paramHandle, Object[] paramArrayOfObject) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_1
    //   19: aload_2
    //   20: aload_3
    //   21: aload #4
    //   23: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/Handle;[Ljava/lang/Object;)Lorg/objectweb/asm/Item;
    //   26: astore #6
    //   28: istore #5
    //   30: aload #6
    //   32: getfield c : I
    //   35: istore #7
    //   37: aload_0
    //   38: iload #5
    //   40: ifne -> 214
    //   43: getfield O : Lorg/objectweb/asm/Label;
    //   46: ifnull -> 197
    //   49: goto -> 53
    //   52: athrow
    //   53: aload_0
    //   54: iload #5
    //   56: ifne -> 99
    //   59: goto -> 63
    //   62: athrow
    //   63: getfield L : I
    //   66: ifeq -> 94
    //   69: goto -> 73
    //   72: athrow
    //   73: aload_0
    //   74: getfield L : I
    //   77: iload #5
    //   79: ifne -> 129
    //   82: goto -> 86
    //   85: athrow
    //   86: iconst_1
    //   87: if_icmpne -> 123
    //   90: goto -> 94
    //   93: athrow
    //   94: aload_0
    //   95: goto -> 99
    //   98: athrow
    //   99: getfield O : Lorg/objectweb/asm/Label;
    //   102: getfield h : Lorg/objectweb/asm/Frame;
    //   105: sipush #186
    //   108: iconst_0
    //   109: aload_0
    //   110: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   113: aload #6
    //   115: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   118: iload #5
    //   120: ifeq -> 197
    //   123: iload #7
    //   125: goto -> 129
    //   128: athrow
    //   129: iload #5
    //   131: ifne -> 170
    //   134: ifne -> 154
    //   137: goto -> 141
    //   140: athrow
    //   141: aload_2
    //   142: invokestatic getArgumentsAndReturnSizes : (Ljava/lang/String;)I
    //   145: istore #7
    //   147: aload #6
    //   149: iload #7
    //   151: putfield c : I
    //   154: aload_0
    //   155: getfield P : I
    //   158: iload #7
    //   160: iconst_2
    //   161: ishr
    //   162: isub
    //   163: iload #7
    //   165: iconst_3
    //   166: iand
    //   167: iadd
    //   168: iconst_1
    //   169: iadd
    //   170: istore #8
    //   172: iload #8
    //   174: aload_0
    //   175: getfield Q : I
    //   178: if_icmple -> 191
    //   181: aload_0
    //   182: iload #8
    //   184: putfield Q : I
    //   187: goto -> 191
    //   190: athrow
    //   191: aload_0
    //   192: iload #8
    //   194: putfield P : I
    //   197: aload_0
    //   198: getfield r : Lorg/objectweb/asm/ByteVector;
    //   201: sipush #186
    //   204: aload #6
    //   206: getfield a : I
    //   209: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   212: pop
    //   213: aload_0
    //   214: getfield r : Lorg/objectweb/asm/ByteVector;
    //   217: iconst_0
    //   218: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   221: pop
    //   222: return
    // Exception table:
    //   from	to	target	type
    //   37	49	52	java/lang/IllegalStateException
    //   43	59	62	java/lang/IllegalStateException
    //   53	69	72	java/lang/IllegalStateException
    //   63	82	85	java/lang/IllegalStateException
    //   73	90	93	java/lang/IllegalStateException
    //   86	95	98	java/lang/IllegalStateException
    //   99	125	128	java/lang/IllegalStateException
    //   129	137	140	java/lang/IllegalStateException
    //   172	187	190	java/lang/IllegalStateException
  }
  
  public void visitJumpInsn(int paramInt, Label paramLabel) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: iload_1
    //   5: iload_3
    //   6: ifne -> 24
    //   9: sipush #200
    //   12: if_icmplt -> 27
    //   15: goto -> 19
    //   18: athrow
    //   19: iconst_1
    //   20: goto -> 24
    //   23: athrow
    //   24: goto -> 28
    //   27: iconst_0
    //   28: istore #4
    //   30: iload #4
    //   32: iload_3
    //   33: ifne -> 51
    //   36: ifeq -> 54
    //   39: goto -> 43
    //   42: athrow
    //   43: iload_1
    //   44: bipush #33
    //   46: isub
    //   47: goto -> 51
    //   50: athrow
    //   51: goto -> 55
    //   54: iload_1
    //   55: istore_1
    //   56: aload_0
    //   57: aload_0
    //   58: getfield r : Lorg/objectweb/asm/ByteVector;
    //   61: getfield b : I
    //   64: putfield Y : I
    //   67: aconst_null
    //   68: astore #5
    //   70: aload_0
    //   71: iload_3
    //   72: ifne -> 90
    //   75: getfield O : Lorg/objectweb/asm/Label;
    //   78: ifnull -> 340
    //   81: goto -> 85
    //   84: athrow
    //   85: aload_0
    //   86: goto -> 90
    //   89: athrow
    //   90: getfield L : I
    //   93: iload_3
    //   94: ifne -> 177
    //   97: ifne -> 173
    //   100: goto -> 104
    //   103: athrow
    //   104: aload_0
    //   105: getfield O : Lorg/objectweb/asm/Label;
    //   108: getfield h : Lorg/objectweb/asm/Frame;
    //   111: iload_1
    //   112: iconst_0
    //   113: aconst_null
    //   114: aconst_null
    //   115: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   118: aload_2
    //   119: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   122: iload_3
    //   123: ifne -> 168
    //   126: goto -> 130
    //   129: athrow
    //   130: dup
    //   131: getfield a : I
    //   134: bipush #16
    //   136: ior
    //   137: putfield a : I
    //   140: aload_0
    //   141: iconst_0
    //   142: aload_2
    //   143: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   146: iload_1
    //   147: sipush #167
    //   150: if_icmpeq -> 340
    //   153: goto -> 157
    //   156: athrow
    //   157: new org/objectweb/asm/Label
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: goto -> 168
    //   167: athrow
    //   168: astore #5
    //   170: goto -> 340
    //   173: aload_0
    //   174: getfield L : I
    //   177: iconst_1
    //   178: iload_3
    //   179: ifne -> 219
    //   182: if_icmpne -> 211
    //   185: goto -> 189
    //   188: athrow
    //   189: aload_0
    //   190: getfield O : Lorg/objectweb/asm/Label;
    //   193: getfield h : Lorg/objectweb/asm/Frame;
    //   196: iload_1
    //   197: iconst_0
    //   198: aconst_null
    //   199: aconst_null
    //   200: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   203: iload_3
    //   204: ifeq -> 340
    //   207: goto -> 211
    //   210: athrow
    //   211: iload_1
    //   212: sipush #168
    //   215: goto -> 219
    //   218: athrow
    //   219: iload_3
    //   220: ifne -> 249
    //   223: if_icmpne -> 317
    //   226: goto -> 230
    //   229: athrow
    //   230: aload_2
    //   231: iload_3
    //   232: ifne -> 312
    //   235: goto -> 239
    //   238: athrow
    //   239: getfield a : I
    //   242: sipush #512
    //   245: goto -> 249
    //   248: athrow
    //   249: iand
    //   250: ifne -> 279
    //   253: aload_2
    //   254: dup
    //   255: getfield a : I
    //   258: sipush #512
    //   261: ior
    //   262: putfield a : I
    //   265: aload_0
    //   266: dup
    //   267: getfield K : I
    //   270: iconst_1
    //   271: iadd
    //   272: putfield K : I
    //   275: goto -> 279
    //   278: athrow
    //   279: aload_0
    //   280: getfield O : Lorg/objectweb/asm/Label;
    //   283: dup
    //   284: getfield a : I
    //   287: sipush #128
    //   290: ior
    //   291: putfield a : I
    //   294: aload_0
    //   295: aload_0
    //   296: getfield P : I
    //   299: iconst_1
    //   300: iadd
    //   301: aload_2
    //   302: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   305: new org/objectweb/asm/Label
    //   308: dup
    //   309: invokespecial <init> : ()V
    //   312: astore #5
    //   314: goto -> 340
    //   317: aload_0
    //   318: dup
    //   319: getfield P : I
    //   322: getstatic org/objectweb/asm/Frame.a : [I
    //   325: iload_1
    //   326: iaload
    //   327: iadd
    //   328: putfield P : I
    //   331: aload_0
    //   332: aload_0
    //   333: getfield P : I
    //   336: aload_2
    //   337: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   340: aload_2
    //   341: getfield a : I
    //   344: iconst_2
    //   345: iand
    //   346: iload_3
    //   347: ifne -> 571
    //   350: ifeq -> 565
    //   353: goto -> 357
    //   356: athrow
    //   357: aload_2
    //   358: getfield c : I
    //   361: aload_0
    //   362: getfield r : Lorg/objectweb/asm/ByteVector;
    //   365: getfield b : I
    //   368: isub
    //   369: iload_3
    //   370: ifne -> 571
    //   373: goto -> 377
    //   376: athrow
    //   377: sipush #-32768
    //   380: if_icmpge -> 565
    //   383: goto -> 387
    //   386: athrow
    //   387: iload_1
    //   388: sipush #167
    //   391: iload_3
    //   392: ifne -> 433
    //   395: goto -> 399
    //   398: athrow
    //   399: if_icmpne -> 425
    //   402: goto -> 406
    //   405: athrow
    //   406: aload_0
    //   407: getfield r : Lorg/objectweb/asm/ByteVector;
    //   410: sipush #200
    //   413: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   416: pop
    //   417: iload_3
    //   418: ifeq -> 542
    //   421: goto -> 425
    //   424: athrow
    //   425: iload_1
    //   426: sipush #168
    //   429: goto -> 433
    //   432: athrow
    //   433: if_icmpne -> 455
    //   436: aload_0
    //   437: getfield r : Lorg/objectweb/asm/ByteVector;
    //   440: sipush #201
    //   443: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   446: pop
    //   447: iload_3
    //   448: ifeq -> 542
    //   451: goto -> 455
    //   454: athrow
    //   455: aload #5
    //   457: iload_3
    //   458: ifne -> 474
    //   461: goto -> 465
    //   464: athrow
    //   465: ifnull -> 484
    //   468: goto -> 472
    //   471: athrow
    //   472: aload #5
    //   474: dup
    //   475: getfield a : I
    //   478: bipush #16
    //   480: ior
    //   481: putfield a : I
    //   484: aload_0
    //   485: getfield r : Lorg/objectweb/asm/ByteVector;
    //   488: iload_1
    //   489: sipush #166
    //   492: iload_3
    //   493: ifne -> 516
    //   496: if_icmpgt -> 514
    //   499: goto -> 503
    //   502: athrow
    //   503: iload_1
    //   504: iconst_1
    //   505: iadd
    //   506: iconst_1
    //   507: ixor
    //   508: iconst_1
    //   509: isub
    //   510: goto -> 517
    //   513: athrow
    //   514: iload_1
    //   515: iconst_1
    //   516: ixor
    //   517: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   520: pop
    //   521: aload_0
    //   522: getfield r : Lorg/objectweb/asm/ByteVector;
    //   525: bipush #8
    //   527: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   530: pop
    //   531: aload_0
    //   532: getfield r : Lorg/objectweb/asm/ByteVector;
    //   535: sipush #200
    //   538: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   541: pop
    //   542: aload_2
    //   543: aload_0
    //   544: aload_0
    //   545: getfield r : Lorg/objectweb/asm/ByteVector;
    //   548: aload_0
    //   549: getfield r : Lorg/objectweb/asm/ByteVector;
    //   552: getfield b : I
    //   555: iconst_1
    //   556: isub
    //   557: iconst_1
    //   558: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   561: iload_3
    //   562: ifeq -> 645
    //   565: iload #4
    //   567: goto -> 571
    //   570: athrow
    //   571: ifeq -> 613
    //   574: aload_0
    //   575: getfield r : Lorg/objectweb/asm/ByteVector;
    //   578: iload_1
    //   579: bipush #33
    //   581: iadd
    //   582: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   585: pop
    //   586: aload_2
    //   587: aload_0
    //   588: aload_0
    //   589: getfield r : Lorg/objectweb/asm/ByteVector;
    //   592: aload_0
    //   593: getfield r : Lorg/objectweb/asm/ByteVector;
    //   596: getfield b : I
    //   599: iconst_1
    //   600: isub
    //   601: iconst_1
    //   602: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   605: iload_3
    //   606: ifeq -> 645
    //   609: goto -> 613
    //   612: athrow
    //   613: aload_0
    //   614: getfield r : Lorg/objectweb/asm/ByteVector;
    //   617: iload_1
    //   618: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   621: pop
    //   622: aload_2
    //   623: aload_0
    //   624: aload_0
    //   625: getfield r : Lorg/objectweb/asm/ByteVector;
    //   628: aload_0
    //   629: getfield r : Lorg/objectweb/asm/ByteVector;
    //   632: getfield b : I
    //   635: iconst_1
    //   636: isub
    //   637: iconst_0
    //   638: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   641: goto -> 645
    //   644: athrow
    //   645: aload_0
    //   646: getfield O : Lorg/objectweb/asm/Label;
    //   649: iload_3
    //   650: ifne -> 662
    //   653: ifnull -> 690
    //   656: goto -> 660
    //   659: athrow
    //   660: aload #5
    //   662: ifnull -> 675
    //   665: aload_0
    //   666: aload #5
    //   668: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   671: goto -> 675
    //   674: athrow
    //   675: iload_1
    //   676: sipush #167
    //   679: if_icmpne -> 690
    //   682: aload_0
    //   683: invokespecial e : ()V
    //   686: goto -> 690
    //   689: athrow
    //   690: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   9	20	23	java/lang/IllegalStateException
    //   30	39	42	java/lang/IllegalStateException
    //   36	47	50	java/lang/IllegalStateException
    //   70	81	84	java/lang/IllegalStateException
    //   75	86	89	java/lang/IllegalStateException
    //   90	100	103	java/lang/IllegalStateException
    //   97	126	129	java/lang/IllegalStateException
    //   104	153	156	java/lang/IllegalStateException
    //   130	164	167	java/lang/IllegalStateException
    //   177	185	188	java/lang/IllegalStateException
    //   182	207	210	java/lang/IllegalStateException
    //   189	215	218	java/lang/IllegalStateException
    //   219	226	229	java/lang/IllegalStateException
    //   223	235	238	java/lang/IllegalStateException
    //   230	245	248	java/lang/IllegalStateException
    //   249	275	278	java/lang/IllegalStateException
    //   340	353	356	java/lang/IllegalStateException
    //   350	373	376	java/lang/IllegalStateException
    //   357	383	386	java/lang/IllegalStateException
    //   377	395	398	java/lang/IllegalStateException
    //   387	402	405	java/lang/IllegalStateException
    //   399	421	424	java/lang/IllegalStateException
    //   406	429	432	java/lang/IllegalStateException
    //   433	451	454	java/lang/IllegalStateException
    //   436	461	464	java/lang/IllegalStateException
    //   455	468	471	java/lang/IllegalStateException
    //   484	499	502	java/lang/IllegalStateException
    //   496	513	513	java/lang/IllegalStateException
    //   542	567	570	java/lang/IllegalStateException
    //   571	609	612	java/lang/IllegalStateException
    //   574	641	644	java/lang/IllegalStateException
    //   645	656	659	java/lang/IllegalStateException
    //   662	671	674	java/lang/IllegalStateException
    //   675	686	689	java/lang/IllegalStateException
  }
  
  public void visitLabel(Label paramLabel) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   8: dup
    //   9: getfield J : Z
    //   12: aload_1
    //   13: aload_0
    //   14: aload_0
    //   15: getfield r : Lorg/objectweb/asm/ByteVector;
    //   18: getfield b : I
    //   21: aload_0
    //   22: getfield r : Lorg/objectweb/asm/ByteVector;
    //   25: getfield a : [B
    //   28: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;I[B)Z
    //   31: ior
    //   32: putfield J : Z
    //   35: aload_1
    //   36: getfield a : I
    //   39: iconst_1
    //   40: iand
    //   41: iload_2
    //   42: ifne -> 57
    //   45: ifeq -> 53
    //   48: goto -> 52
    //   51: athrow
    //   52: return
    //   53: aload_0
    //   54: getfield L : I
    //   57: iload_2
    //   58: ifne -> 303
    //   61: ifne -> 295
    //   64: goto -> 68
    //   67: athrow
    //   68: aload_0
    //   69: getfield O : Lorg/objectweb/asm/Label;
    //   72: iload_2
    //   73: ifne -> 160
    //   76: goto -> 80
    //   79: athrow
    //   80: ifnull -> 154
    //   83: goto -> 87
    //   86: athrow
    //   87: aload_1
    //   88: iload_2
    //   89: ifne -> 137
    //   92: goto -> 96
    //   95: athrow
    //   96: getfield c : I
    //   99: aload_0
    //   100: getfield O : Lorg/objectweb/asm/Label;
    //   103: getfield c : I
    //   106: if_icmpne -> 148
    //   109: goto -> 113
    //   112: athrow
    //   113: aload_0
    //   114: getfield O : Lorg/objectweb/asm/Label;
    //   117: dup
    //   118: getfield a : I
    //   121: aload_1
    //   122: getfield a : I
    //   125: bipush #16
    //   127: iand
    //   128: ior
    //   129: putfield a : I
    //   132: aload_1
    //   133: goto -> 137
    //   136: athrow
    //   137: aload_0
    //   138: getfield O : Lorg/objectweb/asm/Label;
    //   141: getfield h : Lorg/objectweb/asm/Frame;
    //   144: putfield h : Lorg/objectweb/asm/Frame;
    //   147: return
    //   148: aload_0
    //   149: iconst_0
    //   150: aload_1
    //   151: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   154: aload_0
    //   155: aload_1
    //   156: putfield O : Lorg/objectweb/asm/Label;
    //   159: aload_1
    //   160: iload_2
    //   161: ifne -> 209
    //   164: getfield h : Lorg/objectweb/asm/Frame;
    //   167: ifnonnull -> 197
    //   170: goto -> 174
    //   173: athrow
    //   174: aload_1
    //   175: new org/objectweb/asm/Frame
    //   178: dup
    //   179: invokespecial <init> : ()V
    //   182: putfield h : Lorg/objectweb/asm/Frame;
    //   185: aload_1
    //   186: getfield h : Lorg/objectweb/asm/Frame;
    //   189: aload_1
    //   190: putfield b : Lorg/objectweb/asm/Label;
    //   193: goto -> 197
    //   196: athrow
    //   197: aload_0
    //   198: iload_2
    //   199: ifne -> 287
    //   202: getfield N : Lorg/objectweb/asm/Label;
    //   205: goto -> 209
    //   208: athrow
    //   209: ifnull -> 286
    //   212: aload_1
    //   213: iload_2
    //   214: ifne -> 282
    //   217: goto -> 221
    //   220: athrow
    //   221: getfield c : I
    //   224: aload_0
    //   225: getfield N : Lorg/objectweb/asm/Label;
    //   228: getfield c : I
    //   231: if_icmpne -> 278
    //   234: goto -> 238
    //   237: athrow
    //   238: aload_0
    //   239: getfield N : Lorg/objectweb/asm/Label;
    //   242: dup
    //   243: getfield a : I
    //   246: aload_1
    //   247: getfield a : I
    //   250: bipush #16
    //   252: iand
    //   253: ior
    //   254: putfield a : I
    //   257: aload_1
    //   258: aload_0
    //   259: getfield N : Lorg/objectweb/asm/Label;
    //   262: getfield h : Lorg/objectweb/asm/Frame;
    //   265: putfield h : Lorg/objectweb/asm/Frame;
    //   268: aload_0
    //   269: aload_0
    //   270: getfield N : Lorg/objectweb/asm/Label;
    //   273: putfield O : Lorg/objectweb/asm/Label;
    //   276: return
    //   277: athrow
    //   278: aload_0
    //   279: getfield N : Lorg/objectweb/asm/Label;
    //   282: aload_1
    //   283: putfield i : Lorg/objectweb/asm/Label;
    //   286: aload_0
    //   287: aload_1
    //   288: putfield N : Lorg/objectweb/asm/Label;
    //   291: iload_2
    //   292: ifeq -> 472
    //   295: aload_0
    //   296: getfield L : I
    //   299: goto -> 303
    //   302: athrow
    //   303: iconst_1
    //   304: iload_2
    //   305: ifne -> 383
    //   308: if_icmpne -> 366
    //   311: goto -> 315
    //   314: athrow
    //   315: aload_0
    //   316: getfield O : Lorg/objectweb/asm/Label;
    //   319: iload_2
    //   320: ifne -> 355
    //   323: goto -> 327
    //   326: athrow
    //   327: ifnonnull -> 347
    //   330: goto -> 334
    //   333: athrow
    //   334: aload_0
    //   335: aload_1
    //   336: putfield O : Lorg/objectweb/asm/Label;
    //   339: iload_2
    //   340: ifeq -> 472
    //   343: goto -> 347
    //   346: athrow
    //   347: aload_0
    //   348: getfield O : Lorg/objectweb/asm/Label;
    //   351: goto -> 355
    //   354: athrow
    //   355: getfield h : Lorg/objectweb/asm/Frame;
    //   358: aload_1
    //   359: putfield b : Lorg/objectweb/asm/Label;
    //   362: iload_2
    //   363: ifeq -> 472
    //   366: aload_0
    //   367: iload_2
    //   368: ifne -> 387
    //   371: goto -> 375
    //   374: athrow
    //   375: getfield L : I
    //   378: iconst_2
    //   379: goto -> 383
    //   382: athrow
    //   383: if_icmpne -> 472
    //   386: aload_0
    //   387: getfield O : Lorg/objectweb/asm/Label;
    //   390: iload_2
    //   391: ifne -> 452
    //   394: ifnull -> 425
    //   397: goto -> 401
    //   400: athrow
    //   401: aload_0
    //   402: getfield O : Lorg/objectweb/asm/Label;
    //   405: aload_0
    //   406: getfield Q : I
    //   409: putfield g : I
    //   412: aload_0
    //   413: aload_0
    //   414: getfield P : I
    //   417: aload_1
    //   418: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   421: goto -> 425
    //   424: athrow
    //   425: aload_0
    //   426: aload_1
    //   427: putfield O : Lorg/objectweb/asm/Label;
    //   430: aload_0
    //   431: iconst_0
    //   432: putfield P : I
    //   435: aload_0
    //   436: iconst_0
    //   437: putfield Q : I
    //   440: aload_0
    //   441: iload_2
    //   442: ifne -> 468
    //   445: getfield N : Lorg/objectweb/asm/Label;
    //   448: goto -> 452
    //   451: athrow
    //   452: ifnull -> 467
    //   455: aload_0
    //   456: getfield N : Lorg/objectweb/asm/Label;
    //   459: aload_1
    //   460: putfield i : Lorg/objectweb/asm/Label;
    //   463: goto -> 467
    //   466: athrow
    //   467: aload_0
    //   468: aload_1
    //   469: putfield N : Lorg/objectweb/asm/Label;
    //   472: return
    // Exception table:
    //   from	to	target	type
    //   4	48	51	java/lang/IllegalStateException
    //   57	64	67	java/lang/IllegalStateException
    //   61	76	79	java/lang/IllegalStateException
    //   68	83	86	java/lang/IllegalStateException
    //   80	92	95	java/lang/IllegalStateException
    //   87	109	112	java/lang/IllegalStateException
    //   96	133	136	java/lang/IllegalStateException
    //   160	170	173	java/lang/IllegalStateException
    //   164	193	196	java/lang/IllegalStateException
    //   197	205	208	java/lang/IllegalStateException
    //   209	217	220	java/lang/IllegalStateException
    //   212	234	237	java/lang/IllegalStateException
    //   221	277	277	java/lang/IllegalStateException
    //   287	299	302	java/lang/IllegalStateException
    //   303	311	314	java/lang/IllegalStateException
    //   308	323	326	java/lang/IllegalStateException
    //   315	330	333	java/lang/IllegalStateException
    //   327	343	346	java/lang/IllegalStateException
    //   334	351	354	java/lang/IllegalStateException
    //   355	371	374	java/lang/IllegalStateException
    //   366	379	382	java/lang/IllegalStateException
    //   387	397	400	java/lang/IllegalStateException
    //   394	421	424	java/lang/IllegalStateException
    //   425	448	451	java/lang/IllegalStateException
    //   452	463	466	java/lang/IllegalStateException
  }
  
  public void visitLdcInsn(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_1
    //   19: invokevirtual a : (Ljava/lang/Object;)Lorg/objectweb/asm/Item;
    //   22: astore_3
    //   23: istore_2
    //   24: aload_0
    //   25: iload_2
    //   26: ifne -> 44
    //   29: getfield O : Lorg/objectweb/asm/Label;
    //   32: ifnull -> 194
    //   35: goto -> 39
    //   38: athrow
    //   39: aload_0
    //   40: goto -> 44
    //   43: athrow
    //   44: iload_2
    //   45: ifne -> 79
    //   48: getfield L : I
    //   51: ifeq -> 78
    //   54: goto -> 58
    //   57: athrow
    //   58: aload_0
    //   59: getfield L : I
    //   62: iconst_1
    //   63: iload_2
    //   64: ifne -> 109
    //   67: goto -> 71
    //   70: athrow
    //   71: if_icmpne -> 100
    //   74: goto -> 78
    //   77: athrow
    //   78: aload_0
    //   79: getfield O : Lorg/objectweb/asm/Label;
    //   82: getfield h : Lorg/objectweb/asm/Frame;
    //   85: bipush #18
    //   87: iconst_0
    //   88: aload_0
    //   89: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   92: aload_3
    //   93: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   96: iload_2
    //   97: ifeq -> 194
    //   100: aload_3
    //   101: getfield b : I
    //   104: iconst_5
    //   105: goto -> 109
    //   108: athrow
    //   109: iload_2
    //   110: ifne -> 150
    //   113: if_icmpeq -> 141
    //   116: goto -> 120
    //   119: athrow
    //   120: aload_3
    //   121: getfield b : I
    //   124: bipush #6
    //   126: iload_2
    //   127: ifne -> 166
    //   130: goto -> 134
    //   133: athrow
    //   134: if_icmpne -> 157
    //   137: goto -> 141
    //   140: athrow
    //   141: aload_0
    //   142: getfield P : I
    //   145: iconst_2
    //   146: goto -> 150
    //   149: athrow
    //   150: iadd
    //   151: istore #4
    //   153: iload_2
    //   154: ifeq -> 169
    //   157: aload_0
    //   158: getfield P : I
    //   161: iconst_1
    //   162: goto -> 166
    //   165: athrow
    //   166: iadd
    //   167: istore #4
    //   169: iload #4
    //   171: aload_0
    //   172: getfield Q : I
    //   175: if_icmple -> 188
    //   178: aload_0
    //   179: iload #4
    //   181: putfield Q : I
    //   184: goto -> 188
    //   187: athrow
    //   188: aload_0
    //   189: iload #4
    //   191: putfield P : I
    //   194: aload_3
    //   195: getfield a : I
    //   198: istore #4
    //   200: iload_2
    //   201: ifne -> 253
    //   204: aload_3
    //   205: getfield b : I
    //   208: iconst_5
    //   209: if_icmpeq -> 237
    //   212: goto -> 216
    //   215: athrow
    //   216: aload_3
    //   217: getfield b : I
    //   220: bipush #6
    //   222: iload_2
    //   223: ifne -> 266
    //   226: goto -> 230
    //   229: athrow
    //   230: if_icmpne -> 257
    //   233: goto -> 237
    //   236: athrow
    //   237: aload_0
    //   238: getfield r : Lorg/objectweb/asm/ByteVector;
    //   241: bipush #20
    //   243: iload #4
    //   245: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   248: pop
    //   249: goto -> 253
    //   252: athrow
    //   253: iload_2
    //   254: ifeq -> 305
    //   257: iload #4
    //   259: sipush #256
    //   262: goto -> 266
    //   265: athrow
    //   266: if_icmplt -> 289
    //   269: aload_0
    //   270: getfield r : Lorg/objectweb/asm/ByteVector;
    //   273: bipush #19
    //   275: iload #4
    //   277: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   280: pop
    //   281: iload_2
    //   282: ifeq -> 305
    //   285: goto -> 289
    //   288: athrow
    //   289: aload_0
    //   290: getfield r : Lorg/objectweb/asm/ByteVector;
    //   293: bipush #18
    //   295: iload #4
    //   297: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   300: pop
    //   301: goto -> 305
    //   304: athrow
    //   305: return
    // Exception table:
    //   from	to	target	type
    //   24	35	38	java/lang/IllegalStateException
    //   29	40	43	java/lang/IllegalStateException
    //   44	54	57	java/lang/IllegalStateException
    //   48	67	70	java/lang/IllegalStateException
    //   58	74	77	java/lang/IllegalStateException
    //   79	105	108	java/lang/IllegalStateException
    //   109	116	119	java/lang/IllegalStateException
    //   113	130	133	java/lang/IllegalStateException
    //   120	137	140	java/lang/IllegalStateException
    //   134	146	149	java/lang/IllegalStateException
    //   153	162	165	java/lang/IllegalStateException
    //   169	184	187	java/lang/IllegalStateException
    //   200	212	215	java/lang/IllegalStateException
    //   204	226	229	java/lang/IllegalStateException
    //   216	233	236	java/lang/IllegalStateException
    //   230	249	252	java/lang/IllegalStateException
    //   253	262	265	java/lang/IllegalStateException
    //   266	285	288	java/lang/IllegalStateException
    //   269	301	304	java/lang/IllegalStateException
  }
  
  public void visitIincInsn(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: aload_0
    //   6: getfield r : Lorg/objectweb/asm/ByteVector;
    //   9: getfield b : I
    //   12: putfield Y : I
    //   15: aload_0
    //   16: iload_3
    //   17: ifne -> 86
    //   20: getfield O : Lorg/objectweb/asm/Label;
    //   23: ifnull -> 85
    //   26: goto -> 30
    //   29: athrow
    //   30: aload_0
    //   31: iload_3
    //   32: ifne -> 70
    //   35: goto -> 39
    //   38: athrow
    //   39: getfield L : I
    //   42: ifeq -> 69
    //   45: goto -> 49
    //   48: athrow
    //   49: aload_0
    //   50: getfield L : I
    //   53: iconst_1
    //   54: iload_3
    //   55: ifne -> 90
    //   58: goto -> 62
    //   61: athrow
    //   62: if_icmpne -> 85
    //   65: goto -> 69
    //   68: athrow
    //   69: aload_0
    //   70: getfield O : Lorg/objectweb/asm/Label;
    //   73: getfield h : Lorg/objectweb/asm/Frame;
    //   76: sipush #132
    //   79: iload_1
    //   80: aconst_null
    //   81: aconst_null
    //   82: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   85: aload_0
    //   86: getfield L : I
    //   89: iconst_3
    //   90: iload_3
    //   91: ifne -> 137
    //   94: if_icmpeq -> 133
    //   97: goto -> 101
    //   100: athrow
    //   101: iload_1
    //   102: iconst_1
    //   103: iadd
    //   104: istore #4
    //   106: iload #4
    //   108: aload_0
    //   109: getfield t : I
    //   112: iload_3
    //   113: ifne -> 137
    //   116: if_icmple -> 133
    //   119: goto -> 123
    //   122: athrow
    //   123: aload_0
    //   124: iload #4
    //   126: putfield t : I
    //   129: goto -> 133
    //   132: athrow
    //   133: iload_1
    //   134: sipush #255
    //   137: iload_3
    //   138: ifne -> 155
    //   141: if_icmpgt -> 176
    //   144: goto -> 148
    //   147: athrow
    //   148: iload_2
    //   149: bipush #127
    //   151: goto -> 155
    //   154: athrow
    //   155: iload_3
    //   156: ifne -> 173
    //   159: if_icmpgt -> 176
    //   162: goto -> 166
    //   165: athrow
    //   166: iload_2
    //   167: bipush #-128
    //   169: goto -> 173
    //   172: athrow
    //   173: if_icmpge -> 206
    //   176: aload_0
    //   177: getfield r : Lorg/objectweb/asm/ByteVector;
    //   180: sipush #196
    //   183: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   186: sipush #132
    //   189: iload_1
    //   190: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   193: iload_2
    //   194: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   197: pop
    //   198: iload_3
    //   199: ifeq -> 226
    //   202: goto -> 206
    //   205: athrow
    //   206: aload_0
    //   207: getfield r : Lorg/objectweb/asm/ByteVector;
    //   210: sipush #132
    //   213: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   216: iload_1
    //   217: iload_2
    //   218: invokevirtual a : (II)Lorg/objectweb/asm/ByteVector;
    //   221: pop
    //   222: goto -> 226
    //   225: athrow
    //   226: return
    // Exception table:
    //   from	to	target	type
    //   4	26	29	java/lang/IllegalStateException
    //   20	35	38	java/lang/IllegalStateException
    //   30	45	48	java/lang/IllegalStateException
    //   39	58	61	java/lang/IllegalStateException
    //   49	65	68	java/lang/IllegalStateException
    //   90	97	100	java/lang/IllegalStateException
    //   106	119	122	java/lang/IllegalStateException
    //   116	129	132	java/lang/IllegalStateException
    //   137	144	147	java/lang/IllegalStateException
    //   141	151	154	java/lang/IllegalStateException
    //   155	162	165	java/lang/IllegalStateException
    //   159	169	172	java/lang/IllegalStateException
    //   173	202	205	java/lang/IllegalStateException
    //   176	222	225	java/lang/IllegalStateException
  }
  
  public void visitTableSwitchInsn(int paramInt1, int paramInt2, Label paramLabel, Label[] paramArrayOfLabel) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield r : Lorg/objectweb/asm/ByteVector;
    //   18: getfield b : I
    //   21: istore #6
    //   23: aload_0
    //   24: getfield r : Lorg/objectweb/asm/ByteVector;
    //   27: sipush #170
    //   30: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   33: pop
    //   34: aload_0
    //   35: getfield r : Lorg/objectweb/asm/ByteVector;
    //   38: aconst_null
    //   39: iconst_0
    //   40: iconst_4
    //   41: aload_0
    //   42: getfield r : Lorg/objectweb/asm/ByteVector;
    //   45: getfield b : I
    //   48: iconst_4
    //   49: irem
    //   50: isub
    //   51: iconst_4
    //   52: irem
    //   53: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   56: pop
    //   57: istore #5
    //   59: aload_3
    //   60: aload_0
    //   61: aload_0
    //   62: getfield r : Lorg/objectweb/asm/ByteVector;
    //   65: iload #6
    //   67: iconst_1
    //   68: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   71: aload_0
    //   72: getfield r : Lorg/objectweb/asm/ByteVector;
    //   75: iload_1
    //   76: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   79: iload_2
    //   80: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   83: pop
    //   84: iconst_0
    //   85: istore #7
    //   87: iload #7
    //   89: aload #4
    //   91: arraylength
    //   92: if_icmpge -> 128
    //   95: aload #4
    //   97: iload #7
    //   99: aaload
    //   100: aload_0
    //   101: aload_0
    //   102: getfield r : Lorg/objectweb/asm/ByteVector;
    //   105: iload #6
    //   107: iconst_1
    //   108: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   111: iinc #7, 1
    //   114: iload #5
    //   116: ifne -> 135
    //   119: iload #5
    //   121: ifeq -> 87
    //   124: goto -> 128
    //   127: athrow
    //   128: aload_0
    //   129: aload_3
    //   130: aload #4
    //   132: invokespecial a : (Lorg/objectweb/asm/Label;[Lorg/objectweb/asm/Label;)V
    //   135: return
    // Exception table:
    //   from	to	target	type
    //   95	124	127	java/lang/IllegalStateException
  }
  
  public void visitLookupSwitchInsn(Label paramLabel, int[] paramArrayOfint, Label[] paramArrayOfLabel) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield r : Lorg/objectweb/asm/ByteVector;
    //   18: getfield b : I
    //   21: istore #5
    //   23: aload_0
    //   24: getfield r : Lorg/objectweb/asm/ByteVector;
    //   27: sipush #171
    //   30: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   33: pop
    //   34: aload_0
    //   35: getfield r : Lorg/objectweb/asm/ByteVector;
    //   38: aconst_null
    //   39: iconst_0
    //   40: iconst_4
    //   41: aload_0
    //   42: getfield r : Lorg/objectweb/asm/ByteVector;
    //   45: getfield b : I
    //   48: iconst_4
    //   49: irem
    //   50: isub
    //   51: iconst_4
    //   52: irem
    //   53: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   56: pop
    //   57: aload_1
    //   58: aload_0
    //   59: aload_0
    //   60: getfield r : Lorg/objectweb/asm/ByteVector;
    //   63: iload #5
    //   65: iconst_1
    //   66: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   69: aload_0
    //   70: getfield r : Lorg/objectweb/asm/ByteVector;
    //   73: aload_3
    //   74: arraylength
    //   75: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   78: pop
    //   79: istore #4
    //   81: iconst_0
    //   82: istore #6
    //   84: iload #6
    //   86: aload_3
    //   87: arraylength
    //   88: if_icmpge -> 135
    //   91: aload_0
    //   92: getfield r : Lorg/objectweb/asm/ByteVector;
    //   95: aload_2
    //   96: iload #6
    //   98: iaload
    //   99: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   102: pop
    //   103: aload_3
    //   104: iload #6
    //   106: aaload
    //   107: aload_0
    //   108: aload_0
    //   109: getfield r : Lorg/objectweb/asm/ByteVector;
    //   112: iload #5
    //   114: iconst_1
    //   115: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;Lorg/objectweb/asm/ByteVector;IZ)V
    //   118: iinc #6, 1
    //   121: iload #4
    //   123: ifne -> 141
    //   126: iload #4
    //   128: ifeq -> 84
    //   131: goto -> 135
    //   134: athrow
    //   135: aload_0
    //   136: aload_1
    //   137: aload_3
    //   138: invokespecial a : (Lorg/objectweb/asm/Label;[Lorg/objectweb/asm/Label;)V
    //   141: return
    // Exception table:
    //   from	to	target	type
    //   91	131	134	java/lang/IllegalStateException
  }
  
  private void a(Label paramLabel, Label[] paramArrayOfLabel) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: iload_3
    //   6: ifne -> 24
    //   9: getfield O : Lorg/objectweb/asm/Label;
    //   12: ifnull -> 193
    //   15: goto -> 19
    //   18: athrow
    //   19: aload_0
    //   20: goto -> 24
    //   23: athrow
    //   24: getfield L : I
    //   27: iload_3
    //   28: ifne -> 153
    //   31: ifne -> 129
    //   34: goto -> 38
    //   37: athrow
    //   38: aload_0
    //   39: getfield O : Lorg/objectweb/asm/Label;
    //   42: getfield h : Lorg/objectweb/asm/Frame;
    //   45: sipush #171
    //   48: iconst_0
    //   49: aconst_null
    //   50: aconst_null
    //   51: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   54: aload_0
    //   55: iconst_0
    //   56: aload_1
    //   57: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   60: aload_1
    //   61: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   64: dup
    //   65: getfield a : I
    //   68: bipush #16
    //   70: ior
    //   71: putfield a : I
    //   74: iconst_0
    //   75: istore #4
    //   77: iload #4
    //   79: aload_2
    //   80: arraylength
    //   81: if_icmpge -> 125
    //   84: aload_0
    //   85: iconst_0
    //   86: aload_2
    //   87: iload #4
    //   89: aaload
    //   90: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   93: aload_2
    //   94: iload #4
    //   96: aaload
    //   97: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   100: dup
    //   101: getfield a : I
    //   104: bipush #16
    //   106: ior
    //   107: putfield a : I
    //   110: iinc #4, 1
    //   113: iload_3
    //   114: ifne -> 189
    //   117: iload_3
    //   118: ifeq -> 77
    //   121: goto -> 125
    //   124: athrow
    //   125: iload_3
    //   126: ifeq -> 189
    //   129: aload_0
    //   130: dup
    //   131: getfield P : I
    //   134: iconst_1
    //   135: isub
    //   136: putfield P : I
    //   139: aload_0
    //   140: aload_0
    //   141: getfield P : I
    //   144: aload_1
    //   145: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   148: iconst_0
    //   149: goto -> 153
    //   152: athrow
    //   153: istore #4
    //   155: iload #4
    //   157: aload_2
    //   158: arraylength
    //   159: if_icmpge -> 189
    //   162: aload_0
    //   163: aload_0
    //   164: getfield P : I
    //   167: aload_2
    //   168: iload #4
    //   170: aaload
    //   171: invokespecial a : (ILorg/objectweb/asm/Label;)V
    //   174: iinc #4, 1
    //   177: iload_3
    //   178: ifne -> 193
    //   181: iload_3
    //   182: ifeq -> 155
    //   185: goto -> 189
    //   188: athrow
    //   189: aload_0
    //   190: invokespecial e : ()V
    //   193: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   9	20	23	java/lang/IllegalStateException
    //   24	34	37	java/lang/IllegalStateException
    //   84	121	124	java/lang/IllegalStateException
    //   125	149	152	java/lang/IllegalStateException
    //   162	185	188	java/lang/IllegalStateException
  }
  
  public void visitMultiANewArrayInsn(String paramString, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Lorg/objectweb/asm/ByteVector;
    //   5: getfield b : I
    //   8: putfield Y : I
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: aload_0
    //   15: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   18: aload_1
    //   19: invokevirtual a : (Ljava/lang/String;)Lorg/objectweb/asm/Item;
    //   22: astore #4
    //   24: istore_3
    //   25: aload_0
    //   26: iload_3
    //   27: ifne -> 124
    //   30: getfield O : Lorg/objectweb/asm/Label;
    //   33: ifnull -> 123
    //   36: goto -> 40
    //   39: athrow
    //   40: aload_0
    //   41: iload_3
    //   42: ifne -> 84
    //   45: goto -> 49
    //   48: athrow
    //   49: getfield L : I
    //   52: ifeq -> 79
    //   55: goto -> 59
    //   58: athrow
    //   59: aload_0
    //   60: iload_3
    //   61: ifne -> 112
    //   64: goto -> 68
    //   67: athrow
    //   68: getfield L : I
    //   71: iconst_1
    //   72: if_icmpne -> 107
    //   75: goto -> 79
    //   78: athrow
    //   79: aload_0
    //   80: goto -> 84
    //   83: athrow
    //   84: getfield O : Lorg/objectweb/asm/Label;
    //   87: getfield h : Lorg/objectweb/asm/Frame;
    //   90: sipush #197
    //   93: iload_2
    //   94: aload_0
    //   95: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   98: aload #4
    //   100: invokevirtual a : (IILorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Item;)V
    //   103: iload_3
    //   104: ifeq -> 123
    //   107: aload_0
    //   108: goto -> 112
    //   111: athrow
    //   112: dup
    //   113: getfield P : I
    //   116: iconst_1
    //   117: iload_2
    //   118: isub
    //   119: iadd
    //   120: putfield P : I
    //   123: aload_0
    //   124: getfield r : Lorg/objectweb/asm/ByteVector;
    //   127: sipush #197
    //   130: aload #4
    //   132: getfield a : I
    //   135: invokevirtual b : (II)Lorg/objectweb/asm/ByteVector;
    //   138: iload_2
    //   139: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   142: pop
    //   143: return
    // Exception table:
    //   from	to	target	type
    //   25	36	39	java/lang/IllegalStateException
    //   30	45	48	java/lang/IllegalStateException
    //   40	55	58	java/lang/IllegalStateException
    //   49	64	67	java/lang/IllegalStateException
    //   59	75	78	java/lang/IllegalStateException
    //   68	80	83	java/lang/IllegalStateException
    //   84	108	111	java/lang/IllegalStateException
  }
  
  public AnnotationVisitor visitInsnAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   12: iload_1
    //   13: ldc -16776961
    //   15: iand
    //   16: aload_0
    //   17: getfield Y : I
    //   20: bipush #8
    //   22: ishl
    //   23: ior
    //   24: istore_1
    //   25: iload_1
    //   26: aload_2
    //   27: aload #6
    //   29: invokestatic a : (ILorg/objectweb/asm/TypePath;Lorg/objectweb/asm/ByteVector;)V
    //   32: istore #5
    //   34: aload #6
    //   36: aload_0
    //   37: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   40: aload_3
    //   41: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   44: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   47: iconst_0
    //   48: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   51: pop
    //   52: new org/objectweb/asm/AnnotationWriter
    //   55: dup
    //   56: aload_0
    //   57: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   60: iconst_1
    //   61: aload #6
    //   63: aload #6
    //   65: aload #6
    //   67: getfield b : I
    //   70: iconst_2
    //   71: isub
    //   72: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   75: astore #7
    //   77: iload #5
    //   79: ifne -> 128
    //   82: iload #4
    //   84: ifeq -> 115
    //   87: goto -> 91
    //   90: athrow
    //   91: aload #7
    //   93: aload_0
    //   94: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   97: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   100: aload_0
    //   101: aload #7
    //   103: putfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   106: iload #5
    //   108: ifeq -> 134
    //   111: goto -> 115
    //   114: athrow
    //   115: aload #7
    //   117: aload_0
    //   118: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   121: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   124: goto -> 128
    //   127: athrow
    //   128: aload_0
    //   129: aload #7
    //   131: putfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   134: aload #7
    //   136: areturn
    // Exception table:
    //   from	to	target	type
    //   77	87	90	java/lang/IllegalStateException
    //   82	111	114	java/lang/IllegalStateException
    //   91	124	127	java/lang/IllegalStateException
  }
  
  public void visitTryCatchBlock(Label paramLabel1, Label paramLabel2, Label paramLabel3, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: dup
    //   2: getfield A : I
    //   5: iconst_1
    //   6: iadd
    //   7: putfield A : I
    //   10: new org/objectweb/asm/Handler
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: astore #6
    //   19: aload #6
    //   21: aload_1
    //   22: putfield a : Lorg/objectweb/asm/Label;
    //   25: aload #6
    //   27: aload_2
    //   28: putfield b : Lorg/objectweb/asm/Label;
    //   31: aload #6
    //   33: aload_3
    //   34: putfield c : Lorg/objectweb/asm/Label;
    //   37: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   40: aload #6
    //   42: aload #4
    //   44: putfield d : Ljava/lang/String;
    //   47: istore #5
    //   49: aload #6
    //   51: aload #4
    //   53: ifnull -> 69
    //   56: aload_0
    //   57: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   60: aload #4
    //   62: invokevirtual newClass : (Ljava/lang/String;)I
    //   65: goto -> 70
    //   68: athrow
    //   69: iconst_0
    //   70: putfield e : I
    //   73: aload_0
    //   74: getfield C : Lorg/objectweb/asm/Handler;
    //   77: iload #5
    //   79: ifne -> 112
    //   82: ifnonnull -> 104
    //   85: goto -> 89
    //   88: athrow
    //   89: aload_0
    //   90: aload #6
    //   92: putfield B : Lorg/objectweb/asm/Handler;
    //   95: iload #5
    //   97: ifeq -> 117
    //   100: goto -> 104
    //   103: athrow
    //   104: aload_0
    //   105: getfield C : Lorg/objectweb/asm/Handler;
    //   108: goto -> 112
    //   111: athrow
    //   112: aload #6
    //   114: putfield f : Lorg/objectweb/asm/Handler;
    //   117: aload_0
    //   118: aload #6
    //   120: putfield C : Lorg/objectweb/asm/Handler;
    //   123: return
    // Exception table:
    //   from	to	target	type
    //   49	68	68	java/lang/IllegalStateException
    //   70	85	88	java/lang/IllegalStateException
    //   82	100	103	java/lang/IllegalStateException
    //   89	108	111	java/lang/IllegalStateException
  }
  
  public AnnotationVisitor visitTryCatchAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #6
    //   9: iload_1
    //   10: aload_2
    //   11: aload #6
    //   13: invokestatic a : (ILorg/objectweb/asm/TypePath;Lorg/objectweb/asm/ByteVector;)V
    //   16: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   19: aload #6
    //   21: aload_0
    //   22: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   25: aload_3
    //   26: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   29: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   32: iconst_0
    //   33: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   36: pop
    //   37: istore #5
    //   39: new org/objectweb/asm/AnnotationWriter
    //   42: dup
    //   43: aload_0
    //   44: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   47: iconst_1
    //   48: aload #6
    //   50: aload #6
    //   52: aload #6
    //   54: getfield b : I
    //   57: iconst_2
    //   58: isub
    //   59: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   62: astore #7
    //   64: iload #5
    //   66: ifne -> 115
    //   69: iload #4
    //   71: ifeq -> 102
    //   74: goto -> 78
    //   77: athrow
    //   78: aload #7
    //   80: aload_0
    //   81: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   84: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   87: aload_0
    //   88: aload #7
    //   90: putfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   93: iload #5
    //   95: ifeq -> 121
    //   98: goto -> 102
    //   101: athrow
    //   102: aload #7
    //   104: aload_0
    //   105: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   108: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   111: goto -> 115
    //   114: athrow
    //   115: aload_0
    //   116: aload #7
    //   118: putfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   121: aload #7
    //   123: areturn
    // Exception table:
    //   from	to	target	type
    //   64	74	77	java/lang/IllegalStateException
    //   69	98	101	java/lang/IllegalStateException
    //   78	111	114	java/lang/IllegalStateException
  }
  
  public void visitLocalVariable(String paramString1, String paramString2, String paramString3, Label paramLabel1, Label paramLabel2, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #7
    //   5: aload_3
    //   6: ifnull -> 108
    //   9: aload_0
    //   10: getfield G : Lorg/objectweb/asm/ByteVector;
    //   13: iload #7
    //   15: ifne -> 107
    //   18: goto -> 22
    //   21: athrow
    //   22: ifnonnull -> 44
    //   25: goto -> 29
    //   28: athrow
    //   29: aload_0
    //   30: new org/objectweb/asm/ByteVector
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: putfield G : Lorg/objectweb/asm/ByteVector;
    //   40: goto -> 44
    //   43: athrow
    //   44: aload_0
    //   45: dup
    //   46: getfield F : I
    //   49: iconst_1
    //   50: iadd
    //   51: putfield F : I
    //   54: aload_0
    //   55: getfield G : Lorg/objectweb/asm/ByteVector;
    //   58: aload #4
    //   60: getfield c : I
    //   63: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   66: aload #5
    //   68: getfield c : I
    //   71: aload #4
    //   73: getfield c : I
    //   76: isub
    //   77: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   80: aload_0
    //   81: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   84: aload_1
    //   85: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   88: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   91: aload_0
    //   92: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   95: aload_3
    //   96: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   99: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   102: iload #6
    //   104: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   107: pop
    //   108: aload_0
    //   109: getfield E : Lorg/objectweb/asm/ByteVector;
    //   112: iload #7
    //   114: ifne -> 202
    //   117: ifnonnull -> 139
    //   120: goto -> 124
    //   123: athrow
    //   124: aload_0
    //   125: new org/objectweb/asm/ByteVector
    //   128: dup
    //   129: invokespecial <init> : ()V
    //   132: putfield E : Lorg/objectweb/asm/ByteVector;
    //   135: goto -> 139
    //   138: athrow
    //   139: aload_0
    //   140: dup
    //   141: getfield D : I
    //   144: iconst_1
    //   145: iadd
    //   146: putfield D : I
    //   149: aload_0
    //   150: getfield E : Lorg/objectweb/asm/ByteVector;
    //   153: aload #4
    //   155: getfield c : I
    //   158: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   161: aload #5
    //   163: getfield c : I
    //   166: aload #4
    //   168: getfield c : I
    //   171: isub
    //   172: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   175: aload_0
    //   176: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   179: aload_1
    //   180: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   183: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   186: aload_0
    //   187: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   190: aload_2
    //   191: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   194: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   197: iload #6
    //   199: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   202: pop
    //   203: aload_0
    //   204: getfield L : I
    //   207: iload #7
    //   209: ifne -> 229
    //   212: iconst_3
    //   213: if_icmpeq -> 300
    //   216: goto -> 220
    //   219: athrow
    //   220: aload_2
    //   221: iconst_0
    //   222: invokevirtual charAt : (I)C
    //   225: goto -> 229
    //   228: athrow
    //   229: istore #8
    //   231: iload #6
    //   233: iload #8
    //   235: iload #7
    //   237: ifne -> 274
    //   240: bipush #74
    //   242: if_icmpeq -> 269
    //   245: goto -> 249
    //   248: athrow
    //   249: iload #8
    //   251: iload #7
    //   253: ifne -> 274
    //   256: goto -> 260
    //   259: athrow
    //   260: bipush #68
    //   262: if_icmpne -> 277
    //   265: goto -> 269
    //   268: athrow
    //   269: iconst_2
    //   270: goto -> 274
    //   273: athrow
    //   274: goto -> 278
    //   277: iconst_1
    //   278: iadd
    //   279: istore #9
    //   281: iload #9
    //   283: aload_0
    //   284: getfield t : I
    //   287: if_icmple -> 300
    //   290: aload_0
    //   291: iload #9
    //   293: putfield t : I
    //   296: goto -> 300
    //   299: athrow
    //   300: return
    // Exception table:
    //   from	to	target	type
    //   5	18	21	java/lang/IllegalStateException
    //   9	25	28	java/lang/IllegalStateException
    //   22	40	43	java/lang/IllegalStateException
    //   108	120	123	java/lang/IllegalStateException
    //   117	135	138	java/lang/IllegalStateException
    //   202	216	219	java/lang/IllegalStateException
    //   212	225	228	java/lang/IllegalStateException
    //   231	245	248	java/lang/IllegalStateException
    //   240	256	259	java/lang/IllegalStateException
    //   249	265	268	java/lang/IllegalStateException
    //   260	270	273	java/lang/IllegalStateException
    //   281	296	299	java/lang/IllegalStateException
  }
  
  public AnnotationVisitor visitLocalVariableAnnotation(int paramInt, TypePath paramTypePath, Label[] paramArrayOfLabel1, Label[] paramArrayOfLabel2, int[] paramArrayOfint, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: new org/objectweb/asm/ByteVector
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #9
    //   9: aload #9
    //   11: iload_1
    //   12: bipush #24
    //   14: iushr
    //   15: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   18: aload_3
    //   19: arraylength
    //   20: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   23: pop
    //   24: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   27: iconst_0
    //   28: istore #10
    //   30: istore #8
    //   32: iload #10
    //   34: aload_3
    //   35: arraylength
    //   36: if_icmpge -> 96
    //   39: aload #9
    //   41: aload_3
    //   42: iload #10
    //   44: aaload
    //   45: getfield c : I
    //   48: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   51: aload #4
    //   53: iload #10
    //   55: aaload
    //   56: getfield c : I
    //   59: aload_3
    //   60: iload #10
    //   62: aaload
    //   63: getfield c : I
    //   66: isub
    //   67: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   70: aload #5
    //   72: iload #10
    //   74: iaload
    //   75: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   78: pop
    //   79: iinc #10, 1
    //   82: iload #8
    //   84: ifne -> 144
    //   87: iload #8
    //   89: ifeq -> 32
    //   92: goto -> 96
    //   95: athrow
    //   96: aload_2
    //   97: iload #8
    //   99: ifne -> 130
    //   102: ifnonnull -> 125
    //   105: goto -> 109
    //   108: athrow
    //   109: aload #9
    //   111: iconst_0
    //   112: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   115: pop
    //   116: iload #8
    //   118: ifeq -> 160
    //   121: goto -> 125
    //   124: athrow
    //   125: aload_2
    //   126: goto -> 130
    //   129: athrow
    //   130: getfield a : [B
    //   133: aload_2
    //   134: getfield b : I
    //   137: baload
    //   138: iconst_2
    //   139: imul
    //   140: iconst_1
    //   141: iadd
    //   142: istore #10
    //   144: aload #9
    //   146: aload_2
    //   147: getfield a : [B
    //   150: aload_2
    //   151: getfield b : I
    //   154: iload #10
    //   156: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   159: pop
    //   160: aload #9
    //   162: aload_0
    //   163: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   166: aload #6
    //   168: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   171: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   174: iconst_0
    //   175: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   178: pop
    //   179: new org/objectweb/asm/AnnotationWriter
    //   182: dup
    //   183: aload_0
    //   184: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   187: iconst_1
    //   188: aload #9
    //   190: aload #9
    //   192: aload #9
    //   194: getfield b : I
    //   197: iconst_2
    //   198: isub
    //   199: invokespecial <init> : (Lorg/objectweb/asm/ClassWriter;ZLorg/objectweb/asm/ByteVector;Lorg/objectweb/asm/ByteVector;I)V
    //   202: astore #10
    //   204: iload #8
    //   206: ifne -> 255
    //   209: iload #7
    //   211: ifeq -> 242
    //   214: goto -> 218
    //   217: athrow
    //   218: aload #10
    //   220: aload_0
    //   221: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   224: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   227: aload_0
    //   228: aload #10
    //   230: putfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   233: iload #8
    //   235: ifeq -> 261
    //   238: goto -> 242
    //   241: athrow
    //   242: aload #10
    //   244: aload_0
    //   245: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   248: putfield g : Lorg/objectweb/asm/AnnotationWriter;
    //   251: goto -> 255
    //   254: athrow
    //   255: aload_0
    //   256: aload #10
    //   258: putfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   261: aload #10
    //   263: areturn
    // Exception table:
    //   from	to	target	type
    //   39	92	95	java/lang/IllegalStateException
    //   96	105	108	java/lang/IllegalStateException
    //   102	121	124	java/lang/IllegalStateException
    //   109	126	129	java/lang/IllegalStateException
    //   204	214	217	java/lang/IllegalStateException
    //   209	238	241	java/lang/IllegalStateException
    //   218	251	254	java/lang/IllegalStateException
  }
  
  public void visitLineNumber(int paramInt, Label paramLabel) {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.I == null)
            this.I = new ByteVector(); 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        this.H++;
        this.I.putShort(paramLabel.c);
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.I.putShort(paramInt);
  }
  
  public void visitMaxs(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: getfield L : I
    //   8: iload_3
    //   9: ifne -> 820
    //   12: ifne -> 804
    //   15: goto -> 19
    //   18: athrow
    //   19: aload_0
    //   20: getfield B : Lorg/objectweb/asm/Handler;
    //   23: astore #4
    //   25: aload #4
    //   27: ifnull -> 207
    //   30: aload #4
    //   32: getfield a : Lorg/objectweb/asm/Label;
    //   35: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   38: astore #5
    //   40: aload #4
    //   42: getfield c : Lorg/objectweb/asm/Label;
    //   45: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   48: astore #6
    //   50: aload #4
    //   52: getfield b : Lorg/objectweb/asm/Label;
    //   55: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   58: astore #7
    //   60: iload_3
    //   61: ifne -> 1501
    //   64: aload #4
    //   66: iload_3
    //   67: ifne -> 99
    //   70: goto -> 74
    //   73: athrow
    //   74: getfield d : Ljava/lang/String;
    //   77: ifnonnull -> 97
    //   80: goto -> 84
    //   83: athrow
    //   84: sipush #-21119
    //   87: sipush #-32710
    //   90: invokestatic b : (II)Ljava/lang/String;
    //   93: goto -> 102
    //   96: athrow
    //   97: aload #4
    //   99: getfield d : Ljava/lang/String;
    //   102: astore #8
    //   104: ldc 24117248
    //   106: aload_0
    //   107: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   110: aload #8
    //   112: invokevirtual c : (Ljava/lang/String;)I
    //   115: ior
    //   116: istore #9
    //   118: aload #6
    //   120: dup
    //   121: getfield a : I
    //   124: bipush #16
    //   126: ior
    //   127: putfield a : I
    //   130: aload #5
    //   132: aload #7
    //   134: if_acmpeq -> 196
    //   137: new org/objectweb/asm/Edge
    //   140: dup
    //   141: invokespecial <init> : ()V
    //   144: astore #10
    //   146: aload #10
    //   148: iload #9
    //   150: putfield a : I
    //   153: aload #10
    //   155: aload #6
    //   157: putfield b : Lorg/objectweb/asm/Label;
    //   160: aload #10
    //   162: aload #5
    //   164: getfield j : Lorg/objectweb/asm/Edge;
    //   167: putfield c : Lorg/objectweb/asm/Edge;
    //   170: aload #5
    //   172: aload #10
    //   174: putfield j : Lorg/objectweb/asm/Edge;
    //   177: aload #5
    //   179: getfield i : Lorg/objectweb/asm/Label;
    //   182: astore #5
    //   184: iload_3
    //   185: ifne -> 203
    //   188: iload_3
    //   189: ifeq -> 130
    //   192: goto -> 196
    //   195: athrow
    //   196: aload #4
    //   198: getfield f : Lorg/objectweb/asm/Handler;
    //   201: astore #4
    //   203: iload_3
    //   204: ifeq -> 25
    //   207: aload_0
    //   208: getfield M : Lorg/objectweb/asm/Label;
    //   211: getfield h : Lorg/objectweb/asm/Frame;
    //   214: astore #5
    //   216: aload #5
    //   218: aload_0
    //   219: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   222: aload_0
    //   223: getfield c : I
    //   226: aload_0
    //   227: getfield f : Ljava/lang/String;
    //   230: invokestatic getArgumentTypes : (Ljava/lang/String;)[Lorg/objectweb/asm/Type;
    //   233: aload_0
    //   234: getfield t : I
    //   237: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;I[Lorg/objectweb/asm/Type;I)V
    //   240: aload_0
    //   241: aload #5
    //   243: invokespecial b : (Lorg/objectweb/asm/Frame;)V
    //   246: iconst_0
    //   247: istore #6
    //   249: aload_0
    //   250: getfield M : Lorg/objectweb/asm/Label;
    //   253: astore #7
    //   255: aload #7
    //   257: ifnull -> 490
    //   260: aload #7
    //   262: astore #8
    //   264: aload #7
    //   266: getfield k : Lorg/objectweb/asm/Label;
    //   269: astore #7
    //   271: aload #8
    //   273: aconst_null
    //   274: putfield k : Lorg/objectweb/asm/Label;
    //   277: aload #8
    //   279: getfield h : Lorg/objectweb/asm/Frame;
    //   282: astore #5
    //   284: aload #8
    //   286: getfield a : I
    //   289: bipush #16
    //   291: iand
    //   292: iload_3
    //   293: ifne -> 524
    //   296: iload_3
    //   297: ifne -> 351
    //   300: goto -> 304
    //   303: athrow
    //   304: ifeq -> 327
    //   307: goto -> 311
    //   310: athrow
    //   311: aload #8
    //   313: dup
    //   314: getfield a : I
    //   317: bipush #32
    //   319: ior
    //   320: putfield a : I
    //   323: goto -> 327
    //   326: athrow
    //   327: aload #8
    //   329: dup
    //   330: getfield a : I
    //   333: bipush #64
    //   335: ior
    //   336: putfield a : I
    //   339: aload #5
    //   341: getfield d : [I
    //   344: arraylength
    //   345: aload #8
    //   347: getfield g : I
    //   350: iadd
    //   351: istore #9
    //   353: iload #9
    //   355: iload_3
    //   356: ifne -> 374
    //   359: iload #6
    //   361: if_icmple -> 376
    //   364: goto -> 368
    //   367: athrow
    //   368: iload #9
    //   370: goto -> 374
    //   373: athrow
    //   374: istore #6
    //   376: aload #8
    //   378: getfield j : Lorg/objectweb/asm/Edge;
    //   381: astore #10
    //   383: aload #10
    //   385: ifnull -> 486
    //   388: aload #10
    //   390: getfield b : Lorg/objectweb/asm/Label;
    //   393: invokevirtual a : ()Lorg/objectweb/asm/Label;
    //   396: astore #11
    //   398: aload #5
    //   400: aload_0
    //   401: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   404: aload #11
    //   406: getfield h : Lorg/objectweb/asm/Frame;
    //   409: aload #10
    //   411: getfield a : I
    //   414: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;Lorg/objectweb/asm/Frame;I)Z
    //   417: istore #12
    //   419: iload_3
    //   420: ifne -> 482
    //   423: iload #12
    //   425: iload_3
    //   426: ifne -> 524
    //   429: goto -> 433
    //   432: athrow
    //   433: ifeq -> 475
    //   436: goto -> 440
    //   439: athrow
    //   440: aload #11
    //   442: getfield k : Lorg/objectweb/asm/Label;
    //   445: iload_3
    //   446: ifne -> 473
    //   449: goto -> 453
    //   452: athrow
    //   453: ifnonnull -> 475
    //   456: goto -> 460
    //   459: athrow
    //   460: aload #11
    //   462: aload #7
    //   464: putfield k : Lorg/objectweb/asm/Label;
    //   467: aload #11
    //   469: goto -> 473
    //   472: athrow
    //   473: astore #7
    //   475: aload #10
    //   477: getfield c : Lorg/objectweb/asm/Edge;
    //   480: astore #10
    //   482: iload_3
    //   483: ifeq -> 383
    //   486: iload_3
    //   487: ifeq -> 255
    //   490: aload_0
    //   491: getfield M : Lorg/objectweb/asm/Label;
    //   494: astore #8
    //   496: aload #8
    //   498: ifnull -> 749
    //   501: aload #8
    //   503: getfield h : Lorg/objectweb/asm/Frame;
    //   506: astore #5
    //   508: iload_3
    //   509: ifne -> 755
    //   512: aload #8
    //   514: getfield a : I
    //   517: bipush #32
    //   519: iand
    //   520: goto -> 524
    //   523: athrow
    //   524: iload_3
    //   525: ifne -> 561
    //   528: ifeq -> 545
    //   531: goto -> 535
    //   534: athrow
    //   535: aload_0
    //   536: aload #5
    //   538: invokespecial b : (Lorg/objectweb/asm/Frame;)V
    //   541: goto -> 545
    //   544: athrow
    //   545: aload #8
    //   547: iload_3
    //   548: ifne -> 743
    //   551: getfield a : I
    //   554: bipush #64
    //   556: iand
    //   557: goto -> 561
    //   560: athrow
    //   561: ifne -> 738
    //   564: aload #8
    //   566: getfield i : Lorg/objectweb/asm/Label;
    //   569: astore #9
    //   571: aload #8
    //   573: getfield c : I
    //   576: istore #10
    //   578: aload #9
    //   580: iload_3
    //   581: ifne -> 604
    //   584: ifnonnull -> 602
    //   587: goto -> 591
    //   590: athrow
    //   591: aload_0
    //   592: getfield r : Lorg/objectweb/asm/ByteVector;
    //   595: getfield b : I
    //   598: goto -> 607
    //   601: athrow
    //   602: aload #9
    //   604: getfield c : I
    //   607: iconst_1
    //   608: isub
    //   609: istore #11
    //   611: iload_3
    //   612: ifne -> 745
    //   615: iload #11
    //   617: iload #10
    //   619: if_icmplt -> 738
    //   622: goto -> 626
    //   625: athrow
    //   626: iload #6
    //   628: iconst_1
    //   629: invokestatic max : (II)I
    //   632: istore #6
    //   634: iload #10
    //   636: istore #12
    //   638: iload #12
    //   640: iload #11
    //   642: if_icmpge -> 671
    //   645: aload_0
    //   646: getfield r : Lorg/objectweb/asm/ByteVector;
    //   649: getfield a : [B
    //   652: iload #12
    //   654: iconst_0
    //   655: bastore
    //   656: iinc #12, 1
    //   659: iload_3
    //   660: ifne -> 723
    //   663: iload_3
    //   664: ifeq -> 638
    //   667: goto -> 671
    //   670: athrow
    //   671: aload_0
    //   672: getfield r : Lorg/objectweb/asm/ByteVector;
    //   675: getfield a : [B
    //   678: iload #11
    //   680: bipush #-65
    //   682: bastore
    //   683: aload_0
    //   684: iload #10
    //   686: iconst_0
    //   687: iconst_1
    //   688: invokespecial a : (III)I
    //   691: istore #12
    //   693: aload_0
    //   694: getfield z : [I
    //   697: iload #12
    //   699: ldc 24117248
    //   701: aload_0
    //   702: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   705: sipush #-21119
    //   708: sipush #-32710
    //   711: invokestatic b : (II)Ljava/lang/String;
    //   714: invokevirtual c : (Ljava/lang/String;)I
    //   717: ior
    //   718: iastore
    //   719: aload_0
    //   720: invokespecial b : ()V
    //   723: aload_0
    //   724: aload_0
    //   725: getfield B : Lorg/objectweb/asm/Handler;
    //   728: aload #8
    //   730: aload #9
    //   732: invokestatic a : (Lorg/objectweb/asm/Handler;Lorg/objectweb/asm/Label;Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Handler;
    //   735: putfield B : Lorg/objectweb/asm/Handler;
    //   738: aload #8
    //   740: getfield i : Lorg/objectweb/asm/Label;
    //   743: astore #8
    //   745: iload_3
    //   746: ifeq -> 496
    //   749: aload_0
    //   750: getfield B : Lorg/objectweb/asm/Handler;
    //   753: astore #4
    //   755: aload_0
    //   756: iconst_0
    //   757: putfield A : I
    //   760: aload #4
    //   762: ifnull -> 794
    //   765: aload_0
    //   766: dup
    //   767: getfield A : I
    //   770: iconst_1
    //   771: iadd
    //   772: putfield A : I
    //   775: aload #4
    //   777: getfield f : Lorg/objectweb/asm/Handler;
    //   780: astore #4
    //   782: iload_3
    //   783: ifne -> 800
    //   786: iload_3
    //   787: ifeq -> 760
    //   790: goto -> 794
    //   793: athrow
    //   794: aload_0
    //   795: iload #6
    //   797: putfield s : I
    //   800: iload_3
    //   801: ifeq -> 1501
    //   804: aload_0
    //   805: iload_3
    //   806: ifne -> 1497
    //   809: goto -> 813
    //   812: athrow
    //   813: getfield L : I
    //   816: goto -> 820
    //   819: athrow
    //   820: iconst_2
    //   821: if_icmpne -> 1487
    //   824: aload_0
    //   825: getfield B : Lorg/objectweb/asm/Handler;
    //   828: astore #4
    //   830: aload #4
    //   832: ifnull -> 998
    //   835: aload #4
    //   837: getfield a : Lorg/objectweb/asm/Label;
    //   840: astore #5
    //   842: aload #4
    //   844: getfield c : Lorg/objectweb/asm/Label;
    //   847: astore #6
    //   849: iload_3
    //   850: ifne -> 1265
    //   853: aload #4
    //   855: getfield b : Lorg/objectweb/asm/Label;
    //   858: astore #7
    //   860: aload #5
    //   862: aload #7
    //   864: if_acmpeq -> 987
    //   867: new org/objectweb/asm/Edge
    //   870: dup
    //   871: invokespecial <init> : ()V
    //   874: astore #8
    //   876: aload #8
    //   878: ldc 2147483647
    //   880: putfield a : I
    //   883: aload #8
    //   885: aload #6
    //   887: putfield b : Lorg/objectweb/asm/Label;
    //   890: aload #5
    //   892: iload_3
    //   893: ifne -> 965
    //   896: getfield a : I
    //   899: sipush #128
    //   902: iand
    //   903: iload_3
    //   904: ifne -> 1002
    //   907: goto -> 911
    //   910: athrow
    //   911: ifne -> 943
    //   914: goto -> 918
    //   917: athrow
    //   918: aload #8
    //   920: aload #5
    //   922: getfield j : Lorg/objectweb/asm/Edge;
    //   925: putfield c : Lorg/objectweb/asm/Edge;
    //   928: aload #5
    //   930: aload #8
    //   932: putfield j : Lorg/objectweb/asm/Edge;
    //   935: iload_3
    //   936: ifeq -> 976
    //   939: goto -> 943
    //   942: athrow
    //   943: aload #8
    //   945: aload #5
    //   947: getfield j : Lorg/objectweb/asm/Edge;
    //   950: getfield c : Lorg/objectweb/asm/Edge;
    //   953: getfield c : Lorg/objectweb/asm/Edge;
    //   956: putfield c : Lorg/objectweb/asm/Edge;
    //   959: aload #5
    //   961: goto -> 965
    //   964: athrow
    //   965: getfield j : Lorg/objectweb/asm/Edge;
    //   968: getfield c : Lorg/objectweb/asm/Edge;
    //   971: aload #8
    //   973: putfield c : Lorg/objectweb/asm/Edge;
    //   976: aload #5
    //   978: getfield i : Lorg/objectweb/asm/Label;
    //   981: astore #5
    //   983: iload_3
    //   984: ifeq -> 860
    //   987: aload #4
    //   989: getfield f : Lorg/objectweb/asm/Handler;
    //   992: astore #4
    //   994: iload_3
    //   995: ifeq -> 830
    //   998: aload_0
    //   999: getfield K : I
    //   1002: iload_3
    //   1003: ifne -> 1266
    //   1006: ifle -> 1265
    //   1009: goto -> 1013
    //   1012: athrow
    //   1013: iconst_0
    //   1014: istore #5
    //   1016: aload_0
    //   1017: getfield M : Lorg/objectweb/asm/Label;
    //   1020: aconst_null
    //   1021: lconst_1
    //   1022: aload_0
    //   1023: getfield K : I
    //   1026: invokevirtual b : (Lorg/objectweb/asm/Label;JI)V
    //   1029: aload_0
    //   1030: getfield M : Lorg/objectweb/asm/Label;
    //   1033: astore #6
    //   1035: aload #6
    //   1037: ifnull -> 1147
    //   1040: aload #6
    //   1042: iload_3
    //   1043: ifne -> 1141
    //   1046: getfield a : I
    //   1049: sipush #128
    //   1052: iand
    //   1053: iload_3
    //   1054: ifne -> 1266
    //   1057: goto -> 1061
    //   1060: athrow
    //   1061: ifeq -> 1136
    //   1064: goto -> 1068
    //   1067: athrow
    //   1068: aload #6
    //   1070: getfield j : Lorg/objectweb/asm/Edge;
    //   1073: getfield c : Lorg/objectweb/asm/Edge;
    //   1076: getfield b : Lorg/objectweb/asm/Label;
    //   1079: astore #7
    //   1081: aload #7
    //   1083: iload_3
    //   1084: ifne -> 1141
    //   1087: getfield a : I
    //   1090: sipush #1024
    //   1093: iand
    //   1094: ifne -> 1136
    //   1097: goto -> 1101
    //   1100: athrow
    //   1101: iinc #5, 1
    //   1104: aload #7
    //   1106: aconst_null
    //   1107: iload #5
    //   1109: i2l
    //   1110: ldc2_w 32
    //   1113: ldiv
    //   1114: bipush #32
    //   1116: lshl
    //   1117: lconst_1
    //   1118: iload #5
    //   1120: bipush #32
    //   1122: irem
    //   1123: lshl
    //   1124: lor
    //   1125: aload_0
    //   1126: getfield K : I
    //   1129: invokevirtual b : (Lorg/objectweb/asm/Label;JI)V
    //   1132: goto -> 1136
    //   1135: athrow
    //   1136: aload #6
    //   1138: getfield i : Lorg/objectweb/asm/Label;
    //   1141: astore #6
    //   1143: iload_3
    //   1144: ifeq -> 1035
    //   1147: aload_0
    //   1148: getfield M : Lorg/objectweb/asm/Label;
    //   1151: astore #6
    //   1153: aload #6
    //   1155: ifnull -> 1265
    //   1158: aload #6
    //   1160: iload_3
    //   1161: ifne -> 1259
    //   1164: getfield a : I
    //   1167: sipush #128
    //   1170: iand
    //   1171: iload_3
    //   1172: ifne -> 1266
    //   1175: goto -> 1179
    //   1178: athrow
    //   1179: ifeq -> 1254
    //   1182: goto -> 1186
    //   1185: athrow
    //   1186: aload_0
    //   1187: getfield M : Lorg/objectweb/asm/Label;
    //   1190: astore #7
    //   1192: aload #7
    //   1194: ifnull -> 1229
    //   1197: aload #7
    //   1199: dup
    //   1200: getfield a : I
    //   1203: sipush #-2049
    //   1206: iand
    //   1207: putfield a : I
    //   1210: aload #7
    //   1212: getfield i : Lorg/objectweb/asm/Label;
    //   1215: astore #7
    //   1217: iload_3
    //   1218: ifne -> 1261
    //   1221: iload_3
    //   1222: ifeq -> 1192
    //   1225: goto -> 1229
    //   1228: athrow
    //   1229: aload #6
    //   1231: getfield j : Lorg/objectweb/asm/Edge;
    //   1234: getfield c : Lorg/objectweb/asm/Edge;
    //   1237: getfield b : Lorg/objectweb/asm/Label;
    //   1240: astore #8
    //   1242: aload #8
    //   1244: aload #6
    //   1246: lconst_0
    //   1247: aload_0
    //   1248: getfield K : I
    //   1251: invokevirtual b : (Lorg/objectweb/asm/Label;JI)V
    //   1254: aload #6
    //   1256: getfield i : Lorg/objectweb/asm/Label;
    //   1259: astore #6
    //   1261: iload_3
    //   1262: ifeq -> 1153
    //   1265: iconst_0
    //   1266: istore #5
    //   1268: aload_0
    //   1269: getfield M : Lorg/objectweb/asm/Label;
    //   1272: astore #6
    //   1274: aload #6
    //   1276: ifnull -> 1473
    //   1279: aload #6
    //   1281: astore #7
    //   1283: aload #6
    //   1285: getfield k : Lorg/objectweb/asm/Label;
    //   1288: astore #6
    //   1290: aload #7
    //   1292: getfield f : I
    //   1295: istore #8
    //   1297: iload #8
    //   1299: aload #7
    //   1301: getfield g : I
    //   1304: iadd
    //   1305: istore #9
    //   1307: iload_3
    //   1308: ifne -> 1483
    //   1311: iload #9
    //   1313: goto -> 1317
    //   1316: athrow
    //   1317: iload_3
    //   1318: ifne -> 1332
    //   1321: iload #5
    //   1323: if_icmple -> 1334
    //   1326: iload #9
    //   1328: goto -> 1332
    //   1331: athrow
    //   1332: istore #5
    //   1334: aload #7
    //   1336: getfield j : Lorg/objectweb/asm/Edge;
    //   1339: astore #10
    //   1341: aload #7
    //   1343: getfield a : I
    //   1346: sipush #128
    //   1349: iand
    //   1350: ifeq -> 1360
    //   1353: aload #10
    //   1355: getfield c : Lorg/objectweb/asm/Edge;
    //   1358: astore #10
    //   1360: aload #10
    //   1362: ifnull -> 1469
    //   1365: aload #10
    //   1367: getfield b : Lorg/objectweb/asm/Label;
    //   1370: astore #7
    //   1372: iload_3
    //   1373: ifne -> 1465
    //   1376: aload #7
    //   1378: getfield a : I
    //   1381: bipush #8
    //   1383: iand
    //   1384: iload_3
    //   1385: ifne -> 1317
    //   1388: goto -> 1392
    //   1391: athrow
    //   1392: ifne -> 1458
    //   1395: aload #7
    //   1397: aload #10
    //   1399: getfield a : I
    //   1402: ldc 2147483647
    //   1404: iload_3
    //   1405: ifne -> 1431
    //   1408: goto -> 1412
    //   1411: athrow
    //   1412: if_icmpne -> 1424
    //   1415: goto -> 1419
    //   1418: athrow
    //   1419: iconst_1
    //   1420: goto -> 1432
    //   1423: athrow
    //   1424: iload #8
    //   1426: aload #10
    //   1428: getfield a : I
    //   1431: iadd
    //   1432: putfield f : I
    //   1435: aload #7
    //   1437: dup
    //   1438: getfield a : I
    //   1441: bipush #8
    //   1443: ior
    //   1444: putfield a : I
    //   1447: aload #7
    //   1449: aload #6
    //   1451: putfield k : Lorg/objectweb/asm/Label;
    //   1454: aload #7
    //   1456: astore #6
    //   1458: aload #10
    //   1460: getfield c : Lorg/objectweb/asm/Edge;
    //   1463: astore #10
    //   1465: iload_3
    //   1466: ifeq -> 1360
    //   1469: iload_3
    //   1470: ifeq -> 1274
    //   1473: aload_0
    //   1474: iload_1
    //   1475: iload #5
    //   1477: invokestatic max : (II)I
    //   1480: putfield s : I
    //   1483: iload_3
    //   1484: ifeq -> 1501
    //   1487: aload_0
    //   1488: iload_1
    //   1489: putfield s : I
    //   1492: aload_0
    //   1493: goto -> 1497
    //   1496: athrow
    //   1497: iload_2
    //   1498: putfield t : I
    //   1501: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   60	70	73	java/lang/IllegalStateException
    //   64	80	83	java/lang/IllegalStateException
    //   74	96	96	java/lang/IllegalStateException
    //   184	192	195	java/lang/IllegalStateException
    //   284	300	303	java/lang/IllegalStateException
    //   296	307	310	java/lang/IllegalStateException
    //   304	323	326	java/lang/IllegalStateException
    //   353	364	367	java/lang/IllegalStateException
    //   359	370	373	java/lang/IllegalStateException
    //   419	429	432	java/lang/IllegalStateException
    //   423	436	439	java/lang/IllegalStateException
    //   433	449	452	java/lang/IllegalStateException
    //   440	456	459	java/lang/IllegalStateException
    //   453	469	472	java/lang/IllegalStateException
    //   508	520	523	java/lang/IllegalStateException
    //   524	531	534	java/lang/IllegalStateException
    //   528	541	544	java/lang/IllegalStateException
    //   545	557	560	java/lang/IllegalStateException
    //   578	587	590	java/lang/IllegalStateException
    //   584	601	601	java/lang/IllegalStateException
    //   611	622	625	java/lang/IllegalStateException
    //   645	667	670	java/lang/IllegalStateException
    //   782	790	793	java/lang/IllegalStateException
    //   800	809	812	java/lang/IllegalStateException
    //   804	816	819	java/lang/IllegalStateException
    //   876	907	910	java/lang/IllegalStateException
    //   896	914	917	java/lang/IllegalStateException
    //   911	939	942	java/lang/IllegalStateException
    //   918	961	964	java/lang/IllegalStateException
    //   1002	1009	1012	java/lang/IllegalStateException
    //   1040	1057	1060	java/lang/IllegalStateException
    //   1046	1064	1067	java/lang/IllegalStateException
    //   1081	1097	1100	java/lang/IllegalStateException
    //   1087	1132	1135	java/lang/IllegalStateException
    //   1158	1175	1178	java/lang/IllegalStateException
    //   1164	1182	1185	java/lang/IllegalStateException
    //   1217	1225	1228	java/lang/IllegalStateException
    //   1307	1313	1316	java/lang/IllegalStateException
    //   1321	1328	1331	java/lang/IllegalStateException
    //   1372	1388	1391	java/lang/IllegalStateException
    //   1392	1408	1411	java/lang/IllegalStateException
    //   1395	1415	1418	java/lang/IllegalStateException
    //   1412	1423	1423	java/lang/IllegalStateException
    //   1483	1493	1496	java/lang/IllegalStateException
  }
  
  public void visitEnd() {}
  
  private void a(int paramInt, Label paramLabel) {
    Edge edge = new Edge();
    edge.a = paramInt;
    edge.b = paramLabel;
    edge.c = this.O.j;
    this.O.j = edge;
  }
  
  private void e() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: iload_1
    //   6: ifne -> 88
    //   9: getfield L : I
    //   12: ifne -> 83
    //   15: goto -> 19
    //   18: athrow
    //   19: new org/objectweb/asm/Label
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore_2
    //   27: aload_2
    //   28: new org/objectweb/asm/Frame
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield h : Lorg/objectweb/asm/Frame;
    //   38: aload_2
    //   39: getfield h : Lorg/objectweb/asm/Frame;
    //   42: aload_2
    //   43: putfield b : Lorg/objectweb/asm/Label;
    //   46: aload_2
    //   47: aload_0
    //   48: aload_0
    //   49: getfield r : Lorg/objectweb/asm/ByteVector;
    //   52: getfield b : I
    //   55: aload_0
    //   56: getfield r : Lorg/objectweb/asm/ByteVector;
    //   59: getfield a : [B
    //   62: invokevirtual a : (Lorg/objectweb/asm/MethodWriter;I[B)Z
    //   65: pop
    //   66: aload_0
    //   67: getfield N : Lorg/objectweb/asm/Label;
    //   70: aload_2
    //   71: putfield i : Lorg/objectweb/asm/Label;
    //   74: aload_0
    //   75: aload_2
    //   76: putfield N : Lorg/objectweb/asm/Label;
    //   79: iload_1
    //   80: ifeq -> 98
    //   83: aload_0
    //   84: goto -> 88
    //   87: athrow
    //   88: getfield O : Lorg/objectweb/asm/Label;
    //   91: aload_0
    //   92: getfield Q : I
    //   95: putfield g : I
    //   98: aload_0
    //   99: iload_1
    //   100: ifne -> 119
    //   103: getfield L : I
    //   106: iconst_1
    //   107: if_icmpeq -> 123
    //   110: goto -> 114
    //   113: athrow
    //   114: aload_0
    //   115: goto -> 119
    //   118: athrow
    //   119: aconst_null
    //   120: putfield O : Lorg/objectweb/asm/Label;
    //   123: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   27	84	87	java/lang/IllegalStateException
    //   98	110	113	java/lang/IllegalStateException
    //   103	115	118	java/lang/IllegalStateException
  }
  
  private void b(Frame paramFrame) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: iconst_0
    //   7: istore #6
    //   9: iconst_0
    //   10: istore #7
    //   12: aload_1
    //   13: getfield c : [I
    //   16: astore #8
    //   18: aload_1
    //   19: getfield d : [I
    //   22: astore #9
    //   24: iconst_0
    //   25: istore_3
    //   26: istore_2
    //   27: iload_3
    //   28: aload #8
    //   30: arraylength
    //   31: if_icmpge -> 126
    //   34: aload #8
    //   36: iload_3
    //   37: iaload
    //   38: istore #4
    //   40: iload #4
    //   42: ldc 16777216
    //   44: iload_2
    //   45: ifne -> 132
    //   48: iload_2
    //   49: ifne -> 84
    //   52: goto -> 56
    //   55: athrow
    //   56: if_icmpne -> 74
    //   59: goto -> 63
    //   62: athrow
    //   63: iinc #5, 1
    //   66: iload_2
    //   67: ifeq -> 90
    //   70: goto -> 74
    //   73: athrow
    //   74: iload #6
    //   76: iload #5
    //   78: iconst_1
    //   79: iadd
    //   80: goto -> 84
    //   83: athrow
    //   84: iadd
    //   85: istore #6
    //   87: iconst_0
    //   88: istore #5
    //   90: iload #4
    //   92: ldc 16777220
    //   94: iload_2
    //   95: ifne -> 113
    //   98: if_icmpeq -> 116
    //   101: goto -> 105
    //   104: athrow
    //   105: iload #4
    //   107: ldc 16777219
    //   109: goto -> 113
    //   112: athrow
    //   113: if_icmpne -> 119
    //   116: iinc #3, 1
    //   119: iinc #3, 1
    //   122: iload_2
    //   123: ifeq -> 27
    //   126: iconst_0
    //   127: istore_3
    //   128: iload_3
    //   129: aload #9
    //   131: arraylength
    //   132: if_icmpge -> 188
    //   135: aload #9
    //   137: iload_3
    //   138: iaload
    //   139: istore #4
    //   141: iinc #7, 1
    //   144: iload #4
    //   146: iload_2
    //   147: ifne -> 203
    //   150: ldc 16777220
    //   152: iload_2
    //   153: ifne -> 175
    //   156: goto -> 160
    //   159: athrow
    //   160: if_icmpeq -> 178
    //   163: goto -> 167
    //   166: athrow
    //   167: iload #4
    //   169: ldc 16777219
    //   171: goto -> 175
    //   174: athrow
    //   175: if_icmpne -> 181
    //   178: iinc #3, 1
    //   181: iinc #3, 1
    //   184: iload_2
    //   185: ifeq -> 128
    //   188: aload_0
    //   189: aload_1
    //   190: getfield b : Lorg/objectweb/asm/Label;
    //   193: getfield c : I
    //   196: iload #6
    //   198: iload #7
    //   200: invokespecial a : (III)I
    //   203: istore #10
    //   205: iconst_0
    //   206: istore_3
    //   207: iload #6
    //   209: ifle -> 277
    //   212: aload #8
    //   214: iload_3
    //   215: iaload
    //   216: istore #4
    //   218: aload_0
    //   219: getfield z : [I
    //   222: iload #10
    //   224: iinc #10, 1
    //   227: iload #4
    //   229: iastore
    //   230: iload #4
    //   232: ldc 16777220
    //   234: iload_2
    //   235: ifne -> 283
    //   238: iload_2
    //   239: ifne -> 261
    //   242: goto -> 246
    //   245: athrow
    //   246: if_icmpeq -> 264
    //   249: goto -> 253
    //   252: athrow
    //   253: iload #4
    //   255: ldc 16777219
    //   257: goto -> 261
    //   260: athrow
    //   261: if_icmpne -> 267
    //   264: iinc #3, 1
    //   267: iinc #3, 1
    //   270: iinc #6, -1
    //   273: iload_2
    //   274: ifeq -> 207
    //   277: iconst_0
    //   278: istore_3
    //   279: iload_3
    //   280: aload #9
    //   282: arraylength
    //   283: if_icmpge -> 348
    //   286: aload #9
    //   288: iload_3
    //   289: iaload
    //   290: istore #4
    //   292: aload_0
    //   293: getfield z : [I
    //   296: iload #10
    //   298: iinc #10, 1
    //   301: iload #4
    //   303: iastore
    //   304: iload_2
    //   305: ifne -> 352
    //   308: iload #4
    //   310: ldc 16777220
    //   312: iload_2
    //   313: ifne -> 335
    //   316: goto -> 320
    //   319: athrow
    //   320: if_icmpeq -> 338
    //   323: goto -> 327
    //   326: athrow
    //   327: iload #4
    //   329: ldc 16777219
    //   331: goto -> 335
    //   334: athrow
    //   335: if_icmpne -> 341
    //   338: iinc #3, 1
    //   341: iinc #3, 1
    //   344: iload_2
    //   345: ifeq -> 279
    //   348: aload_0
    //   349: invokespecial b : ()V
    //   352: return
    // Exception table:
    //   from	to	target	type
    //   40	52	55	java/lang/IllegalStateException
    //   48	59	62	java/lang/IllegalStateException
    //   56	70	73	java/lang/IllegalStateException
    //   63	80	83	java/lang/IllegalStateException
    //   90	101	104	java/lang/IllegalStateException
    //   98	109	112	java/lang/IllegalStateException
    //   141	156	159	java/lang/IllegalStateException
    //   150	163	166	java/lang/IllegalStateException
    //   160	171	174	java/lang/IllegalStateException
    //   218	242	245	java/lang/IllegalStateException
    //   238	249	252	java/lang/IllegalStateException
    //   246	257	260	java/lang/IllegalStateException
    //   292	316	319	java/lang/IllegalStateException
    //   308	323	326	java/lang/IllegalStateException
    //   320	331	334	java/lang/IllegalStateException
  }
  
  private void f() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: iconst_0
    //   6: aload_0
    //   7: getfield f : Ljava/lang/String;
    //   10: invokevirtual length : ()I
    //   13: iconst_1
    //   14: iadd
    //   15: iconst_0
    //   16: invokespecial a : (III)I
    //   19: istore_2
    //   20: aload_0
    //   21: getfield c : I
    //   24: bipush #8
    //   26: iand
    //   27: iload_1
    //   28: ifne -> 110
    //   31: ifne -> 109
    //   34: goto -> 38
    //   37: athrow
    //   38: aload_0
    //   39: iload_1
    //   40: ifne -> 99
    //   43: goto -> 47
    //   46: athrow
    //   47: getfield c : I
    //   50: ldc 524288
    //   52: iand
    //   53: ifne -> 94
    //   56: goto -> 60
    //   59: athrow
    //   60: aload_0
    //   61: getfield z : [I
    //   64: iload_2
    //   65: iinc #2, 1
    //   68: ldc 24117248
    //   70: aload_0
    //   71: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   74: aload_0
    //   75: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   78: getfield I : Ljava/lang/String;
    //   81: invokevirtual c : (Ljava/lang/String;)I
    //   84: ior
    //   85: iastore
    //   86: iload_1
    //   87: ifeq -> 109
    //   90: goto -> 94
    //   93: athrow
    //   94: aload_0
    //   95: goto -> 99
    //   98: athrow
    //   99: getfield z : [I
    //   102: iload_2
    //   103: iinc #2, 1
    //   106: bipush #6
    //   108: iastore
    //   109: iconst_1
    //   110: istore_3
    //   111: iload_3
    //   112: istore #4
    //   114: aload_0
    //   115: getfield f : Ljava/lang/String;
    //   118: iload_3
    //   119: iinc #3, 1
    //   122: invokevirtual charAt : (I)C
    //   125: tableswitch default -> 506, 66 -> 244, 67 -> 244, 68 -> 294, 69 -> 506, 70 -> 258, 71 -> 506, 72 -> 506, 73 -> 244, 74 -> 276, 75 -> 506, 76 -> 436, 77 -> 506, 78 -> 506, 79 -> 506, 80 -> 506, 81 -> 506, 82 -> 506, 83 -> 244, 84 -> 506, 85 -> 506, 86 -> 506, 87 -> 506, 88 -> 506, 89 -> 506, 90 -> 244, 91 -> 312
    //   244: aload_0
    //   245: getfield z : [I
    //   248: iload_2
    //   249: iinc #2, 1
    //   252: iconst_1
    //   253: iastore
    //   254: iload_1
    //   255: ifeq -> 514
    //   258: aload_0
    //   259: getfield z : [I
    //   262: iload_2
    //   263: iinc #2, 1
    //   266: iconst_2
    //   267: iastore
    //   268: iload_1
    //   269: ifeq -> 514
    //   272: goto -> 276
    //   275: athrow
    //   276: aload_0
    //   277: getfield z : [I
    //   280: iload_2
    //   281: iinc #2, 1
    //   284: iconst_4
    //   285: iastore
    //   286: iload_1
    //   287: ifeq -> 514
    //   290: goto -> 294
    //   293: athrow
    //   294: aload_0
    //   295: getfield z : [I
    //   298: iload_2
    //   299: iinc #2, 1
    //   302: iconst_3
    //   303: iastore
    //   304: iload_1
    //   305: ifeq -> 514
    //   308: goto -> 312
    //   311: athrow
    //   312: aload_0
    //   313: getfield f : Ljava/lang/String;
    //   316: iload_3
    //   317: invokevirtual charAt : (I)C
    //   320: bipush #91
    //   322: if_icmpne -> 344
    //   325: goto -> 329
    //   328: athrow
    //   329: iinc #3, 1
    //   332: iload_1
    //   333: ifne -> 432
    //   336: iload_1
    //   337: ifeq -> 312
    //   340: goto -> 344
    //   343: athrow
    //   344: aload_0
    //   345: iload_1
    //   346: ifne -> 401
    //   349: getfield f : Ljava/lang/String;
    //   352: iload_3
    //   353: invokevirtual charAt : (I)C
    //   356: bipush #76
    //   358: if_icmpne -> 400
    //   361: goto -> 365
    //   364: athrow
    //   365: iinc #3, 1
    //   368: goto -> 372
    //   371: athrow
    //   372: aload_0
    //   373: getfield f : Ljava/lang/String;
    //   376: iload_3
    //   377: invokevirtual charAt : (I)C
    //   380: bipush #59
    //   382: if_icmpeq -> 400
    //   385: iinc #3, 1
    //   388: iload_1
    //   389: ifne -> 432
    //   392: iload_1
    //   393: ifeq -> 372
    //   396: goto -> 400
    //   399: athrow
    //   400: aload_0
    //   401: getfield z : [I
    //   404: iload_2
    //   405: iinc #2, 1
    //   408: ldc 24117248
    //   410: aload_0
    //   411: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   414: aload_0
    //   415: getfield f : Ljava/lang/String;
    //   418: iload #4
    //   420: iinc #3, 1
    //   423: iload_3
    //   424: invokevirtual substring : (II)Ljava/lang/String;
    //   427: invokevirtual c : (Ljava/lang/String;)I
    //   430: ior
    //   431: iastore
    //   432: iload_1
    //   433: ifeq -> 514
    //   436: aload_0
    //   437: getfield f : Ljava/lang/String;
    //   440: iload_3
    //   441: invokevirtual charAt : (I)C
    //   444: bipush #59
    //   446: if_icmpeq -> 468
    //   449: goto -> 453
    //   452: athrow
    //   453: iinc #3, 1
    //   456: iload_1
    //   457: ifne -> 502
    //   460: iload_1
    //   461: ifeq -> 436
    //   464: goto -> 468
    //   467: athrow
    //   468: aload_0
    //   469: getfield z : [I
    //   472: iload_2
    //   473: iinc #2, 1
    //   476: ldc 24117248
    //   478: aload_0
    //   479: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   482: aload_0
    //   483: getfield f : Ljava/lang/String;
    //   486: iload #4
    //   488: iconst_1
    //   489: iadd
    //   490: iload_3
    //   491: iinc #3, 1
    //   494: invokevirtual substring : (II)Ljava/lang/String;
    //   497: invokevirtual c : (Ljava/lang/String;)I
    //   500: ior
    //   501: iastore
    //   502: iload_1
    //   503: ifeq -> 514
    //   506: iload_1
    //   507: ifeq -> 522
    //   510: goto -> 514
    //   513: athrow
    //   514: iload_1
    //   515: ifeq -> 111
    //   518: goto -> 522
    //   521: athrow
    //   522: aload_0
    //   523: getfield z : [I
    //   526: iconst_1
    //   527: iload_2
    //   528: iconst_3
    //   529: isub
    //   530: iastore
    //   531: aload_0
    //   532: invokespecial b : ()V
    //   535: return
    // Exception table:
    //   from	to	target	type
    //   20	34	37	java/lang/IllegalStateException
    //   31	43	46	java/lang/IllegalStateException
    //   38	56	59	java/lang/IllegalStateException
    //   47	90	93	java/lang/IllegalStateException
    //   60	95	98	java/lang/IllegalStateException
    //   244	272	275	java/lang/IllegalStateException
    //   258	290	293	java/lang/IllegalStateException
    //   276	308	311	java/lang/IllegalStateException
    //   294	325	328	java/lang/IllegalStateException
    //   329	340	343	java/lang/IllegalStateException
    //   344	361	364	java/lang/IllegalStateException
    //   349	368	371	java/lang/IllegalStateException
    //   385	396	399	java/lang/IllegalStateException
    //   432	449	452	java/lang/IllegalStateException
    //   453	464	467	java/lang/IllegalStateException
    //   502	510	513	java/lang/IllegalStateException
    //   506	518	521	java/lang/IllegalStateException
  }
  
  private int a(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #4
    //   5: iconst_3
    //   6: iload_2
    //   7: iadd
    //   8: iload_3
    //   9: iadd
    //   10: istore #5
    //   12: aload_0
    //   13: iload #4
    //   15: ifne -> 56
    //   18: getfield z : [I
    //   21: ifnull -> 51
    //   24: goto -> 28
    //   27: athrow
    //   28: aload_0
    //   29: getfield z : [I
    //   32: arraylength
    //   33: iload #4
    //   35: ifne -> 85
    //   38: goto -> 42
    //   41: athrow
    //   42: iload #5
    //   44: if_icmpge -> 63
    //   47: goto -> 51
    //   50: athrow
    //   51: aload_0
    //   52: goto -> 56
    //   55: athrow
    //   56: iload #5
    //   58: newarray int
    //   60: putfield z : [I
    //   63: aload_0
    //   64: getfield z : [I
    //   67: iconst_0
    //   68: iload_1
    //   69: iastore
    //   70: aload_0
    //   71: getfield z : [I
    //   74: iconst_1
    //   75: iload_2
    //   76: iastore
    //   77: aload_0
    //   78: getfield z : [I
    //   81: iconst_2
    //   82: iload_3
    //   83: iastore
    //   84: iconst_3
    //   85: ireturn
    // Exception table:
    //   from	to	target	type
    //   12	24	27	java/lang/IllegalStateException
    //   18	38	41	java/lang/IllegalStateException
    //   28	47	50	java/lang/IllegalStateException
    //   42	52	55	java/lang/IllegalStateException
  }
  
  private void b() {
    int i = MethodVisitor.b;
    try {
      if (i == 0) {
        try {
          if (this.x != null) {
            try {
              if (i == 0) {
                try {
                  if (this.v == null)
                    this.v = new ByteVector(); 
                } catch (IllegalStateException illegalStateException) {
                  throw null;
                } 
                c();
              } 
            } catch (IllegalStateException illegalStateException) {
              throw null;
            } 
            this.u++;
          } 
        } catch (IllegalStateException illegalStateException) {
          throw null;
        } 
        this.x = this.z;
      } 
    } catch (IllegalStateException illegalStateException) {
      throw null;
    } 
    this.z = null;
  }
  
  private void c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield z : [I
    //   4: iconst_1
    //   5: iaload
    //   6: istore_2
    //   7: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   10: aload_0
    //   11: getfield z : [I
    //   14: iconst_2
    //   15: iaload
    //   16: istore_3
    //   17: istore_1
    //   18: aload_0
    //   19: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   22: getfield b : I
    //   25: ldc 65535
    //   27: iand
    //   28: iload_1
    //   29: ifne -> 96
    //   32: bipush #50
    //   34: if_icmpge -> 90
    //   37: goto -> 41
    //   40: athrow
    //   41: aload_0
    //   42: getfield v : Lorg/objectweb/asm/ByteVector;
    //   45: aload_0
    //   46: getfield z : [I
    //   49: iconst_0
    //   50: iaload
    //   51: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   54: iload_2
    //   55: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   58: pop
    //   59: aload_0
    //   60: iconst_3
    //   61: iconst_3
    //   62: iload_2
    //   63: iadd
    //   64: invokespecial a : (II)V
    //   67: aload_0
    //   68: getfield v : Lorg/objectweb/asm/ByteVector;
    //   71: iload_3
    //   72: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   75: pop
    //   76: aload_0
    //   77: iconst_3
    //   78: iload_2
    //   79: iadd
    //   80: iconst_3
    //   81: iload_2
    //   82: iadd
    //   83: iload_3
    //   84: iadd
    //   85: invokespecial a : (II)V
    //   88: return
    //   89: athrow
    //   90: aload_0
    //   91: getfield x : [I
    //   94: iconst_1
    //   95: iaload
    //   96: istore #4
    //   98: sipush #255
    //   101: istore #5
    //   103: iconst_0
    //   104: istore #6
    //   106: aload_0
    //   107: getfield u : I
    //   110: iload_1
    //   111: ifne -> 152
    //   114: ifne -> 133
    //   117: goto -> 121
    //   120: athrow
    //   121: aload_0
    //   122: getfield z : [I
    //   125: iconst_0
    //   126: iaload
    //   127: istore #7
    //   129: iload_1
    //   130: ifeq -> 154
    //   133: aload_0
    //   134: getfield z : [I
    //   137: iconst_0
    //   138: iaload
    //   139: aload_0
    //   140: getfield x : [I
    //   143: iconst_0
    //   144: iaload
    //   145: isub
    //   146: iconst_1
    //   147: isub
    //   148: goto -> 152
    //   151: athrow
    //   152: istore #7
    //   154: iload_3
    //   155: iload_1
    //   156: ifne -> 283
    //   159: ifne -> 278
    //   162: goto -> 166
    //   165: athrow
    //   166: iload_2
    //   167: iload #4
    //   169: isub
    //   170: istore #6
    //   172: iload #6
    //   174: iload_1
    //   175: ifne -> 227
    //   178: tableswitch default -> 274, -3 -> 221, -2 -> 221, -1 -> 221, 0 -> 233, 1 -> 269, 2 -> 269, 3 -> 269
    //   220: athrow
    //   221: sipush #248
    //   224: istore #5
    //   226: iload_2
    //   227: istore #4
    //   229: iload_1
    //   230: ifeq -> 274
    //   233: iload #7
    //   235: iload_1
    //   236: ifne -> 257
    //   239: goto -> 243
    //   242: athrow
    //   243: bipush #64
    //   245: if_icmpge -> 260
    //   248: goto -> 252
    //   251: athrow
    //   252: iconst_0
    //   253: goto -> 257
    //   256: athrow
    //   257: goto -> 263
    //   260: sipush #251
    //   263: istore #5
    //   265: iload_1
    //   266: ifeq -> 274
    //   269: sipush #252
    //   272: istore #5
    //   274: iload_1
    //   275: ifeq -> 346
    //   278: iload_2
    //   279: goto -> 283
    //   282: athrow
    //   283: iload #4
    //   285: iload_1
    //   286: ifne -> 359
    //   289: if_icmpne -> 346
    //   292: goto -> 296
    //   295: athrow
    //   296: iload_3
    //   297: iconst_1
    //   298: iload_1
    //   299: ifne -> 359
    //   302: goto -> 306
    //   305: athrow
    //   306: if_icmpne -> 346
    //   309: goto -> 313
    //   312: athrow
    //   313: iload #7
    //   315: iload_1
    //   316: ifne -> 338
    //   319: goto -> 323
    //   322: athrow
    //   323: bipush #63
    //   325: if_icmpge -> 341
    //   328: goto -> 332
    //   331: athrow
    //   332: bipush #64
    //   334: goto -> 338
    //   337: athrow
    //   338: goto -> 344
    //   341: sipush #247
    //   344: istore #5
    //   346: iload #5
    //   348: iload_1
    //   349: ifne -> 437
    //   352: sipush #255
    //   355: goto -> 359
    //   358: athrow
    //   359: if_icmpeq -> 435
    //   362: iconst_3
    //   363: istore #8
    //   365: iconst_0
    //   366: istore #9
    //   368: iload #9
    //   370: iload #4
    //   372: if_icmpge -> 435
    //   375: aload_0
    //   376: getfield z : [I
    //   379: iload #8
    //   381: iaload
    //   382: iload_1
    //   383: ifne -> 437
    //   386: iload_1
    //   387: ifne -> 415
    //   390: goto -> 394
    //   393: athrow
    //   394: aload_0
    //   395: getfield x : [I
    //   398: iload #8
    //   400: iaload
    //   401: if_icmpeq -> 421
    //   404: goto -> 408
    //   407: athrow
    //   408: sipush #255
    //   411: goto -> 415
    //   414: athrow
    //   415: istore #5
    //   417: iload_1
    //   418: ifeq -> 435
    //   421: iinc #8, 1
    //   424: iinc #9, 1
    //   427: iload_1
    //   428: ifeq -> 368
    //   431: goto -> 435
    //   434: athrow
    //   435: iload #5
    //   437: lookupswitch default -> 668, 0 -> 496, 64 -> 514, 247 -> 545, 248 -> 603, 251 -> 579, 252 -> 630
    //   496: aload_0
    //   497: getfield v : Lorg/objectweb/asm/ByteVector;
    //   500: iload #7
    //   502: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   505: pop
    //   506: iload_1
    //   507: ifeq -> 721
    //   510: goto -> 514
    //   513: athrow
    //   514: aload_0
    //   515: getfield v : Lorg/objectweb/asm/ByteVector;
    //   518: bipush #64
    //   520: iload #7
    //   522: iadd
    //   523: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   526: pop
    //   527: aload_0
    //   528: iconst_3
    //   529: iload_2
    //   530: iadd
    //   531: iconst_4
    //   532: iload_2
    //   533: iadd
    //   534: invokespecial a : (II)V
    //   537: iload_1
    //   538: ifeq -> 721
    //   541: goto -> 545
    //   544: athrow
    //   545: aload_0
    //   546: getfield v : Lorg/objectweb/asm/ByteVector;
    //   549: sipush #247
    //   552: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   555: iload #7
    //   557: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   560: pop
    //   561: aload_0
    //   562: iconst_3
    //   563: iload_2
    //   564: iadd
    //   565: iconst_4
    //   566: iload_2
    //   567: iadd
    //   568: invokespecial a : (II)V
    //   571: iload_1
    //   572: ifeq -> 721
    //   575: goto -> 579
    //   578: athrow
    //   579: aload_0
    //   580: getfield v : Lorg/objectweb/asm/ByteVector;
    //   583: sipush #251
    //   586: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   589: iload #7
    //   591: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   594: pop
    //   595: iload_1
    //   596: ifeq -> 721
    //   599: goto -> 603
    //   602: athrow
    //   603: aload_0
    //   604: getfield v : Lorg/objectweb/asm/ByteVector;
    //   607: sipush #251
    //   610: iload #6
    //   612: iadd
    //   613: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   616: iload #7
    //   618: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   621: pop
    //   622: iload_1
    //   623: ifeq -> 721
    //   626: goto -> 630
    //   629: athrow
    //   630: aload_0
    //   631: getfield v : Lorg/objectweb/asm/ByteVector;
    //   634: sipush #251
    //   637: iload #6
    //   639: iadd
    //   640: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   643: iload #7
    //   645: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   648: pop
    //   649: aload_0
    //   650: iconst_3
    //   651: iload #4
    //   653: iadd
    //   654: iconst_3
    //   655: iload_2
    //   656: iadd
    //   657: invokespecial a : (II)V
    //   660: iload_1
    //   661: ifeq -> 721
    //   664: goto -> 668
    //   667: athrow
    //   668: aload_0
    //   669: getfield v : Lorg/objectweb/asm/ByteVector;
    //   672: sipush #255
    //   675: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   678: iload #7
    //   680: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   683: iload_2
    //   684: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   687: pop
    //   688: aload_0
    //   689: iconst_3
    //   690: iconst_3
    //   691: iload_2
    //   692: iadd
    //   693: invokespecial a : (II)V
    //   696: aload_0
    //   697: getfield v : Lorg/objectweb/asm/ByteVector;
    //   700: iload_3
    //   701: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   704: pop
    //   705: aload_0
    //   706: iconst_3
    //   707: iload_2
    //   708: iadd
    //   709: iconst_3
    //   710: iload_2
    //   711: iadd
    //   712: iload_3
    //   713: iadd
    //   714: invokespecial a : (II)V
    //   717: goto -> 721
    //   720: athrow
    //   721: return
    // Exception table:
    //   from	to	target	type
    //   18	37	40	java/lang/IllegalStateException
    //   32	89	89	java/lang/IllegalStateException
    //   106	117	120	java/lang/IllegalStateException
    //   129	148	151	java/lang/IllegalStateException
    //   154	162	165	java/lang/IllegalStateException
    //   172	220	220	java/lang/IllegalStateException
    //   229	239	242	java/lang/IllegalStateException
    //   233	248	251	java/lang/IllegalStateException
    //   243	253	256	java/lang/IllegalStateException
    //   274	279	282	java/lang/IllegalStateException
    //   283	292	295	java/lang/IllegalStateException
    //   289	302	305	java/lang/IllegalStateException
    //   296	309	312	java/lang/IllegalStateException
    //   306	319	322	java/lang/IllegalStateException
    //   313	328	331	java/lang/IllegalStateException
    //   323	334	337	java/lang/IllegalStateException
    //   346	355	358	java/lang/IllegalStateException
    //   375	390	393	java/lang/IllegalStateException
    //   386	404	407	java/lang/IllegalStateException
    //   394	411	414	java/lang/IllegalStateException
    //   417	431	434	java/lang/IllegalStateException
    //   437	510	513	java/lang/IllegalStateException
    //   496	541	544	java/lang/IllegalStateException
    //   514	575	578	java/lang/IllegalStateException
    //   545	599	602	java/lang/IllegalStateException
    //   579	626	629	java/lang/IllegalStateException
    //   603	664	667	java/lang/IllegalStateException
    //   630	717	720	java/lang/IllegalStateException
  }
  
  private void a(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: iload_1
    //   5: istore #4
    //   7: iload #4
    //   9: iload_2
    //   10: if_icmpge -> 512
    //   13: aload_0
    //   14: getfield z : [I
    //   17: iload #4
    //   19: iaload
    //   20: istore #5
    //   22: iload #5
    //   24: ldc -268435456
    //   26: iand
    //   27: istore #6
    //   29: iload #6
    //   31: iload_3
    //   32: ifne -> 51
    //   35: ifne -> 182
    //   38: goto -> 42
    //   41: athrow
    //   42: iload #5
    //   44: ldc 1048575
    //   46: iand
    //   47: goto -> 51
    //   50: athrow
    //   51: istore #7
    //   53: iload_3
    //   54: ifne -> 126
    //   57: iload #5
    //   59: ldc 267386880
    //   61: iand
    //   62: lookupswitch default -> 164, 24117248 -> 89, 25165824 -> 130
    //   88: athrow
    //   89: aload_0
    //   90: getfield v : Lorg/objectweb/asm/ByteVector;
    //   93: bipush #7
    //   95: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   98: aload_0
    //   99: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   102: aload_0
    //   103: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   106: getfield H : [Lorg/objectweb/asm/Item;
    //   109: iload #7
    //   111: aaload
    //   112: getfield g : Ljava/lang/String;
    //   115: invokevirtual newClass : (Ljava/lang/String;)I
    //   118: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   121: pop
    //   122: goto -> 126
    //   125: athrow
    //   126: iload_3
    //   127: ifeq -> 178
    //   130: aload_0
    //   131: getfield v : Lorg/objectweb/asm/ByteVector;
    //   134: bipush #8
    //   136: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   139: aload_0
    //   140: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   143: getfield H : [Lorg/objectweb/asm/Item;
    //   146: iload #7
    //   148: aaload
    //   149: getfield c : I
    //   152: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   155: pop
    //   156: iload_3
    //   157: ifeq -> 178
    //   160: goto -> 164
    //   163: athrow
    //   164: aload_0
    //   165: getfield v : Lorg/objectweb/asm/ByteVector;
    //   168: iload #7
    //   170: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   173: pop
    //   174: goto -> 178
    //   177: athrow
    //   178: iload_3
    //   179: ifeq -> 505
    //   182: new java/lang/StringBuffer
    //   185: dup
    //   186: invokespecial <init> : ()V
    //   189: astore #7
    //   191: iload #6
    //   193: bipush #28
    //   195: ishr
    //   196: istore #6
    //   198: iload #6
    //   200: iinc #6, -1
    //   203: ifle -> 226
    //   206: aload #7
    //   208: bipush #91
    //   210: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   213: pop
    //   214: iload_3
    //   215: ifne -> 290
    //   218: iload_3
    //   219: ifeq -> 198
    //   222: goto -> 226
    //   225: athrow
    //   226: iload #5
    //   228: ldc 267386880
    //   230: iand
    //   231: ldc 24117248
    //   233: iload_3
    //   234: ifne -> 294
    //   237: if_icmpne -> 290
    //   240: goto -> 244
    //   243: athrow
    //   244: aload #7
    //   246: bipush #76
    //   248: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   251: pop
    //   252: aload #7
    //   254: aload_0
    //   255: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   258: getfield H : [Lorg/objectweb/asm/Item;
    //   261: iload #5
    //   263: ldc 1048575
    //   265: iand
    //   266: aaload
    //   267: getfield g : Ljava/lang/String;
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   273: pop
    //   274: aload #7
    //   276: bipush #59
    //   278: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   281: pop
    //   282: iload_3
    //   283: ifeq -> 480
    //   286: goto -> 290
    //   289: athrow
    //   290: iload #5
    //   292: bipush #15
    //   294: iand
    //   295: tableswitch default -> 468, 1 -> 356, 2 -> 372, 3 -> 388, 4 -> 468, 5 -> 468, 6 -> 468, 7 -> 468, 8 -> 468, 9 -> 404, 10 -> 420, 11 -> 436, 12 -> 452
    //   356: aload #7
    //   358: bipush #73
    //   360: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   363: pop
    //   364: iload_3
    //   365: ifeq -> 480
    //   368: goto -> 372
    //   371: athrow
    //   372: aload #7
    //   374: bipush #70
    //   376: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   379: pop
    //   380: iload_3
    //   381: ifeq -> 480
    //   384: goto -> 388
    //   387: athrow
    //   388: aload #7
    //   390: bipush #68
    //   392: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   395: pop
    //   396: iload_3
    //   397: ifeq -> 480
    //   400: goto -> 404
    //   403: athrow
    //   404: aload #7
    //   406: bipush #90
    //   408: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   411: pop
    //   412: iload_3
    //   413: ifeq -> 480
    //   416: goto -> 420
    //   419: athrow
    //   420: aload #7
    //   422: bipush #66
    //   424: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   427: pop
    //   428: iload_3
    //   429: ifeq -> 480
    //   432: goto -> 436
    //   435: athrow
    //   436: aload #7
    //   438: bipush #67
    //   440: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   443: pop
    //   444: iload_3
    //   445: ifeq -> 480
    //   448: goto -> 452
    //   451: athrow
    //   452: aload #7
    //   454: bipush #83
    //   456: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   459: pop
    //   460: iload_3
    //   461: ifeq -> 480
    //   464: goto -> 468
    //   467: athrow
    //   468: aload #7
    //   470: bipush #74
    //   472: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   475: pop
    //   476: goto -> 480
    //   479: athrow
    //   480: aload_0
    //   481: getfield v : Lorg/objectweb/asm/ByteVector;
    //   484: bipush #7
    //   486: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   489: aload_0
    //   490: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   493: aload #7
    //   495: invokevirtual toString : ()Ljava/lang/String;
    //   498: invokevirtual newClass : (Ljava/lang/String;)I
    //   501: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   504: pop
    //   505: iinc #4, 1
    //   508: iload_3
    //   509: ifeq -> 7
    //   512: return
    // Exception table:
    //   from	to	target	type
    //   29	38	41	java/lang/IllegalStateException
    //   35	47	50	java/lang/IllegalStateException
    //   53	88	88	java/lang/IllegalStateException
    //   57	122	125	java/lang/IllegalStateException
    //   126	160	163	java/lang/IllegalStateException
    //   130	174	177	java/lang/IllegalStateException
    //   206	222	225	java/lang/IllegalStateException
    //   226	240	243	java/lang/IllegalStateException
    //   237	286	289	java/lang/IllegalStateException
    //   294	368	371	java/lang/IllegalStateException
    //   356	384	387	java/lang/IllegalStateException
    //   372	400	403	java/lang/IllegalStateException
    //   388	416	419	java/lang/IllegalStateException
    //   404	432	435	java/lang/IllegalStateException
    //   420	448	451	java/lang/IllegalStateException
    //   436	464	467	java/lang/IllegalStateException
    //   452	476	479	java/lang/IllegalStateException
  }
  
  private void a(Object paramObject) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: instanceof java/lang/String
    //   8: iload_2
    //   9: ifne -> 59
    //   12: ifeq -> 51
    //   15: goto -> 19
    //   18: athrow
    //   19: aload_0
    //   20: getfield v : Lorg/objectweb/asm/ByteVector;
    //   23: bipush #7
    //   25: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   28: aload_0
    //   29: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   32: aload_1
    //   33: checkcast java/lang/String
    //   36: invokevirtual newClass : (Ljava/lang/String;)I
    //   39: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   42: pop
    //   43: iload_2
    //   44: ifeq -> 109
    //   47: goto -> 51
    //   50: athrow
    //   51: aload_1
    //   52: instanceof java/lang/Integer
    //   55: goto -> 59
    //   58: athrow
    //   59: ifeq -> 85
    //   62: aload_0
    //   63: getfield v : Lorg/objectweb/asm/ByteVector;
    //   66: aload_1
    //   67: checkcast java/lang/Integer
    //   70: invokevirtual intValue : ()I
    //   73: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   76: pop
    //   77: iload_2
    //   78: ifeq -> 109
    //   81: goto -> 85
    //   84: athrow
    //   85: aload_0
    //   86: getfield v : Lorg/objectweb/asm/ByteVector;
    //   89: bipush #8
    //   91: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   94: aload_1
    //   95: checkcast org/objectweb/asm/Label
    //   98: getfield c : I
    //   101: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   104: pop
    //   105: goto -> 109
    //   108: athrow
    //   109: return
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   12	47	50	java/lang/IllegalStateException
    //   19	55	58	java/lang/IllegalStateException
    //   59	81	84	java/lang/IllegalStateException
    //   62	105	108	java/lang/IllegalStateException
  }
  
  final int a() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: getfield h : I
    //   8: iload_1
    //   9: ifne -> 30
    //   12: ifeq -> 28
    //   15: goto -> 19
    //   18: athrow
    //   19: bipush #6
    //   21: aload_0
    //   22: getfield i : I
    //   25: iadd
    //   26: ireturn
    //   27: athrow
    //   28: bipush #8
    //   30: istore_2
    //   31: aload_0
    //   32: getfield r : Lorg/objectweb/asm/ByteVector;
    //   35: getfield b : I
    //   38: iload_1
    //   39: ifne -> 508
    //   42: ifle -> 504
    //   45: goto -> 49
    //   48: athrow
    //   49: aload_0
    //   50: getfield r : Lorg/objectweb/asm/ByteVector;
    //   53: getfield b : I
    //   56: ldc 65535
    //   58: iload_1
    //   59: ifne -> 127
    //   62: goto -> 66
    //   65: athrow
    //   66: if_icmple -> 91
    //   69: goto -> 73
    //   72: athrow
    //   73: new java/lang/RuntimeException
    //   76: dup
    //   77: sipush #-21103
    //   80: sipush #-8418
    //   83: invokestatic b : (II)Ljava/lang/String;
    //   86: invokespecial <init> : (Ljava/lang/String;)V
    //   89: athrow
    //   90: athrow
    //   91: aload_0
    //   92: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   95: sipush #-21097
    //   98: sipush #29742
    //   101: invokestatic b : (II)Ljava/lang/String;
    //   104: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   107: pop
    //   108: iload_2
    //   109: bipush #18
    //   111: aload_0
    //   112: getfield r : Lorg/objectweb/asm/ByteVector;
    //   115: getfield b : I
    //   118: iadd
    //   119: bipush #8
    //   121: aload_0
    //   122: getfield A : I
    //   125: imul
    //   126: iadd
    //   127: iadd
    //   128: istore_2
    //   129: aload_0
    //   130: getfield E : Lorg/objectweb/asm/ByteVector;
    //   133: iload_1
    //   134: ifne -> 178
    //   137: ifnull -> 174
    //   140: goto -> 144
    //   143: athrow
    //   144: aload_0
    //   145: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   148: sipush #-21091
    //   151: sipush #12980
    //   154: invokestatic b : (II)Ljava/lang/String;
    //   157: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   160: pop
    //   161: iload_2
    //   162: bipush #8
    //   164: aload_0
    //   165: getfield E : Lorg/objectweb/asm/ByteVector;
    //   168: getfield b : I
    //   171: iadd
    //   172: iadd
    //   173: istore_2
    //   174: aload_0
    //   175: getfield G : Lorg/objectweb/asm/ByteVector;
    //   178: iload_1
    //   179: ifne -> 223
    //   182: ifnull -> 219
    //   185: goto -> 189
    //   188: athrow
    //   189: aload_0
    //   190: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   193: sipush #-21104
    //   196: sipush #9898
    //   199: invokestatic b : (II)Ljava/lang/String;
    //   202: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   205: pop
    //   206: iload_2
    //   207: bipush #8
    //   209: aload_0
    //   210: getfield G : Lorg/objectweb/asm/ByteVector;
    //   213: getfield b : I
    //   216: iadd
    //   217: iadd
    //   218: istore_2
    //   219: aload_0
    //   220: getfield I : Lorg/objectweb/asm/ByteVector;
    //   223: iload_1
    //   224: ifne -> 276
    //   227: ifnull -> 264
    //   230: goto -> 234
    //   233: athrow
    //   234: aload_0
    //   235: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   238: sipush #-21116
    //   241: sipush #-3243
    //   244: invokestatic b : (II)Ljava/lang/String;
    //   247: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   250: pop
    //   251: iload_2
    //   252: bipush #8
    //   254: aload_0
    //   255: getfield I : Lorg/objectweb/asm/ByteVector;
    //   258: getfield b : I
    //   261: iadd
    //   262: iadd
    //   263: istore_2
    //   264: aload_0
    //   265: iload_1
    //   266: ifne -> 364
    //   269: getfield v : Lorg/objectweb/asm/ByteVector;
    //   272: goto -> 276
    //   275: athrow
    //   276: ifnull -> 363
    //   279: aload_0
    //   280: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   283: getfield b : I
    //   286: ldc 65535
    //   288: iand
    //   289: iload_1
    //   290: ifne -> 311
    //   293: goto -> 297
    //   296: athrow
    //   297: bipush #50
    //   299: if_icmplt -> 314
    //   302: goto -> 306
    //   305: athrow
    //   306: iconst_1
    //   307: goto -> 311
    //   310: athrow
    //   311: goto -> 315
    //   314: iconst_0
    //   315: istore_3
    //   316: aload_0
    //   317: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   320: iload_3
    //   321: ifeq -> 337
    //   324: sipush #-21098
    //   327: sipush #8501
    //   330: invokestatic b : (II)Ljava/lang/String;
    //   333: goto -> 346
    //   336: athrow
    //   337: sipush #-21115
    //   340: sipush #13305
    //   343: invokestatic b : (II)Ljava/lang/String;
    //   346: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   349: pop
    //   350: iload_2
    //   351: bipush #8
    //   353: aload_0
    //   354: getfield v : Lorg/objectweb/asm/ByteVector;
    //   357: getfield b : I
    //   360: iadd
    //   361: iadd
    //   362: istore_2
    //   363: aload_0
    //   364: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   367: iload_1
    //   368: ifne -> 420
    //   371: ifnull -> 408
    //   374: goto -> 378
    //   377: athrow
    //   378: aload_0
    //   379: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   382: sipush #-21114
    //   385: sipush #-27438
    //   388: invokestatic b : (II)Ljava/lang/String;
    //   391: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   394: pop
    //   395: iload_2
    //   396: bipush #8
    //   398: aload_0
    //   399: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   402: invokevirtual a : ()I
    //   405: iadd
    //   406: iadd
    //   407: istore_2
    //   408: aload_0
    //   409: iload_1
    //   410: ifne -> 454
    //   413: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   416: goto -> 420
    //   419: athrow
    //   420: ifnull -> 453
    //   423: aload_0
    //   424: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   427: sipush #-21092
    //   430: sipush #-32532
    //   433: invokestatic b : (II)Ljava/lang/String;
    //   436: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   439: pop
    //   440: iload_2
    //   441: bipush #8
    //   443: aload_0
    //   444: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   447: invokevirtual a : ()I
    //   450: iadd
    //   451: iadd
    //   452: istore_2
    //   453: aload_0
    //   454: iload_1
    //   455: ifne -> 505
    //   458: getfield J : Lorg/objectweb/asm/Attribute;
    //   461: ifnull -> 504
    //   464: goto -> 468
    //   467: athrow
    //   468: iload_2
    //   469: aload_0
    //   470: getfield J : Lorg/objectweb/asm/Attribute;
    //   473: aload_0
    //   474: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   477: aload_0
    //   478: getfield r : Lorg/objectweb/asm/ByteVector;
    //   481: getfield a : [B
    //   484: aload_0
    //   485: getfield r : Lorg/objectweb/asm/ByteVector;
    //   488: getfield b : I
    //   491: aload_0
    //   492: getfield s : I
    //   495: aload_0
    //   496: getfield t : I
    //   499: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIII)I
    //   502: iadd
    //   503: istore_2
    //   504: aload_0
    //   505: getfield j : I
    //   508: iload_1
    //   509: ifne -> 556
    //   512: ifle -> 548
    //   515: goto -> 519
    //   518: athrow
    //   519: aload_0
    //   520: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   523: sipush #-21113
    //   526: sipush #10258
    //   529: invokestatic b : (II)Ljava/lang/String;
    //   532: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   535: pop
    //   536: iload_2
    //   537: bipush #8
    //   539: iconst_2
    //   540: aload_0
    //   541: getfield j : I
    //   544: imul
    //   545: iadd
    //   546: iadd
    //   547: istore_2
    //   548: aload_0
    //   549: getfield c : I
    //   552: sipush #4096
    //   555: iand
    //   556: iload_1
    //   557: ifne -> 655
    //   560: ifeq -> 640
    //   563: goto -> 567
    //   566: athrow
    //   567: aload_0
    //   568: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   571: getfield b : I
    //   574: ldc 65535
    //   576: iand
    //   577: iload_1
    //   578: ifne -> 636
    //   581: goto -> 585
    //   584: athrow
    //   585: bipush #49
    //   587: if_icmplt -> 616
    //   590: goto -> 594
    //   593: athrow
    //   594: aload_0
    //   595: getfield c : I
    //   598: ldc 262144
    //   600: iand
    //   601: iload_1
    //   602: ifne -> 655
    //   605: goto -> 609
    //   608: athrow
    //   609: ifeq -> 640
    //   612: goto -> 616
    //   615: athrow
    //   616: aload_0
    //   617: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   620: sipush #-21101
    //   623: sipush #-28565
    //   626: invokestatic b : (II)Ljava/lang/String;
    //   629: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   632: goto -> 636
    //   635: athrow
    //   636: pop
    //   637: iinc #2, 6
    //   640: aload_0
    //   641: iload_1
    //   642: ifne -> 683
    //   645: getfield c : I
    //   648: ldc 131072
    //   650: iand
    //   651: goto -> 655
    //   654: athrow
    //   655: ifeq -> 682
    //   658: aload_0
    //   659: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   662: sipush #-21089
    //   665: sipush #23526
    //   668: invokestatic b : (II)Ljava/lang/String;
    //   671: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   674: pop
    //   675: iinc #2, 6
    //   678: goto -> 682
    //   681: athrow
    //   682: aload_0
    //   683: iload_1
    //   684: ifne -> 734
    //   687: getfield g : Ljava/lang/String;
    //   690: ifnull -> 733
    //   693: goto -> 697
    //   696: athrow
    //   697: aload_0
    //   698: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   701: sipush #-21093
    //   704: sipush #26921
    //   707: invokestatic b : (II)Ljava/lang/String;
    //   710: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   713: pop
    //   714: aload_0
    //   715: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   718: aload_0
    //   719: getfield g : Ljava/lang/String;
    //   722: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   725: pop
    //   726: iinc #2, 8
    //   729: goto -> 733
    //   732: athrow
    //   733: aload_0
    //   734: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   737: iload_1
    //   738: ifne -> 790
    //   741: ifnull -> 778
    //   744: goto -> 748
    //   747: athrow
    //   748: aload_0
    //   749: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   752: sipush #-21102
    //   755: sipush #-21719
    //   758: invokestatic b : (II)Ljava/lang/String;
    //   761: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   764: pop
    //   765: iload_2
    //   766: bipush #7
    //   768: aload_0
    //   769: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   772: getfield b : I
    //   775: iadd
    //   776: iadd
    //   777: istore_2
    //   778: aload_0
    //   779: iload_1
    //   780: ifne -> 824
    //   783: getfield l : Lorg/objectweb/asm/ByteVector;
    //   786: goto -> 790
    //   789: athrow
    //   790: ifnull -> 823
    //   793: aload_0
    //   794: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   797: sipush #-21100
    //   800: sipush #25520
    //   803: invokestatic b : (II)Ljava/lang/String;
    //   806: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   809: pop
    //   810: iload_2
    //   811: bipush #6
    //   813: aload_0
    //   814: getfield l : Lorg/objectweb/asm/ByteVector;
    //   817: getfield b : I
    //   820: iadd
    //   821: iadd
    //   822: istore_2
    //   823: aload_0
    //   824: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   827: iload_1
    //   828: ifne -> 872
    //   831: ifnull -> 868
    //   834: goto -> 838
    //   837: athrow
    //   838: aload_0
    //   839: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   842: sipush #-21095
    //   845: sipush #23920
    //   848: invokestatic b : (II)Ljava/lang/String;
    //   851: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   854: pop
    //   855: iload_2
    //   856: bipush #8
    //   858: aload_0
    //   859: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   862: invokevirtual a : ()I
    //   865: iadd
    //   866: iadd
    //   867: istore_2
    //   868: aload_0
    //   869: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   872: iload_1
    //   873: ifne -> 917
    //   876: ifnull -> 913
    //   879: goto -> 883
    //   882: athrow
    //   883: aload_0
    //   884: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   887: sipush #-21094
    //   890: sipush #-28672
    //   893: invokestatic b : (II)Ljava/lang/String;
    //   896: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   899: pop
    //   900: iload_2
    //   901: bipush #8
    //   903: aload_0
    //   904: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   907: invokevirtual a : ()I
    //   910: iadd
    //   911: iadd
    //   912: istore_2
    //   913: aload_0
    //   914: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   917: iload_1
    //   918: ifne -> 970
    //   921: ifnull -> 958
    //   924: goto -> 928
    //   927: athrow
    //   928: aload_0
    //   929: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   932: sipush #-21114
    //   935: sipush #-27438
    //   938: invokestatic b : (II)Ljava/lang/String;
    //   941: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   944: pop
    //   945: iload_2
    //   946: bipush #8
    //   948: aload_0
    //   949: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   952: invokevirtual a : ()I
    //   955: iadd
    //   956: iadd
    //   957: istore_2
    //   958: aload_0
    //   959: iload_1
    //   960: ifne -> 1004
    //   963: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   966: goto -> 970
    //   969: athrow
    //   970: ifnull -> 1003
    //   973: aload_0
    //   974: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   977: sipush #-21092
    //   980: sipush #-32532
    //   983: invokestatic b : (II)Ljava/lang/String;
    //   986: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   989: pop
    //   990: iload_2
    //   991: bipush #8
    //   993: aload_0
    //   994: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   997: invokevirtual a : ()I
    //   1000: iadd
    //   1001: iadd
    //   1002: istore_2
    //   1003: aload_0
    //   1004: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   1007: iload_1
    //   1008: ifne -> 1130
    //   1011: ifnull -> 1118
    //   1014: goto -> 1018
    //   1017: athrow
    //   1018: aload_0
    //   1019: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1022: sipush #-21096
    //   1025: sipush #13293
    //   1028: invokestatic b : (II)Ljava/lang/String;
    //   1031: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1034: pop
    //   1035: iload_2
    //   1036: bipush #7
    //   1038: iconst_2
    //   1039: aload_0
    //   1040: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   1043: arraylength
    //   1044: aload_0
    //   1045: getfield R : I
    //   1048: isub
    //   1049: imul
    //   1050: iadd
    //   1051: iadd
    //   1052: istore_2
    //   1053: aload_0
    //   1054: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   1057: arraylength
    //   1058: iconst_1
    //   1059: isub
    //   1060: istore_3
    //   1061: iload_3
    //   1062: aload_0
    //   1063: getfield R : I
    //   1066: if_icmplt -> 1118
    //   1069: iload_2
    //   1070: aload_0
    //   1071: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   1074: iload_3
    //   1075: aaload
    //   1076: iload_1
    //   1077: ifne -> 1199
    //   1080: iload_1
    //   1081: ifne -> 1106
    //   1084: goto -> 1088
    //   1087: athrow
    //   1088: ifnonnull -> 1100
    //   1091: goto -> 1095
    //   1094: athrow
    //   1095: iconst_0
    //   1096: goto -> 1109
    //   1099: athrow
    //   1100: aload_0
    //   1101: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   1104: iload_3
    //   1105: aaload
    //   1106: invokevirtual a : ()I
    //   1109: iadd
    //   1110: istore_2
    //   1111: iinc #3, -1
    //   1114: iload_1
    //   1115: ifeq -> 1061
    //   1118: aload_0
    //   1119: iload_1
    //   1120: ifne -> 1234
    //   1123: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   1126: goto -> 1130
    //   1129: athrow
    //   1130: ifnull -> 1233
    //   1133: aload_0
    //   1134: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1137: sipush #-21120
    //   1140: sipush #-5892
    //   1143: invokestatic b : (II)Ljava/lang/String;
    //   1146: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1149: pop
    //   1150: iload_2
    //   1151: bipush #7
    //   1153: iconst_2
    //   1154: aload_0
    //   1155: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   1158: arraylength
    //   1159: aload_0
    //   1160: getfield R : I
    //   1163: isub
    //   1164: imul
    //   1165: iadd
    //   1166: iadd
    //   1167: istore_2
    //   1168: aload_0
    //   1169: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   1172: arraylength
    //   1173: iconst_1
    //   1174: isub
    //   1175: istore_3
    //   1176: iload_3
    //   1177: aload_0
    //   1178: getfield R : I
    //   1181: if_icmplt -> 1233
    //   1184: iload_2
    //   1185: aload_0
    //   1186: iload_1
    //   1187: ifne -> 1246
    //   1190: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   1193: iload_3
    //   1194: aaload
    //   1195: goto -> 1199
    //   1198: athrow
    //   1199: iload_1
    //   1200: ifne -> 1221
    //   1203: ifnonnull -> 1215
    //   1206: goto -> 1210
    //   1209: athrow
    //   1210: iconst_0
    //   1211: goto -> 1224
    //   1214: athrow
    //   1215: aload_0
    //   1216: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   1219: iload_3
    //   1220: aaload
    //   1221: invokevirtual a : ()I
    //   1224: iadd
    //   1225: istore_2
    //   1226: iinc #3, -1
    //   1229: iload_1
    //   1230: ifeq -> 1176
    //   1233: aload_0
    //   1234: getfield q : Lorg/objectweb/asm/Attribute;
    //   1237: ifnull -> 1262
    //   1240: iload_2
    //   1241: aload_0
    //   1242: goto -> 1246
    //   1245: athrow
    //   1246: getfield q : Lorg/objectweb/asm/Attribute;
    //   1249: aload_0
    //   1250: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1253: aconst_null
    //   1254: iconst_0
    //   1255: iconst_m1
    //   1256: iconst_m1
    //   1257: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIII)I
    //   1260: iadd
    //   1261: istore_2
    //   1262: iload_2
    //   1263: ireturn
    // Exception table:
    //   from	to	target	type
    //   4	15	18	java/lang/IllegalStateException
    //   12	27	27	java/lang/IllegalStateException
    //   31	45	48	java/lang/IllegalStateException
    //   42	62	65	java/lang/IllegalStateException
    //   49	69	72	java/lang/IllegalStateException
    //   66	90	90	java/lang/IllegalStateException
    //   129	140	143	java/lang/IllegalStateException
    //   178	185	188	java/lang/IllegalStateException
    //   223	230	233	java/lang/IllegalStateException
    //   264	272	275	java/lang/IllegalStateException
    //   276	293	296	java/lang/IllegalStateException
    //   279	302	305	java/lang/IllegalStateException
    //   297	307	310	java/lang/IllegalStateException
    //   316	336	336	java/lang/IllegalStateException
    //   364	374	377	java/lang/IllegalStateException
    //   408	416	419	java/lang/IllegalStateException
    //   454	464	467	java/lang/IllegalStateException
    //   508	515	518	java/lang/IllegalStateException
    //   556	563	566	java/lang/IllegalStateException
    //   560	581	584	java/lang/IllegalStateException
    //   567	590	593	java/lang/IllegalStateException
    //   585	605	608	java/lang/IllegalStateException
    //   594	612	615	java/lang/IllegalStateException
    //   609	632	635	java/lang/IllegalStateException
    //   640	651	654	java/lang/IllegalStateException
    //   655	678	681	java/lang/IllegalStateException
    //   683	693	696	java/lang/IllegalStateException
    //   687	729	732	java/lang/IllegalStateException
    //   734	744	747	java/lang/IllegalStateException
    //   778	786	789	java/lang/IllegalStateException
    //   824	834	837	java/lang/IllegalStateException
    //   872	879	882	java/lang/IllegalStateException
    //   917	924	927	java/lang/IllegalStateException
    //   958	966	969	java/lang/IllegalStateException
    //   1004	1014	1017	java/lang/IllegalStateException
    //   1069	1084	1087	java/lang/IllegalStateException
    //   1080	1091	1094	java/lang/IllegalStateException
    //   1088	1099	1099	java/lang/IllegalStateException
    //   1118	1126	1129	java/lang/IllegalStateException
    //   1184	1195	1198	java/lang/IllegalStateException
    //   1199	1206	1209	java/lang/IllegalStateException
    //   1203	1214	1214	java/lang/IllegalStateException
    //   1234	1242	1245	java/lang/IllegalStateException
  }
  
  final void a(ByteVector paramByteVector) {
    // Byte code:
    //   0: bipush #64
    //   2: istore_3
    //   3: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   6: ldc 917504
    //   8: aload_0
    //   9: getfield c : I
    //   12: ldc 262144
    //   14: iand
    //   15: bipush #64
    //   17: idiv
    //   18: ior
    //   19: istore #4
    //   21: istore_2
    //   22: aload_1
    //   23: aload_0
    //   24: getfield c : I
    //   27: iload #4
    //   29: iconst_m1
    //   30: ixor
    //   31: iand
    //   32: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   35: aload_0
    //   36: getfield d : I
    //   39: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   42: aload_0
    //   43: getfield e : I
    //   46: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   49: pop
    //   50: aload_0
    //   51: getfield h : I
    //   54: iload_2
    //   55: ifne -> 91
    //   58: ifeq -> 90
    //   61: goto -> 65
    //   64: athrow
    //   65: aload_1
    //   66: aload_0
    //   67: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   70: getfield K : Lorg/objectweb/asm/ClassReader;
    //   73: getfield b : [B
    //   76: aload_0
    //   77: getfield h : I
    //   80: aload_0
    //   81: getfield i : I
    //   84: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   87: pop
    //   88: return
    //   89: athrow
    //   90: iconst_0
    //   91: istore #5
    //   93: aload_0
    //   94: getfield r : Lorg/objectweb/asm/ByteVector;
    //   97: getfield b : I
    //   100: iload_2
    //   101: ifne -> 118
    //   104: ifle -> 114
    //   107: goto -> 111
    //   110: athrow
    //   111: iinc #5, 1
    //   114: aload_0
    //   115: getfield j : I
    //   118: iload_2
    //   119: ifne -> 140
    //   122: ifle -> 132
    //   125: goto -> 129
    //   128: athrow
    //   129: iinc #5, 1
    //   132: aload_0
    //   133: getfield c : I
    //   136: sipush #4096
    //   139: iand
    //   140: iload_2
    //   141: ifne -> 218
    //   144: ifeq -> 203
    //   147: goto -> 151
    //   150: athrow
    //   151: aload_0
    //   152: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   155: getfield b : I
    //   158: ldc 65535
    //   160: iand
    //   161: bipush #49
    //   163: iload_2
    //   164: ifne -> 188
    //   167: goto -> 171
    //   170: athrow
    //   171: if_icmplt -> 200
    //   174: goto -> 178
    //   177: athrow
    //   178: aload_0
    //   179: getfield c : I
    //   182: ldc 262144
    //   184: goto -> 188
    //   187: athrow
    //   188: iand
    //   189: iload_2
    //   190: ifne -> 218
    //   193: ifeq -> 203
    //   196: goto -> 200
    //   199: athrow
    //   200: iinc #5, 1
    //   203: aload_0
    //   204: iload_2
    //   205: ifne -> 225
    //   208: getfield c : I
    //   211: ldc 131072
    //   213: iand
    //   214: goto -> 218
    //   217: athrow
    //   218: ifeq -> 224
    //   221: iinc #5, 1
    //   224: aload_0
    //   225: iload_2
    //   226: ifne -> 247
    //   229: getfield g : Ljava/lang/String;
    //   232: ifnull -> 246
    //   235: goto -> 239
    //   238: athrow
    //   239: iinc #5, 1
    //   242: goto -> 246
    //   245: athrow
    //   246: aload_0
    //   247: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   250: iload_2
    //   251: ifne -> 276
    //   254: ifnull -> 264
    //   257: goto -> 261
    //   260: athrow
    //   261: iinc #5, 1
    //   264: aload_0
    //   265: iload_2
    //   266: ifne -> 283
    //   269: getfield l : Lorg/objectweb/asm/ByteVector;
    //   272: goto -> 276
    //   275: athrow
    //   276: ifnull -> 282
    //   279: iinc #5, 1
    //   282: aload_0
    //   283: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   286: iload_2
    //   287: ifne -> 304
    //   290: ifnull -> 300
    //   293: goto -> 297
    //   296: athrow
    //   297: iinc #5, 1
    //   300: aload_0
    //   301: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   304: iload_2
    //   305: ifne -> 322
    //   308: ifnull -> 318
    //   311: goto -> 315
    //   314: athrow
    //   315: iinc #5, 1
    //   318: aload_0
    //   319: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   322: iload_2
    //   323: ifne -> 348
    //   326: ifnull -> 336
    //   329: goto -> 333
    //   332: athrow
    //   333: iinc #5, 1
    //   336: aload_0
    //   337: iload_2
    //   338: ifne -> 355
    //   341: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   344: goto -> 348
    //   347: athrow
    //   348: ifnull -> 354
    //   351: iinc #5, 1
    //   354: aload_0
    //   355: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   358: iload_2
    //   359: ifne -> 384
    //   362: ifnull -> 372
    //   365: goto -> 369
    //   368: athrow
    //   369: iinc #5, 1
    //   372: aload_0
    //   373: iload_2
    //   374: ifne -> 391
    //   377: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   380: goto -> 384
    //   383: athrow
    //   384: ifnull -> 390
    //   387: iinc #5, 1
    //   390: aload_0
    //   391: iload_2
    //   392: ifne -> 425
    //   395: getfield q : Lorg/objectweb/asm/Attribute;
    //   398: ifnull -> 417
    //   401: goto -> 405
    //   404: athrow
    //   405: iload #5
    //   407: aload_0
    //   408: getfield q : Lorg/objectweb/asm/Attribute;
    //   411: invokevirtual a : ()I
    //   414: iadd
    //   415: istore #5
    //   417: aload_1
    //   418: iload #5
    //   420: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   423: pop
    //   424: aload_0
    //   425: getfield r : Lorg/objectweb/asm/ByteVector;
    //   428: getfield b : I
    //   431: iload_2
    //   432: ifne -> 1538
    //   435: ifle -> 1534
    //   438: goto -> 442
    //   441: athrow
    //   442: bipush #12
    //   444: aload_0
    //   445: getfield r : Lorg/objectweb/asm/ByteVector;
    //   448: getfield b : I
    //   451: iadd
    //   452: bipush #8
    //   454: aload_0
    //   455: getfield A : I
    //   458: imul
    //   459: iadd
    //   460: istore #6
    //   462: aload_0
    //   463: getfield E : Lorg/objectweb/asm/ByteVector;
    //   466: iload_2
    //   467: ifne -> 496
    //   470: ifnull -> 492
    //   473: goto -> 477
    //   476: athrow
    //   477: iload #6
    //   479: bipush #8
    //   481: aload_0
    //   482: getfield E : Lorg/objectweb/asm/ByteVector;
    //   485: getfield b : I
    //   488: iadd
    //   489: iadd
    //   490: istore #6
    //   492: aload_0
    //   493: getfield G : Lorg/objectweb/asm/ByteVector;
    //   496: iload_2
    //   497: ifne -> 526
    //   500: ifnull -> 522
    //   503: goto -> 507
    //   506: athrow
    //   507: iload #6
    //   509: bipush #8
    //   511: aload_0
    //   512: getfield G : Lorg/objectweb/asm/ByteVector;
    //   515: getfield b : I
    //   518: iadd
    //   519: iadd
    //   520: istore #6
    //   522: aload_0
    //   523: getfield I : Lorg/objectweb/asm/ByteVector;
    //   526: iload_2
    //   527: ifne -> 564
    //   530: ifnull -> 552
    //   533: goto -> 537
    //   536: athrow
    //   537: iload #6
    //   539: bipush #8
    //   541: aload_0
    //   542: getfield I : Lorg/objectweb/asm/ByteVector;
    //   545: getfield b : I
    //   548: iadd
    //   549: iadd
    //   550: istore #6
    //   552: aload_0
    //   553: iload_2
    //   554: ifne -> 583
    //   557: getfield v : Lorg/objectweb/asm/ByteVector;
    //   560: goto -> 564
    //   563: athrow
    //   564: ifnull -> 582
    //   567: iload #6
    //   569: bipush #8
    //   571: aload_0
    //   572: getfield v : Lorg/objectweb/asm/ByteVector;
    //   575: getfield b : I
    //   578: iadd
    //   579: iadd
    //   580: istore #6
    //   582: aload_0
    //   583: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   586: iload_2
    //   587: ifne -> 624
    //   590: ifnull -> 612
    //   593: goto -> 597
    //   596: athrow
    //   597: iload #6
    //   599: bipush #8
    //   601: aload_0
    //   602: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   605: invokevirtual a : ()I
    //   608: iadd
    //   609: iadd
    //   610: istore #6
    //   612: aload_0
    //   613: iload_2
    //   614: ifne -> 643
    //   617: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   620: goto -> 624
    //   623: athrow
    //   624: ifnull -> 642
    //   627: iload #6
    //   629: bipush #8
    //   631: aload_0
    //   632: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   635: invokevirtual a : ()I
    //   638: iadd
    //   639: iadd
    //   640: istore #6
    //   642: aload_0
    //   643: iload_2
    //   644: ifne -> 777
    //   647: getfield J : Lorg/objectweb/asm/Attribute;
    //   650: ifnull -> 695
    //   653: goto -> 657
    //   656: athrow
    //   657: iload #6
    //   659: aload_0
    //   660: getfield J : Lorg/objectweb/asm/Attribute;
    //   663: aload_0
    //   664: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   667: aload_0
    //   668: getfield r : Lorg/objectweb/asm/ByteVector;
    //   671: getfield a : [B
    //   674: aload_0
    //   675: getfield r : Lorg/objectweb/asm/ByteVector;
    //   678: getfield b : I
    //   681: aload_0
    //   682: getfield s : I
    //   685: aload_0
    //   686: getfield t : I
    //   689: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIII)I
    //   692: iadd
    //   693: istore #6
    //   695: aload_1
    //   696: aload_0
    //   697: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   700: sipush #-21097
    //   703: sipush #29742
    //   706: invokestatic b : (II)Ljava/lang/String;
    //   709: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   712: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   715: iload #6
    //   717: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   720: pop
    //   721: aload_1
    //   722: aload_0
    //   723: getfield s : I
    //   726: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   729: aload_0
    //   730: getfield t : I
    //   733: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   736: pop
    //   737: aload_1
    //   738: aload_0
    //   739: getfield r : Lorg/objectweb/asm/ByteVector;
    //   742: getfield b : I
    //   745: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   748: aload_0
    //   749: getfield r : Lorg/objectweb/asm/ByteVector;
    //   752: getfield a : [B
    //   755: iconst_0
    //   756: aload_0
    //   757: getfield r : Lorg/objectweb/asm/ByteVector;
    //   760: getfield b : I
    //   763: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   766: pop
    //   767: aload_1
    //   768: aload_0
    //   769: getfield A : I
    //   772: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   775: pop
    //   776: aload_0
    //   777: getfield A : I
    //   780: iload_2
    //   781: ifne -> 865
    //   784: ifle -> 864
    //   787: goto -> 791
    //   790: athrow
    //   791: aload_0
    //   792: getfield B : Lorg/objectweb/asm/Handler;
    //   795: astore #7
    //   797: aload #7
    //   799: ifnull -> 864
    //   802: aload_1
    //   803: aload #7
    //   805: getfield a : Lorg/objectweb/asm/Label;
    //   808: getfield c : I
    //   811: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   814: aload #7
    //   816: getfield b : Lorg/objectweb/asm/Label;
    //   819: getfield c : I
    //   822: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   825: aload #7
    //   827: getfield c : Lorg/objectweb/asm/Label;
    //   830: getfield c : I
    //   833: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   836: aload #7
    //   838: getfield e : I
    //   841: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   844: pop
    //   845: aload #7
    //   847: getfield f : Lorg/objectweb/asm/Handler;
    //   850: astore #7
    //   852: iload_2
    //   853: ifne -> 867
    //   856: iload_2
    //   857: ifeq -> 797
    //   860: goto -> 864
    //   863: athrow
    //   864: iconst_0
    //   865: istore #5
    //   867: aload_0
    //   868: getfield E : Lorg/objectweb/asm/ByteVector;
    //   871: iload_2
    //   872: ifne -> 889
    //   875: ifnull -> 885
    //   878: goto -> 882
    //   881: athrow
    //   882: iinc #5, 1
    //   885: aload_0
    //   886: getfield G : Lorg/objectweb/asm/ByteVector;
    //   889: iload_2
    //   890: ifne -> 907
    //   893: ifnull -> 903
    //   896: goto -> 900
    //   899: athrow
    //   900: iinc #5, 1
    //   903: aload_0
    //   904: getfield I : Lorg/objectweb/asm/ByteVector;
    //   907: iload_2
    //   908: ifne -> 933
    //   911: ifnull -> 921
    //   914: goto -> 918
    //   917: athrow
    //   918: iinc #5, 1
    //   921: aload_0
    //   922: iload_2
    //   923: ifne -> 940
    //   926: getfield v : Lorg/objectweb/asm/ByteVector;
    //   929: goto -> 933
    //   932: athrow
    //   933: ifnull -> 939
    //   936: iinc #5, 1
    //   939: aload_0
    //   940: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   943: iload_2
    //   944: ifne -> 969
    //   947: ifnull -> 957
    //   950: goto -> 954
    //   953: athrow
    //   954: iinc #5, 1
    //   957: aload_0
    //   958: iload_2
    //   959: ifne -> 976
    //   962: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   965: goto -> 969
    //   968: athrow
    //   969: ifnull -> 975
    //   972: iinc #5, 1
    //   975: aload_0
    //   976: iload_2
    //   977: ifne -> 1010
    //   980: getfield J : Lorg/objectweb/asm/Attribute;
    //   983: ifnull -> 1002
    //   986: goto -> 990
    //   989: athrow
    //   990: iload #5
    //   992: aload_0
    //   993: getfield J : Lorg/objectweb/asm/Attribute;
    //   996: invokevirtual a : ()I
    //   999: iadd
    //   1000: istore #5
    //   1002: aload_1
    //   1003: iload #5
    //   1005: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1008: pop
    //   1009: aload_0
    //   1010: getfield E : Lorg/objectweb/asm/ByteVector;
    //   1013: iload_2
    //   1014: ifne -> 1094
    //   1017: ifnull -> 1090
    //   1020: goto -> 1024
    //   1023: athrow
    //   1024: aload_1
    //   1025: aload_0
    //   1026: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1029: sipush #-21091
    //   1032: sipush #12980
    //   1035: invokestatic b : (II)Ljava/lang/String;
    //   1038: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1041: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1044: pop
    //   1045: aload_1
    //   1046: aload_0
    //   1047: getfield E : Lorg/objectweb/asm/ByteVector;
    //   1050: getfield b : I
    //   1053: iconst_2
    //   1054: iadd
    //   1055: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1058: aload_0
    //   1059: getfield D : I
    //   1062: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1065: pop
    //   1066: aload_1
    //   1067: aload_0
    //   1068: getfield E : Lorg/objectweb/asm/ByteVector;
    //   1071: getfield a : [B
    //   1074: iconst_0
    //   1075: aload_0
    //   1076: getfield E : Lorg/objectweb/asm/ByteVector;
    //   1079: getfield b : I
    //   1082: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1085: pop
    //   1086: goto -> 1090
    //   1089: athrow
    //   1090: aload_0
    //   1091: getfield G : Lorg/objectweb/asm/ByteVector;
    //   1094: iload_2
    //   1095: ifne -> 1175
    //   1098: ifnull -> 1171
    //   1101: goto -> 1105
    //   1104: athrow
    //   1105: aload_1
    //   1106: aload_0
    //   1107: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1110: sipush #-21104
    //   1113: sipush #9898
    //   1116: invokestatic b : (II)Ljava/lang/String;
    //   1119: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1122: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1125: pop
    //   1126: aload_1
    //   1127: aload_0
    //   1128: getfield G : Lorg/objectweb/asm/ByteVector;
    //   1131: getfield b : I
    //   1134: iconst_2
    //   1135: iadd
    //   1136: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1139: aload_0
    //   1140: getfield F : I
    //   1143: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1146: pop
    //   1147: aload_1
    //   1148: aload_0
    //   1149: getfield G : Lorg/objectweb/asm/ByteVector;
    //   1152: getfield a : [B
    //   1155: iconst_0
    //   1156: aload_0
    //   1157: getfield G : Lorg/objectweb/asm/ByteVector;
    //   1160: getfield b : I
    //   1163: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1166: pop
    //   1167: goto -> 1171
    //   1170: athrow
    //   1171: aload_0
    //   1172: getfield I : Lorg/objectweb/asm/ByteVector;
    //   1175: iload_2
    //   1176: ifne -> 1264
    //   1179: ifnull -> 1252
    //   1182: goto -> 1186
    //   1185: athrow
    //   1186: aload_1
    //   1187: aload_0
    //   1188: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1191: sipush #-21116
    //   1194: sipush #-3243
    //   1197: invokestatic b : (II)Ljava/lang/String;
    //   1200: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1203: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1206: pop
    //   1207: aload_1
    //   1208: aload_0
    //   1209: getfield I : Lorg/objectweb/asm/ByteVector;
    //   1212: getfield b : I
    //   1215: iconst_2
    //   1216: iadd
    //   1217: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1220: aload_0
    //   1221: getfield H : I
    //   1224: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1227: pop
    //   1228: aload_1
    //   1229: aload_0
    //   1230: getfield I : Lorg/objectweb/asm/ByteVector;
    //   1233: getfield a : [B
    //   1236: iconst_0
    //   1237: aload_0
    //   1238: getfield I : Lorg/objectweb/asm/ByteVector;
    //   1241: getfield b : I
    //   1244: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1247: pop
    //   1248: goto -> 1252
    //   1251: athrow
    //   1252: aload_0
    //   1253: iload_2
    //   1254: ifne -> 1386
    //   1257: getfield v : Lorg/objectweb/asm/ByteVector;
    //   1260: goto -> 1264
    //   1263: athrow
    //   1264: ifnull -> 1385
    //   1267: aload_0
    //   1268: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1271: getfield b : I
    //   1274: ldc 65535
    //   1276: iand
    //   1277: iload_2
    //   1278: ifne -> 1299
    //   1281: goto -> 1285
    //   1284: athrow
    //   1285: bipush #50
    //   1287: if_icmplt -> 1302
    //   1290: goto -> 1294
    //   1293: athrow
    //   1294: iconst_1
    //   1295: goto -> 1299
    //   1298: athrow
    //   1299: goto -> 1303
    //   1302: iconst_0
    //   1303: istore #7
    //   1305: aload_1
    //   1306: aload_0
    //   1307: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1310: iload #7
    //   1312: ifeq -> 1328
    //   1315: sipush #-21098
    //   1318: sipush #8501
    //   1321: invokestatic b : (II)Ljava/lang/String;
    //   1324: goto -> 1337
    //   1327: athrow
    //   1328: sipush #-21115
    //   1331: sipush #13305
    //   1334: invokestatic b : (II)Ljava/lang/String;
    //   1337: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1340: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1343: pop
    //   1344: aload_1
    //   1345: aload_0
    //   1346: getfield v : Lorg/objectweb/asm/ByteVector;
    //   1349: getfield b : I
    //   1352: iconst_2
    //   1353: iadd
    //   1354: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1357: aload_0
    //   1358: getfield u : I
    //   1361: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1364: pop
    //   1365: aload_1
    //   1366: aload_0
    //   1367: getfield v : Lorg/objectweb/asm/ByteVector;
    //   1370: getfield a : [B
    //   1373: iconst_0
    //   1374: aload_0
    //   1375: getfield v : Lorg/objectweb/asm/ByteVector;
    //   1378: getfield b : I
    //   1381: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1384: pop
    //   1385: aload_0
    //   1386: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   1389: iload_2
    //   1390: ifne -> 1445
    //   1393: ifnull -> 1433
    //   1396: goto -> 1400
    //   1399: athrow
    //   1400: aload_1
    //   1401: aload_0
    //   1402: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1405: sipush #-21114
    //   1408: sipush #-27438
    //   1411: invokestatic b : (II)Ljava/lang/String;
    //   1414: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1417: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1420: pop
    //   1421: aload_0
    //   1422: getfield W : Lorg/objectweb/asm/AnnotationWriter;
    //   1425: aload_1
    //   1426: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1429: goto -> 1433
    //   1432: athrow
    //   1433: aload_0
    //   1434: iload_2
    //   1435: ifne -> 1482
    //   1438: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   1441: goto -> 1445
    //   1444: athrow
    //   1445: ifnull -> 1481
    //   1448: aload_1
    //   1449: aload_0
    //   1450: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1453: sipush #-21092
    //   1456: sipush #-32532
    //   1459: invokestatic b : (II)Ljava/lang/String;
    //   1462: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1465: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1468: pop
    //   1469: aload_0
    //   1470: getfield X : Lorg/objectweb/asm/AnnotationWriter;
    //   1473: aload_1
    //   1474: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   1477: goto -> 1481
    //   1480: athrow
    //   1481: aload_0
    //   1482: iload_2
    //   1483: ifne -> 1535
    //   1486: getfield J : Lorg/objectweb/asm/Attribute;
    //   1489: ifnull -> 1534
    //   1492: goto -> 1496
    //   1495: athrow
    //   1496: aload_0
    //   1497: getfield J : Lorg/objectweb/asm/Attribute;
    //   1500: aload_0
    //   1501: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1504: aload_0
    //   1505: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1508: getfield a : [B
    //   1511: aload_0
    //   1512: getfield r : Lorg/objectweb/asm/ByteVector;
    //   1515: getfield b : I
    //   1518: aload_0
    //   1519: getfield t : I
    //   1522: aload_0
    //   1523: getfield s : I
    //   1526: aload_1
    //   1527: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIIILorg/objectweb/asm/ByteVector;)V
    //   1530: goto -> 1534
    //   1533: athrow
    //   1534: aload_0
    //   1535: getfield j : I
    //   1538: iload_2
    //   1539: ifne -> 1637
    //   1542: ifle -> 1629
    //   1545: goto -> 1549
    //   1548: athrow
    //   1549: aload_1
    //   1550: aload_0
    //   1551: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1554: sipush #-21113
    //   1557: sipush #10258
    //   1560: invokestatic b : (II)Ljava/lang/String;
    //   1563: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1566: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1569: iconst_2
    //   1570: aload_0
    //   1571: getfield j : I
    //   1574: imul
    //   1575: iconst_2
    //   1576: iadd
    //   1577: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1580: pop
    //   1581: aload_1
    //   1582: aload_0
    //   1583: getfield j : I
    //   1586: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1589: pop
    //   1590: iconst_0
    //   1591: istore #6
    //   1593: iload #6
    //   1595: aload_0
    //   1596: getfield j : I
    //   1599: if_icmpge -> 1629
    //   1602: aload_1
    //   1603: aload_0
    //   1604: getfield k : [I
    //   1607: iload #6
    //   1609: iaload
    //   1610: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1613: pop
    //   1614: iinc #6, 1
    //   1617: iload_2
    //   1618: ifne -> 1726
    //   1621: iload_2
    //   1622: ifeq -> 1593
    //   1625: goto -> 1629
    //   1628: athrow
    //   1629: aload_0
    //   1630: getfield c : I
    //   1633: sipush #4096
    //   1636: iand
    //   1637: iload_2
    //   1638: ifne -> 1741
    //   1641: ifeq -> 1726
    //   1644: goto -> 1648
    //   1647: athrow
    //   1648: aload_0
    //   1649: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1652: getfield b : I
    //   1655: ldc 65535
    //   1657: iand
    //   1658: bipush #49
    //   1660: iload_2
    //   1661: ifne -> 1685
    //   1664: goto -> 1668
    //   1667: athrow
    //   1668: if_icmplt -> 1697
    //   1671: goto -> 1675
    //   1674: athrow
    //   1675: aload_0
    //   1676: getfield c : I
    //   1679: ldc 262144
    //   1681: goto -> 1685
    //   1684: athrow
    //   1685: iand
    //   1686: iload_2
    //   1687: ifne -> 1741
    //   1690: ifeq -> 1726
    //   1693: goto -> 1697
    //   1696: athrow
    //   1697: aload_1
    //   1698: aload_0
    //   1699: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1702: sipush #-21101
    //   1705: sipush #-28565
    //   1708: invokestatic b : (II)Ljava/lang/String;
    //   1711: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1714: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1717: iconst_0
    //   1718: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1721: pop
    //   1722: goto -> 1726
    //   1725: athrow
    //   1726: aload_0
    //   1727: iload_2
    //   1728: ifne -> 1774
    //   1731: getfield c : I
    //   1734: ldc 131072
    //   1736: iand
    //   1737: goto -> 1741
    //   1740: athrow
    //   1741: ifeq -> 1773
    //   1744: aload_1
    //   1745: aload_0
    //   1746: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1749: sipush #-21089
    //   1752: sipush #23526
    //   1755: invokestatic b : (II)Ljava/lang/String;
    //   1758: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1761: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1764: iconst_0
    //   1765: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1768: pop
    //   1769: goto -> 1773
    //   1772: athrow
    //   1773: aload_0
    //   1774: iload_2
    //   1775: ifne -> 1832
    //   1778: getfield g : Ljava/lang/String;
    //   1781: ifnull -> 1831
    //   1784: goto -> 1788
    //   1787: athrow
    //   1788: aload_1
    //   1789: aload_0
    //   1790: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1793: sipush #-21093
    //   1796: sipush #26921
    //   1799: invokestatic b : (II)Ljava/lang/String;
    //   1802: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1805: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1808: iconst_2
    //   1809: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1812: aload_0
    //   1813: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1816: aload_0
    //   1817: getfield g : Ljava/lang/String;
    //   1820: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1823: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1826: pop
    //   1827: goto -> 1831
    //   1830: athrow
    //   1831: aload_0
    //   1832: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   1835: iload_2
    //   1836: ifne -> 1924
    //   1839: ifnull -> 1912
    //   1842: goto -> 1846
    //   1845: athrow
    //   1846: aload_1
    //   1847: aload_0
    //   1848: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1851: sipush #-21102
    //   1854: sipush #-21719
    //   1857: invokestatic b : (II)Ljava/lang/String;
    //   1860: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1863: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1866: pop
    //   1867: aload_1
    //   1868: aload_0
    //   1869: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   1872: getfield b : I
    //   1875: iconst_1
    //   1876: iadd
    //   1877: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1880: aload_0
    //   1881: getfield Z : I
    //   1884: invokevirtual putByte : (I)Lorg/objectweb/asm/ByteVector;
    //   1887: pop
    //   1888: aload_1
    //   1889: aload_0
    //   1890: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   1893: getfield a : [B
    //   1896: iconst_0
    //   1897: aload_0
    //   1898: getfield $ : Lorg/objectweb/asm/ByteVector;
    //   1901: getfield b : I
    //   1904: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1907: pop
    //   1908: goto -> 1912
    //   1911: athrow
    //   1912: aload_0
    //   1913: iload_2
    //   1914: ifne -> 1985
    //   1917: getfield l : Lorg/objectweb/asm/ByteVector;
    //   1920: goto -> 1924
    //   1923: athrow
    //   1924: ifnull -> 1984
    //   1927: aload_1
    //   1928: aload_0
    //   1929: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   1932: sipush #-21100
    //   1935: sipush #25520
    //   1938: invokestatic b : (II)Ljava/lang/String;
    //   1941: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   1944: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   1947: pop
    //   1948: aload_1
    //   1949: aload_0
    //   1950: getfield l : Lorg/objectweb/asm/ByteVector;
    //   1953: getfield b : I
    //   1956: invokevirtual putInt : (I)Lorg/objectweb/asm/ByteVector;
    //   1959: pop
    //   1960: aload_1
    //   1961: aload_0
    //   1962: getfield l : Lorg/objectweb/asm/ByteVector;
    //   1965: getfield a : [B
    //   1968: iconst_0
    //   1969: aload_0
    //   1970: getfield l : Lorg/objectweb/asm/ByteVector;
    //   1973: getfield b : I
    //   1976: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   1979: pop
    //   1980: goto -> 1984
    //   1983: athrow
    //   1984: aload_0
    //   1985: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   1988: iload_2
    //   1989: ifne -> 2036
    //   1992: ifnull -> 2032
    //   1995: goto -> 1999
    //   1998: athrow
    //   1999: aload_1
    //   2000: aload_0
    //   2001: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2004: sipush #-21095
    //   2007: sipush #23920
    //   2010: invokestatic b : (II)Ljava/lang/String;
    //   2013: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2016: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2019: pop
    //   2020: aload_0
    //   2021: getfield m : Lorg/objectweb/asm/AnnotationWriter;
    //   2024: aload_1
    //   2025: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   2028: goto -> 2032
    //   2031: athrow
    //   2032: aload_0
    //   2033: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   2036: iload_2
    //   2037: ifne -> 2084
    //   2040: ifnull -> 2080
    //   2043: goto -> 2047
    //   2046: athrow
    //   2047: aload_1
    //   2048: aload_0
    //   2049: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2052: sipush #-21094
    //   2055: sipush #-28672
    //   2058: invokestatic b : (II)Ljava/lang/String;
    //   2061: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2064: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2067: pop
    //   2068: aload_0
    //   2069: getfield n : Lorg/objectweb/asm/AnnotationWriter;
    //   2072: aload_1
    //   2073: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   2076: goto -> 2080
    //   2079: athrow
    //   2080: aload_0
    //   2081: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   2084: iload_2
    //   2085: ifne -> 2140
    //   2088: ifnull -> 2128
    //   2091: goto -> 2095
    //   2094: athrow
    //   2095: aload_1
    //   2096: aload_0
    //   2097: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2100: sipush #-21114
    //   2103: sipush #-27438
    //   2106: invokestatic b : (II)Ljava/lang/String;
    //   2109: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2112: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2115: pop
    //   2116: aload_0
    //   2117: getfield U : Lorg/objectweb/asm/AnnotationWriter;
    //   2120: aload_1
    //   2121: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   2124: goto -> 2128
    //   2127: athrow
    //   2128: aload_0
    //   2129: iload_2
    //   2130: ifne -> 2177
    //   2133: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   2136: goto -> 2140
    //   2139: athrow
    //   2140: ifnull -> 2176
    //   2143: aload_1
    //   2144: aload_0
    //   2145: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2148: sipush #-21092
    //   2151: sipush #-32532
    //   2154: invokestatic b : (II)Ljava/lang/String;
    //   2157: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2160: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2163: pop
    //   2164: aload_0
    //   2165: getfield V : Lorg/objectweb/asm/AnnotationWriter;
    //   2168: aload_1
    //   2169: invokevirtual a : (Lorg/objectweb/asm/ByteVector;)V
    //   2172: goto -> 2176
    //   2175: athrow
    //   2176: aload_0
    //   2177: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   2180: iload_2
    //   2181: ifne -> 2240
    //   2184: ifnull -> 2228
    //   2187: goto -> 2191
    //   2190: athrow
    //   2191: aload_1
    //   2192: aload_0
    //   2193: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2196: sipush #-21096
    //   2199: sipush #13293
    //   2202: invokestatic b : (II)Ljava/lang/String;
    //   2205: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2208: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2211: pop
    //   2212: aload_0
    //   2213: getfield o : [Lorg/objectweb/asm/AnnotationWriter;
    //   2216: aload_0
    //   2217: getfield R : I
    //   2220: aload_1
    //   2221: invokestatic a : ([Lorg/objectweb/asm/AnnotationWriter;ILorg/objectweb/asm/ByteVector;)V
    //   2224: goto -> 2228
    //   2227: athrow
    //   2228: aload_0
    //   2229: iload_2
    //   2230: ifne -> 2281
    //   2233: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   2236: goto -> 2240
    //   2239: athrow
    //   2240: ifnull -> 2280
    //   2243: aload_1
    //   2244: aload_0
    //   2245: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2248: sipush #-21120
    //   2251: sipush #-5892
    //   2254: invokestatic b : (II)Ljava/lang/String;
    //   2257: invokevirtual newUTF8 : (Ljava/lang/String;)I
    //   2260: invokevirtual putShort : (I)Lorg/objectweb/asm/ByteVector;
    //   2263: pop
    //   2264: aload_0
    //   2265: getfield p : [Lorg/objectweb/asm/AnnotationWriter;
    //   2268: aload_0
    //   2269: getfield R : I
    //   2272: aload_1
    //   2273: invokestatic a : ([Lorg/objectweb/asm/AnnotationWriter;ILorg/objectweb/asm/ByteVector;)V
    //   2276: goto -> 2280
    //   2279: athrow
    //   2280: aload_0
    //   2281: getfield q : Lorg/objectweb/asm/Attribute;
    //   2284: iload_2
    //   2285: ifne -> 2303
    //   2288: ifnull -> 2315
    //   2291: goto -> 2295
    //   2294: athrow
    //   2295: aload_0
    //   2296: getfield q : Lorg/objectweb/asm/Attribute;
    //   2299: goto -> 2303
    //   2302: athrow
    //   2303: aload_0
    //   2304: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   2307: aconst_null
    //   2308: iconst_0
    //   2309: iconst_m1
    //   2310: iconst_m1
    //   2311: aload_1
    //   2312: invokevirtual a : (Lorg/objectweb/asm/ClassWriter;[BIIILorg/objectweb/asm/ByteVector;)V
    //   2315: return
    // Exception table:
    //   from	to	target	type
    //   22	61	64	java/lang/IllegalStateException
    //   58	89	89	java/lang/IllegalStateException
    //   93	107	110	java/lang/IllegalStateException
    //   118	125	128	java/lang/IllegalStateException
    //   140	147	150	java/lang/IllegalStateException
    //   144	167	170	java/lang/IllegalStateException
    //   151	174	177	java/lang/IllegalStateException
    //   171	184	187	java/lang/IllegalStateException
    //   188	196	199	java/lang/IllegalStateException
    //   203	214	217	java/lang/IllegalStateException
    //   225	235	238	java/lang/IllegalStateException
    //   229	242	245	java/lang/IllegalStateException
    //   247	257	260	java/lang/IllegalStateException
    //   264	272	275	java/lang/IllegalStateException
    //   283	293	296	java/lang/IllegalStateException
    //   304	311	314	java/lang/IllegalStateException
    //   322	329	332	java/lang/IllegalStateException
    //   336	344	347	java/lang/IllegalStateException
    //   355	365	368	java/lang/IllegalStateException
    //   372	380	383	java/lang/IllegalStateException
    //   391	401	404	java/lang/IllegalStateException
    //   425	438	441	java/lang/IllegalStateException
    //   462	473	476	java/lang/IllegalStateException
    //   496	503	506	java/lang/IllegalStateException
    //   526	533	536	java/lang/IllegalStateException
    //   552	560	563	java/lang/IllegalStateException
    //   583	593	596	java/lang/IllegalStateException
    //   612	620	623	java/lang/IllegalStateException
    //   643	653	656	java/lang/IllegalStateException
    //   777	787	790	java/lang/IllegalStateException
    //   852	860	863	java/lang/IllegalStateException
    //   867	878	881	java/lang/IllegalStateException
    //   889	896	899	java/lang/IllegalStateException
    //   907	914	917	java/lang/IllegalStateException
    //   921	929	932	java/lang/IllegalStateException
    //   940	950	953	java/lang/IllegalStateException
    //   957	965	968	java/lang/IllegalStateException
    //   976	986	989	java/lang/IllegalStateException
    //   1010	1020	1023	java/lang/IllegalStateException
    //   1017	1086	1089	java/lang/IllegalStateException
    //   1094	1101	1104	java/lang/IllegalStateException
    //   1098	1167	1170	java/lang/IllegalStateException
    //   1175	1182	1185	java/lang/IllegalStateException
    //   1179	1248	1251	java/lang/IllegalStateException
    //   1252	1260	1263	java/lang/IllegalStateException
    //   1264	1281	1284	java/lang/IllegalStateException
    //   1267	1290	1293	java/lang/IllegalStateException
    //   1285	1295	1298	java/lang/IllegalStateException
    //   1305	1327	1327	java/lang/IllegalStateException
    //   1386	1396	1399	java/lang/IllegalStateException
    //   1393	1429	1432	java/lang/IllegalStateException
    //   1433	1441	1444	java/lang/IllegalStateException
    //   1445	1477	1480	java/lang/IllegalStateException
    //   1482	1492	1495	java/lang/IllegalStateException
    //   1486	1530	1533	java/lang/IllegalStateException
    //   1538	1545	1548	java/lang/IllegalStateException
    //   1602	1625	1628	java/lang/IllegalStateException
    //   1637	1644	1647	java/lang/IllegalStateException
    //   1641	1664	1667	java/lang/IllegalStateException
    //   1648	1671	1674	java/lang/IllegalStateException
    //   1668	1681	1684	java/lang/IllegalStateException
    //   1685	1693	1696	java/lang/IllegalStateException
    //   1690	1722	1725	java/lang/IllegalStateException
    //   1726	1737	1740	java/lang/IllegalStateException
    //   1741	1769	1772	java/lang/IllegalStateException
    //   1774	1784	1787	java/lang/IllegalStateException
    //   1778	1827	1830	java/lang/IllegalStateException
    //   1832	1842	1845	java/lang/IllegalStateException
    //   1839	1908	1911	java/lang/IllegalStateException
    //   1912	1920	1923	java/lang/IllegalStateException
    //   1924	1980	1983	java/lang/IllegalStateException
    //   1985	1995	1998	java/lang/IllegalStateException
    //   1992	2028	2031	java/lang/IllegalStateException
    //   2036	2043	2046	java/lang/IllegalStateException
    //   2040	2076	2079	java/lang/IllegalStateException
    //   2084	2091	2094	java/lang/IllegalStateException
    //   2088	2124	2127	java/lang/IllegalStateException
    //   2128	2136	2139	java/lang/IllegalStateException
    //   2140	2172	2175	java/lang/IllegalStateException
    //   2177	2187	2190	java/lang/IllegalStateException
    //   2184	2224	2227	java/lang/IllegalStateException
    //   2228	2236	2239	java/lang/IllegalStateException
    //   2240	2276	2279	java/lang/IllegalStateException
    //   2281	2291	2294	java/lang/IllegalStateException
    //   2288	2299	2302	java/lang/IllegalStateException
  }
  
  static {
    // Byte code:
    //   0: bipush #22
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc 'ôoâôc"ÝÛ^ý.SFæñª8ìR{\\r}^k$8ä±ÿ¬[ Ç²B²\\bþUíñÆÒb12MI~¢7m»Yeâ!\\nU0ÌFã\\nö\\t ÝáÜìk\\bÆ372\\t\\tâ\\rx®Ø^Æ¨÷H\\nîG´-Ú@+×þØÙåB²£Êk¯é³Èª+ZGÂ°\\n[÷ä\\rê\\ftxîjáéÊ¾áçIHÊ»oR¥(.¦Oa¸î@N^ÝcÚ²õ®ð]ûGü-"»ìÓÌ¸ÎÎÀdö$®UT²3¸1z×n"pù¯7ä\\t'WúèNÆØ×Äaº}çlCsKõY"«JAkßàZÞ|\\bpÁÿ16¢7häy:WÚV!\\b®\\nÁJotzº{3>¤MT°øk¨j#·iXg± eÍ'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #6
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: jsr -> 137
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 23
    //   65: ldc 'ÀYà3c$~×êHû"jç$Ï&æ2~]ì@á$ÞD1:Ïüíÿ)(ÍO%3mV'
    //   67: dup
    //   68: astore_2
    //   69: invokevirtual length : ()I
    //   72: istore #4
    //   74: bipush #19
    //   76: istore_1
    //   77: iconst_m1
    //   78: istore_0
    //   79: iinc #0, 1
    //   82: aload_2
    //   83: iload_0
    //   84: dup
    //   85: iload_1
    //   86: iadd
    //   87: invokevirtual substring : (II)Ljava/lang/String;
    //   90: jsr -> 137
    //   93: aload #5
    //   95: swap
    //   96: iload_3
    //   97: iinc #3, 1
    //   100: swap
    //   101: aastore
    //   102: iload_0
    //   103: iload_1
    //   104: iadd
    //   105: dup
    //   106: istore_0
    //   107: iload #4
    //   109: if_icmpge -> 121
    //   112: aload_2
    //   113: iload_0
    //   114: invokevirtual charAt : (I)C
    //   117: istore_1
    //   118: goto -> 79
    //   121: aload #5
    //   123: putstatic org/objectweb/asm/MethodWriter.y : [Ljava/lang/String;
    //   126: bipush #22
    //   128: anewarray java/lang/String
    //   131: putstatic org/objectweb/asm/MethodWriter.S : [Ljava/lang/String;
    //   134: goto -> 278
    //   137: astore #6
    //   139: invokevirtual toCharArray : ()[C
    //   142: dup
    //   143: arraylength
    //   144: swap
    //   145: iconst_0
    //   146: istore #7
    //   148: swap
    //   149: dup_x1
    //   150: iconst_1
    //   151: if_icmpgt -> 256
    //   154: dup
    //   155: iload #7
    //   157: dup2
    //   158: caload
    //   159: iload #7
    //   161: bipush #7
    //   163: irem
    //   164: tableswitch default -> 237, 0 -> 204, 1 -> 209, 2 -> 215, 3 -> 221, 4 -> 226, 5 -> 231
    //   204: bipush #57
    //   206: goto -> 240
    //   209: sipush #225
    //   212: goto -> 240
    //   215: sipush #142
    //   218: goto -> 240
    //   221: bipush #8
    //   223: goto -> 240
    //   226: bipush #57
    //   228: goto -> 240
    //   231: sipush #199
    //   234: goto -> 240
    //   237: sipush #196
    //   240: ixor
    //   241: i2c
    //   242: castore
    //   243: iinc #7, 1
    //   246: swap
    //   247: dup_x1
    //   248: ifne -> 256
    //   251: dup2
    //   252: swap
    //   253: goto -> 157
    //   256: swap
    //   257: dup_x1
    //   258: iload #7
    //   260: if_icmpgt -> 154
    //   263: new java/lang/String
    //   266: dup_x1
    //   267: swap
    //   268: invokespecial <init> : ([C)V
    //   271: invokevirtual intern : ()Ljava/lang/String;
    //   274: swap
    //   275: pop
    //   276: ret #6
    //   278: return
  }
  
  private static String b(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0xFFFFAD95) & 0xFFFF;
    if (S[i] == null) {
      char[] arrayOfChar = y[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 80;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      S[i] = (new String(arrayOfChar)).intern();
    } 
    return S[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\MethodWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */