package org.objectweb.asm;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class Type {
  public static final int VOID = 0;
  
  public static final int BOOLEAN = 1;
  
  public static final int CHAR = 2;
  
  public static final int BYTE = 3;
  
  public static final int SHORT = 4;
  
  public static final int INT = 5;
  
  public static final int FLOAT = 6;
  
  public static final int LONG = 7;
  
  public static final int DOUBLE = 8;
  
  public static final int ARRAY = 9;
  
  public static final int OBJECT = 10;
  
  public static final int METHOD = 11;
  
  public static final Type VOID_TYPE;
  
  public static final Type BOOLEAN_TYPE;
  
  public static final Type CHAR_TYPE;
  
  public static final Type BYTE_TYPE;
  
  public static final Type SHORT_TYPE;
  
  public static final Type INT_TYPE;
  
  public static final Type FLOAT_TYPE;
  
  public static final Type LONG_TYPE;
  
  public static final Type DOUBLE_TYPE;
  
  private final int a;
  
  private final char[] b;
  
  private final int c;
  
  private final int d;
  
  private static final String[] e;
  
  private static final String[] f;
  
  private Type(int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramArrayOfchar;
    this.c = paramInt2;
    this.d = paramInt3;
  }
  
  public static Type getType(String paramString) {
    return a(paramString.toCharArray(), 0);
  }
  
  public static Type getObjectType(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    return new Type((arrayOfChar[0] == '[') ? 9 : 10, arrayOfChar, 0, arrayOfChar.length);
  }
  
  public static Type getMethodType(String paramString) {
    return a(paramString.toCharArray(), 0);
  }
  
  public static Type getMethodType(Type paramType, Type[] paramArrayOfType) {
    return getType(getMethodDescriptor(paramType, paramArrayOfType));
  }
  
  public static Type getType(Class paramClass) {
    int i = MethodVisitor.b;
    if (i == 0)
      if (paramClass.isPrimitive()) {
        if (i == 0)
          if (paramClass == int.class)
            return INT_TYPE;  
        if (i == 0)
          if (paramClass == void.class)
            return VOID_TYPE;  
        if (i == 0)
          if (paramClass == boolean.class)
            return BOOLEAN_TYPE;  
        if (i == 0)
          if (paramClass == byte.class)
            return BYTE_TYPE;  
        if (i == 0)
          if (paramClass == char.class)
            return CHAR_TYPE;  
        if (i == 0)
          if (paramClass == short.class)
            return SHORT_TYPE;  
        if (i == 0)
          if (paramClass == double.class)
            return DOUBLE_TYPE;  
        return (paramClass == float.class) ? FLOAT_TYPE : LONG_TYPE;
      }  
    return getType(getDescriptor(paramClass));
  }
  
  public static Type getType(Constructor paramConstructor) {
    return getType(getConstructorDescriptor(paramConstructor));
  }
  
  public static Type getType(Method paramMethod) {
    return getType(getMethodDescriptor(paramMethod));
  }
  
  public static Type[] getArgumentTypes(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual toCharArray : ()[C
    //   4: astore_2
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: iconst_1
    //   9: istore_3
    //   10: istore_1
    //   11: iconst_0
    //   12: istore #4
    //   14: aload_2
    //   15: iload_3
    //   16: iinc #3, 1
    //   19: caload
    //   20: istore #5
    //   22: iload #5
    //   24: bipush #41
    //   26: if_icmpne -> 32
    //   29: goto -> 78
    //   32: iload #5
    //   34: bipush #76
    //   36: iload_1
    //   37: ifne -> 68
    //   40: if_icmpne -> 64
    //   43: aload_2
    //   44: iload_3
    //   45: iinc #3, 1
    //   48: caload
    //   49: bipush #59
    //   51: if_icmpeq -> 57
    //   54: goto -> 43
    //   57: iinc #4, 1
    //   60: iload_1
    //   61: ifeq -> 74
    //   64: iload #5
    //   66: bipush #91
    //   68: if_icmpeq -> 74
    //   71: iinc #4, 1
    //   74: iload_1
    //   75: ifeq -> 14
    //   78: iload #4
    //   80: anewarray org/objectweb/asm/Type
    //   83: astore #5
    //   85: iconst_1
    //   86: istore_3
    //   87: iconst_0
    //   88: istore #4
    //   90: aload_2
    //   91: iload_3
    //   92: caload
    //   93: bipush #41
    //   95: if_icmpeq -> 153
    //   98: aload #5
    //   100: iload_1
    //   101: ifne -> 155
    //   104: iload #4
    //   106: aload_2
    //   107: iload_3
    //   108: invokestatic a : ([CI)Lorg/objectweb/asm/Type;
    //   111: aastore
    //   112: iload_3
    //   113: aload #5
    //   115: iload #4
    //   117: aaload
    //   118: getfield d : I
    //   121: aload #5
    //   123: iload #4
    //   125: aaload
    //   126: getfield a : I
    //   129: iload_1
    //   130: ifne -> 139
    //   133: bipush #10
    //   135: if_icmpne -> 142
    //   138: iconst_2
    //   139: goto -> 143
    //   142: iconst_0
    //   143: iadd
    //   144: iadd
    //   145: istore_3
    //   146: iinc #4, 1
    //   149: iload_1
    //   150: ifeq -> 90
    //   153: aload #5
    //   155: areturn
  }
  
  public static Type[] getArgumentTypes(Method paramMethod) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   4: astore_2
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: aload_2
    //   9: arraylength
    //   10: anewarray org/objectweb/asm/Type
    //   13: astore_3
    //   14: istore_1
    //   15: aload_2
    //   16: arraylength
    //   17: iconst_1
    //   18: isub
    //   19: istore #4
    //   21: iload #4
    //   23: iflt -> 48
    //   26: aload_3
    //   27: iload_1
    //   28: ifne -> 49
    //   31: iload #4
    //   33: aload_2
    //   34: iload #4
    //   36: aaload
    //   37: invokestatic getType : (Ljava/lang/Class;)Lorg/objectweb/asm/Type;
    //   40: aastore
    //   41: iinc #4, -1
    //   44: iload_1
    //   45: ifeq -> 21
    //   48: aload_3
    //   49: areturn
  }
  
  public static Type getReturnType(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual toCharArray : ()[C
    //   4: astore_2
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: iconst_1
    //   9: istore_3
    //   10: istore_1
    //   11: aload_2
    //   12: iload_3
    //   13: iinc #3, 1
    //   16: caload
    //   17: istore #4
    //   19: iload #4
    //   21: bipush #41
    //   23: if_icmpne -> 36
    //   26: aload_2
    //   27: iload_3
    //   28: iload_1
    //   29: ifne -> 52
    //   32: invokestatic a : ([CI)Lorg/objectweb/asm/Type;
    //   35: areturn
    //   36: iload #4
    //   38: bipush #76
    //   40: iload_1
    //   41: ifne -> 55
    //   44: if_icmpne -> 61
    //   47: aload_2
    //   48: iload_3
    //   49: iinc #3, 1
    //   52: caload
    //   53: bipush #59
    //   55: if_icmpeq -> 61
    //   58: goto -> 47
    //   61: goto -> 11
  }
  
  public static Type getReturnType(Method paramMethod) {
    return getType(paramMethod.getReturnType());
  }
  
  public static int getArgumentsAndReturnSizes(String paramString) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   5: iconst_1
    //   6: istore_3
    //   7: istore_1
    //   8: aload_0
    //   9: iload_3
    //   10: iinc #3, 1
    //   13: invokevirtual charAt : (I)C
    //   16: istore #4
    //   18: iload #4
    //   20: bipush #41
    //   22: if_icmpne -> 83
    //   25: aload_0
    //   26: iload_3
    //   27: invokevirtual charAt : (I)C
    //   30: istore #4
    //   32: iload_2
    //   33: iconst_2
    //   34: ishl
    //   35: iload #4
    //   37: iload_1
    //   38: ifne -> 87
    //   41: bipush #86
    //   43: iload_1
    //   44: ifne -> 62
    //   47: if_icmpne -> 54
    //   50: iconst_0
    //   51: goto -> 81
    //   54: iload #4
    //   56: iload_1
    //   57: ifne -> 77
    //   60: bipush #68
    //   62: if_icmpeq -> 76
    //   65: iload #4
    //   67: iload_1
    //   68: ifne -> 77
    //   71: bipush #74
    //   73: if_icmpne -> 80
    //   76: iconst_2
    //   77: goto -> 81
    //   80: iconst_1
    //   81: ior
    //   82: ireturn
    //   83: iload #4
    //   85: bipush #76
    //   87: iload_1
    //   88: ifne -> 121
    //   91: if_icmpne -> 117
    //   94: aload_0
    //   95: iload_3
    //   96: iinc #3, 1
    //   99: invokevirtual charAt : (I)C
    //   102: bipush #59
    //   104: if_icmpeq -> 110
    //   107: goto -> 94
    //   110: iinc #2, 1
    //   113: iload_1
    //   114: ifeq -> 205
    //   117: iload #4
    //   119: bipush #91
    //   121: iload_1
    //   122: ifne -> 181
    //   125: if_icmpne -> 177
    //   128: aload_0
    //   129: iload_3
    //   130: invokevirtual charAt : (I)C
    //   133: dup
    //   134: istore #4
    //   136: bipush #91
    //   138: if_icmpne -> 152
    //   141: iinc #3, 1
    //   144: iload_1
    //   145: ifne -> 173
    //   148: iload_1
    //   149: ifeq -> 128
    //   152: iload #4
    //   154: bipush #68
    //   156: iload_1
    //   157: ifne -> 167
    //   160: if_icmpeq -> 170
    //   163: iload #4
    //   165: bipush #74
    //   167: if_icmpne -> 205
    //   170: iinc #2, -1
    //   173: iload_1
    //   174: ifeq -> 205
    //   177: iload #4
    //   179: bipush #68
    //   181: iload_1
    //   182: ifne -> 192
    //   185: if_icmpeq -> 195
    //   188: iload #4
    //   190: bipush #74
    //   192: if_icmpne -> 202
    //   195: iinc #2, 2
    //   198: iload_1
    //   199: ifeq -> 205
    //   202: iinc #2, 1
    //   205: goto -> 8
  }
  
  private static Type a(char[] paramArrayOfchar, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: iload_1
    //   6: caload
    //   7: tableswitch default -> 264, 66 -> 136, 67 -> 132, 68 -> 156, 69 -> 264, 70 -> 148, 71 -> 264, 72 -> 264, 73 -> 144, 74 -> 152, 75 -> 264, 76 -> 228, 77 -> 264, 78 -> 264, 79 -> 264, 80 -> 264, 81 -> 264, 82 -> 264, 83 -> 140, 84 -> 264, 85 -> 264, 86 -> 124, 87 -> 264, 88 -> 264, 89 -> 264, 90 -> 128, 91 -> 160
    //   124: getstatic org/objectweb/asm/Type.VOID_TYPE : Lorg/objectweb/asm/Type;
    //   127: areturn
    //   128: getstatic org/objectweb/asm/Type.BOOLEAN_TYPE : Lorg/objectweb/asm/Type;
    //   131: areturn
    //   132: getstatic org/objectweb/asm/Type.CHAR_TYPE : Lorg/objectweb/asm/Type;
    //   135: areturn
    //   136: getstatic org/objectweb/asm/Type.BYTE_TYPE : Lorg/objectweb/asm/Type;
    //   139: areturn
    //   140: getstatic org/objectweb/asm/Type.SHORT_TYPE : Lorg/objectweb/asm/Type;
    //   143: areturn
    //   144: getstatic org/objectweb/asm/Type.INT_TYPE : Lorg/objectweb/asm/Type;
    //   147: areturn
    //   148: getstatic org/objectweb/asm/Type.FLOAT_TYPE : Lorg/objectweb/asm/Type;
    //   151: areturn
    //   152: getstatic org/objectweb/asm/Type.LONG_TYPE : Lorg/objectweb/asm/Type;
    //   155: areturn
    //   156: getstatic org/objectweb/asm/Type.DOUBLE_TYPE : Lorg/objectweb/asm/Type;
    //   159: areturn
    //   160: iconst_1
    //   161: istore_3
    //   162: aload_0
    //   163: iload_1
    //   164: iload_3
    //   165: iadd
    //   166: caload
    //   167: bipush #91
    //   169: if_icmpne -> 183
    //   172: iinc #3, 1
    //   175: iload_2
    //   176: ifne -> 213
    //   179: iload_2
    //   180: ifeq -> 162
    //   183: aload_0
    //   184: iload_1
    //   185: iload_3
    //   186: iadd
    //   187: caload
    //   188: bipush #76
    //   190: if_icmpne -> 213
    //   193: iinc #3, 1
    //   196: aload_0
    //   197: iload_1
    //   198: iload_3
    //   199: iadd
    //   200: caload
    //   201: bipush #59
    //   203: if_icmpeq -> 213
    //   206: iinc #3, 1
    //   209: iload_2
    //   210: ifeq -> 196
    //   213: new org/objectweb/asm/Type
    //   216: dup
    //   217: bipush #9
    //   219: aload_0
    //   220: iload_1
    //   221: iload_3
    //   222: iconst_1
    //   223: iadd
    //   224: invokespecial <init> : (I[CII)V
    //   227: areturn
    //   228: iconst_1
    //   229: istore_3
    //   230: aload_0
    //   231: iload_1
    //   232: iload_3
    //   233: iadd
    //   234: caload
    //   235: bipush #59
    //   237: if_icmpeq -> 247
    //   240: iinc #3, 1
    //   243: iload_2
    //   244: ifeq -> 230
    //   247: new org/objectweb/asm/Type
    //   250: dup
    //   251: bipush #10
    //   253: aload_0
    //   254: iload_1
    //   255: iconst_1
    //   256: iadd
    //   257: iload_3
    //   258: iconst_1
    //   259: isub
    //   260: invokespecial <init> : (I[CII)V
    //   263: areturn
    //   264: new org/objectweb/asm/Type
    //   267: dup
    //   268: bipush #11
    //   270: aload_0
    //   271: iload_1
    //   272: aload_0
    //   273: arraylength
    //   274: iload_1
    //   275: isub
    //   276: invokespecial <init> : (I[CII)V
    //   279: areturn
  }
  
  public int getSort() {
    return this.a;
  }
  
  public int getDimensions() {
    int i = MethodVisitor.b;
    byte b = 1;
    while (this.b[this.c + b] == '[') {
      b++;
      if (i != 0)
        break; 
    } 
    return b;
  }
  
  public Type getElementType() {
    return a(this.b, this.c + getDimensions());
  }
  
  public String getClassName() {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_1
    //   4: aload_0
    //   5: getfield a : I
    //   8: tableswitch default -> 239, 0 -> 68, 1 -> 78, 2 -> 88, 3 -> 98, 4 -> 108, 5 -> 118, 6 -> 128, 7 -> 138, 8 -> 148, 9 -> 158, 10 -> 212
    //   68: sipush #20986
    //   71: sipush #12813
    //   74: invokestatic a : (II)Ljava/lang/String;
    //   77: areturn
    //   78: sipush #20982
    //   81: sipush #-20872
    //   84: invokestatic a : (II)Ljava/lang/String;
    //   87: areturn
    //   88: sipush #20983
    //   91: sipush #28208
    //   94: invokestatic a : (II)Ljava/lang/String;
    //   97: areturn
    //   98: sipush #20987
    //   101: sipush #13007
    //   104: invokestatic a : (II)Ljava/lang/String;
    //   107: areturn
    //   108: sipush #20980
    //   111: sipush #7206
    //   114: invokestatic a : (II)Ljava/lang/String;
    //   117: areturn
    //   118: sipush #20976
    //   121: sipush #12545
    //   124: invokestatic a : (II)Ljava/lang/String;
    //   127: areturn
    //   128: sipush #20984
    //   131: sipush #-13072
    //   134: invokestatic a : (II)Ljava/lang/String;
    //   137: areturn
    //   138: sipush #20978
    //   141: sipush #-7322
    //   144: invokestatic a : (II)Ljava/lang/String;
    //   147: areturn
    //   148: sipush #20979
    //   151: sipush #-5399
    //   154: invokestatic a : (II)Ljava/lang/String;
    //   157: areturn
    //   158: new java/lang/StringBuffer
    //   161: dup
    //   162: aload_0
    //   163: invokevirtual getElementType : ()Lorg/objectweb/asm/Type;
    //   166: invokevirtual getClassName : ()Ljava/lang/String;
    //   169: invokespecial <init> : (Ljava/lang/String;)V
    //   172: astore_2
    //   173: aload_0
    //   174: invokevirtual getDimensions : ()I
    //   177: istore_3
    //   178: iload_3
    //   179: ifle -> 207
    //   182: aload_2
    //   183: sipush #20977
    //   186: sipush #2515
    //   189: invokestatic a : (II)Ljava/lang/String;
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   195: iload_1
    //   196: ifne -> 208
    //   199: pop
    //   200: iinc #3, -1
    //   203: iload_1
    //   204: ifeq -> 178
    //   207: aload_2
    //   208: invokevirtual toString : ()Ljava/lang/String;
    //   211: areturn
    //   212: new java/lang/String
    //   215: dup
    //   216: aload_0
    //   217: getfield b : [C
    //   220: aload_0
    //   221: getfield c : I
    //   224: aload_0
    //   225: getfield d : I
    //   228: invokespecial <init> : ([CII)V
    //   231: bipush #47
    //   233: bipush #46
    //   235: invokevirtual replace : (CC)Ljava/lang/String;
    //   238: areturn
    //   239: aconst_null
    //   240: areturn
  }
  
  public String getInternalName() {
    return new String(this.b, this.c, this.d);
  }
  
  public Type[] getArgumentTypes() {
    return getArgumentTypes(getDescriptor());
  }
  
  public Type getReturnType() {
    return getReturnType(getDescriptor());
  }
  
  public int getArgumentsAndReturnSizes() {
    return getArgumentsAndReturnSizes(getDescriptor());
  }
  
  public String getDescriptor() {
    StringBuffer stringBuffer = new StringBuffer();
    a(stringBuffer);
    return stringBuffer.toString();
  }
  
  public static String getMethodDescriptor(Type paramType, Type[] paramArrayOfType) {
    // Byte code:
    //   0: new java/lang/StringBuffer
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_3
    //   8: aload_3
    //   9: bipush #40
    //   11: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   14: pop
    //   15: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   18: iconst_0
    //   19: istore #4
    //   21: istore_2
    //   22: iload #4
    //   24: aload_1
    //   25: arraylength
    //   26: if_icmpge -> 48
    //   29: aload_1
    //   30: iload #4
    //   32: aaload
    //   33: aload_3
    //   34: invokespecial a : (Ljava/lang/StringBuffer;)V
    //   37: iinc #4, 1
    //   40: iload_2
    //   41: ifne -> 60
    //   44: iload_2
    //   45: ifeq -> 22
    //   48: aload_3
    //   49: bipush #41
    //   51: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   54: pop
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial a : (Ljava/lang/StringBuffer;)V
    //   60: aload_3
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: areturn
  }
  
  private void a(StringBuffer paramStringBuffer) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: iload_2
    //   6: ifne -> 36
    //   9: getfield b : [C
    //   12: ifnonnull -> 35
    //   15: aload_1
    //   16: aload_0
    //   17: getfield c : I
    //   20: ldc -16777216
    //   22: iand
    //   23: bipush #24
    //   25: iushr
    //   26: i2c
    //   27: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   30: pop
    //   31: iload_2
    //   32: ifeq -> 96
    //   35: aload_0
    //   36: getfield a : I
    //   39: bipush #10
    //   41: if_icmpne -> 79
    //   44: aload_1
    //   45: bipush #76
    //   47: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   50: pop
    //   51: aload_1
    //   52: aload_0
    //   53: getfield b : [C
    //   56: aload_0
    //   57: getfield c : I
    //   60: aload_0
    //   61: getfield d : I
    //   64: invokevirtual append : ([CII)Ljava/lang/StringBuffer;
    //   67: pop
    //   68: aload_1
    //   69: bipush #59
    //   71: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   74: pop
    //   75: iload_2
    //   76: ifeq -> 96
    //   79: aload_1
    //   80: aload_0
    //   81: getfield b : [C
    //   84: aload_0
    //   85: getfield c : I
    //   88: aload_0
    //   89: getfield d : I
    //   92: invokevirtual append : ([CII)Ljava/lang/StringBuffer;
    //   95: pop
    //   96: return
  }
  
  public static String getInternalName(Class paramClass) {
    return paramClass.getName().replace('.', '/');
  }
  
  public static String getDescriptor(Class paramClass) {
    StringBuffer stringBuffer = new StringBuffer();
    a(stringBuffer, paramClass);
    return stringBuffer.toString();
  }
  
  public static String getConstructorDescriptor(Constructor paramConstructor) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   4: astore_2
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: new java/lang/StringBuffer
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_3
    //   16: istore_1
    //   17: aload_3
    //   18: bipush #40
    //   20: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   23: pop
    //   24: iconst_0
    //   25: istore #4
    //   27: iload #4
    //   29: aload_2
    //   30: arraylength
    //   31: if_icmpge -> 53
    //   34: aload_3
    //   35: iload_1
    //   36: ifne -> 66
    //   39: aload_2
    //   40: iload #4
    //   42: aaload
    //   43: invokestatic a : (Ljava/lang/StringBuffer;Ljava/lang/Class;)V
    //   46: iinc #4, 1
    //   49: iload_1
    //   50: ifeq -> 27
    //   53: aload_3
    //   54: sipush #20981
    //   57: sipush #26576
    //   60: invokestatic a : (II)Ljava/lang/String;
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   66: invokevirtual toString : ()Ljava/lang/String;
    //   69: areturn
  }
  
  public static String getMethodDescriptor(Method paramMethod) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   4: astore_2
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: new java/lang/StringBuffer
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_3
    //   16: aload_3
    //   17: bipush #40
    //   19: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   22: pop
    //   23: iconst_0
    //   24: istore #4
    //   26: istore_1
    //   27: iload #4
    //   29: aload_2
    //   30: arraylength
    //   31: if_icmpge -> 53
    //   34: aload_3
    //   35: aload_2
    //   36: iload #4
    //   38: aaload
    //   39: invokestatic a : (Ljava/lang/StringBuffer;Ljava/lang/Class;)V
    //   42: iinc #4, 1
    //   45: iload_1
    //   46: ifne -> 68
    //   49: iload_1
    //   50: ifeq -> 27
    //   53: aload_3
    //   54: bipush #41
    //   56: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   59: pop
    //   60: aload_3
    //   61: aload_0
    //   62: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   65: invokestatic a : (Ljava/lang/StringBuffer;Ljava/lang/Class;)V
    //   68: aload_3
    //   69: invokevirtual toString : ()Ljava/lang/String;
    //   72: areturn
  }
  
  private static void a(StringBuffer paramStringBuffer, Class paramClass) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_1
    //   5: astore_3
    //   6: aload_3
    //   7: invokevirtual isPrimitive : ()Z
    //   10: ifeq -> 177
    //   13: aload_3
    //   14: iload_2
    //   15: ifne -> 178
    //   18: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   21: iload_2
    //   22: ifne -> 40
    //   25: if_acmpne -> 36
    //   28: bipush #73
    //   30: istore #4
    //   32: iload_2
    //   33: ifeq -> 169
    //   36: aload_3
    //   37: getstatic java/lang/Void.TYPE : Ljava/lang/Class;
    //   40: iload_2
    //   41: ifne -> 59
    //   44: if_acmpne -> 55
    //   47: bipush #86
    //   49: istore #4
    //   51: iload_2
    //   52: ifeq -> 169
    //   55: aload_3
    //   56: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   59: iload_2
    //   60: ifne -> 78
    //   63: if_acmpne -> 74
    //   66: bipush #90
    //   68: istore #4
    //   70: iload_2
    //   71: ifeq -> 169
    //   74: aload_3
    //   75: getstatic java/lang/Byte.TYPE : Ljava/lang/Class;
    //   78: iload_2
    //   79: ifne -> 97
    //   82: if_acmpne -> 93
    //   85: bipush #66
    //   87: istore #4
    //   89: iload_2
    //   90: ifeq -> 169
    //   93: aload_3
    //   94: getstatic java/lang/Character.TYPE : Ljava/lang/Class;
    //   97: iload_2
    //   98: ifne -> 116
    //   101: if_acmpne -> 112
    //   104: bipush #67
    //   106: istore #4
    //   108: iload_2
    //   109: ifeq -> 169
    //   112: aload_3
    //   113: getstatic java/lang/Short.TYPE : Ljava/lang/Class;
    //   116: iload_2
    //   117: ifne -> 135
    //   120: if_acmpne -> 131
    //   123: bipush #83
    //   125: istore #4
    //   127: iload_2
    //   128: ifeq -> 169
    //   131: aload_3
    //   132: getstatic java/lang/Double.TYPE : Ljava/lang/Class;
    //   135: iload_2
    //   136: ifne -> 154
    //   139: if_acmpne -> 150
    //   142: bipush #68
    //   144: istore #4
    //   146: iload_2
    //   147: ifeq -> 169
    //   150: aload_3
    //   151: getstatic java/lang/Float.TYPE : Ljava/lang/Class;
    //   154: if_acmpne -> 165
    //   157: bipush #70
    //   159: istore #4
    //   161: iload_2
    //   162: ifeq -> 169
    //   165: bipush #74
    //   167: istore #4
    //   169: aload_0
    //   170: iload #4
    //   172: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   175: pop
    //   176: return
    //   177: aload_3
    //   178: iload_2
    //   179: ifne -> 212
    //   182: invokevirtual isArray : ()Z
    //   185: ifeq -> 204
    //   188: aload_0
    //   189: bipush #91
    //   191: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   194: pop
    //   195: aload_3
    //   196: invokevirtual getComponentType : ()Ljava/lang/Class;
    //   199: astore_3
    //   200: iload_2
    //   201: ifeq -> 6
    //   204: aload_0
    //   205: bipush #76
    //   207: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   210: pop
    //   211: aload_3
    //   212: invokevirtual getName : ()Ljava/lang/String;
    //   215: astore #4
    //   217: aload #4
    //   219: invokevirtual length : ()I
    //   222: istore #5
    //   224: iconst_0
    //   225: istore #6
    //   227: iload #6
    //   229: iload #5
    //   231: if_icmpge -> 277
    //   234: aload #4
    //   236: iload #6
    //   238: invokevirtual charAt : (I)C
    //   241: istore #7
    //   243: aload_0
    //   244: iload #7
    //   246: iload_2
    //   247: ifne -> 280
    //   250: iload_2
    //   251: ifne -> 261
    //   254: bipush #46
    //   256: if_icmpne -> 264
    //   259: bipush #47
    //   261: goto -> 266
    //   264: iload #7
    //   266: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   269: pop
    //   270: iinc #6, 1
    //   273: iload_2
    //   274: ifeq -> 227
    //   277: aload_0
    //   278: bipush #59
    //   280: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   283: pop
    //   284: return
  }
  
  public int getSize() {
    int i = MethodVisitor.b;
    if (i == 0)
      if (this.b == null) {
      
      } else {
        return 1;
      }  
  }
  
  public int getOpcode(int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: iload_1
    //   5: iload_2
    //   6: ifne -> 25
    //   9: bipush #46
    //   11: if_icmpeq -> 24
    //   14: iload_1
    //   15: iload_2
    //   16: ifne -> 53
    //   19: bipush #79
    //   21: if_icmpne -> 52
    //   24: iload_1
    //   25: aload_0
    //   26: iload_2
    //   27: ifne -> 37
    //   30: getfield b : [C
    //   33: ifnonnull -> 49
    //   36: aload_0
    //   37: getfield c : I
    //   40: ldc 65280
    //   42: iand
    //   43: bipush #8
    //   45: ishr
    //   46: goto -> 50
    //   49: iconst_4
    //   50: iadd
    //   51: ireturn
    //   52: iload_1
    //   53: aload_0
    //   54: iload_2
    //   55: ifne -> 65
    //   58: getfield b : [C
    //   61: ifnonnull -> 77
    //   64: aload_0
    //   65: getfield c : I
    //   68: ldc 16711680
    //   70: iand
    //   71: bipush #16
    //   73: ishr
    //   74: goto -> 78
    //   77: iconst_4
    //   78: iadd
    //   79: ireturn
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: iload_2
    //   6: ifne -> 16
    //   9: aload_1
    //   10: if_acmpne -> 15
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_1
    //   16: iload_2
    //   17: ifne -> 29
    //   20: instanceof org/objectweb/asm/Type
    //   23: ifne -> 28
    //   26: iconst_0
    //   27: ireturn
    //   28: aload_1
    //   29: checkcast org/objectweb/asm/Type
    //   32: astore_3
    //   33: aload_0
    //   34: getfield a : I
    //   37: aload_3
    //   38: getfield a : I
    //   41: iload_2
    //   42: ifne -> 60
    //   45: if_icmpeq -> 50
    //   48: iconst_0
    //   49: ireturn
    //   50: aload_0
    //   51: getfield a : I
    //   54: iload_2
    //   55: ifne -> 146
    //   58: bipush #9
    //   60: if_icmplt -> 145
    //   63: aload_0
    //   64: getfield d : I
    //   67: iload_2
    //   68: ifne -> 84
    //   71: aload_3
    //   72: getfield d : I
    //   75: if_icmpeq -> 80
    //   78: iconst_0
    //   79: ireturn
    //   80: aload_0
    //   81: getfield c : I
    //   84: istore #4
    //   86: aload_3
    //   87: getfield c : I
    //   90: istore #5
    //   92: iload #4
    //   94: aload_0
    //   95: getfield d : I
    //   98: iadd
    //   99: istore #6
    //   101: iload #4
    //   103: iload #6
    //   105: if_icmpge -> 145
    //   108: aload_0
    //   109: getfield b : [C
    //   112: iload #4
    //   114: caload
    //   115: iload_2
    //   116: ifne -> 146
    //   119: iload_2
    //   120: ifne -> 134
    //   123: aload_3
    //   124: getfield b : [C
    //   127: iload #5
    //   129: caload
    //   130: if_icmpeq -> 135
    //   133: iconst_0
    //   134: ireturn
    //   135: iinc #4, 1
    //   138: iinc #5, 1
    //   141: iload_2
    //   142: ifeq -> 101
    //   145: iconst_1
    //   146: ireturn
  }
  
  public int hashCode() {
    int i = MethodVisitor.b;
    int j = 13 * this.a;
    if (i == 0)
      if (this.a >= 9) {
        int k = this.c;
        int m = k + this.d;
        while (k < m) {
          if (i == 0) {
            j = 17 * (j + this.b[k]);
            k++;
            if (i != 0)
              break; 
            continue;
          } 
          // Byte code: goto -> 68
        } 
      }  
    return j;
  }
  
  public String toString() {
    return getDescriptor();
  }
  
  static {
    // Byte code:
    //   0: bipush #11
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc '¶ê¾\\nxÈ2¡ÊÀqÈ'ÓÚóù»ñ0°ýN0hÅ­'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: iconst_4
    //   19: istore_1
    //   20: iconst_m1
    //   21: istore_0
    //   22: iinc #0, 1
    //   25: aload_2
    //   26: iload_0
    //   27: dup
    //   28: iload_1
    //   29: iadd
    //   30: invokevirtual substring : (II)Ljava/lang/String;
    //   33: jsr -> 135
    //   36: aload #5
    //   38: swap
    //   39: iload_3
    //   40: iinc #3, 1
    //   43: swap
    //   44: aastore
    //   45: iload_0
    //   46: iload_1
    //   47: iadd
    //   48: dup
    //   49: istore_0
    //   50: iload #4
    //   52: if_icmpge -> 64
    //   55: aload_2
    //   56: iload_0
    //   57: invokevirtual charAt : (I)C
    //   60: istore_1
    //   61: goto -> 22
    //   64: ldc '»óée7­¿í'
    //   66: dup
    //   67: astore_2
    //   68: invokevirtual length : ()I
    //   71: istore #4
    //   73: iconst_4
    //   74: istore_1
    //   75: iconst_m1
    //   76: istore_0
    //   77: iinc #0, 1
    //   80: aload_2
    //   81: iload_0
    //   82: dup
    //   83: iload_1
    //   84: iadd
    //   85: invokevirtual substring : (II)Ljava/lang/String;
    //   88: jsr -> 135
    //   91: aload #5
    //   93: swap
    //   94: iload_3
    //   95: iinc #3, 1
    //   98: swap
    //   99: aastore
    //   100: iload_0
    //   101: iload_1
    //   102: iadd
    //   103: dup
    //   104: istore_0
    //   105: iload #4
    //   107: if_icmpge -> 119
    //   110: aload_2
    //   111: iload_0
    //   112: invokevirtual charAt : (I)C
    //   115: istore_1
    //   116: goto -> 77
    //   119: aload #5
    //   121: putstatic org/objectweb/asm/Type.e : [Ljava/lang/String;
    //   124: bipush #11
    //   126: anewarray java/lang/String
    //   129: putstatic org/objectweb/asm/Type.f : [Ljava/lang/String;
    //   132: goto -> 273
    //   135: astore #6
    //   137: invokevirtual toCharArray : ()[C
    //   140: dup
    //   141: arraylength
    //   142: swap
    //   143: iconst_0
    //   144: istore #7
    //   146: swap
    //   147: dup_x1
    //   148: iconst_1
    //   149: if_icmpgt -> 251
    //   152: dup
    //   153: iload #7
    //   155: dup2
    //   156: caload
    //   157: iload #7
    //   159: bipush #7
    //   161: irem
    //   162: tableswitch default -> 233, 0 -> 200, 1 -> 206, 2 -> 211, 3 -> 216, 4 -> 222, 5 -> 227
    //   200: sipush #159
    //   203: goto -> 235
    //   206: bipush #35
    //   208: goto -> 235
    //   211: bipush #55
    //   213: goto -> 235
    //   216: sipush #189
    //   219: goto -> 235
    //   222: bipush #72
    //   224: goto -> 235
    //   227: sipush #193
    //   230: goto -> 235
    //   233: bipush #6
    //   235: ixor
    //   236: i2c
    //   237: castore
    //   238: iinc #7, 1
    //   241: swap
    //   242: dup_x1
    //   243: ifne -> 251
    //   246: dup2
    //   247: swap
    //   248: goto -> 155
    //   251: swap
    //   252: dup_x1
    //   253: iload #7
    //   255: if_icmpgt -> 152
    //   258: new java/lang/String
    //   261: dup_x1
    //   262: swap
    //   263: invokespecial <init> : ([C)V
    //   266: invokevirtual intern : ()Ljava/lang/String;
    //   269: swap
    //   270: pop
    //   271: ret #6
    //   273: invokestatic _clinit_ : ()V
    //   276: new org/objectweb/asm/Type
    //   279: dup
    //   280: iconst_0
    //   281: aconst_null
    //   282: ldc 1443168256
    //   284: iconst_1
    //   285: invokespecial <init> : (I[CII)V
    //   288: putstatic org/objectweb/asm/Type.VOID_TYPE : Lorg/objectweb/asm/Type;
    //   291: new org/objectweb/asm/Type
    //   294: dup
    //   295: iconst_1
    //   296: aconst_null
    //   297: ldc 1509950721
    //   299: iconst_1
    //   300: invokespecial <init> : (I[CII)V
    //   303: putstatic org/objectweb/asm/Type.BOOLEAN_TYPE : Lorg/objectweb/asm/Type;
    //   306: new org/objectweb/asm/Type
    //   309: dup
    //   310: iconst_2
    //   311: aconst_null
    //   312: ldc 1124075009
    //   314: iconst_1
    //   315: invokespecial <init> : (I[CII)V
    //   318: putstatic org/objectweb/asm/Type.CHAR_TYPE : Lorg/objectweb/asm/Type;
    //   321: new org/objectweb/asm/Type
    //   324: dup
    //   325: iconst_3
    //   326: aconst_null
    //   327: ldc 1107297537
    //   329: iconst_1
    //   330: invokespecial <init> : (I[CII)V
    //   333: putstatic org/objectweb/asm/Type.BYTE_TYPE : Lorg/objectweb/asm/Type;
    //   336: new org/objectweb/asm/Type
    //   339: dup
    //   340: iconst_4
    //   341: aconst_null
    //   342: ldc 1392510721
    //   344: iconst_1
    //   345: invokespecial <init> : (I[CII)V
    //   348: putstatic org/objectweb/asm/Type.SHORT_TYPE : Lorg/objectweb/asm/Type;
    //   351: new org/objectweb/asm/Type
    //   354: dup
    //   355: iconst_5
    //   356: aconst_null
    //   357: ldc 1224736769
    //   359: iconst_1
    //   360: invokespecial <init> : (I[CII)V
    //   363: putstatic org/objectweb/asm/Type.INT_TYPE : Lorg/objectweb/asm/Type;
    //   366: new org/objectweb/asm/Type
    //   369: dup
    //   370: bipush #6
    //   372: aconst_null
    //   373: ldc 1174536705
    //   375: iconst_1
    //   376: invokespecial <init> : (I[CII)V
    //   379: putstatic org/objectweb/asm/Type.FLOAT_TYPE : Lorg/objectweb/asm/Type;
    //   382: new org/objectweb/asm/Type
    //   385: dup
    //   386: bipush #7
    //   388: aconst_null
    //   389: ldc 1241579778
    //   391: iconst_1
    //   392: invokespecial <init> : (I[CII)V
    //   395: putstatic org/objectweb/asm/Type.LONG_TYPE : Lorg/objectweb/asm/Type;
    //   398: new org/objectweb/asm/Type
    //   401: dup
    //   402: bipush #8
    //   404: aconst_null
    //   405: ldc 1141048066
    //   407: iconst_1
    //   408: invokespecial <init> : (I[CII)V
    //   411: putstatic org/objectweb/asm/Type.DOUBLE_TYPE : Lorg/objectweb/asm/Type;
    //   414: return
  }
  
  static void _clinit_() {}
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0x51F2) & 0xFFFF;
    if (f[i] == null) {
      char[] arrayOfChar = e[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 92;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      f[i] = (new String(arrayOfChar)).intern();
    } 
    return f[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Type.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */