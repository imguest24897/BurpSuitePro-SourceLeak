package org.objectweb.asm;

class Context {
  Attribute[] a;
  
  int b;
  
  char[] c;
  
  int[] d;
  
  int e;
  
  String f;
  
  String g;
  
  Label[] h;
  
  int i;
  
  TypePath j;
  
  int o;
  
  Label[] l;
  
  Label[] m;
  
  int[] n;
  
  int p;
  
  int q;
  
  int r;
  
  Object[] s;
  
  int t;
  
  Object[] u;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Context.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */