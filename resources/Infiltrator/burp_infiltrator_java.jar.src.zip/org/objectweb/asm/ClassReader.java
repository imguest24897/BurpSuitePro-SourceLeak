package org.objectweb.asm;

import java.io.InputStream;

public class ClassReader {
  public static final int SKIP_CODE = 1;
  
  public static final int SKIP_DEBUG = 2;
  
  public static final int SKIP_FRAMES = 4;
  
  public static final int EXPAND_FRAMES = 8;
  
  public final byte[] b;
  
  private final int[] a;
  
  private final String[] c;
  
  private final int d;
  
  public final int header;
  
  private static final String[] e;
  
  private static final String[] f;
  
  public ClassReader(byte[] paramArrayOfbyte) {
    this(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public ClassReader(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   7: aload_0
    //   8: aload_1
    //   9: putfield b : [B
    //   12: istore #4
    //   14: aload_0
    //   15: iload_2
    //   16: bipush #6
    //   18: iadd
    //   19: invokevirtual readShort : (I)S
    //   22: iload #4
    //   24: ifne -> 64
    //   27: bipush #52
    //   29: if_icmple -> 45
    //   32: goto -> 36
    //   35: athrow
    //   36: new java/lang/IllegalArgumentException
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: athrow
    //   44: athrow
    //   45: aload_0
    //   46: aload_0
    //   47: iload_2
    //   48: bipush #8
    //   50: iadd
    //   51: invokevirtual readUnsignedShort : (I)I
    //   54: newarray int
    //   56: putfield a : [I
    //   59: aload_0
    //   60: getfield a : [I
    //   63: arraylength
    //   64: istore #5
    //   66: aload_0
    //   67: iload #5
    //   69: anewarray java/lang/String
    //   72: putfield c : [Ljava/lang/String;
    //   75: iconst_0
    //   76: istore #6
    //   78: iload_2
    //   79: bipush #10
    //   81: iadd
    //   82: istore #7
    //   84: iconst_1
    //   85: istore #8
    //   87: iload #8
    //   89: iload #5
    //   91: if_icmpge -> 296
    //   94: aload_0
    //   95: getfield a : [I
    //   98: iload #8
    //   100: iload #7
    //   102: iconst_1
    //   103: iadd
    //   104: iastore
    //   105: iload #4
    //   107: ifne -> 308
    //   110: aload_1
    //   111: iload #7
    //   113: baload
    //   114: iload #4
    //   116: ifne -> 279
    //   119: goto -> 123
    //   122: athrow
    //   123: tableswitch default -> 274, 1 -> 229, 2 -> 274, 3 -> 209, 4 -> 209, 5 -> 217, 6 -> 217, 7 -> 274, 8 -> 274, 9 -> 209, 10 -> 209, 11 -> 209, 12 -> 209, 13 -> 274, 14 -> 274, 15 -> 266, 16 -> 274, 17 -> 274, 18 -> 209
    //   208: athrow
    //   209: iconst_5
    //   210: istore #9
    //   212: iload #4
    //   214: ifeq -> 281
    //   217: bipush #9
    //   219: istore #9
    //   221: iinc #8, 1
    //   224: iload #4
    //   226: ifeq -> 281
    //   229: iconst_3
    //   230: aload_0
    //   231: iload #7
    //   233: iconst_1
    //   234: iadd
    //   235: invokevirtual readUnsignedShort : (I)I
    //   238: iadd
    //   239: istore #9
    //   241: iload #9
    //   243: iload #6
    //   245: iload #4
    //   247: ifne -> 285
    //   250: if_icmple -> 281
    //   253: goto -> 257
    //   256: athrow
    //   257: iload #9
    //   259: istore #6
    //   261: iload #4
    //   263: ifeq -> 281
    //   266: iconst_4
    //   267: istore #9
    //   269: iload #4
    //   271: ifeq -> 281
    //   274: iconst_3
    //   275: goto -> 279
    //   278: athrow
    //   279: istore #9
    //   281: iload #7
    //   283: iload #9
    //   285: iadd
    //   286: istore #7
    //   288: iinc #8, 1
    //   291: iload #4
    //   293: ifeq -> 87
    //   296: aload_0
    //   297: iload #6
    //   299: putfield d : I
    //   302: aload_0
    //   303: iload #7
    //   305: putfield header : I
    //   308: return
    // Exception table:
    //   from	to	target	type
    //   14	32	35	java/lang/IllegalArgumentException
    //   27	44	44	java/lang/IllegalArgumentException
    //   94	119	122	java/lang/IllegalArgumentException
    //   110	208	208	java/lang/IllegalArgumentException
    //   241	253	256	java/lang/IllegalArgumentException
    //   269	275	278	java/lang/IllegalArgumentException
  }
  
  public int getAccess() {
    return readUnsignedShort(this.header);
  }
  
  public String getClassName() {
    return readClass(this.header + 2, new char[this.d]);
  }
  
  public String getSuperName() {
    return readClass(this.header + 4, new char[this.d]);
  }
  
  public String[] getInterfaces() {
    // Byte code:
    //   0: aload_0
    //   1: getfield header : I
    //   4: bipush #6
    //   6: iadd
    //   7: istore_2
    //   8: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   11: aload_0
    //   12: iload_2
    //   13: invokevirtual readUnsignedShort : (I)I
    //   16: istore_3
    //   17: istore_1
    //   18: iload_3
    //   19: anewarray java/lang/String
    //   22: astore #4
    //   24: iload_3
    //   25: iload_1
    //   26: ifne -> 44
    //   29: ifle -> 87
    //   32: goto -> 36
    //   35: athrow
    //   36: aload_0
    //   37: getfield d : I
    //   40: goto -> 44
    //   43: athrow
    //   44: newarray char
    //   46: astore #5
    //   48: iconst_0
    //   49: istore #6
    //   51: iload #6
    //   53: iload_3
    //   54: if_icmpge -> 87
    //   57: iinc #2, 2
    //   60: aload #4
    //   62: iload_1
    //   63: ifne -> 89
    //   66: iload #6
    //   68: aload_0
    //   69: iload_2
    //   70: aload #5
    //   72: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   75: aastore
    //   76: iinc #6, 1
    //   79: iload_1
    //   80: ifeq -> 51
    //   83: goto -> 87
    //   86: athrow
    //   87: aload #4
    //   89: areturn
    // Exception table:
    //   from	to	target	type
    //   24	32	35	java/lang/IllegalArgumentException
    //   29	40	43	java/lang/IllegalArgumentException
    //   57	83	86	java/lang/IllegalArgumentException
  }
  
  void a(ClassWriter paramClassWriter) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : I
    //   4: newarray char
    //   6: astore_3
    //   7: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   10: aload_0
    //   11: getfield a : [I
    //   14: arraylength
    //   15: istore #4
    //   17: iload #4
    //   19: anewarray org/objectweb/asm/Item
    //   22: astore #5
    //   24: iconst_1
    //   25: istore #6
    //   27: istore_2
    //   28: iload #6
    //   30: iload #4
    //   32: if_icmpge -> 608
    //   35: aload_0
    //   36: getfield a : [I
    //   39: iload #6
    //   41: iaload
    //   42: istore #7
    //   44: aload_0
    //   45: getfield b : [B
    //   48: iload #7
    //   50: iconst_1
    //   51: isub
    //   52: baload
    //   53: istore #8
    //   55: new org/objectweb/asm/Item
    //   58: dup
    //   59: iload #6
    //   61: invokespecial <init> : (I)V
    //   64: astore #9
    //   66: iload #8
    //   68: iload_2
    //   69: ifne -> 616
    //   72: iload_2
    //   73: ifne -> 186
    //   76: goto -> 80
    //   79: athrow
    //   80: tableswitch default -> 553, 1 -> 342, 2 -> 553, 3 -> 222, 4 -> 241, 5 -> 295, 6 -> 317, 7 -> 553, 8 -> 553, 9 -> 169, 10 -> 169, 11 -> 169, 12 -> 263, 13 -> 553, 14 -> 553, 15 -> 413, 16 -> 553, 17 -> 553, 18 -> 484
    //   168: athrow
    //   169: aload_0
    //   170: getfield a : [I
    //   173: aload_0
    //   174: iload #7
    //   176: iconst_2
    //   177: iadd
    //   178: invokevirtual readUnsignedShort : (I)I
    //   181: iaload
    //   182: goto -> 186
    //   185: athrow
    //   186: istore #10
    //   188: aload #9
    //   190: iload #8
    //   192: aload_0
    //   193: iload #7
    //   195: aload_3
    //   196: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   199: aload_0
    //   200: iload #10
    //   202: aload_3
    //   203: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   206: aload_0
    //   207: iload #10
    //   209: iconst_2
    //   210: iadd
    //   211: aload_3
    //   212: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   215: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   218: iload_2
    //   219: ifeq -> 573
    //   222: aload #9
    //   224: aload_0
    //   225: iload #7
    //   227: invokevirtual readInt : (I)I
    //   230: invokevirtual a : (I)V
    //   233: iload_2
    //   234: ifeq -> 573
    //   237: goto -> 241
    //   240: athrow
    //   241: aload #9
    //   243: aload_0
    //   244: iload #7
    //   246: invokevirtual readInt : (I)I
    //   249: invokestatic intBitsToFloat : (I)F
    //   252: invokevirtual a : (F)V
    //   255: iload_2
    //   256: ifeq -> 573
    //   259: goto -> 263
    //   262: athrow
    //   263: aload #9
    //   265: iload #8
    //   267: aload_0
    //   268: iload #7
    //   270: aload_3
    //   271: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   274: aload_0
    //   275: iload #7
    //   277: iconst_2
    //   278: iadd
    //   279: aload_3
    //   280: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   283: aconst_null
    //   284: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   287: iload_2
    //   288: ifeq -> 573
    //   291: goto -> 295
    //   294: athrow
    //   295: aload #9
    //   297: aload_0
    //   298: iload #7
    //   300: invokevirtual readLong : (I)J
    //   303: invokevirtual a : (J)V
    //   306: iinc #6, 1
    //   309: iload_2
    //   310: ifeq -> 573
    //   313: goto -> 317
    //   316: athrow
    //   317: aload #9
    //   319: aload_0
    //   320: iload #7
    //   322: invokevirtual readLong : (I)J
    //   325: invokestatic longBitsToDouble : (J)D
    //   328: invokevirtual a : (D)V
    //   331: iinc #6, 1
    //   334: iload_2
    //   335: ifeq -> 573
    //   338: goto -> 342
    //   341: athrow
    //   342: aload_0
    //   343: getfield c : [Ljava/lang/String;
    //   346: iload #6
    //   348: aaload
    //   349: astore #11
    //   351: iload_2
    //   352: ifne -> 409
    //   355: aload #11
    //   357: ifnonnull -> 398
    //   360: goto -> 364
    //   363: athrow
    //   364: aload_0
    //   365: getfield a : [I
    //   368: iload #6
    //   370: iaload
    //   371: istore #7
    //   373: aload_0
    //   374: getfield c : [Ljava/lang/String;
    //   377: iload #6
    //   379: aload_0
    //   380: iload #7
    //   382: iconst_2
    //   383: iadd
    //   384: aload_0
    //   385: iload #7
    //   387: invokevirtual readUnsignedShort : (I)I
    //   390: aload_3
    //   391: invokespecial a : (II[C)Ljava/lang/String;
    //   394: dup_x2
    //   395: aastore
    //   396: astore #11
    //   398: aload #9
    //   400: iload #8
    //   402: aload #11
    //   404: aconst_null
    //   405: aconst_null
    //   406: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   409: iload_2
    //   410: ifeq -> 573
    //   413: aload_0
    //   414: getfield a : [I
    //   417: aload_0
    //   418: iload #7
    //   420: iconst_1
    //   421: iadd
    //   422: invokevirtual readUnsignedShort : (I)I
    //   425: iaload
    //   426: istore #11
    //   428: aload_0
    //   429: getfield a : [I
    //   432: aload_0
    //   433: iload #11
    //   435: iconst_2
    //   436: iadd
    //   437: invokevirtual readUnsignedShort : (I)I
    //   440: iaload
    //   441: istore #10
    //   443: aload #9
    //   445: bipush #20
    //   447: aload_0
    //   448: iload #7
    //   450: invokevirtual readByte : (I)I
    //   453: iadd
    //   454: aload_0
    //   455: iload #11
    //   457: aload_3
    //   458: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   461: aload_0
    //   462: iload #10
    //   464: aload_3
    //   465: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   468: aload_0
    //   469: iload #10
    //   471: iconst_2
    //   472: iadd
    //   473: aload_3
    //   474: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   477: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   480: iload_2
    //   481: ifeq -> 573
    //   484: aload_1
    //   485: getfield A : Lorg/objectweb/asm/ByteVector;
    //   488: ifnonnull -> 507
    //   491: goto -> 495
    //   494: athrow
    //   495: aload_0
    //   496: aload_1
    //   497: aload #5
    //   499: aload_3
    //   500: invokespecial a : (Lorg/objectweb/asm/ClassWriter;[Lorg/objectweb/asm/Item;[C)V
    //   503: goto -> 507
    //   506: athrow
    //   507: aload_0
    //   508: getfield a : [I
    //   511: aload_0
    //   512: iload #7
    //   514: iconst_2
    //   515: iadd
    //   516: invokevirtual readUnsignedShort : (I)I
    //   519: iaload
    //   520: istore #10
    //   522: aload #9
    //   524: aload_0
    //   525: iload #10
    //   527: aload_3
    //   528: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   531: aload_0
    //   532: iload #10
    //   534: iconst_2
    //   535: iadd
    //   536: aload_3
    //   537: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   540: aload_0
    //   541: iload #7
    //   543: invokevirtual readUnsignedShort : (I)I
    //   546: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;I)V
    //   549: iload_2
    //   550: ifeq -> 573
    //   553: aload #9
    //   555: iload #8
    //   557: aload_0
    //   558: iload #7
    //   560: aload_3
    //   561: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   564: aconst_null
    //   565: aconst_null
    //   566: invokevirtual a : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   569: goto -> 573
    //   572: athrow
    //   573: aload #9
    //   575: getfield j : I
    //   578: aload #5
    //   580: arraylength
    //   581: irem
    //   582: istore #11
    //   584: aload #9
    //   586: aload #5
    //   588: iload #11
    //   590: aaload
    //   591: putfield k : Lorg/objectweb/asm/Item;
    //   594: aload #5
    //   596: iload #11
    //   598: aload #9
    //   600: aastore
    //   601: iinc #6, 1
    //   604: iload_2
    //   605: ifeq -> 28
    //   608: aload_0
    //   609: getfield a : [I
    //   612: iconst_1
    //   613: iaload
    //   614: iconst_1
    //   615: isub
    //   616: istore #6
    //   618: aload_1
    //   619: getfield d : Lorg/objectweb/asm/ByteVector;
    //   622: aload_0
    //   623: getfield b : [B
    //   626: iload #6
    //   628: aload_0
    //   629: getfield header : I
    //   632: iload #6
    //   634: isub
    //   635: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   638: pop
    //   639: aload_1
    //   640: aload #5
    //   642: putfield e : [Lorg/objectweb/asm/Item;
    //   645: aload_1
    //   646: ldc2_w 0.75
    //   649: iload #4
    //   651: i2d
    //   652: dmul
    //   653: d2i
    //   654: putfield f : I
    //   657: aload_1
    //   658: iload #4
    //   660: putfield c : I
    //   663: return
    // Exception table:
    //   from	to	target	type
    //   66	76	79	java/lang/IllegalArgumentException
    //   72	168	168	java/lang/IllegalArgumentException
    //   80	182	185	java/lang/IllegalArgumentException
    //   188	237	240	java/lang/IllegalArgumentException
    //   222	259	262	java/lang/IllegalArgumentException
    //   241	291	294	java/lang/IllegalArgumentException
    //   263	313	316	java/lang/IllegalArgumentException
    //   295	338	341	java/lang/IllegalArgumentException
    //   351	360	363	java/lang/IllegalArgumentException
    //   443	491	494	java/lang/IllegalArgumentException
    //   484	503	506	java/lang/IllegalArgumentException
    //   522	569	572	java/lang/IllegalArgumentException
  }
  
  private void a(ClassWriter paramClassWriter, Item[] paramArrayOfItem, char[] paramArrayOfchar) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial a : ()I
    //   4: istore #5
    //   6: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   9: iconst_0
    //   10: istore #6
    //   12: istore #4
    //   14: aload_0
    //   15: iload #5
    //   17: invokevirtual readUnsignedShort : (I)I
    //   20: istore #7
    //   22: iload #7
    //   24: ifle -> 109
    //   27: aload_0
    //   28: iload #5
    //   30: iconst_2
    //   31: iadd
    //   32: aload_3
    //   33: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   36: astore #8
    //   38: sipush #29974
    //   41: sipush #18414
    //   44: invokestatic a : (II)Ljava/lang/String;
    //   47: aload #8
    //   49: invokevirtual equals : (Ljava/lang/Object;)Z
    //   52: iload #4
    //   54: ifne -> 111
    //   57: iload #4
    //   59: ifne -> 99
    //   62: goto -> 66
    //   65: athrow
    //   66: ifeq -> 81
    //   69: goto -> 73
    //   72: athrow
    //   73: iconst_1
    //   74: istore #6
    //   76: iload #4
    //   78: ifeq -> 109
    //   81: iload #5
    //   83: bipush #6
    //   85: aload_0
    //   86: iload #5
    //   88: iconst_4
    //   89: iadd
    //   90: invokevirtual readInt : (I)I
    //   93: iadd
    //   94: iadd
    //   95: goto -> 99
    //   98: athrow
    //   99: istore #5
    //   101: iinc #7, -1
    //   104: iload #4
    //   106: ifeq -> 22
    //   109: iload #6
    //   111: iload #4
    //   113: ifne -> 136
    //   116: ifne -> 124
    //   119: goto -> 123
    //   122: athrow
    //   123: return
    //   124: aload_0
    //   125: iload #5
    //   127: bipush #8
    //   129: iadd
    //   130: invokevirtual readUnsignedShort : (I)I
    //   133: istore #7
    //   135: iconst_0
    //   136: istore #8
    //   138: iload #5
    //   140: bipush #10
    //   142: iadd
    //   143: istore #9
    //   145: iload #8
    //   147: iload #7
    //   149: if_icmpge -> 298
    //   152: iload #9
    //   154: iload #5
    //   156: isub
    //   157: bipush #10
    //   159: isub
    //   160: istore #10
    //   162: aload_0
    //   163: aload_0
    //   164: iload #9
    //   166: invokevirtual readUnsignedShort : (I)I
    //   169: aload_3
    //   170: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   173: invokevirtual hashCode : ()I
    //   176: istore #11
    //   178: aload_0
    //   179: iload #9
    //   181: iconst_2
    //   182: iadd
    //   183: invokevirtual readUnsignedShort : (I)I
    //   186: iload #4
    //   188: ifne -> 306
    //   191: istore #12
    //   193: iload #12
    //   195: ifle -> 239
    //   198: iload #11
    //   200: aload_0
    //   201: aload_0
    //   202: iload #9
    //   204: iconst_4
    //   205: iadd
    //   206: invokevirtual readUnsignedShort : (I)I
    //   209: aload_3
    //   210: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   213: invokevirtual hashCode : ()I
    //   216: ixor
    //   217: istore #11
    //   219: iinc #9, 2
    //   222: iinc #12, -1
    //   225: iload #4
    //   227: ifne -> 242
    //   230: iload #4
    //   232: ifeq -> 193
    //   235: goto -> 239
    //   238: athrow
    //   239: iinc #9, 4
    //   242: new org/objectweb/asm/Item
    //   245: dup
    //   246: iload #8
    //   248: invokespecial <init> : (I)V
    //   251: astore #12
    //   253: aload #12
    //   255: iload #10
    //   257: iload #11
    //   259: ldc 2147483647
    //   261: iand
    //   262: invokevirtual a : (II)V
    //   265: aload #12
    //   267: getfield j : I
    //   270: aload_2
    //   271: arraylength
    //   272: irem
    //   273: istore #13
    //   275: aload #12
    //   277: aload_2
    //   278: iload #13
    //   280: aaload
    //   281: putfield k : Lorg/objectweb/asm/Item;
    //   284: aload_2
    //   285: iload #13
    //   287: aload #12
    //   289: aastore
    //   290: iinc #8, 1
    //   293: iload #4
    //   295: ifeq -> 145
    //   298: aload_0
    //   299: iload #5
    //   301: iconst_4
    //   302: iadd
    //   303: invokevirtual readInt : (I)I
    //   306: istore #8
    //   308: new org/objectweb/asm/ByteVector
    //   311: dup
    //   312: iload #8
    //   314: bipush #62
    //   316: iadd
    //   317: invokespecial <init> : (I)V
    //   320: astore #9
    //   322: aload #9
    //   324: aload_0
    //   325: getfield b : [B
    //   328: iload #5
    //   330: bipush #10
    //   332: iadd
    //   333: iload #8
    //   335: iconst_2
    //   336: isub
    //   337: invokevirtual putByteArray : ([BII)Lorg/objectweb/asm/ByteVector;
    //   340: pop
    //   341: aload_1
    //   342: iload #7
    //   344: putfield z : I
    //   347: aload_1
    //   348: aload #9
    //   350: putfield A : Lorg/objectweb/asm/ByteVector;
    //   353: return
    // Exception table:
    //   from	to	target	type
    //   38	62	65	java/lang/IllegalArgumentException
    //   57	69	72	java/lang/IllegalArgumentException
    //   76	95	98	java/lang/IllegalArgumentException
    //   111	119	122	java/lang/IllegalArgumentException
    //   219	235	238	java/lang/IllegalArgumentException
  }
  
  public ClassReader(InputStream paramInputStream) {
    this(a(paramInputStream, false));
  }
  
  public ClassReader(String paramString) {
    this(a(ClassLoader.getSystemResourceAsStream(paramString.replace('.', '/') + a(29972, 9120)), true));
  }
  
  private static byte[] a(InputStream paramInputStream, boolean paramBoolean) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_2
    //   4: aload_0
    //   5: iload_2
    //   6: ifne -> 35
    //   9: ifnonnull -> 34
    //   12: goto -> 16
    //   15: athrow
    //   16: new java/io/IOException
    //   19: dup
    //   20: sipush #29963
    //   23: sipush #13637
    //   26: invokestatic a : (II)Ljava/lang/String;
    //   29: invokespecial <init> : (Ljava/lang/String;)V
    //   32: athrow
    //   33: athrow
    //   34: aload_0
    //   35: invokevirtual available : ()I
    //   38: newarray byte
    //   40: astore_3
    //   41: iconst_0
    //   42: istore #4
    //   44: aload_0
    //   45: aload_3
    //   46: iload #4
    //   48: aload_3
    //   49: arraylength
    //   50: iload #4
    //   52: isub
    //   53: invokevirtual read : ([BII)I
    //   56: istore #5
    //   58: iload #5
    //   60: iconst_m1
    //   61: if_icmpne -> 128
    //   64: iload #4
    //   66: iload_2
    //   67: ifne -> 93
    //   70: goto -> 74
    //   73: athrow
    //   74: aload_3
    //   75: arraylength
    //   76: iload_2
    //   77: ifne -> 147
    //   80: goto -> 84
    //   83: athrow
    //   84: if_icmpge -> 110
    //   87: goto -> 91
    //   90: athrow
    //   91: iload #4
    //   93: newarray byte
    //   95: astore #6
    //   97: aload_3
    //   98: iconst_0
    //   99: aload #6
    //   101: iconst_0
    //   102: iload #4
    //   104: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   107: aload #6
    //   109: astore_3
    //   110: aload_3
    //   111: astore #6
    //   113: iload_1
    //   114: ifeq -> 125
    //   117: aload_0
    //   118: invokevirtual close : ()V
    //   121: goto -> 125
    //   124: athrow
    //   125: aload #6
    //   127: areturn
    //   128: iload #4
    //   130: iload #5
    //   132: iadd
    //   133: istore #4
    //   135: iload #4
    //   137: iload_2
    //   138: ifne -> 158
    //   141: aload_3
    //   142: arraylength
    //   143: goto -> 147
    //   146: athrow
    //   147: if_icmpne -> 225
    //   150: aload_0
    //   151: invokevirtual read : ()I
    //   154: goto -> 158
    //   157: athrow
    //   158: istore #6
    //   160: iload #6
    //   162: iload_2
    //   163: ifne -> 197
    //   166: ifge -> 191
    //   169: goto -> 173
    //   172: athrow
    //   173: aload_3
    //   174: astore #7
    //   176: iload_1
    //   177: ifeq -> 188
    //   180: aload_0
    //   181: invokevirtual close : ()V
    //   184: goto -> 188
    //   187: athrow
    //   188: aload #7
    //   190: areturn
    //   191: aload_3
    //   192: arraylength
    //   193: sipush #1000
    //   196: iadd
    //   197: newarray byte
    //   199: astore #7
    //   201: aload_3
    //   202: iconst_0
    //   203: aload #7
    //   205: iconst_0
    //   206: iload #4
    //   208: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   211: aload #7
    //   213: iload #4
    //   215: iinc #4, 1
    //   218: iload #6
    //   220: i2b
    //   221: bastore
    //   222: aload #7
    //   224: astore_3
    //   225: goto -> 44
    //   228: astore #8
    //   230: iload_1
    //   231: ifeq -> 242
    //   234: aload_0
    //   235: invokevirtual close : ()V
    //   238: goto -> 242
    //   241: athrow
    //   242: aload #8
    //   244: athrow
    // Exception table:
    //   from	to	target	type
    //   4	12	15	java/lang/IllegalArgumentException
    //   9	33	33	java/lang/IllegalArgumentException
    //   34	113	228	finally
    //   58	70	73	java/lang/IllegalArgumentException
    //   64	80	83	java/lang/IllegalArgumentException
    //   74	87	90	java/lang/IllegalArgumentException
    //   113	121	124	java/lang/IllegalArgumentException
    //   128	176	228	finally
    //   135	143	146	java/lang/IllegalArgumentException
    //   147	154	157	java/lang/IllegalArgumentException
    //   160	169	172	java/lang/IllegalArgumentException
    //   176	184	187	java/lang/IllegalArgumentException
    //   191	230	228	finally
    //   230	238	241	java/lang/IllegalArgumentException
  }
  
  public void accept(ClassVisitor paramClassVisitor, int paramInt) {
    accept(paramClassVisitor, new Attribute[0], paramInt);
  }
  
  public void accept(ClassVisitor paramClassVisitor, Attribute[] paramArrayOfAttribute, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield header : I
    //   4: istore #5
    //   6: aload_0
    //   7: getfield d : I
    //   10: newarray char
    //   12: astore #6
    //   14: new org/objectweb/asm/Context
    //   17: dup
    //   18: invokespecial <init> : ()V
    //   21: astore #7
    //   23: aload #7
    //   25: aload_2
    //   26: putfield a : [Lorg/objectweb/asm/Attribute;
    //   29: aload #7
    //   31: iload_3
    //   32: putfield b : I
    //   35: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   38: aload #7
    //   40: aload #6
    //   42: putfield c : [C
    //   45: aload_0
    //   46: iload #5
    //   48: invokevirtual readUnsignedShort : (I)I
    //   51: istore #8
    //   53: aload_0
    //   54: iload #5
    //   56: iconst_2
    //   57: iadd
    //   58: aload #6
    //   60: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   63: astore #9
    //   65: istore #4
    //   67: aload_0
    //   68: iload #5
    //   70: iconst_4
    //   71: iadd
    //   72: aload #6
    //   74: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   77: astore #10
    //   79: aload_0
    //   80: iload #5
    //   82: bipush #6
    //   84: iadd
    //   85: invokevirtual readUnsignedShort : (I)I
    //   88: anewarray java/lang/String
    //   91: astore #11
    //   93: iinc #5, 8
    //   96: iconst_0
    //   97: istore #12
    //   99: iload #12
    //   101: aload #11
    //   103: arraylength
    //   104: if_icmpge -> 131
    //   107: aload #11
    //   109: iload #12
    //   111: aload_0
    //   112: iload #5
    //   114: aload #6
    //   116: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   119: aastore
    //   120: iinc #5, 2
    //   123: iinc #12, 1
    //   126: iload #4
    //   128: ifeq -> 99
    //   131: aconst_null
    //   132: astore #12
    //   134: aconst_null
    //   135: astore #13
    //   137: aconst_null
    //   138: astore #14
    //   140: aconst_null
    //   141: astore #15
    //   143: aconst_null
    //   144: astore #16
    //   146: aconst_null
    //   147: astore #17
    //   149: iconst_0
    //   150: istore #18
    //   152: iconst_0
    //   153: istore #19
    //   155: iconst_0
    //   156: istore #20
    //   158: iconst_0
    //   159: istore #21
    //   161: iconst_0
    //   162: istore #22
    //   164: aconst_null
    //   165: astore #23
    //   167: aload_0
    //   168: invokespecial a : ()I
    //   171: istore #5
    //   173: aload_0
    //   174: iload #5
    //   176: invokevirtual readUnsignedShort : (I)I
    //   179: istore #24
    //   181: iload #24
    //   183: ifle -> 953
    //   186: aload_0
    //   187: iload #5
    //   189: iconst_2
    //   190: iadd
    //   191: aload #6
    //   193: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   196: astore #25
    //   198: sipush #29981
    //   201: sipush #-491
    //   204: invokestatic a : (II)Ljava/lang/String;
    //   207: aload #25
    //   209: invokevirtual equals : (Ljava/lang/Object;)Z
    //   212: iload #4
    //   214: ifne -> 983
    //   217: iload #4
    //   219: ifne -> 269
    //   222: goto -> 226
    //   225: athrow
    //   226: ifeq -> 251
    //   229: goto -> 233
    //   232: athrow
    //   233: aload_0
    //   234: iload #5
    //   236: bipush #8
    //   238: iadd
    //   239: aload #6
    //   241: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   244: astore #13
    //   246: iload #4
    //   248: ifeq -> 929
    //   251: sipush #29977
    //   254: sipush #29350
    //   257: invokestatic a : (II)Ljava/lang/String;
    //   260: aload #25
    //   262: invokevirtual equals : (Ljava/lang/Object;)Z
    //   265: goto -> 269
    //   268: athrow
    //   269: iload #4
    //   271: ifne -> 311
    //   274: ifeq -> 293
    //   277: goto -> 281
    //   280: athrow
    //   281: iload #5
    //   283: bipush #8
    //   285: iadd
    //   286: istore #22
    //   288: iload #4
    //   290: ifeq -> 929
    //   293: sipush #29982
    //   296: sipush #-16950
    //   299: invokestatic a : (II)Ljava/lang/String;
    //   302: aload #25
    //   304: invokevirtual equals : (Ljava/lang/Object;)Z
    //   307: goto -> 311
    //   310: athrow
    //   311: iload #4
    //   313: ifne -> 416
    //   316: ifeq -> 398
    //   319: goto -> 323
    //   322: athrow
    //   323: aload_0
    //   324: iload #5
    //   326: bipush #8
    //   328: iadd
    //   329: aload #6
    //   331: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   334: astore #15
    //   336: aload_0
    //   337: iload #5
    //   339: bipush #10
    //   341: iadd
    //   342: invokevirtual readUnsignedShort : (I)I
    //   345: istore #26
    //   347: iload #4
    //   349: ifne -> 376
    //   352: iload #26
    //   354: ifeq -> 393
    //   357: goto -> 361
    //   360: athrow
    //   361: aload_0
    //   362: aload_0
    //   363: getfield a : [I
    //   366: iload #26
    //   368: iaload
    //   369: aload #6
    //   371: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   374: astore #16
    //   376: aload_0
    //   377: aload_0
    //   378: getfield a : [I
    //   381: iload #26
    //   383: iaload
    //   384: iconst_2
    //   385: iadd
    //   386: aload #6
    //   388: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   391: astore #17
    //   393: iload #4
    //   395: ifeq -> 929
    //   398: sipush #29964
    //   401: sipush #-5009
    //   404: invokestatic a : (II)Ljava/lang/String;
    //   407: aload #25
    //   409: invokevirtual equals : (Ljava/lang/Object;)Z
    //   412: goto -> 416
    //   415: athrow
    //   416: iload #4
    //   418: ifne -> 464
    //   421: ifeq -> 446
    //   424: goto -> 428
    //   427: athrow
    //   428: aload_0
    //   429: iload #5
    //   431: bipush #8
    //   433: iadd
    //   434: aload #6
    //   436: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   439: astore #12
    //   441: iload #4
    //   443: ifeq -> 929
    //   446: sipush #29953
    //   449: sipush #9514
    //   452: invokestatic a : (II)Ljava/lang/String;
    //   455: aload #25
    //   457: invokevirtual equals : (Ljava/lang/Object;)Z
    //   460: goto -> 464
    //   463: athrow
    //   464: iload #4
    //   466: ifne -> 506
    //   469: ifeq -> 488
    //   472: goto -> 476
    //   475: athrow
    //   476: iload #5
    //   478: bipush #8
    //   480: iadd
    //   481: istore #18
    //   483: iload #4
    //   485: ifeq -> 929
    //   488: sipush #29979
    //   491: sipush #14533
    //   494: invokestatic a : (II)Ljava/lang/String;
    //   497: aload #25
    //   499: invokevirtual equals : (Ljava/lang/Object;)Z
    //   502: goto -> 506
    //   505: athrow
    //   506: iload #4
    //   508: ifne -> 548
    //   511: ifeq -> 530
    //   514: goto -> 518
    //   517: athrow
    //   518: iload #5
    //   520: bipush #8
    //   522: iadd
    //   523: istore #20
    //   525: iload #4
    //   527: ifeq -> 929
    //   530: sipush #29975
    //   533: sipush #-10634
    //   536: invokestatic a : (II)Ljava/lang/String;
    //   539: aload #25
    //   541: invokevirtual equals : (Ljava/lang/Object;)Z
    //   544: goto -> 548
    //   547: athrow
    //   548: iload #4
    //   550: ifne -> 590
    //   553: ifeq -> 572
    //   556: goto -> 560
    //   559: athrow
    //   560: iload #8
    //   562: ldc 131072
    //   564: ior
    //   565: istore #8
    //   567: iload #4
    //   569: ifeq -> 929
    //   572: sipush #29976
    //   575: sipush #7573
    //   578: invokestatic a : (II)Ljava/lang/String;
    //   581: aload #25
    //   583: invokevirtual equals : (Ljava/lang/Object;)Z
    //   586: goto -> 590
    //   589: athrow
    //   590: iload #4
    //   592: ifne -> 632
    //   595: ifeq -> 614
    //   598: goto -> 602
    //   601: athrow
    //   602: iload #8
    //   604: ldc 266240
    //   606: ior
    //   607: istore #8
    //   609: iload #4
    //   611: ifeq -> 929
    //   614: sipush #29955
    //   617: sipush #6867
    //   620: invokestatic a : (II)Ljava/lang/String;
    //   623: aload #25
    //   625: invokevirtual equals : (Ljava/lang/Object;)Z
    //   628: goto -> 632
    //   631: athrow
    //   632: iload #4
    //   634: ifne -> 694
    //   637: ifeq -> 676
    //   640: goto -> 644
    //   643: athrow
    //   644: aload_0
    //   645: iload #5
    //   647: iconst_4
    //   648: iadd
    //   649: invokevirtual readInt : (I)I
    //   652: istore #26
    //   654: aload_0
    //   655: iload #5
    //   657: bipush #8
    //   659: iadd
    //   660: iload #26
    //   662: iload #26
    //   664: newarray char
    //   666: invokespecial a : (II[C)Ljava/lang/String;
    //   669: astore #14
    //   671: iload #4
    //   673: ifeq -> 929
    //   676: sipush #29962
    //   679: sipush #23367
    //   682: invokestatic a : (II)Ljava/lang/String;
    //   685: aload #25
    //   687: invokevirtual equals : (Ljava/lang/Object;)Z
    //   690: goto -> 694
    //   693: athrow
    //   694: iload #4
    //   696: ifne -> 736
    //   699: ifeq -> 718
    //   702: goto -> 706
    //   705: athrow
    //   706: iload #5
    //   708: bipush #8
    //   710: iadd
    //   711: istore #19
    //   713: iload #4
    //   715: ifeq -> 929
    //   718: sipush #29973
    //   721: sipush #-12970
    //   724: invokestatic a : (II)Ljava/lang/String;
    //   727: aload #25
    //   729: invokevirtual equals : (Ljava/lang/Object;)Z
    //   732: goto -> 736
    //   735: athrow
    //   736: iload #4
    //   738: ifne -> 778
    //   741: ifeq -> 760
    //   744: goto -> 748
    //   747: athrow
    //   748: iload #5
    //   750: bipush #8
    //   752: iadd
    //   753: istore #21
    //   755: iload #4
    //   757: ifeq -> 929
    //   760: sipush #29974
    //   763: sipush #18414
    //   766: invokestatic a : (II)Ljava/lang/String;
    //   769: aload #25
    //   771: invokevirtual equals : (Ljava/lang/Object;)Z
    //   774: goto -> 778
    //   777: athrow
    //   778: iload #4
    //   780: ifne -> 803
    //   783: ifeq -> 878
    //   786: goto -> 790
    //   789: athrow
    //   790: aload_0
    //   791: iload #5
    //   793: bipush #8
    //   795: iadd
    //   796: invokevirtual readUnsignedShort : (I)I
    //   799: goto -> 803
    //   802: athrow
    //   803: newarray int
    //   805: astore #26
    //   807: iconst_0
    //   808: istore #27
    //   810: iload #5
    //   812: bipush #10
    //   814: iadd
    //   815: istore #28
    //   817: iload #27
    //   819: aload #26
    //   821: arraylength
    //   822: if_icmpge -> 866
    //   825: aload #26
    //   827: iload #27
    //   829: iload #28
    //   831: iastore
    //   832: iload #28
    //   834: iconst_2
    //   835: aload_0
    //   836: iload #28
    //   838: iconst_2
    //   839: iadd
    //   840: invokevirtual readUnsignedShort : (I)I
    //   843: iadd
    //   844: iconst_1
    //   845: ishl
    //   846: iadd
    //   847: istore #28
    //   849: iinc #27, 1
    //   852: iload #4
    //   854: ifne -> 873
    //   857: iload #4
    //   859: ifeq -> 817
    //   862: goto -> 866
    //   865: athrow
    //   866: aload #7
    //   868: aload #26
    //   870: putfield d : [I
    //   873: iload #4
    //   875: ifeq -> 929
    //   878: aload_0
    //   879: aload_2
    //   880: aload #25
    //   882: iload #5
    //   884: bipush #8
    //   886: iadd
    //   887: aload_0
    //   888: iload #5
    //   890: iconst_4
    //   891: iadd
    //   892: invokevirtual readInt : (I)I
    //   895: aload #6
    //   897: iconst_m1
    //   898: aconst_null
    //   899: invokespecial a : ([Lorg/objectweb/asm/Attribute;Ljava/lang/String;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   902: astore #26
    //   904: iload #4
    //   906: ifne -> 948
    //   909: aload #26
    //   911: ifnull -> 929
    //   914: goto -> 918
    //   917: athrow
    //   918: aload #26
    //   920: aload #23
    //   922: putfield a : Lorg/objectweb/asm/Attribute;
    //   925: aload #26
    //   927: astore #23
    //   929: iload #5
    //   931: bipush #6
    //   933: aload_0
    //   934: iload #5
    //   936: iconst_4
    //   937: iadd
    //   938: invokevirtual readInt : (I)I
    //   941: iadd
    //   942: iadd
    //   943: istore #5
    //   945: iinc #24, -1
    //   948: iload #4
    //   950: ifeq -> 181
    //   953: aload_1
    //   954: aload_0
    //   955: aload_0
    //   956: getfield a : [I
    //   959: iconst_1
    //   960: iaload
    //   961: bipush #7
    //   963: isub
    //   964: invokevirtual readInt : (I)I
    //   967: iload #8
    //   969: aload #9
    //   971: aload #12
    //   973: aload #10
    //   975: aload #11
    //   977: invokevirtual visit : (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V
    //   980: iload_3
    //   981: iconst_2
    //   982: iand
    //   983: ifne -> 1030
    //   986: aload #13
    //   988: iload #4
    //   990: ifne -> 1006
    //   993: goto -> 997
    //   996: athrow
    //   997: ifnonnull -> 1018
    //   1000: goto -> 1004
    //   1003: athrow
    //   1004: aload #14
    //   1006: iload #4
    //   1008: ifne -> 1032
    //   1011: ifnull -> 1030
    //   1014: goto -> 1018
    //   1017: athrow
    //   1018: aload_1
    //   1019: aload #13
    //   1021: aload #14
    //   1023: invokevirtual visitSource : (Ljava/lang/String;Ljava/lang/String;)V
    //   1026: goto -> 1030
    //   1029: athrow
    //   1030: aload #15
    //   1032: ifnull -> 1049
    //   1035: aload_1
    //   1036: aload #15
    //   1038: aload #16
    //   1040: aload #17
    //   1042: invokevirtual visitOuterClass : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1045: goto -> 1049
    //   1048: athrow
    //   1049: iload #18
    //   1051: iload #4
    //   1053: ifne -> 1127
    //   1056: ifeq -> 1125
    //   1059: goto -> 1063
    //   1062: athrow
    //   1063: aload_0
    //   1064: iload #18
    //   1066: invokevirtual readUnsignedShort : (I)I
    //   1069: istore #24
    //   1071: iload #18
    //   1073: iconst_2
    //   1074: iadd
    //   1075: istore #25
    //   1077: iload #24
    //   1079: ifle -> 1125
    //   1082: aload_0
    //   1083: iload #25
    //   1085: iconst_2
    //   1086: iadd
    //   1087: aload #6
    //   1089: iconst_1
    //   1090: aload_1
    //   1091: aload_0
    //   1092: iload #25
    //   1094: aload #6
    //   1096: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1099: iconst_1
    //   1100: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1103: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1106: istore #25
    //   1108: iinc #24, -1
    //   1111: iload #4
    //   1113: ifne -> 1201
    //   1116: iload #4
    //   1118: ifeq -> 1077
    //   1121: goto -> 1125
    //   1124: athrow
    //   1125: iload #19
    //   1127: iload #4
    //   1129: ifne -> 1203
    //   1132: ifeq -> 1201
    //   1135: goto -> 1139
    //   1138: athrow
    //   1139: aload_0
    //   1140: iload #19
    //   1142: invokevirtual readUnsignedShort : (I)I
    //   1145: istore #24
    //   1147: iload #19
    //   1149: iconst_2
    //   1150: iadd
    //   1151: istore #25
    //   1153: iload #24
    //   1155: ifle -> 1201
    //   1158: aload_0
    //   1159: iload #25
    //   1161: iconst_2
    //   1162: iadd
    //   1163: aload #6
    //   1165: iconst_1
    //   1166: aload_1
    //   1167: aload_0
    //   1168: iload #25
    //   1170: aload #6
    //   1172: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1175: iconst_0
    //   1176: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1179: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1182: istore #25
    //   1184: iinc #24, -1
    //   1187: iload #4
    //   1189: ifne -> 1297
    //   1192: iload #4
    //   1194: ifeq -> 1153
    //   1197: goto -> 1201
    //   1200: athrow
    //   1201: iload #20
    //   1203: iload #4
    //   1205: ifne -> 1299
    //   1208: ifeq -> 1297
    //   1211: goto -> 1215
    //   1214: athrow
    //   1215: aload_0
    //   1216: iload #20
    //   1218: invokevirtual readUnsignedShort : (I)I
    //   1221: istore #24
    //   1223: iload #20
    //   1225: iconst_2
    //   1226: iadd
    //   1227: istore #25
    //   1229: iload #24
    //   1231: ifle -> 1297
    //   1234: aload_0
    //   1235: aload #7
    //   1237: iload #25
    //   1239: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   1242: istore #25
    //   1244: aload_0
    //   1245: iload #25
    //   1247: iconst_2
    //   1248: iadd
    //   1249: aload #6
    //   1251: iconst_1
    //   1252: aload_1
    //   1253: aload #7
    //   1255: getfield i : I
    //   1258: aload #7
    //   1260: getfield j : Lorg/objectweb/asm/TypePath;
    //   1263: aload_0
    //   1264: iload #25
    //   1266: aload #6
    //   1268: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1271: iconst_1
    //   1272: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1275: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1278: istore #25
    //   1280: iinc #24, -1
    //   1283: iload #4
    //   1285: ifne -> 1393
    //   1288: iload #4
    //   1290: ifeq -> 1229
    //   1293: goto -> 1297
    //   1296: athrow
    //   1297: iload #21
    //   1299: iload #4
    //   1301: ifne -> 1323
    //   1304: ifeq -> 1393
    //   1307: goto -> 1311
    //   1310: athrow
    //   1311: aload_0
    //   1312: iload #21
    //   1314: invokevirtual readUnsignedShort : (I)I
    //   1317: istore #24
    //   1319: iload #21
    //   1321: iconst_2
    //   1322: iadd
    //   1323: istore #25
    //   1325: iload #24
    //   1327: ifle -> 1393
    //   1330: aload_0
    //   1331: aload #7
    //   1333: iload #25
    //   1335: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   1338: istore #25
    //   1340: aload_0
    //   1341: iload #25
    //   1343: iconst_2
    //   1344: iadd
    //   1345: aload #6
    //   1347: iconst_1
    //   1348: aload_1
    //   1349: aload #7
    //   1351: getfield i : I
    //   1354: aload #7
    //   1356: getfield j : Lorg/objectweb/asm/TypePath;
    //   1359: aload_0
    //   1360: iload #25
    //   1362: aload #6
    //   1364: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1367: iconst_0
    //   1368: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1371: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1374: istore #25
    //   1376: iinc #24, -1
    //   1379: iload #4
    //   1381: ifne -> 1435
    //   1384: iload #4
    //   1386: ifeq -> 1325
    //   1389: goto -> 1393
    //   1392: athrow
    //   1393: aload #23
    //   1395: ifnull -> 1435
    //   1398: aload #23
    //   1400: getfield a : Lorg/objectweb/asm/Attribute;
    //   1403: astore #24
    //   1405: aload #23
    //   1407: aconst_null
    //   1408: putfield a : Lorg/objectweb/asm/Attribute;
    //   1411: aload_1
    //   1412: aload #23
    //   1414: invokevirtual visitAttribute : (Lorg/objectweb/asm/Attribute;)V
    //   1417: aload #24
    //   1419: astore #23
    //   1421: iload #4
    //   1423: ifne -> 1544
    //   1426: iload #4
    //   1428: ifeq -> 1393
    //   1431: goto -> 1435
    //   1434: athrow
    //   1435: iload #22
    //   1437: iload #4
    //   1439: ifne -> 1552
    //   1442: ifeq -> 1529
    //   1445: goto -> 1449
    //   1448: athrow
    //   1449: iload #22
    //   1451: iconst_2
    //   1452: iadd
    //   1453: istore #24
    //   1455: aload_0
    //   1456: iload #22
    //   1458: invokevirtual readUnsignedShort : (I)I
    //   1461: istore #25
    //   1463: iload #25
    //   1465: ifle -> 1529
    //   1468: aload_1
    //   1469: aload_0
    //   1470: iload #24
    //   1472: aload #6
    //   1474: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   1477: aload_0
    //   1478: iload #24
    //   1480: iconst_2
    //   1481: iadd
    //   1482: aload #6
    //   1484: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   1487: aload_0
    //   1488: iload #24
    //   1490: iconst_4
    //   1491: iadd
    //   1492: aload #6
    //   1494: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1497: aload_0
    //   1498: iload #24
    //   1500: bipush #6
    //   1502: iadd
    //   1503: invokevirtual readUnsignedShort : (I)I
    //   1506: invokevirtual visitInnerClass : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    //   1509: iinc #24, 8
    //   1512: iinc #25, -1
    //   1515: iload #4
    //   1517: ifne -> 1544
    //   1520: iload #4
    //   1522: ifeq -> 1463
    //   1525: goto -> 1529
    //   1528: athrow
    //   1529: aload_0
    //   1530: getfield header : I
    //   1533: bipush #10
    //   1535: iadd
    //   1536: iconst_2
    //   1537: aload #11
    //   1539: arraylength
    //   1540: imul
    //   1541: iadd
    //   1542: istore #5
    //   1544: aload_0
    //   1545: iload #5
    //   1547: iconst_2
    //   1548: isub
    //   1549: invokevirtual readUnsignedShort : (I)I
    //   1552: istore #24
    //   1554: iload #24
    //   1556: ifle -> 1587
    //   1559: aload_0
    //   1560: aload_1
    //   1561: aload #7
    //   1563: iload #5
    //   1565: invokespecial a : (Lorg/objectweb/asm/ClassVisitor;Lorg/objectweb/asm/Context;I)I
    //   1568: istore #5
    //   1570: iinc #24, -1
    //   1573: iload #4
    //   1575: ifne -> 1590
    //   1578: iload #4
    //   1580: ifeq -> 1554
    //   1583: goto -> 1587
    //   1586: athrow
    //   1587: iinc #5, 2
    //   1590: aload_0
    //   1591: iload #5
    //   1593: iconst_2
    //   1594: isub
    //   1595: invokevirtual readUnsignedShort : (I)I
    //   1598: istore #24
    //   1600: iload #24
    //   1602: ifle -> 1633
    //   1605: aload_0
    //   1606: aload_1
    //   1607: aload #7
    //   1609: iload #5
    //   1611: invokespecial b : (Lorg/objectweb/asm/ClassVisitor;Lorg/objectweb/asm/Context;I)I
    //   1614: istore #5
    //   1616: iinc #24, -1
    //   1619: iload #4
    //   1621: ifne -> 1637
    //   1624: iload #4
    //   1626: ifeq -> 1600
    //   1629: goto -> 1633
    //   1632: athrow
    //   1633: aload_1
    //   1634: invokevirtual visitEnd : ()V
    //   1637: getstatic org/objectweb/asm/ClassVisitor.b : Z
    //   1640: ifeq -> 1655
    //   1643: iinc #4, 1
    //   1646: iload #4
    //   1648: putstatic org/objectweb/asm/MethodVisitor.b : I
    //   1651: goto -> 1655
    //   1654: athrow
    //   1655: return
    // Exception table:
    //   from	to	target	type
    //   198	222	225	java/lang/IllegalArgumentException
    //   217	229	232	java/lang/IllegalArgumentException
    //   246	265	268	java/lang/IllegalArgumentException
    //   269	277	280	java/lang/IllegalArgumentException
    //   288	307	310	java/lang/IllegalArgumentException
    //   311	319	322	java/lang/IllegalArgumentException
    //   347	357	360	java/lang/IllegalArgumentException
    //   393	412	415	java/lang/IllegalArgumentException
    //   416	424	427	java/lang/IllegalArgumentException
    //   441	460	463	java/lang/IllegalArgumentException
    //   464	472	475	java/lang/IllegalArgumentException
    //   483	502	505	java/lang/IllegalArgumentException
    //   506	514	517	java/lang/IllegalArgumentException
    //   525	544	547	java/lang/IllegalArgumentException
    //   548	556	559	java/lang/IllegalArgumentException
    //   567	586	589	java/lang/IllegalArgumentException
    //   590	598	601	java/lang/IllegalArgumentException
    //   609	628	631	java/lang/IllegalArgumentException
    //   632	640	643	java/lang/IllegalArgumentException
    //   671	690	693	java/lang/IllegalArgumentException
    //   694	702	705	java/lang/IllegalArgumentException
    //   713	732	735	java/lang/IllegalArgumentException
    //   736	744	747	java/lang/IllegalArgumentException
    //   755	774	777	java/lang/IllegalArgumentException
    //   778	786	789	java/lang/IllegalArgumentException
    //   783	799	802	java/lang/IllegalArgumentException
    //   849	862	865	java/lang/IllegalArgumentException
    //   904	914	917	java/lang/IllegalArgumentException
    //   983	993	996	java/lang/IllegalArgumentException
    //   986	1000	1003	java/lang/IllegalArgumentException
    //   1006	1014	1017	java/lang/IllegalArgumentException
    //   1011	1026	1029	java/lang/IllegalArgumentException
    //   1032	1045	1048	java/lang/IllegalArgumentException
    //   1049	1059	1062	java/lang/IllegalArgumentException
    //   1108	1121	1124	java/lang/IllegalArgumentException
    //   1127	1135	1138	java/lang/IllegalArgumentException
    //   1184	1197	1200	java/lang/IllegalArgumentException
    //   1203	1211	1214	java/lang/IllegalArgumentException
    //   1280	1293	1296	java/lang/IllegalArgumentException
    //   1299	1307	1310	java/lang/IllegalArgumentException
    //   1376	1389	1392	java/lang/IllegalArgumentException
    //   1421	1431	1434	java/lang/IllegalArgumentException
    //   1435	1445	1448	java/lang/IllegalArgumentException
    //   1468	1525	1528	java/lang/IllegalArgumentException
    //   1570	1583	1586	java/lang/IllegalArgumentException
    //   1616	1629	1632	java/lang/IllegalArgumentException
    //   1637	1651	1654	java/lang/IllegalArgumentException
  }
  
  private int a(ClassVisitor paramClassVisitor, Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_2
    //   1: getfield c : [C
    //   4: astore #5
    //   6: aload_0
    //   7: iload_3
    //   8: invokevirtual readUnsignedShort : (I)I
    //   11: istore #6
    //   13: aload_0
    //   14: iload_3
    //   15: iconst_2
    //   16: iadd
    //   17: aload #5
    //   19: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   22: astore #7
    //   24: aload_0
    //   25: iload_3
    //   26: iconst_4
    //   27: iadd
    //   28: aload #5
    //   30: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   33: astore #8
    //   35: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   38: iinc #3, 6
    //   41: aconst_null
    //   42: astore #9
    //   44: iconst_0
    //   45: istore #10
    //   47: istore #4
    //   49: iconst_0
    //   50: istore #11
    //   52: iconst_0
    //   53: istore #12
    //   55: iconst_0
    //   56: istore #13
    //   58: aconst_null
    //   59: astore #14
    //   61: aconst_null
    //   62: astore #15
    //   64: aload_0
    //   65: iload_3
    //   66: invokevirtual readUnsignedShort : (I)I
    //   69: istore #16
    //   71: iload #16
    //   73: ifle -> 529
    //   76: aload_0
    //   77: iload_3
    //   78: iconst_2
    //   79: iadd
    //   80: aload #5
    //   82: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   85: astore #17
    //   87: iload #4
    //   89: ifne -> 532
    //   92: sipush #29961
    //   95: sipush #-6807
    //   98: invokestatic a : (II)Ljava/lang/String;
    //   101: aload #17
    //   103: invokevirtual equals : (Ljava/lang/Object;)Z
    //   106: iload #4
    //   108: ifne -> 175
    //   111: goto -> 115
    //   114: athrow
    //   115: ifeq -> 157
    //   118: goto -> 122
    //   121: athrow
    //   122: aload_0
    //   123: iload_3
    //   124: bipush #8
    //   126: iadd
    //   127: invokevirtual readUnsignedShort : (I)I
    //   130: istore #18
    //   132: iload #18
    //   134: ifne -> 142
    //   137: aconst_null
    //   138: goto -> 150
    //   141: athrow
    //   142: aload_0
    //   143: iload #18
    //   145: aload #5
    //   147: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   150: astore #14
    //   152: iload #4
    //   154: ifeq -> 508
    //   157: sipush #29964
    //   160: sipush #-5009
    //   163: invokestatic a : (II)Ljava/lang/String;
    //   166: aload #17
    //   168: invokevirtual equals : (Ljava/lang/Object;)Z
    //   171: goto -> 175
    //   174: athrow
    //   175: iload #4
    //   177: ifne -> 222
    //   180: ifeq -> 204
    //   183: goto -> 187
    //   186: athrow
    //   187: aload_0
    //   188: iload_3
    //   189: bipush #8
    //   191: iadd
    //   192: aload #5
    //   194: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   197: astore #9
    //   199: iload #4
    //   201: ifeq -> 508
    //   204: sipush #29975
    //   207: sipush #-10634
    //   210: invokestatic a : (II)Ljava/lang/String;
    //   213: aload #17
    //   215: invokevirtual equals : (Ljava/lang/Object;)Z
    //   218: goto -> 222
    //   221: athrow
    //   222: iload #4
    //   224: ifne -> 264
    //   227: ifeq -> 246
    //   230: goto -> 234
    //   233: athrow
    //   234: iload #6
    //   236: ldc 131072
    //   238: ior
    //   239: istore #6
    //   241: iload #4
    //   243: ifeq -> 508
    //   246: sipush #29976
    //   249: sipush #7573
    //   252: invokestatic a : (II)Ljava/lang/String;
    //   255: aload #17
    //   257: invokevirtual equals : (Ljava/lang/Object;)Z
    //   260: goto -> 264
    //   263: athrow
    //   264: iload #4
    //   266: ifne -> 306
    //   269: ifeq -> 288
    //   272: goto -> 276
    //   275: athrow
    //   276: iload #6
    //   278: ldc 266240
    //   280: ior
    //   281: istore #6
    //   283: iload #4
    //   285: ifeq -> 508
    //   288: sipush #29953
    //   291: sipush #9514
    //   294: invokestatic a : (II)Ljava/lang/String;
    //   297: aload #17
    //   299: invokevirtual equals : (Ljava/lang/Object;)Z
    //   302: goto -> 306
    //   305: athrow
    //   306: iload #4
    //   308: ifne -> 347
    //   311: ifeq -> 329
    //   314: goto -> 318
    //   317: athrow
    //   318: iload_3
    //   319: bipush #8
    //   321: iadd
    //   322: istore #10
    //   324: iload #4
    //   326: ifeq -> 508
    //   329: sipush #29979
    //   332: sipush #14533
    //   335: invokestatic a : (II)Ljava/lang/String;
    //   338: aload #17
    //   340: invokevirtual equals : (Ljava/lang/Object;)Z
    //   343: goto -> 347
    //   346: athrow
    //   347: iload #4
    //   349: ifne -> 388
    //   352: ifeq -> 370
    //   355: goto -> 359
    //   358: athrow
    //   359: iload_3
    //   360: bipush #8
    //   362: iadd
    //   363: istore #12
    //   365: iload #4
    //   367: ifeq -> 508
    //   370: sipush #29962
    //   373: sipush #23367
    //   376: invokestatic a : (II)Ljava/lang/String;
    //   379: aload #17
    //   381: invokevirtual equals : (Ljava/lang/Object;)Z
    //   384: goto -> 388
    //   387: athrow
    //   388: iload #4
    //   390: ifne -> 429
    //   393: ifeq -> 411
    //   396: goto -> 400
    //   399: athrow
    //   400: iload_3
    //   401: bipush #8
    //   403: iadd
    //   404: istore #11
    //   406: iload #4
    //   408: ifeq -> 508
    //   411: sipush #29973
    //   414: sipush #-12970
    //   417: invokestatic a : (II)Ljava/lang/String;
    //   420: aload #17
    //   422: invokevirtual equals : (Ljava/lang/Object;)Z
    //   425: goto -> 429
    //   428: athrow
    //   429: iload #4
    //   431: ifne -> 449
    //   434: ifeq -> 456
    //   437: goto -> 441
    //   440: athrow
    //   441: iload_3
    //   442: bipush #8
    //   444: iadd
    //   445: goto -> 449
    //   448: athrow
    //   449: istore #13
    //   451: iload #4
    //   453: ifeq -> 508
    //   456: aload_0
    //   457: aload_2
    //   458: getfield a : [Lorg/objectweb/asm/Attribute;
    //   461: aload #17
    //   463: iload_3
    //   464: bipush #8
    //   466: iadd
    //   467: aload_0
    //   468: iload_3
    //   469: iconst_4
    //   470: iadd
    //   471: invokevirtual readInt : (I)I
    //   474: aload #5
    //   476: iconst_m1
    //   477: aconst_null
    //   478: invokespecial a : ([Lorg/objectweb/asm/Attribute;Ljava/lang/String;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   481: astore #18
    //   483: iload #4
    //   485: ifne -> 524
    //   488: aload #18
    //   490: ifnull -> 508
    //   493: goto -> 497
    //   496: athrow
    //   497: aload #18
    //   499: aload #15
    //   501: putfield a : Lorg/objectweb/asm/Attribute;
    //   504: aload #18
    //   506: astore #15
    //   508: iload_3
    //   509: bipush #6
    //   511: aload_0
    //   512: iload_3
    //   513: iconst_4
    //   514: iadd
    //   515: invokevirtual readInt : (I)I
    //   518: iadd
    //   519: iadd
    //   520: istore_3
    //   521: iinc #16, -1
    //   524: iload #4
    //   526: ifeq -> 71
    //   529: iinc #3, 2
    //   532: aload_1
    //   533: iload #6
    //   535: aload #7
    //   537: aload #8
    //   539: aload #9
    //   541: aload #14
    //   543: invokevirtual visitField : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/objectweb/asm/FieldVisitor;
    //   546: astore #16
    //   548: aload #16
    //   550: ifnonnull -> 556
    //   553: iload_3
    //   554: ireturn
    //   555: athrow
    //   556: iload #10
    //   558: iload #4
    //   560: ifne -> 635
    //   563: ifeq -> 633
    //   566: goto -> 570
    //   569: athrow
    //   570: aload_0
    //   571: iload #10
    //   573: invokevirtual readUnsignedShort : (I)I
    //   576: istore #17
    //   578: iload #10
    //   580: iconst_2
    //   581: iadd
    //   582: istore #18
    //   584: iload #17
    //   586: ifle -> 633
    //   589: aload_0
    //   590: iload #18
    //   592: iconst_2
    //   593: iadd
    //   594: aload #5
    //   596: iconst_1
    //   597: aload #16
    //   599: aload_0
    //   600: iload #18
    //   602: aload #5
    //   604: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   607: iconst_1
    //   608: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   611: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   614: istore #18
    //   616: iinc #17, -1
    //   619: iload #4
    //   621: ifne -> 710
    //   624: iload #4
    //   626: ifeq -> 584
    //   629: goto -> 633
    //   632: athrow
    //   633: iload #11
    //   635: iload #4
    //   637: ifne -> 712
    //   640: ifeq -> 710
    //   643: goto -> 647
    //   646: athrow
    //   647: aload_0
    //   648: iload #11
    //   650: invokevirtual readUnsignedShort : (I)I
    //   653: istore #17
    //   655: iload #11
    //   657: iconst_2
    //   658: iadd
    //   659: istore #18
    //   661: iload #17
    //   663: ifle -> 710
    //   666: aload_0
    //   667: iload #18
    //   669: iconst_2
    //   670: iadd
    //   671: aload #5
    //   673: iconst_1
    //   674: aload #16
    //   676: aload_0
    //   677: iload #18
    //   679: aload #5
    //   681: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   684: iconst_0
    //   685: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   688: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   691: istore #18
    //   693: iinc #17, -1
    //   696: iload #4
    //   698: ifne -> 804
    //   701: iload #4
    //   703: ifeq -> 661
    //   706: goto -> 710
    //   709: athrow
    //   710: iload #12
    //   712: iload #4
    //   714: ifne -> 806
    //   717: ifeq -> 804
    //   720: goto -> 724
    //   723: athrow
    //   724: aload_0
    //   725: iload #12
    //   727: invokevirtual readUnsignedShort : (I)I
    //   730: istore #17
    //   732: iload #12
    //   734: iconst_2
    //   735: iadd
    //   736: istore #18
    //   738: iload #17
    //   740: ifle -> 804
    //   743: aload_0
    //   744: aload_2
    //   745: iload #18
    //   747: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   750: istore #18
    //   752: aload_0
    //   753: iload #18
    //   755: iconst_2
    //   756: iadd
    //   757: aload #5
    //   759: iconst_1
    //   760: aload #16
    //   762: aload_2
    //   763: getfield i : I
    //   766: aload_2
    //   767: getfield j : Lorg/objectweb/asm/TypePath;
    //   770: aload_0
    //   771: iload #18
    //   773: aload #5
    //   775: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   778: iconst_1
    //   779: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   782: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   785: istore #18
    //   787: iinc #17, -1
    //   790: iload #4
    //   792: ifne -> 902
    //   795: iload #4
    //   797: ifeq -> 738
    //   800: goto -> 804
    //   803: athrow
    //   804: iload #13
    //   806: iload #4
    //   808: ifne -> 828
    //   811: ifeq -> 902
    //   814: goto -> 818
    //   817: athrow
    //   818: aload_0
    //   819: iload #13
    //   821: invokevirtual readUnsignedShort : (I)I
    //   824: goto -> 828
    //   827: athrow
    //   828: istore #17
    //   830: iload #13
    //   832: iconst_2
    //   833: iadd
    //   834: istore #18
    //   836: iload #17
    //   838: ifle -> 902
    //   841: aload_0
    //   842: aload_2
    //   843: iload #18
    //   845: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   848: istore #18
    //   850: aload_0
    //   851: iload #18
    //   853: iconst_2
    //   854: iadd
    //   855: aload #5
    //   857: iconst_1
    //   858: aload #16
    //   860: aload_2
    //   861: getfield i : I
    //   864: aload_2
    //   865: getfield j : Lorg/objectweb/asm/TypePath;
    //   868: aload_0
    //   869: iload #18
    //   871: aload #5
    //   873: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   876: iconst_0
    //   877: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   880: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   883: istore #18
    //   885: iinc #17, -1
    //   888: iload #4
    //   890: ifne -> 950
    //   893: iload #4
    //   895: ifeq -> 836
    //   898: goto -> 902
    //   901: athrow
    //   902: aload #15
    //   904: ifnull -> 945
    //   907: aload #15
    //   909: getfield a : Lorg/objectweb/asm/Attribute;
    //   912: astore #17
    //   914: aload #15
    //   916: aconst_null
    //   917: putfield a : Lorg/objectweb/asm/Attribute;
    //   920: aload #16
    //   922: aload #15
    //   924: invokevirtual visitAttribute : (Lorg/objectweb/asm/Attribute;)V
    //   927: aload #17
    //   929: astore #15
    //   931: iload #4
    //   933: ifne -> 950
    //   936: iload #4
    //   938: ifeq -> 902
    //   941: goto -> 945
    //   944: athrow
    //   945: aload #16
    //   947: invokevirtual visitEnd : ()V
    //   950: iload_3
    //   951: ireturn
    // Exception table:
    //   from	to	target	type
    //   87	111	114	java/lang/IllegalArgumentException
    //   92	118	121	java/lang/IllegalArgumentException
    //   132	141	141	java/lang/IllegalArgumentException
    //   152	171	174	java/lang/IllegalArgumentException
    //   175	183	186	java/lang/IllegalArgumentException
    //   199	218	221	java/lang/IllegalArgumentException
    //   222	230	233	java/lang/IllegalArgumentException
    //   241	260	263	java/lang/IllegalArgumentException
    //   264	272	275	java/lang/IllegalArgumentException
    //   283	302	305	java/lang/IllegalArgumentException
    //   306	314	317	java/lang/IllegalArgumentException
    //   324	343	346	java/lang/IllegalArgumentException
    //   347	355	358	java/lang/IllegalArgumentException
    //   365	384	387	java/lang/IllegalArgumentException
    //   388	396	399	java/lang/IllegalArgumentException
    //   406	425	428	java/lang/IllegalArgumentException
    //   429	437	440	java/lang/IllegalArgumentException
    //   434	445	448	java/lang/IllegalArgumentException
    //   483	493	496	java/lang/IllegalArgumentException
    //   548	555	555	java/lang/IllegalArgumentException
    //   556	566	569	java/lang/IllegalArgumentException
    //   616	629	632	java/lang/IllegalArgumentException
    //   635	643	646	java/lang/IllegalArgumentException
    //   693	706	709	java/lang/IllegalArgumentException
    //   712	720	723	java/lang/IllegalArgumentException
    //   787	800	803	java/lang/IllegalArgumentException
    //   806	814	817	java/lang/IllegalArgumentException
    //   811	824	827	java/lang/IllegalArgumentException
    //   885	898	901	java/lang/IllegalArgumentException
    //   931	941	944	java/lang/IllegalArgumentException
  }
  
  private int b(ClassVisitor paramClassVisitor, Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_2
    //   1: getfield c : [C
    //   4: astore #5
    //   6: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   9: aload_2
    //   10: aload_0
    //   11: iload_3
    //   12: invokevirtual readUnsignedShort : (I)I
    //   15: putfield e : I
    //   18: aload_2
    //   19: aload_0
    //   20: iload_3
    //   21: iconst_2
    //   22: iadd
    //   23: aload #5
    //   25: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   28: putfield f : Ljava/lang/String;
    //   31: aload_2
    //   32: aload_0
    //   33: iload_3
    //   34: iconst_4
    //   35: iadd
    //   36: aload #5
    //   38: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   41: putfield g : Ljava/lang/String;
    //   44: istore #4
    //   46: iinc #3, 6
    //   49: iconst_0
    //   50: istore #6
    //   52: iconst_0
    //   53: istore #7
    //   55: aconst_null
    //   56: astore #8
    //   58: aconst_null
    //   59: astore #9
    //   61: iconst_0
    //   62: istore #10
    //   64: iconst_0
    //   65: istore #11
    //   67: iconst_0
    //   68: istore #12
    //   70: iconst_0
    //   71: istore #13
    //   73: iconst_0
    //   74: istore #14
    //   76: iconst_0
    //   77: istore #15
    //   79: iconst_0
    //   80: istore #16
    //   82: iconst_0
    //   83: istore #17
    //   85: iload_3
    //   86: istore #18
    //   88: aconst_null
    //   89: astore #19
    //   91: aload_0
    //   92: iload_3
    //   93: invokevirtual readUnsignedShort : (I)I
    //   96: istore #20
    //   98: iload #20
    //   100: ifle -> 832
    //   103: aload_0
    //   104: iload_3
    //   105: iconst_2
    //   106: iadd
    //   107: aload #5
    //   109: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   112: astore #21
    //   114: iload #4
    //   116: ifne -> 835
    //   119: sipush #29983
    //   122: sipush #-28155
    //   125: invokestatic a : (II)Ljava/lang/String;
    //   128: aload #21
    //   130: invokevirtual equals : (Ljava/lang/Object;)Z
    //   133: iload #4
    //   135: ifne -> 200
    //   138: goto -> 142
    //   141: athrow
    //   142: ifeq -> 182
    //   145: goto -> 149
    //   148: athrow
    //   149: aload_2
    //   150: getfield b : I
    //   153: iconst_1
    //   154: iand
    //   155: iload #4
    //   157: ifne -> 823
    //   160: goto -> 164
    //   163: athrow
    //   164: ifne -> 811
    //   167: goto -> 171
    //   170: athrow
    //   171: iload_3
    //   172: bipush #8
    //   174: iadd
    //   175: istore #6
    //   177: iload #4
    //   179: ifeq -> 811
    //   182: sipush #29965
    //   185: sipush #-10064
    //   188: invokestatic a : (II)Ljava/lang/String;
    //   191: aload #21
    //   193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   196: goto -> 200
    //   199: athrow
    //   200: iload #4
    //   202: ifne -> 298
    //   205: ifeq -> 280
    //   208: goto -> 212
    //   211: athrow
    //   212: aload_0
    //   213: iload_3
    //   214: bipush #8
    //   216: iadd
    //   217: invokevirtual readUnsignedShort : (I)I
    //   220: anewarray java/lang/String
    //   223: astore #8
    //   225: iload_3
    //   226: bipush #10
    //   228: iadd
    //   229: istore #7
    //   231: iconst_0
    //   232: istore #22
    //   234: iload #22
    //   236: aload #8
    //   238: arraylength
    //   239: if_icmpge -> 275
    //   242: aload #8
    //   244: iload #22
    //   246: aload_0
    //   247: iload #7
    //   249: aload #5
    //   251: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   254: aastore
    //   255: iinc #7, 2
    //   258: iinc #22, 1
    //   261: iload #4
    //   263: ifne -> 827
    //   266: iload #4
    //   268: ifeq -> 234
    //   271: goto -> 275
    //   274: athrow
    //   275: iload #4
    //   277: ifeq -> 811
    //   280: sipush #29964
    //   283: sipush #-5009
    //   286: invokestatic a : (II)Ljava/lang/String;
    //   289: aload #21
    //   291: invokevirtual equals : (Ljava/lang/Object;)Z
    //   294: goto -> 298
    //   297: athrow
    //   298: iload #4
    //   300: ifne -> 345
    //   303: ifeq -> 327
    //   306: goto -> 310
    //   309: athrow
    //   310: aload_0
    //   311: iload_3
    //   312: bipush #8
    //   314: iadd
    //   315: aload #5
    //   317: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   320: astore #9
    //   322: iload #4
    //   324: ifeq -> 811
    //   327: sipush #29975
    //   330: sipush #-10634
    //   333: invokestatic a : (II)Ljava/lang/String;
    //   336: aload #21
    //   338: invokevirtual equals : (Ljava/lang/Object;)Z
    //   341: goto -> 345
    //   344: athrow
    //   345: iload #4
    //   347: ifne -> 395
    //   350: ifeq -> 377
    //   353: goto -> 357
    //   356: athrow
    //   357: aload_2
    //   358: dup
    //   359: getfield e : I
    //   362: ldc 131072
    //   364: ior
    //   365: putfield e : I
    //   368: iload #4
    //   370: ifeq -> 811
    //   373: goto -> 377
    //   376: athrow
    //   377: sipush #29953
    //   380: sipush #9514
    //   383: invokestatic a : (II)Ljava/lang/String;
    //   386: aload #21
    //   388: invokevirtual equals : (Ljava/lang/Object;)Z
    //   391: goto -> 395
    //   394: athrow
    //   395: iload #4
    //   397: ifne -> 436
    //   400: ifeq -> 418
    //   403: goto -> 407
    //   406: athrow
    //   407: iload_3
    //   408: bipush #8
    //   410: iadd
    //   411: istore #11
    //   413: iload #4
    //   415: ifeq -> 811
    //   418: sipush #29979
    //   421: sipush #14533
    //   424: invokestatic a : (II)Ljava/lang/String;
    //   427: aload #21
    //   429: invokevirtual equals : (Ljava/lang/Object;)Z
    //   432: goto -> 436
    //   435: athrow
    //   436: iload #4
    //   438: ifne -> 477
    //   441: ifeq -> 459
    //   444: goto -> 448
    //   447: athrow
    //   448: iload_3
    //   449: bipush #8
    //   451: iadd
    //   452: istore #13
    //   454: iload #4
    //   456: ifeq -> 811
    //   459: sipush #29954
    //   462: sipush #2625
    //   465: invokestatic a : (II)Ljava/lang/String;
    //   468: aload #21
    //   470: invokevirtual equals : (Ljava/lang/Object;)Z
    //   473: goto -> 477
    //   476: athrow
    //   477: iload #4
    //   479: ifne -> 518
    //   482: ifeq -> 500
    //   485: goto -> 489
    //   488: athrow
    //   489: iload_3
    //   490: bipush #8
    //   492: iadd
    //   493: istore #15
    //   495: iload #4
    //   497: ifeq -> 811
    //   500: sipush #29976
    //   503: sipush #7573
    //   506: invokestatic a : (II)Ljava/lang/String;
    //   509: aload #21
    //   511: invokevirtual equals : (Ljava/lang/Object;)Z
    //   514: goto -> 518
    //   517: athrow
    //   518: iload #4
    //   520: ifne -> 568
    //   523: ifeq -> 550
    //   526: goto -> 530
    //   529: athrow
    //   530: aload_2
    //   531: dup
    //   532: getfield e : I
    //   535: ldc 266240
    //   537: ior
    //   538: putfield e : I
    //   541: iload #4
    //   543: ifeq -> 811
    //   546: goto -> 550
    //   549: athrow
    //   550: sipush #29962
    //   553: sipush #23367
    //   556: invokestatic a : (II)Ljava/lang/String;
    //   559: aload #21
    //   561: invokevirtual equals : (Ljava/lang/Object;)Z
    //   564: goto -> 568
    //   567: athrow
    //   568: iload #4
    //   570: ifne -> 609
    //   573: ifeq -> 591
    //   576: goto -> 580
    //   579: athrow
    //   580: iload_3
    //   581: bipush #8
    //   583: iadd
    //   584: istore #12
    //   586: iload #4
    //   588: ifeq -> 811
    //   591: sipush #29973
    //   594: sipush #-12970
    //   597: invokestatic a : (II)Ljava/lang/String;
    //   600: aload #21
    //   602: invokevirtual equals : (Ljava/lang/Object;)Z
    //   605: goto -> 609
    //   608: athrow
    //   609: iload #4
    //   611: ifne -> 650
    //   614: ifeq -> 632
    //   617: goto -> 621
    //   620: athrow
    //   621: iload_3
    //   622: bipush #8
    //   624: iadd
    //   625: istore #14
    //   627: iload #4
    //   629: ifeq -> 811
    //   632: sipush #29967
    //   635: sipush #-4407
    //   638: invokestatic a : (II)Ljava/lang/String;
    //   641: aload #21
    //   643: invokevirtual equals : (Ljava/lang/Object;)Z
    //   646: goto -> 650
    //   649: athrow
    //   650: iload #4
    //   652: ifne -> 691
    //   655: ifeq -> 673
    //   658: goto -> 662
    //   661: athrow
    //   662: iload_3
    //   663: bipush #8
    //   665: iadd
    //   666: istore #16
    //   668: iload #4
    //   670: ifeq -> 811
    //   673: sipush #29957
    //   676: sipush #-31518
    //   679: invokestatic a : (II)Ljava/lang/String;
    //   682: aload #21
    //   684: invokevirtual equals : (Ljava/lang/Object;)Z
    //   687: goto -> 691
    //   690: athrow
    //   691: iload #4
    //   693: ifne -> 732
    //   696: ifeq -> 714
    //   699: goto -> 703
    //   702: athrow
    //   703: iload_3
    //   704: bipush #8
    //   706: iadd
    //   707: istore #17
    //   709: iload #4
    //   711: ifeq -> 811
    //   714: sipush #29978
    //   717: sipush #32377
    //   720: invokestatic a : (II)Ljava/lang/String;
    //   723: aload #21
    //   725: invokevirtual equals : (Ljava/lang/Object;)Z
    //   728: goto -> 732
    //   731: athrow
    //   732: iload #4
    //   734: ifne -> 752
    //   737: ifeq -> 759
    //   740: goto -> 744
    //   743: athrow
    //   744: iload_3
    //   745: bipush #8
    //   747: iadd
    //   748: goto -> 752
    //   751: athrow
    //   752: istore #10
    //   754: iload #4
    //   756: ifeq -> 811
    //   759: aload_0
    //   760: aload_2
    //   761: getfield a : [Lorg/objectweb/asm/Attribute;
    //   764: aload #21
    //   766: iload_3
    //   767: bipush #8
    //   769: iadd
    //   770: aload_0
    //   771: iload_3
    //   772: iconst_4
    //   773: iadd
    //   774: invokevirtual readInt : (I)I
    //   777: aload #5
    //   779: iconst_m1
    //   780: aconst_null
    //   781: invokespecial a : ([Lorg/objectweb/asm/Attribute;Ljava/lang/String;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   784: astore #22
    //   786: iload #4
    //   788: ifne -> 827
    //   791: aload #22
    //   793: ifnull -> 811
    //   796: goto -> 800
    //   799: athrow
    //   800: aload #22
    //   802: aload #19
    //   804: putfield a : Lorg/objectweb/asm/Attribute;
    //   807: aload #22
    //   809: astore #19
    //   811: iload_3
    //   812: bipush #6
    //   814: aload_0
    //   815: iload_3
    //   816: iconst_4
    //   817: iadd
    //   818: invokevirtual readInt : (I)I
    //   821: iadd
    //   822: iadd
    //   823: istore_3
    //   824: iinc #20, -1
    //   827: iload #4
    //   829: ifeq -> 98
    //   832: iinc #3, 2
    //   835: aload_1
    //   836: aload_2
    //   837: getfield e : I
    //   840: aload_2
    //   841: getfield f : Ljava/lang/String;
    //   844: aload_2
    //   845: getfield g : Ljava/lang/String;
    //   848: aload #9
    //   850: aload #8
    //   852: invokevirtual visitMethod : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor;
    //   855: astore #20
    //   857: aload #20
    //   859: iload #4
    //   861: ifne -> 876
    //   864: ifnonnull -> 874
    //   867: goto -> 871
    //   870: athrow
    //   871: iload_3
    //   872: ireturn
    //   873: athrow
    //   874: aload #20
    //   876: instanceof org/objectweb/asm/MethodWriter
    //   879: iload #4
    //   881: ifne -> 1106
    //   884: ifeq -> 1104
    //   887: goto -> 891
    //   890: athrow
    //   891: aload #20
    //   893: checkcast org/objectweb/asm/MethodWriter
    //   896: astore #21
    //   898: aload #21
    //   900: getfield b : Lorg/objectweb/asm/ClassWriter;
    //   903: getfield K : Lorg/objectweb/asm/ClassReader;
    //   906: aload_0
    //   907: if_acmpne -> 1104
    //   910: aload #9
    //   912: aload #21
    //   914: getfield g : Ljava/lang/String;
    //   917: if_acmpne -> 1104
    //   920: goto -> 924
    //   923: athrow
    //   924: iconst_0
    //   925: istore #22
    //   927: aload #8
    //   929: iload #4
    //   931: ifne -> 980
    //   934: ifnonnull -> 974
    //   937: goto -> 941
    //   940: athrow
    //   941: aload #21
    //   943: getfield j : I
    //   946: iload #4
    //   948: ifne -> 963
    //   951: goto -> 955
    //   954: athrow
    //   955: ifne -> 966
    //   958: goto -> 962
    //   961: athrow
    //   962: iconst_1
    //   963: goto -> 967
    //   966: iconst_0
    //   967: istore #22
    //   969: iload #4
    //   971: ifeq -> 1071
    //   974: aload #8
    //   976: goto -> 980
    //   979: athrow
    //   980: arraylength
    //   981: iload #4
    //   983: ifne -> 1073
    //   986: aload #21
    //   988: getfield j : I
    //   991: if_icmpne -> 1071
    //   994: goto -> 998
    //   997: athrow
    //   998: iconst_1
    //   999: istore #22
    //   1001: aload #8
    //   1003: arraylength
    //   1004: iconst_1
    //   1005: isub
    //   1006: istore #23
    //   1008: iload #23
    //   1010: iflt -> 1071
    //   1013: iinc #7, -2
    //   1016: iload #4
    //   1018: ifne -> 1066
    //   1021: aload #21
    //   1023: getfield k : [I
    //   1026: iload #23
    //   1028: iaload
    //   1029: aload_0
    //   1030: iload #7
    //   1032: invokevirtual readUnsignedShort : (I)I
    //   1035: iload #4
    //   1037: ifne -> 1132
    //   1040: goto -> 1044
    //   1043: athrow
    //   1044: if_icmpeq -> 1059
    //   1047: goto -> 1051
    //   1050: athrow
    //   1051: iconst_0
    //   1052: istore #22
    //   1054: iload #4
    //   1056: ifeq -> 1071
    //   1059: iinc #23, -1
    //   1062: goto -> 1066
    //   1065: athrow
    //   1066: iload #4
    //   1068: ifeq -> 1008
    //   1071: iload #22
    //   1073: iload #4
    //   1075: ifne -> 1106
    //   1078: ifeq -> 1104
    //   1081: goto -> 1085
    //   1084: athrow
    //   1085: aload #21
    //   1087: iload #18
    //   1089: putfield h : I
    //   1092: aload #21
    //   1094: iload_3
    //   1095: iload #18
    //   1097: isub
    //   1098: putfield i : I
    //   1101: iload_3
    //   1102: ireturn
    //   1103: athrow
    //   1104: iload #10
    //   1106: iload #4
    //   1108: ifne -> 1192
    //   1111: ifeq -> 1190
    //   1114: goto -> 1118
    //   1117: athrow
    //   1118: aload_0
    //   1119: getfield b : [B
    //   1122: iload #10
    //   1124: baload
    //   1125: sipush #255
    //   1128: goto -> 1132
    //   1131: athrow
    //   1132: iand
    //   1133: istore #21
    //   1135: iload #10
    //   1137: iconst_1
    //   1138: iadd
    //   1139: istore #22
    //   1141: iload #21
    //   1143: ifle -> 1190
    //   1146: aload #20
    //   1148: aload_0
    //   1149: iload #22
    //   1151: aload #5
    //   1153: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1156: aload_0
    //   1157: iload #22
    //   1159: iconst_2
    //   1160: iadd
    //   1161: invokevirtual readUnsignedShort : (I)I
    //   1164: invokevirtual visitParameter : (Ljava/lang/String;I)V
    //   1167: iinc #21, -1
    //   1170: iload #22
    //   1172: iconst_4
    //   1173: iadd
    //   1174: istore #22
    //   1176: iload #4
    //   1178: ifne -> 1246
    //   1181: iload #4
    //   1183: ifeq -> 1141
    //   1186: goto -> 1190
    //   1189: athrow
    //   1190: iload #15
    //   1192: iload #4
    //   1194: ifne -> 1248
    //   1197: ifeq -> 1246
    //   1200: goto -> 1204
    //   1203: athrow
    //   1204: aload #20
    //   1206: invokevirtual visitAnnotationDefault : ()Lorg/objectweb/asm/AnnotationVisitor;
    //   1209: astore #21
    //   1211: aload_0
    //   1212: iload #15
    //   1214: aload #5
    //   1216: aconst_null
    //   1217: aload #21
    //   1219: invokespecial a : (I[CLjava/lang/String;Lorg/objectweb/asm/AnnotationVisitor;)I
    //   1222: iload #4
    //   1224: ifne -> 1248
    //   1227: pop
    //   1228: aload #21
    //   1230: ifnull -> 1246
    //   1233: goto -> 1237
    //   1236: athrow
    //   1237: aload #21
    //   1239: invokevirtual visitEnd : ()V
    //   1242: goto -> 1246
    //   1245: athrow
    //   1246: iload #11
    //   1248: iload #4
    //   1250: ifne -> 1325
    //   1253: ifeq -> 1323
    //   1256: goto -> 1260
    //   1259: athrow
    //   1260: aload_0
    //   1261: iload #11
    //   1263: invokevirtual readUnsignedShort : (I)I
    //   1266: istore #21
    //   1268: iload #11
    //   1270: iconst_2
    //   1271: iadd
    //   1272: istore #22
    //   1274: iload #21
    //   1276: ifle -> 1323
    //   1279: aload_0
    //   1280: iload #22
    //   1282: iconst_2
    //   1283: iadd
    //   1284: aload #5
    //   1286: iconst_1
    //   1287: aload #20
    //   1289: aload_0
    //   1290: iload #22
    //   1292: aload #5
    //   1294: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1297: iconst_1
    //   1298: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1301: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1304: istore #22
    //   1306: iinc #21, -1
    //   1309: iload #4
    //   1311: ifne -> 1400
    //   1314: iload #4
    //   1316: ifeq -> 1274
    //   1319: goto -> 1323
    //   1322: athrow
    //   1323: iload #12
    //   1325: iload #4
    //   1327: ifne -> 1402
    //   1330: ifeq -> 1400
    //   1333: goto -> 1337
    //   1336: athrow
    //   1337: aload_0
    //   1338: iload #12
    //   1340: invokevirtual readUnsignedShort : (I)I
    //   1343: istore #21
    //   1345: iload #12
    //   1347: iconst_2
    //   1348: iadd
    //   1349: istore #22
    //   1351: iload #21
    //   1353: ifle -> 1400
    //   1356: aload_0
    //   1357: iload #22
    //   1359: iconst_2
    //   1360: iadd
    //   1361: aload #5
    //   1363: iconst_1
    //   1364: aload #20
    //   1366: aload_0
    //   1367: iload #22
    //   1369: aload #5
    //   1371: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1374: iconst_0
    //   1375: invokevirtual visitAnnotation : (Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1378: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1381: istore #22
    //   1383: iinc #21, -1
    //   1386: iload #4
    //   1388: ifne -> 1494
    //   1391: iload #4
    //   1393: ifeq -> 1351
    //   1396: goto -> 1400
    //   1399: athrow
    //   1400: iload #13
    //   1402: iload #4
    //   1404: ifne -> 1496
    //   1407: ifeq -> 1494
    //   1410: goto -> 1414
    //   1413: athrow
    //   1414: aload_0
    //   1415: iload #13
    //   1417: invokevirtual readUnsignedShort : (I)I
    //   1420: istore #21
    //   1422: iload #13
    //   1424: iconst_2
    //   1425: iadd
    //   1426: istore #22
    //   1428: iload #21
    //   1430: ifle -> 1494
    //   1433: aload_0
    //   1434: aload_2
    //   1435: iload #22
    //   1437: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   1440: istore #22
    //   1442: aload_0
    //   1443: iload #22
    //   1445: iconst_2
    //   1446: iadd
    //   1447: aload #5
    //   1449: iconst_1
    //   1450: aload #20
    //   1452: aload_2
    //   1453: getfield i : I
    //   1456: aload_2
    //   1457: getfield j : Lorg/objectweb/asm/TypePath;
    //   1460: aload_0
    //   1461: iload #22
    //   1463: aload #5
    //   1465: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1468: iconst_1
    //   1469: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1472: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1475: istore #22
    //   1477: iinc #21, -1
    //   1480: iload #4
    //   1482: ifne -> 1588
    //   1485: iload #4
    //   1487: ifeq -> 1428
    //   1490: goto -> 1494
    //   1493: athrow
    //   1494: iload #14
    //   1496: iload #4
    //   1498: ifne -> 1590
    //   1501: ifeq -> 1588
    //   1504: goto -> 1508
    //   1507: athrow
    //   1508: aload_0
    //   1509: iload #14
    //   1511: invokevirtual readUnsignedShort : (I)I
    //   1514: istore #21
    //   1516: iload #14
    //   1518: iconst_2
    //   1519: iadd
    //   1520: istore #22
    //   1522: iload #21
    //   1524: ifle -> 1588
    //   1527: aload_0
    //   1528: aload_2
    //   1529: iload #22
    //   1531: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   1534: istore #22
    //   1536: aload_0
    //   1537: iload #22
    //   1539: iconst_2
    //   1540: iadd
    //   1541: aload #5
    //   1543: iconst_1
    //   1544: aload #20
    //   1546: aload_2
    //   1547: getfield i : I
    //   1550: aload_2
    //   1551: getfield j : Lorg/objectweb/asm/TypePath;
    //   1554: aload_0
    //   1555: iload #22
    //   1557: aload #5
    //   1559: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   1562: iconst_0
    //   1563: invokevirtual visitTypeAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   1566: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1569: istore #22
    //   1571: iinc #21, -1
    //   1574: iload #4
    //   1576: ifne -> 1616
    //   1579: iload #4
    //   1581: ifeq -> 1522
    //   1584: goto -> 1588
    //   1587: athrow
    //   1588: iload #16
    //   1590: iload #4
    //   1592: ifne -> 1618
    //   1595: ifeq -> 1616
    //   1598: goto -> 1602
    //   1601: athrow
    //   1602: aload_0
    //   1603: aload #20
    //   1605: aload_2
    //   1606: iload #16
    //   1608: iconst_1
    //   1609: invokespecial b : (Lorg/objectweb/asm/MethodVisitor;Lorg/objectweb/asm/Context;IZ)V
    //   1612: goto -> 1616
    //   1615: athrow
    //   1616: iload #17
    //   1618: ifeq -> 1635
    //   1621: aload_0
    //   1622: aload #20
    //   1624: aload_2
    //   1625: iload #17
    //   1627: iconst_0
    //   1628: invokespecial b : (Lorg/objectweb/asm/MethodVisitor;Lorg/objectweb/asm/Context;IZ)V
    //   1631: goto -> 1635
    //   1634: athrow
    //   1635: aload #19
    //   1637: ifnull -> 1678
    //   1640: aload #19
    //   1642: getfield a : Lorg/objectweb/asm/Attribute;
    //   1645: astore #21
    //   1647: aload #19
    //   1649: aconst_null
    //   1650: putfield a : Lorg/objectweb/asm/Attribute;
    //   1653: aload #20
    //   1655: aload #19
    //   1657: invokevirtual visitAttribute : (Lorg/objectweb/asm/Attribute;)V
    //   1660: aload #21
    //   1662: astore #19
    //   1664: iload #4
    //   1666: ifne -> 1715
    //   1669: iload #4
    //   1671: ifeq -> 1635
    //   1674: goto -> 1678
    //   1677: athrow
    //   1678: iload #6
    //   1680: iload #4
    //   1682: ifne -> 1716
    //   1685: ifeq -> 1710
    //   1688: goto -> 1692
    //   1691: athrow
    //   1692: aload #20
    //   1694: invokevirtual visitCode : ()V
    //   1697: aload_0
    //   1698: aload #20
    //   1700: aload_2
    //   1701: iload #6
    //   1703: invokespecial a : (Lorg/objectweb/asm/MethodVisitor;Lorg/objectweb/asm/Context;I)V
    //   1706: goto -> 1710
    //   1709: athrow
    //   1710: aload #20
    //   1712: invokevirtual visitEnd : ()V
    //   1715: iload_3
    //   1716: ireturn
    // Exception table:
    //   from	to	target	type
    //   114	138	141	java/lang/IllegalArgumentException
    //   119	145	148	java/lang/IllegalArgumentException
    //   142	160	163	java/lang/IllegalArgumentException
    //   149	167	170	java/lang/IllegalArgumentException
    //   177	196	199	java/lang/IllegalArgumentException
    //   200	208	211	java/lang/IllegalArgumentException
    //   242	271	274	java/lang/IllegalArgumentException
    //   275	294	297	java/lang/IllegalArgumentException
    //   298	306	309	java/lang/IllegalArgumentException
    //   322	341	344	java/lang/IllegalArgumentException
    //   345	353	356	java/lang/IllegalArgumentException
    //   350	373	376	java/lang/IllegalArgumentException
    //   357	391	394	java/lang/IllegalArgumentException
    //   395	403	406	java/lang/IllegalArgumentException
    //   413	432	435	java/lang/IllegalArgumentException
    //   436	444	447	java/lang/IllegalArgumentException
    //   454	473	476	java/lang/IllegalArgumentException
    //   477	485	488	java/lang/IllegalArgumentException
    //   495	514	517	java/lang/IllegalArgumentException
    //   518	526	529	java/lang/IllegalArgumentException
    //   523	546	549	java/lang/IllegalArgumentException
    //   530	564	567	java/lang/IllegalArgumentException
    //   568	576	579	java/lang/IllegalArgumentException
    //   586	605	608	java/lang/IllegalArgumentException
    //   609	617	620	java/lang/IllegalArgumentException
    //   627	646	649	java/lang/IllegalArgumentException
    //   650	658	661	java/lang/IllegalArgumentException
    //   668	687	690	java/lang/IllegalArgumentException
    //   691	699	702	java/lang/IllegalArgumentException
    //   709	728	731	java/lang/IllegalArgumentException
    //   732	740	743	java/lang/IllegalArgumentException
    //   737	748	751	java/lang/IllegalArgumentException
    //   786	796	799	java/lang/IllegalArgumentException
    //   857	867	870	java/lang/IllegalArgumentException
    //   864	873	873	java/lang/IllegalArgumentException
    //   876	887	890	java/lang/IllegalArgumentException
    //   898	920	923	java/lang/IllegalArgumentException
    //   927	937	940	java/lang/IllegalArgumentException
    //   934	951	954	java/lang/IllegalArgumentException
    //   941	958	961	java/lang/IllegalArgumentException
    //   969	976	979	java/lang/IllegalArgumentException
    //   980	994	997	java/lang/IllegalArgumentException
    //   1013	1040	1043	java/lang/IllegalArgumentException
    //   1021	1047	1050	java/lang/IllegalArgumentException
    //   1054	1062	1065	java/lang/IllegalArgumentException
    //   1073	1081	1084	java/lang/IllegalArgumentException
    //   1078	1103	1103	java/lang/IllegalArgumentException
    //   1106	1114	1117	java/lang/IllegalArgumentException
    //   1111	1128	1131	java/lang/IllegalArgumentException
    //   1176	1186	1189	java/lang/IllegalArgumentException
    //   1192	1200	1203	java/lang/IllegalArgumentException
    //   1211	1233	1236	java/lang/IllegalArgumentException
    //   1227	1242	1245	java/lang/IllegalArgumentException
    //   1248	1256	1259	java/lang/IllegalArgumentException
    //   1306	1319	1322	java/lang/IllegalArgumentException
    //   1325	1333	1336	java/lang/IllegalArgumentException
    //   1383	1396	1399	java/lang/IllegalArgumentException
    //   1402	1410	1413	java/lang/IllegalArgumentException
    //   1477	1490	1493	java/lang/IllegalArgumentException
    //   1496	1504	1507	java/lang/IllegalArgumentException
    //   1571	1584	1587	java/lang/IllegalArgumentException
    //   1590	1598	1601	java/lang/IllegalArgumentException
    //   1595	1612	1615	java/lang/IllegalArgumentException
    //   1618	1631	1634	java/lang/IllegalArgumentException
    //   1664	1674	1677	java/lang/IllegalArgumentException
    //   1678	1688	1691	java/lang/IllegalArgumentException
    //   1685	1706	1709	java/lang/IllegalArgumentException
  }
  
  private void a(MethodVisitor paramMethodVisitor, Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : [B
    //   4: astore #5
    //   6: aload_2
    //   7: getfield c : [C
    //   10: astore #6
    //   12: aload_0
    //   13: iload_3
    //   14: invokevirtual readUnsignedShort : (I)I
    //   17: istore #7
    //   19: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   22: aload_0
    //   23: iload_3
    //   24: iconst_2
    //   25: iadd
    //   26: invokevirtual readUnsignedShort : (I)I
    //   29: istore #8
    //   31: istore #4
    //   33: aload_0
    //   34: iload_3
    //   35: iconst_4
    //   36: iadd
    //   37: invokevirtual readInt : (I)I
    //   40: istore #9
    //   42: iinc #3, 8
    //   45: iload_3
    //   46: istore #10
    //   48: iload_3
    //   49: iload #9
    //   51: iadd
    //   52: istore #11
    //   54: aload_2
    //   55: iload #9
    //   57: iconst_2
    //   58: iadd
    //   59: anewarray org/objectweb/asm/Label
    //   62: dup_x1
    //   63: putfield h : [Lorg/objectweb/asm/Label;
    //   66: astore #12
    //   68: aload_0
    //   69: iload #9
    //   71: iconst_1
    //   72: iadd
    //   73: aload #12
    //   75: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   78: pop
    //   79: iload_3
    //   80: iload #11
    //   82: if_icmpge -> 588
    //   85: iload_3
    //   86: iload #10
    //   88: isub
    //   89: istore #13
    //   91: aload #5
    //   93: iload_3
    //   94: baload
    //   95: sipush #255
    //   98: iand
    //   99: istore #14
    //   101: iload #4
    //   103: ifne -> 216
    //   106: getstatic org/objectweb/asm/ClassWriter.a : [B
    //   109: iload #14
    //   111: baload
    //   112: iload #4
    //   114: ifne -> 593
    //   117: goto -> 121
    //   120: athrow
    //   121: tableswitch default -> 576, 0 -> 213, 1 -> 540, 2 -> 552, 3 -> 540, 4 -> 213, 5 -> 552, 6 -> 552, 7 -> 564, 8 -> 564, 9 -> 221, 10 -> 279, 11 -> 540, 12 -> 552, 13 -> 552, 14 -> 361, 15 -> 456, 16 -> 576, 17 -> 308, 18 -> 250
    //   212: athrow
    //   213: iinc #3, 1
    //   216: iload #4
    //   218: ifeq -> 583
    //   221: aload_0
    //   222: iload #13
    //   224: aload_0
    //   225: iload_3
    //   226: iconst_1
    //   227: iadd
    //   228: invokevirtual readShort : (I)S
    //   231: iadd
    //   232: aload #12
    //   234: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   237: pop
    //   238: iinc #3, 3
    //   241: iload #4
    //   243: ifeq -> 583
    //   246: goto -> 250
    //   249: athrow
    //   250: aload_0
    //   251: iload #13
    //   253: aload_0
    //   254: iload_3
    //   255: iconst_1
    //   256: iadd
    //   257: invokevirtual readUnsignedShort : (I)I
    //   260: iadd
    //   261: aload #12
    //   263: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   266: pop
    //   267: iinc #3, 3
    //   270: iload #4
    //   272: ifeq -> 583
    //   275: goto -> 279
    //   278: athrow
    //   279: aload_0
    //   280: iload #13
    //   282: aload_0
    //   283: iload_3
    //   284: iconst_1
    //   285: iadd
    //   286: invokevirtual readInt : (I)I
    //   289: iadd
    //   290: aload #12
    //   292: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   295: pop
    //   296: iinc #3, 5
    //   299: iload #4
    //   301: ifeq -> 583
    //   304: goto -> 308
    //   307: athrow
    //   308: aload #5
    //   310: iload_3
    //   311: iconst_1
    //   312: iadd
    //   313: baload
    //   314: sipush #255
    //   317: iand
    //   318: istore #14
    //   320: iload #4
    //   322: ifne -> 356
    //   325: iload #14
    //   327: sipush #132
    //   330: if_icmpne -> 349
    //   333: goto -> 337
    //   336: athrow
    //   337: iinc #3, 6
    //   340: iload #4
    //   342: ifeq -> 583
    //   345: goto -> 349
    //   348: athrow
    //   349: iinc #3, 4
    //   352: goto -> 356
    //   355: athrow
    //   356: iload #4
    //   358: ifeq -> 583
    //   361: iload_3
    //   362: iconst_4
    //   363: iadd
    //   364: iload #13
    //   366: iconst_3
    //   367: iand
    //   368: isub
    //   369: istore_3
    //   370: aload_0
    //   371: iload #13
    //   373: aload_0
    //   374: iload_3
    //   375: invokevirtual readInt : (I)I
    //   378: iadd
    //   379: aload #12
    //   381: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   384: pop
    //   385: aload_0
    //   386: iload_3
    //   387: bipush #8
    //   389: iadd
    //   390: invokevirtual readInt : (I)I
    //   393: aload_0
    //   394: iload_3
    //   395: iconst_4
    //   396: iadd
    //   397: invokevirtual readInt : (I)I
    //   400: isub
    //   401: iconst_1
    //   402: iadd
    //   403: istore #15
    //   405: iload #15
    //   407: ifle -> 448
    //   410: aload_0
    //   411: iload #13
    //   413: aload_0
    //   414: iload_3
    //   415: bipush #12
    //   417: iadd
    //   418: invokevirtual readInt : (I)I
    //   421: iadd
    //   422: aload #12
    //   424: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   427: pop
    //   428: iinc #3, 4
    //   431: iinc #15, -1
    //   434: iload #4
    //   436: ifne -> 451
    //   439: iload #4
    //   441: ifeq -> 405
    //   444: goto -> 448
    //   447: athrow
    //   448: iinc #3, 12
    //   451: iload #4
    //   453: ifeq -> 583
    //   456: iload_3
    //   457: iconst_4
    //   458: iadd
    //   459: iload #13
    //   461: iconst_3
    //   462: iand
    //   463: isub
    //   464: istore_3
    //   465: aload_0
    //   466: iload #13
    //   468: aload_0
    //   469: iload_3
    //   470: invokevirtual readInt : (I)I
    //   473: iadd
    //   474: aload #12
    //   476: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   479: pop
    //   480: aload_0
    //   481: iload_3
    //   482: iconst_4
    //   483: iadd
    //   484: invokevirtual readInt : (I)I
    //   487: istore #15
    //   489: iload #15
    //   491: ifle -> 532
    //   494: aload_0
    //   495: iload #13
    //   497: aload_0
    //   498: iload_3
    //   499: bipush #12
    //   501: iadd
    //   502: invokevirtual readInt : (I)I
    //   505: iadd
    //   506: aload #12
    //   508: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   511: pop
    //   512: iinc #3, 8
    //   515: iinc #15, -1
    //   518: iload #4
    //   520: ifne -> 535
    //   523: iload #4
    //   525: ifeq -> 489
    //   528: goto -> 532
    //   531: athrow
    //   532: iinc #3, 8
    //   535: iload #4
    //   537: ifeq -> 583
    //   540: iinc #3, 2
    //   543: iload #4
    //   545: ifeq -> 583
    //   548: goto -> 552
    //   551: athrow
    //   552: iinc #3, 3
    //   555: iload #4
    //   557: ifeq -> 583
    //   560: goto -> 564
    //   563: athrow
    //   564: iinc #3, 5
    //   567: iload #4
    //   569: ifeq -> 583
    //   572: goto -> 576
    //   575: athrow
    //   576: iinc #3, 4
    //   579: goto -> 583
    //   582: athrow
    //   583: iload #4
    //   585: ifeq -> 79
    //   588: aload_0
    //   589: iload_3
    //   590: invokevirtual readUnsignedShort : (I)I
    //   593: istore #13
    //   595: iload #13
    //   597: ifle -> 699
    //   600: aload_0
    //   601: aload_0
    //   602: iload_3
    //   603: iconst_2
    //   604: iadd
    //   605: invokevirtual readUnsignedShort : (I)I
    //   608: aload #12
    //   610: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   613: astore #14
    //   615: aload_0
    //   616: aload_0
    //   617: iload_3
    //   618: iconst_4
    //   619: iadd
    //   620: invokevirtual readUnsignedShort : (I)I
    //   623: aload #12
    //   625: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   628: astore #15
    //   630: aload_0
    //   631: aload_0
    //   632: iload_3
    //   633: bipush #6
    //   635: iadd
    //   636: invokevirtual readUnsignedShort : (I)I
    //   639: aload #12
    //   641: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   644: astore #16
    //   646: aload_0
    //   647: aload_0
    //   648: getfield a : [I
    //   651: aload_0
    //   652: iload_3
    //   653: bipush #8
    //   655: iadd
    //   656: invokevirtual readUnsignedShort : (I)I
    //   659: iaload
    //   660: aload #6
    //   662: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   665: astore #17
    //   667: aload_1
    //   668: aload #14
    //   670: aload #15
    //   672: aload #16
    //   674: aload #17
    //   676: invokevirtual visitTryCatchBlock : (Lorg/objectweb/asm/Label;Lorg/objectweb/asm/Label;Lorg/objectweb/asm/Label;Ljava/lang/String;)V
    //   679: iinc #3, 8
    //   682: iinc #13, -1
    //   685: iload #4
    //   687: ifne -> 702
    //   690: iload #4
    //   692: ifeq -> 595
    //   695: goto -> 699
    //   698: athrow
    //   699: iinc #3, 2
    //   702: aconst_null
    //   703: astore #13
    //   705: aconst_null
    //   706: astore #14
    //   708: iconst_0
    //   709: istore #15
    //   711: iconst_0
    //   712: istore #16
    //   714: iconst_m1
    //   715: istore #17
    //   717: iconst_m1
    //   718: istore #18
    //   720: iconst_0
    //   721: istore #19
    //   723: iconst_0
    //   724: istore #20
    //   726: iconst_1
    //   727: istore #21
    //   729: aload_2
    //   730: getfield b : I
    //   733: bipush #8
    //   735: iand
    //   736: iload #4
    //   738: ifne -> 749
    //   741: ifeq -> 752
    //   744: goto -> 748
    //   747: athrow
    //   748: iconst_1
    //   749: goto -> 753
    //   752: iconst_0
    //   753: istore #22
    //   755: iconst_0
    //   756: istore #23
    //   758: iconst_0
    //   759: istore #24
    //   761: iconst_0
    //   762: istore #25
    //   764: aconst_null
    //   765: astore #26
    //   767: aconst_null
    //   768: astore #27
    //   770: aload_0
    //   771: iload_3
    //   772: invokevirtual readUnsignedShort : (I)I
    //   775: istore #28
    //   777: iload #28
    //   779: ifle -> 1789
    //   782: aload_0
    //   783: iload_3
    //   784: iconst_2
    //   785: iadd
    //   786: aload #6
    //   788: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   791: astore #29
    //   793: sipush #29959
    //   796: sipush #21236
    //   799: invokestatic a : (II)Ljava/lang/String;
    //   802: aload #29
    //   804: invokevirtual equals : (Ljava/lang/Object;)Z
    //   807: iload #4
    //   809: ifne -> 1794
    //   812: iload #4
    //   814: ifne -> 1014
    //   817: goto -> 821
    //   820: athrow
    //   821: ifeq -> 996
    //   824: goto -> 828
    //   827: athrow
    //   828: aload_2
    //   829: getfield b : I
    //   832: iconst_2
    //   833: iand
    //   834: iload #4
    //   836: ifne -> 1780
    //   839: goto -> 843
    //   842: athrow
    //   843: ifne -> 1768
    //   846: goto -> 850
    //   849: athrow
    //   850: iload_3
    //   851: bipush #8
    //   853: iadd
    //   854: istore #19
    //   856: aload_0
    //   857: iload_3
    //   858: bipush #8
    //   860: iadd
    //   861: invokevirtual readUnsignedShort : (I)I
    //   864: istore #30
    //   866: iload_3
    //   867: istore #31
    //   869: iload #30
    //   871: ifle -> 991
    //   874: aload_0
    //   875: iload #31
    //   877: bipush #10
    //   879: iadd
    //   880: invokevirtual readUnsignedShort : (I)I
    //   883: istore #32
    //   885: aload #12
    //   887: iload #32
    //   889: aaload
    //   890: iload #4
    //   892: ifne -> 1123
    //   895: iload #4
    //   897: ifne -> 956
    //   900: goto -> 904
    //   903: athrow
    //   904: ifnonnull -> 928
    //   907: aload_0
    //   908: iload #32
    //   910: aload #12
    //   912: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   915: dup
    //   916: getfield a : I
    //   919: iconst_1
    //   920: ior
    //   921: putfield a : I
    //   924: goto -> 928
    //   927: athrow
    //   928: iload #32
    //   930: aload_0
    //   931: iload #31
    //   933: bipush #12
    //   935: iadd
    //   936: invokevirtual readUnsignedShort : (I)I
    //   939: iadd
    //   940: istore #32
    //   942: iload #4
    //   944: ifne -> 986
    //   947: aload #12
    //   949: iload #32
    //   951: aaload
    //   952: goto -> 956
    //   955: athrow
    //   956: ifnonnull -> 980
    //   959: aload_0
    //   960: iload #32
    //   962: aload #12
    //   964: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   967: dup
    //   968: getfield a : I
    //   971: iconst_1
    //   972: ior
    //   973: putfield a : I
    //   976: goto -> 980
    //   979: athrow
    //   980: iinc #31, 10
    //   983: iinc #30, -1
    //   986: iload #4
    //   988: ifeq -> 869
    //   991: iload #4
    //   993: ifeq -> 1768
    //   996: sipush #29966
    //   999: sipush #15936
    //   1002: invokestatic a : (II)Ljava/lang/String;
    //   1005: aload #29
    //   1007: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1010: goto -> 1014
    //   1013: athrow
    //   1014: iload #4
    //   1016: ifne -> 1055
    //   1019: ifeq -> 1037
    //   1022: goto -> 1026
    //   1025: athrow
    //   1026: iload_3
    //   1027: bipush #8
    //   1029: iadd
    //   1030: istore #20
    //   1032: iload #4
    //   1034: ifeq -> 1768
    //   1037: sipush #29956
    //   1040: sipush #32018
    //   1043: invokestatic a : (II)Ljava/lang/String;
    //   1046: aload #29
    //   1048: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1051: goto -> 1055
    //   1054: athrow
    //   1055: iload #4
    //   1057: ifne -> 1278
    //   1060: ifeq -> 1260
    //   1063: goto -> 1067
    //   1066: athrow
    //   1067: aload_2
    //   1068: getfield b : I
    //   1071: iconst_2
    //   1072: iand
    //   1073: iload #4
    //   1075: ifne -> 1780
    //   1078: goto -> 1082
    //   1081: athrow
    //   1082: ifne -> 1768
    //   1085: goto -> 1089
    //   1088: athrow
    //   1089: aload_0
    //   1090: iload_3
    //   1091: bipush #8
    //   1093: iadd
    //   1094: invokevirtual readUnsignedShort : (I)I
    //   1097: istore #30
    //   1099: iload_3
    //   1100: istore #31
    //   1102: iload #30
    //   1104: ifle -> 1255
    //   1107: aload_0
    //   1108: iload #31
    //   1110: bipush #10
    //   1112: iadd
    //   1113: invokevirtual readUnsignedShort : (I)I
    //   1116: istore #32
    //   1118: aload #12
    //   1120: iload #32
    //   1122: aaload
    //   1123: iload #4
    //   1125: ifne -> 895
    //   1128: iload #4
    //   1130: ifne -> 1166
    //   1133: ifnonnull -> 1161
    //   1136: goto -> 1140
    //   1139: athrow
    //   1140: aload_0
    //   1141: iload #32
    //   1143: aload #12
    //   1145: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   1148: dup
    //   1149: getfield a : I
    //   1152: iconst_1
    //   1153: ior
    //   1154: putfield a : I
    //   1157: goto -> 1161
    //   1160: athrow
    //   1161: aload #12
    //   1163: iload #32
    //   1165: aaload
    //   1166: astore #33
    //   1168: aload #33
    //   1170: getfield b : I
    //   1173: ifle -> 1230
    //   1176: aload #33
    //   1178: getfield k : Lorg/objectweb/asm/Label;
    //   1181: iload #4
    //   1183: ifne -> 1232
    //   1186: iload #4
    //   1188: ifne -> 1223
    //   1191: goto -> 1195
    //   1194: athrow
    //   1195: ifnonnull -> 1218
    //   1198: goto -> 1202
    //   1201: athrow
    //   1202: aload #33
    //   1204: new org/objectweb/asm/Label
    //   1207: dup
    //   1208: invokespecial <init> : ()V
    //   1211: putfield k : Lorg/objectweb/asm/Label;
    //   1214: goto -> 1218
    //   1217: athrow
    //   1218: aload #33
    //   1220: getfield k : Lorg/objectweb/asm/Label;
    //   1223: astore #33
    //   1225: iload #4
    //   1227: ifeq -> 1168
    //   1230: aload #33
    //   1232: aload_0
    //   1233: iload #31
    //   1235: bipush #12
    //   1237: iadd
    //   1238: invokevirtual readUnsignedShort : (I)I
    //   1241: putfield b : I
    //   1244: iinc #31, 4
    //   1247: iinc #30, -1
    //   1250: iload #4
    //   1252: ifeq -> 1102
    //   1255: iload #4
    //   1257: ifeq -> 1768
    //   1260: sipush #29979
    //   1263: sipush #14533
    //   1266: invokestatic a : (II)Ljava/lang/String;
    //   1269: aload #29
    //   1271: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1274: goto -> 1278
    //   1277: athrow
    //   1278: iload #4
    //   1280: ifne -> 1387
    //   1283: ifeq -> 1369
    //   1286: goto -> 1290
    //   1289: athrow
    //   1290: aload_0
    //   1291: aload_1
    //   1292: aload_2
    //   1293: iload_3
    //   1294: bipush #8
    //   1296: iadd
    //   1297: iconst_1
    //   1298: invokespecial a : (Lorg/objectweb/asm/MethodVisitor;Lorg/objectweb/asm/Context;IZ)[I
    //   1301: astore #13
    //   1303: aload #13
    //   1305: arraylength
    //   1306: iload #4
    //   1308: ifne -> 1349
    //   1311: ifeq -> 1344
    //   1314: goto -> 1318
    //   1317: athrow
    //   1318: aload_0
    //   1319: aload #13
    //   1321: iconst_0
    //   1322: iaload
    //   1323: iload #4
    //   1325: ifne -> 1359
    //   1328: goto -> 1332
    //   1331: athrow
    //   1332: invokevirtual readByte : (I)I
    //   1335: bipush #67
    //   1337: if_icmpge -> 1352
    //   1340: goto -> 1344
    //   1343: athrow
    //   1344: iconst_m1
    //   1345: goto -> 1349
    //   1348: athrow
    //   1349: goto -> 1362
    //   1352: aload_0
    //   1353: aload #13
    //   1355: iconst_0
    //   1356: iaload
    //   1357: iconst_1
    //   1358: iadd
    //   1359: invokevirtual readUnsignedShort : (I)I
    //   1362: istore #17
    //   1364: iload #4
    //   1366: ifeq -> 1768
    //   1369: sipush #29973
    //   1372: sipush #-12970
    //   1375: invokestatic a : (II)Ljava/lang/String;
    //   1378: aload #29
    //   1380: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1383: goto -> 1387
    //   1386: athrow
    //   1387: iload #4
    //   1389: ifne -> 1496
    //   1392: ifeq -> 1478
    //   1395: goto -> 1399
    //   1398: athrow
    //   1399: aload_0
    //   1400: aload_1
    //   1401: aload_2
    //   1402: iload_3
    //   1403: bipush #8
    //   1405: iadd
    //   1406: iconst_0
    //   1407: invokespecial a : (Lorg/objectweb/asm/MethodVisitor;Lorg/objectweb/asm/Context;IZ)[I
    //   1410: astore #14
    //   1412: aload #14
    //   1414: arraylength
    //   1415: iload #4
    //   1417: ifne -> 1458
    //   1420: ifeq -> 1453
    //   1423: goto -> 1427
    //   1426: athrow
    //   1427: aload_0
    //   1428: aload #14
    //   1430: iconst_0
    //   1431: iaload
    //   1432: iload #4
    //   1434: ifne -> 1468
    //   1437: goto -> 1441
    //   1440: athrow
    //   1441: invokevirtual readByte : (I)I
    //   1444: bipush #67
    //   1446: if_icmpge -> 1461
    //   1449: goto -> 1453
    //   1452: athrow
    //   1453: iconst_m1
    //   1454: goto -> 1458
    //   1457: athrow
    //   1458: goto -> 1471
    //   1461: aload_0
    //   1462: aload #14
    //   1464: iconst_0
    //   1465: iaload
    //   1466: iconst_1
    //   1467: iadd
    //   1468: invokevirtual readUnsignedShort : (I)I
    //   1471: istore #18
    //   1473: iload #4
    //   1475: ifeq -> 1768
    //   1478: sipush #29960
    //   1481: sipush #1215
    //   1484: invokestatic a : (II)Ljava/lang/String;
    //   1487: aload #29
    //   1489: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1492: goto -> 1496
    //   1495: athrow
    //   1496: iload #4
    //   1498: ifne -> 1578
    //   1501: ifeq -> 1560
    //   1504: goto -> 1508
    //   1507: athrow
    //   1508: aload_2
    //   1509: getfield b : I
    //   1512: iconst_4
    //   1513: iand
    //   1514: iload #4
    //   1516: ifne -> 1780
    //   1519: goto -> 1523
    //   1522: athrow
    //   1523: ifne -> 1768
    //   1526: goto -> 1530
    //   1529: athrow
    //   1530: iload_3
    //   1531: bipush #10
    //   1533: iadd
    //   1534: istore #23
    //   1536: aload_0
    //   1537: iload_3
    //   1538: iconst_4
    //   1539: iadd
    //   1540: invokevirtual readInt : (I)I
    //   1543: istore #24
    //   1545: aload_0
    //   1546: iload_3
    //   1547: bipush #8
    //   1549: iadd
    //   1550: invokevirtual readUnsignedShort : (I)I
    //   1553: istore #25
    //   1555: iload #4
    //   1557: ifeq -> 1768
    //   1560: sipush #29952
    //   1563: sipush #14308
    //   1566: invokestatic a : (II)Ljava/lang/String;
    //   1569: aload #29
    //   1571: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1574: goto -> 1578
    //   1577: athrow
    //   1578: iload #4
    //   1580: ifne -> 1650
    //   1583: ifeq -> 1645
    //   1586: goto -> 1590
    //   1589: athrow
    //   1590: aload_2
    //   1591: getfield b : I
    //   1594: iconst_4
    //   1595: iand
    //   1596: iload #4
    //   1598: ifne -> 1780
    //   1601: goto -> 1605
    //   1604: athrow
    //   1605: ifne -> 1768
    //   1608: goto -> 1612
    //   1611: athrow
    //   1612: iconst_0
    //   1613: istore #21
    //   1615: iload_3
    //   1616: bipush #10
    //   1618: iadd
    //   1619: istore #23
    //   1621: aload_0
    //   1622: iload_3
    //   1623: iconst_4
    //   1624: iadd
    //   1625: invokevirtual readInt : (I)I
    //   1628: istore #24
    //   1630: aload_0
    //   1631: iload_3
    //   1632: bipush #8
    //   1634: iadd
    //   1635: invokevirtual readUnsignedShort : (I)I
    //   1638: istore #25
    //   1640: iload #4
    //   1642: ifeq -> 1768
    //   1645: iconst_0
    //   1646: goto -> 1650
    //   1649: athrow
    //   1650: istore #30
    //   1652: iload #30
    //   1654: aload_2
    //   1655: getfield a : [Lorg/objectweb/asm/Attribute;
    //   1658: arraylength
    //   1659: if_icmpge -> 1768
    //   1662: aload_2
    //   1663: getfield a : [Lorg/objectweb/asm/Attribute;
    //   1666: iload #30
    //   1668: aaload
    //   1669: iload #4
    //   1671: ifne -> 1733
    //   1674: getfield type : Ljava/lang/String;
    //   1677: aload #29
    //   1679: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1682: iload #4
    //   1684: ifne -> 1780
    //   1687: goto -> 1691
    //   1690: athrow
    //   1691: ifeq -> 1760
    //   1694: goto -> 1698
    //   1697: athrow
    //   1698: aload_2
    //   1699: getfield a : [Lorg/objectweb/asm/Attribute;
    //   1702: iload #30
    //   1704: aaload
    //   1705: aload_0
    //   1706: iload_3
    //   1707: bipush #8
    //   1709: iadd
    //   1710: aload_0
    //   1711: iload_3
    //   1712: iconst_4
    //   1713: iadd
    //   1714: invokevirtual readInt : (I)I
    //   1717: aload #6
    //   1719: iload #10
    //   1721: bipush #8
    //   1723: isub
    //   1724: aload #12
    //   1726: invokevirtual read : (Lorg/objectweb/asm/ClassReader;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   1729: goto -> 1733
    //   1732: athrow
    //   1733: astore #31
    //   1735: iload #4
    //   1737: ifne -> 1763
    //   1740: aload #31
    //   1742: ifnull -> 1760
    //   1745: goto -> 1749
    //   1748: athrow
    //   1749: aload #31
    //   1751: aload #27
    //   1753: putfield a : Lorg/objectweb/asm/Attribute;
    //   1756: aload #31
    //   1758: astore #27
    //   1760: iinc #30, 1
    //   1763: iload #4
    //   1765: ifeq -> 1652
    //   1768: iload_3
    //   1769: bipush #6
    //   1771: aload_0
    //   1772: iload_3
    //   1773: iconst_4
    //   1774: iadd
    //   1775: invokevirtual readInt : (I)I
    //   1778: iadd
    //   1779: iadd
    //   1780: istore_3
    //   1781: iinc #28, -1
    //   1784: iload #4
    //   1786: ifeq -> 777
    //   1789: iinc #3, 2
    //   1792: iload #23
    //   1794: ifeq -> 2008
    //   1797: aload_2
    //   1798: astore #26
    //   1800: aload #26
    //   1802: iconst_m1
    //   1803: putfield o : I
    //   1806: aload #26
    //   1808: iconst_0
    //   1809: putfield p : I
    //   1812: aload #26
    //   1814: iconst_0
    //   1815: putfield q : I
    //   1818: aload #26
    //   1820: iconst_0
    //   1821: putfield r : I
    //   1824: aload #26
    //   1826: iconst_0
    //   1827: putfield t : I
    //   1830: aload #26
    //   1832: iload #8
    //   1834: anewarray java/lang/Object
    //   1837: putfield s : [Ljava/lang/Object;
    //   1840: aload #26
    //   1842: iload #7
    //   1844: anewarray java/lang/Object
    //   1847: putfield u : [Ljava/lang/Object;
    //   1850: iload #22
    //   1852: iload #4
    //   1854: ifne -> 1875
    //   1857: ifeq -> 1873
    //   1860: goto -> 1864
    //   1863: athrow
    //   1864: aload_0
    //   1865: aload_2
    //   1866: invokespecial a : (Lorg/objectweb/asm/Context;)V
    //   1869: goto -> 1873
    //   1872: athrow
    //   1873: iload #23
    //   1875: istore #28
    //   1877: iload #28
    //   1879: iload #23
    //   1881: iload #24
    //   1883: iadd
    //   1884: iconst_2
    //   1885: isub
    //   1886: if_icmpge -> 2008
    //   1889: aload #5
    //   1891: iload #28
    //   1893: baload
    //   1894: iload #4
    //   1896: ifne -> 1929
    //   1899: bipush #8
    //   1901: iload #4
    //   1903: ifne -> 2015
    //   1906: goto -> 1910
    //   1909: athrow
    //   1910: if_icmpne -> 2000
    //   1913: goto -> 1917
    //   1916: athrow
    //   1917: aload_0
    //   1918: iload #28
    //   1920: iconst_1
    //   1921: iadd
    //   1922: invokevirtual readUnsignedShort : (I)I
    //   1925: goto -> 1929
    //   1928: athrow
    //   1929: istore #29
    //   1931: iload #4
    //   1933: ifne -> 2003
    //   1936: iload #29
    //   1938: iflt -> 2000
    //   1941: goto -> 1945
    //   1944: athrow
    //   1945: iload #29
    //   1947: iload #9
    //   1949: iload #4
    //   1951: ifne -> 1984
    //   1954: goto -> 1958
    //   1957: athrow
    //   1958: if_icmpge -> 2000
    //   1961: goto -> 1965
    //   1964: athrow
    //   1965: aload #5
    //   1967: iload #10
    //   1969: iload #29
    //   1971: iadd
    //   1972: baload
    //   1973: sipush #255
    //   1976: iand
    //   1977: sipush #187
    //   1980: goto -> 1984
    //   1983: athrow
    //   1984: if_icmpne -> 2000
    //   1987: aload_0
    //   1988: iload #29
    //   1990: aload #12
    //   1992: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   1995: pop
    //   1996: goto -> 2000
    //   1999: athrow
    //   2000: iinc #28, 1
    //   2003: iload #4
    //   2005: ifeq -> 1877
    //   2008: aload_2
    //   2009: getfield b : I
    //   2012: sipush #256
    //   2015: iand
    //   2016: iload #4
    //   2018: ifne -> 2050
    //   2021: ifeq -> 2042
    //   2024: goto -> 2028
    //   2027: athrow
    //   2028: aload_1
    //   2029: iconst_m1
    //   2030: iload #8
    //   2032: aconst_null
    //   2033: iconst_0
    //   2034: aconst_null
    //   2035: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
    //   2038: goto -> 2042
    //   2041: athrow
    //   2042: aload_2
    //   2043: getfield b : I
    //   2046: sipush #256
    //   2049: iand
    //   2050: iload #4
    //   2052: ifne -> 2064
    //   2055: ifne -> 2067
    //   2058: goto -> 2062
    //   2061: athrow
    //   2062: bipush #-33
    //   2064: goto -> 2068
    //   2067: iconst_0
    //   2068: istore #28
    //   2070: iload #10
    //   2072: istore_3
    //   2073: iload_3
    //   2074: iload #11
    //   2076: if_icmpge -> 4223
    //   2079: iload_3
    //   2080: iload #10
    //   2082: isub
    //   2083: istore #29
    //   2085: aload #12
    //   2087: iload #29
    //   2089: aaload
    //   2090: astore #30
    //   2092: aload #30
    //   2094: iload #4
    //   2096: ifne -> 4228
    //   2099: iload #4
    //   2101: ifne -> 2124
    //   2104: goto -> 2108
    //   2107: athrow
    //   2108: ifnull -> 2220
    //   2111: goto -> 2115
    //   2114: athrow
    //   2115: aload #30
    //   2117: getfield k : Lorg/objectweb/asm/Label;
    //   2120: goto -> 2124
    //   2123: athrow
    //   2124: astore #31
    //   2126: aload #30
    //   2128: aconst_null
    //   2129: putfield k : Lorg/objectweb/asm/Label;
    //   2132: aload_1
    //   2133: aload #30
    //   2135: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   2138: aload_2
    //   2139: iload #4
    //   2141: ifne -> 2222
    //   2144: getfield b : I
    //   2147: iconst_2
    //   2148: iand
    //   2149: ifne -> 2220
    //   2152: goto -> 2156
    //   2155: athrow
    //   2156: aload #30
    //   2158: getfield b : I
    //   2161: ifle -> 2220
    //   2164: goto -> 2168
    //   2167: athrow
    //   2168: aload_1
    //   2169: aload #30
    //   2171: getfield b : I
    //   2174: aload #30
    //   2176: invokevirtual visitLineNumber : (ILorg/objectweb/asm/Label;)V
    //   2179: goto -> 2183
    //   2182: athrow
    //   2183: aload #31
    //   2185: ifnull -> 2220
    //   2188: aload_1
    //   2189: aload #31
    //   2191: getfield b : I
    //   2194: aload #30
    //   2196: invokevirtual visitLineNumber : (ILorg/objectweb/asm/Label;)V
    //   2199: aload #31
    //   2201: getfield k : Lorg/objectweb/asm/Label;
    //   2204: astore #31
    //   2206: iload #4
    //   2208: ifne -> 2437
    //   2211: iload #4
    //   2213: ifeq -> 2183
    //   2216: goto -> 2220
    //   2219: athrow
    //   2220: aload #26
    //   2222: ifnull -> 2437
    //   2225: aload #26
    //   2227: getfield o : I
    //   2230: iload #29
    //   2232: iload #4
    //   2234: ifne -> 2444
    //   2237: goto -> 2241
    //   2240: athrow
    //   2241: iload #4
    //   2243: ifne -> 2298
    //   2246: goto -> 2250
    //   2249: athrow
    //   2250: if_icmpeq -> 2279
    //   2253: goto -> 2257
    //   2256: athrow
    //   2257: aload #26
    //   2259: getfield o : I
    //   2262: iconst_m1
    //   2263: iload #4
    //   2265: ifne -> 2444
    //   2268: goto -> 2272
    //   2271: athrow
    //   2272: if_icmpne -> 2437
    //   2275: goto -> 2279
    //   2278: athrow
    //   2279: aload #26
    //   2281: getfield o : I
    //   2284: iload #4
    //   2286: ifne -> 2393
    //   2289: goto -> 2293
    //   2292: athrow
    //   2293: iconst_m1
    //   2294: goto -> 2298
    //   2297: athrow
    //   2298: if_icmpeq -> 2391
    //   2301: iload #21
    //   2303: iload #4
    //   2305: ifne -> 2321
    //   2308: goto -> 2312
    //   2311: athrow
    //   2312: ifeq -> 2324
    //   2315: goto -> 2319
    //   2318: athrow
    //   2319: iload #22
    //   2321: ifeq -> 2358
    //   2324: aload_1
    //   2325: iconst_m1
    //   2326: aload #26
    //   2328: getfield q : I
    //   2331: aload #26
    //   2333: getfield s : [Ljava/lang/Object;
    //   2336: aload #26
    //   2338: getfield t : I
    //   2341: aload #26
    //   2343: getfield u : [Ljava/lang/Object;
    //   2346: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
    //   2349: iload #4
    //   2351: ifeq -> 2391
    //   2354: goto -> 2358
    //   2357: athrow
    //   2358: aload_1
    //   2359: aload #26
    //   2361: getfield p : I
    //   2364: aload #26
    //   2366: getfield r : I
    //   2369: aload #26
    //   2371: getfield s : [Ljava/lang/Object;
    //   2374: aload #26
    //   2376: getfield t : I
    //   2379: aload #26
    //   2381: getfield u : [Ljava/lang/Object;
    //   2384: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
    //   2387: goto -> 2391
    //   2390: athrow
    //   2391: iload #25
    //   2393: iload #4
    //   2395: ifne -> 2421
    //   2398: ifle -> 2431
    //   2401: goto -> 2405
    //   2404: athrow
    //   2405: aload_0
    //   2406: iload #23
    //   2408: iload #21
    //   2410: iload #22
    //   2412: aload #26
    //   2414: invokespecial a : (IZZLorg/objectweb/asm/Context;)I
    //   2417: goto -> 2421
    //   2420: athrow
    //   2421: istore #23
    //   2423: iinc #25, -1
    //   2426: iload #4
    //   2428: ifeq -> 2220
    //   2431: aconst_null
    //   2432: astore #26
    //   2434: goto -> 2220
    //   2437: aload #5
    //   2439: iload_3
    //   2440: baload
    //   2441: sipush #255
    //   2444: iand
    //   2445: istore #31
    //   2447: iload #4
    //   2449: ifne -> 3845
    //   2452: getstatic org/objectweb/asm/ClassWriter.a : [B
    //   2455: iload #31
    //   2457: baload
    //   2458: tableswitch default -> 3818, 0 -> 2549, 1 -> 3300, 2 -> 3324, 3 -> 3272, 4 -> 2567, 5 -> 3759, 6 -> 3410, 7 -> 3410, 8 -> 3591, 9 -> 2635, 10 -> 2666, 11 -> 3349, 12 -> 3381, 13 -> 3786, 14 -> 3032, 15 -> 3152, 16 -> 3818, 17 -> 2948, 18 -> 2700
    //   2548: athrow
    //   2549: aload_1
    //   2550: iload #31
    //   2552: invokevirtual visitInsn : (I)V
    //   2555: iinc #3, 1
    //   2558: iload #4
    //   2560: ifeq -> 3848
    //   2563: goto -> 2567
    //   2566: athrow
    //   2567: iload #31
    //   2569: bipush #54
    //   2571: if_icmple -> 2605
    //   2574: goto -> 2578
    //   2577: athrow
    //   2578: iinc #31, -59
    //   2581: aload_1
    //   2582: bipush #54
    //   2584: iload #31
    //   2586: iconst_2
    //   2587: ishr
    //   2588: iadd
    //   2589: iload #31
    //   2591: iconst_3
    //   2592: iand
    //   2593: invokevirtual visitVarInsn : (II)V
    //   2596: iload #4
    //   2598: ifeq -> 2627
    //   2601: goto -> 2605
    //   2604: athrow
    //   2605: iinc #31, -26
    //   2608: aload_1
    //   2609: bipush #21
    //   2611: iload #31
    //   2613: iconst_2
    //   2614: ishr
    //   2615: iadd
    //   2616: iload #31
    //   2618: iconst_3
    //   2619: iand
    //   2620: invokevirtual visitVarInsn : (II)V
    //   2623: goto -> 2627
    //   2626: athrow
    //   2627: iinc #3, 1
    //   2630: iload #4
    //   2632: ifeq -> 3848
    //   2635: aload_1
    //   2636: iload #31
    //   2638: aload #12
    //   2640: iload #29
    //   2642: aload_0
    //   2643: iload_3
    //   2644: iconst_1
    //   2645: iadd
    //   2646: invokevirtual readShort : (I)S
    //   2649: iadd
    //   2650: aaload
    //   2651: invokevirtual visitJumpInsn : (ILorg/objectweb/asm/Label;)V
    //   2654: iinc #3, 3
    //   2657: iload #4
    //   2659: ifeq -> 3848
    //   2662: goto -> 2666
    //   2665: athrow
    //   2666: aload_1
    //   2667: iload #31
    //   2669: iload #28
    //   2671: iadd
    //   2672: aload #12
    //   2674: iload #29
    //   2676: aload_0
    //   2677: iload_3
    //   2678: iconst_1
    //   2679: iadd
    //   2680: invokevirtual readInt : (I)I
    //   2683: iadd
    //   2684: aaload
    //   2685: invokevirtual visitJumpInsn : (ILorg/objectweb/asm/Label;)V
    //   2688: iinc #3, 5
    //   2691: iload #4
    //   2693: ifeq -> 3848
    //   2696: goto -> 2700
    //   2699: athrow
    //   2700: iload #31
    //   2702: sipush #218
    //   2705: iload #4
    //   2707: ifne -> 2734
    //   2710: goto -> 2714
    //   2713: athrow
    //   2714: if_icmpge -> 2730
    //   2717: goto -> 2721
    //   2720: athrow
    //   2721: iload #31
    //   2723: bipush #49
    //   2725: isub
    //   2726: goto -> 2735
    //   2729: athrow
    //   2730: iload #31
    //   2732: bipush #20
    //   2734: isub
    //   2735: istore #31
    //   2737: aload #12
    //   2739: iload #29
    //   2741: aload_0
    //   2742: iload_3
    //   2743: iconst_1
    //   2744: iadd
    //   2745: invokevirtual readUnsignedShort : (I)I
    //   2748: iadd
    //   2749: aaload
    //   2750: astore #32
    //   2752: iload #4
    //   2754: ifne -> 2805
    //   2757: iload #31
    //   2759: sipush #167
    //   2762: if_icmpeq -> 2790
    //   2765: goto -> 2769
    //   2768: athrow
    //   2769: iload #31
    //   2771: sipush #168
    //   2774: iload #4
    //   2776: ifne -> 2819
    //   2779: goto -> 2783
    //   2782: athrow
    //   2783: if_icmpne -> 2810
    //   2786: goto -> 2790
    //   2789: athrow
    //   2790: aload_1
    //   2791: iload #31
    //   2793: bipush #33
    //   2795: iadd
    //   2796: aload #32
    //   2798: invokevirtual visitJumpInsn : (ILorg/objectweb/asm/Label;)V
    //   2801: goto -> 2805
    //   2804: athrow
    //   2805: iload #4
    //   2807: ifeq -> 2940
    //   2810: iload #31
    //   2812: sipush #166
    //   2815: goto -> 2819
    //   2818: athrow
    //   2819: iload #4
    //   2821: ifne -> 2846
    //   2824: if_icmpgt -> 2843
    //   2827: goto -> 2831
    //   2830: athrow
    //   2831: iload #31
    //   2833: iconst_1
    //   2834: iadd
    //   2835: iconst_1
    //   2836: ixor
    //   2837: iconst_1
    //   2838: isub
    //   2839: goto -> 2847
    //   2842: athrow
    //   2843: iload #31
    //   2845: iconst_1
    //   2846: ixor
    //   2847: istore #31
    //   2849: new org/objectweb/asm/Label
    //   2852: dup
    //   2853: invokespecial <init> : ()V
    //   2856: astore #33
    //   2858: aload_1
    //   2859: iload #31
    //   2861: aload #33
    //   2863: invokevirtual visitJumpInsn : (ILorg/objectweb/asm/Label;)V
    //   2866: aload_1
    //   2867: sipush #200
    //   2870: aload #32
    //   2872: invokevirtual visitJumpInsn : (ILorg/objectweb/asm/Label;)V
    //   2875: aload_1
    //   2876: aload #33
    //   2878: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   2881: iload #4
    //   2883: ifne -> 2943
    //   2886: iload #23
    //   2888: ifeq -> 2940
    //   2891: goto -> 2895
    //   2894: athrow
    //   2895: aload #26
    //   2897: iload #4
    //   2899: ifne -> 2915
    //   2902: goto -> 2906
    //   2905: athrow
    //   2906: ifnull -> 2925
    //   2909: goto -> 2913
    //   2912: athrow
    //   2913: aload #26
    //   2915: getfield o : I
    //   2918: iload #29
    //   2920: iconst_3
    //   2921: iadd
    //   2922: if_icmpeq -> 2940
    //   2925: aload_1
    //   2926: sipush #256
    //   2929: iconst_0
    //   2930: aconst_null
    //   2931: iconst_0
    //   2932: aconst_null
    //   2933: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
    //   2936: goto -> 2940
    //   2939: athrow
    //   2940: iinc #3, 3
    //   2943: iload #4
    //   2945: ifeq -> 3848
    //   2948: aload #5
    //   2950: iload_3
    //   2951: iconst_1
    //   2952: iadd
    //   2953: baload
    //   2954: sipush #255
    //   2957: iand
    //   2958: istore #31
    //   2960: iload #4
    //   2962: ifne -> 3027
    //   2965: iload #31
    //   2967: sipush #132
    //   2970: if_icmpne -> 3007
    //   2973: goto -> 2977
    //   2976: athrow
    //   2977: aload_1
    //   2978: aload_0
    //   2979: iload_3
    //   2980: iconst_2
    //   2981: iadd
    //   2982: invokevirtual readUnsignedShort : (I)I
    //   2985: aload_0
    //   2986: iload_3
    //   2987: iconst_4
    //   2988: iadd
    //   2989: invokevirtual readShort : (I)S
    //   2992: invokevirtual visitIincInsn : (II)V
    //   2995: iinc #3, 6
    //   2998: iload #4
    //   3000: ifeq -> 3848
    //   3003: goto -> 3007
    //   3006: athrow
    //   3007: aload_1
    //   3008: iload #31
    //   3010: aload_0
    //   3011: iload_3
    //   3012: iconst_2
    //   3013: iadd
    //   3014: invokevirtual readUnsignedShort : (I)I
    //   3017: invokevirtual visitVarInsn : (II)V
    //   3020: iinc #3, 4
    //   3023: goto -> 3027
    //   3026: athrow
    //   3027: iload #4
    //   3029: ifeq -> 3848
    //   3032: iload_3
    //   3033: iconst_4
    //   3034: iadd
    //   3035: iload #29
    //   3037: iconst_3
    //   3038: iand
    //   3039: isub
    //   3040: istore_3
    //   3041: iload #29
    //   3043: aload_0
    //   3044: iload_3
    //   3045: invokevirtual readInt : (I)I
    //   3048: iadd
    //   3049: istore #32
    //   3051: aload_0
    //   3052: iload_3
    //   3053: iconst_4
    //   3054: iadd
    //   3055: invokevirtual readInt : (I)I
    //   3058: istore #33
    //   3060: aload_0
    //   3061: iload_3
    //   3062: bipush #8
    //   3064: iadd
    //   3065: invokevirtual readInt : (I)I
    //   3068: istore #34
    //   3070: iload #34
    //   3072: iload #33
    //   3074: isub
    //   3075: iconst_1
    //   3076: iadd
    //   3077: anewarray org/objectweb/asm/Label
    //   3080: astore #35
    //   3082: iinc #3, 12
    //   3085: iconst_0
    //   3086: istore #36
    //   3088: iload #36
    //   3090: aload #35
    //   3092: arraylength
    //   3093: if_icmpge -> 3132
    //   3096: aload #35
    //   3098: iload #36
    //   3100: aload #12
    //   3102: iload #29
    //   3104: aload_0
    //   3105: iload_3
    //   3106: invokevirtual readInt : (I)I
    //   3109: iadd
    //   3110: aaload
    //   3111: aastore
    //   3112: iinc #3, 4
    //   3115: iinc #36, 1
    //   3118: iload #4
    //   3120: ifne -> 3147
    //   3123: iload #4
    //   3125: ifeq -> 3088
    //   3128: goto -> 3132
    //   3131: athrow
    //   3132: aload_1
    //   3133: iload #33
    //   3135: iload #34
    //   3137: aload #12
    //   3139: iload #32
    //   3141: aaload
    //   3142: aload #35
    //   3144: invokevirtual visitTableSwitchInsn : (IILorg/objectweb/asm/Label;[Lorg/objectweb/asm/Label;)V
    //   3147: iload #4
    //   3149: ifeq -> 3848
    //   3152: iload_3
    //   3153: iconst_4
    //   3154: iadd
    //   3155: iload #29
    //   3157: iconst_3
    //   3158: iand
    //   3159: isub
    //   3160: istore_3
    //   3161: iload #29
    //   3163: aload_0
    //   3164: iload_3
    //   3165: invokevirtual readInt : (I)I
    //   3168: iadd
    //   3169: istore #32
    //   3171: aload_0
    //   3172: iload_3
    //   3173: iconst_4
    //   3174: iadd
    //   3175: invokevirtual readInt : (I)I
    //   3178: istore #33
    //   3180: iload #33
    //   3182: newarray int
    //   3184: astore #34
    //   3186: iload #33
    //   3188: anewarray org/objectweb/asm/Label
    //   3191: astore #35
    //   3193: iinc #3, 8
    //   3196: iconst_0
    //   3197: istore #36
    //   3199: iload #36
    //   3201: iload #33
    //   3203: if_icmpge -> 3254
    //   3206: aload #34
    //   3208: iload #36
    //   3210: aload_0
    //   3211: iload_3
    //   3212: invokevirtual readInt : (I)I
    //   3215: iastore
    //   3216: aload #35
    //   3218: iload #36
    //   3220: aload #12
    //   3222: iload #29
    //   3224: aload_0
    //   3225: iload_3
    //   3226: iconst_4
    //   3227: iadd
    //   3228: invokevirtual readInt : (I)I
    //   3231: iadd
    //   3232: aaload
    //   3233: aastore
    //   3234: iinc #3, 8
    //   3237: iinc #36, 1
    //   3240: iload #4
    //   3242: ifne -> 3267
    //   3245: iload #4
    //   3247: ifeq -> 3199
    //   3250: goto -> 3254
    //   3253: athrow
    //   3254: aload_1
    //   3255: aload #12
    //   3257: iload #32
    //   3259: aaload
    //   3260: aload #34
    //   3262: aload #35
    //   3264: invokevirtual visitLookupSwitchInsn : (Lorg/objectweb/asm/Label;[I[Lorg/objectweb/asm/Label;)V
    //   3267: iload #4
    //   3269: ifeq -> 3848
    //   3272: aload_1
    //   3273: iload #31
    //   3275: aload #5
    //   3277: iload_3
    //   3278: iconst_1
    //   3279: iadd
    //   3280: baload
    //   3281: sipush #255
    //   3284: iand
    //   3285: invokevirtual visitVarInsn : (II)V
    //   3288: iinc #3, 2
    //   3291: iload #4
    //   3293: ifeq -> 3848
    //   3296: goto -> 3300
    //   3299: athrow
    //   3300: aload_1
    //   3301: iload #31
    //   3303: aload #5
    //   3305: iload_3
    //   3306: iconst_1
    //   3307: iadd
    //   3308: baload
    //   3309: invokevirtual visitIntInsn : (II)V
    //   3312: iinc #3, 2
    //   3315: iload #4
    //   3317: ifeq -> 3848
    //   3320: goto -> 3324
    //   3323: athrow
    //   3324: aload_1
    //   3325: iload #31
    //   3327: aload_0
    //   3328: iload_3
    //   3329: iconst_1
    //   3330: iadd
    //   3331: invokevirtual readShort : (I)S
    //   3334: invokevirtual visitIntInsn : (II)V
    //   3337: iinc #3, 3
    //   3340: iload #4
    //   3342: ifeq -> 3848
    //   3345: goto -> 3349
    //   3348: athrow
    //   3349: aload_1
    //   3350: aload_0
    //   3351: aload #5
    //   3353: iload_3
    //   3354: iconst_1
    //   3355: iadd
    //   3356: baload
    //   3357: sipush #255
    //   3360: iand
    //   3361: aload #6
    //   3363: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   3366: invokevirtual visitLdcInsn : (Ljava/lang/Object;)V
    //   3369: iinc #3, 2
    //   3372: iload #4
    //   3374: ifeq -> 3848
    //   3377: goto -> 3381
    //   3380: athrow
    //   3381: aload_1
    //   3382: aload_0
    //   3383: aload_0
    //   3384: iload_3
    //   3385: iconst_1
    //   3386: iadd
    //   3387: invokevirtual readUnsignedShort : (I)I
    //   3390: aload #6
    //   3392: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   3395: invokevirtual visitLdcInsn : (Ljava/lang/Object;)V
    //   3398: iinc #3, 3
    //   3401: iload #4
    //   3403: ifeq -> 3848
    //   3406: goto -> 3410
    //   3409: athrow
    //   3410: aload_0
    //   3411: getfield a : [I
    //   3414: aload_0
    //   3415: iload_3
    //   3416: iconst_1
    //   3417: iadd
    //   3418: invokevirtual readUnsignedShort : (I)I
    //   3421: iaload
    //   3422: istore #32
    //   3424: aload #5
    //   3426: iload #32
    //   3428: iconst_1
    //   3429: isub
    //   3430: baload
    //   3431: iload #4
    //   3433: ifne -> 3450
    //   3436: bipush #11
    //   3438: if_icmpne -> 3453
    //   3441: goto -> 3445
    //   3444: athrow
    //   3445: iconst_1
    //   3446: goto -> 3450
    //   3449: athrow
    //   3450: goto -> 3454
    //   3453: iconst_0
    //   3454: istore #33
    //   3456: aload_0
    //   3457: iload #32
    //   3459: aload #6
    //   3461: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   3464: astore #34
    //   3466: aload_0
    //   3467: getfield a : [I
    //   3470: aload_0
    //   3471: iload #32
    //   3473: iconst_2
    //   3474: iadd
    //   3475: invokevirtual readUnsignedShort : (I)I
    //   3478: iaload
    //   3479: istore #32
    //   3481: aload_0
    //   3482: iload #32
    //   3484: aload #6
    //   3486: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   3489: astore #35
    //   3491: aload_0
    //   3492: iload #32
    //   3494: iconst_2
    //   3495: iadd
    //   3496: aload #6
    //   3498: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   3501: astore #36
    //   3503: iload #4
    //   3505: ifne -> 3536
    //   3508: iload #31
    //   3510: sipush #182
    //   3513: if_icmpge -> 3541
    //   3516: goto -> 3520
    //   3519: athrow
    //   3520: aload_1
    //   3521: iload #31
    //   3523: aload #34
    //   3525: aload #35
    //   3527: aload #36
    //   3529: invokevirtual visitFieldInsn : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   3532: goto -> 3536
    //   3535: athrow
    //   3536: iload #4
    //   3538: ifeq -> 3559
    //   3541: aload_1
    //   3542: iload #31
    //   3544: aload #34
    //   3546: aload #35
    //   3548: aload #36
    //   3550: iload #33
    //   3552: invokevirtual visitMethodInsn : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    //   3555: goto -> 3559
    //   3558: athrow
    //   3559: iload #31
    //   3561: sipush #185
    //   3564: if_icmpne -> 3579
    //   3567: iinc #3, 5
    //   3570: iload #4
    //   3572: ifeq -> 3848
    //   3575: goto -> 3579
    //   3578: athrow
    //   3579: iinc #3, 3
    //   3582: iload #4
    //   3584: ifeq -> 3848
    //   3587: goto -> 3591
    //   3590: athrow
    //   3591: aload_0
    //   3592: getfield a : [I
    //   3595: aload_0
    //   3596: iload_3
    //   3597: iconst_1
    //   3598: iadd
    //   3599: invokevirtual readUnsignedShort : (I)I
    //   3602: iaload
    //   3603: istore #32
    //   3605: aload_2
    //   3606: getfield d : [I
    //   3609: aload_0
    //   3610: iload #32
    //   3612: invokevirtual readUnsignedShort : (I)I
    //   3615: iaload
    //   3616: istore #33
    //   3618: aload_0
    //   3619: aload_0
    //   3620: iload #33
    //   3622: invokevirtual readUnsignedShort : (I)I
    //   3625: aload #6
    //   3627: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   3630: checkcast org/objectweb/asm/Handle
    //   3633: astore #34
    //   3635: aload_0
    //   3636: iload #33
    //   3638: iconst_2
    //   3639: iadd
    //   3640: invokevirtual readUnsignedShort : (I)I
    //   3643: istore #35
    //   3645: iload #35
    //   3647: anewarray java/lang/Object
    //   3650: astore #36
    //   3652: iinc #33, 4
    //   3655: iconst_0
    //   3656: istore #37
    //   3658: iload #37
    //   3660: iload #35
    //   3662: if_icmpge -> 3702
    //   3665: aload #36
    //   3667: iload #37
    //   3669: aload_0
    //   3670: aload_0
    //   3671: iload #33
    //   3673: invokevirtual readUnsignedShort : (I)I
    //   3676: aload #6
    //   3678: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   3681: aastore
    //   3682: iinc #33, 2
    //   3685: iinc #37, 1
    //   3688: iload #4
    //   3690: ifne -> 3717
    //   3693: iload #4
    //   3695: ifeq -> 3658
    //   3698: goto -> 3702
    //   3701: athrow
    //   3702: aload_0
    //   3703: getfield a : [I
    //   3706: aload_0
    //   3707: iload #32
    //   3709: iconst_2
    //   3710: iadd
    //   3711: invokevirtual readUnsignedShort : (I)I
    //   3714: iaload
    //   3715: istore #32
    //   3717: aload_0
    //   3718: iload #32
    //   3720: aload #6
    //   3722: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   3725: astore #37
    //   3727: aload_0
    //   3728: iload #32
    //   3730: iconst_2
    //   3731: iadd
    //   3732: aload #6
    //   3734: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   3737: astore #38
    //   3739: aload_1
    //   3740: aload #37
    //   3742: aload #38
    //   3744: aload #34
    //   3746: aload #36
    //   3748: invokevirtual visitInvokeDynamicInsn : (Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/Handle;[Ljava/lang/Object;)V
    //   3751: iinc #3, 5
    //   3754: iload #4
    //   3756: ifeq -> 3848
    //   3759: aload_1
    //   3760: iload #31
    //   3762: aload_0
    //   3763: iload_3
    //   3764: iconst_1
    //   3765: iadd
    //   3766: aload #6
    //   3768: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   3771: invokevirtual visitTypeInsn : (ILjava/lang/String;)V
    //   3774: iinc #3, 3
    //   3777: iload #4
    //   3779: ifeq -> 3848
    //   3782: goto -> 3786
    //   3785: athrow
    //   3786: aload_1
    //   3787: aload #5
    //   3789: iload_3
    //   3790: iconst_1
    //   3791: iadd
    //   3792: baload
    //   3793: sipush #255
    //   3796: iand
    //   3797: aload #5
    //   3799: iload_3
    //   3800: iconst_2
    //   3801: iadd
    //   3802: baload
    //   3803: invokevirtual visitIincInsn : (II)V
    //   3806: iinc #3, 3
    //   3809: iload #4
    //   3811: ifeq -> 3848
    //   3814: goto -> 3818
    //   3817: athrow
    //   3818: aload_1
    //   3819: aload_0
    //   3820: iload_3
    //   3821: iconst_1
    //   3822: iadd
    //   3823: aload #6
    //   3825: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   3828: aload #5
    //   3830: iload_3
    //   3831: iconst_3
    //   3832: iadd
    //   3833: baload
    //   3834: sipush #255
    //   3837: iand
    //   3838: invokevirtual visitMultiANewArrayInsn : (Ljava/lang/String;I)V
    //   3841: goto -> 3845
    //   3844: athrow
    //   3845: iinc #3, 4
    //   3848: aload #13
    //   3850: ifnull -> 4033
    //   3853: iload #15
    //   3855: aload #13
    //   3857: arraylength
    //   3858: iload #4
    //   3860: ifne -> 2076
    //   3863: iload #4
    //   3865: ifne -> 3883
    //   3868: if_icmpge -> 4033
    //   3871: goto -> 3875
    //   3874: athrow
    //   3875: iload #17
    //   3877: iload #29
    //   3879: goto -> 3883
    //   3882: athrow
    //   3883: iload #4
    //   3885: ifne -> 3903
    //   3888: if_icmpgt -> 4033
    //   3891: goto -> 3895
    //   3894: athrow
    //   3895: iload #17
    //   3897: iload #29
    //   3899: goto -> 3903
    //   3902: athrow
    //   3903: iload #4
    //   3905: ifne -> 3977
    //   3908: if_icmpne -> 3960
    //   3911: goto -> 3915
    //   3914: athrow
    //   3915: aload_0
    //   3916: aload_2
    //   3917: aload #13
    //   3919: iload #15
    //   3921: iaload
    //   3922: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   3925: istore #32
    //   3927: aload_0
    //   3928: iload #32
    //   3930: iconst_2
    //   3931: iadd
    //   3932: aload #6
    //   3934: iconst_1
    //   3935: aload_1
    //   3936: aload_2
    //   3937: getfield i : I
    //   3940: aload_2
    //   3941: getfield j : Lorg/objectweb/asm/TypePath;
    //   3944: aload_0
    //   3945: iload #32
    //   3947: aload #6
    //   3949: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   3952: iconst_1
    //   3953: invokevirtual visitInsnAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   3956: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   3959: pop
    //   3960: iinc #15, 1
    //   3963: iload #15
    //   3965: iload #4
    //   3967: ifne -> 4012
    //   3970: aload #13
    //   3972: arraylength
    //   3973: goto -> 3977
    //   3976: athrow
    //   3977: if_icmpge -> 4007
    //   3980: aload_0
    //   3981: aload #13
    //   3983: iload #15
    //   3985: iaload
    //   3986: iload #4
    //   3988: ifne -> 4023
    //   3991: goto -> 3995
    //   3994: athrow
    //   3995: invokevirtual readByte : (I)I
    //   3998: bipush #67
    //   4000: if_icmpge -> 4015
    //   4003: goto -> 4007
    //   4006: athrow
    //   4007: iconst_m1
    //   4008: goto -> 4012
    //   4011: athrow
    //   4012: goto -> 4026
    //   4015: aload_0
    //   4016: aload #13
    //   4018: iload #15
    //   4020: iaload
    //   4021: iconst_1
    //   4022: iadd
    //   4023: invokevirtual readUnsignedShort : (I)I
    //   4026: istore #17
    //   4028: iload #4
    //   4030: ifeq -> 3848
    //   4033: aload #14
    //   4035: ifnull -> 4218
    //   4038: iload #16
    //   4040: aload #14
    //   4042: arraylength
    //   4043: iload #4
    //   4045: ifne -> 2076
    //   4048: iload #4
    //   4050: ifne -> 4068
    //   4053: if_icmpge -> 4218
    //   4056: goto -> 4060
    //   4059: athrow
    //   4060: iload #18
    //   4062: iload #29
    //   4064: goto -> 4068
    //   4067: athrow
    //   4068: iload #4
    //   4070: ifne -> 4088
    //   4073: if_icmpgt -> 4218
    //   4076: goto -> 4080
    //   4079: athrow
    //   4080: iload #18
    //   4082: iload #29
    //   4084: goto -> 4088
    //   4087: athrow
    //   4088: iload #4
    //   4090: ifne -> 4162
    //   4093: if_icmpne -> 4145
    //   4096: goto -> 4100
    //   4099: athrow
    //   4100: aload_0
    //   4101: aload_2
    //   4102: aload #14
    //   4104: iload #16
    //   4106: iaload
    //   4107: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   4110: istore #32
    //   4112: aload_0
    //   4113: iload #32
    //   4115: iconst_2
    //   4116: iadd
    //   4117: aload #6
    //   4119: iconst_1
    //   4120: aload_1
    //   4121: aload_2
    //   4122: getfield i : I
    //   4125: aload_2
    //   4126: getfield j : Lorg/objectweb/asm/TypePath;
    //   4129: aload_0
    //   4130: iload #32
    //   4132: aload #6
    //   4134: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4137: iconst_0
    //   4138: invokevirtual visitInsnAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   4141: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   4144: pop
    //   4145: iinc #16, 1
    //   4148: iload #16
    //   4150: iload #4
    //   4152: ifne -> 4197
    //   4155: aload #14
    //   4157: arraylength
    //   4158: goto -> 4162
    //   4161: athrow
    //   4162: if_icmpge -> 4192
    //   4165: aload_0
    //   4166: aload #14
    //   4168: iload #16
    //   4170: iaload
    //   4171: iload #4
    //   4173: ifne -> 4208
    //   4176: goto -> 4180
    //   4179: athrow
    //   4180: invokevirtual readByte : (I)I
    //   4183: bipush #67
    //   4185: if_icmpge -> 4200
    //   4188: goto -> 4192
    //   4191: athrow
    //   4192: iconst_m1
    //   4193: goto -> 4197
    //   4196: athrow
    //   4197: goto -> 4211
    //   4200: aload_0
    //   4201: aload #14
    //   4203: iload #16
    //   4205: iaload
    //   4206: iconst_1
    //   4207: iadd
    //   4208: invokevirtual readUnsignedShort : (I)I
    //   4211: istore #18
    //   4213: iload #4
    //   4215: ifeq -> 4033
    //   4218: iload #4
    //   4220: ifeq -> 2073
    //   4223: aload #12
    //   4225: iload #9
    //   4227: aaload
    //   4228: ifnull -> 4244
    //   4231: aload_1
    //   4232: aload #12
    //   4234: iload #9
    //   4236: aaload
    //   4237: invokevirtual visitLabel : (Lorg/objectweb/asm/Label;)V
    //   4240: goto -> 4244
    //   4243: athrow
    //   4244: aload_2
    //   4245: getfield b : I
    //   4248: iconst_2
    //   4249: iand
    //   4250: iload #4
    //   4252: ifne -> 4264
    //   4255: ifne -> 4556
    //   4258: goto -> 4262
    //   4261: athrow
    //   4262: iload #19
    //   4264: ifeq -> 4556
    //   4267: aconst_null
    //   4268: astore #29
    //   4270: iload #20
    //   4272: iload #4
    //   4274: ifne -> 4297
    //   4277: ifeq -> 4369
    //   4280: goto -> 4284
    //   4283: athrow
    //   4284: iload #20
    //   4286: iconst_2
    //   4287: iadd
    //   4288: istore_3
    //   4289: aload_0
    //   4290: iload #20
    //   4292: invokevirtual readUnsignedShort : (I)I
    //   4295: iconst_3
    //   4296: imul
    //   4297: newarray int
    //   4299: astore #29
    //   4301: aload #29
    //   4303: arraylength
    //   4304: istore #30
    //   4306: iload #30
    //   4308: ifle -> 4369
    //   4311: aload #29
    //   4313: iinc #30, -1
    //   4316: iload #30
    //   4318: iload_3
    //   4319: bipush #6
    //   4321: iadd
    //   4322: iastore
    //   4323: aload #29
    //   4325: iinc #30, -1
    //   4328: iload #30
    //   4330: aload_0
    //   4331: iload_3
    //   4332: bipush #8
    //   4334: iadd
    //   4335: invokevirtual readUnsignedShort : (I)I
    //   4338: iastore
    //   4339: aload #29
    //   4341: iinc #30, -1
    //   4344: iload #30
    //   4346: aload_0
    //   4347: iload_3
    //   4348: invokevirtual readUnsignedShort : (I)I
    //   4351: iastore
    //   4352: iinc #3, 10
    //   4355: iload #4
    //   4357: ifne -> 4374
    //   4360: iload #4
    //   4362: ifeq -> 4306
    //   4365: goto -> 4369
    //   4368: athrow
    //   4369: iload #19
    //   4371: iconst_2
    //   4372: iadd
    //   4373: istore_3
    //   4374: aload_0
    //   4375: iload #19
    //   4377: invokevirtual readUnsignedShort : (I)I
    //   4380: istore #30
    //   4382: iload #30
    //   4384: ifle -> 4556
    //   4387: aload_0
    //   4388: iload_3
    //   4389: invokevirtual readUnsignedShort : (I)I
    //   4392: istore #31
    //   4394: aload_0
    //   4395: iload_3
    //   4396: iconst_2
    //   4397: iadd
    //   4398: invokevirtual readUnsignedShort : (I)I
    //   4401: istore #32
    //   4403: aload_0
    //   4404: iload_3
    //   4405: bipush #8
    //   4407: iadd
    //   4408: invokevirtual readUnsignedShort : (I)I
    //   4411: istore #33
    //   4413: aconst_null
    //   4414: astore #34
    //   4416: aload #29
    //   4418: iload #4
    //   4420: ifne -> 4558
    //   4423: ifnull -> 4505
    //   4426: goto -> 4430
    //   4429: athrow
    //   4430: iconst_0
    //   4431: istore #35
    //   4433: iload #35
    //   4435: aload #29
    //   4437: arraylength
    //   4438: if_icmpge -> 4505
    //   4441: aload #29
    //   4443: iload #35
    //   4445: iaload
    //   4446: iload #31
    //   4448: iload #4
    //   4450: ifne -> 4438
    //   4453: iload #4
    //   4455: ifne -> 4478
    //   4458: if_icmpne -> 4499
    //   4461: goto -> 4465
    //   4464: athrow
    //   4465: aload #29
    //   4467: iload #35
    //   4469: iconst_1
    //   4470: iadd
    //   4471: iaload
    //   4472: iload #33
    //   4474: goto -> 4478
    //   4477: athrow
    //   4478: if_icmpne -> 4499
    //   4481: aload_0
    //   4482: aload #29
    //   4484: iload #35
    //   4486: iconst_2
    //   4487: iadd
    //   4488: iaload
    //   4489: aload #6
    //   4491: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4494: astore #34
    //   4496: goto -> 4505
    //   4499: iinc #35, 3
    //   4502: goto -> 4433
    //   4505: aload_1
    //   4506: aload_0
    //   4507: iload_3
    //   4508: iconst_4
    //   4509: iadd
    //   4510: aload #6
    //   4512: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4515: aload_0
    //   4516: iload_3
    //   4517: bipush #6
    //   4519: iadd
    //   4520: aload #6
    //   4522: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4525: aload #34
    //   4527: aload #12
    //   4529: iload #31
    //   4531: aaload
    //   4532: aload #12
    //   4534: iload #31
    //   4536: iload #32
    //   4538: iadd
    //   4539: aaload
    //   4540: iload #33
    //   4542: invokevirtual visitLocalVariable : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/Label;Lorg/objectweb/asm/Label;I)V
    //   4545: iinc #3, 10
    //   4548: iinc #30, -1
    //   4551: iload #4
    //   4553: ifeq -> 4382
    //   4556: aload #13
    //   4558: iload #4
    //   4560: ifne -> 4687
    //   4563: ifnull -> 4685
    //   4566: goto -> 4570
    //   4569: athrow
    //   4570: iconst_0
    //   4571: istore #29
    //   4573: iload #29
    //   4575: aload #13
    //   4577: arraylength
    //   4578: if_icmpge -> 4685
    //   4581: aload_0
    //   4582: aload #13
    //   4584: iload #29
    //   4586: iaload
    //   4587: invokevirtual readByte : (I)I
    //   4590: iconst_1
    //   4591: ishr
    //   4592: iload #4
    //   4594: ifne -> 4629
    //   4597: bipush #32
    //   4599: iload #4
    //   4601: ifne -> 4698
    //   4604: goto -> 4608
    //   4607: athrow
    //   4608: if_icmpne -> 4677
    //   4611: goto -> 4615
    //   4614: athrow
    //   4615: aload_0
    //   4616: aload_2
    //   4617: aload #13
    //   4619: iload #29
    //   4621: iaload
    //   4622: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   4625: goto -> 4629
    //   4628: athrow
    //   4629: istore #30
    //   4631: aload_0
    //   4632: iload #30
    //   4634: iconst_2
    //   4635: iadd
    //   4636: aload #6
    //   4638: iconst_1
    //   4639: aload_1
    //   4640: aload_2
    //   4641: getfield i : I
    //   4644: aload_2
    //   4645: getfield j : Lorg/objectweb/asm/TypePath;
    //   4648: aload_2
    //   4649: getfield l : [Lorg/objectweb/asm/Label;
    //   4652: aload_2
    //   4653: getfield m : [Lorg/objectweb/asm/Label;
    //   4656: aload_2
    //   4657: getfield n : [I
    //   4660: aload_0
    //   4661: iload #30
    //   4663: aload #6
    //   4665: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4668: iconst_1
    //   4669: invokevirtual visitLocalVariableAnnotation : (ILorg/objectweb/asm/TypePath;[Lorg/objectweb/asm/Label;[Lorg/objectweb/asm/Label;[ILjava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   4672: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   4675: istore #30
    //   4677: iinc #29, 1
    //   4680: iload #4
    //   4682: ifeq -> 4573
    //   4685: aload #14
    //   4687: ifnull -> 4800
    //   4690: iconst_0
    //   4691: istore #29
    //   4693: iload #29
    //   4695: aload #14
    //   4697: arraylength
    //   4698: if_icmpge -> 4800
    //   4701: aload_0
    //   4702: aload #14
    //   4704: iload #29
    //   4706: iaload
    //   4707: invokevirtual readByte : (I)I
    //   4710: iconst_1
    //   4711: ishr
    //   4712: iload #4
    //   4714: ifne -> 4744
    //   4717: goto -> 4721
    //   4720: athrow
    //   4721: bipush #32
    //   4723: if_icmpne -> 4792
    //   4726: goto -> 4730
    //   4729: athrow
    //   4730: aload_0
    //   4731: aload_2
    //   4732: aload #14
    //   4734: iload #29
    //   4736: iaload
    //   4737: invokespecial a : (Lorg/objectweb/asm/Context;I)I
    //   4740: goto -> 4744
    //   4743: athrow
    //   4744: istore #30
    //   4746: aload_0
    //   4747: iload #30
    //   4749: iconst_2
    //   4750: iadd
    //   4751: aload #6
    //   4753: iconst_1
    //   4754: aload_1
    //   4755: aload_2
    //   4756: getfield i : I
    //   4759: aload_2
    //   4760: getfield j : Lorg/objectweb/asm/TypePath;
    //   4763: aload_2
    //   4764: getfield l : [Lorg/objectweb/asm/Label;
    //   4767: aload_2
    //   4768: getfield m : [Lorg/objectweb/asm/Label;
    //   4771: aload_2
    //   4772: getfield n : [I
    //   4775: aload_0
    //   4776: iload #30
    //   4778: aload #6
    //   4780: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   4783: iconst_0
    //   4784: invokevirtual visitLocalVariableAnnotation : (ILorg/objectweb/asm/TypePath;[Lorg/objectweb/asm/Label;[Lorg/objectweb/asm/Label;[ILjava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   4787: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   4790: istore #30
    //   4792: iinc #29, 1
    //   4795: iload #4
    //   4797: ifeq -> 4693
    //   4800: aload #27
    //   4802: ifnull -> 4842
    //   4805: aload #27
    //   4807: getfield a : Lorg/objectweb/asm/Attribute;
    //   4810: astore #29
    //   4812: aload #27
    //   4814: aconst_null
    //   4815: putfield a : Lorg/objectweb/asm/Attribute;
    //   4818: aload_1
    //   4819: aload #27
    //   4821: invokevirtual visitAttribute : (Lorg/objectweb/asm/Attribute;)V
    //   4824: aload #29
    //   4826: astore #27
    //   4828: iload #4
    //   4830: ifne -> 4850
    //   4833: iload #4
    //   4835: ifeq -> 4800
    //   4838: goto -> 4842
    //   4841: athrow
    //   4842: aload_1
    //   4843: iload #7
    //   4845: iload #8
    //   4847: invokevirtual visitMaxs : (II)V
    //   4850: return
    // Exception table:
    //   from	to	target	type
    //   101	117	120	java/lang/IllegalArgumentException
    //   106	212	212	java/lang/IllegalArgumentException
    //   216	246	249	java/lang/IllegalArgumentException
    //   221	275	278	java/lang/IllegalArgumentException
    //   250	304	307	java/lang/IllegalArgumentException
    //   320	333	336	java/lang/IllegalArgumentException
    //   325	345	348	java/lang/IllegalArgumentException
    //   337	352	355	java/lang/IllegalArgumentException
    //   410	444	447	java/lang/IllegalArgumentException
    //   494	528	531	java/lang/IllegalArgumentException
    //   535	548	551	java/lang/IllegalArgumentException
    //   540	560	563	java/lang/IllegalArgumentException
    //   552	572	575	java/lang/IllegalArgumentException
    //   564	579	582	java/lang/IllegalArgumentException
    //   667	695	698	java/lang/IllegalArgumentException
    //   729	744	747	java/lang/IllegalArgumentException
    //   793	817	820	java/lang/IllegalArgumentException
    //   812	824	827	java/lang/IllegalArgumentException
    //   821	839	842	java/lang/IllegalArgumentException
    //   828	846	849	java/lang/IllegalArgumentException
    //   885	900	903	java/lang/IllegalArgumentException
    //   904	924	927	java/lang/IllegalArgumentException
    //   942	952	955	java/lang/IllegalArgumentException
    //   956	976	979	java/lang/IllegalArgumentException
    //   991	1010	1013	java/lang/IllegalArgumentException
    //   1014	1022	1025	java/lang/IllegalArgumentException
    //   1032	1051	1054	java/lang/IllegalArgumentException
    //   1055	1063	1066	java/lang/IllegalArgumentException
    //   1060	1078	1081	java/lang/IllegalArgumentException
    //   1067	1085	1088	java/lang/IllegalArgumentException
    //   1128	1136	1139	java/lang/IllegalArgumentException
    //   1133	1157	1160	java/lang/IllegalArgumentException
    //   1176	1191	1194	java/lang/IllegalArgumentException
    //   1186	1198	1201	java/lang/IllegalArgumentException
    //   1195	1214	1217	java/lang/IllegalArgumentException
    //   1255	1274	1277	java/lang/IllegalArgumentException
    //   1278	1286	1289	java/lang/IllegalArgumentException
    //   1303	1314	1317	java/lang/IllegalArgumentException
    //   1311	1328	1331	java/lang/IllegalArgumentException
    //   1318	1340	1343	java/lang/IllegalArgumentException
    //   1332	1345	1348	java/lang/IllegalArgumentException
    //   1364	1383	1386	java/lang/IllegalArgumentException
    //   1387	1395	1398	java/lang/IllegalArgumentException
    //   1412	1423	1426	java/lang/IllegalArgumentException
    //   1420	1437	1440	java/lang/IllegalArgumentException
    //   1427	1449	1452	java/lang/IllegalArgumentException
    //   1441	1454	1457	java/lang/IllegalArgumentException
    //   1473	1492	1495	java/lang/IllegalArgumentException
    //   1496	1504	1507	java/lang/IllegalArgumentException
    //   1501	1519	1522	java/lang/IllegalArgumentException
    //   1508	1526	1529	java/lang/IllegalArgumentException
    //   1555	1574	1577	java/lang/IllegalArgumentException
    //   1578	1586	1589	java/lang/IllegalArgumentException
    //   1583	1601	1604	java/lang/IllegalArgumentException
    //   1590	1608	1611	java/lang/IllegalArgumentException
    //   1640	1646	1649	java/lang/IllegalArgumentException
    //   1662	1687	1690	java/lang/IllegalArgumentException
    //   1674	1694	1697	java/lang/IllegalArgumentException
    //   1691	1729	1732	java/lang/IllegalArgumentException
    //   1735	1745	1748	java/lang/IllegalArgumentException
    //   1800	1860	1863	java/lang/IllegalArgumentException
    //   1857	1869	1872	java/lang/IllegalArgumentException
    //   1889	1906	1909	java/lang/IllegalArgumentException
    //   1899	1913	1916	java/lang/IllegalArgumentException
    //   1910	1925	1928	java/lang/IllegalArgumentException
    //   1931	1941	1944	java/lang/IllegalArgumentException
    //   1936	1954	1957	java/lang/IllegalArgumentException
    //   1945	1961	1964	java/lang/IllegalArgumentException
    //   1958	1980	1983	java/lang/IllegalArgumentException
    //   1984	1996	1999	java/lang/IllegalArgumentException
    //   2015	2024	2027	java/lang/IllegalArgumentException
    //   2021	2038	2041	java/lang/IllegalArgumentException
    //   2050	2058	2061	java/lang/IllegalArgumentException
    //   2092	2104	2107	java/lang/IllegalArgumentException
    //   2099	2111	2114	java/lang/IllegalArgumentException
    //   2108	2120	2123	java/lang/IllegalArgumentException
    //   2126	2152	2155	java/lang/IllegalArgumentException
    //   2144	2164	2167	java/lang/IllegalArgumentException
    //   2156	2179	2182	java/lang/IllegalArgumentException
    //   2206	2216	2219	java/lang/IllegalArgumentException
    //   2222	2237	2240	java/lang/IllegalArgumentException
    //   2225	2246	2249	java/lang/IllegalArgumentException
    //   2241	2253	2256	java/lang/IllegalArgumentException
    //   2250	2268	2271	java/lang/IllegalArgumentException
    //   2257	2275	2278	java/lang/IllegalArgumentException
    //   2272	2289	2292	java/lang/IllegalArgumentException
    //   2279	2294	2297	java/lang/IllegalArgumentException
    //   2298	2308	2311	java/lang/IllegalArgumentException
    //   2301	2315	2318	java/lang/IllegalArgumentException
    //   2321	2354	2357	java/lang/IllegalArgumentException
    //   2324	2387	2390	java/lang/IllegalArgumentException
    //   2393	2401	2404	java/lang/IllegalArgumentException
    //   2398	2417	2420	java/lang/IllegalArgumentException
    //   2447	2548	2548	java/lang/IllegalArgumentException
    //   2452	2563	2566	java/lang/IllegalArgumentException
    //   2549	2574	2577	java/lang/IllegalArgumentException
    //   2567	2601	2604	java/lang/IllegalArgumentException
    //   2578	2623	2626	java/lang/IllegalArgumentException
    //   2627	2662	2665	java/lang/IllegalArgumentException
    //   2635	2696	2699	java/lang/IllegalArgumentException
    //   2666	2710	2713	java/lang/IllegalArgumentException
    //   2700	2717	2720	java/lang/IllegalArgumentException
    //   2714	2729	2729	java/lang/IllegalArgumentException
    //   2752	2765	2768	java/lang/IllegalArgumentException
    //   2757	2779	2782	java/lang/IllegalArgumentException
    //   2769	2786	2789	java/lang/IllegalArgumentException
    //   2783	2801	2804	java/lang/IllegalArgumentException
    //   2805	2815	2818	java/lang/IllegalArgumentException
    //   2819	2827	2830	java/lang/IllegalArgumentException
    //   2824	2842	2842	java/lang/IllegalArgumentException
    //   2858	2891	2894	java/lang/IllegalArgumentException
    //   2886	2902	2905	java/lang/IllegalArgumentException
    //   2895	2909	2912	java/lang/IllegalArgumentException
    //   2915	2936	2939	java/lang/IllegalArgumentException
    //   2960	2973	2976	java/lang/IllegalArgumentException
    //   2965	3003	3006	java/lang/IllegalArgumentException
    //   2977	3023	3026	java/lang/IllegalArgumentException
    //   3096	3128	3131	java/lang/IllegalArgumentException
    //   3206	3250	3253	java/lang/IllegalArgumentException
    //   3267	3296	3299	java/lang/IllegalArgumentException
    //   3272	3320	3323	java/lang/IllegalArgumentException
    //   3300	3345	3348	java/lang/IllegalArgumentException
    //   3324	3377	3380	java/lang/IllegalArgumentException
    //   3349	3406	3409	java/lang/IllegalArgumentException
    //   3424	3441	3444	java/lang/IllegalArgumentException
    //   3436	3446	3449	java/lang/IllegalArgumentException
    //   3503	3516	3519	java/lang/IllegalArgumentException
    //   3508	3532	3535	java/lang/IllegalArgumentException
    //   3536	3555	3558	java/lang/IllegalArgumentException
    //   3559	3575	3578	java/lang/IllegalArgumentException
    //   3567	3587	3590	java/lang/IllegalArgumentException
    //   3665	3698	3701	java/lang/IllegalArgumentException
    //   3739	3782	3785	java/lang/IllegalArgumentException
    //   3759	3814	3817	java/lang/IllegalArgumentException
    //   3786	3841	3844	java/lang/IllegalArgumentException
    //   3863	3871	3874	java/lang/IllegalArgumentException
    //   3868	3879	3882	java/lang/IllegalArgumentException
    //   3883	3891	3894	java/lang/IllegalArgumentException
    //   3888	3899	3902	java/lang/IllegalArgumentException
    //   3903	3911	3914	java/lang/IllegalArgumentException
    //   3960	3973	3976	java/lang/IllegalArgumentException
    //   3977	3991	3994	java/lang/IllegalArgumentException
    //   3980	4003	4006	java/lang/IllegalArgumentException
    //   3995	4008	4011	java/lang/IllegalArgumentException
    //   4048	4056	4059	java/lang/IllegalArgumentException
    //   4053	4064	4067	java/lang/IllegalArgumentException
    //   4068	4076	4079	java/lang/IllegalArgumentException
    //   4073	4084	4087	java/lang/IllegalArgumentException
    //   4088	4096	4099	java/lang/IllegalArgumentException
    //   4145	4158	4161	java/lang/IllegalArgumentException
    //   4162	4176	4179	java/lang/IllegalArgumentException
    //   4165	4188	4191	java/lang/IllegalArgumentException
    //   4180	4193	4196	java/lang/IllegalArgumentException
    //   4228	4240	4243	java/lang/IllegalArgumentException
    //   4244	4258	4261	java/lang/IllegalArgumentException
    //   4270	4280	4283	java/lang/IllegalArgumentException
    //   4311	4365	4368	java/lang/IllegalArgumentException
    //   4416	4426	4429	java/lang/IllegalArgumentException
    //   4453	4461	4464	java/lang/IllegalArgumentException
    //   4458	4474	4477	java/lang/IllegalArgumentException
    //   4558	4566	4569	java/lang/IllegalArgumentException
    //   4581	4604	4607	java/lang/IllegalArgumentException
    //   4597	4611	4614	java/lang/IllegalArgumentException
    //   4608	4625	4628	java/lang/IllegalArgumentException
    //   4698	4717	4720	java/lang/IllegalArgumentException
    //   4701	4726	4729	java/lang/IllegalArgumentException
    //   4721	4740	4743	java/lang/IllegalArgumentException
    //   4828	4838	4841	java/lang/IllegalArgumentException
  }
  
  private int[] a(MethodVisitor paramMethodVisitor, Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_2
    //   1: getfield c : [C
    //   4: astore #6
    //   6: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   9: aload_0
    //   10: iload_3
    //   11: invokevirtual readUnsignedShort : (I)I
    //   14: newarray int
    //   16: astore #7
    //   18: istore #5
    //   20: iinc #3, 2
    //   23: iconst_0
    //   24: istore #8
    //   26: iload #8
    //   28: aload #7
    //   30: arraylength
    //   31: if_icmpge -> 430
    //   34: aload #7
    //   36: iload #5
    //   38: ifne -> 432
    //   41: iload #8
    //   43: iload_3
    //   44: iastore
    //   45: aload_0
    //   46: iload_3
    //   47: invokevirtual readInt : (I)I
    //   50: istore #9
    //   52: iload #5
    //   54: ifne -> 184
    //   57: iload #9
    //   59: bipush #24
    //   61: iushr
    //   62: lookupswitch default -> 298, 0 -> 177, 1 -> 177, 19 -> 189, 20 -> 189, 21 -> 189, 22 -> 177, 64 -> 201, 65 -> 201, 71 -> 286, 72 -> 286, 73 -> 286, 74 -> 286, 75 -> 286
    //   176: athrow
    //   177: iinc #3, 2
    //   180: goto -> 184
    //   183: athrow
    //   184: iload #5
    //   186: ifeq -> 305
    //   189: iinc #3, 1
    //   192: iload #5
    //   194: ifeq -> 305
    //   197: goto -> 201
    //   200: athrow
    //   201: aload_0
    //   202: iload_3
    //   203: iconst_1
    //   204: iadd
    //   205: invokevirtual readUnsignedShort : (I)I
    //   208: istore #10
    //   210: iload #10
    //   212: ifle -> 278
    //   215: aload_0
    //   216: iload_3
    //   217: iconst_3
    //   218: iadd
    //   219: invokevirtual readUnsignedShort : (I)I
    //   222: istore #11
    //   224: aload_0
    //   225: iload_3
    //   226: iconst_5
    //   227: iadd
    //   228: invokevirtual readUnsignedShort : (I)I
    //   231: istore #12
    //   233: aload_0
    //   234: iload #11
    //   236: aload_2
    //   237: getfield h : [Lorg/objectweb/asm/Label;
    //   240: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   243: pop
    //   244: aload_0
    //   245: iload #11
    //   247: iload #12
    //   249: iadd
    //   250: aload_2
    //   251: getfield h : [Lorg/objectweb/asm/Label;
    //   254: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   257: pop
    //   258: iinc #3, 6
    //   261: iinc #10, -1
    //   264: iload #5
    //   266: ifne -> 281
    //   269: iload #5
    //   271: ifeq -> 210
    //   274: goto -> 278
    //   277: athrow
    //   278: iinc #3, 3
    //   281: iload #5
    //   283: ifeq -> 305
    //   286: iinc #3, 4
    //   289: iload #5
    //   291: ifeq -> 305
    //   294: goto -> 298
    //   297: athrow
    //   298: iinc #3, 3
    //   301: goto -> 305
    //   304: athrow
    //   305: aload_0
    //   306: iload_3
    //   307: invokevirtual readByte : (I)I
    //   310: istore #10
    //   312: iload #9
    //   314: bipush #24
    //   316: iushr
    //   317: iload #5
    //   319: ifne -> 421
    //   322: bipush #66
    //   324: if_icmpne -> 401
    //   327: goto -> 331
    //   330: athrow
    //   331: iload #10
    //   333: ifne -> 345
    //   336: goto -> 340
    //   339: athrow
    //   340: aconst_null
    //   341: goto -> 357
    //   344: athrow
    //   345: new org/objectweb/asm/TypePath
    //   348: dup
    //   349: aload_0
    //   350: getfield b : [B
    //   353: iload_3
    //   354: invokespecial <init> : ([BI)V
    //   357: astore #11
    //   359: iload_3
    //   360: iconst_1
    //   361: iconst_2
    //   362: iload #10
    //   364: imul
    //   365: iadd
    //   366: iadd
    //   367: istore_3
    //   368: aload_0
    //   369: iload_3
    //   370: iconst_2
    //   371: iadd
    //   372: aload #6
    //   374: iconst_1
    //   375: aload_1
    //   376: iload #9
    //   378: aload #11
    //   380: aload_0
    //   381: iload_3
    //   382: aload #6
    //   384: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   387: iload #4
    //   389: invokevirtual visitTryCatchAnnotation : (ILorg/objectweb/asm/TypePath;Ljava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   392: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   395: istore_3
    //   396: iload #5
    //   398: ifeq -> 422
    //   401: aload_0
    //   402: iload_3
    //   403: iconst_3
    //   404: iadd
    //   405: iconst_2
    //   406: iload #10
    //   408: imul
    //   409: iadd
    //   410: aload #6
    //   412: iconst_1
    //   413: aconst_null
    //   414: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   417: goto -> 421
    //   420: athrow
    //   421: istore_3
    //   422: iinc #8, 1
    //   425: iload #5
    //   427: ifeq -> 26
    //   430: aload #7
    //   432: areturn
    // Exception table:
    //   from	to	target	type
    //   52	176	176	java/lang/IllegalArgumentException
    //   57	180	183	java/lang/IllegalArgumentException
    //   184	197	200	java/lang/IllegalArgumentException
    //   233	274	277	java/lang/IllegalArgumentException
    //   281	294	297	java/lang/IllegalArgumentException
    //   286	301	304	java/lang/IllegalArgumentException
    //   312	327	330	java/lang/IllegalArgumentException
    //   322	336	339	java/lang/IllegalArgumentException
    //   331	344	344	java/lang/IllegalArgumentException
    //   396	417	420	java/lang/IllegalArgumentException
  }
  
  private int a(Context paramContext, int paramInt) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore_3
    //   4: aload_0
    //   5: iload_2
    //   6: invokevirtual readInt : (I)I
    //   9: istore #4
    //   11: iload #4
    //   13: bipush #24
    //   15: iushr
    //   16: iload_3
    //   17: ifne -> 329
    //   20: lookupswitch default -> 323, 0 -> 137, 1 -> 137, 19 -> 151, 20 -> 151, 21 -> 151, 22 -> 137, 64 -> 165, 65 -> 165, 71 -> 309, 72 -> 309, 73 -> 309, 74 -> 309, 75 -> 309
    //   136: athrow
    //   137: iload #4
    //   139: ldc -65536
    //   141: iand
    //   142: istore #4
    //   144: iinc #2, 2
    //   147: iload_3
    //   148: ifeq -> 365
    //   151: iload #4
    //   153: ldc -16777216
    //   155: iand
    //   156: istore #4
    //   158: iinc #2, 1
    //   161: iload_3
    //   162: ifeq -> 365
    //   165: iload #4
    //   167: ldc -16777216
    //   169: iand
    //   170: istore #4
    //   172: aload_0
    //   173: iload_2
    //   174: iconst_1
    //   175: iadd
    //   176: invokevirtual readUnsignedShort : (I)I
    //   179: istore #5
    //   181: aload_1
    //   182: iload #5
    //   184: anewarray org/objectweb/asm/Label
    //   187: putfield l : [Lorg/objectweb/asm/Label;
    //   190: aload_1
    //   191: iload #5
    //   193: anewarray org/objectweb/asm/Label
    //   196: putfield m : [Lorg/objectweb/asm/Label;
    //   199: aload_1
    //   200: iload #5
    //   202: newarray int
    //   204: putfield n : [I
    //   207: iinc #2, 3
    //   210: iconst_0
    //   211: istore #6
    //   213: iload #6
    //   215: iload #5
    //   217: if_icmpge -> 305
    //   220: aload_0
    //   221: iload_2
    //   222: invokevirtual readUnsignedShort : (I)I
    //   225: istore #7
    //   227: aload_0
    //   228: iload_2
    //   229: iconst_2
    //   230: iadd
    //   231: invokevirtual readUnsignedShort : (I)I
    //   234: istore #8
    //   236: aload_1
    //   237: getfield l : [Lorg/objectweb/asm/Label;
    //   240: iload #6
    //   242: aload_0
    //   243: iload #7
    //   245: aload_1
    //   246: getfield h : [Lorg/objectweb/asm/Label;
    //   249: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   252: aastore
    //   253: aload_1
    //   254: getfield m : [Lorg/objectweb/asm/Label;
    //   257: iload #6
    //   259: aload_0
    //   260: iload #7
    //   262: iload #8
    //   264: iadd
    //   265: aload_1
    //   266: getfield h : [Lorg/objectweb/asm/Label;
    //   269: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   272: aastore
    //   273: aload_1
    //   274: getfield n : [I
    //   277: iload #6
    //   279: aload_0
    //   280: iload_2
    //   281: iconst_4
    //   282: iadd
    //   283: invokevirtual readUnsignedShort : (I)I
    //   286: iastore
    //   287: iinc #2, 6
    //   290: iinc #6, 1
    //   293: iload_3
    //   294: ifne -> 378
    //   297: iload_3
    //   298: ifeq -> 213
    //   301: goto -> 305
    //   304: athrow
    //   305: iload_3
    //   306: ifeq -> 365
    //   309: iload #4
    //   311: ldc -16776961
    //   313: iand
    //   314: istore #4
    //   316: iinc #2, 4
    //   319: iload_3
    //   320: ifeq -> 365
    //   323: iload #4
    //   325: goto -> 329
    //   328: athrow
    //   329: iload #4
    //   331: bipush #24
    //   333: iushr
    //   334: iload_3
    //   335: ifne -> 354
    //   338: bipush #67
    //   340: if_icmpge -> 357
    //   343: goto -> 347
    //   346: athrow
    //   347: sipush #-256
    //   350: goto -> 354
    //   353: athrow
    //   354: goto -> 359
    //   357: ldc -16777216
    //   359: iand
    //   360: istore #4
    //   362: iinc #2, 3
    //   365: aload_0
    //   366: iload_2
    //   367: invokevirtual readByte : (I)I
    //   370: istore #5
    //   372: aload_1
    //   373: iload #4
    //   375: putfield i : I
    //   378: aload_1
    //   379: iload #5
    //   381: ifne -> 389
    //   384: aconst_null
    //   385: goto -> 401
    //   388: athrow
    //   389: new org/objectweb/asm/TypePath
    //   392: dup
    //   393: aload_0
    //   394: getfield b : [B
    //   397: iload_2
    //   398: invokespecial <init> : ([BI)V
    //   401: putfield j : Lorg/objectweb/asm/TypePath;
    //   404: iload_2
    //   405: iconst_1
    //   406: iadd
    //   407: iconst_2
    //   408: iload #5
    //   410: imul
    //   411: iadd
    //   412: ireturn
    // Exception table:
    //   from	to	target	type
    //   11	136	136	java/lang/IllegalArgumentException
    //   236	301	304	java/lang/IllegalArgumentException
    //   316	325	328	java/lang/IllegalArgumentException
    //   329	343	346	java/lang/IllegalArgumentException
    //   338	350	353	java/lang/IllegalArgumentException
    //   378	388	388	java/lang/IllegalArgumentException
  }
  
  private void b(MethodVisitor paramMethodVisitor, Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : [B
    //   4: iload_3
    //   5: iinc #3, 1
    //   8: baload
    //   9: sipush #255
    //   12: iand
    //   13: istore #7
    //   15: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   18: aload_2
    //   19: getfield g : Ljava/lang/String;
    //   22: invokestatic getArgumentTypes : (Ljava/lang/String;)[Lorg/objectweb/asm/Type;
    //   25: arraylength
    //   26: iload #7
    //   28: isub
    //   29: istore #8
    //   31: iconst_0
    //   32: istore #6
    //   34: istore #5
    //   36: iload #6
    //   38: iload #8
    //   40: if_icmpge -> 92
    //   43: aload_1
    //   44: iload #6
    //   46: sipush #29958
    //   49: sipush #-14245
    //   52: invokestatic a : (II)Ljava/lang/String;
    //   55: iconst_0
    //   56: invokevirtual visitParameterAnnotation : (ILjava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   59: astore #9
    //   61: iload #5
    //   63: ifne -> 87
    //   66: aload #9
    //   68: ifnull -> 84
    //   71: goto -> 75
    //   74: athrow
    //   75: aload #9
    //   77: invokevirtual visitEnd : ()V
    //   80: goto -> 84
    //   83: athrow
    //   84: iinc #6, 1
    //   87: iload #5
    //   89: ifeq -> 36
    //   92: aload_2
    //   93: getfield c : [C
    //   96: astore #10
    //   98: iload #6
    //   100: iload #7
    //   102: iload #8
    //   104: iadd
    //   105: if_icmpge -> 178
    //   108: aload_0
    //   109: iload_3
    //   110: invokevirtual readUnsignedShort : (I)I
    //   113: istore #11
    //   115: iinc #3, 2
    //   118: iload #11
    //   120: ifle -> 170
    //   123: aload_1
    //   124: iload #6
    //   126: aload_0
    //   127: iload_3
    //   128: aload #10
    //   130: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   133: iload #4
    //   135: invokevirtual visitParameterAnnotation : (ILjava/lang/String;Z)Lorg/objectweb/asm/AnnotationVisitor;
    //   138: astore #9
    //   140: aload_0
    //   141: iload_3
    //   142: iconst_2
    //   143: iadd
    //   144: aload #10
    //   146: iconst_1
    //   147: aload #9
    //   149: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   152: istore_3
    //   153: iinc #11, -1
    //   156: iload #5
    //   158: ifne -> 173
    //   161: iload #5
    //   163: ifeq -> 118
    //   166: goto -> 170
    //   169: athrow
    //   170: iinc #6, 1
    //   173: iload #5
    //   175: ifeq -> 98
    //   178: return
    // Exception table:
    //   from	to	target	type
    //   61	71	74	java/lang/IllegalArgumentException
    //   66	80	83	java/lang/IllegalArgumentException
    //   153	166	169	java/lang/IllegalArgumentException
  }
  
  private int a(int paramInt, char[] paramArrayOfchar, boolean paramBoolean, AnnotationVisitor paramAnnotationVisitor) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokevirtual readUnsignedShort : (I)I
    //   5: istore #6
    //   7: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   10: iinc #1, 2
    //   13: istore #5
    //   15: iload_3
    //   16: iload #5
    //   18: ifne -> 73
    //   21: ifeq -> 71
    //   24: goto -> 28
    //   27: athrow
    //   28: iload #6
    //   30: ifle -> 103
    //   33: goto -> 37
    //   36: athrow
    //   37: aload_0
    //   38: iload_1
    //   39: iconst_2
    //   40: iadd
    //   41: aload_2
    //   42: aload_0
    //   43: iload_1
    //   44: aload_2
    //   45: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   48: aload #4
    //   50: invokespecial a : (I[CLjava/lang/String;Lorg/objectweb/asm/AnnotationVisitor;)I
    //   53: istore_1
    //   54: iinc #6, -1
    //   57: iload #5
    //   59: ifne -> 122
    //   62: iload #5
    //   64: ifeq -> 28
    //   67: goto -> 71
    //   70: athrow
    //   71: iload #6
    //   73: ifle -> 103
    //   76: aload_0
    //   77: iload_1
    //   78: aload_2
    //   79: aconst_null
    //   80: aload #4
    //   82: invokespecial a : (I[CLjava/lang/String;Lorg/objectweb/asm/AnnotationVisitor;)I
    //   85: istore_1
    //   86: iinc #6, -1
    //   89: iload #5
    //   91: ifne -> 122
    //   94: iload #5
    //   96: ifeq -> 71
    //   99: goto -> 103
    //   102: athrow
    //   103: aload #4
    //   105: iload #5
    //   107: ifne -> 119
    //   110: ifnull -> 122
    //   113: goto -> 117
    //   116: athrow
    //   117: aload #4
    //   119: invokevirtual visitEnd : ()V
    //   122: iload_1
    //   123: ireturn
    // Exception table:
    //   from	to	target	type
    //   15	24	27	java/lang/IllegalArgumentException
    //   21	33	36	java/lang/IllegalArgumentException
    //   54	67	70	java/lang/IllegalArgumentException
    //   86	99	102	java/lang/IllegalArgumentException
    //   103	113	116	java/lang/IllegalArgumentException
  }
  
  private int a(int paramInt, char[] paramArrayOfchar, String paramString, AnnotationVisitor paramAnnotationVisitor) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #5
    //   5: aload #4
    //   7: ifnonnull -> 96
    //   10: aload_0
    //   11: getfield b : [B
    //   14: iload_1
    //   15: baload
    //   16: sipush #255
    //   19: iand
    //   20: iload #5
    //   22: ifne -> 95
    //   25: goto -> 29
    //   28: athrow
    //   29: lookupswitch default -> 92, 64 -> 70, 91 -> 81, 101 -> 65
    //   64: athrow
    //   65: iload_1
    //   66: iconst_5
    //   67: iadd
    //   68: ireturn
    //   69: athrow
    //   70: aload_0
    //   71: iload_1
    //   72: iconst_3
    //   73: iadd
    //   74: aload_2
    //   75: iconst_1
    //   76: aconst_null
    //   77: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   80: ireturn
    //   81: aload_0
    //   82: iload_1
    //   83: iconst_1
    //   84: iadd
    //   85: aload_2
    //   86: iconst_0
    //   87: aconst_null
    //   88: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   91: ireturn
    //   92: iload_1
    //   93: iconst_3
    //   94: iadd
    //   95: ireturn
    //   96: aload_0
    //   97: getfield b : [B
    //   100: iload_1
    //   101: iinc #1, 1
    //   104: baload
    //   105: sipush #255
    //   108: iand
    //   109: iload #5
    //   111: ifne -> 1427
    //   114: tableswitch default -> 1426, 64 -> 619, 65 -> 1426, 66 -> 365, 67 -> 494, 68 -> 337, 69 -> 1426, 70 -> 337, 71 -> 1426, 72 -> 1426, 73 -> 337, 74 -> 337, 75 -> 1426, 76 -> 1426, 77 -> 1426, 78 -> 1426, 79 -> 1426, 80 -> 1426, 81 -> 1426, 82 -> 1426, 83 -> 452, 84 -> 1426, 85 -> 1426, 86 -> 1426, 87 -> 1426, 88 -> 1426, 89 -> 1426, 90 -> 407, 91 -> 646, 92 -> 1426, 93 -> 1426, 94 -> 1426, 95 -> 1426, 96 -> 1426, 97 -> 1426, 98 -> 1426, 99 -> 592, 100 -> 1426, 101 -> 560, 102 -> 1426, 103 -> 1426, 104 -> 1426, 105 -> 1426, 106 -> 1426, 107 -> 1426, 108 -> 1426, 109 -> 1426, 110 -> 1426, 111 -> 1426, 112 -> 1426, 113 -> 1426, 114 -> 1426, 115 -> 536
    //   336: athrow
    //   337: aload #4
    //   339: aload_3
    //   340: aload_0
    //   341: aload_0
    //   342: iload_1
    //   343: invokevirtual readUnsignedShort : (I)I
    //   346: aload_2
    //   347: invokevirtual readConst : (I[C)Ljava/lang/Object;
    //   350: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   353: iinc #1, 2
    //   356: iload #5
    //   358: ifeq -> 1426
    //   361: goto -> 365
    //   364: athrow
    //   365: aload #4
    //   367: aload_3
    //   368: aload_0
    //   369: aload_0
    //   370: getfield a : [I
    //   373: aload_0
    //   374: iload_1
    //   375: invokevirtual readUnsignedShort : (I)I
    //   378: iaload
    //   379: invokevirtual readInt : (I)I
    //   382: i2b
    //   383: new java/lang/Byte
    //   386: dup
    //   387: dup2_x1
    //   388: pop2
    //   389: invokespecial <init> : (B)V
    //   392: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   395: iinc #1, 2
    //   398: iload #5
    //   400: ifeq -> 1426
    //   403: goto -> 407
    //   406: athrow
    //   407: aload #4
    //   409: aload_3
    //   410: aload_0
    //   411: aload_0
    //   412: getfield a : [I
    //   415: aload_0
    //   416: iload_1
    //   417: invokevirtual readUnsignedShort : (I)I
    //   420: iaload
    //   421: invokevirtual readInt : (I)I
    //   424: ifne -> 438
    //   427: goto -> 431
    //   430: athrow
    //   431: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   434: goto -> 441
    //   437: athrow
    //   438: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   441: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   444: iinc #1, 2
    //   447: iload #5
    //   449: ifeq -> 1426
    //   452: aload #4
    //   454: aload_3
    //   455: aload_0
    //   456: aload_0
    //   457: getfield a : [I
    //   460: aload_0
    //   461: iload_1
    //   462: invokevirtual readUnsignedShort : (I)I
    //   465: iaload
    //   466: invokevirtual readInt : (I)I
    //   469: i2s
    //   470: new java/lang/Short
    //   473: dup
    //   474: dup2_x1
    //   475: pop2
    //   476: invokespecial <init> : (S)V
    //   479: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   482: iinc #1, 2
    //   485: iload #5
    //   487: ifeq -> 1426
    //   490: goto -> 494
    //   493: athrow
    //   494: aload #4
    //   496: aload_3
    //   497: aload_0
    //   498: aload_0
    //   499: getfield a : [I
    //   502: aload_0
    //   503: iload_1
    //   504: invokevirtual readUnsignedShort : (I)I
    //   507: iaload
    //   508: invokevirtual readInt : (I)I
    //   511: i2c
    //   512: new java/lang/Character
    //   515: dup
    //   516: dup2_x1
    //   517: pop2
    //   518: invokespecial <init> : (C)V
    //   521: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   524: iinc #1, 2
    //   527: iload #5
    //   529: ifeq -> 1426
    //   532: goto -> 536
    //   535: athrow
    //   536: aload #4
    //   538: aload_3
    //   539: aload_0
    //   540: iload_1
    //   541: aload_2
    //   542: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   545: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   548: iinc #1, 2
    //   551: iload #5
    //   553: ifeq -> 1426
    //   556: goto -> 560
    //   559: athrow
    //   560: aload #4
    //   562: aload_3
    //   563: aload_0
    //   564: iload_1
    //   565: aload_2
    //   566: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   569: aload_0
    //   570: iload_1
    //   571: iconst_2
    //   572: iadd
    //   573: aload_2
    //   574: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   577: invokevirtual visitEnum : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   580: iinc #1, 4
    //   583: iload #5
    //   585: ifeq -> 1426
    //   588: goto -> 592
    //   591: athrow
    //   592: aload #4
    //   594: aload_3
    //   595: aload_0
    //   596: iload_1
    //   597: aload_2
    //   598: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   601: invokestatic getType : (Ljava/lang/String;)Lorg/objectweb/asm/Type;
    //   604: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   607: iinc #1, 2
    //   610: iload #5
    //   612: ifeq -> 1426
    //   615: goto -> 619
    //   618: athrow
    //   619: aload_0
    //   620: iload_1
    //   621: iconst_2
    //   622: iadd
    //   623: aload_2
    //   624: iconst_1
    //   625: aload #4
    //   627: aload_3
    //   628: aload_0
    //   629: iload_1
    //   630: aload_2
    //   631: invokevirtual readUTF8 : (I[C)Ljava/lang/String;
    //   634: invokevirtual visitAnnotation : (Ljava/lang/String;Ljava/lang/String;)Lorg/objectweb/asm/AnnotationVisitor;
    //   637: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   640: istore_1
    //   641: iload #5
    //   643: ifeq -> 1426
    //   646: aload_0
    //   647: iload_1
    //   648: invokevirtual readUnsignedShort : (I)I
    //   651: istore #7
    //   653: iinc #1, 2
    //   656: iload #7
    //   658: iload #5
    //   660: ifne -> 700
    //   663: ifne -> 687
    //   666: goto -> 670
    //   669: athrow
    //   670: aload_0
    //   671: iload_1
    //   672: iconst_2
    //   673: isub
    //   674: aload_2
    //   675: iconst_0
    //   676: aload #4
    //   678: aload_3
    //   679: invokevirtual visitArray : (Ljava/lang/String;)Lorg/objectweb/asm/AnnotationVisitor;
    //   682: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   685: ireturn
    //   686: athrow
    //   687: aload_0
    //   688: getfield b : [B
    //   691: iload_1
    //   692: iinc #1, 1
    //   695: baload
    //   696: sipush #255
    //   699: iand
    //   700: iload #5
    //   702: ifne -> 1425
    //   705: tableswitch default -> 1406, 66 -> 821, 67 -> 1044, 68 -> 1332, 69 -> 1406, 70 -> 1258, 71 -> 1406, 72 -> 1406, 73 -> 1116, 74 -> 1187, 75 -> 1406, 76 -> 1406, 77 -> 1406, 78 -> 1406, 79 -> 1406, 80 -> 1406, 81 -> 1406, 82 -> 1406, 83 -> 972, 84 -> 1406, 85 -> 1406, 86 -> 1406, 87 -> 1406, 88 -> 1406, 89 -> 1406, 90 -> 893
    //   820: athrow
    //   821: iload #7
    //   823: newarray byte
    //   825: astore #8
    //   827: iconst_0
    //   828: istore #6
    //   830: iload #6
    //   832: iload #7
    //   834: if_icmpge -> 877
    //   837: aload #8
    //   839: iload #6
    //   841: aload_0
    //   842: aload_0
    //   843: getfield a : [I
    //   846: aload_0
    //   847: iload_1
    //   848: invokevirtual readUnsignedShort : (I)I
    //   851: iaload
    //   852: invokevirtual readInt : (I)I
    //   855: i2b
    //   856: bastore
    //   857: iinc #1, 3
    //   860: iinc #6, 1
    //   863: iload #5
    //   865: ifne -> 888
    //   868: iload #5
    //   870: ifeq -> 830
    //   873: goto -> 877
    //   876: athrow
    //   877: aload #4
    //   879: aload_3
    //   880: aload #8
    //   882: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   885: iinc #1, -1
    //   888: iload #5
    //   890: ifeq -> 1426
    //   893: iload #7
    //   895: newarray boolean
    //   897: astore #9
    //   899: iconst_0
    //   900: istore #6
    //   902: iload #6
    //   904: iload #7
    //   906: if_icmpge -> 956
    //   909: aload #9
    //   911: iload #6
    //   913: aload_0
    //   914: aload_0
    //   915: getfield a : [I
    //   918: aload_0
    //   919: iload_1
    //   920: invokevirtual readUnsignedShort : (I)I
    //   923: iaload
    //   924: invokevirtual readInt : (I)I
    //   927: iload #5
    //   929: ifne -> 940
    //   932: ifeq -> 943
    //   935: goto -> 939
    //   938: athrow
    //   939: iconst_1
    //   940: goto -> 944
    //   943: iconst_0
    //   944: bastore
    //   945: iinc #1, 3
    //   948: iinc #6, 1
    //   951: iload #5
    //   953: ifeq -> 902
    //   956: aload #4
    //   958: aload_3
    //   959: aload #9
    //   961: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   964: iinc #1, -1
    //   967: iload #5
    //   969: ifeq -> 1426
    //   972: iload #7
    //   974: newarray short
    //   976: astore #10
    //   978: iconst_0
    //   979: istore #6
    //   981: iload #6
    //   983: iload #7
    //   985: if_icmpge -> 1028
    //   988: aload #10
    //   990: iload #6
    //   992: aload_0
    //   993: aload_0
    //   994: getfield a : [I
    //   997: aload_0
    //   998: iload_1
    //   999: invokevirtual readUnsignedShort : (I)I
    //   1002: iaload
    //   1003: invokevirtual readInt : (I)I
    //   1006: i2s
    //   1007: sastore
    //   1008: iinc #1, 3
    //   1011: iinc #6, 1
    //   1014: iload #5
    //   1016: ifne -> 1039
    //   1019: iload #5
    //   1021: ifeq -> 981
    //   1024: goto -> 1028
    //   1027: athrow
    //   1028: aload #4
    //   1030: aload_3
    //   1031: aload #10
    //   1033: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1036: iinc #1, -1
    //   1039: iload #5
    //   1041: ifeq -> 1426
    //   1044: iload #7
    //   1046: newarray char
    //   1048: astore #11
    //   1050: iconst_0
    //   1051: istore #6
    //   1053: iload #6
    //   1055: iload #7
    //   1057: if_icmpge -> 1100
    //   1060: aload #11
    //   1062: iload #6
    //   1064: aload_0
    //   1065: aload_0
    //   1066: getfield a : [I
    //   1069: aload_0
    //   1070: iload_1
    //   1071: invokevirtual readUnsignedShort : (I)I
    //   1074: iaload
    //   1075: invokevirtual readInt : (I)I
    //   1078: i2c
    //   1079: castore
    //   1080: iinc #1, 3
    //   1083: iinc #6, 1
    //   1086: iload #5
    //   1088: ifne -> 1111
    //   1091: iload #5
    //   1093: ifeq -> 1053
    //   1096: goto -> 1100
    //   1099: athrow
    //   1100: aload #4
    //   1102: aload_3
    //   1103: aload #11
    //   1105: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1108: iinc #1, -1
    //   1111: iload #5
    //   1113: ifeq -> 1426
    //   1116: iload #7
    //   1118: newarray int
    //   1120: astore #12
    //   1122: iconst_0
    //   1123: istore #6
    //   1125: iload #6
    //   1127: iload #7
    //   1129: if_icmpge -> 1171
    //   1132: aload #12
    //   1134: iload #6
    //   1136: aload_0
    //   1137: aload_0
    //   1138: getfield a : [I
    //   1141: aload_0
    //   1142: iload_1
    //   1143: invokevirtual readUnsignedShort : (I)I
    //   1146: iaload
    //   1147: invokevirtual readInt : (I)I
    //   1150: iastore
    //   1151: iinc #1, 3
    //   1154: iinc #6, 1
    //   1157: iload #5
    //   1159: ifne -> 1182
    //   1162: iload #5
    //   1164: ifeq -> 1125
    //   1167: goto -> 1171
    //   1170: athrow
    //   1171: aload #4
    //   1173: aload_3
    //   1174: aload #12
    //   1176: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1179: iinc #1, -1
    //   1182: iload #5
    //   1184: ifeq -> 1426
    //   1187: iload #7
    //   1189: newarray long
    //   1191: astore #13
    //   1193: iconst_0
    //   1194: istore #6
    //   1196: iload #6
    //   1198: iload #7
    //   1200: if_icmpge -> 1242
    //   1203: aload #13
    //   1205: iload #6
    //   1207: aload_0
    //   1208: aload_0
    //   1209: getfield a : [I
    //   1212: aload_0
    //   1213: iload_1
    //   1214: invokevirtual readUnsignedShort : (I)I
    //   1217: iaload
    //   1218: invokevirtual readLong : (I)J
    //   1221: lastore
    //   1222: iinc #1, 3
    //   1225: iinc #6, 1
    //   1228: iload #5
    //   1230: ifne -> 1253
    //   1233: iload #5
    //   1235: ifeq -> 1196
    //   1238: goto -> 1242
    //   1241: athrow
    //   1242: aload #4
    //   1244: aload_3
    //   1245: aload #13
    //   1247: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1250: iinc #1, -1
    //   1253: iload #5
    //   1255: ifeq -> 1426
    //   1258: iload #7
    //   1260: newarray float
    //   1262: astore #14
    //   1264: iconst_0
    //   1265: istore #6
    //   1267: iload #6
    //   1269: iload #7
    //   1271: if_icmpge -> 1316
    //   1274: aload #14
    //   1276: iload #6
    //   1278: aload_0
    //   1279: aload_0
    //   1280: getfield a : [I
    //   1283: aload_0
    //   1284: iload_1
    //   1285: invokevirtual readUnsignedShort : (I)I
    //   1288: iaload
    //   1289: invokevirtual readInt : (I)I
    //   1292: invokestatic intBitsToFloat : (I)F
    //   1295: fastore
    //   1296: iinc #1, 3
    //   1299: iinc #6, 1
    //   1302: iload #5
    //   1304: ifne -> 1327
    //   1307: iload #5
    //   1309: ifeq -> 1267
    //   1312: goto -> 1316
    //   1315: athrow
    //   1316: aload #4
    //   1318: aload_3
    //   1319: aload #14
    //   1321: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1324: iinc #1, -1
    //   1327: iload #5
    //   1329: ifeq -> 1426
    //   1332: iload #7
    //   1334: newarray double
    //   1336: astore #15
    //   1338: iconst_0
    //   1339: istore #6
    //   1341: iload #6
    //   1343: iload #7
    //   1345: if_icmpge -> 1390
    //   1348: aload #15
    //   1350: iload #6
    //   1352: aload_0
    //   1353: aload_0
    //   1354: getfield a : [I
    //   1357: aload_0
    //   1358: iload_1
    //   1359: invokevirtual readUnsignedShort : (I)I
    //   1362: iaload
    //   1363: invokevirtual readLong : (I)J
    //   1366: invokestatic longBitsToDouble : (J)D
    //   1369: dastore
    //   1370: iinc #1, 3
    //   1373: iinc #6, 1
    //   1376: iload #5
    //   1378: ifne -> 1401
    //   1381: iload #5
    //   1383: ifeq -> 1341
    //   1386: goto -> 1390
    //   1389: athrow
    //   1390: aload #4
    //   1392: aload_3
    //   1393: aload #15
    //   1395: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1398: iinc #1, -1
    //   1401: iload #5
    //   1403: ifeq -> 1426
    //   1406: aload_0
    //   1407: iload_1
    //   1408: iconst_3
    //   1409: isub
    //   1410: aload_2
    //   1411: iconst_0
    //   1412: aload #4
    //   1414: aload_3
    //   1415: invokevirtual visitArray : (Ljava/lang/String;)Lorg/objectweb/asm/AnnotationVisitor;
    //   1418: invokespecial a : (I[CZLorg/objectweb/asm/AnnotationVisitor;)I
    //   1421: goto -> 1425
    //   1424: athrow
    //   1425: istore_1
    //   1426: iload_1
    //   1427: ireturn
    // Exception table:
    //   from	to	target	type
    //   5	25	28	java/lang/IllegalArgumentException
    //   10	64	64	java/lang/IllegalArgumentException
    //   29	69	69	java/lang/IllegalArgumentException
    //   96	336	336	java/lang/IllegalArgumentException
    //   114	361	364	java/lang/IllegalArgumentException
    //   337	403	406	java/lang/IllegalArgumentException
    //   365	427	430	java/lang/IllegalArgumentException
    //   407	437	437	java/lang/IllegalArgumentException
    //   441	490	493	java/lang/IllegalArgumentException
    //   452	532	535	java/lang/IllegalArgumentException
    //   494	556	559	java/lang/IllegalArgumentException
    //   536	588	591	java/lang/IllegalArgumentException
    //   560	615	618	java/lang/IllegalArgumentException
    //   653	666	669	java/lang/IllegalArgumentException
    //   663	686	686	java/lang/IllegalArgumentException
    //   700	820	820	java/lang/IllegalArgumentException
    //   837	873	876	java/lang/IllegalArgumentException
    //   909	935	938	java/lang/IllegalArgumentException
    //   988	1024	1027	java/lang/IllegalArgumentException
    //   1060	1096	1099	java/lang/IllegalArgumentException
    //   1132	1167	1170	java/lang/IllegalArgumentException
    //   1203	1238	1241	java/lang/IllegalArgumentException
    //   1274	1312	1315	java/lang/IllegalArgumentException
    //   1348	1386	1389	java/lang/IllegalArgumentException
    //   1401	1421	1424	java/lang/IllegalArgumentException
  }
  
  private void a(Context paramContext) {
    // Byte code:
    //   0: aload_1
    //   1: getfield g : Ljava/lang/String;
    //   4: astore_3
    //   5: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   8: aload_1
    //   9: getfield s : [Ljava/lang/Object;
    //   12: astore #4
    //   14: istore_2
    //   15: iconst_0
    //   16: istore #5
    //   18: aload_1
    //   19: getfield e : I
    //   22: bipush #8
    //   24: iand
    //   25: iload_2
    //   26: ifne -> 105
    //   29: ifne -> 104
    //   32: goto -> 36
    //   35: athrow
    //   36: sipush #29980
    //   39: sipush #-30011
    //   42: invokestatic a : (II)Ljava/lang/String;
    //   45: aload_1
    //   46: getfield f : Ljava/lang/String;
    //   49: invokevirtual equals : (Ljava/lang/Object;)Z
    //   52: ifeq -> 78
    //   55: goto -> 59
    //   58: athrow
    //   59: aload #4
    //   61: iload #5
    //   63: iinc #5, 1
    //   66: getstatic org/objectweb/asm/Opcodes.UNINITIALIZED_THIS : Ljava/lang/Integer;
    //   69: aastore
    //   70: iload_2
    //   71: ifeq -> 104
    //   74: goto -> 78
    //   77: athrow
    //   78: aload #4
    //   80: iload #5
    //   82: iinc #5, 1
    //   85: aload_0
    //   86: aload_0
    //   87: getfield header : I
    //   90: iconst_2
    //   91: iadd
    //   92: aload_1
    //   93: getfield c : [C
    //   96: invokevirtual readClass : (I[C)Ljava/lang/String;
    //   99: aastore
    //   100: goto -> 104
    //   103: athrow
    //   104: iconst_1
    //   105: istore #6
    //   107: iload #6
    //   109: istore #7
    //   111: aload_3
    //   112: iload #6
    //   114: iinc #6, 1
    //   117: invokevirtual charAt : (I)C
    //   120: tableswitch default -> 464, 66 -> 240, 67 -> 240, 68 -> 293, 69 -> 464, 70 -> 255, 71 -> 464, 72 -> 464, 73 -> 240, 74 -> 274, 75 -> 464, 76 -> 409, 77 -> 464, 78 -> 464, 79 -> 464, 80 -> 464, 81 -> 464, 82 -> 464, 83 -> 240, 84 -> 464, 85 -> 464, 86 -> 464, 87 -> 464, 88 -> 464, 89 -> 464, 90 -> 240, 91 -> 312
    //   240: aload #4
    //   242: iload #5
    //   244: iinc #5, 1
    //   247: getstatic org/objectweb/asm/Opcodes.INTEGER : Ljava/lang/Integer;
    //   250: aastore
    //   251: iload_2
    //   252: ifeq -> 472
    //   255: aload #4
    //   257: iload #5
    //   259: iinc #5, 1
    //   262: getstatic org/objectweb/asm/Opcodes.FLOAT : Ljava/lang/Integer;
    //   265: aastore
    //   266: iload_2
    //   267: ifeq -> 472
    //   270: goto -> 274
    //   273: athrow
    //   274: aload #4
    //   276: iload #5
    //   278: iinc #5, 1
    //   281: getstatic org/objectweb/asm/Opcodes.LONG : Ljava/lang/Integer;
    //   284: aastore
    //   285: iload_2
    //   286: ifeq -> 472
    //   289: goto -> 293
    //   292: athrow
    //   293: aload #4
    //   295: iload #5
    //   297: iinc #5, 1
    //   300: getstatic org/objectweb/asm/Opcodes.DOUBLE : Ljava/lang/Integer;
    //   303: aastore
    //   304: iload_2
    //   305: ifeq -> 472
    //   308: goto -> 312
    //   311: athrow
    //   312: aload_3
    //   313: iload #6
    //   315: invokevirtual charAt : (I)C
    //   318: bipush #91
    //   320: if_icmpne -> 342
    //   323: goto -> 327
    //   326: athrow
    //   327: iinc #6, 1
    //   330: iload_2
    //   331: ifne -> 405
    //   334: iload_2
    //   335: ifeq -> 312
    //   338: goto -> 342
    //   341: athrow
    //   342: aload_3
    //   343: iload #6
    //   345: invokevirtual charAt : (I)C
    //   348: bipush #76
    //   350: if_icmpne -> 386
    //   353: iinc #6, 1
    //   356: goto -> 360
    //   359: athrow
    //   360: aload_3
    //   361: iload #6
    //   363: invokevirtual charAt : (I)C
    //   366: bipush #59
    //   368: if_icmpeq -> 386
    //   371: iinc #6, 1
    //   374: iload_2
    //   375: ifne -> 405
    //   378: iload_2
    //   379: ifeq -> 360
    //   382: goto -> 386
    //   385: athrow
    //   386: aload #4
    //   388: iload #5
    //   390: iinc #5, 1
    //   393: aload_3
    //   394: iload #7
    //   396: iinc #6, 1
    //   399: iload #6
    //   401: invokevirtual substring : (II)Ljava/lang/String;
    //   404: aastore
    //   405: iload_2
    //   406: ifeq -> 472
    //   409: aload_3
    //   410: iload #6
    //   412: invokevirtual charAt : (I)C
    //   415: bipush #59
    //   417: if_icmpeq -> 439
    //   420: goto -> 424
    //   423: athrow
    //   424: iinc #6, 1
    //   427: iload_2
    //   428: ifne -> 460
    //   431: iload_2
    //   432: ifeq -> 409
    //   435: goto -> 439
    //   438: athrow
    //   439: aload #4
    //   441: iload #5
    //   443: iinc #5, 1
    //   446: aload_3
    //   447: iload #7
    //   449: iconst_1
    //   450: iadd
    //   451: iload #6
    //   453: iinc #6, 1
    //   456: invokevirtual substring : (II)Ljava/lang/String;
    //   459: aastore
    //   460: iload_2
    //   461: ifeq -> 472
    //   464: iload_2
    //   465: ifeq -> 480
    //   468: goto -> 472
    //   471: athrow
    //   472: iload_2
    //   473: ifeq -> 107
    //   476: goto -> 480
    //   479: athrow
    //   480: aload_1
    //   481: iload #5
    //   483: putfield q : I
    //   486: return
    // Exception table:
    //   from	to	target	type
    //   18	32	35	java/lang/IllegalArgumentException
    //   29	55	58	java/lang/IllegalArgumentException
    //   36	74	77	java/lang/IllegalArgumentException
    //   59	100	103	java/lang/IllegalArgumentException
    //   240	270	273	java/lang/IllegalArgumentException
    //   255	289	292	java/lang/IllegalArgumentException
    //   274	308	311	java/lang/IllegalArgumentException
    //   293	323	326	java/lang/IllegalArgumentException
    //   327	338	341	java/lang/IllegalArgumentException
    //   342	356	359	java/lang/IllegalArgumentException
    //   371	382	385	java/lang/IllegalArgumentException
    //   405	420	423	java/lang/IllegalArgumentException
    //   424	435	438	java/lang/IllegalArgumentException
    //   460	468	471	java/lang/IllegalArgumentException
    //   464	476	479	java/lang/IllegalArgumentException
  }
  
  private int a(int paramInt, boolean paramBoolean1, boolean paramBoolean2, Context paramContext) {
    // Byte code:
    //   0: aload #4
    //   2: getfield c : [C
    //   5: astore #6
    //   7: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   10: aload #4
    //   12: getfield h : [Lorg/objectweb/asm/Label;
    //   15: astore #7
    //   17: istore #5
    //   19: iload_2
    //   20: iload #5
    //   22: ifne -> 59
    //   25: ifeq -> 52
    //   28: goto -> 32
    //   31: athrow
    //   32: aload_0
    //   33: getfield b : [B
    //   36: iload_1
    //   37: iinc #1, 1
    //   40: baload
    //   41: sipush #255
    //   44: iand
    //   45: istore #8
    //   47: iload #5
    //   49: ifeq -> 67
    //   52: sipush #255
    //   55: goto -> 59
    //   58: athrow
    //   59: istore #8
    //   61: aload #4
    //   63: iconst_m1
    //   64: putfield o : I
    //   67: aload #4
    //   69: iconst_0
    //   70: putfield r : I
    //   73: iload #8
    //   75: bipush #64
    //   77: iload #5
    //   79: ifne -> 128
    //   82: if_icmpge -> 110
    //   85: goto -> 89
    //   88: athrow
    //   89: iload #8
    //   91: istore #9
    //   93: aload #4
    //   95: iconst_3
    //   96: putfield p : I
    //   99: aload #4
    //   101: iconst_0
    //   102: putfield t : I
    //   105: iload #5
    //   107: ifeq -> 653
    //   110: iload #8
    //   112: iload #5
    //   114: ifne -> 180
    //   117: goto -> 121
    //   120: athrow
    //   121: sipush #128
    //   124: goto -> 128
    //   127: athrow
    //   128: if_icmpge -> 171
    //   131: iload #8
    //   133: bipush #64
    //   135: isub
    //   136: istore #9
    //   138: aload_0
    //   139: aload #4
    //   141: getfield u : [Ljava/lang/Object;
    //   144: iconst_0
    //   145: iload_1
    //   146: aload #6
    //   148: aload #7
    //   150: invokespecial a : ([Ljava/lang/Object;II[C[Lorg/objectweb/asm/Label;)I
    //   153: istore_1
    //   154: aload #4
    //   156: iconst_4
    //   157: putfield p : I
    //   160: aload #4
    //   162: iconst_1
    //   163: putfield t : I
    //   166: iload #5
    //   168: ifeq -> 653
    //   171: aload_0
    //   172: iload_1
    //   173: invokevirtual readUnsignedShort : (I)I
    //   176: goto -> 180
    //   179: athrow
    //   180: istore #9
    //   182: iinc #1, 2
    //   185: iload #8
    //   187: sipush #247
    //   190: iload #5
    //   192: ifne -> 244
    //   195: if_icmpne -> 235
    //   198: goto -> 202
    //   201: athrow
    //   202: aload_0
    //   203: aload #4
    //   205: getfield u : [Ljava/lang/Object;
    //   208: iconst_0
    //   209: iload_1
    //   210: aload #6
    //   212: aload #7
    //   214: invokespecial a : ([Ljava/lang/Object;II[C[Lorg/objectweb/asm/Label;)I
    //   217: istore_1
    //   218: aload #4
    //   220: iconst_4
    //   221: putfield p : I
    //   224: aload #4
    //   226: iconst_1
    //   227: putfield t : I
    //   230: iload #5
    //   232: ifeq -> 653
    //   235: iload #8
    //   237: sipush #248
    //   240: goto -> 244
    //   243: athrow
    //   244: iload #5
    //   246: ifne -> 333
    //   249: if_icmplt -> 324
    //   252: goto -> 256
    //   255: athrow
    //   256: iload #8
    //   258: sipush #251
    //   261: iload #5
    //   263: ifne -> 333
    //   266: goto -> 270
    //   269: athrow
    //   270: if_icmpge -> 324
    //   273: goto -> 277
    //   276: athrow
    //   277: aload #4
    //   279: iconst_2
    //   280: putfield p : I
    //   283: aload #4
    //   285: sipush #251
    //   288: iload #8
    //   290: isub
    //   291: putfield r : I
    //   294: aload #4
    //   296: dup
    //   297: getfield q : I
    //   300: aload #4
    //   302: getfield r : I
    //   305: isub
    //   306: putfield q : I
    //   309: aload #4
    //   311: iconst_0
    //   312: putfield t : I
    //   315: iload #5
    //   317: ifeq -> 653
    //   320: goto -> 324
    //   323: athrow
    //   324: iload #8
    //   326: sipush #251
    //   329: goto -> 333
    //   332: athrow
    //   333: iload #5
    //   335: ifne -> 384
    //   338: if_icmpne -> 366
    //   341: goto -> 345
    //   344: athrow
    //   345: aload #4
    //   347: iconst_3
    //   348: putfield p : I
    //   351: aload #4
    //   353: iconst_0
    //   354: putfield t : I
    //   357: iload #5
    //   359: ifeq -> 653
    //   362: goto -> 366
    //   365: athrow
    //   366: iload #8
    //   368: iload #5
    //   370: ifne -> 527
    //   373: goto -> 377
    //   376: athrow
    //   377: sipush #255
    //   380: goto -> 384
    //   383: athrow
    //   384: if_icmpge -> 512
    //   387: iload_3
    //   388: iload #5
    //   390: ifne -> 413
    //   393: goto -> 397
    //   396: athrow
    //   397: ifeq -> 416
    //   400: goto -> 404
    //   403: athrow
    //   404: aload #4
    //   406: getfield q : I
    //   409: goto -> 413
    //   412: athrow
    //   413: goto -> 417
    //   416: iconst_0
    //   417: istore #10
    //   419: iload #8
    //   421: sipush #251
    //   424: isub
    //   425: istore #11
    //   427: iload #11
    //   429: ifle -> 469
    //   432: aload_0
    //   433: aload #4
    //   435: getfield s : [Ljava/lang/Object;
    //   438: iload #10
    //   440: iinc #10, 1
    //   443: iload_1
    //   444: aload #6
    //   446: aload #7
    //   448: invokespecial a : ([Ljava/lang/Object;II[C[Lorg/objectweb/asm/Label;)I
    //   451: istore_1
    //   452: iinc #11, -1
    //   455: iload #5
    //   457: ifne -> 507
    //   460: iload #5
    //   462: ifeq -> 427
    //   465: goto -> 469
    //   468: athrow
    //   469: aload #4
    //   471: iconst_1
    //   472: putfield p : I
    //   475: aload #4
    //   477: iload #8
    //   479: sipush #251
    //   482: isub
    //   483: putfield r : I
    //   486: aload #4
    //   488: dup
    //   489: getfield q : I
    //   492: aload #4
    //   494: getfield r : I
    //   497: iadd
    //   498: putfield q : I
    //   501: aload #4
    //   503: iconst_0
    //   504: putfield t : I
    //   507: iload #5
    //   509: ifeq -> 653
    //   512: aload #4
    //   514: iconst_0
    //   515: putfield p : I
    //   518: aload_0
    //   519: iload_1
    //   520: invokevirtual readUnsignedShort : (I)I
    //   523: goto -> 527
    //   526: athrow
    //   527: istore #10
    //   529: iinc #1, 2
    //   532: aload #4
    //   534: iload #10
    //   536: putfield r : I
    //   539: aload #4
    //   541: iload #10
    //   543: putfield q : I
    //   546: iconst_0
    //   547: istore #11
    //   549: iload #10
    //   551: ifle -> 591
    //   554: aload_0
    //   555: aload #4
    //   557: getfield s : [Ljava/lang/Object;
    //   560: iload #11
    //   562: iinc #11, 1
    //   565: iload_1
    //   566: aload #6
    //   568: aload #7
    //   570: invokespecial a : ([Ljava/lang/Object;II[C[Lorg/objectweb/asm/Label;)I
    //   573: istore_1
    //   574: iinc #10, -1
    //   577: iload #5
    //   579: ifne -> 608
    //   582: iload #5
    //   584: ifeq -> 549
    //   587: goto -> 591
    //   590: athrow
    //   591: aload_0
    //   592: iload_1
    //   593: invokevirtual readUnsignedShort : (I)I
    //   596: istore #10
    //   598: iinc #1, 2
    //   601: aload #4
    //   603: iload #10
    //   605: putfield t : I
    //   608: iconst_0
    //   609: istore #11
    //   611: iload #10
    //   613: ifle -> 653
    //   616: aload_0
    //   617: aload #4
    //   619: getfield u : [Ljava/lang/Object;
    //   622: iload #11
    //   624: iinc #11, 1
    //   627: iload_1
    //   628: aload #6
    //   630: aload #7
    //   632: invokespecial a : ([Ljava/lang/Object;II[C[Lorg/objectweb/asm/Label;)I
    //   635: istore_1
    //   636: iinc #10, -1
    //   639: iload #5
    //   641: ifne -> 679
    //   644: iload #5
    //   646: ifeq -> 611
    //   649: goto -> 653
    //   652: athrow
    //   653: aload #4
    //   655: dup
    //   656: getfield o : I
    //   659: iload #9
    //   661: iconst_1
    //   662: iadd
    //   663: iadd
    //   664: putfield o : I
    //   667: aload_0
    //   668: aload #4
    //   670: getfield o : I
    //   673: aload #7
    //   675: invokevirtual readLabel : (I[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Label;
    //   678: pop
    //   679: iload_1
    //   680: ireturn
    // Exception table:
    //   from	to	target	type
    //   19	28	31	java/lang/IllegalArgumentException
    //   47	55	58	java/lang/IllegalArgumentException
    //   67	85	88	java/lang/IllegalArgumentException
    //   93	117	120	java/lang/IllegalArgumentException
    //   110	124	127	java/lang/IllegalArgumentException
    //   154	176	179	java/lang/IllegalArgumentException
    //   182	198	201	java/lang/IllegalArgumentException
    //   218	240	243	java/lang/IllegalArgumentException
    //   244	252	255	java/lang/IllegalArgumentException
    //   249	266	269	java/lang/IllegalArgumentException
    //   256	273	276	java/lang/IllegalArgumentException
    //   270	320	323	java/lang/IllegalArgumentException
    //   277	329	332	java/lang/IllegalArgumentException
    //   333	341	344	java/lang/IllegalArgumentException
    //   338	362	365	java/lang/IllegalArgumentException
    //   345	373	376	java/lang/IllegalArgumentException
    //   366	380	383	java/lang/IllegalArgumentException
    //   384	393	396	java/lang/IllegalArgumentException
    //   387	400	403	java/lang/IllegalArgumentException
    //   397	409	412	java/lang/IllegalArgumentException
    //   452	465	468	java/lang/IllegalArgumentException
    //   507	523	526	java/lang/IllegalArgumentException
    //   574	587	590	java/lang/IllegalArgumentException
    //   636	649	652	java/lang/IllegalArgumentException
  }
  
  private int a(Object[] paramArrayOfObject, int paramInt1, int paramInt2, char[] paramArrayOfchar, Label[] paramArrayOfLabel) {
    int i = MethodVisitor.b;
    int j = this.b[paramInt2++] & 0xFF;
    try {
      if (i == 0) {
        try {
          switch (j) {
            case 0:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.TOP;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 1:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.INTEGER;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 2:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.FLOAT;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 3:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.DOUBLE;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 4:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.LONG;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 5:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.NULL;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 6:
              try {
                paramArrayOfObject[paramInt1] = Opcodes.UNINITIALIZED_THIS;
                if (i != 0);
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
            case 7:
              try {
                paramArrayOfObject[paramInt1] = readClass(paramInt2, paramArrayOfchar);
                paramInt2 += 2;
                if (i != 0)
                  break; 
              } catch (IllegalArgumentException illegalArgumentException) {
                throw null;
              } 
              return paramInt2;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
        paramArrayOfObject[paramInt1] = readLabel(readUnsignedShort(paramInt2), paramArrayOfLabel);
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    paramInt2 += 2;
    return paramInt2;
  }
  
  protected Label readLabel(int paramInt, Label[] paramArrayOfLabel) {
    int i = MethodVisitor.b;
    try {
      if (i == 0)
        try {
          if (paramArrayOfLabel[paramInt] == null)
            paramArrayOfLabel[paramInt] = new Label(); 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    return paramArrayOfLabel[paramInt];
  }
  
  private int a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield header : I
    //   4: bipush #8
    //   6: iadd
    //   7: aload_0
    //   8: aload_0
    //   9: getfield header : I
    //   12: bipush #6
    //   14: iadd
    //   15: invokevirtual readUnsignedShort : (I)I
    //   18: iconst_2
    //   19: imul
    //   20: iadd
    //   21: istore_2
    //   22: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   25: aload_0
    //   26: iload_2
    //   27: invokevirtual readUnsignedShort : (I)I
    //   30: istore_3
    //   31: istore_1
    //   32: iload_3
    //   33: ifle -> 94
    //   36: aload_0
    //   37: iload_2
    //   38: bipush #8
    //   40: iadd
    //   41: invokevirtual readUnsignedShort : (I)I
    //   44: iload_1
    //   45: ifne -> 102
    //   48: istore #4
    //   50: iload #4
    //   52: ifle -> 84
    //   55: iload_2
    //   56: bipush #6
    //   58: aload_0
    //   59: iload_2
    //   60: bipush #12
    //   62: iadd
    //   63: invokevirtual readInt : (I)I
    //   66: iadd
    //   67: iadd
    //   68: istore_2
    //   69: iinc #4, -1
    //   72: iload_1
    //   73: ifne -> 90
    //   76: iload_1
    //   77: ifeq -> 50
    //   80: goto -> 84
    //   83: athrow
    //   84: iinc #2, 8
    //   87: iinc #3, -1
    //   90: iload_1
    //   91: ifeq -> 32
    //   94: iinc #2, 2
    //   97: aload_0
    //   98: iload_2
    //   99: invokevirtual readUnsignedShort : (I)I
    //   102: istore_3
    //   103: iload_3
    //   104: ifle -> 165
    //   107: aload_0
    //   108: iload_2
    //   109: bipush #8
    //   111: iadd
    //   112: invokevirtual readUnsignedShort : (I)I
    //   115: iload_1
    //   116: ifne -> 168
    //   119: istore #4
    //   121: iload #4
    //   123: ifle -> 155
    //   126: iload_2
    //   127: bipush #6
    //   129: aload_0
    //   130: iload_2
    //   131: bipush #12
    //   133: iadd
    //   134: invokevirtual readInt : (I)I
    //   137: iadd
    //   138: iadd
    //   139: istore_2
    //   140: iinc #4, -1
    //   143: iload_1
    //   144: ifne -> 161
    //   147: iload_1
    //   148: ifeq -> 121
    //   151: goto -> 155
    //   154: athrow
    //   155: iinc #2, 8
    //   158: iinc #3, -1
    //   161: iload_1
    //   162: ifeq -> 103
    //   165: iload_2
    //   166: iconst_2
    //   167: iadd
    //   168: ireturn
    // Exception table:
    //   from	to	target	type
    //   69	80	83	java/lang/IllegalArgumentException
    //   140	151	154	java/lang/IllegalArgumentException
  }
  
  private Attribute a(Attribute[] paramArrayOfAttribute, String paramString, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, Label[] paramArrayOfLabel) {
    // Byte code:
    //   0: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   3: istore #8
    //   5: iconst_0
    //   6: istore #9
    //   8: iload #9
    //   10: aload_1
    //   11: arraylength
    //   12: if_icmpge -> 77
    //   15: aload_1
    //   16: iload #9
    //   18: aaload
    //   19: iload #8
    //   21: ifne -> 95
    //   24: iload #8
    //   26: ifne -> 68
    //   29: goto -> 33
    //   32: athrow
    //   33: getfield type : Ljava/lang/String;
    //   36: aload_2
    //   37: invokevirtual equals : (Ljava/lang/Object;)Z
    //   40: ifeq -> 69
    //   43: goto -> 47
    //   46: athrow
    //   47: aload_1
    //   48: iload #9
    //   50: aaload
    //   51: aload_0
    //   52: iload_3
    //   53: iload #4
    //   55: aload #5
    //   57: iload #6
    //   59: aload #7
    //   61: invokevirtual read : (Lorg/objectweb/asm/ClassReader;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   64: goto -> 68
    //   67: athrow
    //   68: areturn
    //   69: iinc #9, 1
    //   72: iload #8
    //   74: ifeq -> 8
    //   77: new org/objectweb/asm/Attribute
    //   80: dup
    //   81: aload_2
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: aload_0
    //   86: iload_3
    //   87: iload #4
    //   89: aconst_null
    //   90: iconst_m1
    //   91: aconst_null
    //   92: invokevirtual read : (Lorg/objectweb/asm/ClassReader;II[CI[Lorg/objectweb/asm/Label;)Lorg/objectweb/asm/Attribute;
    //   95: areturn
    // Exception table:
    //   from	to	target	type
    //   15	29	32	java/lang/IllegalArgumentException
    //   24	43	46	java/lang/IllegalArgumentException
    //   33	64	67	java/lang/IllegalArgumentException
  }
  
  public int getItemCount() {
    return this.a.length;
  }
  
  public int getItem(int paramInt) {
    return this.a[paramInt];
  }
  
  public int getMaxStringLength() {
    return this.d;
  }
  
  public int readByte(int paramInt) {
    return this.b[paramInt] & 0xFF;
  }
  
  public int readUnsignedShort(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (arrayOfByte[paramInt] & 0xFF) << 8 | arrayOfByte[paramInt + 1] & 0xFF;
  }
  
  public short readShort(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (short)((arrayOfByte[paramInt] & 0xFF) << 8 | arrayOfByte[paramInt + 1] & 0xFF);
  }
  
  public int readInt(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (arrayOfByte[paramInt] & 0xFF) << 24 | (arrayOfByte[paramInt + 1] & 0xFF) << 16 | (arrayOfByte[paramInt + 2] & 0xFF) << 8 | arrayOfByte[paramInt + 3] & 0xFF;
  }
  
  public long readLong(int paramInt) {
    long l1 = readInt(paramInt);
    long l2 = readInt(paramInt + 4) & 0xFFFFFFFFL;
    return l1 << 32L | l2;
  }
  
  public String readUTF8(int paramInt, char[] paramArrayOfchar) {
    int i = MethodVisitor.b;
    int j = readUnsignedShort(paramInt);
    try {
      if (i == 0)
        if (paramInt != 0) {
        
        } else {
          return null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    try {
      if (paramInt != 0) {
        String str = this.c[j];
        try {
          if (i == 0) {
            try {
              if (str != null)
                return str; 
            } catch (IllegalArgumentException illegalArgumentException) {
              throw null;
            } 
            paramInt = this.a[j];
            this.c[j] = a(paramInt + 2, readUnsignedShort(paramInt), paramArrayOfchar);
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        } 
        return a(paramInt + 2, readUnsignedShort(paramInt), paramArrayOfchar);
      } 
      return null;
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
  }
  
  private String a(int paramInt1, int paramInt2, char[] paramArrayOfchar) {
    // Byte code:
    //   0: iload_1
    //   1: iload_2
    //   2: iadd
    //   3: istore #5
    //   5: aload_0
    //   6: getfield b : [B
    //   9: astore #6
    //   11: getstatic org/objectweb/asm/MethodVisitor.b : I
    //   14: iconst_0
    //   15: istore #7
    //   17: iconst_0
    //   18: istore #9
    //   20: iconst_0
    //   21: istore #10
    //   23: istore #4
    //   25: iload_1
    //   26: iload #5
    //   28: if_icmpge -> 244
    //   31: aload #6
    //   33: iload_1
    //   34: iinc #1, 1
    //   37: baload
    //   38: istore #8
    //   40: iload #9
    //   42: iload #4
    //   44: ifne -> 83
    //   47: tableswitch default -> 239, 0 -> 73, 1 -> 195, 2 -> 222
    //   72: athrow
    //   73: iload #8
    //   75: sipush #255
    //   78: iand
    //   79: istore #8
    //   81: iload #8
    //   83: sipush #128
    //   86: iload #4
    //   88: ifne -> 126
    //   91: if_icmpge -> 117
    //   94: goto -> 98
    //   97: athrow
    //   98: aload_3
    //   99: iload #7
    //   101: iinc #7, 1
    //   104: iload #8
    //   106: i2c
    //   107: castore
    //   108: iload #4
    //   110: ifeq -> 239
    //   113: goto -> 117
    //   116: athrow
    //   117: iload #8
    //   119: sipush #224
    //   122: goto -> 126
    //   125: athrow
    //   126: iload #4
    //   128: ifne -> 183
    //   131: if_icmpge -> 175
    //   134: goto -> 138
    //   137: athrow
    //   138: iload #8
    //   140: sipush #191
    //   143: iload #4
    //   145: ifne -> 183
    //   148: goto -> 152
    //   151: athrow
    //   152: if_icmple -> 175
    //   155: goto -> 159
    //   158: athrow
    //   159: iload #8
    //   161: bipush #31
    //   163: iand
    //   164: i2c
    //   165: istore #10
    //   167: iconst_1
    //   168: istore #9
    //   170: iload #4
    //   172: ifeq -> 239
    //   175: iload #8
    //   177: bipush #15
    //   179: goto -> 183
    //   182: athrow
    //   183: iand
    //   184: i2c
    //   185: istore #10
    //   187: iconst_2
    //   188: istore #9
    //   190: iload #4
    //   192: ifeq -> 239
    //   195: aload_3
    //   196: iload #7
    //   198: iinc #7, 1
    //   201: iload #10
    //   203: bipush #6
    //   205: ishl
    //   206: iload #8
    //   208: bipush #63
    //   210: iand
    //   211: ior
    //   212: i2c
    //   213: castore
    //   214: iconst_0
    //   215: istore #9
    //   217: iload #4
    //   219: ifeq -> 239
    //   222: iload #10
    //   224: bipush #6
    //   226: ishl
    //   227: iload #8
    //   229: bipush #63
    //   231: iand
    //   232: ior
    //   233: i2c
    //   234: istore #10
    //   236: iconst_1
    //   237: istore #9
    //   239: iload #4
    //   241: ifeq -> 25
    //   244: new java/lang/String
    //   247: dup
    //   248: aload_3
    //   249: iconst_0
    //   250: iload #7
    //   252: invokespecial <init> : ([CII)V
    //   255: areturn
    // Exception table:
    //   from	to	target	type
    //   40	72	72	java/lang/IllegalArgumentException
    //   83	94	97	java/lang/IllegalArgumentException
    //   91	113	116	java/lang/IllegalArgumentException
    //   98	122	125	java/lang/IllegalArgumentException
    //   126	134	137	java/lang/IllegalArgumentException
    //   131	148	151	java/lang/IllegalArgumentException
    //   138	155	158	java/lang/IllegalArgumentException
    //   170	179	182	java/lang/IllegalArgumentException
  }
  
  public String readClass(int paramInt, char[] paramArrayOfchar) {
    return readUTF8(this.a[readUnsignedShort(paramInt)], paramArrayOfchar);
  }
  
  public Object readConst(int paramInt, char[] paramArrayOfchar) {
    int i = MethodVisitor.b;
    int j = this.a[paramInt];
    try {
      if (i == 0)
        try {
          switch (this.b[j - 1]) {
            case 3:
              new Integer();
              super(new Integer());
              return new Integer();
            case 4:
              new Float();
              super(new Float());
              return new Float();
            case 5:
              new Long();
              super(new Long());
              return new Long();
            case 6:
              new Double();
              super(new Double());
              return new Double();
            case 7:
              return Type.getObjectType(readUTF8(j, paramArrayOfchar));
            case 8:
              return readUTF8(j, paramArrayOfchar);
            case 16:
              return Type.getMethodType(readUTF8(j, paramArrayOfchar));
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    int k = readByte(j);
    int[] arrayOfInt = this.a;
    int m = arrayOfInt[readUnsignedShort(j + 1)];
    try {
      if (i == 0)
        try {
        
        } catch (IllegalArgumentException illegalArgumentException) {
          throw null;
        }  
    } catch (IllegalArgumentException illegalArgumentException) {
      throw null;
    } 
    boolean bool = (this.b[m - 1] == 11) ? true : false;
    String str1 = readClass(m, paramArrayOfchar);
    m = arrayOfInt[readUnsignedShort(m + 2)];
    String str2 = readUTF8(m, paramArrayOfchar);
    String str3 = readUTF8(m + 2, paramArrayOfchar);
    return new Handle(k, str1, str2, str3, bool);
  }
  
  static {
    // Byte code:
    //   0: bipush #28
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc 'Ë½Òqè!ð\\tKL,Fy"²Å¬7Æã·dûÎÀÃqU,ØQb\\fg­\*¨Æ"G¬Ã p]ÊÞRÍ´¾2XÈ\\rizMjÑ) ÙP.'Y\\rÝÆßQ¡ãeÀp\].=6U$jÒ+MÕúÁ:·Èºd}èÌ¾wRâg%ÊX°ÿ$\\rgò;}èãOý`¼â ç0ëqôr¹¡÷nu@*<0ÝNSm.ÑÅCñÜÝ\\r#"Si?f¸>(ÿûûþ4\\\tOªæ\\r«\\n¦ÿn:ÂÆ ¸q¡@1ÂßËô¡L©°\\bN´¯¯*¤$âíxªN° >,'RÕÕ¤g¦e\\n©º¶Ù@RºLM\\r#\\n»ÍÔò};ècFu8W»¹+(ªG#ª[ìPY\\f<l¬ëa£GoD,\\tc0bÔóÿBDOÛÝLè×h*= ×qÇ¾G~á½úíÔ02«-9(.B¼JÚVìÎ\\t¼® >dò]³EæÌÝ²*4çoÿ¡i¾}X{àU!'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #10
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: jsr -> 137
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 23
    //   65: ldc 'ÊèÀr¬\\tÿHºm¼gV²#s«QÌ]v'
    //   67: dup
    //   68: astore_2
    //   69: invokevirtual length : ()I
    //   72: istore #4
    //   74: bipush #10
    //   76: istore_1
    //   77: iconst_m1
    //   78: istore_0
    //   79: iinc #0, 1
    //   82: aload_2
    //   83: iload_0
    //   84: dup
    //   85: iload_1
    //   86: iadd
    //   87: invokevirtual substring : (II)Ljava/lang/String;
    //   90: jsr -> 137
    //   93: aload #5
    //   95: swap
    //   96: iload_3
    //   97: iinc #3, 1
    //   100: swap
    //   101: aastore
    //   102: iload_0
    //   103: iload_1
    //   104: iadd
    //   105: dup
    //   106: istore_0
    //   107: iload #4
    //   109: if_icmpge -> 121
    //   112: aload_2
    //   113: iload_0
    //   114: invokevirtual charAt : (I)C
    //   117: istore_1
    //   118: goto -> 79
    //   121: aload #5
    //   123: putstatic org/objectweb/asm/ClassReader.e : [Ljava/lang/String;
    //   126: bipush #28
    //   128: anewarray java/lang/String
    //   131: putstatic org/objectweb/asm/ClassReader.f : [Ljava/lang/String;
    //   134: goto -> 279
    //   137: astore #6
    //   139: invokevirtual toCharArray : ()[C
    //   142: dup
    //   143: arraylength
    //   144: swap
    //   145: iconst_0
    //   146: istore #7
    //   148: swap
    //   149: dup_x1
    //   150: iconst_1
    //   151: if_icmpgt -> 257
    //   154: dup
    //   155: iload #7
    //   157: dup2
    //   158: caload
    //   159: iload #7
    //   161: bipush #7
    //   163: irem
    //   164: tableswitch default -> 238, 0 -> 204, 1 -> 209, 2 -> 215, 3 -> 220, 4 -> 226, 5 -> 232
    //   204: bipush #120
    //   206: goto -> 241
    //   209: sipush #219
    //   212: goto -> 241
    //   215: bipush #42
    //   217: goto -> 241
    //   220: sipush #175
    //   223: goto -> 241
    //   226: sipush #234
    //   229: goto -> 241
    //   232: sipush #237
    //   235: goto -> 241
    //   238: sipush #243
    //   241: ixor
    //   242: i2c
    //   243: castore
    //   244: iinc #7, 1
    //   247: swap
    //   248: dup_x1
    //   249: ifne -> 257
    //   252: dup2
    //   253: swap
    //   254: goto -> 157
    //   257: swap
    //   258: dup_x1
    //   259: iload #7
    //   261: if_icmpgt -> 154
    //   264: new java/lang/String
    //   267: dup_x1
    //   268: swap
    //   269: invokespecial <init> : ([C)V
    //   272: invokevirtual intern : ()Ljava/lang/String;
    //   275: swap
    //   276: pop
    //   277: ret #6
    //   279: return
  }
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0x750D) & 0xFFFF;
    if (f[i] == null) {
      char[] arrayOfChar = e[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 30;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      f[i] = (new String(arrayOfChar)).intern();
    } 
    return f[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\ClassReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */