package org.objectweb.asm;

class Edge {
  int a;
  
  Label b;
  
  Edge c;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\org\objectweb\asm\Edge.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */