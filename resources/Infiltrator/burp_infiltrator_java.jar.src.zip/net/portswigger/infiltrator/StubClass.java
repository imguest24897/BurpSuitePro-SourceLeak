/*     */ package net.portswigger.infiltrator;public class StubClass { public static List stub_instance_org_dom4j_Document_selectNodes(Document paramDocument, String paramString) {
/*   2 */     (new c()).b(paramString, 114, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  22 */     return paramDocument.selectNodes(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File stub_ctor_java_io_File(String paramString1, String paramString2) {
/*     */     (new c()).b(paramString1, 9, 1);
/* 176 */     (new c()).b(paramString2, 9, 2);
/*     */     return new File(paramString1, paramString2);
/*     */   } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString, int paramInt) throws SQLException {
/*     */     (new c()).b(paramString, 80, 1);
/*     */     return paramConnection.prepareStatement(paramString, paramInt);
/*     */   } public static boolean stub_instance_java_sql_Statement_execute(Statement paramStatement, String paramString, String[] paramArrayOfString) throws SQLException {
/*     */     (new c()).b(paramString, 18, 1);
/*     */     return paramStatement.execute(paramString, paramArrayOfString);
/*     */   }
/*     */   public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, String paramString, DefaultHandler paramDefaultHandler) throws SAXException, IOException {
/*     */     (new c()).b(paramString, 99, 1);
/* 187 */     paramSAXParser.parse(paramString, paramDefaultHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stub_instance_java_io_RandomAccessFile_write(RandomAccessFile paramRandomAccessFile, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*     */     (new c()).a(paramArrayOfbyte, 48, 1);
/*     */     paramRandomAccessFile.write(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String paramString, String[] paramArrayOfString) throws IOException {
/*     */     (new c()).b(paramString, 5, 1);
/*     */     (new c()).a(paramArrayOfString, 5, 2);
/*     */     return paramRuntime.exec(paramString, paramArrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URLConnection stub_instance_java_net_URL_openConnection(URL paramURL) throws IOException {
/*     */     (new c()).a(paramURL, 24, 0);
/*     */     return paramURL.openConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Path stub_static_java_nio_file_Paths_get(String paramString, String[] paramArrayOfString) {
/*     */     (new c()).b(paramString, 67, 1);
/*     */     (new c()).a(paramArrayOfString, 67, 2);
/* 229 */     return Paths.get(paramString, paramArrayOfString);
/* 230 */   } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString) throws SQLException { (new c()).b(paramString, 79, 1); return paramConnection.prepareStatement(paramString); } public static void stub_static_java_lang_System_load(String paramString) { (new c()).b(paramString, 93, 1); System.load(paramString); } public static FileWriter stub_ctor_java_io_FileWriter(String paramString) throws IOException { (new c()).b(paramString, 37, 1); return new FileWriter(paramString); } public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, String paramString, HandlerBase paramHandlerBase) throws SAXException, IOException { (new c()).b(paramString, 98, 1); paramSAXParser.parse(paramString, paramHandlerBase); } public static Path stub_static_java_nio_file_Files_createTempFile(Path paramPath, String paramString1, String paramString2, FileAttribute[] paramArrayOfFileAttribute) throws IOException { (new c()).b(paramString1, 73, 2); (new c()).b(paramString2, 73, 3); return Files.createTempFile(paramPath, paramString1, paramString2, (FileAttribute[])paramArrayOfFileAttribute); } public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, InputStream paramInputStream, DefaultHandler paramDefaultHandler, String paramString) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 96, 1); (new c()).b(paramString, 96, 3); paramSAXParser.parse(paramInputStream, paramDefaultHandler, paramString); } public static Connection stub_static_java_sql_DriverManager_getConnection(String paramString, Properties paramProperties) throws SQLException { (new c()).b(paramString, 86, 1); return DriverManager.getConnection(paramString, paramProperties); } public static ResultSet stub_instance_java_sql_Statement_executeQuery(Statement paramStatement, String paramString) throws SQLException { (new c()).b(paramString, 11, 1); return paramStatement.executeQuery(paramString); } public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, InputStream paramInputStream, DefaultHandler paramDefaultHandler) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 21, 1); paramSAXParser.parse(paramInputStream, paramDefaultHandler); } public static Path stub_instance_java_nio_file_Path_resolveSibling(Path paramPath, String paramString) { (new c()).b(paramString, 70, 1); return paramPath.resolveSibling(paramString); } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString, String[] paramArrayOfString) throws SQLException { (new c()).b(paramString, 84, 1); return paramConnection.prepareStatement(paramString, paramArrayOfString); } public static List stub_static_org_dom4j_DocumentHelper_selectNodes(String paramString, Node paramNode) { (new c()).b(paramString, 106, 1); return DocumentHelper.selectNodes(paramString, paramNode); } public static int stub_instance_java_io_FileInputStream_read(FileInputStream paramFileInputStream, byte[] paramArrayOfbyte) throws IOException { (new c()).a(paramArrayOfbyte, 45, 1); return paramFileInputStream.read(paramArrayOfbyte); } public static void stub_instance_java_sql_Connection_setSchema(Connection paramConnection, String paramString) throws SQLException { (new c()).b(paramString, 89, 1); paramConnection.setSchema(paramString); }
/*     */   public static File stub_ctor_java_io_File(String paramString) { (new c()).b(paramString, 8, 1); return new File(paramString); }
/*     */   public static void stub_static_java_lang_System_loadLibrary(String paramString) { (new c()).b(paramString, 94, 1); System.loadLibrary(paramString); }
/* 233 */   public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, InputStream paramInputStream, HandlerBase paramHandlerBase, String paramString) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 97, 1); (new c()).b(paramString, 97, 3); paramSAXParser.parse(paramInputStream, paramHandlerBase, paramString); } public static void stub_instance_java_io_RandomAccessFile_writeUTF(RandomAccessFile paramRandomAccessFile, String paramString) throws IOException { (new c()).b(paramString, 51, 1); paramRandomAccessFile.writeUTF(paramString); } public static Path stub_static_java_nio_file_Files_createTempDirectory(Path paramPath, String paramString, FileAttribute[] paramArrayOfFileAttribute) throws IOException { (new c()).b(paramString, 71, 2); return Files.createTempDirectory(paramPath, paramString, (FileAttribute[])paramArrayOfFileAttribute); } public static Path stub_instance_java_nio_file_Path_resolve(Path paramPath, String paramString) { (new c()).b(paramString, 69, 1); return paramPath.resolve(paramString); } public static List stub_instance_org_dom4j_Node_selectNodes(Node paramNode, String paramString) { (new c()).b(paramString, 107, 1); return paramNode.selectNodes(paramString); } public static void stub_instance_java_io_RandomAccessFile_writeChars(RandomAccessFile paramRandomAccessFile, String paramString) throws IOException { (new c()).b(paramString, 50, 1); paramRandomAccessFile.writeChars(paramString); } public static Path stub_static_java_nio_file_Files_createTempFile(String paramString1, String paramString2, FileAttribute[] paramArrayOfFileAttribute) throws IOException { (new c()).b(paramString1, 74, 1); (new c()).b(paramString2, 74, 2); return Files.createTempFile(paramString1, paramString2, (FileAttribute[])paramArrayOfFileAttribute); } public static PrintWriter stub_ctor_java_io_PrintWriter(String paramString) throws FileNotFoundException { (new c()).b(paramString, 41, 1); return new PrintWriter(paramString); } public static Path stub_static_java_nio_file_Files_write(Path paramPath, byte[] paramArrayOfbyte, OpenOption[] paramArrayOfOpenOption) throws IOException { (new c()).a(paramArrayOfbyte, 75, 2); return Files.write(paramPath, paramArrayOfbyte, paramArrayOfOpenOption); } public static void stub_instance_java_io_RandomAccessFile_writeBytes(RandomAccessFile paramRandomAccessFile, String paramString) throws IOException { (new c()).b(paramString, 49, 1); paramRandomAccessFile.writeBytes(paramString); } public static InitialLdapContext stub_ctor_javax_naming_ldap_InitialLdapContext(Hashtable paramHashtable, Control[] paramArrayOfControl) throws NamingException { (new c()).a(paramHashtable, 29, 1); return new InitialLdapContext(paramHashtable, paramArrayOfControl); } public static ProcessBuilder stub_ctor_java_lang_ProcessBuilder(String[] paramArrayOfString) { (new c()).a(paramArrayOfString, 33, 1); return new ProcessBuilder(paramArrayOfString); } public static Document stub_instance_javax_xml_parsers_DocumentBuilder_parse(DocumentBuilder paramDocumentBuilder, String paramString) throws SAXException, IOException { (new c()).b(paramString, 95, 1); return paramDocumentBuilder.parse(paramString); } public static List stub_instance_org_dom4j_tree_AbstractNode_selectNodes(AbstractNode paramAbstractNode, String paramString) { (new c()).b(paramString, 110, 1); return paramAbstractNode.selectNodes(paramString); } public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String[] paramArrayOfString1, String[] paramArrayOfString2) throws IOException { (new c()).a(paramArrayOfString1, 3, 1); (new c()).a(paramArrayOfString2, 3, 2); return paramRuntime.exec(paramArrayOfString1, paramArrayOfString2); } public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String paramString) throws IOException { (new c()).b(paramString, 1, 1); return paramRuntime.exec(paramString); } public static ProcessBuilder stub_instance_java_lang_ProcessBuilder_command(ProcessBuilder paramProcessBuilder, String[] paramArrayOfString) { (new c()).a(paramArrayOfString, 92, 1); return paramProcessBuilder.command(paramArrayOfString); } public static Node stub_instance_org_dom4j_tree_AbstractNode_selectSingleNode(AbstractNode paramAbstractNode, String paramString) { (new c()).b(paramString, 113, 1); return paramAbstractNode.selectSingleNode(paramString); } public static ProcessBuilder stub_ctor_java_lang_ProcessBuilder(List paramList) { (new c()).a(paramList, 90, 1); return new ProcessBuilder(paramList); } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException { (new c()).b(paramString, 83, 1); return paramConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3); } public static RandomAccessFile stub_ctor_java_io_RandomAccessFile(String paramString1, String paramString2) throws FileNotFoundException { (new c()).b(paramString1, 39, 1); return new RandomAccessFile(paramString1, paramString2); } public static Document stub_instance_javax_xml_parsers_DocumentBuilder_parse(DocumentBuilder paramDocumentBuilder, InputStream paramInputStream) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 23, 1); return paramDocumentBuilder.parse(paramInputStream); } public static PrintWriter stub_ctor_java_io_PrintWriter(String paramString1, String paramString2) throws FileNotFoundException, UnsupportedEncodingException { (new c()).b(paramString1, 42, 1); return new PrintWriter(paramString1, paramString2); } public static FileWriter stub_ctor_java_io_FileWriter(String paramString, boolean paramBoolean) throws IOException { (new c()).b(paramString, 38, 1); return new FileWriter(paramString, paramBoolean); } public static List stub_instance_org_dom4j_Node_selectNodes(Node paramNode, String paramString1, String paramString2, boolean paramBoolean) { (new c()).b(paramString1, 109, 1); (new c()).b(paramString2, 109, 2); return paramNode.selectNodes(paramString1, paramString2, paramBoolean); } public static Document stub_instance_org_dom4j_io_SAXReader_read(SAXReader paramSAXReader, URL paramURL) throws DocumentException { (new c()).a(paramURL, 101, 1); return paramSAXReader.read(paramURL); } public static void stub_instance_java_io_RandomAccessFile_write(RandomAccessFile paramRandomAccessFile, byte[] paramArrayOfbyte) throws IOException { (new c()).a(paramArrayOfbyte, 47, 1); paramRandomAccessFile.write(paramArrayOfbyte); } public static List stub_instance_org_dom4j_Node_selectNodes(Node paramNode, String paramString1, String paramString2) { (new c()).b(paramString1, 108, 1); (new c()).b(paramString2, 108, 2); return paramNode.selectNodes(paramString1, paramString2); } public static List stub_instance_org_dom4j_tree_AbstractNode_selectNodes(AbstractNode paramAbstractNode, String paramString1, String paramString2, boolean paramBoolean) { (new c()).b(paramString1, 112, 1); return paramAbstractNode.selectNodes(paramString1, paramString2, paramBoolean); } public static FileOutputStream stub_ctor_java_io_FileOutputStream(String paramString, boolean paramBoolean) throws FileNotFoundException { (new c()).b(paramString, 36, 1); return new FileOutputStream(paramString, paramBoolean); } public static FilePermission stub_ctor_java_io_FilePermission(String paramString1, String paramString2) { (new c()).b(paramString1, 40, 1); return new FilePermission(paramString1, paramString2); } public static ProcessBuilder stub_instance_java_lang_ProcessBuilder_command(ProcessBuilder paramProcessBuilder, List paramList) { (new c()).a(paramList, 91, 1); return paramProcessBuilder.command(paramList); } public static int stub_instance_java_sql_Statement_executeUpdate(Statement paramStatement, String paramString, int[] paramArrayOfint) throws SQLException { (new c()).b(paramString, 14, 1); return paramStatement.executeUpdate(paramString, paramArrayOfint); } public static List stub_static_org_dom4j_DocumentHelper_selectNodes(String paramString, List paramList) { (new c()).b(paramString, 105, 1); return DocumentHelper.selectNodes(paramString, paramList); } public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String[] paramArrayOfString1, String[] paramArrayOfString2, File paramFile) throws IOException { (new c()).a(paramArrayOfString1, 4, 1); (new c()).a(paramArrayOfString2, 4, 2); return paramRuntime.exec(paramArrayOfString1, paramArrayOfString2, paramFile); } public static NamingEnumeration stub_instance_javax_naming_directory_DirContext_search(DirContext paramDirContext, String paramString1, String paramString2, SearchControls paramSearchControls) throws NamingException { (new c()).b(paramString1, 30, 1); (new c()).b(paramString2, 30, 2); return paramDirContext.search(paramString1, paramString2, paramSearchControls); }
/* 234 */   public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String[] paramArrayOfString) throws IOException { (new c()).a(paramArrayOfString, 2, 1); return paramRuntime.exec(paramArrayOfString); } public static void stub_instance_java_sql_Connection_setCatalog(Connection paramConnection, String paramString) throws SQLException { (new c()).b(paramString, 88, 1); paramConnection.setCatalog(paramString); } public static CallableStatement stub_instance_java_sql_Connection_prepareCall(Connection paramConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { (new c()).b(paramString, 77, 1); return paramConnection.prepareCall(paramString, paramInt1, paramInt2); } public static Document stub_instance_javax_xml_parsers_DocumentBuilder_parse(DocumentBuilder paramDocumentBuilder, InputStream paramInputStream, String paramString) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 22, 1); return paramDocumentBuilder.parse(paramInputStream, paramString); } public static File stub_ctor_java_io_File(File paramFile, String paramString) { (new c()).b(paramString, 10, 2); return new File(paramFile, paramString); } public static int stub_instance_java_sql_Statement_executeUpdate(Statement paramStatement, String paramString, String[] paramArrayOfString) throws SQLException { (new c()).b(paramString, 15, 1); return paramStatement.executeUpdate(paramString, paramArrayOfString); } public static void stub_instance_javax_xml_parsers_SAXParser_parse(SAXParser paramSAXParser, InputStream paramInputStream, HandlerBase paramHandlerBase) throws SAXException, IOException { paramInputStream = (new c()).a(paramInputStream, 20, 1); paramSAXParser.parse(paramInputStream, paramHandlerBase); } public static String stub_instance_javax_xml_xpath_XPath_evaluate(XPath paramXPath, String paramString, InputSource paramInputSource) throws XPathExpressionException { (new c()).b(paramString, 25, 1); return paramXPath.evaluate(paramString, paramInputSource); } public static List stub_instance_org_dom4j_tree_AbstractNode_selectNodes(AbstractNode paramAbstractNode, String paramString1, String paramString2) { (new c()).b(paramString1, 111, 1); return paramAbstractNode.selectNodes(paramString1, paramString2); } public static Document stub_instance_org_dom4j_io_SAXReader_read(SAXReader paramSAXReader, InputStream paramInputStream, String paramString) throws DocumentException { paramInputStream = (new c()).a(paramInputStream, 104, 1); (new c()).b(paramString, 104, 2); return paramSAXReader.read(paramInputStream, paramString); } public static void stub_instance_java_io_FileOutputStream_write(FileOutputStream paramFileOutputStream, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException { (new c()).a(paramArrayOfbyte, 44, 1); paramFileOutputStream.write(paramArrayOfbyte, paramInt1, paramInt2); } public static Process stub_instance_java_lang_Runtime_exec(Runtime paramRuntime, String paramString, String[] paramArrayOfString, File paramFile) throws IOException { (new c()).b(paramString, 6, 1); (new c()).a(paramArrayOfString, 6, 2); return paramRuntime.exec(paramString, paramArrayOfString, paramFile); } public static FileInputStream stub_ctor_java_io_FileInputStream(String paramString) throws FileNotFoundException { (new c()).b(paramString, 34, 1); return new FileInputStream(paramString); } public static int stub_instance_java_io_FileInputStream_read(FileInputStream paramFileInputStream, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException { (new c()).a(paramArrayOfbyte, 46, 1); return paramFileInputStream.read(paramArrayOfbyte, paramInt1, paramInt2); } public static Object stub_instance_javax_xml_xpath_XPath_evaluate(XPath paramXPath, String paramString, InputSource paramInputSource, QName paramQName) throws XPathExpressionException { (new c()).b(paramString, 26, 1); return paramXPath.evaluate(paramString, paramInputSource, paramQName); } public static Document stub_instance_org_dom4j_io_SAXReader_read(SAXReader paramSAXReader, InputStream paramInputStream) throws DocumentException { paramInputStream = (new c()).a(paramInputStream, 103, 1); return paramSAXReader.read(paramInputStream); } public static Connection stub_static_java_sql_DriverManager_getConnection(String paramString1, String paramString2, String paramString3) throws SQLException { (new c()).b(paramString1, 87, 1); (new c()).b(paramString2, 87, 2); (new c()).b(paramString3, 87, 3); return DriverManager.getConnection(paramString1, paramString2, paramString3); } public static void stub_instance_java_io_FileOutputStream_write(FileOutputStream paramFileOutputStream, byte[] paramArrayOfbyte) throws IOException { (new c()).a(paramArrayOfbyte, 43, 1); paramFileOutputStream.write(paramArrayOfbyte); } public static FileOutputStream stub_ctor_java_io_FileOutputStream(String paramString) throws FileNotFoundException { (new c()).b(paramString, 35, 1); return new FileOutputStream(paramString); } public static FileReader stub_ctor_java_io_FileReader(String paramString) throws FileNotFoundException { (new c()).b(paramString, 7, 1); return new FileReader(paramString); } public static CallableStatement stub_instance_java_sql_Connection_prepareCall(Connection paramConnection, String paramString) throws SQLException { (new c()).b(paramString, 76, 1); return paramConnection.prepareCall(paramString); } public static Connection stub_static_java_sql_DriverManager_getConnection(String paramString) throws SQLException { (new c()).b(paramString, 85, 1); return DriverManager.getConnection(paramString); } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { (new c()).b(paramString, 82, 1); return paramConnection.prepareStatement(paramString, paramInt1, paramInt2); } public static Document stub_instance_org_dom4j_io_SAXReader_read(SAXReader paramSAXReader, String paramString) throws DocumentException { (new c()).b(paramString, 102, 1); return paramSAXReader.read(paramString); } public static boolean stub_instance_java_sql_Statement_execute(Statement paramStatement, String paramString, int paramInt) throws SQLException { (new c()).b(paramString, 16, 1); return paramStatement.execute(paramString, paramInt); } public static Path stub_static_java_nio_file_Files_createTempDirectory(String paramString, FileAttribute[] paramArrayOfFileAttribute) throws IOException { (new c()).b(paramString, 72, 1); return Files.createTempDirectory(paramString, (FileAttribute[])paramArrayOfFileAttribute); } public static Document stub_instance_org_dom4j_io_SAXReader_read(SAXReader paramSAXReader, File paramFile) throws DocumentException { (new c()).a(paramFile, 100, 1); return paramSAXReader.read(paramFile); } public static PreparedStatement stub_instance_java_sql_Connection_prepareStatement(Connection paramConnection, String paramString, int[] paramArrayOfint) throws SQLException { (new c()).b(paramString, 81, 1); return paramConnection.prepareStatement(paramString, paramArrayOfint); } public static int stub_instance_java_sql_Statement_executeUpdate(Statement paramStatement, String paramString, int paramInt) throws SQLException { (new c()).b(paramString, 13, 1); return paramStatement.executeUpdate(paramString, paramInt); } public static NamingEnumeration stub_instance_javax_naming_directory_DirContext_search(DirContext paramDirContext, Name paramName, String paramString, Object[] paramArrayOfObject, SearchControls paramSearchControls) throws NamingException { (new c()).a(paramName, 32, 1); (new c()).b(paramString, 32, 2); return paramDirContext.search(paramName, paramString, paramArrayOfObject, paramSearchControls); } public static boolean stub_instance_java_sql_Statement_execute(Statement paramStatement, String paramString, int[] paramArrayOfint) throws SQLException { (new c()).b(paramString, 17, 1); return paramStatement.execute(paramString, paramArrayOfint); } public static Path stub_instance_java_nio_file_Path_relativize(Path paramPath1, Path paramPath2) { (new c()).a(paramPath2, 68, 1); return paramPath1.relativize(paramPath2); } public static NamingEnumeration stub_instance_javax_naming_directory_DirContext_search(DirContext paramDirContext, String paramString1, String paramString2, Object[] paramArrayOfObject, SearchControls paramSearchControls) throws NamingException { (new c()).b(paramString1, 31, 1); (new c()).b(paramString2, 31, 2); return paramDirContext.search(paramString1, paramString2, paramArrayOfObject, paramSearchControls); } public static CallableStatement stub_instance_java_sql_Connection_prepareCall(Connection paramConnection, String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException { (new c()).b(paramString, 78, 1); return paramConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3); } public static void stub_instance_java_sql_Statement_addBatch(Statement paramStatement, String paramString) throws SQLException { (new c()).b(paramString, 12, 1); paramStatement.addBatch(paramString); } public static String stub_instance_javax_xml_xpath_XPath_evaluate(XPath paramXPath, String paramString, Object paramObject) throws XPathExpressionException { (new c()).b(paramString, 27, 1); return paramXPath.evaluate(paramString, paramObject); } public static boolean stub_instance_java_sql_Statement_execute(Statement paramStatement, String paramString) throws SQLException { (new c()).b(paramString, 19, 1);
/* 235 */     return paramStatement.execute(paramString); } public static Object stub_instance_javax_xml_xpath_XPath_evaluate(XPath paramXPath, String paramString, Object paramObject, QName paramQName) throws XPathExpressionException { (new c()).b(paramString, 28, 1);
/*     */     return paramXPath.evaluate(paramString, paramObject, paramQName); }
/*     */    }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\StubClass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */