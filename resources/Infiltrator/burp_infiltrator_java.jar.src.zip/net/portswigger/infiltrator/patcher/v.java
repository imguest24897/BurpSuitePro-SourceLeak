/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class v
/*    */ {
/*    */   private final k a;
/*    */   private static final String[] b;
/*    */   private static final String[] c;
/*    */   
/*    */   public v(k paramk) {
/* 17 */     this.a = paramk;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void b(String paramString) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: istore_2
/*    */     //   4: aload_1
/*    */     //   5: sipush #-32493
/*    */     //   8: sipush #151
/*    */     //   11: invokestatic a : (II)Ljava/lang/String;
/*    */     //   14: ldc '/'
/*    */     //   16: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*    */     //   19: iload_2
/*    */     //   20: ifne -> 49
/*    */     //   23: sipush #-32490
/*    */     //   26: sipush #31933
/*    */     //   29: invokestatic a : (II)Ljava/lang/String;
/*    */     //   32: invokevirtual indexOf : (Ljava/lang/String;)I
/*    */     //   35: iconst_m1
/*    */     //   36: if_icmpeq -> 45
/*    */     //   39: goto -> 43
/*    */     //   42: athrow
/*    */     //   43: return
/*    */     //   44: athrow
/*    */     //   45: aload_1
/*    */     //   46: invokestatic b : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   49: astore_3
/*    */     //   50: aload_0
/*    */     //   51: aload_1
/*    */     //   52: invokespecial a : (Ljava/lang/String;)Z
/*    */     //   55: ifeq -> 205
/*    */     //   58: new java/io/File
/*    */     //   61: dup
/*    */     //   62: aload_1
/*    */     //   63: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   66: astore #4
/*    */     //   68: new java/io/FileInputStream
/*    */     //   71: dup
/*    */     //   72: aload #4
/*    */     //   74: invokespecial <init> : (Ljava/io/File;)V
/*    */     //   77: astore #5
/*    */     //   79: new net/portswigger/infiltrator/patcher/w
/*    */     //   82: dup
/*    */     //   83: aload #5
/*    */     //   85: aload #4
/*    */     //   87: invokevirtual getName : ()Ljava/lang/String;
/*    */     //   90: invokespecial <init> : (Ljava/io/InputStream;Ljava/lang/String;)V
/*    */     //   93: new net/portswigger/infiltrator/patcher/d
/*    */     //   96: dup
/*    */     //   97: invokespecial <init> : ()V
/*    */     //   100: invokevirtual a : ()Ljava/util/List;
/*    */     //   103: invokevirtual a : (Ljava/util/List;)Lnet/portswigger/infiltrator/patcher/l;
/*    */     //   106: astore #6
/*    */     //   108: aload #6
/*    */     //   110: aload_3
/*    */     //   111: invokevirtual a : (Ljava/lang/String;)V
/*    */     //   114: new net/portswigger/infiltrator/patcher/a
/*    */     //   117: dup
/*    */     //   118: aload_0
/*    */     //   119: getfield a : Lnet/portswigger/infiltrator/patcher/k;
/*    */     //   122: invokespecial <init> : (Lnet/portswigger/infiltrator/patcher/k;)V
/*    */     //   125: aload #6
/*    */     //   127: aload_1
/*    */     //   128: invokevirtual a : (Lnet/portswigger/infiltrator/patcher/l;Ljava/lang/String;)V
/*    */     //   131: aload #5
/*    */     //   133: invokevirtual close : ()V
/*    */     //   136: goto -> 201
/*    */     //   139: astore #6
/*    */     //   141: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*    */     //   144: new java/lang/StringBuffer
/*    */     //   147: dup
/*    */     //   148: invokespecial <init> : ()V
/*    */     //   151: sipush #-32492
/*    */     //   154: sipush #-9212
/*    */     //   157: invokestatic a : (II)Ljava/lang/String;
/*    */     //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   163: aload_1
/*    */     //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   167: sipush #-32491
/*    */     //   170: sipush #15959
/*    */     //   173: invokestatic a : (II)Ljava/lang/String;
/*    */     //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   179: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   182: invokevirtual println : (Ljava/lang/String;)V
/*    */     //   185: aload #5
/*    */     //   187: invokevirtual close : ()V
/*    */     //   190: return
/*    */     //   191: astore #7
/*    */     //   193: aload #5
/*    */     //   195: invokevirtual close : ()V
/*    */     //   198: aload #7
/*    */     //   200: athrow
/*    */     //   201: iload_2
/*    */     //   202: ifeq -> 245
/*    */     //   205: new java/util/jar/JarOutputStream
/*    */     //   208: dup
/*    */     //   209: new java/io/FileOutputStream
/*    */     //   212: dup
/*    */     //   213: aload_3
/*    */     //   214: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   217: invokespecial <init> : (Ljava/io/OutputStream;)V
/*    */     //   220: astore #4
/*    */     //   222: new net/portswigger/infiltrator/patcher/n
/*    */     //   225: dup
/*    */     //   226: aload_0
/*    */     //   227: getfield a : Lnet/portswigger/infiltrator/patcher/k;
/*    */     //   230: aload_1
/*    */     //   231: invokespecial <init> : (Lnet/portswigger/infiltrator/patcher/k;Ljava/lang/String;)V
/*    */     //   234: aload_1
/*    */     //   235: aload #4
/*    */     //   237: invokevirtual a : (Ljava/lang/String;Ljava/util/jar/JarOutputStream;)V
/*    */     //   240: aload #4
/*    */     //   242: invokevirtual close : ()V
/*    */     //   245: aload_1
/*    */     //   246: aload_3
/*    */     //   247: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
/*    */     //   250: goto -> 278
/*    */     //   253: astore #4
/*    */     //   255: new java/io/File
/*    */     //   258: dup
/*    */     //   259: aload_3
/*    */     //   260: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   263: invokevirtual delete : ()Z
/*    */     //   266: pop
/*    */     //   267: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*    */     //   270: aload #4
/*    */     //   272: invokevirtual getMessage : ()Ljava/lang/String;
/*    */     //   275: invokevirtual println : (Ljava/lang/String;)V
/*    */     //   278: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #22	-> 4
/*    */     //   #24	-> 43
/*    */     //   #27	-> 45
/*    */     //   #29	-> 50
/*    */     //   #31	-> 58
/*    */     //   #33	-> 68
/*    */     //   #37	-> 79
/*    */     //   #38	-> 108
/*    */     //   #39	-> 114
/*    */     //   #48	-> 131
/*    */     //   #49	-> 136
/*    */     //   #41	-> 139
/*    */     //   #43	-> 141
/*    */     //   #48	-> 185
/*    */     //   #44	-> 190
/*    */     //   #48	-> 191
/*    */     //   #50	-> 201
/*    */     //   #53	-> 205
/*    */     //   #55	-> 222
/*    */     //   #57	-> 240
/*    */     //   #62	-> 245
/*    */     //   #68	-> 250
/*    */     //   #64	-> 253
/*    */     //   #66	-> 255
/*    */     //   #67	-> 267
/*    */     //   #69	-> 278
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   4	39	42	java/lang/Throwable
/*    */     //   23	44	44	java/lang/Throwable
/*    */     //   79	131	139	java/lang/Throwable
/*    */     //   79	131	191	finally
/*    */     //   139	185	191	finally
/*    */     //   191	193	191	finally
/*    */     //   245	250	253	java/lang/Exception
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean a(String paramString) {
/* 73 */     return paramString.substring(paramString.lastIndexOf(".") + 1).equals(a(-32489, 27487));
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: iconst_5
/*    */     //   1: anewarray java/lang/String
/*    */     //   4: astore #5
/*    */     //   6: iconst_0
/*    */     //   7: istore_3
/*    */     //   8: ldc '22D¤ÂÎ´ÀÂ¤\\ru¥+YÖ×ã.q³°\\fvËÃM$c>¤§xÚqVRè*'
/*    */     //   10: dup
/*    */     //   11: astore_2
/*    */     //   12: invokevirtual length : ()I
/*    */     //   15: istore #4
/*    */     //   17: iconst_5
/*    */     //   18: istore_1
/*    */     //   19: iconst_m1
/*    */     //   20: istore_0
/*    */     //   21: iinc #0, 1
/*    */     //   24: aload_2
/*    */     //   25: iload_0
/*    */     //   26: dup
/*    */     //   27: iload_1
/*    */     //   28: iadd
/*    */     //   29: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   32: jsr -> 134
/*    */     //   35: aload #5
/*    */     //   37: swap
/*    */     //   38: iload_3
/*    */     //   39: iinc #3, 1
/*    */     //   42: swap
/*    */     //   43: aastore
/*    */     //   44: iload_0
/*    */     //   45: iload_1
/*    */     //   46: iadd
/*    */     //   47: dup
/*    */     //   48: istore_0
/*    */     //   49: iload #4
/*    */     //   51: if_icmpge -> 63
/*    */     //   54: aload_2
/*    */     //   55: iload_0
/*    */     //   56: invokevirtual charAt : (I)C
/*    */     //   59: istore_1
/*    */     //   60: goto -> 21
/*    */     //   63: ldc 'Â«âBTÙ¹¬d K-;µf?áÁè'
/*    */     //   65: dup
/*    */     //   66: astore_2
/*    */     //   67: invokevirtual length : ()I
/*    */     //   70: istore #4
/*    */     //   72: bipush #24
/*    */     //   74: istore_1
/*    */     //   75: iconst_m1
/*    */     //   76: istore_0
/*    */     //   77: iinc #0, 1
/*    */     //   80: aload_2
/*    */     //   81: iload_0
/*    */     //   82: dup
/*    */     //   83: iload_1
/*    */     //   84: iadd
/*    */     //   85: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   88: jsr -> 134
/*    */     //   91: aload #5
/*    */     //   93: swap
/*    */     //   94: iload_3
/*    */     //   95: iinc #3, 1
/*    */     //   98: swap
/*    */     //   99: aastore
/*    */     //   100: iload_0
/*    */     //   101: iload_1
/*    */     //   102: iadd
/*    */     //   103: dup
/*    */     //   104: istore_0
/*    */     //   105: iload #4
/*    */     //   107: if_icmpge -> 119
/*    */     //   110: aload_2
/*    */     //   111: iload_0
/*    */     //   112: invokevirtual charAt : (I)C
/*    */     //   115: istore_1
/*    */     //   116: goto -> 77
/*    */     //   119: aload #5
/*    */     //   121: putstatic net/portswigger/infiltrator/patcher/v.b : [Ljava/lang/String;
/*    */     //   124: iconst_5
/*    */     //   125: anewarray java/lang/String
/*    */     //   128: putstatic net/portswigger/infiltrator/patcher/v.c : [Ljava/lang/String;
/*    */     //   131: goto -> 273
/*    */     //   134: astore #6
/*    */     //   136: invokevirtual toCharArray : ()[C
/*    */     //   139: dup
/*    */     //   140: arraylength
/*    */     //   141: swap
/*    */     //   142: iconst_0
/*    */     //   143: istore #7
/*    */     //   145: swap
/*    */     //   146: dup_x1
/*    */     //   147: iconst_1
/*    */     //   148: if_icmpgt -> 251
/*    */     //   151: dup
/*    */     //   152: iload #7
/*    */     //   154: dup2
/*    */     //   155: caload
/*    */     //   156: iload #7
/*    */     //   158: bipush #7
/*    */     //   160: irem
/*    */     //   161: tableswitch default -> 232, 0 -> 200, 1 -> 205, 2 -> 210, 3 -> 215, 4 -> 220, 5 -> 226
/*    */     //   200: bipush #25
/*    */     //   202: goto -> 235
/*    */     //   205: bipush #10
/*    */     //   207: goto -> 235
/*    */     //   210: bipush #79
/*    */     //   212: goto -> 235
/*    */     //   215: bipush #49
/*    */     //   217: goto -> 235
/*    */     //   220: sipush #198
/*    */     //   223: goto -> 235
/*    */     //   226: sipush #154
/*    */     //   229: goto -> 235
/*    */     //   232: sipush #128
/*    */     //   235: ixor
/*    */     //   236: i2c
/*    */     //   237: castore
/*    */     //   238: iinc #7, 1
/*    */     //   241: swap
/*    */     //   242: dup_x1
/*    */     //   243: ifne -> 251
/*    */     //   246: dup2
/*    */     //   247: swap
/*    */     //   248: goto -> 154
/*    */     //   251: swap
/*    */     //   252: dup_x1
/*    */     //   253: iload #7
/*    */     //   255: if_icmpgt -> 151
/*    */     //   258: new java/lang/String
/*    */     //   261: dup_x1
/*    */     //   262: swap
/*    */     //   263: invokespecial <init> : ([C)V
/*    */     //   266: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   269: swap
/*    */     //   270: pop
/*    */     //   271: ret #6
/*    */     //   273: return
/*    */   }
/*    */   
/*    */   private static String a(int paramInt1, int paramInt2) {
/*    */     int i = (paramInt1 ^ 0xFFFF8117) & 0xFFFF;
/*    */     if (c[i] == null) {
/*    */       char[] arrayOfChar = b[i].toCharArray();
/*    */       switch (arrayOfChar[0] & 0xFF) {
/*    */         case 0:
/*    */         
/*    */         case 1:
/*    */         
/*    */         case 2:
/*    */         
/*    */         case 3:
/*    */         
/*    */         case 4:
/*    */         
/*    */         case 5:
/*    */         
/*    */         case 6:
/*    */         
/*    */         case 7:
/*    */         
/*    */         case 8:
/*    */         
/*    */         case 9:
/*    */         
/*    */         case 10:
/*    */         
/*    */         case 11:
/*    */         
/*    */         case 12:
/*    */         
/*    */         case 13:
/*    */         
/*    */         case 14:
/*    */         
/*    */         case 15:
/*    */         
/*    */         case 16:
/*    */         
/*    */         case 17:
/*    */         
/*    */         case 18:
/*    */         
/*    */         case 19:
/*    */         
/*    */         case 20:
/*    */         
/*    */         case 21:
/*    */         
/*    */         case 22:
/*    */         
/*    */         case 23:
/*    */         
/*    */         case 24:
/*    */         
/*    */         case 25:
/*    */         
/*    */         case 26:
/*    */         
/*    */         case 27:
/*    */         
/*    */         case 28:
/*    */         
/*    */         case 29:
/*    */         
/*    */         case 30:
/*    */         
/*    */         case 31:
/*    */         
/*    */         case 32:
/*    */         
/*    */         case 33:
/*    */         
/*    */         case 34:
/*    */         
/*    */         case 35:
/*    */         
/*    */         case 36:
/*    */         
/*    */         case 37:
/*    */         
/*    */         case 38:
/*    */         
/*    */         case 39:
/*    */         
/*    */         case 40:
/*    */         
/*    */         case 41:
/*    */         
/*    */         case 42:
/*    */         
/*    */         case 43:
/*    */         
/*    */         case 44:
/*    */         
/*    */         case 45:
/*    */         
/*    */         case 46:
/*    */         
/*    */         case 47:
/*    */         
/*    */         case 48:
/*    */         
/*    */         case 49:
/*    */         
/*    */         case 50:
/*    */         
/*    */         case 51:
/*    */         
/*    */         case 52:
/*    */         
/*    */         case 53:
/*    */         
/*    */         case 54:
/*    */         
/*    */         case 55:
/*    */         
/*    */         case 56:
/*    */         
/*    */         case 57:
/*    */         
/*    */         case 58:
/*    */         
/*    */         case 59:
/*    */         
/*    */         case 60:
/*    */         
/*    */         case 61:
/*    */         
/*    */         case 62:
/*    */         
/*    */         case 63:
/*    */         
/*    */         case 64:
/*    */         
/*    */         case 65:
/*    */         
/*    */         case 66:
/*    */         
/*    */         case 67:
/*    */         
/*    */         case 68:
/*    */         
/*    */         case 69:
/*    */         
/*    */         case 70:
/*    */         
/*    */         case 71:
/*    */         
/*    */         case 72:
/*    */         
/*    */         case 73:
/*    */         
/*    */         case 74:
/*    */         
/*    */         case 75:
/*    */         
/*    */         case 76:
/*    */         
/*    */         case 77:
/*    */         
/*    */         case 78:
/*    */         
/*    */         case 79:
/*    */         
/*    */         case 80:
/*    */         
/*    */         case 81:
/*    */         
/*    */         case 82:
/*    */         
/*    */         case 83:
/*    */         
/*    */         case 84:
/*    */         
/*    */         case 85:
/*    */         
/*    */         case 86:
/*    */         
/*    */         case 87:
/*    */         
/*    */         case 88:
/*    */         
/*    */         case 89:
/*    */         
/*    */         case 90:
/*    */         
/*    */         case 91:
/*    */         
/*    */         case 92:
/*    */         
/*    */         case 93:
/*    */         
/*    */         case 94:
/*    */         
/*    */         case 95:
/*    */         
/*    */         case 96:
/*    */         
/*    */         case 97:
/*    */         
/*    */         case 98:
/*    */         
/*    */         case 99:
/*    */         
/*    */         case 100:
/*    */         
/*    */         case 101:
/*    */         
/*    */         case 102:
/*    */         
/*    */         case 103:
/*    */         
/*    */         case 104:
/*    */         
/*    */         case 105:
/*    */         
/*    */         case 106:
/*    */         
/*    */         case 107:
/*    */         
/*    */         case 108:
/*    */         
/*    */         case 109:
/*    */         
/*    */         case 110:
/*    */         
/*    */         case 111:
/*    */         
/*    */         case 112:
/*    */         
/*    */         case 113:
/*    */         
/*    */         case 114:
/*    */         
/*    */         case 115:
/*    */         
/*    */         case 116:
/*    */         
/*    */         case 117:
/*    */         
/*    */         case 118:
/*    */         
/*    */         case 119:
/*    */         
/*    */         case 120:
/*    */         
/*    */         case 121:
/*    */         
/*    */         case 122:
/*    */         
/*    */         case 123:
/*    */         
/*    */         case 124:
/*    */         
/*    */         case 125:
/*    */         
/*    */         case 126:
/*    */         
/*    */         case 127:
/*    */         
/*    */         case 128:
/*    */         
/*    */         case 129:
/*    */         
/*    */         case 130:
/*    */         
/*    */         case 131:
/*    */         
/*    */         case 132:
/*    */         
/*    */         case 133:
/*    */         
/*    */         case 134:
/*    */         
/*    */         case 135:
/*    */         
/*    */         case 136:
/*    */         
/*    */         case 137:
/*    */         
/*    */         case 138:
/*    */         
/*    */         case 139:
/*    */         
/*    */         case 140:
/*    */         
/*    */         case 141:
/*    */         
/*    */         case 142:
/*    */         
/*    */         case 143:
/*    */         
/*    */         case 144:
/*    */         
/*    */         case 145:
/*    */         
/*    */         case 146:
/*    */         
/*    */         case 147:
/*    */         
/*    */         case 148:
/*    */         
/*    */         case 149:
/*    */         
/*    */         case 150:
/*    */         
/*    */         case 151:
/*    */         
/*    */         case 152:
/*    */         
/*    */         case 153:
/*    */         
/*    */         case 154:
/*    */         
/*    */         case 155:
/*    */         
/*    */         case 156:
/*    */         
/*    */         case 157:
/*    */         
/*    */         case 158:
/*    */         
/*    */         case 159:
/*    */         
/*    */         case 160:
/*    */         
/*    */         case 161:
/*    */         
/*    */         case 162:
/*    */         
/*    */         case 163:
/*    */         
/*    */         case 164:
/*    */         
/*    */         case 165:
/*    */         
/*    */         case 166:
/*    */         
/*    */         case 167:
/*    */         
/*    */         case 168:
/*    */         
/*    */         case 169:
/*    */         
/*    */         case 170:
/*    */         
/*    */         case 171:
/*    */         
/*    */         case 172:
/*    */         
/*    */         case 173:
/*    */         
/*    */         case 174:
/*    */         
/*    */         case 175:
/*    */         
/*    */         case 176:
/*    */         
/*    */         case 177:
/*    */         
/*    */         case 178:
/*    */         
/*    */         case 179:
/*    */         
/*    */         case 180:
/*    */         
/*    */         case 181:
/*    */         
/*    */         case 182:
/*    */         
/*    */         case 183:
/*    */         
/*    */         case 184:
/*    */         
/*    */         case 185:
/*    */         
/*    */         case 186:
/*    */         
/*    */         case 187:
/*    */         
/*    */         case 188:
/*    */         
/*    */         case 189:
/*    */         
/*    */         case 190:
/*    */         
/*    */         case 191:
/*    */         
/*    */         case 192:
/*    */         
/*    */         case 193:
/*    */         
/*    */         case 194:
/*    */         
/*    */         case 195:
/*    */         
/*    */         case 196:
/*    */         
/*    */         case 197:
/*    */         
/*    */         case 198:
/*    */         
/*    */         case 199:
/*    */         
/*    */         case 200:
/*    */         
/*    */         case 201:
/*    */         
/*    */         case 202:
/*    */         
/*    */         case 203:
/*    */         
/*    */         case 204:
/*    */         
/*    */         case 205:
/*    */         
/*    */         case 206:
/*    */         
/*    */         case 207:
/*    */         
/*    */         case 208:
/*    */         
/*    */         case 209:
/*    */         
/*    */         case 210:
/*    */         
/*    */         case 211:
/*    */         
/*    */         case 212:
/*    */         
/*    */         case 213:
/*    */         
/*    */         case 214:
/*    */         
/*    */         case 215:
/*    */         
/*    */         case 216:
/*    */         
/*    */         case 217:
/*    */         
/*    */         case 218:
/*    */         
/*    */         case 219:
/*    */         
/*    */         case 220:
/*    */         
/*    */         case 221:
/*    */         
/*    */         case 222:
/*    */         
/*    */         case 223:
/*    */         
/*    */         case 224:
/*    */         
/*    */         case 225:
/*    */         
/*    */         case 226:
/*    */         
/*    */         case 227:
/*    */         
/*    */         case 228:
/*    */         
/*    */         case 229:
/*    */         
/*    */         case 230:
/*    */         
/*    */         case 231:
/*    */         
/*    */         case 232:
/*    */         
/*    */         case 233:
/*    */         
/*    */         case 234:
/*    */         
/*    */         case 235:
/*    */         
/*    */         case 236:
/*    */         
/*    */         case 237:
/*    */         
/*    */         case 238:
/*    */         
/*    */         case 239:
/*    */         
/*    */         case 240:
/*    */         
/*    */         case 241:
/*    */         
/*    */         case 242:
/*    */         
/*    */         case 243:
/*    */         
/*    */         case 244:
/*    */         
/*    */         case 245:
/*    */         
/*    */         case 246:
/*    */         
/*    */         case 247:
/*    */         
/*    */         case 248:
/*    */         
/*    */         case 249:
/*    */         
/*    */         case 250:
/*    */         
/*    */         case 251:
/*    */         
/*    */         case 252:
/*    */         
/*    */         case 253:
/*    */         
/*    */         case 254:
/*    */         
/*    */         default:
/*    */           break;
/*    */       } 
/*    */       byte b1 = 96;
/*    */       int j = (paramInt2 & 0xFF) - b1;
/*    */       if (j < 0)
/*    */         j += 256; 
/*    */       int m = ((paramInt2 & 0xFFFF) >>> 8) - b1;
/*    */       if (m < 0)
/*    */         m += 256; 
/*    */       for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*    */         int n = b2 % 2;
/*    */         if (n == 0) {
/*    */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
/*    */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
/*    */         } else {
/*    */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ m);
/*    */           m = ((m >>> 3 | m << 5) ^ arrayOfChar[b2]) & 0xFF;
/*    */         } 
/*    */       } 
/*    */       c[i] = (new String(arrayOfChar)).intern();
/*    */     } 
/*    */     return c[i];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\v.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */