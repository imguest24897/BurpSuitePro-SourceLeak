/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.a;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class d
/*    */ {
/*    */   private static final String[] a;
/*    */   private static final String[] b;
/*    */   
/*    */   public List a() {
/*    */     try {
/* 18 */       Class.forName(a.a(w.d + "." + w.a));
/* 19 */       return a(w.d + "." + w.a);
/*    */     }
/* 21 */     catch (ClassNotFoundException classNotFoundException) {
/*    */ 
/*    */ 
/*    */       
/* 25 */       j.a.b(classNotFoundException.getMessage());
/*    */       
/* 27 */       throw new RuntimeException(a(-746, 13501));
/*    */     } 
/*    */   }
/*    */   
/*    */   private List a(String paramString) {
/*    */     // Byte code:
/*    */     //   0: new java/util/ArrayList
/*    */     //   3: dup
/*    */     //   4: invokespecial <init> : ()V
/*    */     //   7: astore_3
/*    */     //   8: aload_1
/*    */     //   9: invokestatic c : (Ljava/lang/String;)Ljava/util/List;
/*    */     //   12: astore #4
/*    */     //   14: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   17: iconst_0
/*    */     //   18: istore #5
/*    */     //   20: istore_2
/*    */     //   21: iload #5
/*    */     //   23: aload #4
/*    */     //   25: invokeinterface size : ()I
/*    */     //   30: if_icmpge -> 349
/*    */     //   33: aload #4
/*    */     //   35: iload #5
/*    */     //   37: invokeinterface get : (I)Ljava/lang/Object;
/*    */     //   42: checkcast net/portswigger/infiltrator/patcher/u
/*    */     //   45: astore #6
/*    */     //   47: iload_2
/*    */     //   48: ifne -> 345
/*    */     //   51: aload #6
/*    */     //   53: getfield b : Ljava/lang/String;
/*    */     //   56: sipush #-752
/*    */     //   59: sipush #28042
/*    */     //   62: invokestatic a : (II)Ljava/lang/String;
/*    */     //   65: invokevirtual startsWith : (Ljava/lang/String;)Z
/*    */     //   68: ifeq -> 342
/*    */     //   71: goto -> 75
/*    */     //   74: athrow
/*    */     //   75: aload #6
/*    */     //   77: getfield a : I
/*    */     //   80: bipush #8
/*    */     //   82: iand
/*    */     //   83: iload_2
/*    */     //   84: ifne -> 129
/*    */     //   87: goto -> 91
/*    */     //   90: athrow
/*    */     //   91: bipush #8
/*    */     //   93: if_icmpeq -> 108
/*    */     //   96: goto -> 100
/*    */     //   99: athrow
/*    */     //   100: iload_2
/*    */     //   101: ifeq -> 342
/*    */     //   104: goto -> 108
/*    */     //   107: athrow
/*    */     //   108: aload #6
/*    */     //   110: getfield b : Ljava/lang/String;
/*    */     //   113: sipush #-749
/*    */     //   116: sipush #-24959
/*    */     //   119: invokestatic a : (II)Ljava/lang/String;
/*    */     //   122: invokevirtual startsWith : (Ljava/lang/String;)Z
/*    */     //   125: goto -> 129
/*    */     //   128: athrow
/*    */     //   129: iload_2
/*    */     //   130: ifne -> 192
/*    */     //   133: ifeq -> 171
/*    */     //   136: goto -> 140
/*    */     //   139: athrow
/*    */     //   140: aload_3
/*    */     //   141: aload_0
/*    */     //   142: aload #6
/*    */     //   144: sipush #-749
/*    */     //   147: sipush #-24959
/*    */     //   150: invokestatic a : (II)Ljava/lang/String;
/*    */     //   153: iconst_0
/*    */     //   154: invokespecial a : (Lnet/portswigger/infiltrator/patcher/u;Ljava/lang/String;I)Lnet/portswigger/infiltrator/patcher/b;
/*    */     //   157: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   162: pop
/*    */     //   163: iload_2
/*    */     //   164: ifeq -> 342
/*    */     //   167: goto -> 171
/*    */     //   170: athrow
/*    */     //   171: aload #6
/*    */     //   173: getfield b : Ljava/lang/String;
/*    */     //   176: sipush #-750
/*    */     //   179: sipush #3637
/*    */     //   182: invokestatic a : (II)Ljava/lang/String;
/*    */     //   185: invokevirtual startsWith : (Ljava/lang/String;)Z
/*    */     //   188: goto -> 192
/*    */     //   191: athrow
/*    */     //   192: iload_2
/*    */     //   193: ifne -> 255
/*    */     //   196: ifeq -> 234
/*    */     //   199: goto -> 203
/*    */     //   202: athrow
/*    */     //   203: aload_3
/*    */     //   204: aload_0
/*    */     //   205: aload #6
/*    */     //   207: sipush #-750
/*    */     //   210: sipush #3637
/*    */     //   213: invokestatic a : (II)Ljava/lang/String;
/*    */     //   216: iconst_1
/*    */     //   217: invokespecial a : (Lnet/portswigger/infiltrator/patcher/u;Ljava/lang/String;I)Lnet/portswigger/infiltrator/patcher/b;
/*    */     //   220: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   225: pop
/*    */     //   226: iload_2
/*    */     //   227: ifeq -> 342
/*    */     //   230: goto -> 234
/*    */     //   233: athrow
/*    */     //   234: aload #6
/*    */     //   236: getfield b : Ljava/lang/String;
/*    */     //   239: sipush #-748
/*    */     //   242: sipush #1474
/*    */     //   245: invokestatic a : (II)Ljava/lang/String;
/*    */     //   248: invokevirtual startsWith : (Ljava/lang/String;)Z
/*    */     //   251: goto -> 255
/*    */     //   254: athrow
/*    */     //   255: iload_2
/*    */     //   256: ifne -> 292
/*    */     //   259: ifeq -> 297
/*    */     //   262: goto -> 266
/*    */     //   265: athrow
/*    */     //   266: aload_3
/*    */     //   267: aload_0
/*    */     //   268: aload #6
/*    */     //   270: sipush #-748
/*    */     //   273: sipush #1474
/*    */     //   276: invokestatic a : (II)Ljava/lang/String;
/*    */     //   279: iconst_2
/*    */     //   280: invokespecial a : (Lnet/portswigger/infiltrator/patcher/u;Ljava/lang/String;I)Lnet/portswigger/infiltrator/patcher/b;
/*    */     //   283: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   288: goto -> 292
/*    */     //   291: athrow
/*    */     //   292: pop
/*    */     //   293: iload_2
/*    */     //   294: ifeq -> 342
/*    */     //   297: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*    */     //   300: new java/lang/StringBuffer
/*    */     //   303: dup
/*    */     //   304: invokespecial <init> : ()V
/*    */     //   307: sipush #-747
/*    */     //   310: sipush #-32048
/*    */     //   313: invokestatic a : (II)Ljava/lang/String;
/*    */     //   316: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   319: aload #6
/*    */     //   321: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   324: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   327: ldc ']'
/*    */     //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   332: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   335: invokevirtual b : (Ljava/lang/String;)V
/*    */     //   338: goto -> 342
/*    */     //   341: athrow
/*    */     //   342: iinc #5, 1
/*    */     //   345: iload_2
/*    */     //   346: ifeq -> 21
/*    */     //   349: aload_3
/*    */     //   350: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #33	-> 0
/*    */     //   #34	-> 8
/*    */     //   #35	-> 14
/*    */     //   #37	-> 33
/*    */     //   #38	-> 47
/*    */     //   #40	-> 100
/*    */     //   #43	-> 108
/*    */     //   #45	-> 140
/*    */     //   #47	-> 171
/*    */     //   #49	-> 203
/*    */     //   #51	-> 234
/*    */     //   #53	-> 266
/*    */     //   #59	-> 297
/*    */     //   #35	-> 342
/*    */     //   #64	-> 349
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   47	71	74	java/lang/RuntimeException
/*    */     //   51	87	90	java/lang/RuntimeException
/*    */     //   75	96	99	java/lang/RuntimeException
/*    */     //   91	104	107	java/lang/RuntimeException
/*    */     //   100	125	128	java/lang/RuntimeException
/*    */     //   129	136	139	java/lang/RuntimeException
/*    */     //   133	167	170	java/lang/RuntimeException
/*    */     //   140	188	191	java/lang/RuntimeException
/*    */     //   192	199	202	java/lang/RuntimeException
/*    */     //   196	230	233	java/lang/RuntimeException
/*    */     //   203	251	254	java/lang/RuntimeException
/*    */     //   255	262	265	java/lang/RuntimeException
/*    */     //   259	288	291	java/lang/RuntimeException
/*    */     //   292	338	341	java/lang/RuntimeException
/*    */   }
/*    */   
/*    */   private b a(u paramu, String paramString, int paramInt) {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: getfield b : Ljava/lang/String;
/*    */     //   4: ldc '_'
/*    */     //   6: ldc '.'
/*    */     //   8: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*    */     //   11: aload_2
/*    */     //   12: invokevirtual length : ()I
/*    */     //   15: invokevirtual substring : (I)Ljava/lang/String;
/*    */     //   18: astore #5
/*    */     //   20: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   23: istore #4
/*    */     //   25: aload #5
/*    */     //   27: iconst_0
/*    */     //   28: aload #5
/*    */     //   30: ldc '.'
/*    */     //   32: invokevirtual lastIndexOf : (Ljava/lang/String;)I
/*    */     //   35: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   38: astore #6
/*    */     //   40: aload #5
/*    */     //   42: aload #5
/*    */     //   44: ldc '.'
/*    */     //   46: invokevirtual lastIndexOf : (Ljava/lang/String;)I
/*    */     //   49: iconst_1
/*    */     //   50: iadd
/*    */     //   51: invokevirtual substring : (I)Ljava/lang/String;
/*    */     //   54: astore #7
/*    */     //   56: iload_3
/*    */     //   57: iconst_1
/*    */     //   58: if_icmpne -> 110
/*    */     //   61: new java/lang/StringBuffer
/*    */     //   64: dup
/*    */     //   65: invokespecial <init> : ()V
/*    */     //   68: aload_1
/*    */     //   69: getfield c : Ljava/lang/String;
/*    */     //   72: iconst_0
/*    */     //   73: invokevirtual charAt : (I)C
/*    */     //   76: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*    */     //   79: aload_1
/*    */     //   80: getfield c : Ljava/lang/String;
/*    */     //   83: aload_1
/*    */     //   84: getfield c : Ljava/lang/String;
/*    */     //   87: ldc ';'
/*    */     //   89: invokevirtual indexOf : (Ljava/lang/String;)I
/*    */     //   92: iconst_1
/*    */     //   93: iadd
/*    */     //   94: invokevirtual substring : (I)Ljava/lang/String;
/*    */     //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   100: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   103: astore #8
/*    */     //   105: iload #4
/*    */     //   107: ifeq -> 116
/*    */     //   110: aload_1
/*    */     //   111: getfield c : Ljava/lang/String;
/*    */     //   114: astore #8
/*    */     //   116: iload_3
/*    */     //   117: iconst_2
/*    */     //   118: if_icmpne -> 159
/*    */     //   121: new java/lang/StringBuffer
/*    */     //   124: dup
/*    */     //   125: invokespecial <init> : ()V
/*    */     //   128: aload #6
/*    */     //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   133: ldc '/'
/*    */     //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   138: aload #7
/*    */     //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   143: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   146: astore #6
/*    */     //   148: sipush #-751
/*    */     //   151: sipush #18567
/*    */     //   154: invokestatic a : (II)Ljava/lang/String;
/*    */     //   157: astore #7
/*    */     //   159: new net/portswigger/infiltrator/patcher/b
/*    */     //   162: dup
/*    */     //   163: aload #6
/*    */     //   165: aload #7
/*    */     //   167: iload_3
/*    */     //   168: aload #8
/*    */     //   170: aload_1
/*    */     //   171: getfield b : Ljava/lang/String;
/*    */     //   174: aload_1
/*    */     //   175: getfield c : Ljava/lang/String;
/*    */     //   178: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*    */     //   181: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #69	-> 0
/*    */     //   #70	-> 23
/*    */     //   #71	-> 40
/*    */     //   #74	-> 56
/*    */     //   #79	-> 61
/*    */     //   #83	-> 110
/*    */     //   #86	-> 116
/*    */     //   #88	-> 121
/*    */     //   #89	-> 148
/*    */     //   #92	-> 159
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: bipush #7
/*    */     //   2: anewarray java/lang/String
/*    */     //   5: astore #5
/*    */     //   7: iconst_0
/*    */     //   8: istore_3
/*    */     //   9: ldc '¯m{r¼óHdkêûÌÉñOTÕR\\f$æåJÿàý-Â;\\nÉq[HýZUõ}'
/*    */     //   11: dup
/*    */     //   12: astore_2
/*    */     //   13: invokevirtual length : ()I
/*    */     //   16: istore #4
/*    */     //   18: iconst_4
/*    */     //   19: istore_1
/*    */     //   20: iconst_m1
/*    */     //   21: istore_0
/*    */     //   22: iinc #0, 1
/*    */     //   25: aload_2
/*    */     //   26: iload_0
/*    */     //   27: dup
/*    */     //   28: iload_1
/*    */     //   29: iadd
/*    */     //   30: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   33: jsr -> 136
/*    */     //   36: aload #5
/*    */     //   38: swap
/*    */     //   39: iload_3
/*    */     //   40: iinc #3, 1
/*    */     //   43: swap
/*    */     //   44: aastore
/*    */     //   45: iload_0
/*    */     //   46: iload_1
/*    */     //   47: iadd
/*    */     //   48: dup
/*    */     //   49: istore_0
/*    */     //   50: iload #4
/*    */     //   52: if_icmpge -> 64
/*    */     //   55: aload_2
/*    */     //   56: iload_0
/*    */     //   57: invokevirtual charAt : (I)C
/*    */     //   60: istore_1
/*    */     //   61: goto -> 22
/*    */     //   64: ldc '´ÿÚkW)ö±É¿wö\\b~%Kì=\\nn®ø½·Õ©`|ñdÃþëëPIÉOmäkìS'
/*    */     //   66: dup
/*    */     //   67: astore_2
/*    */     //   68: invokevirtual length : ()I
/*    */     //   71: istore #4
/*    */     //   73: bipush #17
/*    */     //   75: istore_1
/*    */     //   76: iconst_m1
/*    */     //   77: istore_0
/*    */     //   78: iinc #0, 1
/*    */     //   81: aload_2
/*    */     //   82: iload_0
/*    */     //   83: dup
/*    */     //   84: iload_1
/*    */     //   85: iadd
/*    */     //   86: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   89: jsr -> 136
/*    */     //   92: aload #5
/*    */     //   94: swap
/*    */     //   95: iload_3
/*    */     //   96: iinc #3, 1
/*    */     //   99: swap
/*    */     //   100: aastore
/*    */     //   101: iload_0
/*    */     //   102: iload_1
/*    */     //   103: iadd
/*    */     //   104: dup
/*    */     //   105: istore_0
/*    */     //   106: iload #4
/*    */     //   108: if_icmpge -> 120
/*    */     //   111: aload_2
/*    */     //   112: iload_0
/*    */     //   113: invokevirtual charAt : (I)C
/*    */     //   116: istore_1
/*    */     //   117: goto -> 78
/*    */     //   120: aload #5
/*    */     //   122: putstatic net/portswigger/infiltrator/patcher/d.a : [Ljava/lang/String;
/*    */     //   125: bipush #7
/*    */     //   127: anewarray java/lang/String
/*    */     //   130: putstatic net/portswigger/infiltrator/patcher/d.b : [Ljava/lang/String;
/*    */     //   133: goto -> 275
/*    */     //   136: astore #6
/*    */     //   138: invokevirtual toCharArray : ()[C
/*    */     //   141: dup
/*    */     //   142: arraylength
/*    */     //   143: swap
/*    */     //   144: iconst_0
/*    */     //   145: istore #7
/*    */     //   147: swap
/*    */     //   148: dup_x1
/*    */     //   149: iconst_1
/*    */     //   150: if_icmpgt -> 253
/*    */     //   153: dup
/*    */     //   154: iload #7
/*    */     //   156: dup2
/*    */     //   157: caload
/*    */     //   158: iload #7
/*    */     //   160: bipush #7
/*    */     //   162: irem
/*    */     //   163: tableswitch default -> 234, 0 -> 200, 1 -> 206, 2 -> 212, 3 -> 218, 4 -> 223, 5 -> 228
/*    */     //   200: sipush #133
/*    */     //   203: goto -> 237
/*    */     //   206: sipush #135
/*    */     //   209: goto -> 237
/*    */     //   212: sipush #186
/*    */     //   215: goto -> 237
/*    */     //   218: bipush #14
/*    */     //   220: goto -> 237
/*    */     //   223: bipush #69
/*    */     //   225: goto -> 237
/*    */     //   228: sipush #223
/*    */     //   231: goto -> 237
/*    */     //   234: sipush #193
/*    */     //   237: ixor
/*    */     //   238: i2c
/*    */     //   239: castore
/*    */     //   240: iinc #7, 1
/*    */     //   243: swap
/*    */     //   244: dup_x1
/*    */     //   245: ifne -> 253
/*    */     //   248: dup2
/*    */     //   249: swap
/*    */     //   250: goto -> 156
/*    */     //   253: swap
/*    */     //   254: dup_x1
/*    */     //   255: iload #7
/*    */     //   257: if_icmpgt -> 153
/*    */     //   260: new java/lang/String
/*    */     //   263: dup_x1
/*    */     //   264: swap
/*    */     //   265: invokespecial <init> : ([C)V
/*    */     //   268: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   271: swap
/*    */     //   272: pop
/*    */     //   273: ret #6
/*    */     //   275: return
/*    */   }
/*    */   
/*    */   private static String a(int paramInt1, int paramInt2) {
/*    */     int i = (paramInt1 ^ 0xFFFFFD10) & 0xFFFF;
/*    */     if (b[i] == null) {
/*    */       char[] arrayOfChar = a[i].toCharArray();
/*    */       switch (arrayOfChar[0] & 0xFF) {
/*    */         case 0:
/*    */         
/*    */         case 1:
/*    */         
/*    */         case 2:
/*    */         
/*    */         case 3:
/*    */         
/*    */         case 4:
/*    */         
/*    */         case 5:
/*    */         
/*    */         case 6:
/*    */         
/*    */         case 7:
/*    */         
/*    */         case 8:
/*    */         
/*    */         case 9:
/*    */         
/*    */         case 10:
/*    */         
/*    */         case 11:
/*    */         
/*    */         case 12:
/*    */         
/*    */         case 13:
/*    */         
/*    */         case 14:
/*    */         
/*    */         case 15:
/*    */         
/*    */         case 16:
/*    */         
/*    */         case 17:
/*    */         
/*    */         case 18:
/*    */         
/*    */         case 19:
/*    */         
/*    */         case 20:
/*    */         
/*    */         case 21:
/*    */         
/*    */         case 22:
/*    */         
/*    */         case 23:
/*    */         
/*    */         case 24:
/*    */         
/*    */         case 25:
/*    */         
/*    */         case 26:
/*    */         
/*    */         case 27:
/*    */         
/*    */         case 28:
/*    */         
/*    */         case 29:
/*    */         
/*    */         case 30:
/*    */         
/*    */         case 31:
/*    */         
/*    */         case 32:
/*    */         
/*    */         case 33:
/*    */         
/*    */         case 34:
/*    */         
/*    */         case 35:
/*    */         
/*    */         case 36:
/*    */         
/*    */         case 37:
/*    */         
/*    */         case 38:
/*    */         
/*    */         case 39:
/*    */         
/*    */         case 40:
/*    */         
/*    */         case 41:
/*    */         
/*    */         case 42:
/*    */         
/*    */         case 43:
/*    */         
/*    */         case 44:
/*    */         
/*    */         case 45:
/*    */         
/*    */         case 46:
/*    */         
/*    */         case 47:
/*    */         
/*    */         case 48:
/*    */         
/*    */         case 49:
/*    */         
/*    */         case 50:
/*    */         
/*    */         case 51:
/*    */         
/*    */         case 52:
/*    */         
/*    */         case 53:
/*    */         
/*    */         case 54:
/*    */         
/*    */         case 55:
/*    */         
/*    */         case 56:
/*    */         
/*    */         case 57:
/*    */         
/*    */         case 58:
/*    */         
/*    */         case 59:
/*    */         
/*    */         case 60:
/*    */         
/*    */         case 61:
/*    */         
/*    */         case 62:
/*    */         
/*    */         case 63:
/*    */         
/*    */         case 64:
/*    */         
/*    */         case 65:
/*    */         
/*    */         case 66:
/*    */         
/*    */         case 67:
/*    */         
/*    */         case 68:
/*    */         
/*    */         case 69:
/*    */         
/*    */         case 70:
/*    */         
/*    */         case 71:
/*    */         
/*    */         case 72:
/*    */         
/*    */         case 73:
/*    */         
/*    */         case 74:
/*    */         
/*    */         case 75:
/*    */         
/*    */         case 76:
/*    */         
/*    */         case 77:
/*    */         
/*    */         case 78:
/*    */         
/*    */         case 79:
/*    */         
/*    */         case 80:
/*    */         
/*    */         case 81:
/*    */         
/*    */         case 82:
/*    */         
/*    */         case 83:
/*    */         
/*    */         case 84:
/*    */         
/*    */         case 85:
/*    */         
/*    */         case 86:
/*    */         
/*    */         case 87:
/*    */         
/*    */         case 88:
/*    */         
/*    */         case 89:
/*    */         
/*    */         case 90:
/*    */         
/*    */         case 91:
/*    */         
/*    */         case 92:
/*    */         
/*    */         case 93:
/*    */         
/*    */         case 94:
/*    */         
/*    */         case 95:
/*    */         
/*    */         case 96:
/*    */         
/*    */         case 97:
/*    */         
/*    */         case 98:
/*    */         
/*    */         case 99:
/*    */         
/*    */         case 100:
/*    */         
/*    */         case 101:
/*    */         
/*    */         case 102:
/*    */         
/*    */         case 103:
/*    */         
/*    */         case 104:
/*    */         
/*    */         case 105:
/*    */         
/*    */         case 106:
/*    */         
/*    */         case 107:
/*    */         
/*    */         case 108:
/*    */         
/*    */         case 109:
/*    */         
/*    */         case 110:
/*    */         
/*    */         case 111:
/*    */         
/*    */         case 112:
/*    */         
/*    */         case 113:
/*    */         
/*    */         case 114:
/*    */         
/*    */         case 115:
/*    */         
/*    */         case 116:
/*    */         
/*    */         case 117:
/*    */         
/*    */         case 118:
/*    */         
/*    */         case 119:
/*    */         
/*    */         case 120:
/*    */         
/*    */         case 121:
/*    */         
/*    */         case 122:
/*    */         
/*    */         case 123:
/*    */         
/*    */         case 124:
/*    */         
/*    */         case 125:
/*    */         
/*    */         case 126:
/*    */         
/*    */         case 127:
/*    */         
/*    */         case 128:
/*    */         
/*    */         case 129:
/*    */         
/*    */         case 130:
/*    */         
/*    */         case 131:
/*    */         
/*    */         case 132:
/*    */         
/*    */         case 133:
/*    */         
/*    */         case 134:
/*    */         
/*    */         case 135:
/*    */         
/*    */         case 136:
/*    */         
/*    */         case 137:
/*    */         
/*    */         case 138:
/*    */         
/*    */         case 139:
/*    */         
/*    */         case 140:
/*    */         
/*    */         case 141:
/*    */         
/*    */         case 142:
/*    */         
/*    */         case 143:
/*    */         
/*    */         case 144:
/*    */         
/*    */         case 145:
/*    */         
/*    */         case 146:
/*    */         
/*    */         case 147:
/*    */         
/*    */         case 148:
/*    */         
/*    */         case 149:
/*    */         
/*    */         case 150:
/*    */         
/*    */         case 151:
/*    */         
/*    */         case 152:
/*    */         
/*    */         case 153:
/*    */         
/*    */         case 154:
/*    */         
/*    */         case 155:
/*    */         
/*    */         case 156:
/*    */         
/*    */         case 157:
/*    */         
/*    */         case 158:
/*    */         
/*    */         case 159:
/*    */         
/*    */         case 160:
/*    */         
/*    */         case 161:
/*    */         
/*    */         case 162:
/*    */         
/*    */         case 163:
/*    */         
/*    */         case 164:
/*    */         
/*    */         case 165:
/*    */         
/*    */         case 166:
/*    */         
/*    */         case 167:
/*    */         
/*    */         case 168:
/*    */         
/*    */         case 169:
/*    */         
/*    */         case 170:
/*    */         
/*    */         case 171:
/*    */         
/*    */         case 172:
/*    */         
/*    */         case 173:
/*    */         
/*    */         case 174:
/*    */         
/*    */         case 175:
/*    */         
/*    */         case 176:
/*    */         
/*    */         case 177:
/*    */         
/*    */         case 178:
/*    */         
/*    */         case 179:
/*    */         
/*    */         case 180:
/*    */         
/*    */         case 181:
/*    */         
/*    */         case 182:
/*    */         
/*    */         case 183:
/*    */         
/*    */         case 184:
/*    */         
/*    */         case 185:
/*    */         
/*    */         case 186:
/*    */         
/*    */         case 187:
/*    */         
/*    */         case 188:
/*    */         
/*    */         case 189:
/*    */         
/*    */         case 190:
/*    */         
/*    */         case 191:
/*    */         
/*    */         case 192:
/*    */         
/*    */         case 193:
/*    */         
/*    */         case 194:
/*    */         
/*    */         case 195:
/*    */         
/*    */         case 196:
/*    */         
/*    */         case 197:
/*    */         
/*    */         case 198:
/*    */         
/*    */         case 199:
/*    */         
/*    */         case 200:
/*    */         
/*    */         case 201:
/*    */         
/*    */         case 202:
/*    */         
/*    */         case 203:
/*    */         
/*    */         case 204:
/*    */         
/*    */         case 205:
/*    */         
/*    */         case 206:
/*    */         
/*    */         case 207:
/*    */         
/*    */         case 208:
/*    */         
/*    */         case 209:
/*    */         
/*    */         case 210:
/*    */         
/*    */         case 211:
/*    */         
/*    */         case 212:
/*    */         
/*    */         case 213:
/*    */         
/*    */         case 214:
/*    */         
/*    */         case 215:
/*    */         
/*    */         case 216:
/*    */         
/*    */         case 217:
/*    */         
/*    */         case 218:
/*    */         
/*    */         case 219:
/*    */         
/*    */         case 220:
/*    */         
/*    */         case 221:
/*    */         
/*    */         case 222:
/*    */         
/*    */         case 223:
/*    */         
/*    */         case 224:
/*    */         
/*    */         case 225:
/*    */         
/*    */         case 226:
/*    */         
/*    */         case 227:
/*    */         
/*    */         case 228:
/*    */         
/*    */         case 229:
/*    */         
/*    */         case 230:
/*    */         
/*    */         case 231:
/*    */         
/*    */         case 232:
/*    */         
/*    */         case 233:
/*    */         
/*    */         case 234:
/*    */         
/*    */         case 235:
/*    */         
/*    */         case 236:
/*    */         
/*    */         case 237:
/*    */         
/*    */         case 238:
/*    */         
/*    */         case 239:
/*    */         
/*    */         case 240:
/*    */         
/*    */         case 241:
/*    */         
/*    */         case 242:
/*    */         
/*    */         case 243:
/*    */         
/*    */         case 244:
/*    */         
/*    */         case 245:
/*    */         
/*    */         case 246:
/*    */         
/*    */         case 247:
/*    */         
/*    */         case 248:
/*    */         
/*    */         case 249:
/*    */         
/*    */         case 250:
/*    */         
/*    */         case 251:
/*    */         
/*    */         case 252:
/*    */         
/*    */         case 253:
/*    */         
/*    */         case 254:
/*    */         
/*    */         default:
/*    */           break;
/*    */       } 
/*    */       byte b1 = 122;
/*    */       int j = (paramInt2 & 0xFF) - b1;
/*    */       if (j < 0)
/*    */         j += 256; 
/*    */       int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
/*    */       if (k < 0)
/*    */         k += 256; 
/*    */       for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*    */         int m = b2 % 2;
/*    */         if (m == 0) {
/*    */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
/*    */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
/*    */         } else {
/*    */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
/*    */           k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
/*    */         } 
/*    */       } 
/*    */       b[i] = (new String(arrayOfChar)).intern();
/*    */     } 
/*    */     return b[i];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\d.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */