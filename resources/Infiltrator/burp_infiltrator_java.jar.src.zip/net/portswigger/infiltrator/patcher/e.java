/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.a;
/*    */ 
/*    */ 
/*    */ class e
/*    */ {
/*    */   private static final List b;
/*    */   static final List c;
/*    */   private static String a;
/*    */   private final v e;
/*    */   static Class d;
/*    */   private static final String[] f;
/*    */   private static final String[] g;
/*    */   
/*    */   static Class a(String paramString) {
/*    */     
/* 20 */     try { return Class.forName(a.a(paramString)); } catch (ClassNotFoundException classNotFoundException) { throw (new NoClassDefFoundError()).initCause(classNotFoundException); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public e(v paramv) {
/* 39 */     this.e = paramv;
/*    */   }
/*    */   public void a(k paramk) {
/*    */     boolean bool;
/*    */     byte b;
/* 44 */     for (b = 0, bool = w.e; b < paramk.a.size(); ) {
/*    */       
/* 46 */       a(new File(paramk.a.get(b)));
/*    */       b++;
/*    */       if (bool)
/*    */         break; 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void a(File paramFile) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: aload_1
/*    */     //   4: invokevirtual listFiles : ()[Ljava/io/File;
/*    */     //   7: astore_3
/*    */     //   8: istore_2
/*    */     //   9: aload_3
/*    */     //   10: ifnonnull -> 15
/*    */     //   13: return
/*    */     //   14: athrow
/*    */     //   15: iconst_0
/*    */     //   16: istore #4
/*    */     //   18: iload #4
/*    */     //   20: aload_3
/*    */     //   21: arraylength
/*    */     //   22: if_icmpge -> 251
/*    */     //   25: aload_3
/*    */     //   26: iload #4
/*    */     //   28: aaload
/*    */     //   29: astore #5
/*    */     //   31: aload #5
/*    */     //   33: invokevirtual isDirectory : ()Z
/*    */     //   36: iload_2
/*    */     //   37: ifne -> 62
/*    */     //   40: ifne -> 165
/*    */     //   43: goto -> 47
/*    */     //   46: athrow
/*    */     //   47: getstatic net/portswigger/infiltrator/patcher/e.b : Ljava/util/List;
/*    */     //   50: aload #5
/*    */     //   52: invokevirtual getName : ()Ljava/lang/String;
/*    */     //   55: invokestatic a : (Ljava/util/List;Ljava/lang/String;)Z
/*    */     //   58: goto -> 62
/*    */     //   61: athrow
/*    */     //   62: iload_2
/*    */     //   63: ifne -> 103
/*    */     //   66: ifeq -> 175
/*    */     //   69: goto -> 73
/*    */     //   72: athrow
/*    */     //   73: aload #5
/*    */     //   75: invokevirtual getAbsolutePath : ()Ljava/lang/String;
/*    */     //   78: invokevirtual toLowerCase : ()Ljava/lang/String;
/*    */     //   81: sipush #29299
/*    */     //   84: iconst_2
/*    */     //   85: invokestatic a : (II)Ljava/lang/String;
/*    */     //   88: ldc '/'
/*    */     //   90: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*    */     //   93: getstatic net/portswigger/infiltrator/patcher/e.a : Ljava/lang/String;
/*    */     //   96: invokevirtual indexOf : (Ljava/lang/String;)I
/*    */     //   99: goto -> 103
/*    */     //   102: athrow
/*    */     //   103: iconst_m1
/*    */     //   104: if_icmpne -> 175
/*    */     //   107: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*    */     //   110: new java/lang/StringBuffer
/*    */     //   113: dup
/*    */     //   114: invokespecial <init> : ()V
/*    */     //   117: sipush #29297
/*    */     //   120: sipush #-10877
/*    */     //   123: invokestatic a : (II)Ljava/lang/String;
/*    */     //   126: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   129: aload #5
/*    */     //   131: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*    */     //   134: ldc ']'
/*    */     //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   139: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   142: invokevirtual a : (Ljava/lang/String;)V
/*    */     //   145: aload_0
/*    */     //   146: getfield e : Lnet/portswigger/infiltrator/patcher/v;
/*    */     //   149: aload #5
/*    */     //   151: invokevirtual getAbsolutePath : ()Ljava/lang/String;
/*    */     //   154: invokevirtual b : (Ljava/lang/String;)V
/*    */     //   157: iload_2
/*    */     //   158: ifeq -> 175
/*    */     //   161: goto -> 165
/*    */     //   164: athrow
/*    */     //   165: aload_0
/*    */     //   166: aload #5
/*    */     //   168: invokevirtual a : (Ljava/io/File;)V
/*    */     //   171: goto -> 175
/*    */     //   174: athrow
/*    */     //   175: goto -> 244
/*    */     //   178: astore #6
/*    */     //   180: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*    */     //   183: new java/lang/StringBuffer
/*    */     //   186: dup
/*    */     //   187: invokespecial <init> : ()V
/*    */     //   190: sipush #29296
/*    */     //   193: sipush #-18329
/*    */     //   196: invokestatic a : (II)Ljava/lang/String;
/*    */     //   199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   202: aload #5
/*    */     //   204: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*    */     //   207: sipush #29300
/*    */     //   210: sipush #11742
/*    */     //   213: invokestatic a : (II)Ljava/lang/String;
/*    */     //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   219: aload #6
/*    */     //   221: invokevirtual getMessage : ()Ljava/lang/String;
/*    */     //   224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   227: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   230: invokevirtual b : (Ljava/lang/String;)V
/*    */     //   233: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*    */     //   236: aload #6
/*    */     //   238: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
/*    */     //   241: invokevirtual a : ([Ljava/lang/StackTraceElement;)V
/*    */     //   244: iinc #4, 1
/*    */     //   247: iload_2
/*    */     //   248: ifeq -> 18
/*    */     //   251: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #52	-> 3
/*    */     //   #53	-> 9
/*    */     //   #55	-> 13
/*    */     //   #58	-> 15
/*    */     //   #60	-> 25
/*    */     //   #63	-> 31
/*    */     //   #65	-> 47
/*    */     //   #69	-> 107
/*    */     //   #71	-> 145
/*    */     //   #76	-> 165
/*    */     //   #86	-> 175
/*    */     //   #79	-> 178
/*    */     //   #83	-> 180
/*    */     //   #84	-> 233
/*    */     //   #58	-> 244
/*    */     //   #88	-> 251
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   9	14	14	java/io/IOException
/*    */     //   31	43	46	java/io/IOException
/*    */     //   31	175	178	java/io/IOException
/*    */     //   40	58	61	java/io/IOException
/*    */     //   62	69	72	java/io/IOException
/*    */     //   66	99	102	java/io/IOException
/*    */     //   103	161	164	java/io/IOException
/*    */     //   107	171	174	java/io/IOException
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: bipush #9
/*    */     //   2: anewarray java/lang/String
/*    */     //   5: astore #5
/*    */     //   7: iconst_0
/*    */     //   8: istore_3
/*    */     //   9: ldc '65þhÄ%]e} ùm;$ë¬¦)[.J5G*ußºü@R¶Ý²\\f£÷aaÿMÌÈï4YQu÷ëcî\\f(,1ä3Gà]>t2ß«A'
/*    */     //   11: dup
/*    */     //   12: astore_2
/*    */     //   13: invokevirtual length : ()I
/*    */     //   16: istore #4
/*    */     //   18: iconst_3
/*    */     //   19: istore_1
/*    */     //   20: iconst_m1
/*    */     //   21: istore_0
/*    */     //   22: iinc #0, 1
/*    */     //   25: aload_2
/*    */     //   26: iload_0
/*    */     //   27: dup
/*    */     //   28: iload_1
/*    */     //   29: iadd
/*    */     //   30: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   33: jsr -> 135
/*    */     //   36: aload #5
/*    */     //   38: swap
/*    */     //   39: iload_3
/*    */     //   40: iinc #3, 1
/*    */     //   43: swap
/*    */     //   44: aastore
/*    */     //   45: iload_0
/*    */     //   46: iload_1
/*    */     //   47: iadd
/*    */     //   48: dup
/*    */     //   49: istore_0
/*    */     //   50: iload #4
/*    */     //   52: if_icmpge -> 64
/*    */     //   55: aload_2
/*    */     //   56: iload_0
/*    */     //   57: invokevirtual charAt : (I)C
/*    */     //   60: istore_1
/*    */     //   61: goto -> 22
/*    */     //   64: ldc 'b4Ý'
/*    */     //   66: dup
/*    */     //   67: astore_2
/*    */     //   68: invokevirtual length : ()I
/*    */     //   71: istore #4
/*    */     //   73: iconst_2
/*    */     //   74: istore_1
/*    */     //   75: iconst_m1
/*    */     //   76: istore_0
/*    */     //   77: iinc #0, 1
/*    */     //   80: aload_2
/*    */     //   81: iload_0
/*    */     //   82: dup
/*    */     //   83: iload_1
/*    */     //   84: iadd
/*    */     //   85: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   88: jsr -> 135
/*    */     //   91: aload #5
/*    */     //   93: swap
/*    */     //   94: iload_3
/*    */     //   95: iinc #3, 1
/*    */     //   98: swap
/*    */     //   99: aastore
/*    */     //   100: iload_0
/*    */     //   101: iload_1
/*    */     //   102: iadd
/*    */     //   103: dup
/*    */     //   104: istore_0
/*    */     //   105: iload #4
/*    */     //   107: if_icmpge -> 119
/*    */     //   110: aload_2
/*    */     //   111: iload_0
/*    */     //   112: invokevirtual charAt : (I)C
/*    */     //   115: istore_1
/*    */     //   116: goto -> 77
/*    */     //   119: aload #5
/*    */     //   121: putstatic net/portswigger/infiltrator/patcher/e.f : [Ljava/lang/String;
/*    */     //   124: bipush #9
/*    */     //   126: anewarray java/lang/String
/*    */     //   129: putstatic net/portswigger/infiltrator/patcher/e.g : [Ljava/lang/String;
/*    */     //   132: goto -> 274
/*    */     //   135: astore #6
/*    */     //   137: invokevirtual toCharArray : ()[C
/*    */     //   140: dup
/*    */     //   141: arraylength
/*    */     //   142: swap
/*    */     //   143: iconst_0
/*    */     //   144: istore #7
/*    */     //   146: swap
/*    */     //   147: dup_x1
/*    */     //   148: iconst_1
/*    */     //   149: if_icmpgt -> 252
/*    */     //   152: dup
/*    */     //   153: iload #7
/*    */     //   155: dup2
/*    */     //   156: caload
/*    */     //   157: iload #7
/*    */     //   159: bipush #7
/*    */     //   161: irem
/*    */     //   162: tableswitch default -> 233, 0 -> 200, 1 -> 205, 2 -> 210, 3 -> 216, 4 -> 221, 5 -> 227
/*    */     //   200: bipush #108
/*    */     //   202: goto -> 236
/*    */     //   205: bipush #56
/*    */     //   207: goto -> 236
/*    */     //   210: sipush #140
/*    */     //   213: goto -> 236
/*    */     //   216: bipush #91
/*    */     //   218: goto -> 236
/*    */     //   221: sipush #180
/*    */     //   224: goto -> 236
/*    */     //   227: sipush #244
/*    */     //   230: goto -> 236
/*    */     //   233: sipush #247
/*    */     //   236: ixor
/*    */     //   237: i2c
/*    */     //   238: castore
/*    */     //   239: iinc #7, 1
/*    */     //   242: swap
/*    */     //   243: dup_x1
/*    */     //   244: ifne -> 252
/*    */     //   247: dup2
/*    */     //   248: swap
/*    */     //   249: goto -> 155
/*    */     //   252: swap
/*    */     //   253: dup_x1
/*    */     //   254: iload #7
/*    */     //   256: if_icmpgt -> 152
/*    */     //   259: new java/lang/String
/*    */     //   262: dup_x1
/*    */     //   263: swap
/*    */     //   264: invokespecial <init> : ([C)V
/*    */     //   267: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   270: swap
/*    */     //   271: pop
/*    */     //   272: ret #6
/*    */     //   274: new java/util/ArrayList
/*    */     //   277: dup
/*    */     //   278: invokespecial <init> : ()V
/*    */     //   281: putstatic net/portswigger/infiltrator/patcher/e.b : Ljava/util/List;
/*    */     //   284: new java/util/ArrayList
/*    */     //   287: dup
/*    */     //   288: invokespecial <init> : ()V
/*    */     //   291: putstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*    */     //   294: new java/net/URI
/*    */     //   297: dup
/*    */     //   298: getstatic net/portswigger/infiltrator/patcher/e.d : Ljava/lang/Class;
/*    */     //   301: ifnonnull -> 323
/*    */     //   304: sipush #29302
/*    */     //   307: sipush #2609
/*    */     //   310: invokestatic a : (II)Ljava/lang/String;
/*    */     //   313: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   316: dup
/*    */     //   317: putstatic net/portswigger/infiltrator/patcher/e.d : Ljava/lang/Class;
/*    */     //   320: goto -> 326
/*    */     //   323: getstatic net/portswigger/infiltrator/patcher/e.d : Ljava/lang/Class;
/*    */     //   326: invokevirtual getProtectionDomain : ()Ljava/security/ProtectionDomain;
/*    */     //   329: invokevirtual getCodeSource : ()Ljava/security/CodeSource;
/*    */     //   332: invokevirtual getLocation : ()Ljava/net/URL;
/*    */     //   335: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   338: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   341: invokevirtual getPath : ()Ljava/lang/String;
/*    */     //   344: astore #8
/*    */     //   346: aload #8
/*    */     //   348: aload #8
/*    */     //   350: ldc '/'
/*    */     //   352: invokevirtual indexOf : (Ljava/lang/String;)I
/*    */     //   355: iconst_1
/*    */     //   356: iadd
/*    */     //   357: invokevirtual substring : (I)Ljava/lang/String;
/*    */     //   360: invokevirtual toLowerCase : ()Ljava/lang/String;
/*    */     //   363: putstatic net/portswigger/infiltrator/patcher/e.a : Ljava/lang/String;
/*    */     //   366: goto -> 371
/*    */     //   369: astore #8
/*    */     //   371: getstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*    */     //   374: sipush #29308
/*    */     //   377: sipush #7083
/*    */     //   380: invokestatic a : (II)Ljava/lang/String;
/*    */     //   383: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   388: pop
/*    */     //   389: getstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*    */     //   392: sipush #29303
/*    */     //   395: sipush #18970
/*    */     //   398: invokestatic a : (II)Ljava/lang/String;
/*    */     //   401: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   406: pop
/*    */     //   407: getstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*    */     //   410: sipush #29298
/*    */     //   413: sipush #-1571
/*    */     //   416: invokestatic a : (II)Ljava/lang/String;
/*    */     //   419: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   424: pop
/*    */     //   425: getstatic net/portswigger/infiltrator/patcher/e.b : Ljava/util/List;
/*    */     //   428: getstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*    */     //   431: invokeinterface addAll : (Ljava/util/Collection;)Z
/*    */     //   436: pop
/*    */     //   437: getstatic net/portswigger/infiltrator/patcher/e.b : Ljava/util/List;
/*    */     //   440: sipush #29301
/*    */     //   443: sipush #13912
/*    */     //   446: invokestatic a : (II)Ljava/lang/String;
/*    */     //   449: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   454: pop
/*    */     //   455: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #12	-> 274
/*    */     //   #13	-> 284
/*    */     //   #20	-> 294
/*    */     //   #21	-> 346
/*    */     //   #25	-> 366
/*    */     //   #23	-> 369
/*    */     //   #27	-> 371
/*    */     //   #28	-> 389
/*    */     //   #29	-> 407
/*    */     //   #31	-> 425
/*    */     //   #32	-> 437
/*    */     //   #33	-> 455
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   294	366	369	java/net/URISyntaxException
/*    */   }
/*    */   
/*    */   private static String a(int paramInt1, int paramInt2) {
/*    */     int i = (paramInt1 ^ 0x7274) & 0xFFFF;
/*    */     if (g[i] == null) {
/*    */       char[] arrayOfChar = f[i].toCharArray();
/*    */       switch (arrayOfChar[0] & 0xFF) {
/*    */         case 0:
/*    */         
/*    */         case 1:
/*    */         
/*    */         case 2:
/*    */         
/*    */         case 3:
/*    */         
/*    */         case 4:
/*    */         
/*    */         case 5:
/*    */         
/*    */         case 6:
/*    */         
/*    */         case 7:
/*    */         
/*    */         case 8:
/*    */         
/*    */         case 9:
/*    */         
/*    */         case 10:
/*    */         
/*    */         case 11:
/*    */         
/*    */         case 12:
/*    */         
/*    */         case 13:
/*    */         
/*    */         case 14:
/*    */         
/*    */         case 15:
/*    */         
/*    */         case 16:
/*    */         
/*    */         case 17:
/*    */         
/*    */         case 18:
/*    */         
/*    */         case 19:
/*    */         
/*    */         case 20:
/*    */         
/*    */         case 21:
/*    */         
/*    */         case 22:
/*    */         
/*    */         case 23:
/*    */         
/*    */         case 24:
/*    */         
/*    */         case 25:
/*    */         
/*    */         case 26:
/*    */         
/*    */         case 27:
/*    */         
/*    */         case 28:
/*    */         
/*    */         case 29:
/*    */         
/*    */         case 30:
/*    */         
/*    */         case 31:
/*    */         
/*    */         case 32:
/*    */         
/*    */         case 33:
/*    */         
/*    */         case 34:
/*    */         
/*    */         case 35:
/*    */         
/*    */         case 36:
/*    */         
/*    */         case 37:
/*    */         
/*    */         case 38:
/*    */         
/*    */         case 39:
/*    */         
/*    */         case 40:
/*    */         
/*    */         case 41:
/*    */         
/*    */         case 42:
/*    */         
/*    */         case 43:
/*    */         
/*    */         case 44:
/*    */         
/*    */         case 45:
/*    */         
/*    */         case 46:
/*    */         
/*    */         case 47:
/*    */         
/*    */         case 48:
/*    */         
/*    */         case 49:
/*    */         
/*    */         case 50:
/*    */         
/*    */         case 51:
/*    */         
/*    */         case 52:
/*    */         
/*    */         case 53:
/*    */         
/*    */         case 54:
/*    */         
/*    */         case 55:
/*    */         
/*    */         case 56:
/*    */         
/*    */         case 57:
/*    */         
/*    */         case 58:
/*    */         
/*    */         case 59:
/*    */         
/*    */         case 60:
/*    */         
/*    */         case 61:
/*    */         
/*    */         case 62:
/*    */         
/*    */         case 63:
/*    */         
/*    */         case 64:
/*    */         
/*    */         case 65:
/*    */         
/*    */         case 66:
/*    */         
/*    */         case 67:
/*    */         
/*    */         case 68:
/*    */         
/*    */         case 69:
/*    */         
/*    */         case 70:
/*    */         
/*    */         case 71:
/*    */         
/*    */         case 72:
/*    */         
/*    */         case 73:
/*    */         
/*    */         case 74:
/*    */         
/*    */         case 75:
/*    */         
/*    */         case 76:
/*    */         
/*    */         case 77:
/*    */         
/*    */         case 78:
/*    */         
/*    */         case 79:
/*    */         
/*    */         case 80:
/*    */         
/*    */         case 81:
/*    */         
/*    */         case 82:
/*    */         
/*    */         case 83:
/*    */         
/*    */         case 84:
/*    */         
/*    */         case 85:
/*    */         
/*    */         case 86:
/*    */         
/*    */         case 87:
/*    */         
/*    */         case 88:
/*    */         
/*    */         case 89:
/*    */         
/*    */         case 90:
/*    */         
/*    */         case 91:
/*    */         
/*    */         case 92:
/*    */         
/*    */         case 93:
/*    */         
/*    */         case 94:
/*    */         
/*    */         case 95:
/*    */         
/*    */         case 96:
/*    */         
/*    */         case 97:
/*    */         
/*    */         case 98:
/*    */         
/*    */         case 99:
/*    */         
/*    */         case 100:
/*    */         
/*    */         case 101:
/*    */         
/*    */         case 102:
/*    */         
/*    */         case 103:
/*    */         
/*    */         case 104:
/*    */         
/*    */         case 105:
/*    */         
/*    */         case 106:
/*    */         
/*    */         case 107:
/*    */         
/*    */         case 108:
/*    */         
/*    */         case 109:
/*    */         
/*    */         case 110:
/*    */         
/*    */         case 111:
/*    */         
/*    */         case 112:
/*    */         
/*    */         case 113:
/*    */         
/*    */         case 114:
/*    */         
/*    */         case 115:
/*    */         
/*    */         case 116:
/*    */         
/*    */         case 117:
/*    */         
/*    */         case 118:
/*    */         
/*    */         case 119:
/*    */         
/*    */         case 120:
/*    */         
/*    */         case 121:
/*    */         
/*    */         case 122:
/*    */         
/*    */         case 123:
/*    */         
/*    */         case 124:
/*    */         
/*    */         case 125:
/*    */         
/*    */         case 126:
/*    */         
/*    */         case 127:
/*    */         
/*    */         case 128:
/*    */         
/*    */         case 129:
/*    */         
/*    */         case 130:
/*    */         
/*    */         case 131:
/*    */         
/*    */         case 132:
/*    */         
/*    */         case 133:
/*    */         
/*    */         case 134:
/*    */         
/*    */         case 135:
/*    */         
/*    */         case 136:
/*    */         
/*    */         case 137:
/*    */         
/*    */         case 138:
/*    */         
/*    */         case 139:
/*    */         
/*    */         case 140:
/*    */         
/*    */         case 141:
/*    */         
/*    */         case 142:
/*    */         
/*    */         case 143:
/*    */         
/*    */         case 144:
/*    */         
/*    */         case 145:
/*    */         
/*    */         case 146:
/*    */         
/*    */         case 147:
/*    */         
/*    */         case 148:
/*    */         
/*    */         case 149:
/*    */         
/*    */         case 150:
/*    */         
/*    */         case 151:
/*    */         
/*    */         case 152:
/*    */         
/*    */         case 153:
/*    */         
/*    */         case 154:
/*    */         
/*    */         case 155:
/*    */         
/*    */         case 156:
/*    */         
/*    */         case 157:
/*    */         
/*    */         case 158:
/*    */         
/*    */         case 159:
/*    */         
/*    */         case 160:
/*    */         
/*    */         case 161:
/*    */         
/*    */         case 162:
/*    */         
/*    */         case 163:
/*    */         
/*    */         case 164:
/*    */         
/*    */         case 165:
/*    */         
/*    */         case 166:
/*    */         
/*    */         case 167:
/*    */         
/*    */         case 168:
/*    */         
/*    */         case 169:
/*    */         
/*    */         case 170:
/*    */         
/*    */         case 171:
/*    */         
/*    */         case 172:
/*    */         
/*    */         case 173:
/*    */         
/*    */         case 174:
/*    */         
/*    */         case 175:
/*    */         
/*    */         case 176:
/*    */         
/*    */         case 177:
/*    */         
/*    */         case 178:
/*    */         
/*    */         case 179:
/*    */         
/*    */         case 180:
/*    */         
/*    */         case 181:
/*    */         
/*    */         case 182:
/*    */         
/*    */         case 183:
/*    */         
/*    */         case 184:
/*    */         
/*    */         case 185:
/*    */         
/*    */         case 186:
/*    */         
/*    */         case 187:
/*    */         
/*    */         case 188:
/*    */         
/*    */         case 189:
/*    */         
/*    */         case 190:
/*    */         
/*    */         case 191:
/*    */         
/*    */         case 192:
/*    */         
/*    */         case 193:
/*    */         
/*    */         case 194:
/*    */         
/*    */         case 195:
/*    */         
/*    */         case 196:
/*    */         
/*    */         case 197:
/*    */         
/*    */         case 198:
/*    */         
/*    */         case 199:
/*    */         
/*    */         case 200:
/*    */         
/*    */         case 201:
/*    */         
/*    */         case 202:
/*    */         
/*    */         case 203:
/*    */         
/*    */         case 204:
/*    */         
/*    */         case 205:
/*    */         
/*    */         case 206:
/*    */         
/*    */         case 207:
/*    */         
/*    */         case 208:
/*    */         
/*    */         case 209:
/*    */         
/*    */         case 210:
/*    */         
/*    */         case 211:
/*    */         
/*    */         case 212:
/*    */         
/*    */         case 213:
/*    */         
/*    */         case 214:
/*    */         
/*    */         case 215:
/*    */         
/*    */         case 216:
/*    */         
/*    */         case 217:
/*    */         
/*    */         case 218:
/*    */         
/*    */         case 219:
/*    */         
/*    */         case 220:
/*    */         
/*    */         case 221:
/*    */         
/*    */         case 222:
/*    */         
/*    */         case 223:
/*    */         
/*    */         case 224:
/*    */         
/*    */         case 225:
/*    */         
/*    */         case 226:
/*    */         
/*    */         case 227:
/*    */         
/*    */         case 228:
/*    */         
/*    */         case 229:
/*    */         
/*    */         case 230:
/*    */         
/*    */         case 231:
/*    */         
/*    */         case 232:
/*    */         
/*    */         case 233:
/*    */         
/*    */         case 234:
/*    */         
/*    */         case 235:
/*    */         
/*    */         case 236:
/*    */         
/*    */         case 237:
/*    */         
/*    */         case 238:
/*    */         
/*    */         case 239:
/*    */         
/*    */         case 240:
/*    */         
/*    */         case 241:
/*    */         
/*    */         case 242:
/*    */         
/*    */         case 243:
/*    */         
/*    */         case 244:
/*    */         
/*    */         case 245:
/*    */         
/*    */         case 246:
/*    */         
/*    */         case 247:
/*    */         
/*    */         case 248:
/*    */         
/*    */         case 249:
/*    */         
/*    */         case 250:
/*    */         
/*    */         case 251:
/*    */         
/*    */         case 252:
/*    */         
/*    */         case 253:
/*    */         
/*    */         case 254:
/*    */         
/*    */         default:
/*    */           break;
/*    */       } 
/*    */       char c = '';
/*    */       int j = (paramInt2 & 0xFF) - c;
/*    */       if (j < 0)
/*    */         j += 256; 
/*    */       int k = ((paramInt2 & 0xFFFF) >>> 8) - c;
/*    */       if (k < 0)
/*    */         k += 256; 
/*    */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*    */         int m = b % 2;
/*    */         if (m == 0) {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
/*    */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } else {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ k);
/*    */           k = ((k >>> 3 | k << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } 
/*    */       } 
/*    */       g[i] = (new String(arrayOfChar)).intern();
/*    */     } 
/*    */     return g[i];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\e.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */