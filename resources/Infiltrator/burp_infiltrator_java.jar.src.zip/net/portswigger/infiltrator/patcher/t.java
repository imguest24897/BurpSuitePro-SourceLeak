/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.objectweb.asm.a;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class t
/*     */ {
/*  16 */   public final f b = new f(); private final k a; static Class c;
/*     */   private static final String[] d;
/*     */   private static final String[] e;
/*     */   
/*     */   public t(k paramk) {
/*  21 */     this.a = paramk;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(l paraml, String paramString, JarOutputStream paramJarOutputStream) {
/*  26 */     String str1 = paraml.a.replaceAll(a(3067, -10028), "/");
/*  27 */     boolean bool = w.e; if (!bool) if (paramString.indexOf(str1) != -1) {  }
/*     */       else { return; }
/*  29 */         String str2 = paramString;
/*  30 */     if (!bool) if (this.b.a(str2)) {  }
/*     */       else { return; }
/*  32 */         a(paramJarOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream) {
/*  39 */     InputStream inputStream = getClass().getResourceAsStream(a(3071, -270)); boolean bool = w.e;
/*  40 */     ZipInputStream zipInputStream = new ZipInputStream(inputStream);
/*     */     
/*     */     try {
/*  43 */       Iterator iterator = this.b.b();
/*  44 */       while (iterator.hasNext())
/*     */       {
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  58 */     catch (IOException iOException) {
/*     */ 
/*     */ 
/*     */       
/*  62 */       j.a.b(iOException.getMessage());
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/*  69 */         zipInputStream.close();
/*  70 */         inputStream.close();
/*     */       }
/*  72 */       catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, ZipInputStream paramZipInputStream, String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore #4
/*     */     //   5: aload_2
/*     */     //   6: invokevirtual getNextEntry : ()Ljava/util/zip/ZipEntry;
/*     */     //   9: dup
/*     */     //   10: astore #5
/*     */     //   12: ifnull -> 95
/*     */     //   15: aload #5
/*     */     //   17: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   20: sipush #3065
/*     */     //   23: sipush #-3450
/*     */     //   26: invokestatic a : (II)Ljava/lang/String;
/*     */     //   29: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   32: ifne -> 40
/*     */     //   35: iload #4
/*     */     //   37: ifeq -> 5
/*     */     //   40: aload_1
/*     */     //   41: new java/util/jar/JarEntry
/*     */     //   44: dup
/*     */     //   45: new java/lang/StringBuffer
/*     */     //   48: dup
/*     */     //   49: invokespecial <init> : ()V
/*     */     //   52: aload_3
/*     */     //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   56: aload #5
/*     */     //   58: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   64: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   67: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   70: invokevirtual putNextEntry : (Ljava/util/zip/ZipEntry;)V
/*     */     //   73: aload_1
/*     */     //   74: aload_2
/*     */     //   75: invokestatic a : (Ljava/io/InputStream;)[B
/*     */     //   78: invokevirtual write : ([B)V
/*     */     //   81: aload_1
/*     */     //   82: invokevirtual closeEntry : ()V
/*     */     //   85: goto -> 5
/*     */     //   88: astore #6
/*     */     //   90: iload #4
/*     */     //   92: ifeq -> 5
/*     */     //   95: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #81	-> 5
/*     */     //   #85	-> 15
/*     */     //   #87	-> 35
/*     */     //   #90	-> 40
/*     */     //   #91	-> 73
/*     */     //   #92	-> 81
/*     */     //   #97	-> 85
/*     */     //   #94	-> 88
/*     */     //   #97	-> 90
/*     */     //   #99	-> 95
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   15	35	88	java/util/zip/ZipException
/*     */     //   40	85	88	java/util/zip/ZipException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, String paramString) {
/*     */     try {
/*     */       
/*     */       try {  }
/* 105 */       catch (IOException iOException) { throw null; }  paramJarOutputStream.putNextEntry(new JarEntry(paramString + ((c == null) ? (c = a(a(3064, -24359))) : c).getPackage().getName().replaceAll(a(3067, -10028), "/") + "/" + a(3066, 11696)));
/* 106 */       paramJarOutputStream.write(this.a.a().getBytes());
/*     */     }
/* 108 */     catch (IOException iOException) {}
/*     */   }
/*     */   
/*     */   static Class a(String paramString) {
/*     */     try {
/*     */       return Class.forName(a.a(paramString));
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       throw (new NoClassDefFoundError()).initCause(classNotFoundException);
/*     */     } 
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: iconst_5
/*     */     //   1: anewarray java/lang/String
/*     */     //   4: astore #5
/*     */     //   6: iconst_0
/*     */     //   7: istore_3
/*     */     //   8: ldc 'ê÷±K>&#oy;ÃFÙr7¤äà'
/*     */     //   10: dup
/*     */     //   11: astore_2
/*     */     //   12: invokevirtual length : ()I
/*     */     //   15: istore #4
/*     */     //   17: iconst_2
/*     */     //   18: istore_1
/*     */     //   19: iconst_m1
/*     */     //   20: istore_0
/*     */     //   21: iinc #0, 1
/*     */     //   24: aload_2
/*     */     //   25: iload_0
/*     */     //   26: dup
/*     */     //   27: iload_1
/*     */     //   28: iadd
/*     */     //   29: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   32: jsr -> 134
/*     */     //   35: aload #5
/*     */     //   37: swap
/*     */     //   38: iload_3
/*     */     //   39: iinc #3, 1
/*     */     //   42: swap
/*     */     //   43: aastore
/*     */     //   44: iload_0
/*     */     //   45: iload_1
/*     */     //   46: iadd
/*     */     //   47: dup
/*     */     //   48: istore_0
/*     */     //   49: iload #4
/*     */     //   51: if_icmpge -> 63
/*     */     //   54: aload_2
/*     */     //   55: iload_0
/*     */     //   56: invokevirtual charAt : (I)C
/*     */     //   59: istore_1
/*     */     //   60: goto -> 21
/*     */     //   63: ldc 'Èü£ùDa?#|îeTc·äbíK×L0w(1$ÒZ{Ñó´®»\\bgÿ/. \\trõ$1j!'
/*     */     //   65: dup
/*     */     //   66: astore_2
/*     */     //   67: invokevirtual length : ()I
/*     */     //   70: istore #4
/*     */     //   72: bipush #37
/*     */     //   74: istore_1
/*     */     //   75: iconst_m1
/*     */     //   76: istore_0
/*     */     //   77: iinc #0, 1
/*     */     //   80: aload_2
/*     */     //   81: iload_0
/*     */     //   82: dup
/*     */     //   83: iload_1
/*     */     //   84: iadd
/*     */     //   85: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   88: jsr -> 134
/*     */     //   91: aload #5
/*     */     //   93: swap
/*     */     //   94: iload_3
/*     */     //   95: iinc #3, 1
/*     */     //   98: swap
/*     */     //   99: aastore
/*     */     //   100: iload_0
/*     */     //   101: iload_1
/*     */     //   102: iadd
/*     */     //   103: dup
/*     */     //   104: istore_0
/*     */     //   105: iload #4
/*     */     //   107: if_icmpge -> 119
/*     */     //   110: aload_2
/*     */     //   111: iload_0
/*     */     //   112: invokevirtual charAt : (I)C
/*     */     //   115: istore_1
/*     */     //   116: goto -> 77
/*     */     //   119: aload #5
/*     */     //   121: putstatic net/portswigger/infiltrator/patcher/t.d : [Ljava/lang/String;
/*     */     //   124: iconst_5
/*     */     //   125: anewarray java/lang/String
/*     */     //   128: putstatic net/portswigger/infiltrator/patcher/t.e : [Ljava/lang/String;
/*     */     //   131: goto -> 273
/*     */     //   134: astore #6
/*     */     //   136: invokevirtual toCharArray : ()[C
/*     */     //   139: dup
/*     */     //   140: arraylength
/*     */     //   141: swap
/*     */     //   142: iconst_0
/*     */     //   143: istore #7
/*     */     //   145: swap
/*     */     //   146: dup_x1
/*     */     //   147: iconst_1
/*     */     //   148: if_icmpgt -> 251
/*     */     //   151: dup
/*     */     //   152: iload #7
/*     */     //   154: dup2
/*     */     //   155: caload
/*     */     //   156: iload #7
/*     */     //   158: bipush #7
/*     */     //   160: irem
/*     */     //   161: tableswitch default -> 233, 0 -> 200, 1 -> 206, 2 -> 211, 3 -> 217, 4 -> 222, 5 -> 228
/*     */     //   200: sipush #140
/*     */     //   203: goto -> 235
/*     */     //   206: bipush #104
/*     */     //   208: goto -> 235
/*     */     //   211: sipush #252
/*     */     //   214: goto -> 235
/*     */     //   217: bipush #97
/*     */     //   219: goto -> 235
/*     */     //   222: sipush #152
/*     */     //   225: goto -> 235
/*     */     //   228: bipush #110
/*     */     //   230: goto -> 235
/*     */     //   233: bipush #65
/*     */     //   235: ixor
/*     */     //   236: i2c
/*     */     //   237: castore
/*     */     //   238: iinc #7, 1
/*     */     //   241: swap
/*     */     //   242: dup_x1
/*     */     //   243: ifne -> 251
/*     */     //   246: dup2
/*     */     //   247: swap
/*     */     //   248: goto -> 154
/*     */     //   251: swap
/*     */     //   252: dup_x1
/*     */     //   253: iload #7
/*     */     //   255: if_icmpgt -> 151
/*     */     //   258: new java/lang/String
/*     */     //   261: dup_x1
/*     */     //   262: swap
/*     */     //   263: invokespecial <init> : ([C)V
/*     */     //   266: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   269: swap
/*     */     //   270: pop
/*     */     //   271: ret #6
/*     */     //   273: return
/*     */   }
/*     */   
/*     */   private static String a(int paramInt1, int paramInt2) {
/*     */     int i = (paramInt1 ^ 0xBFB) & 0xFFFF;
/*     */     if (e[i] == null) {
/*     */       char[] arrayOfChar = d[i].toCharArray();
/*     */       switch (arrayOfChar[0] & 0xFF) {
/*     */         case 0:
/*     */         
/*     */         case 1:
/*     */         
/*     */         case 2:
/*     */         
/*     */         case 3:
/*     */         
/*     */         case 4:
/*     */         
/*     */         case 5:
/*     */         
/*     */         case 6:
/*     */         
/*     */         case 7:
/*     */         
/*     */         case 8:
/*     */         
/*     */         case 9:
/*     */         
/*     */         case 10:
/*     */         
/*     */         case 11:
/*     */         
/*     */         case 12:
/*     */         
/*     */         case 13:
/*     */         
/*     */         case 14:
/*     */         
/*     */         case 15:
/*     */         
/*     */         case 16:
/*     */         
/*     */         case 17:
/*     */         
/*     */         case 18:
/*     */         
/*     */         case 19:
/*     */         
/*     */         case 20:
/*     */         
/*     */         case 21:
/*     */         
/*     */         case 22:
/*     */         
/*     */         case 23:
/*     */         
/*     */         case 24:
/*     */         
/*     */         case 25:
/*     */         
/*     */         case 26:
/*     */         
/*     */         case 27:
/*     */         
/*     */         case 28:
/*     */         
/*     */         case 29:
/*     */         
/*     */         case 30:
/*     */         
/*     */         case 31:
/*     */         
/*     */         case 32:
/*     */         
/*     */         case 33:
/*     */         
/*     */         case 34:
/*     */         
/*     */         case 35:
/*     */         
/*     */         case 36:
/*     */         
/*     */         case 37:
/*     */         
/*     */         case 38:
/*     */         
/*     */         case 39:
/*     */         
/*     */         case 40:
/*     */         
/*     */         case 41:
/*     */         
/*     */         case 42:
/*     */         
/*     */         case 43:
/*     */         
/*     */         case 44:
/*     */         
/*     */         case 45:
/*     */         
/*     */         case 46:
/*     */         
/*     */         case 47:
/*     */         
/*     */         case 48:
/*     */         
/*     */         case 49:
/*     */         
/*     */         case 50:
/*     */         
/*     */         case 51:
/*     */         
/*     */         case 52:
/*     */         
/*     */         case 53:
/*     */         
/*     */         case 54:
/*     */         
/*     */         case 55:
/*     */         
/*     */         case 56:
/*     */         
/*     */         case 57:
/*     */         
/*     */         case 58:
/*     */         
/*     */         case 59:
/*     */         
/*     */         case 60:
/*     */         
/*     */         case 61:
/*     */         
/*     */         case 62:
/*     */         
/*     */         case 63:
/*     */         
/*     */         case 64:
/*     */         
/*     */         case 65:
/*     */         
/*     */         case 66:
/*     */         
/*     */         case 67:
/*     */         
/*     */         case 68:
/*     */         
/*     */         case 69:
/*     */         
/*     */         case 70:
/*     */         
/*     */         case 71:
/*     */         
/*     */         case 72:
/*     */         
/*     */         case 73:
/*     */         
/*     */         case 74:
/*     */         
/*     */         case 75:
/*     */         
/*     */         case 76:
/*     */         
/*     */         case 77:
/*     */         
/*     */         case 78:
/*     */         
/*     */         case 79:
/*     */         
/*     */         case 80:
/*     */         
/*     */         case 81:
/*     */         
/*     */         case 82:
/*     */         
/*     */         case 83:
/*     */         
/*     */         case 84:
/*     */         
/*     */         case 85:
/*     */         
/*     */         case 86:
/*     */         
/*     */         case 87:
/*     */         
/*     */         case 88:
/*     */         
/*     */         case 89:
/*     */         
/*     */         case 90:
/*     */         
/*     */         case 91:
/*     */         
/*     */         case 92:
/*     */         
/*     */         case 93:
/*     */         
/*     */         case 94:
/*     */         
/*     */         case 95:
/*     */         
/*     */         case 96:
/*     */         
/*     */         case 97:
/*     */         
/*     */         case 98:
/*     */         
/*     */         case 99:
/*     */         
/*     */         case 100:
/*     */         
/*     */         case 101:
/*     */         
/*     */         case 102:
/*     */         
/*     */         case 103:
/*     */         
/*     */         case 104:
/*     */         
/*     */         case 105:
/*     */         
/*     */         case 106:
/*     */         
/*     */         case 107:
/*     */         
/*     */         case 108:
/*     */         
/*     */         case 109:
/*     */         
/*     */         case 110:
/*     */         
/*     */         case 111:
/*     */         
/*     */         case 112:
/*     */         
/*     */         case 113:
/*     */         
/*     */         case 114:
/*     */         
/*     */         case 115:
/*     */         
/*     */         case 116:
/*     */         
/*     */         case 117:
/*     */         
/*     */         case 118:
/*     */         
/*     */         case 119:
/*     */         
/*     */         case 120:
/*     */         
/*     */         case 121:
/*     */         
/*     */         case 122:
/*     */         
/*     */         case 123:
/*     */         
/*     */         case 124:
/*     */         
/*     */         case 125:
/*     */         
/*     */         case 126:
/*     */         
/*     */         case 127:
/*     */         
/*     */         case 128:
/*     */         
/*     */         case 129:
/*     */         
/*     */         case 130:
/*     */         
/*     */         case 131:
/*     */         
/*     */         case 132:
/*     */         
/*     */         case 133:
/*     */         
/*     */         case 134:
/*     */         
/*     */         case 135:
/*     */         
/*     */         case 136:
/*     */         
/*     */         case 137:
/*     */         
/*     */         case 138:
/*     */         
/*     */         case 139:
/*     */         
/*     */         case 140:
/*     */         
/*     */         case 141:
/*     */         
/*     */         case 142:
/*     */         
/*     */         case 143:
/*     */         
/*     */         case 144:
/*     */         
/*     */         case 145:
/*     */         
/*     */         case 146:
/*     */         
/*     */         case 147:
/*     */         
/*     */         case 148:
/*     */         
/*     */         case 149:
/*     */         
/*     */         case 150:
/*     */         
/*     */         case 151:
/*     */         
/*     */         case 152:
/*     */         
/*     */         case 153:
/*     */         
/*     */         case 154:
/*     */         
/*     */         case 155:
/*     */         
/*     */         case 156:
/*     */         
/*     */         case 157:
/*     */         
/*     */         case 158:
/*     */         
/*     */         case 159:
/*     */         
/*     */         case 160:
/*     */         
/*     */         case 161:
/*     */         
/*     */         case 162:
/*     */         
/*     */         case 163:
/*     */         
/*     */         case 164:
/*     */         
/*     */         case 165:
/*     */         
/*     */         case 166:
/*     */         
/*     */         case 167:
/*     */         
/*     */         case 168:
/*     */         
/*     */         case 169:
/*     */         
/*     */         case 170:
/*     */         
/*     */         case 171:
/*     */         
/*     */         case 172:
/*     */         
/*     */         case 173:
/*     */         
/*     */         case 174:
/*     */         
/*     */         case 175:
/*     */         
/*     */         case 176:
/*     */         
/*     */         case 177:
/*     */         
/*     */         case 178:
/*     */         
/*     */         case 179:
/*     */         
/*     */         case 180:
/*     */         
/*     */         case 181:
/*     */         
/*     */         case 182:
/*     */         
/*     */         case 183:
/*     */         
/*     */         case 184:
/*     */         
/*     */         case 185:
/*     */         
/*     */         case 186:
/*     */         
/*     */         case 187:
/*     */         
/*     */         case 188:
/*     */         
/*     */         case 189:
/*     */         
/*     */         case 190:
/*     */         
/*     */         case 191:
/*     */         
/*     */         case 192:
/*     */         
/*     */         case 193:
/*     */         
/*     */         case 194:
/*     */         
/*     */         case 195:
/*     */         
/*     */         case 196:
/*     */         
/*     */         case 197:
/*     */         
/*     */         case 198:
/*     */         
/*     */         case 199:
/*     */         
/*     */         case 200:
/*     */         
/*     */         case 201:
/*     */         
/*     */         case 202:
/*     */         
/*     */         case 203:
/*     */         
/*     */         case 204:
/*     */         
/*     */         case 205:
/*     */         
/*     */         case 206:
/*     */         
/*     */         case 207:
/*     */         
/*     */         case 208:
/*     */         
/*     */         case 209:
/*     */         
/*     */         case 210:
/*     */         
/*     */         case 211:
/*     */         
/*     */         case 212:
/*     */         
/*     */         case 213:
/*     */         
/*     */         case 214:
/*     */         
/*     */         case 215:
/*     */         
/*     */         case 216:
/*     */         
/*     */         case 217:
/*     */         
/*     */         case 218:
/*     */         
/*     */         case 219:
/*     */         
/*     */         case 220:
/*     */         
/*     */         case 221:
/*     */         
/*     */         case 222:
/*     */         
/*     */         case 223:
/*     */         
/*     */         case 224:
/*     */         
/*     */         case 225:
/*     */         
/*     */         case 226:
/*     */         
/*     */         case 227:
/*     */         
/*     */         case 228:
/*     */         
/*     */         case 229:
/*     */         
/*     */         case 230:
/*     */         
/*     */         case 231:
/*     */         
/*     */         case 232:
/*     */         
/*     */         case 233:
/*     */         
/*     */         case 234:
/*     */         
/*     */         case 235:
/*     */         
/*     */         case 236:
/*     */         
/*     */         case 237:
/*     */         
/*     */         case 238:
/*     */         
/*     */         case 239:
/*     */         
/*     */         case 240:
/*     */         
/*     */         case 241:
/*     */         
/*     */         case 242:
/*     */         
/*     */         case 243:
/*     */         
/*     */         case 244:
/*     */         
/*     */         case 245:
/*     */         
/*     */         case 246:
/*     */         
/*     */         case 247:
/*     */         
/*     */         case 248:
/*     */         
/*     */         case 249:
/*     */         
/*     */         case 250:
/*     */         
/*     */         case 251:
/*     */         
/*     */         case 252:
/*     */         
/*     */         case 253:
/*     */         
/*     */         case 254:
/*     */         
/*     */         default:
/*     */           break;
/*     */       } 
/*     */       char c = '';
/*     */       int j = (paramInt2 & 0xFF) - c;
/*     */       if (j < 0)
/*     */         j += 256; 
/*     */       int m = ((paramInt2 & 0xFFFF) >>> 8) - c;
/*     */       if (m < 0)
/*     */         m += 256; 
/*     */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*     */         int n = b % 2;
/*     */         if (n == 0) {
/*     */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
/*     */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
/*     */         } else {
/*     */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ m);
/*     */           m = ((m >>> 3 | m << 5) ^ arrayOfChar[b]) & 0xFF;
/*     */         } 
/*     */       } 
/*     */       e[i] = (new String(arrayOfChar)).intern();
/*     */     } 
/*     */     return e[i];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\t.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */