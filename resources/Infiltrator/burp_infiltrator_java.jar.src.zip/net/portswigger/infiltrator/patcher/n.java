/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class n
/*     */ {
/*     */   private final t b;
/*     */   private final String a;
/*     */   private static final String[] c;
/*     */   private static final String[] d;
/*     */   
/*     */   n(k paramk, String paramString) {
/*  26 */     this.b = new t(paramk);
/*  27 */     this.a = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void a(String paramString, JarOutputStream paramJarOutputStream) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_3
/*     */     //   4: new java/util/jar/JarFile
/*     */     //   7: dup
/*     */     //   8: aload_1
/*     */     //   9: iconst_1
/*     */     //   10: invokespecial <init> : (Ljava/lang/String;Z)V
/*     */     //   13: astore #4
/*     */     //   15: aload #4
/*     */     //   17: invokevirtual entries : ()Ljava/util/Enumeration;
/*     */     //   20: astore #5
/*     */     //   22: aload #5
/*     */     //   24: invokeinterface hasMoreElements : ()Z
/*     */     //   29: ifeq -> 72
/*     */     //   32: aload #5
/*     */     //   34: invokeinterface nextElement : ()Ljava/lang/Object;
/*     */     //   39: checkcast java/util/jar/JarEntry
/*     */     //   42: astore #6
/*     */     //   44: aload_0
/*     */     //   45: aload_2
/*     */     //   46: aload #4
/*     */     //   48: aload #6
/*     */     //   50: invokevirtual getInputStream : (Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
/*     */     //   53: aload #6
/*     */     //   55: aload #4
/*     */     //   57: invokespecial a : (Ljava/util/jar/JarOutputStream;Ljava/io/InputStream;Ljava/util/jar/JarEntry;Ljava/util/jar/JarFile;)V
/*     */     //   60: iload_3
/*     */     //   61: ifne -> 77
/*     */     //   64: iload_3
/*     */     //   65: ifeq -> 22
/*     */     //   68: goto -> 72
/*     */     //   71: athrow
/*     */     //   72: aload #4
/*     */     //   74: invokevirtual close : ()V
/*     */     //   77: goto -> 155
/*     */     //   80: astore #4
/*     */     //   82: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*     */     //   85: new java/lang/StringBuffer
/*     */     //   88: dup
/*     */     //   89: invokespecial <init> : ()V
/*     */     //   92: sipush #25618
/*     */     //   95: sipush #7644
/*     */     //   98: invokestatic a : (II)Ljava/lang/String;
/*     */     //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   104: aload_1
/*     */     //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   108: ldc '.'
/*     */     //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   113: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   116: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   119: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*     */     //   122: new java/lang/StringBuffer
/*     */     //   125: dup
/*     */     //   126: invokespecial <init> : ()V
/*     */     //   129: sipush #25616
/*     */     //   132: sipush #9222
/*     */     //   135: invokestatic a : (II)Ljava/lang/String;
/*     */     //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   141: aload #4
/*     */     //   143: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   149: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   152: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   155: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #34	-> 4
/*     */     //   #36	-> 15
/*     */     //   #37	-> 22
/*     */     //   #39	-> 32
/*     */     //   #40	-> 44
/*     */     //   #41	-> 60
/*     */     //   #43	-> 72
/*     */     //   #49	-> 77
/*     */     //   #45	-> 80
/*     */     //   #47	-> 82
/*     */     //   #48	-> 119
/*     */     //   #50	-> 155
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	77	80	java/lang/Throwable
/*     */     //   44	68	71	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, InputStream paramInputStream, JarEntry paramJarEntry, JarFile paramJarFile) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore #5
/*     */     //   5: aload_1
/*     */     //   6: new java/util/jar/JarEntry
/*     */     //   9: dup
/*     */     //   10: aload_3
/*     */     //   11: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   14: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   17: invokevirtual putNextEntry : (Ljava/util/zip/ZipEntry;)V
/*     */     //   20: goto -> 62
/*     */     //   23: astore #6
/*     */     //   25: aload #6
/*     */     //   27: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   30: sipush #25623
/*     */     //   33: sipush #-11922
/*     */     //   36: invokestatic a : (II)Ljava/lang/String;
/*     */     //   39: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   42: iconst_m1
/*     */     //   43: if_icmpne -> 61
/*     */     //   46: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*     */     //   49: aload #6
/*     */     //   51: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   54: invokevirtual b : (Ljava/lang/String;)V
/*     */     //   57: goto -> 61
/*     */     //   60: athrow
/*     */     //   61: return
/*     */     //   62: aload_3
/*     */     //   63: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   66: sipush #25622
/*     */     //   69: sipush #-13054
/*     */     //   72: invokestatic a : (II)Ljava/lang/String;
/*     */     //   75: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   78: iload #5
/*     */     //   80: ifne -> 144
/*     */     //   83: ifeq -> 130
/*     */     //   86: goto -> 90
/*     */     //   89: athrow
/*     */     //   90: aload_0
/*     */     //   91: aload_3
/*     */     //   92: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   95: invokespecial a : (Ljava/lang/String;)Z
/*     */     //   98: iload #5
/*     */     //   100: ifne -> 144
/*     */     //   103: goto -> 107
/*     */     //   106: athrow
/*     */     //   107: ifeq -> 130
/*     */     //   110: goto -> 114
/*     */     //   113: athrow
/*     */     //   114: aload_0
/*     */     //   115: aload_1
/*     */     //   116: aload_2
/*     */     //   117: aload_3
/*     */     //   118: invokespecial a : (Ljava/util/jar/JarOutputStream;Ljava/io/InputStream;Ljava/util/jar/JarEntry;)V
/*     */     //   121: iload #5
/*     */     //   123: ifeq -> 255
/*     */     //   126: goto -> 130
/*     */     //   129: athrow
/*     */     //   130: getstatic net/portswigger/infiltrator/patcher/e.c : Ljava/util/List;
/*     */     //   133: aload_3
/*     */     //   134: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   137: invokestatic a : (Ljava/util/List;Ljava/lang/String;)Z
/*     */     //   140: goto -> 144
/*     */     //   143: athrow
/*     */     //   144: iload #5
/*     */     //   146: ifne -> 213
/*     */     //   149: ifeq -> 193
/*     */     //   152: goto -> 156
/*     */     //   155: athrow
/*     */     //   156: aload_0
/*     */     //   157: getfield b : Lnet/portswigger/infiltrator/patcher/t;
/*     */     //   160: getfield b : Lnet/portswigger/infiltrator/patcher/f;
/*     */     //   163: invokevirtual a : ()V
/*     */     //   166: aload_0
/*     */     //   167: aload_1
/*     */     //   168: aload_3
/*     */     //   169: aload #4
/*     */     //   171: invokespecial a : (Ljava/util/jar/JarOutputStream;Ljava/util/jar/JarEntry;Ljava/util/jar/JarFile;)V
/*     */     //   174: aload_0
/*     */     //   175: getfield b : Lnet/portswigger/infiltrator/patcher/t;
/*     */     //   178: getfield b : Lnet/portswigger/infiltrator/patcher/f;
/*     */     //   181: invokevirtual c : ()V
/*     */     //   184: iload #5
/*     */     //   186: ifeq -> 255
/*     */     //   189: goto -> 193
/*     */     //   192: athrow
/*     */     //   193: aload_3
/*     */     //   194: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   197: sipush #25620
/*     */     //   200: sipush #-25031
/*     */     //   203: invokestatic a : (II)Ljava/lang/String;
/*     */     //   206: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   209: goto -> 213
/*     */     //   212: athrow
/*     */     //   213: iload #5
/*     */     //   215: ifne -> 245
/*     */     //   218: ifeq -> 249
/*     */     //   221: goto -> 225
/*     */     //   224: athrow
/*     */     //   225: aload_3
/*     */     //   226: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   229: sipush #25630
/*     */     //   232: sipush #-2454
/*     */     //   235: invokestatic a : (II)Ljava/lang/String;
/*     */     //   238: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   241: goto -> 245
/*     */     //   244: athrow
/*     */     //   245: ifeq -> 249
/*     */     //   248: return
/*     */     //   249: aload_0
/*     */     //   250: aload_1
/*     */     //   251: aload_2
/*     */     //   252: invokespecial a : (Ljava/util/jar/JarOutputStream;Ljava/io/InputStream;)V
/*     */     //   255: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #56	-> 5
/*     */     //   #65	-> 20
/*     */     //   #58	-> 23
/*     */     //   #60	-> 25
/*     */     //   #62	-> 46
/*     */     //   #64	-> 61
/*     */     //   #67	-> 62
/*     */     //   #69	-> 114
/*     */     //   #71	-> 130
/*     */     //   #73	-> 156
/*     */     //   #74	-> 166
/*     */     //   #75	-> 174
/*     */     //   #80	-> 193
/*     */     //   #82	-> 248
/*     */     //   #85	-> 249
/*     */     //   #87	-> 255
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   5	20	23	java/util/zip/ZipException
/*     */     //   25	57	60	java/util/zip/ZipException
/*     */     //   62	86	89	java/util/zip/ZipException
/*     */     //   83	103	106	java/util/zip/ZipException
/*     */     //   90	110	113	java/util/zip/ZipException
/*     */     //   107	126	129	java/util/zip/ZipException
/*     */     //   114	140	143	java/util/zip/ZipException
/*     */     //   144	152	155	java/util/zip/ZipException
/*     */     //   149	189	192	java/util/zip/ZipException
/*     */     //   156	209	212	java/util/zip/ZipException
/*     */     //   213	221	224	java/util/zip/ZipException
/*     */     //   218	241	244	java/util/zip/ZipException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean a(String paramString) {
/*  91 */     boolean bool = w.e; try { if (!bool) try {  } catch (SecurityException securityException) { throw null; }   } catch (SecurityException securityException) { throw null; }  return (paramString.indexOf(a(25628, 23759)) == -1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, JarEntry paramJarEntry, JarFile paramJarFile) {
/*  96 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  97 */     JarOutputStream jarOutputStream = new JarOutputStream(byteArrayOutputStream);
/*     */     
/*  99 */     String str = s.a(this.a, 15);
/* 100 */     a(paramJarEntry, str, paramJarFile);
/* 101 */     a(str, jarOutputStream);
/*     */ 
/*     */     
/* 104 */     jarOutputStream.close();
/* 105 */     byteArrayOutputStream.close();
/* 106 */     paramJarOutputStream.write(byteArrayOutputStream.toByteArray());
/*     */ 
/*     */     
/*     */     try {
/* 110 */       (new File(str)).delete();
/*     */     }
/* 112 */     catch (SecurityException securityException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarEntry paramJarEntry, String paramString, JarFile paramJarFile) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aconst_null
/*     */     //   4: astore #5
/*     */     //   6: istore #4
/*     */     //   8: new java/util/jar/JarInputStream
/*     */     //   11: dup
/*     */     //   12: aload_3
/*     */     //   13: aload_1
/*     */     //   14: invokevirtual getInputStream : (Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
/*     */     //   17: invokespecial <init> : (Ljava/io/InputStream;)V
/*     */     //   20: astore #6
/*     */     //   22: aload_0
/*     */     //   23: aload_2
/*     */     //   24: aload #6
/*     */     //   26: invokespecial a : (Ljava/lang/String;Ljava/util/jar/JarInputStream;)Ljava/util/jar/JarOutputStream;
/*     */     //   29: astore #5
/*     */     //   31: aload #6
/*     */     //   33: invokevirtual getNextEntry : ()Ljava/util/zip/ZipEntry;
/*     */     //   36: checkcast java/util/jar/JarEntry
/*     */     //   39: dup
/*     */     //   40: astore #7
/*     */     //   42: ifnull -> 202
/*     */     //   45: iload #4
/*     */     //   47: ifne -> 258
/*     */     //   50: aload #7
/*     */     //   52: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   55: sipush #25620
/*     */     //   58: sipush #-25031
/*     */     //   61: invokestatic a : (II)Ljava/lang/String;
/*     */     //   64: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   67: iload #4
/*     */     //   69: ifne -> 141
/*     */     //   72: goto -> 76
/*     */     //   75: athrow
/*     */     //   76: ifeq -> 121
/*     */     //   79: goto -> 83
/*     */     //   82: athrow
/*     */     //   83: aload #7
/*     */     //   85: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   88: sipush #25630
/*     */     //   91: sipush #-2454
/*     */     //   94: invokestatic a : (II)Ljava/lang/String;
/*     */     //   97: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   100: iload #4
/*     */     //   102: ifne -> 141
/*     */     //   105: goto -> 109
/*     */     //   108: athrow
/*     */     //   109: ifeq -> 121
/*     */     //   112: goto -> 116
/*     */     //   115: athrow
/*     */     //   116: iload #4
/*     */     //   118: ifeq -> 31
/*     */     //   121: aload #5
/*     */     //   123: new java/util/jar/JarEntry
/*     */     //   126: dup
/*     */     //   127: aload #7
/*     */     //   129: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   132: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   135: invokevirtual putNextEntry : (Ljava/util/zip/ZipEntry;)V
/*     */     //   138: sipush #512
/*     */     //   141: newarray byte
/*     */     //   143: astore #9
/*     */     //   145: aload #6
/*     */     //   147: aload #9
/*     */     //   149: iconst_0
/*     */     //   150: aload #9
/*     */     //   152: arraylength
/*     */     //   153: invokevirtual read : ([BII)I
/*     */     //   156: dup
/*     */     //   157: istore #8
/*     */     //   159: iconst_m1
/*     */     //   160: if_icmpeq -> 187
/*     */     //   163: aload #5
/*     */     //   165: aload #9
/*     */     //   167: iconst_0
/*     */     //   168: iload #8
/*     */     //   170: invokevirtual write : ([BII)V
/*     */     //   173: iload #4
/*     */     //   175: ifne -> 192
/*     */     //   178: iload #4
/*     */     //   180: ifeq -> 145
/*     */     //   183: goto -> 187
/*     */     //   186: athrow
/*     */     //   187: aload #5
/*     */     //   189: invokevirtual closeEntry : ()V
/*     */     //   192: goto -> 31
/*     */     //   195: astore #8
/*     */     //   197: iload #4
/*     */     //   199: ifeq -> 31
/*     */     //   202: aload #5
/*     */     //   204: iload #4
/*     */     //   206: ifne -> 218
/*     */     //   209: ifnull -> 258
/*     */     //   212: goto -> 216
/*     */     //   215: athrow
/*     */     //   216: aload #5
/*     */     //   218: invokevirtual close : ()V
/*     */     //   221: goto -> 258
/*     */     //   224: astore #6
/*     */     //   226: goto -> 258
/*     */     //   229: astore #10
/*     */     //   231: aload #5
/*     */     //   233: iload #4
/*     */     //   235: ifne -> 247
/*     */     //   238: ifnull -> 255
/*     */     //   241: goto -> 245
/*     */     //   244: athrow
/*     */     //   245: aload #5
/*     */     //   247: invokevirtual close : ()V
/*     */     //   250: goto -> 255
/*     */     //   253: astore #11
/*     */     //   255: aload #10
/*     */     //   257: athrow
/*     */     //   258: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #119	-> 3
/*     */     //   #122	-> 8
/*     */     //   #124	-> 22
/*     */     //   #127	-> 31
/*     */     //   #132	-> 45
/*     */     //   #134	-> 116
/*     */     //   #138	-> 121
/*     */     //   #141	-> 138
/*     */     //   #142	-> 145
/*     */     //   #144	-> 163
/*     */     //   #147	-> 187
/*     */     //   #152	-> 192
/*     */     //   #149	-> 195
/*     */     //   #152	-> 197
/*     */     //   #157	-> 202
/*     */     //   #161	-> 216
/*     */     //   #165	-> 221
/*     */     //   #163	-> 224
/*     */     //   #165	-> 226
/*     */     //   #157	-> 229
/*     */     //   #161	-> 245
/*     */     //   #165	-> 250
/*     */     //   #163	-> 253
/*     */     //   #165	-> 255
/*     */     //   #168	-> 258
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   8	202	229	finally
/*     */     //   45	72	75	java/util/zip/ZipException
/*     */     //   45	116	195	java/util/zip/ZipException
/*     */     //   50	79	82	java/util/zip/ZipException
/*     */     //   76	105	108	java/util/zip/ZipException
/*     */     //   83	112	115	java/util/zip/ZipException
/*     */     //   121	192	195	java/util/zip/ZipException
/*     */     //   163	183	186	java/util/zip/ZipException
/*     */     //   202	212	215	java/util/zip/ZipException
/*     */     //   216	221	224	java/io/IOException
/*     */     //   229	231	229	finally
/*     */     //   231	241	244	java/util/zip/ZipException
/*     */     //   245	250	253	java/io/IOException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JarOutputStream a(String paramString, JarInputStream paramJarInputStream) {
/* 173 */     Manifest manifest = paramJarInputStream.getManifest(); boolean bool = w.e;
/* 174 */     if (manifest != null) {
/*     */       
/* 176 */       JarOutputStream jarOutputStream = new JarOutputStream(new FileOutputStream(paramString), manifest); if (bool)
/*     */       
/*     */       { 
/*     */         
/* 180 */         jarOutputStream = new JarOutputStream(new FileOutputStream(paramString));
/*     */         
/* 182 */         return jarOutputStream; }  return jarOutputStream;
/*     */     } 
/*     */     return new JarOutputStream(new FileOutputStream(paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, InputStream paramInputStream, JarEntry paramJarEntry) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore #4
/*     */     //   5: new net/portswigger/infiltrator/patcher/w
/*     */     //   8: dup
/*     */     //   9: aload_2
/*     */     //   10: aload_3
/*     */     //   11: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   14: invokespecial <init> : (Ljava/io/InputStream;Ljava/lang/String;)V
/*     */     //   17: new net/portswigger/infiltrator/patcher/d
/*     */     //   20: dup
/*     */     //   21: invokespecial <init> : ()V
/*     */     //   24: invokevirtual a : ()Ljava/util/List;
/*     */     //   27: invokevirtual a : (Ljava/util/List;)Lnet/portswigger/infiltrator/patcher/l;
/*     */     //   30: astore #5
/*     */     //   32: aload_1
/*     */     //   33: aload #5
/*     */     //   35: getfield c : [B
/*     */     //   38: invokevirtual write : ([B)V
/*     */     //   41: aload_0
/*     */     //   42: getfield b : Lnet/portswigger/infiltrator/patcher/t;
/*     */     //   45: aload #5
/*     */     //   47: aload_3
/*     */     //   48: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   51: aload_1
/*     */     //   52: invokevirtual a : (Lnet/portswigger/infiltrator/patcher/l;Ljava/lang/String;Ljava/util/jar/JarOutputStream;)V
/*     */     //   55: goto -> 201
/*     */     //   58: astore #5
/*     */     //   60: aload #5
/*     */     //   62: iload #4
/*     */     //   64: ifne -> 192
/*     */     //   67: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
/*     */     //   70: iconst_0
/*     */     //   71: aaload
/*     */     //   72: invokevirtual getClassName : ()Ljava/lang/String;
/*     */     //   75: sipush #25629
/*     */     //   78: sipush #-5923
/*     */     //   81: invokestatic a : (II)Ljava/lang/String;
/*     */     //   84: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   87: iconst_m1
/*     */     //   88: if_icmpeq -> 151
/*     */     //   91: goto -> 95
/*     */     //   94: athrow
/*     */     //   95: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*     */     //   98: new java/lang/StringBuffer
/*     */     //   101: dup
/*     */     //   102: invokespecial <init> : ()V
/*     */     //   105: sipush #25619
/*     */     //   108: sipush #31120
/*     */     //   111: invokestatic a : (II)Ljava/lang/String;
/*     */     //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   117: aload_3
/*     */     //   118: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   124: sipush #25617
/*     */     //   127: sipush #27077
/*     */     //   130: invokestatic a : (II)Ljava/lang/String;
/*     */     //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   136: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   139: invokevirtual a : (Ljava/lang/String;)V
/*     */     //   142: iload #4
/*     */     //   144: ifeq -> 195
/*     */     //   147: goto -> 151
/*     */     //   150: athrow
/*     */     //   151: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*     */     //   154: new java/lang/StringBuffer
/*     */     //   157: dup
/*     */     //   158: invokespecial <init> : ()V
/*     */     //   161: sipush #25621
/*     */     //   164: sipush #17091
/*     */     //   167: invokestatic a : (II)Ljava/lang/String;
/*     */     //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   173: aload_3
/*     */     //   174: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   180: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   183: invokevirtual a : (Ljava/lang/String;)V
/*     */     //   186: aload #5
/*     */     //   188: goto -> 192
/*     */     //   191: athrow
/*     */     //   192: invokevirtual printStackTrace : ()V
/*     */     //   195: aload_0
/*     */     //   196: aload_1
/*     */     //   197: aload_2
/*     */     //   198: invokespecial a : (Ljava/util/jar/JarOutputStream;Ljava/io/InputStream;)V
/*     */     //   201: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #189	-> 5
/*     */     //   #190	-> 32
/*     */     //   #192	-> 41
/*     */     //   #209	-> 55
/*     */     //   #194	-> 58
/*     */     //   #198	-> 60
/*     */     //   #200	-> 95
/*     */     //   #204	-> 151
/*     */     //   #205	-> 186
/*     */     //   #208	-> 195
/*     */     //   #210	-> 201
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   5	55	58	java/lang/Throwable
/*     */     //   60	91	94	java/lang/Throwable
/*     */     //   67	147	150	java/lang/Throwable
/*     */     //   95	188	191	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(JarOutputStream paramJarOutputStream, InputStream paramInputStream) {
/* 214 */     paramJarOutputStream.write(s.a(paramInputStream));
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: bipush #11
/*     */     //   2: anewarray java/lang/String
/*     */     //   5: astore #5
/*     */     //   7: iconst_0
/*     */     //   8: istore_3
/*     */     //   9: ldc '0ìÈ °G)9¿âÑ¶:äPGÊ+#]x¸÷\\bã§ý/b!\\t&óËÉºÙ¥·ÐÑãeYÍEßºj[ÏÂü=kß/p¦ê£71íÌsR\\bq\\r¢èâ=ioVMÔ]ýËp*ã\\n@T*ö\\b'¾hÝ?¬ôØ¥æÆý¬NÈBïßÜbpÜ_´é%\\n=öd>~Kvªd®¹m¶%¦+g?büg\\n¿$Þa¢Lö'
/*     */     //   11: dup
/*     */     //   12: astore_2
/*     */     //   13: invokevirtual length : ()I
/*     */     //   16: istore #4
/*     */     //   18: bipush #8
/*     */     //   20: istore_1
/*     */     //   21: iconst_m1
/*     */     //   22: istore_0
/*     */     //   23: iinc #0, 1
/*     */     //   26: aload_2
/*     */     //   27: iload_0
/*     */     //   28: dup
/*     */     //   29: iload_1
/*     */     //   30: iadd
/*     */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   34: jsr -> 137
/*     */     //   37: aload #5
/*     */     //   39: swap
/*     */     //   40: iload_3
/*     */     //   41: iinc #3, 1
/*     */     //   44: swap
/*     */     //   45: aastore
/*     */     //   46: iload_0
/*     */     //   47: iload_1
/*     */     //   48: iadd
/*     */     //   49: dup
/*     */     //   50: istore_0
/*     */     //   51: iload #4
/*     */     //   53: if_icmpge -> 65
/*     */     //   56: aload_2
/*     */     //   57: iload_0
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: istore_1
/*     */     //   62: goto -> 23
/*     */     //   65: ldc '>å\êaJï k"ð'
/*     */     //   67: dup
/*     */     //   68: astore_2
/*     */     //   69: invokevirtual length : ()I
/*     */     //   72: istore #4
/*     */     //   74: bipush #13
/*     */     //   76: istore_1
/*     */     //   77: iconst_m1
/*     */     //   78: istore_0
/*     */     //   79: iinc #0, 1
/*     */     //   82: aload_2
/*     */     //   83: iload_0
/*     */     //   84: dup
/*     */     //   85: iload_1
/*     */     //   86: iadd
/*     */     //   87: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   90: jsr -> 137
/*     */     //   93: aload #5
/*     */     //   95: swap
/*     */     //   96: iload_3
/*     */     //   97: iinc #3, 1
/*     */     //   100: swap
/*     */     //   101: aastore
/*     */     //   102: iload_0
/*     */     //   103: iload_1
/*     */     //   104: iadd
/*     */     //   105: dup
/*     */     //   106: istore_0
/*     */     //   107: iload #4
/*     */     //   109: if_icmpge -> 121
/*     */     //   112: aload_2
/*     */     //   113: iload_0
/*     */     //   114: invokevirtual charAt : (I)C
/*     */     //   117: istore_1
/*     */     //   118: goto -> 79
/*     */     //   121: aload #5
/*     */     //   123: putstatic net/portswigger/infiltrator/patcher/n.c : [Ljava/lang/String;
/*     */     //   126: bipush #11
/*     */     //   128: anewarray java/lang/String
/*     */     //   131: putstatic net/portswigger/infiltrator/patcher/n.d : [Ljava/lang/String;
/*     */     //   134: goto -> 275
/*     */     //   137: astore #6
/*     */     //   139: invokevirtual toCharArray : ()[C
/*     */     //   142: dup
/*     */     //   143: arraylength
/*     */     //   144: swap
/*     */     //   145: iconst_0
/*     */     //   146: istore #7
/*     */     //   148: swap
/*     */     //   149: dup_x1
/*     */     //   150: iconst_1
/*     */     //   151: if_icmpgt -> 253
/*     */     //   154: dup
/*     */     //   155: iload #7
/*     */     //   157: dup2
/*     */     //   158: caload
/*     */     //   159: iload #7
/*     */     //   161: bipush #7
/*     */     //   163: irem
/*     */     //   164: tableswitch default -> 235, 0 -> 204, 1 -> 209, 2 -> 214, 3 -> 219, 4 -> 224, 5 -> 229
/*     */     //   204: bipush #40
/*     */     //   206: goto -> 237
/*     */     //   209: bipush #19
/*     */     //   211: goto -> 237
/*     */     //   214: bipush #123
/*     */     //   216: goto -> 237
/*     */     //   219: bipush #83
/*     */     //   221: goto -> 237
/*     */     //   224: bipush #30
/*     */     //   226: goto -> 237
/*     */     //   229: sipush #250
/*     */     //   232: goto -> 237
/*     */     //   235: bipush #119
/*     */     //   237: ixor
/*     */     //   238: i2c
/*     */     //   239: castore
/*     */     //   240: iinc #7, 1
/*     */     //   243: swap
/*     */     //   244: dup_x1
/*     */     //   245: ifne -> 253
/*     */     //   248: dup2
/*     */     //   249: swap
/*     */     //   250: goto -> 157
/*     */     //   253: swap
/*     */     //   254: dup_x1
/*     */     //   255: iload #7
/*     */     //   257: if_icmpgt -> 154
/*     */     //   260: new java/lang/String
/*     */     //   263: dup_x1
/*     */     //   264: swap
/*     */     //   265: invokespecial <init> : ([C)V
/*     */     //   268: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   271: swap
/*     */     //   272: pop
/*     */     //   273: ret #6
/*     */     //   275: return
/*     */   }
/*     */   
/*     */   private static String a(int paramInt1, int paramInt2) {
/*     */     int i = (paramInt1 ^ 0x6414) & 0xFFFF;
/*     */     if (d[i] == null) {
/*     */       char[] arrayOfChar = c[i].toCharArray();
/*     */       switch (arrayOfChar[0] & 0xFF) {
/*     */         case 0:
/*     */         
/*     */         case 1:
/*     */         
/*     */         case 2:
/*     */         
/*     */         case 3:
/*     */         
/*     */         case 4:
/*     */         
/*     */         case 5:
/*     */         
/*     */         case 6:
/*     */         
/*     */         case 7:
/*     */         
/*     */         case 8:
/*     */         
/*     */         case 9:
/*     */         
/*     */         case 10:
/*     */         
/*     */         case 11:
/*     */         
/*     */         case 12:
/*     */         
/*     */         case 13:
/*     */         
/*     */         case 14:
/*     */         
/*     */         case 15:
/*     */         
/*     */         case 16:
/*     */         
/*     */         case 17:
/*     */         
/*     */         case 18:
/*     */         
/*     */         case 19:
/*     */         
/*     */         case 20:
/*     */         
/*     */         case 21:
/*     */         
/*     */         case 22:
/*     */         
/*     */         case 23:
/*     */         
/*     */         case 24:
/*     */         
/*     */         case 25:
/*     */         
/*     */         case 26:
/*     */         
/*     */         case 27:
/*     */         
/*     */         case 28:
/*     */         
/*     */         case 29:
/*     */         
/*     */         case 30:
/*     */         
/*     */         case 31:
/*     */         
/*     */         case 32:
/*     */         
/*     */         case 33:
/*     */         
/*     */         case 34:
/*     */         
/*     */         case 35:
/*     */         
/*     */         case 36:
/*     */         
/*     */         case 37:
/*     */         
/*     */         case 38:
/*     */         
/*     */         case 39:
/*     */         
/*     */         case 40:
/*     */         
/*     */         case 41:
/*     */         
/*     */         case 42:
/*     */         
/*     */         case 43:
/*     */         
/*     */         case 44:
/*     */         
/*     */         case 45:
/*     */         
/*     */         case 46:
/*     */         
/*     */         case 47:
/*     */         
/*     */         case 48:
/*     */         
/*     */         case 49:
/*     */         
/*     */         case 50:
/*     */         
/*     */         case 51:
/*     */         
/*     */         case 52:
/*     */         
/*     */         case 53:
/*     */         
/*     */         case 54:
/*     */         
/*     */         case 55:
/*     */         
/*     */         case 56:
/*     */         
/*     */         case 57:
/*     */         
/*     */         case 58:
/*     */         
/*     */         case 59:
/*     */         
/*     */         case 60:
/*     */         
/*     */         case 61:
/*     */         
/*     */         case 62:
/*     */         
/*     */         case 63:
/*     */         
/*     */         case 64:
/*     */         
/*     */         case 65:
/*     */         
/*     */         case 66:
/*     */         
/*     */         case 67:
/*     */         
/*     */         case 68:
/*     */         
/*     */         case 69:
/*     */         
/*     */         case 70:
/*     */         
/*     */         case 71:
/*     */         
/*     */         case 72:
/*     */         
/*     */         case 73:
/*     */         
/*     */         case 74:
/*     */         
/*     */         case 75:
/*     */         
/*     */         case 76:
/*     */         
/*     */         case 77:
/*     */         
/*     */         case 78:
/*     */         
/*     */         case 79:
/*     */         
/*     */         case 80:
/*     */         
/*     */         case 81:
/*     */         
/*     */         case 82:
/*     */         
/*     */         case 83:
/*     */         
/*     */         case 84:
/*     */         
/*     */         case 85:
/*     */         
/*     */         case 86:
/*     */         
/*     */         case 87:
/*     */         
/*     */         case 88:
/*     */         
/*     */         case 89:
/*     */         
/*     */         case 90:
/*     */         
/*     */         case 91:
/*     */         
/*     */         case 92:
/*     */         
/*     */         case 93:
/*     */         
/*     */         case 94:
/*     */         
/*     */         case 95:
/*     */         
/*     */         case 96:
/*     */         
/*     */         case 97:
/*     */         
/*     */         case 98:
/*     */         
/*     */         case 99:
/*     */         
/*     */         case 100:
/*     */         
/*     */         case 101:
/*     */         
/*     */         case 102:
/*     */         
/*     */         case 103:
/*     */         
/*     */         case 104:
/*     */         
/*     */         case 105:
/*     */         
/*     */         case 106:
/*     */         
/*     */         case 107:
/*     */         
/*     */         case 108:
/*     */         
/*     */         case 109:
/*     */         
/*     */         case 110:
/*     */         
/*     */         case 111:
/*     */         
/*     */         case 112:
/*     */         
/*     */         case 113:
/*     */         
/*     */         case 114:
/*     */         
/*     */         case 115:
/*     */         
/*     */         case 116:
/*     */         
/*     */         case 117:
/*     */         
/*     */         case 118:
/*     */         
/*     */         case 119:
/*     */         
/*     */         case 120:
/*     */         
/*     */         case 121:
/*     */         
/*     */         case 122:
/*     */         
/*     */         case 123:
/*     */         
/*     */         case 124:
/*     */         
/*     */         case 125:
/*     */         
/*     */         case 126:
/*     */         
/*     */         case 127:
/*     */         
/*     */         case 128:
/*     */         
/*     */         case 129:
/*     */         
/*     */         case 130:
/*     */         
/*     */         case 131:
/*     */         
/*     */         case 132:
/*     */         
/*     */         case 133:
/*     */         
/*     */         case 134:
/*     */         
/*     */         case 135:
/*     */         
/*     */         case 136:
/*     */         
/*     */         case 137:
/*     */         
/*     */         case 138:
/*     */         
/*     */         case 139:
/*     */         
/*     */         case 140:
/*     */         
/*     */         case 141:
/*     */         
/*     */         case 142:
/*     */         
/*     */         case 143:
/*     */         
/*     */         case 144:
/*     */         
/*     */         case 145:
/*     */         
/*     */         case 146:
/*     */         
/*     */         case 147:
/*     */         
/*     */         case 148:
/*     */         
/*     */         case 149:
/*     */         
/*     */         case 150:
/*     */         
/*     */         case 151:
/*     */         
/*     */         case 152:
/*     */         
/*     */         case 153:
/*     */         
/*     */         case 154:
/*     */         
/*     */         case 155:
/*     */         
/*     */         case 156:
/*     */         
/*     */         case 157:
/*     */         
/*     */         case 158:
/*     */         
/*     */         case 159:
/*     */         
/*     */         case 160:
/*     */         
/*     */         case 161:
/*     */         
/*     */         case 162:
/*     */         
/*     */         case 163:
/*     */         
/*     */         case 164:
/*     */         
/*     */         case 165:
/*     */         
/*     */         case 166:
/*     */         
/*     */         case 167:
/*     */         
/*     */         case 168:
/*     */         
/*     */         case 169:
/*     */         
/*     */         case 170:
/*     */         
/*     */         case 171:
/*     */         
/*     */         case 172:
/*     */         
/*     */         case 173:
/*     */         
/*     */         case 174:
/*     */         
/*     */         case 175:
/*     */         
/*     */         case 176:
/*     */         
/*     */         case 177:
/*     */         
/*     */         case 178:
/*     */         
/*     */         case 179:
/*     */         
/*     */         case 180:
/*     */         
/*     */         case 181:
/*     */         
/*     */         case 182:
/*     */         
/*     */         case 183:
/*     */         
/*     */         case 184:
/*     */         
/*     */         case 185:
/*     */         
/*     */         case 186:
/*     */         
/*     */         case 187:
/*     */         
/*     */         case 188:
/*     */         
/*     */         case 189:
/*     */         
/*     */         case 190:
/*     */         
/*     */         case 191:
/*     */         
/*     */         case 192:
/*     */         
/*     */         case 193:
/*     */         
/*     */         case 194:
/*     */         
/*     */         case 195:
/*     */         
/*     */         case 196:
/*     */         
/*     */         case 197:
/*     */         
/*     */         case 198:
/*     */         
/*     */         case 199:
/*     */         
/*     */         case 200:
/*     */         
/*     */         case 201:
/*     */         
/*     */         case 202:
/*     */         
/*     */         case 203:
/*     */         
/*     */         case 204:
/*     */         
/*     */         case 205:
/*     */         
/*     */         case 206:
/*     */         
/*     */         case 207:
/*     */         
/*     */         case 208:
/*     */         
/*     */         case 209:
/*     */         
/*     */         case 210:
/*     */         
/*     */         case 211:
/*     */         
/*     */         case 212:
/*     */         
/*     */         case 213:
/*     */         
/*     */         case 214:
/*     */         
/*     */         case 215:
/*     */         
/*     */         case 216:
/*     */         
/*     */         case 217:
/*     */         
/*     */         case 218:
/*     */         
/*     */         case 219:
/*     */         
/*     */         case 220:
/*     */         
/*     */         case 221:
/*     */         
/*     */         case 222:
/*     */         
/*     */         case 223:
/*     */         
/*     */         case 224:
/*     */         
/*     */         case 225:
/*     */         
/*     */         case 226:
/*     */         
/*     */         case 227:
/*     */         
/*     */         case 228:
/*     */         
/*     */         case 229:
/*     */         
/*     */         case 230:
/*     */         
/*     */         case 231:
/*     */         
/*     */         case 232:
/*     */         
/*     */         case 233:
/*     */         
/*     */         case 234:
/*     */         
/*     */         case 235:
/*     */         
/*     */         case 236:
/*     */         
/*     */         case 237:
/*     */         
/*     */         case 238:
/*     */         
/*     */         case 239:
/*     */         
/*     */         case 240:
/*     */         
/*     */         case 241:
/*     */         
/*     */         case 242:
/*     */         
/*     */         case 243:
/*     */         
/*     */         case 244:
/*     */         
/*     */         case 245:
/*     */         
/*     */         case 246:
/*     */         
/*     */         case 247:
/*     */         
/*     */         case 248:
/*     */         
/*     */         case 249:
/*     */         
/*     */         case 250:
/*     */         
/*     */         case 251:
/*     */         
/*     */         case 252:
/*     */         
/*     */         case 253:
/*     */         
/*     */         case 254:
/*     */         
/*     */         default:
/*     */           break;
/*     */       } 
/*     */       byte b1 = 80;
/*     */       int j = (paramInt2 & 0xFF) - b1;
/*     */       if (j < 0)
/*     */         j += 256; 
/*     */       int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
/*     */       if (k < 0)
/*     */         k += 256; 
/*     */       for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*     */         int m = b2 % 2;
/*     */         if (m == 0) {
/*     */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
/*     */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
/*     */         } else {
/*     */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
/*     */           k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
/*     */         } 
/*     */       } 
/*     */       d[i] = (new String(arrayOfChar)).intern();
/*     */     } 
/*     */     return d[i];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\n.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */