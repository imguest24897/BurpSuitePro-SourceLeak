/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class l
/*    */ {
/*    */   final String b;
/*    */   final byte[] c;
/*    */   public final String a;
/*    */   private static final String d;
/*    */   
/*    */   l(String paramString1, byte[] paramArrayOfbyte, String paramString2) {
/* 16 */     this.b = paramString1;
/* 17 */     this.c = paramArrayOfbyte;
/* 18 */     this.a = paramString2;
/*    */   }
/*    */   
/*    */   void a(String paramString) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: aconst_null
/*    */     //   4: astore_3
/*    */     //   5: istore_2
/*    */     //   6: new java/io/File
/*    */     //   9: dup
/*    */     //   10: new java/io/File
/*    */     //   13: dup
/*    */     //   14: aload_1
/*    */     //   15: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   18: invokevirtual getParent : ()Ljava/lang/String;
/*    */     //   21: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   24: invokevirtual exists : ()Z
/*    */     //   27: iload_2
/*    */     //   28: ifne -> 63
/*    */     //   31: ifne -> 105
/*    */     //   34: goto -> 38
/*    */     //   37: athrow
/*    */     //   38: new java/io/File
/*    */     //   41: dup
/*    */     //   42: new java/io/File
/*    */     //   45: dup
/*    */     //   46: aload_1
/*    */     //   47: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   50: invokevirtual getParent : ()Ljava/lang/String;
/*    */     //   53: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   56: invokevirtual mkdirs : ()Z
/*    */     //   59: goto -> 63
/*    */     //   62: athrow
/*    */     //   63: ifne -> 105
/*    */     //   66: new java/io/IOException
/*    */     //   69: dup
/*    */     //   70: new java/lang/StringBuffer
/*    */     //   73: dup
/*    */     //   74: invokespecial <init> : ()V
/*    */     //   77: getstatic net/portswigger/infiltrator/patcher/l.d : Ljava/lang/String;
/*    */     //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   83: new java/io/File
/*    */     //   86: dup
/*    */     //   87: aload_1
/*    */     //   88: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   91: invokevirtual getParent : ()Ljava/lang/String;
/*    */     //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   97: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   100: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   103: athrow
/*    */     //   104: athrow
/*    */     //   105: new java/io/FileOutputStream
/*    */     //   108: dup
/*    */     //   109: new java/io/File
/*    */     //   112: dup
/*    */     //   113: aload_1
/*    */     //   114: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   117: invokespecial <init> : (Ljava/io/File;)V
/*    */     //   120: astore_3
/*    */     //   121: aload_3
/*    */     //   122: aload_0
/*    */     //   123: getfield c : [B
/*    */     //   126: invokevirtual write : ([B)V
/*    */     //   129: aload_3
/*    */     //   130: iload_2
/*    */     //   131: ifne -> 138
/*    */     //   134: ifnull -> 175
/*    */     //   137: aload_3
/*    */     //   138: invokevirtual close : ()V
/*    */     //   141: goto -> 175
/*    */     //   144: astore #4
/*    */     //   146: goto -> 175
/*    */     //   149: astore #5
/*    */     //   151: aload_3
/*    */     //   152: iload_2
/*    */     //   153: ifne -> 164
/*    */     //   156: ifnull -> 172
/*    */     //   159: goto -> 163
/*    */     //   162: athrow
/*    */     //   163: aload_3
/*    */     //   164: invokevirtual close : ()V
/*    */     //   167: goto -> 172
/*    */     //   170: astore #6
/*    */     //   172: aload #5
/*    */     //   174: athrow
/*    */     //   175: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #23	-> 3
/*    */     //   #26	-> 6
/*    */     //   #28	-> 38
/*    */     //   #30	-> 66
/*    */     //   #34	-> 105
/*    */     //   #35	-> 121
/*    */     //   #39	-> 129
/*    */     //   #43	-> 137
/*    */     //   #47	-> 141
/*    */     //   #45	-> 144
/*    */     //   #47	-> 146
/*    */     //   #39	-> 149
/*    */     //   #43	-> 163
/*    */     //   #47	-> 167
/*    */     //   #45	-> 170
/*    */     //   #47	-> 172
/*    */     //   #50	-> 175
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   6	34	37	java/io/IOException
/*    */     //   6	129	149	finally
/*    */     //   31	59	62	java/io/IOException
/*    */     //   63	104	104	java/io/IOException
/*    */     //   137	141	144	java/io/IOException
/*    */     //   149	151	149	finally
/*    */     //   151	159	162	java/io/IOException
/*    */     //   163	167	170	java/io/IOException
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: ldc ' ºâ \\f¡·¶A°·­V ¡ø½'
/*    */     //   2: jsr -> 11
/*    */     //   5: putstatic net/portswigger/infiltrator/patcher/l.d : Ljava/lang/String;
/*    */     //   8: goto -> 144
/*    */     //   11: astore_0
/*    */     //   12: invokevirtual toCharArray : ()[C
/*    */     //   15: dup
/*    */     //   16: arraylength
/*    */     //   17: swap
/*    */     //   18: iconst_0
/*    */     //   19: istore_1
/*    */     //   20: swap
/*    */     //   21: dup_x1
/*    */     //   22: iconst_1
/*    */     //   23: if_icmpgt -> 123
/*    */     //   26: dup
/*    */     //   27: iload_1
/*    */     //   28: dup2
/*    */     //   29: caload
/*    */     //   30: iload_1
/*    */     //   31: bipush #7
/*    */     //   33: irem
/*    */     //   34: tableswitch default -> 105, 0 -> 72, 1 -> 77, 2 -> 83, 3 -> 89, 4 -> 94, 5 -> 100
/*    */     //   72: bipush #99
/*    */     //   74: goto -> 107
/*    */     //   77: sipush #213
/*    */     //   80: goto -> 107
/*    */     //   83: sipush #151
/*    */     //   86: goto -> 107
/*    */     //   89: bipush #98
/*    */     //   91: goto -> 107
/*    */     //   94: sipush #196
/*    */     //   97: goto -> 107
/*    */     //   100: bipush #36
/*    */     //   102: goto -> 107
/*    */     //   105: bipush #106
/*    */     //   107: ixor
/*    */     //   108: i2c
/*    */     //   109: castore
/*    */     //   110: iinc #1, 1
/*    */     //   113: swap
/*    */     //   114: dup_x1
/*    */     //   115: ifne -> 123
/*    */     //   118: dup2
/*    */     //   119: swap
/*    */     //   120: goto -> 28
/*    */     //   123: swap
/*    */     //   124: dup_x1
/*    */     //   125: iload_1
/*    */     //   126: if_icmpgt -> 26
/*    */     //   129: new java/lang/String
/*    */     //   132: dup_x1
/*    */     //   133: swap
/*    */     //   134: invokespecial <init> : ([C)V
/*    */     //   137: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   140: swap
/*    */     //   141: pop
/*    */     //   142: ret #0
/*    */     //   144: return
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\l.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */