/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class p
/*     */   extends MethodVisitor
/*     */ {
/*     */   private final List c;
/*     */   private final List a;
/* 116 */   private final List d = new ArrayList();
/*     */   private int e;
/*     */   private static final String f;
/*     */   
/*     */   p(MethodVisitor paramMethodVisitor, List paramList1, List paramList2) {
/* 121 */     super(327680, paramMethodVisitor);
/* 122 */     this.c = paramList1;
/* 123 */     this.a = paramList2;
/* 124 */     paramList2.add(new ArrayList());
/*     */   }
/*     */   
/*     */   public void visitTypeInsn(int paramInt, String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_0
/*     */     //   4: iload_1
/*     */     //   5: aload_2
/*     */     //   6: invokespecial visitTypeInsn : (ILjava/lang/String;)V
/*     */     //   9: istore_3
/*     */     //   10: iload_1
/*     */     //   11: iload_3
/*     */     //   12: ifne -> 22
/*     */     //   15: sipush #187
/*     */     //   18: if_icmpne -> 136
/*     */     //   21: iconst_0
/*     */     //   22: istore #4
/*     */     //   24: iload #4
/*     */     //   26: aload_0
/*     */     //   27: getfield c : Ljava/util/List;
/*     */     //   30: invokeinterface size : ()I
/*     */     //   35: if_icmpge -> 126
/*     */     //   38: aload_0
/*     */     //   39: getfield c : Ljava/util/List;
/*     */     //   42: iload #4
/*     */     //   44: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   49: checkcast net/portswigger/infiltrator/patcher/b
/*     */     //   52: astore #5
/*     */     //   54: iload_3
/*     */     //   55: ifne -> 136
/*     */     //   58: iload_3
/*     */     //   59: ifne -> 122
/*     */     //   62: aload_2
/*     */     //   63: aload #5
/*     */     //   65: getfield c : Ljava/lang/String;
/*     */     //   68: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   71: ifeq -> 119
/*     */     //   74: aload #5
/*     */     //   76: getfield f : Ljava/lang/String;
/*     */     //   79: getstatic net/portswigger/infiltrator/patcher/p.f : Ljava/lang/String;
/*     */     //   82: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   85: iload_3
/*     */     //   86: ifne -> 114
/*     */     //   89: ifeq -> 119
/*     */     //   92: aload_0
/*     */     //   93: getfield d : Ljava/util/List;
/*     */     //   96: new java/lang/Integer
/*     */     //   99: dup
/*     */     //   100: aload_0
/*     */     //   101: getfield e : I
/*     */     //   104: iconst_1
/*     */     //   105: iadd
/*     */     //   106: invokespecial <init> : (I)V
/*     */     //   109: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   114: pop
/*     */     //   115: iload_3
/*     */     //   116: ifeq -> 126
/*     */     //   119: iinc #4, 1
/*     */     //   122: iload_3
/*     */     //   123: ifeq -> 24
/*     */     //   126: aload_0
/*     */     //   127: dup
/*     */     //   128: getfield e : I
/*     */     //   131: iconst_1
/*     */     //   132: iadd
/*     */     //   133: putfield e : I
/*     */     //   136: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #129	-> 3
/*     */     //   #130	-> 9
/*     */     //   #132	-> 21
/*     */     //   #134	-> 38
/*     */     //   #135	-> 54
/*     */     //   #137	-> 92
/*     */     //   #138	-> 115
/*     */     //   #132	-> 119
/*     */     //   #141	-> 126
/*     */     //   #143	-> 136
/*     */   }
/*     */   
/*     */   public void visitMethodInsn(int paramInt, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_0
/*     */     //   4: iload_1
/*     */     //   5: aload_2
/*     */     //   6: aload_3
/*     */     //   7: aload #4
/*     */     //   9: iload #5
/*     */     //   11: invokespecial visitMethodInsn : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
/*     */     //   14: istore #6
/*     */     //   16: iload_1
/*     */     //   17: iload #6
/*     */     //   19: ifne -> 30
/*     */     //   22: sipush #183
/*     */     //   25: if_icmpeq -> 29
/*     */     //   28: return
/*     */     //   29: iconst_0
/*     */     //   30: istore #7
/*     */     //   32: iload #7
/*     */     //   34: aload_0
/*     */     //   35: getfield c : Ljava/util/List;
/*     */     //   38: invokeinterface size : ()I
/*     */     //   43: if_icmpge -> 173
/*     */     //   46: aload_0
/*     */     //   47: getfield c : Ljava/util/List;
/*     */     //   50: iload #7
/*     */     //   52: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   57: checkcast net/portswigger/infiltrator/patcher/b
/*     */     //   60: astore #8
/*     */     //   62: iload #6
/*     */     //   64: ifne -> 168
/*     */     //   67: aload #8
/*     */     //   69: aload_2
/*     */     //   70: aload_3
/*     */     //   71: aload #4
/*     */     //   73: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
/*     */     //   76: ifeq -> 165
/*     */     //   79: aload_0
/*     */     //   80: getfield d : Ljava/util/List;
/*     */     //   83: iload #6
/*     */     //   85: ifne -> 121
/*     */     //   88: invokeinterface size : ()I
/*     */     //   93: ifne -> 101
/*     */     //   96: iload #6
/*     */     //   98: ifeq -> 173
/*     */     //   101: aload_0
/*     */     //   102: getfield d : Ljava/util/List;
/*     */     //   105: aload_0
/*     */     //   106: getfield d : Ljava/util/List;
/*     */     //   109: invokeinterface size : ()I
/*     */     //   114: iconst_1
/*     */     //   115: isub
/*     */     //   116: invokeinterface remove : (I)Ljava/lang/Object;
/*     */     //   121: checkcast java/lang/Integer
/*     */     //   124: checkcast java/lang/Integer
/*     */     //   127: astore #9
/*     */     //   129: aload_0
/*     */     //   130: getfield a : Ljava/util/List;
/*     */     //   133: aload_0
/*     */     //   134: getfield a : Ljava/util/List;
/*     */     //   137: invokeinterface size : ()I
/*     */     //   142: iconst_1
/*     */     //   143: isub
/*     */     //   144: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   149: checkcast java/util/List
/*     */     //   152: aload #9
/*     */     //   154: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   159: pop
/*     */     //   160: iload #6
/*     */     //   162: ifeq -> 173
/*     */     //   165: iinc #7, 1
/*     */     //   168: iload #6
/*     */     //   170: ifeq -> 32
/*     */     //   173: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #147	-> 3
/*     */     //   #148	-> 16
/*     */     //   #150	-> 28
/*     */     //   #153	-> 29
/*     */     //   #155	-> 46
/*     */     //   #156	-> 62
/*     */     //   #158	-> 79
/*     */     //   #160	-> 96
/*     */     //   #162	-> 101
/*     */     //   #163	-> 129
/*     */     //   #164	-> 160
/*     */     //   #153	-> 165
/*     */     //   #167	-> 173
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: ldc 't:6!Ù'
/*     */     //   2: jsr -> 11
/*     */     //   5: putstatic net/portswigger/infiltrator/patcher/p.f : Ljava/lang/String;
/*     */     //   8: goto -> 144
/*     */     //   11: astore_0
/*     */     //   12: invokevirtual toCharArray : ()[C
/*     */     //   15: dup
/*     */     //   16: arraylength
/*     */     //   17: swap
/*     */     //   18: iconst_0
/*     */     //   19: istore_1
/*     */     //   20: swap
/*     */     //   21: dup_x1
/*     */     //   22: iconst_1
/*     */     //   23: if_icmpgt -> 123
/*     */     //   26: dup
/*     */     //   27: iload_1
/*     */     //   28: dup2
/*     */     //   29: caload
/*     */     //   30: iload_1
/*     */     //   31: bipush #7
/*     */     //   33: irem
/*     */     //   34: tableswitch default -> 104, 0 -> 72, 1 -> 77, 2 -> 82, 3 -> 87, 4 -> 93, 5 -> 98
/*     */     //   72: bipush #72
/*     */     //   74: goto -> 107
/*     */     //   77: bipush #83
/*     */     //   79: goto -> 107
/*     */     //   82: bipush #88
/*     */     //   84: goto -> 107
/*     */     //   87: sipush #247
/*     */     //   90: goto -> 107
/*     */     //   93: bipush #85
/*     */     //   95: goto -> 107
/*     */     //   98: sipush #231
/*     */     //   101: goto -> 107
/*     */     //   104: sipush #241
/*     */     //   107: ixor
/*     */     //   108: i2c
/*     */     //   109: castore
/*     */     //   110: iinc #1, 1
/*     */     //   113: swap
/*     */     //   114: dup_x1
/*     */     //   115: ifne -> 123
/*     */     //   118: dup2
/*     */     //   119: swap
/*     */     //   120: goto -> 28
/*     */     //   123: swap
/*     */     //   124: dup_x1
/*     */     //   125: iload_1
/*     */     //   126: if_icmpgt -> 26
/*     */     //   129: new java/lang/String
/*     */     //   132: dup_x1
/*     */     //   133: swap
/*     */     //   134: invokespecial <init> : ([C)V
/*     */     //   137: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   140: swap
/*     */     //   141: pop
/*     */     //   142: ret #0
/*     */     //   144: return
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\p.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */