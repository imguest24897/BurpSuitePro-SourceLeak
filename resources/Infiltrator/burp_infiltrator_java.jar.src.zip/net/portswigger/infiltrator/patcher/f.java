/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Stack;
/*    */ 
/*    */ public class f
/*    */ {
/*  9 */   final Stack a = new Stack();
/*    */ 
/*    */   
/*    */   public f() {
/* 13 */     this.a.push(new HashSet());
/*    */   }
/*    */ 
/*    */   
/*    */   public void a() {
/* 18 */     this.a.push(new HashSet());
/*    */   }
/*    */ 
/*    */   
/*    */   public void c() {
/* 23 */     this.a.pop();
/*    */   }
/*    */ 
/*    */   
/*    */   Iterator b() {
/* 28 */     return ((HashSet)this.a.peek()).iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   boolean a(String paramString) {
/* 33 */     return ((HashSet)this.a.peek()).add(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\f.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */