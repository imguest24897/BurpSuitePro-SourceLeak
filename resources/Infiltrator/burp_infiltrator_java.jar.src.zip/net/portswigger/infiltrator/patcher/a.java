/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class a
/*     */ {
/*  15 */   private final f a = new f(); private final k b; static Class c;
/*     */   private static final String[] d;
/*     */   private static final String[] e;
/*     */   
/*     */   public a(k paramk) {
/*  20 */     this.b = paramk;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(l paraml, String paramString) {
/*  25 */     String str1 = paraml.a.replaceAll(a(-29496, -26606), "/");
/*  26 */     boolean bool = w.e; if (!bool) if (paramString.indexOf(str1) != -1) {  }
/*     */       else { return; }
/*  28 */         String str2 = paramString;
/*  29 */     if (!bool) if (this.a.a(str2))
/*     */       
/*  31 */       { c(str2); } else { return; }
/*  32 */         a(str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(String paramString) {
/*  39 */     boolean bool = w.e; if (!bool) if (c == null) {  } else {  }   a(paramString + "/" + c.getPackage().getName().replaceAll(a(-29496, -26606), "/") + "/", this.b.a().getBytes(), a(-29492, -20177)); } static Class d(String paramString) { try { return Class.forName(org.objectweb.asm.a.a(paramString)); } catch (ClassNotFoundException classNotFoundException) { throw (new NoClassDefFoundError()).initCause(classNotFoundException); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void c(String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_0
/*     */     //   4: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   7: sipush #-29493
/*     */     //   10: sipush #-22529
/*     */     //   13: invokestatic a : (II)Ljava/lang/String;
/*     */     //   16: invokevirtual getResourceAsStream : (Ljava/lang/String;)Ljava/io/InputStream;
/*     */     //   19: astore_3
/*     */     //   20: istore_2
/*     */     //   21: iload_2
/*     */     //   22: ifne -> 52
/*     */     //   25: aload_3
/*     */     //   26: ifnonnull -> 53
/*     */     //   29: goto -> 33
/*     */     //   32: athrow
/*     */     //   33: getstatic net/portswigger/infiltrator/patcher/j.a : Lnet/portswigger/infiltrator/patcher/j;
/*     */     //   36: sipush #-29495
/*     */     //   39: sipush #30256
/*     */     //   42: invokestatic a : (II)Ljava/lang/String;
/*     */     //   45: invokevirtual b : (Ljava/lang/String;)V
/*     */     //   48: goto -> 52
/*     */     //   51: athrow
/*     */     //   52: return
/*     */     //   53: new java/util/zip/ZipInputStream
/*     */     //   56: dup
/*     */     //   57: aload_3
/*     */     //   58: invokespecial <init> : (Ljava/io/InputStream;)V
/*     */     //   61: astore #4
/*     */     //   63: aload #4
/*     */     //   65: invokevirtual getNextEntry : ()Ljava/util/zip/ZipEntry;
/*     */     //   68: dup
/*     */     //   69: astore #5
/*     */     //   71: ifnull -> 129
/*     */     //   74: iload_2
/*     */     //   75: ifne -> 138
/*     */     //   78: aload #5
/*     */     //   80: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   83: sipush #-29494
/*     */     //   86: sipush #-2451
/*     */     //   89: invokestatic a : (II)Ljava/lang/String;
/*     */     //   92: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   95: ifne -> 110
/*     */     //   98: goto -> 102
/*     */     //   101: athrow
/*     */     //   102: iload_2
/*     */     //   103: ifeq -> 63
/*     */     //   106: goto -> 110
/*     */     //   109: athrow
/*     */     //   110: aload_0
/*     */     //   111: aload_1
/*     */     //   112: aload #4
/*     */     //   114: invokestatic a : (Ljava/io/InputStream;)[B
/*     */     //   117: aload #5
/*     */     //   119: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   122: invokespecial a : (Ljava/lang/String;[BLjava/lang/String;)V
/*     */     //   125: iload_2
/*     */     //   126: ifeq -> 63
/*     */     //   129: aload_3
/*     */     //   130: invokevirtual close : ()V
/*     */     //   133: aload #4
/*     */     //   135: invokevirtual close : ()V
/*     */     //   138: goto -> 184
/*     */     //   141: astore #6
/*     */     //   143: goto -> 184
/*     */     //   146: astore #6
/*     */     //   148: aload_3
/*     */     //   149: invokevirtual close : ()V
/*     */     //   152: aload #4
/*     */     //   154: invokevirtual close : ()V
/*     */     //   157: goto -> 184
/*     */     //   160: astore #6
/*     */     //   162: goto -> 184
/*     */     //   165: astore #7
/*     */     //   167: aload_3
/*     */     //   168: invokevirtual close : ()V
/*     */     //   171: aload #4
/*     */     //   173: invokevirtual close : ()V
/*     */     //   176: goto -> 181
/*     */     //   179: astore #8
/*     */     //   181: aload #7
/*     */     //   183: athrow
/*     */     //   184: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #44	-> 3
/*     */     //   #45	-> 21
/*     */     //   #49	-> 33
/*     */     //   #51	-> 52
/*     */     //   #54	-> 53
/*     */     //   #59	-> 63
/*     */     //   #61	-> 74
/*     */     //   #63	-> 102
/*     */     //   #66	-> 110
/*     */     //   #76	-> 129
/*     */     //   #77	-> 133
/*     */     //   #81	-> 138
/*     */     //   #79	-> 141
/*     */     //   #82	-> 143
/*     */     //   #69	-> 146
/*     */     //   #76	-> 148
/*     */     //   #77	-> 152
/*     */     //   #81	-> 157
/*     */     //   #79	-> 160
/*     */     //   #82	-> 162
/*     */     //   #74	-> 165
/*     */     //   #76	-> 167
/*     */     //   #77	-> 171
/*     */     //   #81	-> 176
/*     */     //   #79	-> 179
/*     */     //   #81	-> 181
/*     */     //   #83	-> 184
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	29	32	java/io/IOException
/*     */     //   25	48	51	java/io/IOException
/*     */     //   63	129	146	java/io/IOException
/*     */     //   63	129	165	finally
/*     */     //   74	98	101	java/io/IOException
/*     */     //   78	106	109	java/io/IOException
/*     */     //   129	138	141	java/io/IOException
/*     */     //   146	148	165	finally
/*     */     //   148	157	160	java/io/IOException
/*     */     //   165	167	165	finally
/*     */     //   167	176	179	java/io/IOException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(String paramString1, byte[] paramArrayOfbyte, String paramString2) {
/*  87 */     FileOutputStream fileOutputStream = null; boolean bool = w.e;
/*     */ 
/*     */     
/*  90 */     try { File file = b(paramString1 + paramString2);
/*  91 */       fileOutputStream = new FileOutputStream(file);
/*  92 */       fileOutputStream.write(paramArrayOfbyte);
/*  93 */       fileOutputStream.flush();
/*  94 */       fileOutputStream.close();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       if (!bool) return;  } catch (IOException iOException) { try { if (!bool) return;  } catch (IOException iOException1) { throw null; }  } finally { Exception exception = null; }  fileOutputStream
/*     */ 
/*     */ 
/*     */       
/* 106 */       .close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File b(String paramString) {
/* 117 */     File file = new File(paramString);
/* 118 */     boolean bool = w.e; if (!bool) if (!(new File(file.getParent())).exists())
/*     */       {
/* 120 */         (new File(file.getParent())).mkdirs();
/*     */       } 
/* 122 */     return file;
/*     */   }
/*     */   
/*     */   public static byte[] a(InputStream paramInputStream) {
/*     */     // Byte code:
/*     */     //   0: new java/io/ByteArrayOutputStream
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   11: istore_1
/*     */     //   12: sipush #10000
/*     */     //   15: newarray byte
/*     */     //   17: astore_3
/*     */     //   18: aload_0
/*     */     //   19: aload_3
/*     */     //   20: iconst_0
/*     */     //   21: sipush #10000
/*     */     //   24: invokevirtual read : ([BII)I
/*     */     //   27: dup
/*     */     //   28: istore #4
/*     */     //   30: iconst_m1
/*     */     //   31: if_icmpeq -> 50
/*     */     //   34: aload_2
/*     */     //   35: iload_1
/*     */     //   36: ifne -> 51
/*     */     //   39: aload_3
/*     */     //   40: iconst_0
/*     */     //   41: iload #4
/*     */     //   43: invokevirtual write : ([BII)V
/*     */     //   46: iload_1
/*     */     //   47: ifeq -> 18
/*     */     //   50: aload_2
/*     */     //   51: invokevirtual toByteArray : ()[B
/*     */     //   54: astore #5
/*     */     //   56: aload_2
/*     */     //   57: invokevirtual close : ()V
/*     */     //   60: aload #5
/*     */     //   62: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #127	-> 0
/*     */     //   #128	-> 11
/*     */     //   #130	-> 18
/*     */     //   #132	-> 34
/*     */     //   #135	-> 50
/*     */     //   #136	-> 56
/*     */     //   #137	-> 60
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: bipush #6
/*     */     //   2: anewarray java/lang/String
/*     */     //   5: astore #5
/*     */     //   7: iconst_0
/*     */     //   8: istore_3
/*     */     //   9: ldc '"ÿg\\tÈÒ·ùÌL#y>$_Æ÷ÅÚèÙa:ÓÞùÍ%É²\\fwò\\tHßþe:K¬èAH\\rF)ºo9¹çÔDâyxÃ¤ç_0:ñäå\\t'
/*     */     //   11: dup
/*     */     //   12: astore_2
/*     */     //   13: invokevirtual length : ()I
/*     */     //   16: istore #4
/*     */     //   18: bipush #67
/*     */     //   20: istore_1
/*     */     //   21: iconst_m1
/*     */     //   22: istore_0
/*     */     //   23: iinc #0, 1
/*     */     //   26: aload_2
/*     */     //   27: iload_0
/*     */     //   28: dup
/*     */     //   29: iload_1
/*     */     //   30: iadd
/*     */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   34: jsr -> 137
/*     */     //   37: aload #5
/*     */     //   39: swap
/*     */     //   40: iload_3
/*     */     //   41: iinc #3, 1
/*     */     //   44: swap
/*     */     //   45: aastore
/*     */     //   46: iload_0
/*     */     //   47: iload_1
/*     */     //   48: iadd
/*     */     //   49: dup
/*     */     //   50: istore_0
/*     */     //   51: iload #4
/*     */     //   53: if_icmpge -> 65
/*     */     //   56: aload_2
/*     */     //   57: iload_0
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: istore_1
/*     */     //   62: goto -> 23
/*     */     //   65: ldc 'ÈX¾!²î£ Í³1¤¦ÉñqUOP #ÿáõeùÖF1LTØä=Uï§\\tL9×ú'
/*     */     //   67: dup
/*     */     //   68: astore_2
/*     */     //   69: invokevirtual length : ()I
/*     */     //   72: istore #4
/*     */     //   74: bipush #37
/*     */     //   76: istore_1
/*     */     //   77: iconst_m1
/*     */     //   78: istore_0
/*     */     //   79: iinc #0, 1
/*     */     //   82: aload_2
/*     */     //   83: iload_0
/*     */     //   84: dup
/*     */     //   85: iload_1
/*     */     //   86: iadd
/*     */     //   87: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   90: jsr -> 137
/*     */     //   93: aload #5
/*     */     //   95: swap
/*     */     //   96: iload_3
/*     */     //   97: iinc #3, 1
/*     */     //   100: swap
/*     */     //   101: aastore
/*     */     //   102: iload_0
/*     */     //   103: iload_1
/*     */     //   104: iadd
/*     */     //   105: dup
/*     */     //   106: istore_0
/*     */     //   107: iload #4
/*     */     //   109: if_icmpge -> 121
/*     */     //   112: aload_2
/*     */     //   113: iload_0
/*     */     //   114: invokevirtual charAt : (I)C
/*     */     //   117: istore_1
/*     */     //   118: goto -> 79
/*     */     //   121: aload #5
/*     */     //   123: putstatic net/portswigger/infiltrator/patcher/a.d : [Ljava/lang/String;
/*     */     //   126: bipush #6
/*     */     //   128: anewarray java/lang/String
/*     */     //   131: putstatic net/portswigger/infiltrator/patcher/a.e : [Ljava/lang/String;
/*     */     //   134: goto -> 278
/*     */     //   137: astore #6
/*     */     //   139: invokevirtual toCharArray : ()[C
/*     */     //   142: dup
/*     */     //   143: arraylength
/*     */     //   144: swap
/*     */     //   145: iconst_0
/*     */     //   146: istore #7
/*     */     //   148: swap
/*     */     //   149: dup_x1
/*     */     //   150: iconst_1
/*     */     //   151: if_icmpgt -> 256
/*     */     //   154: dup
/*     */     //   155: iload #7
/*     */     //   157: dup2
/*     */     //   158: caload
/*     */     //   159: iload #7
/*     */     //   161: bipush #7
/*     */     //   163: irem
/*     */     //   164: tableswitch default -> 237, 0 -> 204, 1 -> 209, 2 -> 215, 3 -> 220, 4 -> 225, 5 -> 231
/*     */     //   204: bipush #104
/*     */     //   206: goto -> 240
/*     */     //   209: sipush #166
/*     */     //   212: goto -> 240
/*     */     //   215: bipush #125
/*     */     //   217: goto -> 240
/*     */     //   220: bipush #25
/*     */     //   222: goto -> 240
/*     */     //   225: sipush #230
/*     */     //   228: goto -> 240
/*     */     //   231: sipush #136
/*     */     //   234: goto -> 240
/*     */     //   237: sipush #224
/*     */     //   240: ixor
/*     */     //   241: i2c
/*     */     //   242: castore
/*     */     //   243: iinc #7, 1
/*     */     //   246: swap
/*     */     //   247: dup_x1
/*     */     //   248: ifne -> 256
/*     */     //   251: dup2
/*     */     //   252: swap
/*     */     //   253: goto -> 157
/*     */     //   256: swap
/*     */     //   257: dup_x1
/*     */     //   258: iload #7
/*     */     //   260: if_icmpgt -> 154
/*     */     //   263: new java/lang/String
/*     */     //   266: dup_x1
/*     */     //   267: swap
/*     */     //   268: invokespecial <init> : ([C)V
/*     */     //   271: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   274: swap
/*     */     //   275: pop
/*     */     //   276: ret #6
/*     */     //   278: return
/*     */   }
/*     */   
/*     */   private static String a(int paramInt1, int paramInt2) {
/*     */     int i = (paramInt1 ^ 0xFFFF8CC9) & 0xFFFF;
/*     */     if (e[i] == null) {
/*     */       char[] arrayOfChar = d[i].toCharArray();
/*     */       switch (arrayOfChar[0] & 0xFF) {
/*     */         case 0:
/*     */         
/*     */         case 1:
/*     */         
/*     */         case 2:
/*     */         
/*     */         case 3:
/*     */         
/*     */         case 4:
/*     */         
/*     */         case 5:
/*     */         
/*     */         case 6:
/*     */         
/*     */         case 7:
/*     */         
/*     */         case 8:
/*     */         
/*     */         case 9:
/*     */         
/*     */         case 10:
/*     */         
/*     */         case 11:
/*     */         
/*     */         case 12:
/*     */         
/*     */         case 13:
/*     */         
/*     */         case 14:
/*     */         
/*     */         case 15:
/*     */         
/*     */         case 16:
/*     */         
/*     */         case 17:
/*     */         
/*     */         case 18:
/*     */         
/*     */         case 19:
/*     */         
/*     */         case 20:
/*     */         
/*     */         case 21:
/*     */         
/*     */         case 22:
/*     */         
/*     */         case 23:
/*     */         
/*     */         case 24:
/*     */         
/*     */         case 25:
/*     */         
/*     */         case 26:
/*     */         
/*     */         case 27:
/*     */         
/*     */         case 28:
/*     */         
/*     */         case 29:
/*     */         
/*     */         case 30:
/*     */         
/*     */         case 31:
/*     */         
/*     */         case 32:
/*     */         
/*     */         case 33:
/*     */         
/*     */         case 34:
/*     */         
/*     */         case 35:
/*     */         
/*     */         case 36:
/*     */         
/*     */         case 37:
/*     */         
/*     */         case 38:
/*     */         
/*     */         case 39:
/*     */         
/*     */         case 40:
/*     */         
/*     */         case 41:
/*     */         
/*     */         case 42:
/*     */         
/*     */         case 43:
/*     */         
/*     */         case 44:
/*     */         
/*     */         case 45:
/*     */         
/*     */         case 46:
/*     */         
/*     */         case 47:
/*     */         
/*     */         case 48:
/*     */         
/*     */         case 49:
/*     */         
/*     */         case 50:
/*     */         
/*     */         case 51:
/*     */         
/*     */         case 52:
/*     */         
/*     */         case 53:
/*     */         
/*     */         case 54:
/*     */         
/*     */         case 55:
/*     */         
/*     */         case 56:
/*     */         
/*     */         case 57:
/*     */         
/*     */         case 58:
/*     */         
/*     */         case 59:
/*     */         
/*     */         case 60:
/*     */         
/*     */         case 61:
/*     */         
/*     */         case 62:
/*     */         
/*     */         case 63:
/*     */         
/*     */         case 64:
/*     */         
/*     */         case 65:
/*     */         
/*     */         case 66:
/*     */         
/*     */         case 67:
/*     */         
/*     */         case 68:
/*     */         
/*     */         case 69:
/*     */         
/*     */         case 70:
/*     */         
/*     */         case 71:
/*     */         
/*     */         case 72:
/*     */         
/*     */         case 73:
/*     */         
/*     */         case 74:
/*     */         
/*     */         case 75:
/*     */         
/*     */         case 76:
/*     */         
/*     */         case 77:
/*     */         
/*     */         case 78:
/*     */         
/*     */         case 79:
/*     */         
/*     */         case 80:
/*     */         
/*     */         case 81:
/*     */         
/*     */         case 82:
/*     */         
/*     */         case 83:
/*     */         
/*     */         case 84:
/*     */         
/*     */         case 85:
/*     */         
/*     */         case 86:
/*     */         
/*     */         case 87:
/*     */         
/*     */         case 88:
/*     */         
/*     */         case 89:
/*     */         
/*     */         case 90:
/*     */         
/*     */         case 91:
/*     */         
/*     */         case 92:
/*     */         
/*     */         case 93:
/*     */         
/*     */         case 94:
/*     */         
/*     */         case 95:
/*     */         
/*     */         case 96:
/*     */         
/*     */         case 97:
/*     */         
/*     */         case 98:
/*     */         
/*     */         case 99:
/*     */         
/*     */         case 100:
/*     */         
/*     */         case 101:
/*     */         
/*     */         case 102:
/*     */         
/*     */         case 103:
/*     */         
/*     */         case 104:
/*     */         
/*     */         case 105:
/*     */         
/*     */         case 106:
/*     */         
/*     */         case 107:
/*     */         
/*     */         case 108:
/*     */         
/*     */         case 109:
/*     */         
/*     */         case 110:
/*     */         
/*     */         case 111:
/*     */         
/*     */         case 112:
/*     */         
/*     */         case 113:
/*     */         
/*     */         case 114:
/*     */         
/*     */         case 115:
/*     */         
/*     */         case 116:
/*     */         
/*     */         case 117:
/*     */         
/*     */         case 118:
/*     */         
/*     */         case 119:
/*     */         
/*     */         case 120:
/*     */         
/*     */         case 121:
/*     */         
/*     */         case 122:
/*     */         
/*     */         case 123:
/*     */         
/*     */         case 124:
/*     */         
/*     */         case 125:
/*     */         
/*     */         case 126:
/*     */         
/*     */         case 127:
/*     */         
/*     */         case 128:
/*     */         
/*     */         case 129:
/*     */         
/*     */         case 130:
/*     */         
/*     */         case 131:
/*     */         
/*     */         case 132:
/*     */         
/*     */         case 133:
/*     */         
/*     */         case 134:
/*     */         
/*     */         case 135:
/*     */         
/*     */         case 136:
/*     */         
/*     */         case 137:
/*     */         
/*     */         case 138:
/*     */         
/*     */         case 139:
/*     */         
/*     */         case 140:
/*     */         
/*     */         case 141:
/*     */         
/*     */         case 142:
/*     */         
/*     */         case 143:
/*     */         
/*     */         case 144:
/*     */         
/*     */         case 145:
/*     */         
/*     */         case 146:
/*     */         
/*     */         case 147:
/*     */         
/*     */         case 148:
/*     */         
/*     */         case 149:
/*     */         
/*     */         case 150:
/*     */         
/*     */         case 151:
/*     */         
/*     */         case 152:
/*     */         
/*     */         case 153:
/*     */         
/*     */         case 154:
/*     */         
/*     */         case 155:
/*     */         
/*     */         case 156:
/*     */         
/*     */         case 157:
/*     */         
/*     */         case 158:
/*     */         
/*     */         case 159:
/*     */         
/*     */         case 160:
/*     */         
/*     */         case 161:
/*     */         
/*     */         case 162:
/*     */         
/*     */         case 163:
/*     */         
/*     */         case 164:
/*     */         
/*     */         case 165:
/*     */         
/*     */         case 166:
/*     */         
/*     */         case 167:
/*     */         
/*     */         case 168:
/*     */         
/*     */         case 169:
/*     */         
/*     */         case 170:
/*     */         
/*     */         case 171:
/*     */         
/*     */         case 172:
/*     */         
/*     */         case 173:
/*     */         
/*     */         case 174:
/*     */         
/*     */         case 175:
/*     */         
/*     */         case 176:
/*     */         
/*     */         case 177:
/*     */         
/*     */         case 178:
/*     */         
/*     */         case 179:
/*     */         
/*     */         case 180:
/*     */         
/*     */         case 181:
/*     */         
/*     */         case 182:
/*     */         
/*     */         case 183:
/*     */         
/*     */         case 184:
/*     */         
/*     */         case 185:
/*     */         
/*     */         case 186:
/*     */         
/*     */         case 187:
/*     */         
/*     */         case 188:
/*     */         
/*     */         case 189:
/*     */         
/*     */         case 190:
/*     */         
/*     */         case 191:
/*     */         
/*     */         case 192:
/*     */         
/*     */         case 193:
/*     */         
/*     */         case 194:
/*     */         
/*     */         case 195:
/*     */         
/*     */         case 196:
/*     */         
/*     */         case 197:
/*     */         
/*     */         case 198:
/*     */         
/*     */         case 199:
/*     */         
/*     */         case 200:
/*     */         
/*     */         case 201:
/*     */         
/*     */         case 202:
/*     */         
/*     */         case 203:
/*     */         
/*     */         case 204:
/*     */         
/*     */         case 205:
/*     */         
/*     */         case 206:
/*     */         
/*     */         case 207:
/*     */         
/*     */         case 208:
/*     */         
/*     */         case 209:
/*     */         
/*     */         case 210:
/*     */         
/*     */         case 211:
/*     */         
/*     */         case 212:
/*     */         
/*     */         case 213:
/*     */         
/*     */         case 214:
/*     */         
/*     */         case 215:
/*     */         
/*     */         case 216:
/*     */         
/*     */         case 217:
/*     */         
/*     */         case 218:
/*     */         
/*     */         case 219:
/*     */         
/*     */         case 220:
/*     */         
/*     */         case 221:
/*     */         
/*     */         case 222:
/*     */         
/*     */         case 223:
/*     */         
/*     */         case 224:
/*     */         
/*     */         case 225:
/*     */         
/*     */         case 226:
/*     */         
/*     */         case 227:
/*     */         
/*     */         case 228:
/*     */         
/*     */         case 229:
/*     */         
/*     */         case 230:
/*     */         
/*     */         case 231:
/*     */         
/*     */         case 232:
/*     */         
/*     */         case 233:
/*     */         
/*     */         case 234:
/*     */         
/*     */         case 235:
/*     */         
/*     */         case 236:
/*     */         
/*     */         case 237:
/*     */         
/*     */         case 238:
/*     */         
/*     */         case 239:
/*     */         
/*     */         case 240:
/*     */         
/*     */         case 241:
/*     */         
/*     */         case 242:
/*     */         
/*     */         case 243:
/*     */         
/*     */         case 244:
/*     */         
/*     */         case 245:
/*     */         
/*     */         case 246:
/*     */         
/*     */         case 247:
/*     */         
/*     */         case 248:
/*     */         
/*     */         case 249:
/*     */         
/*     */         case 250:
/*     */         
/*     */         case 251:
/*     */         
/*     */         case 252:
/*     */         
/*     */         case 253:
/*     */         
/*     */         case 254:
/*     */         
/*     */         default:
/*     */           break;
/*     */       } 
/*     */       byte b1 = 26;
/*     */       int j = (paramInt2 & 0xFF) - b1;
/*     */       if (j < 0)
/*     */         j += 256; 
/*     */       int m = ((paramInt2 & 0xFFFF) >>> 8) - b1;
/*     */       if (m < 0)
/*     */         m += 256; 
/*     */       for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*     */         int n = b2 % 2;
/*     */         if (n == 0) {
/*     */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
/*     */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
/*     */         } else {
/*     */           arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ m);
/*     */           m = ((m >>> 3 | m << 5) ^ arrayOfChar[b2]) & 0xFF;
/*     */         } 
/*     */       } 
/*     */       e[i] = (new String(arrayOfChar)).intern();
/*     */     } 
/*     */     return e[i];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\a.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */