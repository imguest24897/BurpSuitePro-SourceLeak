/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class o
/*     */ {
/*     */   private static final Map c;
/*     */   private static final Integer a;
/*     */   private static final Integer e;
/*     */   private static final Integer b;
/*     */   private final k f;
/*     */   private String[] d;
/*     */   private static final String[] g;
/*     */   private static final String[] h;
/*     */   
/*     */   public o(String[] paramArrayOfString) {
/*  46 */     this.d = paramArrayOfString;
/*  47 */     this.f = new k();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public k e() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_1
/*     */     //   4: aload_0
/*     */     //   5: invokevirtual c : ()Z
/*     */     //   8: iload_1
/*     */     //   9: ifne -> 26
/*     */     //   12: ifne -> 25
/*     */     //   15: goto -> 19
/*     */     //   18: athrow
/*     */     //   19: aload_0
/*     */     //   20: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   23: areturn
/*     */     //   24: athrow
/*     */     //   25: iconst_0
/*     */     //   26: istore_2
/*     */     //   27: iload_2
/*     */     //   28: aload_0
/*     */     //   29: getfield d : [Ljava/lang/String;
/*     */     //   32: arraylength
/*     */     //   33: if_icmpge -> 198
/*     */     //   36: aload_0
/*     */     //   37: getfield d : [Ljava/lang/String;
/*     */     //   40: iload_2
/*     */     //   41: aaload
/*     */     //   42: astore_3
/*     */     //   43: aload_0
/*     */     //   44: iload_1
/*     */     //   45: ifne -> 199
/*     */     //   48: iload_1
/*     */     //   49: ifne -> 127
/*     */     //   52: goto -> 56
/*     */     //   55: athrow
/*     */     //   56: aload_3
/*     */     //   57: invokespecial b : (Ljava/lang/String;)Z
/*     */     //   60: ifne -> 114
/*     */     //   63: goto -> 67
/*     */     //   66: athrow
/*     */     //   67: new java/lang/IllegalArgumentException
/*     */     //   70: dup
/*     */     //   71: new java/lang/StringBuffer
/*     */     //   74: dup
/*     */     //   75: invokespecial <init> : ()V
/*     */     //   78: sipush #-28693
/*     */     //   81: sipush #6142
/*     */     //   84: invokestatic a : (II)Ljava/lang/String;
/*     */     //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   90: aload_3
/*     */     //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   94: sipush #-28701
/*     */     //   97: sipush #7813
/*     */     //   100: invokestatic a : (II)Ljava/lang/String;
/*     */     //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   106: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   109: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   112: athrow
/*     */     //   113: athrow
/*     */     //   114: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   117: aload_0
/*     */     //   118: aload_3
/*     */     //   119: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   122: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   127: checkcast net/portswigger/infiltrator/patcher/m
/*     */     //   130: getfield b : Ljava/lang/Integer;
/*     */     //   133: astore #4
/*     */     //   135: aload #4
/*     */     //   137: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   140: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   143: iload_1
/*     */     //   144: ifne -> 179
/*     */     //   147: ifeq -> 167
/*     */     //   150: goto -> 154
/*     */     //   153: athrow
/*     */     //   154: aload_0
/*     */     //   155: aload_3
/*     */     //   156: invokespecial c : (Ljava/lang/String;)V
/*     */     //   159: iload_1
/*     */     //   160: ifeq -> 191
/*     */     //   163: goto -> 167
/*     */     //   166: athrow
/*     */     //   167: aload #4
/*     */     //   169: getstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   172: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   175: goto -> 179
/*     */     //   178: athrow
/*     */     //   179: ifeq -> 191
/*     */     //   182: aload_0
/*     */     //   183: aload_3
/*     */     //   184: invokespecial a : (Ljava/lang/String;)V
/*     */     //   187: goto -> 191
/*     */     //   190: athrow
/*     */     //   191: iinc #2, 1
/*     */     //   194: iload_1
/*     */     //   195: ifeq -> 27
/*     */     //   198: aload_0
/*     */     //   199: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   202: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #52	-> 4
/*     */     //   #54	-> 19
/*     */     //   #57	-> 25
/*     */     //   #59	-> 36
/*     */     //   #60	-> 43
/*     */     //   #62	-> 67
/*     */     //   #65	-> 114
/*     */     //   #66	-> 135
/*     */     //   #68	-> 154
/*     */     //   #70	-> 167
/*     */     //   #72	-> 182
/*     */     //   #57	-> 191
/*     */     //   #76	-> 198
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	15	18	java/lang/IllegalArgumentException
/*     */     //   12	24	24	java/lang/IllegalArgumentException
/*     */     //   43	52	55	java/lang/IllegalArgumentException
/*     */     //   48	63	66	java/lang/IllegalArgumentException
/*     */     //   56	113	113	java/lang/IllegalArgumentException
/*     */     //   135	150	153	java/lang/IllegalArgumentException
/*     */     //   147	163	166	java/lang/IllegalArgumentException
/*     */     //   154	175	178	java/lang/IllegalArgumentException
/*     */     //   179	187	190	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_1
/*     */     //   4: aload_0
/*     */     //   5: invokespecial a : ()Z
/*     */     //   8: iload_1
/*     */     //   9: ifne -> 28
/*     */     //   12: ifeq -> 27
/*     */     //   15: goto -> 19
/*     */     //   18: athrow
/*     */     //   19: iconst_0
/*     */     //   20: invokestatic exit : (I)V
/*     */     //   23: goto -> 27
/*     */     //   26: athrow
/*     */     //   27: iconst_0
/*     */     //   28: istore_2
/*     */     //   29: iload_2
/*     */     //   30: aload_0
/*     */     //   31: getfield d : [Ljava/lang/String;
/*     */     //   34: arraylength
/*     */     //   35: if_icmpge -> 116
/*     */     //   38: aload_0
/*     */     //   39: aload_0
/*     */     //   40: getfield d : [Ljava/lang/String;
/*     */     //   43: iload_2
/*     */     //   44: aaload
/*     */     //   45: iload_1
/*     */     //   46: ifne -> 78
/*     */     //   49: invokespecial b : (Ljava/lang/String;)Z
/*     */     //   52: iload_1
/*     */     //   53: ifne -> 117
/*     */     //   56: goto -> 60
/*     */     //   59: athrow
/*     */     //   60: ifeq -> 109
/*     */     //   63: goto -> 67
/*     */     //   66: athrow
/*     */     //   67: aload_0
/*     */     //   68: aload_0
/*     */     //   69: getfield d : [Ljava/lang/String;
/*     */     //   72: iload_2
/*     */     //   73: aaload
/*     */     //   74: goto -> 78
/*     */     //   77: athrow
/*     */     //   78: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   81: astore_3
/*     */     //   82: iload_1
/*     */     //   83: ifne -> 112
/*     */     //   86: aload_3
/*     */     //   87: sipush #-28682
/*     */     //   90: sipush #12651
/*     */     //   93: invokestatic a : (II)Ljava/lang/String;
/*     */     //   96: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   99: ifeq -> 109
/*     */     //   102: goto -> 106
/*     */     //   105: athrow
/*     */     //   106: iconst_1
/*     */     //   107: ireturn
/*     */     //   108: athrow
/*     */     //   109: iinc #2, 1
/*     */     //   112: iload_1
/*     */     //   113: ifeq -> 29
/*     */     //   116: iconst_0
/*     */     //   117: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #81	-> 4
/*     */     //   #83	-> 19
/*     */     //   #86	-> 27
/*     */     //   #88	-> 38
/*     */     //   #90	-> 67
/*     */     //   #91	-> 82
/*     */     //   #93	-> 106
/*     */     //   #86	-> 109
/*     */     //   #98	-> 116
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	15	18	java/lang/IllegalArgumentException
/*     */     //   12	23	26	java/lang/IllegalArgumentException
/*     */     //   38	56	59	java/lang/IllegalArgumentException
/*     */     //   49	63	66	java/lang/IllegalArgumentException
/*     */     //   60	74	77	java/lang/IllegalArgumentException
/*     */     //   82	102	105	java/lang/IllegalArgumentException
/*     */     //   86	108	108	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean a() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: iconst_0
/*     */     //   4: istore_2
/*     */     //   5: istore_1
/*     */     //   6: iload_2
/*     */     //   7: aload_0
/*     */     //   8: getfield d : [Ljava/lang/String;
/*     */     //   11: arraylength
/*     */     //   12: if_icmpge -> 421
/*     */     //   15: aload_0
/*     */     //   16: aload_0
/*     */     //   17: getfield d : [Ljava/lang/String;
/*     */     //   20: iload_2
/*     */     //   21: aaload
/*     */     //   22: invokespecial b : (Ljava/lang/String;)Z
/*     */     //   25: iload_1
/*     */     //   26: ifne -> 422
/*     */     //   29: iload_1
/*     */     //   30: ifne -> 78
/*     */     //   33: goto -> 37
/*     */     //   36: athrow
/*     */     //   37: ifeq -> 414
/*     */     //   40: goto -> 44
/*     */     //   43: athrow
/*     */     //   44: aload_0
/*     */     //   45: aload_0
/*     */     //   46: getfield d : [Ljava/lang/String;
/*     */     //   49: iload_2
/*     */     //   50: aaload
/*     */     //   51: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   54: iload_1
/*     */     //   55: ifne -> 90
/*     */     //   58: goto -> 62
/*     */     //   61: athrow
/*     */     //   62: sipush #-28695
/*     */     //   65: sipush #6002
/*     */     //   68: invokestatic a : (II)Ljava/lang/String;
/*     */     //   71: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   74: goto -> 78
/*     */     //   77: athrow
/*     */     //   78: ifeq -> 414
/*     */     //   81: sipush #-28699
/*     */     //   84: sipush #-16334
/*     */     //   87: invokestatic a : (II)Ljava/lang/String;
/*     */     //   90: astore_3
/*     */     //   91: aload_0
/*     */     //   92: invokespecial b : ()I
/*     */     //   95: istore #4
/*     */     //   97: aload_0
/*     */     //   98: invokespecial d : ()Ljava/util/List;
/*     */     //   101: astore #5
/*     */     //   103: iconst_0
/*     */     //   104: istore #6
/*     */     //   106: iload #6
/*     */     //   108: aload #5
/*     */     //   110: invokeinterface size : ()I
/*     */     //   115: if_icmpge -> 405
/*     */     //   118: aload #5
/*     */     //   120: iload #6
/*     */     //   122: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   127: checkcast java/lang/String
/*     */     //   130: astore #7
/*     */     //   132: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   135: aload #7
/*     */     //   137: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   142: checkcast net/portswigger/infiltrator/patcher/m
/*     */     //   145: astore #8
/*     */     //   147: aload #8
/*     */     //   149: getfield b : Ljava/lang/Integer;
/*     */     //   152: getstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   155: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   158: iload_1
/*     */     //   159: ifne -> 413
/*     */     //   162: iload_1
/*     */     //   163: ifne -> 265
/*     */     //   166: goto -> 170
/*     */     //   169: athrow
/*     */     //   170: ifeq -> 250
/*     */     //   173: goto -> 177
/*     */     //   176: athrow
/*     */     //   177: new java/lang/StringBuffer
/*     */     //   180: dup
/*     */     //   181: invokespecial <init> : ()V
/*     */     //   184: sipush #-28680
/*     */     //   187: sipush #15736
/*     */     //   190: invokestatic a : (II)Ljava/lang/String;
/*     */     //   193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   196: aload #7
/*     */     //   198: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   201: sipush #-28674
/*     */     //   204: sipush #1640
/*     */     //   207: invokestatic a : (II)Ljava/lang/String;
/*     */     //   210: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   213: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   216: astore #9
/*     */     //   218: new java/lang/StringBuffer
/*     */     //   221: dup
/*     */     //   222: invokespecial <init> : ()V
/*     */     //   225: aload_3
/*     */     //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   229: aload_0
/*     */     //   230: iload #4
/*     */     //   232: aload #8
/*     */     //   234: aload #9
/*     */     //   236: invokespecial a : (ILnet/portswigger/infiltrator/patcher/m;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   242: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   245: astore_3
/*     */     //   246: iload_1
/*     */     //   247: ifeq -> 398
/*     */     //   250: aload #8
/*     */     //   252: getfield b : Ljava/lang/Integer;
/*     */     //   255: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   258: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   261: goto -> 265
/*     */     //   264: athrow
/*     */     //   265: ifeq -> 341
/*     */     //   268: new java/lang/StringBuffer
/*     */     //   271: dup
/*     */     //   272: invokespecial <init> : ()V
/*     */     //   275: sipush #-28680
/*     */     //   278: sipush #15736
/*     */     //   281: invokestatic a : (II)Ljava/lang/String;
/*     */     //   284: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   287: aload #7
/*     */     //   289: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   292: sipush #-28704
/*     */     //   295: sipush #-11310
/*     */     //   298: invokestatic a : (II)Ljava/lang/String;
/*     */     //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   304: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   307: astore #9
/*     */     //   309: new java/lang/StringBuffer
/*     */     //   312: dup
/*     */     //   313: invokespecial <init> : ()V
/*     */     //   316: aload_3
/*     */     //   317: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   320: aload_0
/*     */     //   321: iload #4
/*     */     //   323: aload #8
/*     */     //   325: aload #9
/*     */     //   327: invokespecial a : (ILnet/portswigger/infiltrator/patcher/m;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   330: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   333: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   336: astore_3
/*     */     //   337: iload_1
/*     */     //   338: ifeq -> 398
/*     */     //   341: new java/lang/StringBuffer
/*     */     //   344: dup
/*     */     //   345: invokespecial <init> : ()V
/*     */     //   348: sipush #-28680
/*     */     //   351: sipush #15736
/*     */     //   354: invokestatic a : (II)Ljava/lang/String;
/*     */     //   357: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   360: aload #7
/*     */     //   362: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   365: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   368: astore #9
/*     */     //   370: new java/lang/StringBuffer
/*     */     //   373: dup
/*     */     //   374: invokespecial <init> : ()V
/*     */     //   377: aload_3
/*     */     //   378: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   381: aload_0
/*     */     //   382: iload #4
/*     */     //   384: aload #8
/*     */     //   386: aload #9
/*     */     //   388: invokespecial a : (ILnet/portswigger/infiltrator/patcher/m;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   394: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   397: astore_3
/*     */     //   398: iinc #6, 1
/*     */     //   401: iload_1
/*     */     //   402: ifeq -> 106
/*     */     //   405: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   408: aload_3
/*     */     //   409: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   412: iconst_1
/*     */     //   413: ireturn
/*     */     //   414: iinc #2, 1
/*     */     //   417: iload_1
/*     */     //   418: ifeq -> 6
/*     */     //   421: iconst_0
/*     */     //   422: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #103	-> 3
/*     */     //   #105	-> 15
/*     */     //   #107	-> 81
/*     */     //   #109	-> 91
/*     */     //   #110	-> 97
/*     */     //   #112	-> 103
/*     */     //   #114	-> 118
/*     */     //   #115	-> 132
/*     */     //   #117	-> 147
/*     */     //   #119	-> 177
/*     */     //   #120	-> 218
/*     */     //   #121	-> 246
/*     */     //   #122	-> 250
/*     */     //   #124	-> 268
/*     */     //   #125	-> 309
/*     */     //   #126	-> 337
/*     */     //   #129	-> 341
/*     */     //   #130	-> 370
/*     */     //   #112	-> 398
/*     */     //   #134	-> 405
/*     */     //   #135	-> 412
/*     */     //   #103	-> 414
/*     */     //   #139	-> 421
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   15	33	36	java/lang/IllegalArgumentException
/*     */     //   29	40	43	java/lang/IllegalArgumentException
/*     */     //   37	58	61	java/lang/IllegalArgumentException
/*     */     //   44	74	77	java/lang/IllegalArgumentException
/*     */     //   147	166	169	java/lang/IllegalArgumentException
/*     */     //   162	173	176	java/lang/IllegalArgumentException
/*     */     //   246	261	264	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List d() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: new java/util/ArrayList
/*     */     //   6: dup
/*     */     //   7: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   10: invokeinterface size : ()I
/*     */     //   15: iconst_1
/*     */     //   16: isub
/*     */     //   17: invokespecial <init> : (I)V
/*     */     //   20: astore_2
/*     */     //   21: istore_1
/*     */     //   22: iconst_0
/*     */     //   23: istore_3
/*     */     //   24: iload_3
/*     */     //   25: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   28: invokeinterface size : ()I
/*     */     //   33: if_icmpge -> 52
/*     */     //   36: aload_2
/*     */     //   37: ldc ''
/*     */     //   39: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   44: pop
/*     */     //   45: iinc #3, 1
/*     */     //   48: iload_1
/*     */     //   49: ifeq -> 24
/*     */     //   52: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   55: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   60: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   65: astore_3
/*     */     //   66: aload_3
/*     */     //   67: invokeinterface hasNext : ()Z
/*     */     //   72: ifeq -> 131
/*     */     //   75: aload_3
/*     */     //   76: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   81: checkcast java/lang/String
/*     */     //   84: astore #4
/*     */     //   86: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   89: aload #4
/*     */     //   91: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   96: checkcast net/portswigger/infiltrator/patcher/m
/*     */     //   99: astore #5
/*     */     //   101: aload #5
/*     */     //   103: getfield c : I
/*     */     //   106: istore #6
/*     */     //   108: aload_2
/*     */     //   109: iload_1
/*     */     //   110: ifne -> 132
/*     */     //   113: iload #6
/*     */     //   115: aload #4
/*     */     //   117: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   122: pop
/*     */     //   123: iload_1
/*     */     //   124: ifeq -> 66
/*     */     //   127: goto -> 131
/*     */     //   130: athrow
/*     */     //   131: aload_2
/*     */     //   132: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #144	-> 3
/*     */     //   #145	-> 21
/*     */     //   #147	-> 36
/*     */     //   #145	-> 45
/*     */     //   #149	-> 52
/*     */     //   #150	-> 66
/*     */     //   #152	-> 75
/*     */     //   #153	-> 86
/*     */     //   #154	-> 101
/*     */     //   #155	-> 108
/*     */     //   #156	-> 123
/*     */     //   #158	-> 131
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   108	127	130	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String a(int paramInt, m paramm, String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_3
/*     */     //   4: invokevirtual length : ()I
/*     */     //   7: istore #5
/*     */     //   9: istore #4
/*     */     //   11: iload #5
/*     */     //   13: iload_1
/*     */     //   14: if_icmpge -> 54
/*     */     //   17: new java/lang/StringBuffer
/*     */     //   20: dup
/*     */     //   21: invokespecial <init> : ()V
/*     */     //   24: aload_3
/*     */     //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   28: ldc ' '
/*     */     //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   33: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   36: astore_3
/*     */     //   37: iinc #5, 1
/*     */     //   40: iload #4
/*     */     //   42: ifne -> 93
/*     */     //   45: iload #4
/*     */     //   47: ifeq -> 11
/*     */     //   50: goto -> 54
/*     */     //   53: athrow
/*     */     //   54: new java/lang/StringBuffer
/*     */     //   57: dup
/*     */     //   58: invokespecial <init> : ()V
/*     */     //   61: aload_3
/*     */     //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   65: sipush #-28681
/*     */     //   68: sipush #20552
/*     */     //   71: invokestatic a : (II)Ljava/lang/String;
/*     */     //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   77: aload_2
/*     */     //   78: getfield a : Ljava/lang/String;
/*     */     //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   84: ldc '\\n'
/*     */     //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   89: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   92: astore_3
/*     */     //   93: aload_3
/*     */     //   94: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #163	-> 3
/*     */     //   #165	-> 17
/*     */     //   #163	-> 37
/*     */     //   #167	-> 54
/*     */     //   #168	-> 93
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   37	50	53	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int b() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   3: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   8: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   13: astore_2
/*     */     //   14: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   17: iconst_0
/*     */     //   18: istore_3
/*     */     //   19: istore_1
/*     */     //   20: aload_2
/*     */     //   21: invokeinterface hasNext : ()Z
/*     */     //   26: ifeq -> 280
/*     */     //   29: aload_2
/*     */     //   30: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   35: checkcast java/lang/String
/*     */     //   38: astore #4
/*     */     //   40: iconst_0
/*     */     //   41: istore #5
/*     */     //   43: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   46: aload #4
/*     */     //   48: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   53: checkcast net/portswigger/infiltrator/patcher/m
/*     */     //   56: astore #6
/*     */     //   58: aload #6
/*     */     //   60: getfield b : Ljava/lang/Integer;
/*     */     //   63: getstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   66: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   69: iload_1
/*     */     //   70: ifne -> 281
/*     */     //   73: iload_1
/*     */     //   74: ifne -> 154
/*     */     //   77: goto -> 81
/*     */     //   80: athrow
/*     */     //   81: ifeq -> 139
/*     */     //   84: goto -> 88
/*     */     //   87: athrow
/*     */     //   88: iload #5
/*     */     //   90: new java/lang/StringBuffer
/*     */     //   93: dup
/*     */     //   94: invokespecial <init> : ()V
/*     */     //   97: sipush #-28680
/*     */     //   100: sipush #15736
/*     */     //   103: invokestatic a : (II)Ljava/lang/String;
/*     */     //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   109: aload #4
/*     */     //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   114: sipush #-28674
/*     */     //   117: sipush #1640
/*     */     //   120: invokestatic a : (II)Ljava/lang/String;
/*     */     //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   126: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   129: invokevirtual length : ()I
/*     */     //   132: iadd
/*     */     //   133: istore #5
/*     */     //   135: iload_1
/*     */     //   136: ifeq -> 255
/*     */     //   139: aload #6
/*     */     //   141: getfield b : Ljava/lang/Integer;
/*     */     //   144: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   147: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   150: goto -> 154
/*     */     //   153: athrow
/*     */     //   154: iload_1
/*     */     //   155: ifne -> 253
/*     */     //   158: ifeq -> 216
/*     */     //   161: goto -> 165
/*     */     //   164: athrow
/*     */     //   165: iload #5
/*     */     //   167: new java/lang/StringBuffer
/*     */     //   170: dup
/*     */     //   171: invokespecial <init> : ()V
/*     */     //   174: sipush #-28680
/*     */     //   177: sipush #15736
/*     */     //   180: invokestatic a : (II)Ljava/lang/String;
/*     */     //   183: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   186: aload #4
/*     */     //   188: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   191: sipush #-28704
/*     */     //   194: sipush #-11310
/*     */     //   197: invokestatic a : (II)Ljava/lang/String;
/*     */     //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   203: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   206: invokevirtual length : ()I
/*     */     //   209: iadd
/*     */     //   210: istore #5
/*     */     //   212: iload_1
/*     */     //   213: ifeq -> 255
/*     */     //   216: iload #5
/*     */     //   218: new java/lang/StringBuffer
/*     */     //   221: dup
/*     */     //   222: invokespecial <init> : ()V
/*     */     //   225: sipush #-28680
/*     */     //   228: sipush #15736
/*     */     //   231: invokestatic a : (II)Ljava/lang/String;
/*     */     //   234: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   237: aload #4
/*     */     //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   242: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   245: invokevirtual length : ()I
/*     */     //   248: iadd
/*     */     //   249: goto -> 253
/*     */     //   252: athrow
/*     */     //   253: istore #5
/*     */     //   255: iload #5
/*     */     //   257: iload_1
/*     */     //   258: ifne -> 275
/*     */     //   261: iload_3
/*     */     //   262: if_icmple -> 276
/*     */     //   265: goto -> 269
/*     */     //   268: athrow
/*     */     //   269: iload #5
/*     */     //   271: goto -> 275
/*     */     //   274: athrow
/*     */     //   275: istore_3
/*     */     //   276: iload_1
/*     */     //   277: ifeq -> 20
/*     */     //   280: iload_3
/*     */     //   281: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #173	-> 0
/*     */     //   #174	-> 14
/*     */     //   #175	-> 20
/*     */     //   #177	-> 29
/*     */     //   #178	-> 40
/*     */     //   #179	-> 43
/*     */     //   #180	-> 58
/*     */     //   #182	-> 88
/*     */     //   #184	-> 139
/*     */     //   #186	-> 165
/*     */     //   #190	-> 216
/*     */     //   #193	-> 255
/*     */     //   #195	-> 269
/*     */     //   #197	-> 276
/*     */     //   #198	-> 280
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   58	77	80	java/lang/IllegalArgumentException
/*     */     //   73	84	87	java/lang/IllegalArgumentException
/*     */     //   135	150	153	java/lang/IllegalArgumentException
/*     */     //   154	161	164	java/lang/IllegalArgumentException
/*     */     //   212	249	252	java/lang/IllegalArgumentException
/*     */     //   255	265	268	java/lang/IllegalArgumentException
/*     */     //   261	271	274	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_0
/*     */     //   4: aload_1
/*     */     //   5: invokespecial d : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   8: astore_3
/*     */     //   9: aload_3
/*     */     //   10: ldc ','
/*     */     //   12: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   15: astore #4
/*     */     //   17: aload_0
/*     */     //   18: aload_1
/*     */     //   19: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   22: astore #5
/*     */     //   24: istore_2
/*     */     //   25: aload #5
/*     */     //   27: sipush #-28694
/*     */     //   30: sipush #32294
/*     */     //   33: invokestatic a : (II)Ljava/lang/String;
/*     */     //   36: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   39: iload_2
/*     */     //   40: ifne -> 111
/*     */     //   43: ifeq -> 93
/*     */     //   46: goto -> 50
/*     */     //   49: athrow
/*     */     //   50: iconst_0
/*     */     //   51: istore #6
/*     */     //   53: iload #6
/*     */     //   55: aload #4
/*     */     //   57: arraylength
/*     */     //   58: if_icmpge -> 89
/*     */     //   61: aload_0
/*     */     //   62: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   65: aload #4
/*     */     //   67: iload #6
/*     */     //   69: aaload
/*     */     //   70: invokevirtual a : (Ljava/lang/String;)Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   73: pop
/*     */     //   74: iinc #6, 1
/*     */     //   77: iload_2
/*     */     //   78: ifne -> 153
/*     */     //   81: iload_2
/*     */     //   82: ifeq -> 53
/*     */     //   85: goto -> 89
/*     */     //   88: athrow
/*     */     //   89: iload_2
/*     */     //   90: ifeq -> 153
/*     */     //   93: aload #5
/*     */     //   95: sipush #-28678
/*     */     //   98: sipush #21711
/*     */     //   101: invokestatic a : (II)Ljava/lang/String;
/*     */     //   104: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   107: goto -> 111
/*     */     //   110: athrow
/*     */     //   111: iload_2
/*     */     //   112: ifne -> 123
/*     */     //   115: ifeq -> 153
/*     */     //   118: goto -> 122
/*     */     //   121: athrow
/*     */     //   122: iconst_0
/*     */     //   123: istore #6
/*     */     //   125: iload #6
/*     */     //   127: aload #4
/*     */     //   129: arraylength
/*     */     //   130: if_icmpge -> 153
/*     */     //   133: aload_0
/*     */     //   134: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   137: aload #4
/*     */     //   139: iload #6
/*     */     //   141: aaload
/*     */     //   142: invokevirtual b : (Ljava/lang/String;)Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   145: pop
/*     */     //   146: iinc #6, 1
/*     */     //   149: iload_2
/*     */     //   150: ifeq -> 125
/*     */     //   153: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #203	-> 3
/*     */     //   #204	-> 9
/*     */     //   #206	-> 17
/*     */     //   #207	-> 25
/*     */     //   #209	-> 50
/*     */     //   #211	-> 61
/*     */     //   #209	-> 74
/*     */     //   #214	-> 93
/*     */     //   #216	-> 122
/*     */     //   #218	-> 133
/*     */     //   #216	-> 146
/*     */     //   #221	-> 153
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   25	46	49	java/lang/IllegalArgumentException
/*     */     //   61	85	88	java/lang/IllegalArgumentException
/*     */     //   89	107	110	java/lang/IllegalArgumentException
/*     */     //   111	118	121	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void c(String paramString) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokespecial d : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   5: astore_3
/*     */     //   6: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   9: aload_0
/*     */     //   10: aload_1
/*     */     //   11: aload_3
/*     */     //   12: invokespecial a : (Ljava/lang/String;Ljava/lang/String;)Z
/*     */     //   15: istore #4
/*     */     //   17: aload_0
/*     */     //   18: aload_1
/*     */     //   19: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   22: astore #5
/*     */     //   24: istore_2
/*     */     //   25: aload #5
/*     */     //   27: sipush #-28692
/*     */     //   30: sipush #-12376
/*     */     //   33: invokestatic a : (II)Ljava/lang/String;
/*     */     //   36: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   39: iload_2
/*     */     //   40: ifne -> 86
/*     */     //   43: ifeq -> 68
/*     */     //   46: goto -> 50
/*     */     //   49: athrow
/*     */     //   50: aload_0
/*     */     //   51: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   54: iload #4
/*     */     //   56: invokevirtual b : (Z)Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   59: pop
/*     */     //   60: iload_2
/*     */     //   61: ifeq -> 150
/*     */     //   64: goto -> 68
/*     */     //   67: athrow
/*     */     //   68: aload #5
/*     */     //   70: sipush #-28702
/*     */     //   73: sipush #-10117
/*     */     //   76: invokestatic a : (II)Ljava/lang/String;
/*     */     //   79: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   82: goto -> 86
/*     */     //   85: athrow
/*     */     //   86: iload_2
/*     */     //   87: ifne -> 133
/*     */     //   90: ifeq -> 115
/*     */     //   93: goto -> 97
/*     */     //   96: athrow
/*     */     //   97: aload_0
/*     */     //   98: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   101: iload #4
/*     */     //   103: invokevirtual a : (Z)Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   106: pop
/*     */     //   107: iload_2
/*     */     //   108: ifeq -> 150
/*     */     //   111: goto -> 115
/*     */     //   114: athrow
/*     */     //   115: aload #5
/*     */     //   117: sipush #-28698
/*     */     //   120: sipush #1561
/*     */     //   123: invokestatic a : (II)Ljava/lang/String;
/*     */     //   126: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   129: goto -> 133
/*     */     //   132: athrow
/*     */     //   133: ifeq -> 150
/*     */     //   136: aload_0
/*     */     //   137: getfield f : Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   140: iload #4
/*     */     //   142: invokevirtual c : (Z)Lnet/portswigger/infiltrator/patcher/k;
/*     */     //   145: pop
/*     */     //   146: goto -> 150
/*     */     //   149: athrow
/*     */     //   150: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #225	-> 0
/*     */     //   #226	-> 6
/*     */     //   #228	-> 17
/*     */     //   #229	-> 25
/*     */     //   #231	-> 50
/*     */     //   #233	-> 68
/*     */     //   #235	-> 97
/*     */     //   #237	-> 115
/*     */     //   #239	-> 136
/*     */     //   #241	-> 150
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   25	46	49	java/lang/IllegalArgumentException
/*     */     //   43	64	67	java/lang/IllegalArgumentException
/*     */     //   50	82	85	java/lang/IllegalArgumentException
/*     */     //   86	93	96	java/lang/IllegalArgumentException
/*     */     //   90	111	114	java/lang/IllegalArgumentException
/*     */     //   97	129	132	java/lang/IllegalArgumentException
/*     */     //   133	146	149	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String d(String paramString) {
/* 245 */     boolean bool = w.e; try { if (!bool) try { if (paramString.indexOf("=") == -1)
/*     */           {
/* 247 */             throw new IllegalArgumentException(a(-28673, 22749) + e(paramString)); }  } catch (IllegalArgumentException illegalArgumentException) { throw null; }
/*     */           }
/*     */     catch (IllegalArgumentException illegalArgumentException) { throw null; }
/* 250 */      String str = paramString.substring(paramString.indexOf("=") + 1); 
/* 251 */     try { if (!bool) try { if (str.length() == 0)
/*     */           {
/* 253 */             throw new IllegalArgumentException(a(-28703, -26080) + e(paramString)); }  } catch (IllegalArgumentException illegalArgumentException) { throw null; }   }
/*     */     catch (IllegalArgumentException illegalArgumentException) { throw null; }
/* 255 */      return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean a(String paramString1, String paramString2) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_3
/*     */     //   4: aload_2
/*     */     //   5: sipush #-28677
/*     */     //   8: sipush #-32063
/*     */     //   11: invokestatic a : (II)Ljava/lang/String;
/*     */     //   14: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   17: iload_3
/*     */     //   18: ifne -> 52
/*     */     //   21: ifeq -> 35
/*     */     //   24: goto -> 28
/*     */     //   27: athrow
/*     */     //   28: iconst_1
/*     */     //   29: istore #4
/*     */     //   31: iload_3
/*     */     //   32: ifeq -> 109
/*     */     //   35: aload_2
/*     */     //   36: sipush #-28690
/*     */     //   39: sipush #12209
/*     */     //   42: invokestatic a : (II)Ljava/lang/String;
/*     */     //   45: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   48: goto -> 52
/*     */     //   51: athrow
/*     */     //   52: iload_3
/*     */     //   53: ifne -> 64
/*     */     //   56: ifeq -> 70
/*     */     //   59: goto -> 63
/*     */     //   62: athrow
/*     */     //   63: iconst_0
/*     */     //   64: istore #4
/*     */     //   66: iload_3
/*     */     //   67: ifeq -> 109
/*     */     //   70: new java/lang/IllegalArgumentException
/*     */     //   73: dup
/*     */     //   74: new java/lang/StringBuffer
/*     */     //   77: dup
/*     */     //   78: invokespecial <init> : ()V
/*     */     //   81: sipush #-28679
/*     */     //   84: sipush #14012
/*     */     //   87: invokestatic a : (II)Ljava/lang/String;
/*     */     //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   93: aload_0
/*     */     //   94: aload_1
/*     */     //   95: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   101: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   104: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   107: athrow
/*     */     //   108: athrow
/*     */     //   109: iload #4
/*     */     //   111: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #261	-> 4
/*     */     //   #263	-> 28
/*     */     //   #265	-> 35
/*     */     //   #267	-> 63
/*     */     //   #271	-> 70
/*     */     //   #273	-> 109
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	24	27	java/lang/IllegalArgumentException
/*     */     //   31	48	51	java/lang/IllegalArgumentException
/*     */     //   52	59	62	java/lang/IllegalArgumentException
/*     */     //   66	108	108	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean b(String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_2
/*     */     //   4: aload_1
/*     */     //   5: iload_2
/*     */     //   6: ifne -> 45
/*     */     //   9: sipush #-28680
/*     */     //   12: sipush #15736
/*     */     //   15: invokestatic a : (II)Ljava/lang/String;
/*     */     //   18: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   21: ifeq -> 53
/*     */     //   24: goto -> 28
/*     */     //   27: athrow
/*     */     //   28: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   31: aload_0
/*     */     //   32: aload_1
/*     */     //   33: invokespecial e : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   36: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   41: goto -> 45
/*     */     //   44: athrow
/*     */     //   45: ifnull -> 53
/*     */     //   48: iconst_1
/*     */     //   49: goto -> 54
/*     */     //   52: athrow
/*     */     //   53: iconst_0
/*     */     //   54: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #278	-> 4
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	24	27	java/lang/IllegalArgumentException
/*     */     //   9	41	44	java/lang/IllegalArgumentException
/*     */     //   45	52	52	java/lang/IllegalArgumentException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String e(String paramString) {
/* 283 */     boolean bool = w.e; try { if (!bool) { try { if (paramString.indexOf("=") != -1) {  } else {  }  } catch (IllegalArgumentException illegalArgumentException) { throw null; }  return paramString.substring(2); }  } catch (IllegalArgumentException illegalArgumentException)
/*     */     { throw null; }
/*     */   
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: bipush #26
/*     */     //   2: anewarray java/lang/String
/*     */     //   5: astore #5
/*     */     //   7: iconst_0
/*     */     //   8: istore_3
/*     */     //   9: ldc '\\t~\\rwdÁúSËc÷évÿµtGJ1W?=´"A0ôë7Ê0}óÔ÷µð¬I¸ ò§ÖîÃí¶G-ã¹âR¡Ê¸B5éúKz*FøFo7µ=Oý î\²üRÄÔ¡\\f\\tµ§ç"ªÞÑ#ZZ/(® :\/ðàEà\\nËe.Ä/è°±ptj@[[Uë,Ä¯.P¢&kÌ+y¦ÎeÑÄêO[ÖrçB</¡ àe\\nù@ò=ÚG©'ÿH7ÐÊù·¤Qó¶»d21`f\\ro<!Ó§þØ%lètGjE»'Ó`6IpIÎv\\b[ÂÊ\\r H­\\b#åóac=<afw¥ÿíÉñë{B%EF/F­s?ÉÌ÷¦ °Ieð$Ø´ÃÏnjÉ'¢²öD_Fb~Ä>(ÁÃ©Æ6c«a°é¨FOfº«  ÑÑÒ¬Ä<d\\t°9hY|6gfêÛ(¢s´Ïùªs¬4|+avêjÙ°¯íU¡Òôù1}S-4Wð2|¨ÜÐì¿ßK$\\bú£6\\rÁÂB­=w~:¾È§L.9½ç 3§nyãá¾håZMå¤òm\\nöP¥Ö93û,2ò\\n§Ý@ÇÃÌF1¸K`&7^Ùl,¥è«n²Ô Róõ·9jïä²,S\\n×äN_u~N¬ÿÿyP»ËNÀ@¥CabÃg1¥²-ãëÃ$²½¤0É¦í»öQ¯ËnÉG¿PD¨l£D¶³xæ¼\\f¡½£wØ½V¶Àá\\n:yÒhÊñ«ì|ÂËVh¡'
/*     */     //   11: dup
/*     */     //   12: astore_2
/*     */     //   13: invokevirtual length : ()I
/*     */     //   16: istore #4
/*     */     //   18: bipush #18
/*     */     //   20: istore_1
/*     */     //   21: iconst_m1
/*     */     //   22: istore_0
/*     */     //   23: iinc #0, 1
/*     */     //   26: aload_2
/*     */     //   27: iload_0
/*     */     //   28: dup
/*     */     //   29: iload_1
/*     */     //   30: iadd
/*     */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   34: jsr -> 136
/*     */     //   37: aload #5
/*     */     //   39: swap
/*     */     //   40: iload_3
/*     */     //   41: iinc #3, 1
/*     */     //   44: swap
/*     */     //   45: aastore
/*     */     //   46: iload_0
/*     */     //   47: iload_1
/*     */     //   48: iadd
/*     */     //   49: dup
/*     */     //   50: istore_0
/*     */     //   51: iload #4
/*     */     //   53: if_icmpge -> 65
/*     */     //   56: aload_2
/*     */     //   57: iload_0
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: istore_1
/*     */     //   62: goto -> 23
/*     */     //   65: ldc 'PÔ&ÕÿýµwWa]gù9'
/*     */     //   67: dup
/*     */     //   68: astore_2
/*     */     //   69: invokevirtual length : ()I
/*     */     //   72: istore #4
/*     */     //   74: iconst_2
/*     */     //   75: istore_1
/*     */     //   76: iconst_m1
/*     */     //   77: istore_0
/*     */     //   78: iinc #0, 1
/*     */     //   81: aload_2
/*     */     //   82: iload_0
/*     */     //   83: dup
/*     */     //   84: iload_1
/*     */     //   85: iadd
/*     */     //   86: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   89: jsr -> 136
/*     */     //   92: aload #5
/*     */     //   94: swap
/*     */     //   95: iload_3
/*     */     //   96: iinc #3, 1
/*     */     //   99: swap
/*     */     //   100: aastore
/*     */     //   101: iload_0
/*     */     //   102: iload_1
/*     */     //   103: iadd
/*     */     //   104: dup
/*     */     //   105: istore_0
/*     */     //   106: iload #4
/*     */     //   108: if_icmpge -> 120
/*     */     //   111: aload_2
/*     */     //   112: iload_0
/*     */     //   113: invokevirtual charAt : (I)C
/*     */     //   116: istore_1
/*     */     //   117: goto -> 78
/*     */     //   120: aload #5
/*     */     //   122: putstatic net/portswigger/infiltrator/patcher/o.g : [Ljava/lang/String;
/*     */     //   125: bipush #26
/*     */     //   127: anewarray java/lang/String
/*     */     //   130: putstatic net/portswigger/infiltrator/patcher/o.h : [Ljava/lang/String;
/*     */     //   133: goto -> 275
/*     */     //   136: astore #6
/*     */     //   138: invokevirtual toCharArray : ()[C
/*     */     //   141: dup
/*     */     //   142: arraylength
/*     */     //   143: swap
/*     */     //   144: iconst_0
/*     */     //   145: istore #7
/*     */     //   147: swap
/*     */     //   148: dup_x1
/*     */     //   149: iconst_1
/*     */     //   150: if_icmpgt -> 253
/*     */     //   153: dup
/*     */     //   154: iload #7
/*     */     //   156: dup2
/*     */     //   157: caload
/*     */     //   158: iload #7
/*     */     //   160: bipush #7
/*     */     //   162: irem
/*     */     //   163: tableswitch default -> 234, 0 -> 200, 1 -> 206, 2 -> 211, 3 -> 217, 4 -> 223, 5 -> 228
/*     */     //   200: sipush #149
/*     */     //   203: goto -> 237
/*     */     //   206: bipush #25
/*     */     //   208: goto -> 237
/*     */     //   211: sipush #173
/*     */     //   214: goto -> 237
/*     */     //   217: sipush #201
/*     */     //   220: goto -> 237
/*     */     //   223: bipush #64
/*     */     //   225: goto -> 237
/*     */     //   228: sipush #149
/*     */     //   231: goto -> 237
/*     */     //   234: sipush #240
/*     */     //   237: ixor
/*     */     //   238: i2c
/*     */     //   239: castore
/*     */     //   240: iinc #7, 1
/*     */     //   243: swap
/*     */     //   244: dup_x1
/*     */     //   245: ifne -> 253
/*     */     //   248: dup2
/*     */     //   249: swap
/*     */     //   250: goto -> 156
/*     */     //   253: swap
/*     */     //   254: dup_x1
/*     */     //   255: iload #7
/*     */     //   257: if_icmpgt -> 153
/*     */     //   260: new java/lang/String
/*     */     //   263: dup_x1
/*     */     //   264: swap
/*     */     //   265: invokespecial <init> : ([C)V
/*     */     //   268: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   271: swap
/*     */     //   272: pop
/*     */     //   273: ret #6
/*     */     //   275: new java/lang/Integer
/*     */     //   278: dup
/*     */     //   279: iconst_1
/*     */     //   280: invokespecial <init> : (I)V
/*     */     //   283: putstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   286: new java/lang/Integer
/*     */     //   289: dup
/*     */     //   290: iconst_2
/*     */     //   291: invokespecial <init> : (I)V
/*     */     //   294: putstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   297: new java/lang/Integer
/*     */     //   300: dup
/*     */     //   301: iconst_3
/*     */     //   302: invokespecial <init> : (I)V
/*     */     //   305: putstatic net/portswigger/infiltrator/patcher/o.b : Ljava/lang/Integer;
/*     */     //   308: new java/util/HashMap
/*     */     //   311: dup
/*     */     //   312: invokespecial <init> : ()V
/*     */     //   315: putstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   318: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   321: sipush #-28695
/*     */     //   324: sipush #6002
/*     */     //   327: invokestatic a : (II)Ljava/lang/String;
/*     */     //   330: new net/portswigger/infiltrator/patcher/m
/*     */     //   333: dup
/*     */     //   334: getstatic net/portswigger/infiltrator/patcher/o.b : Ljava/lang/Integer;
/*     */     //   337: sipush #-28689
/*     */     //   340: sipush #-5728
/*     */     //   343: invokestatic a : (II)Ljava/lang/String;
/*     */     //   346: iconst_0
/*     */     //   347: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   350: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   355: pop
/*     */     //   356: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   359: sipush #-28682
/*     */     //   362: sipush #12651
/*     */     //   365: invokestatic a : (II)Ljava/lang/String;
/*     */     //   368: new net/portswigger/infiltrator/patcher/m
/*     */     //   371: dup
/*     */     //   372: getstatic net/portswigger/infiltrator/patcher/o.b : Ljava/lang/Integer;
/*     */     //   375: sipush #-28700
/*     */     //   378: sipush #-28393
/*     */     //   381: invokestatic a : (II)Ljava/lang/String;
/*     */     //   384: iconst_1
/*     */     //   385: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   388: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   393: pop
/*     */     //   394: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   397: sipush #-28702
/*     */     //   400: sipush #-10117
/*     */     //   403: invokestatic a : (II)Ljava/lang/String;
/*     */     //   406: new net/portswigger/infiltrator/patcher/m
/*     */     //   409: dup
/*     */     //   410: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   413: sipush #-28697
/*     */     //   416: sipush #-23960
/*     */     //   419: invokestatic a : (II)Ljava/lang/String;
/*     */     //   422: iconst_2
/*     */     //   423: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   426: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   431: pop
/*     */     //   432: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   435: sipush #-28692
/*     */     //   438: sipush #-12376
/*     */     //   441: invokestatic a : (II)Ljava/lang/String;
/*     */     //   444: new net/portswigger/infiltrator/patcher/m
/*     */     //   447: dup
/*     */     //   448: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   451: sipush #-28675
/*     */     //   454: sipush #22002
/*     */     //   457: invokestatic a : (II)Ljava/lang/String;
/*     */     //   460: iconst_3
/*     */     //   461: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   464: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   469: pop
/*     */     //   470: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   473: sipush #-28698
/*     */     //   476: sipush #1561
/*     */     //   479: invokestatic a : (II)Ljava/lang/String;
/*     */     //   482: new net/portswigger/infiltrator/patcher/m
/*     */     //   485: dup
/*     */     //   486: getstatic net/portswigger/infiltrator/patcher/o.a : Ljava/lang/Integer;
/*     */     //   489: sipush #-28691
/*     */     //   492: sipush #-31581
/*     */     //   495: invokestatic a : (II)Ljava/lang/String;
/*     */     //   498: iconst_4
/*     */     //   499: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   502: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   507: pop
/*     */     //   508: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   511: sipush #-28694
/*     */     //   514: sipush #32294
/*     */     //   517: invokestatic a : (II)Ljava/lang/String;
/*     */     //   520: new net/portswigger/infiltrator/patcher/m
/*     */     //   523: dup
/*     */     //   524: getstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   527: sipush #-28676
/*     */     //   530: sipush #-5183
/*     */     //   533: invokestatic a : (II)Ljava/lang/String;
/*     */     //   536: iconst_5
/*     */     //   537: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   540: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   545: pop
/*     */     //   546: getstatic net/portswigger/infiltrator/patcher/o.c : Ljava/util/Map;
/*     */     //   549: sipush #-28678
/*     */     //   552: sipush #21711
/*     */     //   555: invokestatic a : (II)Ljava/lang/String;
/*     */     //   558: new net/portswigger/infiltrator/patcher/m
/*     */     //   561: dup
/*     */     //   562: getstatic net/portswigger/infiltrator/patcher/o.e : Ljava/lang/Integer;
/*     */     //   565: sipush #-28696
/*     */     //   568: sipush #-6466
/*     */     //   571: invokestatic a : (II)Ljava/lang/String;
/*     */     //   574: bipush #6
/*     */     //   576: invokespecial <init> : (Ljava/lang/Integer;Ljava/lang/String;I)V
/*     */     //   579: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   584: pop
/*     */     //   585: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #13	-> 275
/*     */     //   #14	-> 286
/*     */     //   #15	-> 297
/*     */     //   #31	-> 308
/*     */     //   #32	-> 318
/*     */     //   #33	-> 356
/*     */     //   #34	-> 394
/*     */     //   #35	-> 432
/*     */     //   #36	-> 470
/*     */     //   #37	-> 508
/*     */     //   #38	-> 546
/*     */     //   #39	-> 585
/*     */   }
/*     */   
/*     */   private static String a(int paramInt1, int paramInt2) {
/*     */     int i = (paramInt1 ^ 0xFFFF8FEF) & 0xFFFF;
/*     */     if (h[i] == null) {
/*     */       char[] arrayOfChar = g[i].toCharArray();
/*     */       switch (arrayOfChar[0] & 0xFF) {
/*     */         case 0:
/*     */         
/*     */         case 1:
/*     */         
/*     */         case 2:
/*     */         
/*     */         case 3:
/*     */         
/*     */         case 4:
/*     */         
/*     */         case 5:
/*     */         
/*     */         case 6:
/*     */         
/*     */         case 7:
/*     */         
/*     */         case 8:
/*     */         
/*     */         case 9:
/*     */         
/*     */         case 10:
/*     */         
/*     */         case 11:
/*     */         
/*     */         case 12:
/*     */         
/*     */         case 13:
/*     */         
/*     */         case 14:
/*     */         
/*     */         case 15:
/*     */         
/*     */         case 16:
/*     */         
/*     */         case 17:
/*     */         
/*     */         case 18:
/*     */         
/*     */         case 19:
/*     */         
/*     */         case 20:
/*     */         
/*     */         case 21:
/*     */         
/*     */         case 22:
/*     */         
/*     */         case 23:
/*     */         
/*     */         case 24:
/*     */         
/*     */         case 25:
/*     */         
/*     */         case 26:
/*     */         
/*     */         case 27:
/*     */         
/*     */         case 28:
/*     */         
/*     */         case 29:
/*     */         
/*     */         case 30:
/*     */         
/*     */         case 31:
/*     */         
/*     */         case 32:
/*     */         
/*     */         case 33:
/*     */         
/*     */         case 34:
/*     */         
/*     */         case 35:
/*     */         
/*     */         case 36:
/*     */         
/*     */         case 37:
/*     */         
/*     */         case 38:
/*     */         
/*     */         case 39:
/*     */         
/*     */         case 40:
/*     */         
/*     */         case 41:
/*     */         
/*     */         case 42:
/*     */         
/*     */         case 43:
/*     */         
/*     */         case 44:
/*     */         
/*     */         case 45:
/*     */         
/*     */         case 46:
/*     */         
/*     */         case 47:
/*     */         
/*     */         case 48:
/*     */         
/*     */         case 49:
/*     */         
/*     */         case 50:
/*     */         
/*     */         case 51:
/*     */         
/*     */         case 52:
/*     */         
/*     */         case 53:
/*     */         
/*     */         case 54:
/*     */         
/*     */         case 55:
/*     */         
/*     */         case 56:
/*     */         
/*     */         case 57:
/*     */         
/*     */         case 58:
/*     */         
/*     */         case 59:
/*     */         
/*     */         case 60:
/*     */         
/*     */         case 61:
/*     */         
/*     */         case 62:
/*     */         
/*     */         case 63:
/*     */         
/*     */         case 64:
/*     */         
/*     */         case 65:
/*     */         
/*     */         case 66:
/*     */         
/*     */         case 67:
/*     */         
/*     */         case 68:
/*     */         
/*     */         case 69:
/*     */         
/*     */         case 70:
/*     */         
/*     */         case 71:
/*     */         
/*     */         case 72:
/*     */         
/*     */         case 73:
/*     */         
/*     */         case 74:
/*     */         
/*     */         case 75:
/*     */         
/*     */         case 76:
/*     */         
/*     */         case 77:
/*     */         
/*     */         case 78:
/*     */         
/*     */         case 79:
/*     */         
/*     */         case 80:
/*     */         
/*     */         case 81:
/*     */         
/*     */         case 82:
/*     */         
/*     */         case 83:
/*     */         
/*     */         case 84:
/*     */         
/*     */         case 85:
/*     */         
/*     */         case 86:
/*     */         
/*     */         case 87:
/*     */         
/*     */         case 88:
/*     */         
/*     */         case 89:
/*     */         
/*     */         case 90:
/*     */         
/*     */         case 91:
/*     */         
/*     */         case 92:
/*     */         
/*     */         case 93:
/*     */         
/*     */         case 94:
/*     */         
/*     */         case 95:
/*     */         
/*     */         case 96:
/*     */         
/*     */         case 97:
/*     */         
/*     */         case 98:
/*     */         
/*     */         case 99:
/*     */         
/*     */         case 100:
/*     */         
/*     */         case 101:
/*     */         
/*     */         case 102:
/*     */         
/*     */         case 103:
/*     */         
/*     */         case 104:
/*     */         
/*     */         case 105:
/*     */         
/*     */         case 106:
/*     */         
/*     */         case 107:
/*     */         
/*     */         case 108:
/*     */         
/*     */         case 109:
/*     */         
/*     */         case 110:
/*     */         
/*     */         case 111:
/*     */         
/*     */         case 112:
/*     */         
/*     */         case 113:
/*     */         
/*     */         case 114:
/*     */         
/*     */         case 115:
/*     */         
/*     */         case 116:
/*     */         
/*     */         case 117:
/*     */         
/*     */         case 118:
/*     */         
/*     */         case 119:
/*     */         
/*     */         case 120:
/*     */         
/*     */         case 121:
/*     */         
/*     */         case 122:
/*     */         
/*     */         case 123:
/*     */         
/*     */         case 124:
/*     */         
/*     */         case 125:
/*     */         
/*     */         case 126:
/*     */         
/*     */         case 127:
/*     */         
/*     */         case 128:
/*     */         
/*     */         case 129:
/*     */         
/*     */         case 130:
/*     */         
/*     */         case 131:
/*     */         
/*     */         case 132:
/*     */         
/*     */         case 133:
/*     */         
/*     */         case 134:
/*     */         
/*     */         case 135:
/*     */         
/*     */         case 136:
/*     */         
/*     */         case 137:
/*     */         
/*     */         case 138:
/*     */         
/*     */         case 139:
/*     */         
/*     */         case 140:
/*     */         
/*     */         case 141:
/*     */         
/*     */         case 142:
/*     */         
/*     */         case 143:
/*     */         
/*     */         case 144:
/*     */         
/*     */         case 145:
/*     */         
/*     */         case 146:
/*     */         
/*     */         case 147:
/*     */         
/*     */         case 148:
/*     */         
/*     */         case 149:
/*     */         
/*     */         case 150:
/*     */         
/*     */         case 151:
/*     */         
/*     */         case 152:
/*     */         
/*     */         case 153:
/*     */         
/*     */         case 154:
/*     */         
/*     */         case 155:
/*     */         
/*     */         case 156:
/*     */         
/*     */         case 157:
/*     */         
/*     */         case 158:
/*     */         
/*     */         case 159:
/*     */         
/*     */         case 160:
/*     */         
/*     */         case 161:
/*     */         
/*     */         case 162:
/*     */         
/*     */         case 163:
/*     */         
/*     */         case 164:
/*     */         
/*     */         case 165:
/*     */         
/*     */         case 166:
/*     */         
/*     */         case 167:
/*     */         
/*     */         case 168:
/*     */         
/*     */         case 169:
/*     */         
/*     */         case 170:
/*     */         
/*     */         case 171:
/*     */         
/*     */         case 172:
/*     */         
/*     */         case 173:
/*     */         
/*     */         case 174:
/*     */         
/*     */         case 175:
/*     */         
/*     */         case 176:
/*     */         
/*     */         case 177:
/*     */         
/*     */         case 178:
/*     */         
/*     */         case 179:
/*     */         
/*     */         case 180:
/*     */         
/*     */         case 181:
/*     */         
/*     */         case 182:
/*     */         
/*     */         case 183:
/*     */         
/*     */         case 184:
/*     */         
/*     */         case 185:
/*     */         
/*     */         case 186:
/*     */         
/*     */         case 187:
/*     */         
/*     */         case 188:
/*     */         
/*     */         case 189:
/*     */         
/*     */         case 190:
/*     */         
/*     */         case 191:
/*     */         
/*     */         case 192:
/*     */         
/*     */         case 193:
/*     */         
/*     */         case 194:
/*     */         
/*     */         case 195:
/*     */         
/*     */         case 196:
/*     */         
/*     */         case 197:
/*     */         
/*     */         case 198:
/*     */         
/*     */         case 199:
/*     */         
/*     */         case 200:
/*     */         
/*     */         case 201:
/*     */         
/*     */         case 202:
/*     */         
/*     */         case 203:
/*     */         
/*     */         case 204:
/*     */         
/*     */         case 205:
/*     */         
/*     */         case 206:
/*     */         
/*     */         case 207:
/*     */         
/*     */         case 208:
/*     */         
/*     */         case 209:
/*     */         
/*     */         case 210:
/*     */         
/*     */         case 211:
/*     */         
/*     */         case 212:
/*     */         
/*     */         case 213:
/*     */         
/*     */         case 214:
/*     */         
/*     */         case 215:
/*     */         
/*     */         case 216:
/*     */         
/*     */         case 217:
/*     */         
/*     */         case 218:
/*     */         
/*     */         case 219:
/*     */         
/*     */         case 220:
/*     */         
/*     */         case 221:
/*     */         
/*     */         case 222:
/*     */         
/*     */         case 223:
/*     */         
/*     */         case 224:
/*     */         
/*     */         case 225:
/*     */         
/*     */         case 226:
/*     */         
/*     */         case 227:
/*     */         
/*     */         case 228:
/*     */         
/*     */         case 229:
/*     */         
/*     */         case 230:
/*     */         
/*     */         case 231:
/*     */         
/*     */         case 232:
/*     */         
/*     */         case 233:
/*     */         
/*     */         case 234:
/*     */         
/*     */         case 235:
/*     */         
/*     */         case 236:
/*     */         
/*     */         case 237:
/*     */         
/*     */         case 238:
/*     */         
/*     */         case 239:
/*     */         
/*     */         case 240:
/*     */         
/*     */         case 241:
/*     */         
/*     */         case 242:
/*     */         
/*     */         case 243:
/*     */         
/*     */         case 244:
/*     */         
/*     */         case 245:
/*     */         
/*     */         case 246:
/*     */         
/*     */         case 247:
/*     */         
/*     */         case 248:
/*     */         
/*     */         case 249:
/*     */         
/*     */         case 250:
/*     */         
/*     */         case 251:
/*     */         
/*     */         case 252:
/*     */         
/*     */         case 253:
/*     */         
/*     */         case 254:
/*     */         
/*     */         default:
/*     */           break;
/*     */       } 
/*     */       char c = 'Û';
/*     */       int j = (paramInt2 & 0xFF) - c;
/*     */       if (j < 0)
/*     */         j += 256; 
/*     */       int m = ((paramInt2 & 0xFFFF) >>> 8) - c;
/*     */       if (m < 0)
/*     */         m += 256; 
/*     */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*     */         int n = b % 2;
/*     */         if (n == 0) {
/*     */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
/*     */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
/*     */         } else {
/*     */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ m);
/*     */           m = ((m >>> 3 | m << 5) ^ arrayOfChar[b]) & 0xFF;
/*     */         } 
/*     */       } 
/*     */       h[i] = (new String(arrayOfChar)).intern();
/*     */     } 
/*     */     return h[i];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\o.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */