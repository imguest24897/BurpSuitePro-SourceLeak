/*     */ package net.portswigger.infiltrator.patcher;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.objectweb.asm.ClassVisitor;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class i
/*     */   extends ClassVisitor
/*     */ {
/*     */   final List c;
/*     */   static final boolean a;
/*     */   
/*     */   i(ClassVisitor paramClassVisitor, List paramList) {
/* 106 */     super(327680, paramClassVisitor);
/* 107 */     this.c = paramList;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
/* 112 */     this.c.add(new u(paramString1, paramInt, a(paramString2), b(paramString2), paramString2));
/* 113 */     return super.visitMethod(paramInt, paramString1, paramString2, paramString3, paramArrayOfString);
/*     */   }
/*     */   
/*     */   private String b(String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: aload_1
/*     */     //   4: ldc ')'
/*     */     //   6: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   9: istore_3
/*     */     //   10: istore_2
/*     */     //   11: getstatic net/portswigger/infiltrator/patcher/i.a : Z
/*     */     //   14: iload_2
/*     */     //   15: ifne -> 22
/*     */     //   18: ifne -> 52
/*     */     //   21: iload_3
/*     */     //   22: iconst_m1
/*     */     //   23: iload_2
/*     */     //   24: ifne -> 41
/*     */     //   27: if_icmpeq -> 44
/*     */     //   30: aload_1
/*     */     //   31: iload_2
/*     */     //   32: ifne -> 59
/*     */     //   35: invokevirtual length : ()I
/*     */     //   38: iload_3
/*     */     //   39: iconst_1
/*     */     //   40: iadd
/*     */     //   41: if_icmpgt -> 52
/*     */     //   44: new java/lang/AssertionError
/*     */     //   47: dup
/*     */     //   48: invokespecial <init> : ()V
/*     */     //   51: athrow
/*     */     //   52: aload_1
/*     */     //   53: iload_3
/*     */     //   54: iconst_1
/*     */     //   55: iadd
/*     */     //   56: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   59: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #118	-> 3
/*     */     //   #119	-> 11
/*     */     //   #120	-> 52
/*     */   }
/*     */   
/*     */   private String a(String paramString) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*     */     //   3: istore_2
/*     */     //   4: getstatic net/portswigger/infiltrator/patcher/i.a : Z
/*     */     //   7: iload_2
/*     */     //   8: ifne -> 20
/*     */     //   11: ifne -> 48
/*     */     //   14: aload_1
/*     */     //   15: ldc ')'
/*     */     //   17: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   20: iconst_m1
/*     */     //   21: iload_2
/*     */     //   22: ifne -> 37
/*     */     //   25: if_icmpeq -> 40
/*     */     //   28: aload_1
/*     */     //   29: iload_2
/*     */     //   30: ifne -> 59
/*     */     //   33: invokevirtual length : ()I
/*     */     //   36: iconst_1
/*     */     //   37: if_icmpgt -> 48
/*     */     //   40: new java/lang/AssertionError
/*     */     //   43: dup
/*     */     //   44: invokespecial <init> : ()V
/*     */     //   47: athrow
/*     */     //   48: aload_1
/*     */     //   49: iconst_1
/*     */     //   50: aload_1
/*     */     //   51: ldc ')'
/*     */     //   53: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   56: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   59: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #125	-> 4
/*     */     //   #126	-> 48
/*     */   }
/*     */   
/*     */   static {
/*     */     // Byte code:
/*     */     //   0: ldc 'XSA×O NPÀG·\\rNÁI¾OFÈRü\S\\fÏE QN'
/*     */     //   2: jsr -> 9
/*     */     //   5: astore_0
/*     */     //   6: goto -> 143
/*     */     //   9: astore_1
/*     */     //   10: invokevirtual toCharArray : ()[C
/*     */     //   13: dup
/*     */     //   14: arraylength
/*     */     //   15: swap
/*     */     //   16: iconst_0
/*     */     //   17: istore_2
/*     */     //   18: swap
/*     */     //   19: dup_x1
/*     */     //   20: iconst_1
/*     */     //   21: if_icmpgt -> 122
/*     */     //   24: dup
/*     */     //   25: iload_2
/*     */     //   26: dup2
/*     */     //   27: caload
/*     */     //   28: iload_2
/*     */     //   29: bipush #7
/*     */     //   31: irem
/*     */     //   32: tableswitch default -> 103, 0 -> 72, 1 -> 77, 2 -> 82, 3 -> 87, 4 -> 92, 5 -> 98
/*     */     //   72: bipush #127
/*     */     //   74: goto -> 106
/*     */     //   77: bipush #61
/*     */     //   79: goto -> 106
/*     */     //   82: bipush #39
/*     */     //   84: goto -> 106
/*     */     //   87: bipush #111
/*     */     //   89: goto -> 106
/*     */     //   92: sipush #167
/*     */     //   95: goto -> 106
/*     */     //   98: bipush #32
/*     */     //   100: goto -> 106
/*     */     //   103: sipush #210
/*     */     //   106: ixor
/*     */     //   107: i2c
/*     */     //   108: castore
/*     */     //   109: iinc #2, 1
/*     */     //   112: swap
/*     */     //   113: dup_x1
/*     */     //   114: ifne -> 122
/*     */     //   117: dup2
/*     */     //   118: swap
/*     */     //   119: goto -> 26
/*     */     //   122: swap
/*     */     //   123: dup_x1
/*     */     //   124: iload_2
/*     */     //   125: if_icmpgt -> 24
/*     */     //   128: new java/lang/String
/*     */     //   131: dup_x1
/*     */     //   132: swap
/*     */     //   133: invokespecial <init> : ([C)V
/*     */     //   136: invokevirtual intern : ()Ljava/lang/String;
/*     */     //   139: swap
/*     */     //   140: pop
/*     */     //   141: ret #1
/*     */     //   143: getstatic net/portswigger/infiltrator/patcher/s.b : Ljava/lang/Class;
/*     */     //   146: ifnonnull -> 160
/*     */     //   149: aload_0
/*     */     //   150: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   153: dup
/*     */     //   154: putstatic net/portswigger/infiltrator/patcher/s.b : Ljava/lang/Class;
/*     */     //   157: goto -> 163
/*     */     //   160: getstatic net/portswigger/infiltrator/patcher/s.b : Ljava/lang/Class;
/*     */     //   163: invokevirtual desiredAssertionStatus : ()Z
/*     */     //   166: ifne -> 173
/*     */     //   169: iconst_1
/*     */     //   170: goto -> 174
/*     */     //   173: iconst_0
/*     */     //   174: putstatic net/portswigger/infiltrator/patcher/i.a : Z
/*     */     //   177: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #100	-> 143
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\i.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */