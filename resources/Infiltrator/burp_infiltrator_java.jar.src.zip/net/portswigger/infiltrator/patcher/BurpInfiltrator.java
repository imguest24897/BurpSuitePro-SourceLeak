/*    */ package net.portswigger.infiltrator.patcher;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ public class BurpInfiltrator {
/*    */   private static final List a;
/*    */   static Class b;
/*    */   static Class c;
/*    */   private static final String[] d;
/*    */   private static final String[] e;
/*    */   
/*    */   static Class a(String paramString) {
/*    */     
/* 13 */     try { return Class.forName(a.a(paramString)); } catch (ClassNotFoundException classNotFoundException) { throw (new NoClassDefFoundError()).initCause(classNotFoundException); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 22 */     o o = new o(paramArrayOfString); boolean bool = w.e; try {
/* 23 */       if (!bool) { try { if (!o.c())
/*    */           {
/* 25 */             a(); }  } catch (RuntimeException runtimeException)
/*    */         { throw null; }
/*    */         
/* 28 */         a(paramArrayOfString); }
/*    */     
/*    */     } catch (RuntimeException runtimeException) {
/*    */       throw null;
/*    */     }  } public static void a(String[] paramArrayOfString) {
/* 33 */     k k = null; boolean bool = w.e;
/*    */ 
/*    */ 
/*    */     
/* 37 */     try { o o = new o(paramArrayOfString); 
/* 38 */       try { if (!bool) try { if (o.c())
/*    */             
/*    */             {  }
/*    */             
/*    */             else
/*    */             
/* 44 */             { k = (new c()).c();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */               
/* 53 */               (new e(new v(k))).a(k); }  } catch (RuntimeException runtimeException) { throw null; }   } catch (RuntimeException runtimeException) { throw null; }  k = o.e(); } catch (RuntimeException runtimeException) { System.err.println(a(6322, -15177) + runtimeException.getMessage()); System.exit(1); }  (new e(new v(k))).a(k);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void a() {
/* 60 */     boolean bool = w.e; try { try { if (!bool) try {  } catch (NoSuchMethodException noSuchMethodException) { throw null; }   } catch (NoSuchMethodException noSuchMethodException) { throw null; }  if (((c == null) ? (c = a(a(6330, 15972))) : c).getMethod(a(6324, 23515), null).invoke(null, null) == null)
/*    */       {
/* 62 */         JFrame jFrame = new JFrame();
/* 63 */         jFrame.setIconImages(a);
/*    */         
/* 65 */         JOptionPane.showOptionDialog(jFrame, a(6325, -22982), a(6323, 26428), 0, 2, null, (Object[])new String[] { a(6329, -20680) }null);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 75 */         System.exit(0);
/*    */       }
/*    */        }
/* 78 */     catch (NoSuchMethodException noSuchMethodException)
/*    */     
/*    */     {  }
/* 81 */     catch (IllegalAccessException illegalAccessException)
/*    */     
/*    */     {  }
/* 84 */     catch (InvocationTargetException invocationTargetException) {}
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: bipush #12
/*    */     //   2: anewarray java/lang/String
/*    */     //   5: astore #5
/*    */     //   7: iconst_0
/*    */     //   8: istore_3
/*    */     //   9: ldc 'Ü\\r[VD Ýú¨èÕaÙÒ¬ØWsßÉ;ÎH³¿ÊäaKäyÿÕ~³Hµ¡¡eÛ©Ò½@.£,ÿ/.&[8Æµ"ûµÒp¸ÔÛÂ×ùß~¸;çÌvØåZéèï¹¶?*Óíàã,$Niî\\nñB­ðS¨SâE6»þò£¼cöß$^¬bN&Ú\\rÒ²«+½uÓVÊ/w3¾roî¤2Ù÷gßásT\!C)cÑ}õ¦(Ïm\\r;!ðSí§\\n|[À@'
/*    */     //   11: dup
/*    */     //   12: astore_2
/*    */     //   13: invokevirtual length : ()I
/*    */     //   16: istore #4
/*    */     //   18: bipush #22
/*    */     //   20: istore_1
/*    */     //   21: iconst_m1
/*    */     //   22: istore_0
/*    */     //   23: iinc #0, 1
/*    */     //   26: aload_2
/*    */     //   27: iload_0
/*    */     //   28: dup
/*    */     //   29: iload_1
/*    */     //   30: iadd
/*    */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   34: jsr -> 137
/*    */     //   37: aload #5
/*    */     //   39: swap
/*    */     //   40: iload_3
/*    */     //   41: iinc #3, 1
/*    */     //   44: swap
/*    */     //   45: aastore
/*    */     //   46: iload_0
/*    */     //   47: iload_1
/*    */     //   48: iadd
/*    */     //   49: dup
/*    */     //   50: istore_0
/*    */     //   51: iload #4
/*    */     //   53: if_icmpge -> 65
/*    */     //   56: aload_2
/*    */     //   57: iload_0
/*    */     //   58: invokevirtual charAt : (I)C
/*    */     //   61: istore_1
/*    */     //   62: goto -> 23
/*    */     //   65: ldc '0IÆÞ÷±íÿ4ìØ`°Äþ4û@øò®<AzµÖ9æ['
/*    */     //   67: dup
/*    */     //   68: astore_2
/*    */     //   69: invokevirtual length : ()I
/*    */     //   72: istore #4
/*    */     //   74: bipush #21
/*    */     //   76: istore_1
/*    */     //   77: iconst_m1
/*    */     //   78: istore_0
/*    */     //   79: iinc #0, 1
/*    */     //   82: aload_2
/*    */     //   83: iload_0
/*    */     //   84: dup
/*    */     //   85: iload_1
/*    */     //   86: iadd
/*    */     //   87: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   90: jsr -> 137
/*    */     //   93: aload #5
/*    */     //   95: swap
/*    */     //   96: iload_3
/*    */     //   97: iinc #3, 1
/*    */     //   100: swap
/*    */     //   101: aastore
/*    */     //   102: iload_0
/*    */     //   103: iload_1
/*    */     //   104: iadd
/*    */     //   105: dup
/*    */     //   106: istore_0
/*    */     //   107: iload #4
/*    */     //   109: if_icmpge -> 121
/*    */     //   112: aload_2
/*    */     //   113: iload_0
/*    */     //   114: invokevirtual charAt : (I)C
/*    */     //   117: istore_1
/*    */     //   118: goto -> 79
/*    */     //   121: aload #5
/*    */     //   123: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.d : [Ljava/lang/String;
/*    */     //   126: bipush #12
/*    */     //   128: anewarray java/lang/String
/*    */     //   131: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.e : [Ljava/lang/String;
/*    */     //   134: goto -> 278
/*    */     //   137: astore #6
/*    */     //   139: invokevirtual toCharArray : ()[C
/*    */     //   142: dup
/*    */     //   143: arraylength
/*    */     //   144: swap
/*    */     //   145: iconst_0
/*    */     //   146: istore #7
/*    */     //   148: swap
/*    */     //   149: dup_x1
/*    */     //   150: iconst_1
/*    */     //   151: if_icmpgt -> 256
/*    */     //   154: dup
/*    */     //   155: iload #7
/*    */     //   157: dup2
/*    */     //   158: caload
/*    */     //   159: iload #7
/*    */     //   161: bipush #7
/*    */     //   163: irem
/*    */     //   164: tableswitch default -> 238, 0 -> 204, 1 -> 209, 2 -> 215, 3 -> 221, 4 -> 226, 5 -> 232
/*    */     //   204: bipush #44
/*    */     //   206: goto -> 240
/*    */     //   209: sipush #255
/*    */     //   212: goto -> 240
/*    */     //   215: sipush #234
/*    */     //   218: goto -> 240
/*    */     //   221: bipush #71
/*    */     //   223: goto -> 240
/*    */     //   226: sipush #212
/*    */     //   229: goto -> 240
/*    */     //   232: sipush #234
/*    */     //   235: goto -> 240
/*    */     //   238: bipush #121
/*    */     //   240: ixor
/*    */     //   241: i2c
/*    */     //   242: castore
/*    */     //   243: iinc #7, 1
/*    */     //   246: swap
/*    */     //   247: dup_x1
/*    */     //   248: ifne -> 256
/*    */     //   251: dup2
/*    */     //   252: swap
/*    */     //   253: goto -> 157
/*    */     //   256: swap
/*    */     //   257: dup_x1
/*    */     //   258: iload #7
/*    */     //   260: if_icmpgt -> 154
/*    */     //   263: new java/lang/String
/*    */     //   266: dup_x1
/*    */     //   267: swap
/*    */     //   268: invokespecial <init> : ([C)V
/*    */     //   271: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   274: swap
/*    */     //   275: pop
/*    */     //   276: ret #6
/*    */     //   278: iconst_5
/*    */     //   279: anewarray java/awt/Image
/*    */     //   282: dup
/*    */     //   283: iconst_0
/*    */     //   284: new javax/swing/ImageIcon
/*    */     //   287: dup
/*    */     //   288: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   291: ifnonnull -> 314
/*    */     //   294: sipush #6328
/*    */     //   297: sipush #-9490
/*    */     //   300: invokestatic a : (II)Ljava/lang/String;
/*    */     //   303: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   306: dup
/*    */     //   307: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   310: goto -> 317
/*    */     //   313: athrow
/*    */     //   314: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   317: sipush #6320
/*    */     //   320: sipush #-27604
/*    */     //   323: invokestatic a : (II)Ljava/lang/String;
/*    */     //   326: invokevirtual getResource : (Ljava/lang/String;)Ljava/net/URL;
/*    */     //   329: invokespecial <init> : (Ljava/net/URL;)V
/*    */     //   332: invokevirtual getImage : ()Ljava/awt/Image;
/*    */     //   335: aastore
/*    */     //   336: dup
/*    */     //   337: iconst_1
/*    */     //   338: new javax/swing/ImageIcon
/*    */     //   341: dup
/*    */     //   342: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   345: ifnonnull -> 367
/*    */     //   348: sipush #6328
/*    */     //   351: sipush #-9490
/*    */     //   354: invokestatic a : (II)Ljava/lang/String;
/*    */     //   357: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   360: dup
/*    */     //   361: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   364: goto -> 370
/*    */     //   367: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   370: sipush #6327
/*    */     //   373: sipush #26593
/*    */     //   376: invokestatic a : (II)Ljava/lang/String;
/*    */     //   379: invokevirtual getResource : (Ljava/lang/String;)Ljava/net/URL;
/*    */     //   382: invokespecial <init> : (Ljava/net/URL;)V
/*    */     //   385: invokevirtual getImage : ()Ljava/awt/Image;
/*    */     //   388: aastore
/*    */     //   389: dup
/*    */     //   390: iconst_2
/*    */     //   391: new javax/swing/ImageIcon
/*    */     //   394: dup
/*    */     //   395: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   398: ifnonnull -> 420
/*    */     //   401: sipush #6328
/*    */     //   404: sipush #-9490
/*    */     //   407: invokestatic a : (II)Ljava/lang/String;
/*    */     //   410: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   413: dup
/*    */     //   414: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   417: goto -> 423
/*    */     //   420: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   423: sipush #6331
/*    */     //   426: sipush #-10426
/*    */     //   429: invokestatic a : (II)Ljava/lang/String;
/*    */     //   432: invokevirtual getResource : (Ljava/lang/String;)Ljava/net/URL;
/*    */     //   435: invokespecial <init> : (Ljava/net/URL;)V
/*    */     //   438: invokevirtual getImage : ()Ljava/awt/Image;
/*    */     //   441: aastore
/*    */     //   442: dup
/*    */     //   443: iconst_3
/*    */     //   444: new javax/swing/ImageIcon
/*    */     //   447: dup
/*    */     //   448: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   451: ifnonnull -> 473
/*    */     //   454: sipush #6328
/*    */     //   457: sipush #-9490
/*    */     //   460: invokestatic a : (II)Ljava/lang/String;
/*    */     //   463: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   466: dup
/*    */     //   467: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   470: goto -> 476
/*    */     //   473: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   476: sipush #6326
/*    */     //   479: sipush #-12019
/*    */     //   482: invokestatic a : (II)Ljava/lang/String;
/*    */     //   485: invokevirtual getResource : (Ljava/lang/String;)Ljava/net/URL;
/*    */     //   488: invokespecial <init> : (Ljava/net/URL;)V
/*    */     //   491: invokevirtual getImage : ()Ljava/awt/Image;
/*    */     //   494: aastore
/*    */     //   495: dup
/*    */     //   496: iconst_4
/*    */     //   497: new javax/swing/ImageIcon
/*    */     //   500: dup
/*    */     //   501: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   504: ifnonnull -> 526
/*    */     //   507: sipush #6328
/*    */     //   510: sipush #-9490
/*    */     //   513: invokestatic a : (II)Ljava/lang/String;
/*    */     //   516: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   519: dup
/*    */     //   520: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   523: goto -> 529
/*    */     //   526: getstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.b : Ljava/lang/Class;
/*    */     //   529: sipush #6321
/*    */     //   532: sipush #10632
/*    */     //   535: invokestatic a : (II)Ljava/lang/String;
/*    */     //   538: invokevirtual getResource : (Ljava/lang/String;)Ljava/net/URL;
/*    */     //   541: invokespecial <init> : (Ljava/net/URL;)V
/*    */     //   544: invokevirtual getImage : ()Ljava/awt/Image;
/*    */     //   547: aastore
/*    */     //   548: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
/*    */     //   551: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
/*    */     //   554: putstatic net/portswigger/infiltrator/patcher/BurpInfiltrator.a : Ljava/util/List;
/*    */     //   557: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #12	-> 278
/*    */     //   #13	-> 303
/*    */     //   #14	-> 357
/*    */     //   #15	-> 410
/*    */     //   #16	-> 463
/*    */     //   #17	-> 516
/*    */     //   #12	-> 548
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   278	313	313	java/lang/RuntimeException
/*    */   }
/*    */   
/*    */   private static String a(int paramInt1, int paramInt2) {
/*    */     int i = (paramInt1 ^ 0x18B1) & 0xFFFF;
/*    */     if (e[i] == null) {
/*    */       char[] arrayOfChar = d[i].toCharArray();
/*    */       switch (arrayOfChar[0] & 0xFF) {
/*    */         case 0:
/*    */         
/*    */         case 1:
/*    */         
/*    */         case 2:
/*    */         
/*    */         case 3:
/*    */         
/*    */         case 4:
/*    */         
/*    */         case 5:
/*    */         
/*    */         case 6:
/*    */         
/*    */         case 7:
/*    */         
/*    */         case 8:
/*    */         
/*    */         case 9:
/*    */         
/*    */         case 10:
/*    */         
/*    */         case 11:
/*    */         
/*    */         case 12:
/*    */         
/*    */         case 13:
/*    */         
/*    */         case 14:
/*    */         
/*    */         case 15:
/*    */         
/*    */         case 16:
/*    */         
/*    */         case 17:
/*    */         
/*    */         case 18:
/*    */         
/*    */         case 19:
/*    */         
/*    */         case 20:
/*    */         
/*    */         case 21:
/*    */         
/*    */         case 22:
/*    */         
/*    */         case 23:
/*    */         
/*    */         case 24:
/*    */         
/*    */         case 25:
/*    */         
/*    */         case 26:
/*    */         
/*    */         case 27:
/*    */         
/*    */         case 28:
/*    */         
/*    */         case 29:
/*    */         
/*    */         case 30:
/*    */         
/*    */         case 31:
/*    */         
/*    */         case 32:
/*    */         
/*    */         case 33:
/*    */         
/*    */         case 34:
/*    */         
/*    */         case 35:
/*    */         
/*    */         case 36:
/*    */         
/*    */         case 37:
/*    */         
/*    */         case 38:
/*    */         
/*    */         case 39:
/*    */         
/*    */         case 40:
/*    */         
/*    */         case 41:
/*    */         
/*    */         case 42:
/*    */         
/*    */         case 43:
/*    */         
/*    */         case 44:
/*    */         
/*    */         case 45:
/*    */         
/*    */         case 46:
/*    */         
/*    */         case 47:
/*    */         
/*    */         case 48:
/*    */         
/*    */         case 49:
/*    */         
/*    */         case 50:
/*    */         
/*    */         case 51:
/*    */         
/*    */         case 52:
/*    */         
/*    */         case 53:
/*    */         
/*    */         case 54:
/*    */         
/*    */         case 55:
/*    */         
/*    */         case 56:
/*    */         
/*    */         case 57:
/*    */         
/*    */         case 58:
/*    */         
/*    */         case 59:
/*    */         
/*    */         case 60:
/*    */         
/*    */         case 61:
/*    */         
/*    */         case 62:
/*    */         
/*    */         case 63:
/*    */         
/*    */         case 64:
/*    */         
/*    */         case 65:
/*    */         
/*    */         case 66:
/*    */         
/*    */         case 67:
/*    */         
/*    */         case 68:
/*    */         
/*    */         case 69:
/*    */         
/*    */         case 70:
/*    */         
/*    */         case 71:
/*    */         
/*    */         case 72:
/*    */         
/*    */         case 73:
/*    */         
/*    */         case 74:
/*    */         
/*    */         case 75:
/*    */         
/*    */         case 76:
/*    */         
/*    */         case 77:
/*    */         
/*    */         case 78:
/*    */         
/*    */         case 79:
/*    */         
/*    */         case 80:
/*    */         
/*    */         case 81:
/*    */         
/*    */         case 82:
/*    */         
/*    */         case 83:
/*    */         
/*    */         case 84:
/*    */         
/*    */         case 85:
/*    */         
/*    */         case 86:
/*    */         
/*    */         case 87:
/*    */         
/*    */         case 88:
/*    */         
/*    */         case 89:
/*    */         
/*    */         case 90:
/*    */         
/*    */         case 91:
/*    */         
/*    */         case 92:
/*    */         
/*    */         case 93:
/*    */         
/*    */         case 94:
/*    */         
/*    */         case 95:
/*    */         
/*    */         case 96:
/*    */         
/*    */         case 97:
/*    */         
/*    */         case 98:
/*    */         
/*    */         case 99:
/*    */         
/*    */         case 100:
/*    */         
/*    */         case 101:
/*    */         
/*    */         case 102:
/*    */         
/*    */         case 103:
/*    */         
/*    */         case 104:
/*    */         
/*    */         case 105:
/*    */         
/*    */         case 106:
/*    */         
/*    */         case 107:
/*    */         
/*    */         case 108:
/*    */         
/*    */         case 109:
/*    */         
/*    */         case 110:
/*    */         
/*    */         case 111:
/*    */         
/*    */         case 112:
/*    */         
/*    */         case 113:
/*    */         
/*    */         case 114:
/*    */         
/*    */         case 115:
/*    */         
/*    */         case 116:
/*    */         
/*    */         case 117:
/*    */         
/*    */         case 118:
/*    */         
/*    */         case 119:
/*    */         
/*    */         case 120:
/*    */         
/*    */         case 121:
/*    */         
/*    */         case 122:
/*    */         
/*    */         case 123:
/*    */         
/*    */         case 124:
/*    */         
/*    */         case 125:
/*    */         
/*    */         case 126:
/*    */         
/*    */         case 127:
/*    */         
/*    */         case 128:
/*    */         
/*    */         case 129:
/*    */         
/*    */         case 130:
/*    */         
/*    */         case 131:
/*    */         
/*    */         case 132:
/*    */         
/*    */         case 133:
/*    */         
/*    */         case 134:
/*    */         
/*    */         case 135:
/*    */         
/*    */         case 136:
/*    */         
/*    */         case 137:
/*    */         
/*    */         case 138:
/*    */         
/*    */         case 139:
/*    */         
/*    */         case 140:
/*    */         
/*    */         case 141:
/*    */         
/*    */         case 142:
/*    */         
/*    */         case 143:
/*    */         
/*    */         case 144:
/*    */         
/*    */         case 145:
/*    */         
/*    */         case 146:
/*    */         
/*    */         case 147:
/*    */         
/*    */         case 148:
/*    */         
/*    */         case 149:
/*    */         
/*    */         case 150:
/*    */         
/*    */         case 151:
/*    */         
/*    */         case 152:
/*    */         
/*    */         case 153:
/*    */         
/*    */         case 154:
/*    */         
/*    */         case 155:
/*    */         
/*    */         case 156:
/*    */         
/*    */         case 157:
/*    */         
/*    */         case 158:
/*    */         
/*    */         case 159:
/*    */         
/*    */         case 160:
/*    */         
/*    */         case 161:
/*    */         
/*    */         case 162:
/*    */         
/*    */         case 163:
/*    */         
/*    */         case 164:
/*    */         
/*    */         case 165:
/*    */         
/*    */         case 166:
/*    */         
/*    */         case 167:
/*    */         
/*    */         case 168:
/*    */         
/*    */         case 169:
/*    */         
/*    */         case 170:
/*    */         
/*    */         case 171:
/*    */         
/*    */         case 172:
/*    */         
/*    */         case 173:
/*    */         
/*    */         case 174:
/*    */         
/*    */         case 175:
/*    */         
/*    */         case 176:
/*    */         
/*    */         case 177:
/*    */         
/*    */         case 178:
/*    */         
/*    */         case 179:
/*    */         
/*    */         case 180:
/*    */         
/*    */         case 181:
/*    */         
/*    */         case 182:
/*    */         
/*    */         case 183:
/*    */         
/*    */         case 184:
/*    */         
/*    */         case 185:
/*    */         
/*    */         case 186:
/*    */         
/*    */         case 187:
/*    */         
/*    */         case 188:
/*    */         
/*    */         case 189:
/*    */         
/*    */         case 190:
/*    */         
/*    */         case 191:
/*    */         
/*    */         case 192:
/*    */         
/*    */         case 193:
/*    */         
/*    */         case 194:
/*    */         
/*    */         case 195:
/*    */         
/*    */         case 196:
/*    */         
/*    */         case 197:
/*    */         
/*    */         case 198:
/*    */         
/*    */         case 199:
/*    */         
/*    */         case 200:
/*    */         
/*    */         case 201:
/*    */         
/*    */         case 202:
/*    */         
/*    */         case 203:
/*    */         
/*    */         case 204:
/*    */         
/*    */         case 205:
/*    */         
/*    */         case 206:
/*    */         
/*    */         case 207:
/*    */         
/*    */         case 208:
/*    */         
/*    */         case 209:
/*    */         
/*    */         case 210:
/*    */         
/*    */         case 211:
/*    */         
/*    */         case 212:
/*    */         
/*    */         case 213:
/*    */         
/*    */         case 214:
/*    */         
/*    */         case 215:
/*    */         
/*    */         case 216:
/*    */         
/*    */         case 217:
/*    */         
/*    */         case 218:
/*    */         
/*    */         case 219:
/*    */         
/*    */         case 220:
/*    */         
/*    */         case 221:
/*    */         
/*    */         case 222:
/*    */         
/*    */         case 223:
/*    */         
/*    */         case 224:
/*    */         
/*    */         case 225:
/*    */         
/*    */         case 226:
/*    */         
/*    */         case 227:
/*    */         
/*    */         case 228:
/*    */         
/*    */         case 229:
/*    */         
/*    */         case 230:
/*    */         
/*    */         case 231:
/*    */         
/*    */         case 232:
/*    */         
/*    */         case 233:
/*    */         
/*    */         case 234:
/*    */         
/*    */         case 235:
/*    */         
/*    */         case 236:
/*    */         
/*    */         case 237:
/*    */         
/*    */         case 238:
/*    */         
/*    */         case 239:
/*    */         
/*    */         case 240:
/*    */         
/*    */         case 241:
/*    */         
/*    */         case 242:
/*    */         
/*    */         case 243:
/*    */         
/*    */         case 244:
/*    */         
/*    */         case 245:
/*    */         
/*    */         case 246:
/*    */         
/*    */         case 247:
/*    */         
/*    */         case 248:
/*    */         
/*    */         case 249:
/*    */         
/*    */         case 250:
/*    */         
/*    */         case 251:
/*    */         
/*    */         case 252:
/*    */         
/*    */         case 253:
/*    */         
/*    */         case 254:
/*    */         
/*    */         default:
/*    */           break;
/*    */       } 
/*    */       char c = 'Û';
/*    */       int j = (paramInt2 & 0xFF) - c;
/*    */       if (j < 0)
/*    */         j += 256; 
/*    */       int k = ((paramInt2 & 0xFFFF) >>> 8) - c;
/*    */       if (k < 0)
/*    */         k += 256; 
/*    */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*    */         int m = b % 2;
/*    */         if (m == 0) {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
/*    */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } else {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ k);
/*    */           k = ((k >>> 3 | k << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } 
/*    */       } 
/*    */       e[i] = (new String(arrayOfChar)).intern();
/*    */     } 
/*    */     return e[i];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\BurpInfiltrator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */