/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class k
/*    */ {
/* 14 */   public final List a = new ArrayList();
/*    */   
/*    */   private boolean c = true;
/*    */   private boolean b = true;
/*    */   private boolean d;
/* 19 */   private final List e = new ArrayList(); private static final String[] f;
/*    */   private static final String[] g;
/*    */   
/*    */   public k() {
/* 23 */     this.a.add(System.getProperty(a(-28713, 13624)));
/*    */   }
/*    */ 
/*    */   
/*    */   public k a(boolean paramBoolean) {
/* 28 */     this.c = paramBoolean;
/* 29 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public k b(boolean paramBoolean) {
/* 34 */     this.b = paramBoolean;
/* 35 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public k c(boolean paramBoolean) {
/* 40 */     this.d = paramBoolean;
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public k a(String paramString) {
/* 46 */     boolean bool = w.e; if (!bool) if (paramString != null)
/*    */       
/*    */       {  }
/*    */       else
/*    */       
/* 51 */       { return this; }   if (!bool) if (paramString.length() != 0) {  } else { return this; }   paramString.length(); return this;
/*    */   }
/*    */   
/*    */   public k b(String paramString) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: istore_2
/*    */     //   4: aload_0
/*    */     //   5: iload_2
/*    */     //   6: ifne -> 60
/*    */     //   9: getfield a : Ljava/util/List;
/*    */     //   12: sipush #-28713
/*    */     //   15: sipush #13624
/*    */     //   18: invokestatic a : (II)Ljava/lang/String;
/*    */     //   21: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   24: invokeinterface remove : (Ljava/lang/Object;)Z
/*    */     //   29: pop
/*    */     //   30: aload_1
/*    */     //   31: ifnull -> 59
/*    */     //   34: aload_1
/*    */     //   35: invokevirtual length : ()I
/*    */     //   38: iload_2
/*    */     //   39: ifne -> 58
/*    */     //   42: ifeq -> 59
/*    */     //   45: aload_0
/*    */     //   46: getfield a : Ljava/util/List;
/*    */     //   49: aload_1
/*    */     //   50: invokevirtual trim : ()Ljava/lang/String;
/*    */     //   53: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   58: pop
/*    */     //   59: aload_0
/*    */     //   60: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #56	-> 4
/*    */     //   #58	-> 30
/*    */     //   #60	-> 45
/*    */     //   #63	-> 59
/*    */   }
/*    */   
/*    */   public String a() {
/*    */     // Byte code:
/*    */     //   0: new java/lang/StringBuffer
/*    */     //   3: dup
/*    */     //   4: invokespecial <init> : ()V
/*    */     //   7: sipush #-28715
/*    */     //   10: sipush #19940
/*    */     //   13: invokestatic a : (II)Ljava/lang/String;
/*    */     //   16: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   19: aload_0
/*    */     //   20: getfield c : Z
/*    */     //   23: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*    */     //   26: ldc '\\n'
/*    */     //   28: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   31: sipush #-28720
/*    */     //   34: sipush #-914
/*    */     //   37: invokestatic a : (II)Ljava/lang/String;
/*    */     //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   43: ldc ' '
/*    */     //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   48: aload_0
/*    */     //   49: getfield b : Z
/*    */     //   52: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*    */     //   55: ldc '\\n'
/*    */     //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   60: sipush #-28716
/*    */     //   63: sipush #-23357
/*    */     //   66: invokestatic a : (II)Ljava/lang/String;
/*    */     //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   72: ldc ' '
/*    */     //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   77: aload_0
/*    */     //   78: getfield d : Z
/*    */     //   81: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*    */     //   84: ldc '\\n'
/*    */     //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   89: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   92: astore_2
/*    */     //   93: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   96: istore_1
/*    */     //   97: aload_0
/*    */     //   98: getfield e : Ljava/util/List;
/*    */     //   101: invokeinterface isEmpty : ()Z
/*    */     //   106: iload_1
/*    */     //   107: ifne -> 172
/*    */     //   110: ifeq -> 144
/*    */     //   113: new java/lang/StringBuffer
/*    */     //   116: dup
/*    */     //   117: invokespecial <init> : ()V
/*    */     //   120: aload_2
/*    */     //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   124: sipush #-28719
/*    */     //   127: sipush #-29777
/*    */     //   130: invokestatic a : (II)Ljava/lang/String;
/*    */     //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   136: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   139: astore_2
/*    */     //   140: iload_1
/*    */     //   141: ifeq -> 242
/*    */     //   144: new java/lang/StringBuffer
/*    */     //   147: dup
/*    */     //   148: invokespecial <init> : ()V
/*    */     //   151: aload_2
/*    */     //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   155: sipush #-28714
/*    */     //   158: sipush #-17181
/*    */     //   161: invokestatic a : (II)Ljava/lang/String;
/*    */     //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   167: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   170: astore_2
/*    */     //   171: iconst_0
/*    */     //   172: istore_3
/*    */     //   173: iload_3
/*    */     //   174: aload_0
/*    */     //   175: getfield e : Ljava/util/List;
/*    */     //   178: invokeinterface size : ()I
/*    */     //   183: if_icmpge -> 230
/*    */     //   186: new java/lang/StringBuffer
/*    */     //   189: dup
/*    */     //   190: invokespecial <init> : ()V
/*    */     //   193: aload_2
/*    */     //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   197: aload_0
/*    */     //   198: getfield e : Ljava/util/List;
/*    */     //   201: iload_3
/*    */     //   202: invokeinterface get : (I)Ljava/lang/Object;
/*    */     //   207: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*    */     //   210: ldc ','
/*    */     //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   215: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   218: astore_2
/*    */     //   219: iinc #3, 1
/*    */     //   222: iload_1
/*    */     //   223: ifne -> 242
/*    */     //   226: iload_1
/*    */     //   227: ifeq -> 173
/*    */     //   230: aload_2
/*    */     //   231: iconst_0
/*    */     //   232: aload_2
/*    */     //   233: invokevirtual length : ()I
/*    */     //   236: iconst_1
/*    */     //   237: isub
/*    */     //   238: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   241: astore_2
/*    */     //   242: aload_2
/*    */     //   243: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #68	-> 0
/*    */     //   #74	-> 96
/*    */     //   #76	-> 113
/*    */     //   #80	-> 144
/*    */     //   #81	-> 171
/*    */     //   #83	-> 186
/*    */     //   #81	-> 219
/*    */     //   #85	-> 230
/*    */     //   #88	-> 242
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: bipush #6
/*    */     //   2: anewarray java/lang/String
/*    */     //   5: astore #5
/*    */     //   7: iconst_0
/*    */     //   8: istore_3
/*    */     //   9: ldc 'c¶AIc (ðmÂon\»CªM:Ôv¾¹"<}¿÷i:/Að(` ¤eº7_÷×LfxJ\\b¦:÷°áf97¦uÛe×³ãË%Qe2á¼§\\b£Û£CæL'
/*    */     //   11: dup
/*    */     //   12: astore_2
/*    */     //   13: invokevirtual length : ()I
/*    */     //   16: istore #4
/*    */     //   18: bipush #8
/*    */     //   20: istore_1
/*    */     //   21: iconst_m1
/*    */     //   22: istore_0
/*    */     //   23: iinc #0, 1
/*    */     //   26: aload_2
/*    */     //   27: iload_0
/*    */     //   28: dup
/*    */     //   29: iload_1
/*    */     //   30: iadd
/*    */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   34: jsr -> 137
/*    */     //   37: aload #5
/*    */     //   39: swap
/*    */     //   40: iload_3
/*    */     //   41: iinc #3, 1
/*    */     //   44: swap
/*    */     //   45: aastore
/*    */     //   46: iload_0
/*    */     //   47: iload_1
/*    */     //   48: iadd
/*    */     //   49: dup
/*    */     //   50: istore_0
/*    */     //   51: iload #4
/*    */     //   53: if_icmpge -> 65
/*    */     //   56: aload_2
/*    */     //   57: iload_0
/*    */     //   58: invokevirtual charAt : (I)C
/*    */     //   61: istore_1
/*    */     //   62: goto -> 23
/*    */     //   65: ldc 'XäÑlóNlD3µt/ò¿Ë¯©ñô&Ó>á+ô'
/*    */     //   67: dup
/*    */     //   68: astore_2
/*    */     //   69: invokevirtual length : ()I
/*    */     //   72: istore #4
/*    */     //   74: bipush #16
/*    */     //   76: istore_1
/*    */     //   77: iconst_m1
/*    */     //   78: istore_0
/*    */     //   79: iinc #0, 1
/*    */     //   82: aload_2
/*    */     //   83: iload_0
/*    */     //   84: dup
/*    */     //   85: iload_1
/*    */     //   86: iadd
/*    */     //   87: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   90: jsr -> 137
/*    */     //   93: aload #5
/*    */     //   95: swap
/*    */     //   96: iload_3
/*    */     //   97: iinc #3, 1
/*    */     //   100: swap
/*    */     //   101: aastore
/*    */     //   102: iload_0
/*    */     //   103: iload_1
/*    */     //   104: iadd
/*    */     //   105: dup
/*    */     //   106: istore_0
/*    */     //   107: iload #4
/*    */     //   109: if_icmpge -> 121
/*    */     //   112: aload_2
/*    */     //   113: iload_0
/*    */     //   114: invokevirtual charAt : (I)C
/*    */     //   117: istore_1
/*    */     //   118: goto -> 79
/*    */     //   121: aload #5
/*    */     //   123: putstatic net/portswigger/infiltrator/patcher/k.f : [Ljava/lang/String;
/*    */     //   126: bipush #6
/*    */     //   128: anewarray java/lang/String
/*    */     //   131: putstatic net/portswigger/infiltrator/patcher/k.g : [Ljava/lang/String;
/*    */     //   134: goto -> 274
/*    */     //   137: astore #6
/*    */     //   139: invokevirtual toCharArray : ()[C
/*    */     //   142: dup
/*    */     //   143: arraylength
/*    */     //   144: swap
/*    */     //   145: iconst_0
/*    */     //   146: istore #7
/*    */     //   148: swap
/*    */     //   149: dup_x1
/*    */     //   150: iconst_1
/*    */     //   151: if_icmpgt -> 252
/*    */     //   154: dup
/*    */     //   155: iload #7
/*    */     //   157: dup2
/*    */     //   158: caload
/*    */     //   159: iload #7
/*    */     //   161: bipush #7
/*    */     //   163: irem
/*    */     //   164: tableswitch default -> 234, 0 -> 204, 1 -> 209, 2 -> 214, 3 -> 220, 4 -> 225, 5 -> 229
/*    */     //   204: bipush #76
/*    */     //   206: goto -> 236
/*    */     //   209: bipush #117
/*    */     //   211: goto -> 236
/*    */     //   214: sipush #222
/*    */     //   217: goto -> 236
/*    */     //   220: bipush #22
/*    */     //   222: goto -> 236
/*    */     //   225: iconst_4
/*    */     //   226: goto -> 236
/*    */     //   229: bipush #8
/*    */     //   231: goto -> 236
/*    */     //   234: bipush #38
/*    */     //   236: ixor
/*    */     //   237: i2c
/*    */     //   238: castore
/*    */     //   239: iinc #7, 1
/*    */     //   242: swap
/*    */     //   243: dup_x1
/*    */     //   244: ifne -> 252
/*    */     //   247: dup2
/*    */     //   248: swap
/*    */     //   249: goto -> 157
/*    */     //   252: swap
/*    */     //   253: dup_x1
/*    */     //   254: iload #7
/*    */     //   256: if_icmpgt -> 154
/*    */     //   259: new java/lang/String
/*    */     //   262: dup_x1
/*    */     //   263: swap
/*    */     //   264: invokespecial <init> : ([C)V
/*    */     //   267: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   270: swap
/*    */     //   271: pop
/*    */     //   272: ret #6
/*    */     //   274: return
/*    */   }
/*    */   
/*    */   private static String a(int paramInt1, int paramInt2) {
/*    */     int i = (paramInt1 ^ 0xFFFF8FD4) & 0xFFFF;
/*    */     if (g[i] == null) {
/*    */       char[] arrayOfChar = f[i].toCharArray();
/*    */       switch (arrayOfChar[0] & 0xFF) {
/*    */         case 0:
/*    */         
/*    */         case 1:
/*    */         
/*    */         case 2:
/*    */         
/*    */         case 3:
/*    */         
/*    */         case 4:
/*    */         
/*    */         case 5:
/*    */         
/*    */         case 6:
/*    */         
/*    */         case 7:
/*    */         
/*    */         case 8:
/*    */         
/*    */         case 9:
/*    */         
/*    */         case 10:
/*    */         
/*    */         case 11:
/*    */         
/*    */         case 12:
/*    */         
/*    */         case 13:
/*    */         
/*    */         case 14:
/*    */         
/*    */         case 15:
/*    */         
/*    */         case 16:
/*    */         
/*    */         case 17:
/*    */         
/*    */         case 18:
/*    */         
/*    */         case 19:
/*    */         
/*    */         case 20:
/*    */         
/*    */         case 21:
/*    */         
/*    */         case 22:
/*    */         
/*    */         case 23:
/*    */         
/*    */         case 24:
/*    */         
/*    */         case 25:
/*    */         
/*    */         case 26:
/*    */         
/*    */         case 27:
/*    */         
/*    */         case 28:
/*    */         
/*    */         case 29:
/*    */         
/*    */         case 30:
/*    */         
/*    */         case 31:
/*    */         
/*    */         case 32:
/*    */         
/*    */         case 33:
/*    */         
/*    */         case 34:
/*    */         
/*    */         case 35:
/*    */         
/*    */         case 36:
/*    */         
/*    */         case 37:
/*    */         
/*    */         case 38:
/*    */         
/*    */         case 39:
/*    */         
/*    */         case 40:
/*    */         
/*    */         case 41:
/*    */         
/*    */         case 42:
/*    */         
/*    */         case 43:
/*    */         
/*    */         case 44:
/*    */         
/*    */         case 45:
/*    */         
/*    */         case 46:
/*    */         
/*    */         case 47:
/*    */         
/*    */         case 48:
/*    */         
/*    */         case 49:
/*    */         
/*    */         case 50:
/*    */         
/*    */         case 51:
/*    */         
/*    */         case 52:
/*    */         
/*    */         case 53:
/*    */         
/*    */         case 54:
/*    */         
/*    */         case 55:
/*    */         
/*    */         case 56:
/*    */         
/*    */         case 57:
/*    */         
/*    */         case 58:
/*    */         
/*    */         case 59:
/*    */         
/*    */         case 60:
/*    */         
/*    */         case 61:
/*    */         
/*    */         case 62:
/*    */         
/*    */         case 63:
/*    */         
/*    */         case 64:
/*    */         
/*    */         case 65:
/*    */         
/*    */         case 66:
/*    */         
/*    */         case 67:
/*    */         
/*    */         case 68:
/*    */         
/*    */         case 69:
/*    */         
/*    */         case 70:
/*    */         
/*    */         case 71:
/*    */         
/*    */         case 72:
/*    */         
/*    */         case 73:
/*    */         
/*    */         case 74:
/*    */         
/*    */         case 75:
/*    */         
/*    */         case 76:
/*    */         
/*    */         case 77:
/*    */         
/*    */         case 78:
/*    */         
/*    */         case 79:
/*    */         
/*    */         case 80:
/*    */         
/*    */         case 81:
/*    */         
/*    */         case 82:
/*    */         
/*    */         case 83:
/*    */         
/*    */         case 84:
/*    */         
/*    */         case 85:
/*    */         
/*    */         case 86:
/*    */         
/*    */         case 87:
/*    */         
/*    */         case 88:
/*    */         
/*    */         case 89:
/*    */         
/*    */         case 90:
/*    */         
/*    */         case 91:
/*    */         
/*    */         case 92:
/*    */         
/*    */         case 93:
/*    */         
/*    */         case 94:
/*    */         
/*    */         case 95:
/*    */         
/*    */         case 96:
/*    */         
/*    */         case 97:
/*    */         
/*    */         case 98:
/*    */         
/*    */         case 99:
/*    */         
/*    */         case 100:
/*    */         
/*    */         case 101:
/*    */         
/*    */         case 102:
/*    */         
/*    */         case 103:
/*    */         
/*    */         case 104:
/*    */         
/*    */         case 105:
/*    */         
/*    */         case 106:
/*    */         
/*    */         case 107:
/*    */         
/*    */         case 108:
/*    */         
/*    */         case 109:
/*    */         
/*    */         case 110:
/*    */         
/*    */         case 111:
/*    */         
/*    */         case 112:
/*    */         
/*    */         case 113:
/*    */         
/*    */         case 114:
/*    */         
/*    */         case 115:
/*    */         
/*    */         case 116:
/*    */         
/*    */         case 117:
/*    */         
/*    */         case 118:
/*    */         
/*    */         case 119:
/*    */         
/*    */         case 120:
/*    */         
/*    */         case 121:
/*    */         
/*    */         case 122:
/*    */         
/*    */         case 123:
/*    */         
/*    */         case 124:
/*    */         
/*    */         case 125:
/*    */         
/*    */         case 126:
/*    */         
/*    */         case 127:
/*    */         
/*    */         case 128:
/*    */         
/*    */         case 129:
/*    */         
/*    */         case 130:
/*    */         
/*    */         case 131:
/*    */         
/*    */         case 132:
/*    */         
/*    */         case 133:
/*    */         
/*    */         case 134:
/*    */         
/*    */         case 135:
/*    */         
/*    */         case 136:
/*    */         
/*    */         case 137:
/*    */         
/*    */         case 138:
/*    */         
/*    */         case 139:
/*    */         
/*    */         case 140:
/*    */         
/*    */         case 141:
/*    */         
/*    */         case 142:
/*    */         
/*    */         case 143:
/*    */         
/*    */         case 144:
/*    */         
/*    */         case 145:
/*    */         
/*    */         case 146:
/*    */         
/*    */         case 147:
/*    */         
/*    */         case 148:
/*    */         
/*    */         case 149:
/*    */         
/*    */         case 150:
/*    */         
/*    */         case 151:
/*    */         
/*    */         case 152:
/*    */         
/*    */         case 153:
/*    */         
/*    */         case 154:
/*    */         
/*    */         case 155:
/*    */         
/*    */         case 156:
/*    */         
/*    */         case 157:
/*    */         
/*    */         case 158:
/*    */         
/*    */         case 159:
/*    */         
/*    */         case 160:
/*    */         
/*    */         case 161:
/*    */         
/*    */         case 162:
/*    */         
/*    */         case 163:
/*    */         
/*    */         case 164:
/*    */         
/*    */         case 165:
/*    */         
/*    */         case 166:
/*    */         
/*    */         case 167:
/*    */         
/*    */         case 168:
/*    */         
/*    */         case 169:
/*    */         
/*    */         case 170:
/*    */         
/*    */         case 171:
/*    */         
/*    */         case 172:
/*    */         
/*    */         case 173:
/*    */         
/*    */         case 174:
/*    */         
/*    */         case 175:
/*    */         
/*    */         case 176:
/*    */         
/*    */         case 177:
/*    */         
/*    */         case 178:
/*    */         
/*    */         case 179:
/*    */         
/*    */         case 180:
/*    */         
/*    */         case 181:
/*    */         
/*    */         case 182:
/*    */         
/*    */         case 183:
/*    */         
/*    */         case 184:
/*    */         
/*    */         case 185:
/*    */         
/*    */         case 186:
/*    */         
/*    */         case 187:
/*    */         
/*    */         case 188:
/*    */         
/*    */         case 189:
/*    */         
/*    */         case 190:
/*    */         
/*    */         case 191:
/*    */         
/*    */         case 192:
/*    */         
/*    */         case 193:
/*    */         
/*    */         case 194:
/*    */         
/*    */         case 195:
/*    */         
/*    */         case 196:
/*    */         
/*    */         case 197:
/*    */         
/*    */         case 198:
/*    */         
/*    */         case 199:
/*    */         
/*    */         case 200:
/*    */         
/*    */         case 201:
/*    */         
/*    */         case 202:
/*    */         
/*    */         case 203:
/*    */         
/*    */         case 204:
/*    */         
/*    */         case 205:
/*    */         
/*    */         case 206:
/*    */         
/*    */         case 207:
/*    */         
/*    */         case 208:
/*    */         
/*    */         case 209:
/*    */         
/*    */         case 210:
/*    */         
/*    */         case 211:
/*    */         
/*    */         case 212:
/*    */         
/*    */         case 213:
/*    */         
/*    */         case 214:
/*    */         
/*    */         case 215:
/*    */         
/*    */         case 216:
/*    */         
/*    */         case 217:
/*    */         
/*    */         case 218:
/*    */         
/*    */         case 219:
/*    */         
/*    */         case 220:
/*    */         
/*    */         case 221:
/*    */         
/*    */         case 222:
/*    */         
/*    */         case 223:
/*    */         
/*    */         case 224:
/*    */         
/*    */         case 225:
/*    */         
/*    */         case 226:
/*    */         
/*    */         case 227:
/*    */         
/*    */         case 228:
/*    */         
/*    */         case 229:
/*    */         
/*    */         case 230:
/*    */         
/*    */         case 231:
/*    */         
/*    */         case 232:
/*    */         
/*    */         case 233:
/*    */         
/*    */         case 234:
/*    */         
/*    */         case 235:
/*    */         
/*    */         case 236:
/*    */         
/*    */         case 237:
/*    */         
/*    */         case 238:
/*    */         
/*    */         case 239:
/*    */         
/*    */         case 240:
/*    */         
/*    */         case 241:
/*    */         
/*    */         case 242:
/*    */         
/*    */         case 243:
/*    */         
/*    */         case 244:
/*    */         
/*    */         case 245:
/*    */         
/*    */         case 246:
/*    */         
/*    */         case 247:
/*    */         
/*    */         case 248:
/*    */         
/*    */         case 249:
/*    */         
/*    */         case 250:
/*    */         
/*    */         case 251:
/*    */         
/*    */         case 252:
/*    */         
/*    */         case 253:
/*    */         
/*    */         case 254:
/*    */         
/*    */         default:
/*    */           break;
/*    */       } 
/*    */       char c = 'ú';
/*    */       int j = (paramInt2 & 0xFF) - c;
/*    */       if (j < 0)
/*    */         j += 256; 
/*    */       int m = ((paramInt2 & 0xFFFF) >>> 8) - c;
/*    */       if (m < 0)
/*    */         m += 256; 
/*    */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*    */         int n = b % 2;
/*    */         if (n == 0) {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
/*    */           j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } else {
/*    */           arrayOfChar[b] = (char)(arrayOfChar[b] ^ m);
/*    */           m = ((m >>> 3 | m << 5) ^ arrayOfChar[b]) & 0xFF;
/*    */         } 
/*    */       } 
/*    */       g[i] = (new String(arrayOfChar)).intern();
/*    */     } 
/*    */     return g[i];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\k.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */