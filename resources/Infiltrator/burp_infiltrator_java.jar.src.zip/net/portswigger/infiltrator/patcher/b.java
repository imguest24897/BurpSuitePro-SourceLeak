/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class b
/*    */ {
/*    */   final String f;
/*    */   final String c;
/*    */   final int e;
/*    */   final String a;
/*    */   final String d;
/*    */   final String b;
/*    */   private static final String g;
/*    */   
/*    */   b(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5) {
/* 19 */     this.f = paramString2;
/* 20 */     this.c = paramString1.replaceAll(g, "/");
/* 21 */     this.e = paramInt;
/* 22 */     this.a = a(paramString3);
/* 23 */     this.d = paramString4;
/* 24 */     this.b = paramString5;
/*    */   }
/*    */ 
/*    */   
/*    */   private String a(String paramString) {
/* 29 */     if (this.e == 2)
/*    */     {
/* 31 */       return paramString.substring(0, paramString.indexOf(")") + 1) + "V";
/*    */     }
/*    */     
/* 34 */     return paramString;
/*    */   }
/*    */   
/*    */   public boolean a(String paramString1, String paramString2, String paramString3) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: istore #4
/*    */     //   5: aload_0
/*    */     //   6: getfield c : Ljava/lang/String;
/*    */     //   9: aload_1
/*    */     //   10: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   13: iload #4
/*    */     //   15: ifne -> 29
/*    */     //   18: ifeq -> 57
/*    */     //   21: aload_0
/*    */     //   22: getfield f : Ljava/lang/String;
/*    */     //   25: aload_2
/*    */     //   26: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   29: iload #4
/*    */     //   31: ifne -> 45
/*    */     //   34: ifeq -> 57
/*    */     //   37: aload_0
/*    */     //   38: getfield a : Ljava/lang/String;
/*    */     //   41: aload_3
/*    */     //   42: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   45: iload #4
/*    */     //   47: ifne -> 54
/*    */     //   50: ifeq -> 57
/*    */     //   53: iconst_1
/*    */     //   54: goto -> 58
/*    */     //   57: iconst_0
/*    */     //   58: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #39	-> 5
/*    */     //   #40	-> 26
/*    */     //   #41	-> 42
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: ldc 'µ'
/*    */     //   2: jsr -> 11
/*    */     //   5: putstatic net/portswigger/infiltrator/patcher/b.g : Ljava/lang/String;
/*    */     //   8: goto -> 145
/*    */     //   11: astore_0
/*    */     //   12: invokevirtual toCharArray : ()[C
/*    */     //   15: dup
/*    */     //   16: arraylength
/*    */     //   17: swap
/*    */     //   18: iconst_0
/*    */     //   19: istore_1
/*    */     //   20: swap
/*    */     //   21: dup_x1
/*    */     //   22: iconst_1
/*    */     //   23: if_icmpgt -> 124
/*    */     //   26: dup
/*    */     //   27: iload_1
/*    */     //   28: dup2
/*    */     //   29: caload
/*    */     //   30: iload_1
/*    */     //   31: bipush #7
/*    */     //   33: irem
/*    */     //   34: tableswitch default -> 106, 0 -> 72, 1 -> 78, 2 -> 84, 3 -> 90, 4 -> 95, 5 -> 101
/*    */     //   72: sipush #233
/*    */     //   75: goto -> 108
/*    */     //   78: sipush #191
/*    */     //   81: goto -> 108
/*    */     //   84: sipush #194
/*    */     //   87: goto -> 108
/*    */     //   90: bipush #27
/*    */     //   92: goto -> 108
/*    */     //   95: sipush #185
/*    */     //   98: goto -> 108
/*    */     //   101: bipush #79
/*    */     //   103: goto -> 108
/*    */     //   106: bipush #88
/*    */     //   108: ixor
/*    */     //   109: i2c
/*    */     //   110: castore
/*    */     //   111: iinc #1, 1
/*    */     //   114: swap
/*    */     //   115: dup_x1
/*    */     //   116: ifne -> 124
/*    */     //   119: dup2
/*    */     //   120: swap
/*    */     //   121: goto -> 28
/*    */     //   124: swap
/*    */     //   125: dup_x1
/*    */     //   126: iload_1
/*    */     //   127: if_icmpgt -> 26
/*    */     //   130: new java/lang/String
/*    */     //   133: dup_x1
/*    */     //   134: swap
/*    */     //   135: invokespecial <init> : ([C)V
/*    */     //   138: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   141: swap
/*    */     //   142: pop
/*    */     //   143: ret #0
/*    */     //   145: return
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\b.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */