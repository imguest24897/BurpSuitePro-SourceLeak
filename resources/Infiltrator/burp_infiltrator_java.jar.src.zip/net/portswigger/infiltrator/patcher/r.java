/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.Label;
/*    */ import org.objectweb.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class r
/*    */   extends MethodVisitor
/*    */ {
/* 14 */   Set c = new HashSet();
/* 15 */   Label d = null;
/* 16 */   Set a = new HashSet();
/*    */ 
/*    */   
/*    */   r(MethodVisitor paramMethodVisitor) {
/* 20 */     super(327680, paramMethodVisitor);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitInsn(int paramInt) {
/* 25 */     boolean bool = w.e; if (!bool) { if (paramInt == 0) {
/*    */         
/* 27 */         if (!bool) if (this.d == null) {
/*    */             
/* 29 */             super.visitInsn(paramInt);
/*    */             return;
/*    */           }  
/* 32 */         this.c.add(this.d);
/*    */       } 
/* 34 */       super.visitInsn(paramInt); }
/*    */   
/*    */   }
/*    */   
/*    */   public void visitLabel(Label paramLabel) {
/* 39 */     this.a.add(paramLabel);
/* 40 */     this.d = paramLabel;
/* 41 */     super.visitLabel(paramLabel);
/*    */   }
/*    */   
/*    */   public void visitFrame(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
/*    */     // Byte code:
/*    */     //   0: new java/util/ArrayList
/*    */     //   3: dup
/*    */     //   4: invokespecial <init> : ()V
/*    */     //   7: astore #7
/*    */     //   9: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   12: iconst_0
/*    */     //   13: istore #8
/*    */     //   15: istore #6
/*    */     //   17: iload #8
/*    */     //   19: iload #4
/*    */     //   21: if_icmpge -> 91
/*    */     //   24: iload #6
/*    */     //   26: ifne -> 115
/*    */     //   29: aload #5
/*    */     //   31: iload #8
/*    */     //   33: aaload
/*    */     //   34: instanceof org/objectweb/asm/Label
/*    */     //   37: iload #6
/*    */     //   39: ifne -> 82
/*    */     //   42: ifeq -> 70
/*    */     //   45: aload_0
/*    */     //   46: aload #5
/*    */     //   48: iload #8
/*    */     //   50: aaload
/*    */     //   51: checkcast org/objectweb/asm/Label
/*    */     //   54: invokespecial a : (Lorg/objectweb/asm/Label;)Z
/*    */     //   57: iload #6
/*    */     //   59: ifne -> 82
/*    */     //   62: ifeq -> 70
/*    */     //   65: iload #6
/*    */     //   67: ifeq -> 83
/*    */     //   70: aload #7
/*    */     //   72: aload #5
/*    */     //   74: iload #8
/*    */     //   76: aaload
/*    */     //   77: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   82: pop
/*    */     //   83: iinc #8, 1
/*    */     //   86: iload #6
/*    */     //   88: ifeq -> 17
/*    */     //   91: aload_0
/*    */     //   92: iload_1
/*    */     //   93: iload_2
/*    */     //   94: aload_3
/*    */     //   95: aload #7
/*    */     //   97: invokeinterface size : ()I
/*    */     //   102: aload #7
/*    */     //   104: invokeinterface toArray : ()[Ljava/lang/Object;
/*    */     //   109: checkcast [Ljava/lang/Object;
/*    */     //   112: invokespecial visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*    */     //   115: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #46	-> 0
/*    */     //   #47	-> 12
/*    */     //   #49	-> 24
/*    */     //   #51	-> 45
/*    */     //   #53	-> 65
/*    */     //   #56	-> 70
/*    */     //   #47	-> 83
/*    */     //   #59	-> 91
/*    */     //   #60	-> 115
/*    */   }
/*    */   
/*    */   private boolean a(Label paramLabel) {
/*    */     // Byte code:
/*    */     //   0: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   3: istore_2
/*    */     //   4: aload_0
/*    */     //   5: getfield c : Ljava/util/Set;
/*    */     //   8: aload_1
/*    */     //   9: invokeinterface contains : (Ljava/lang/Object;)Z
/*    */     //   14: iload_2
/*    */     //   15: ifne -> 39
/*    */     //   18: ifne -> 38
/*    */     //   21: aload_0
/*    */     //   22: getfield a : Ljava/util/Set;
/*    */     //   25: aload_1
/*    */     //   26: invokeinterface contains : (Ljava/lang/Object;)Z
/*    */     //   31: iload_2
/*    */     //   32: ifne -> 39
/*    */     //   35: ifne -> 42
/*    */     //   38: iconst_1
/*    */     //   39: goto -> 43
/*    */     //   42: iconst_0
/*    */     //   43: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #64	-> 4
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\r.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */