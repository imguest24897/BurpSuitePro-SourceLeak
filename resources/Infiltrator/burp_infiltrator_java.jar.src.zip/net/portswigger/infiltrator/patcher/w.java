/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.ClassReader;
/*    */ import org.objectweb.asm.ClassVisitor;
/*    */ import org.objectweb.asm.ClassWriter;
/*    */ import org.objectweb.asm.a;
/*    */ 
/*    */ public class w
/*    */ {
/*    */   public static final String d;
/*    */   public static String a;
/*    */   private final InputStream b;
/*    */   
/*    */   static Class a(String paramString) {
/*    */     
/* 19 */     try { return Class.forName(a.a(paramString)); } catch (ClassNotFoundException classNotFoundException) { throw (new NoClassDefFoundError()).initCause(classNotFoundException); }
/*    */   
/*    */   }
/*    */   
/*    */   private final String c;
/*    */   static Class f;
/*    */   public static boolean e;
/*    */   
/*    */   w(InputStream paramInputStream, String paramString) {
/* 28 */     this.b = paramInputStream;
/* 29 */     this.c = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   l a(List paramList) {
/* 34 */     InputStream[] arrayOfInputStream = a(this.b);
/*    */     
/* 36 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 38 */     a(arrayOfInputStream[0], paramList, arrayList);
/* 39 */     boolean bool = e; ClassWriter classWriter = b(arrayOfInputStream[1], paramList, arrayList);
/* 40 */     classWriter = a(classWriter.toByteArray());
/*    */ 
/*    */     
/* 43 */     byte[] arrayOfByte = classWriter.toByteArray();
/* 44 */     ClassReader classReader = new ClassReader(arrayOfByte);
/* 45 */     if (classReader.getClassName().indexOf("/") != -1)
/*    */     {
/* 47 */       return new l(this.c, arrayOfByte, classReader.getClassName().substring(0, classReader.getClassName().lastIndexOf("/")));
/*    */     }
/*    */ 
/*    */     
/* 51 */     if (ClassVisitor.b) e = !bool;  return new l(this.c, arrayOfByte, classReader.getClassName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ClassWriter a(byte[] paramArrayOfbyte) {
/* 71 */     ClassReader classReader = new ClassReader(paramArrayOfbyte);
/* 72 */     ClassWriter classWriter = new ClassWriter(0);
/* 73 */     classReader.accept(new g(this, 327680, classWriter), 0);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     return classWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   private ClassWriter b(InputStream paramInputStream, List paramList1, List paramList2) {
/* 85 */     ClassReader classReader = new ClassReader(paramInputStream);
/* 86 */     ClassWriter classWriter = new ClassWriter(0);
/* 87 */     classReader.accept(new h(this, classWriter, paramList1, false, paramList2), 8);
/* 88 */     return classWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   private void a(InputStream paramInputStream, List paramList1, List paramList2) {
/* 93 */     h h = new h(this, null, paramList1, true, paramList2);
/* 94 */     ClassReader classReader = new ClassReader(paramInputStream);
/* 95 */     classReader.accept(h, 8);
/*    */   }
/*    */   
/*    */   private InputStream[] a(InputStream paramInputStream) {
/*    */     // Byte code:
/*    */     //   0: new java/io/ByteArrayOutputStream
/*    */     //   3: dup
/*    */     //   4: invokespecial <init> : ()V
/*    */     //   7: astore_3
/*    */     //   8: getstatic net/portswigger/infiltrator/patcher/w.e : Z
/*    */     //   11: sipush #1024
/*    */     //   14: newarray byte
/*    */     //   16: astore #4
/*    */     //   18: istore_2
/*    */     //   19: aload_1
/*    */     //   20: aload #4
/*    */     //   22: invokevirtual read : ([B)I
/*    */     //   25: dup
/*    */     //   26: istore #5
/*    */     //   28: iconst_m1
/*    */     //   29: if_icmple -> 49
/*    */     //   32: aload_3
/*    */     //   33: aload #4
/*    */     //   35: iconst_0
/*    */     //   36: iload #5
/*    */     //   38: invokevirtual write : ([BII)V
/*    */     //   41: iload_2
/*    */     //   42: ifne -> 53
/*    */     //   45: iload_2
/*    */     //   46: ifeq -> 19
/*    */     //   49: aload_3
/*    */     //   50: invokevirtual flush : ()V
/*    */     //   53: iconst_2
/*    */     //   54: anewarray java/io/ByteArrayInputStream
/*    */     //   57: dup
/*    */     //   58: iconst_0
/*    */     //   59: new java/io/ByteArrayInputStream
/*    */     //   62: dup
/*    */     //   63: aload_3
/*    */     //   64: invokevirtual toByteArray : ()[B
/*    */     //   67: invokespecial <init> : ([B)V
/*    */     //   70: aastore
/*    */     //   71: dup
/*    */     //   72: iconst_1
/*    */     //   73: new java/io/ByteArrayInputStream
/*    */     //   76: dup
/*    */     //   77: aload_3
/*    */     //   78: invokevirtual toByteArray : ()[B
/*    */     //   81: invokespecial <init> : ([B)V
/*    */     //   84: aastore
/*    */     //   85: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #100	-> 0
/*    */     //   #101	-> 8
/*    */     //   #103	-> 19
/*    */     //   #105	-> 32
/*    */     //   #107	-> 49
/*    */     //   #109	-> 53
/*    */   }
/*    */   
/*    */   static {
/*    */     // Byte code:
/*    */     //   0: iconst_2
/*    */     //   1: anewarray java/lang/String
/*    */     //   4: astore #6
/*    */     //   6: iconst_0
/*    */     //   7: istore #4
/*    */     //   9: ldc 'àKIÚê¬À%ÝJéé¿ÇIBþá¨ÁÂWEÿï¡Ç__öôãàKIÚê¬À'
/*    */     //   11: dup
/*    */     //   12: astore_3
/*    */     //   13: invokevirtual length : ()I
/*    */     //   16: istore #5
/*    */     //   18: bipush #9
/*    */     //   20: istore_2
/*    */     //   21: iconst_m1
/*    */     //   22: istore_1
/*    */     //   23: iinc #1, 1
/*    */     //   26: aload_3
/*    */     //   27: iload_1
/*    */     //   28: dup
/*    */     //   29: iload_2
/*    */     //   30: iadd
/*    */     //   31: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   34: jsr -> 72
/*    */     //   37: aload #6
/*    */     //   39: swap
/*    */     //   40: iload #4
/*    */     //   42: iinc #4, 1
/*    */     //   45: swap
/*    */     //   46: aastore
/*    */     //   47: iload_1
/*    */     //   48: iload_2
/*    */     //   49: iadd
/*    */     //   50: dup
/*    */     //   51: istore_1
/*    */     //   52: iload #5
/*    */     //   54: if_icmpge -> 66
/*    */     //   57: aload_3
/*    */     //   58: iload_1
/*    */     //   59: invokevirtual charAt : (I)C
/*    */     //   62: istore_2
/*    */     //   63: goto -> 23
/*    */     //   66: aload #6
/*    */     //   68: astore_0
/*    */     //   69: goto -> 211
/*    */     //   72: astore #7
/*    */     //   74: invokevirtual toCharArray : ()[C
/*    */     //   77: dup
/*    */     //   78: arraylength
/*    */     //   79: swap
/*    */     //   80: iconst_0
/*    */     //   81: istore #8
/*    */     //   83: swap
/*    */     //   84: dup_x1
/*    */     //   85: iconst_1
/*    */     //   86: if_icmpgt -> 189
/*    */     //   89: dup
/*    */     //   90: iload #8
/*    */     //   92: dup2
/*    */     //   93: caload
/*    */     //   94: iload #8
/*    */     //   96: bipush #7
/*    */     //   98: irem
/*    */     //   99: tableswitch default -> 170, 0 -> 136, 1 -> 142, 2 -> 148, 3 -> 153, 4 -> 158, 5 -> 164
/*    */     //   136: sipush #179
/*    */     //   139: goto -> 173
/*    */     //   142: sipush #236
/*    */     //   145: goto -> 173
/*    */     //   148: bipush #62
/*    */     //   150: goto -> 173
/*    */     //   153: bipush #43
/*    */     //   155: goto -> 173
/*    */     //   158: sipush #153
/*    */     //   161: goto -> 173
/*    */     //   164: sipush #134
/*    */     //   167: goto -> 173
/*    */     //   170: sipush #205
/*    */     //   173: ixor
/*    */     //   174: i2c
/*    */     //   175: castore
/*    */     //   176: iinc #8, 1
/*    */     //   179: swap
/*    */     //   180: dup_x1
/*    */     //   181: ifne -> 189
/*    */     //   184: dup2
/*    */     //   185: swap
/*    */     //   186: goto -> 92
/*    */     //   189: swap
/*    */     //   190: dup_x1
/*    */     //   191: iload #8
/*    */     //   193: if_icmpgt -> 89
/*    */     //   196: new java/lang/String
/*    */     //   199: dup_x1
/*    */     //   200: swap
/*    */     //   201: invokespecial <init> : ([C)V
/*    */     //   204: invokevirtual intern : ()Ljava/lang/String;
/*    */     //   207: swap
/*    */     //   208: pop
/*    */     //   209: ret #7
/*    */     //   211: getstatic net/portswigger/infiltrator/patcher/w.f : Ljava/lang/Class;
/*    */     //   214: ifnonnull -> 230
/*    */     //   217: aload_0
/*    */     //   218: iconst_1
/*    */     //   219: aaload
/*    */     //   220: invokestatic a : (Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   223: dup
/*    */     //   224: putstatic net/portswigger/infiltrator/patcher/w.f : Ljava/lang/Class;
/*    */     //   227: goto -> 233
/*    */     //   230: getstatic net/portswigger/infiltrator/patcher/w.f : Ljava/lang/Class;
/*    */     //   233: invokevirtual getPackage : ()Ljava/lang/Package;
/*    */     //   236: invokevirtual getName : ()Ljava/lang/String;
/*    */     //   239: putstatic net/portswigger/infiltrator/patcher/w.d : Ljava/lang/String;
/*    */     //   242: aload_0
/*    */     //   243: iconst_0
/*    */     //   244: aaload
/*    */     //   245: putstatic net/portswigger/infiltrator/patcher/w.a : Ljava/lang/String;
/*    */     //   248: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #19	-> 211
/*    */     //   #21	-> 242
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\w.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */