/*    */ package net.portswigger.infiltrator.patcher;
/*    */ 
/*    */ public class j
/*    */ {
/*  5 */   public static final j a = new j();
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(String paramString) {
/* 10 */     System.out.println(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(String paramString) {
/* 15 */     System.err.println(paramString);
/*    */   }
/*    */   public void a(StackTraceElement[] paramArrayOfStackTraceElement) {
/*    */     boolean bool;
/*    */     byte b;
/* 20 */     for (b = 0, bool = w.e; b < paramArrayOfStackTraceElement.length; ) {
/*    */       
/* 22 */       System.err.println("\t" + paramArrayOfStackTraceElement[b].toString());
/*    */       b++;
/*    */       if (bool)
/*    */         break; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Infiltrator\burp_infiltrator_java.jar!\net\portswigger\infiltrator\patcher\j.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */